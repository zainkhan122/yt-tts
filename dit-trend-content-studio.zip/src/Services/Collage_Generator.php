<?php

namespace DIT\TrendStudio\Services;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

class Collage_Generator
{
    private int $canvas_width;
    private int $canvas_height;
    private int $image_area_height;
    private int $bar_height;
    private int $heading_band_height = 0;
    private int $desc_band_height = 0;
	private int $heading_font_size = 0;
	private int $desc_font_size = 0;
	private int $heading_fitted_font_size = 0;
	private int $desc_fitted_font_size = 0;
	private string $social_font_file = '';
    public int $width;
    public int $height;
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    // Professional color palettes (Hex) - Deep, rich tones
    private const PALETTES = [
        '#1A2B4C', // Deep Navy
        '#2C3E50', // Charcoal Blue
        '#4A151B', // Burgundy
        '#1E3F20', // Forest Green
        '#34495E', // Wet Asphalt
        '#2E151B', // Dark Plum
        '#003366', // Midnight Blue
        '#333333', // Dark Grey
    ];

    /**
     * Get available layouts for a given number of images
     */
    public static function get_available_layouts(int $count): array
    {
        switch ($count) {
            // @MODIFIED 2026-02-19 - Support 1 image with a stable layout key for UI rendering.
            case 1:
                return [
                    'single' => \__('Single Image', 'dit-trend-content-studio'),
                ];
            case 2:
                return [
                    '2-cols' => '2 Columns (Split)',
                    '2-rows' => \__('Two Rows (Stacked)', 'dit-trend-content-studio'),
                ];
            case 3:
                return [
                    '3-cols' => '3 Columns (1-1-1)',
                    '1-2'    => '2 Columns (1 Left, 2 Right)',
                ];
            case 4:
                return [
                    '2x2'   => '2x2 Grid (2 Rows, 2 Cols)',
                    '1-2-1' => '3 Columns (1-2-1)',
                    '2-1-1' => '3 Columns (2-1-1)',
                    '1-1-2' => '3 Columns (1-1-2)',
                ];
            case 5:
                return [
                    '2-2-1' => '3 Columns (2-2-1)',
                    '1-2-2' => '3 Columns (1-2-2)',
                    '2-1-2' => '3 Columns (2-1-2)',
                ];
            case 6:
                return [
                    '2-2-2' => 'Grid (2-2-2)',
                ];
            default:
                return [];
        }
    }

    /**
     * Creates a professional grid collage with bottom bar
     *
     * @param array  $image_urls  List of 2-6 image URLs
     * @param string $title       For attachment metadata
 * @param array $options Configuration options:
 * - vertical (string)
 * - bottom_text (string)
 * - is_retina (bool)
 * - border_color (string hex)
 * - font_file (string path)
 * - layout (string key)
 * - format (string: webp, jpg, png)
 * - social_font (string filename)
 * - social_heading_bg (string hex)
     * - social_heading_color (string hex)
     * - social_desc_bg (string hex)
     * - social_desc_color (string hex)
     * - image_area_pct (int) percentage of canvas for image area (default 50)
     * - heading_area_pct (int) percentage of canvas for heading band (default 20)
     * - desc_area_pct (int) percentage of canvas for description band (default 20)
     * - bar_area_pct (int) percentage of canvas for brand bar (default 10)
     * @return int|WP_Error Attachment ID on success, WP_Error on failure
     * @MODIFIED 2026-02-18 - Added support for 2-6 images and specific layouts
     */
    public function create_collage(array $image_urls, string $title, array $options = [])
    {
        // Defaults
        $defaults = [
            'vertical'        => 'general',
            'bottom_text'     => '',
            'is_retina'       => true,
            'border_color'    => '',
            'font_file'       => '',
            'layout'          => '',
            'format'          => 'webp',
            'crops'           => [],
            'use_brand_logo'  => false, // @MODIFIED 2026-03-13 - Fixed branding leakage
            'letter_spacing'  => 10,    // @MODIFIED 2026-03-18 - Set default to 10 per specs
        'bar_font_file' => '',
        'bar_font_size' => 24,
        'bar_text_color' => '',
        'bar_accent_line' => false,
        'social_font' => '',
        'social_heading_bg' => '',
        'social_heading_color' => '',
        'social_desc_bg' => '',
        'social_desc_color' => '',
    ];

        // Backwards compatibility for old signature
        if (!is_array($options)) {
            // If 2nd arg was title (handled), 3rd was vertical, 4th text, 5th retina
            // We can't easily map this reliably without breaking changes if args were messy.
            // Assuming simplified usage or consistent named args in new calls.
        }

        $opts = \wp_parse_args($options, $defaults);
        $this->ensure_media_includes(); // @MODIFIED 2026-02-21 - Load dependencies early to avoid fatal error on wp_tempnam

        $image_urls = array_values(array_unique(array_filter(array_map('trim', $image_urls))));
        $count = count($image_urls);
        // @MODIFIED Phase 7: Support 1 image
        if ($count < 1) {
            return new WP_Error('dit_ts_collage_not_enough_images', 'Not enough images for collage');
        }

        if (!function_exists('imagecreatetruecolor') || !function_exists('imagecreatefromstring')) {
            return new WP_Error('dit_ts_collage_gd_missing', 'GD extension is not available');
        }

        // @MODIFIED 2026-02-18 - Removed premature truncation min($count, 6)
        // We now iterate through ALL candidates until we fill the slots.

        // @MODIFIED Phase 10 & 11: Dynamic Aspect Ratio & Custom Dimensions
        $scale = $opts['is_retina'] ? 2 : 1;

        // @MODIFIED 2026-02-19 - Default to 700x412 (Post Standard) per user request
        $aspect_ratio = $opts['aspect_ratio'] ?? 'legacy';
        $target_w = 700; // default
        $target_h = 412; // default

        $ratio_map = [
            '1:1'  => 1.0,
            '4:5'  => 1.25,
            '9:16' => 1.777,
            '16:9' => 0.5625,
        ];

        if ($aspect_ratio === 'legacy') {
            $target_w = 700;
            $target_h = 412;
        } elseif ($aspect_ratio === 'custom') {
            $target_w = (int)($opts['custom_width'] ?? 800);
            $target_h = (int)($opts['custom_height'] ?? 800);
        } elseif (isset($ratio_map[$aspect_ratio])) {
            $target_w = 800;
            $target_h = (int) round($target_w * $ratio_map[$aspect_ratio]);
        } elseif (preg_match('/^(\d+):(\d+)$/', (string) $aspect_ratio, $m)) {
            // @MODIFIED 2026-02-19 - Support arbitrary ratios (e.g. 19:6, 19:16) without hardcoding.
            $rw = max(1, (int) $m[1]);
            $rh = max(1, (int) $m[2]);
            $target_w = 800;
            $target_h = (int) round($target_w * ($rh / $rw));
        }

        $this->canvas_width = $target_w * $scale;
        $this->width = $this->canvas_width;

        $total_height = $target_h * $scale;
        // @MODIFIED 2026-02-19 - Dynamic bottom bar height so typography controls (line-height, multi-line)
        // are accurately reflected and never clipped.
        if (empty($opts['bottom_text'])) {
            $this->bar_height = 0;
        } else {
            $base = (int) ($total_height * 0.08);
            $min = 40 * $scale;

            $font_size = (int) ($opts['bar_font_size'] ?? $opts['font_size'] ?? 24) * $scale;
            $line_height_mult = (float) ($opts['line_height'] ?? 1.2);
            $lines = explode("\n", (string) $opts['bottom_text']);
            $line_count = max(1, count($lines));
            $text_h = (int) ceil($font_size * $line_count * $line_height_mult);
            $pad = 20 * $scale;
            $required = $text_h + $pad;

        $this->bar_height = max($base, $min, $required);

        // @MODIFIED 2026-04-21 - Enforce minimum brand bar height of 10% for social collages
        // @MODIFIED 2026-04-22 - Use dynamic bar_area_pct from settings (default 10%)
        if (!empty($opts['social_bands'])) {
            $bar_pct = max(5, min(30, (int)($opts['bar_area_pct'] ?? 10))) / 100;
            $min_brand_bar = (int)($total_height * $bar_pct);
            $this->bar_height = max($this->bar_height, $min_brand_bar);
        }

        // Safety clamp: don't let the bar consume the canvas.
        $max_bar = (int) floor($total_height * 0.30);
        if ($this->bar_height > $max_bar) {
            $this->bar_height = $max_bar;
        }
        }

        // @MODIFIED 2026-03-13 - Compute band heights from ACTUAL text content
        // Old fixed 22%/28% produced huge empty colored bands with tiny text.
        $this->heading_band_height = 0;
        $this->desc_band_height    = 0;

	if (!empty($opts['social_bands'])) {
		$social_font = $this->resolve_social_font($opts);
		$h_font_size = (int)(($opts['heading_font_size'] ?? 36) * $scale);
		$d_font_size = (int)(($opts['desc_font_size'] ?? 26) * $scale);

		$image_pct = max(10, min(80, (int)($opts['image_area_pct'] ?? 50))) / 100;
		$heading_pct = max(5, min(50, (int)($opts['heading_area_pct'] ?? 20))) / 100;
		$desc_pct = max(5, min(50, (int)($opts['desc_area_pct'] ?? 20))) / 100;
		$bar_pct_val = max(5, min(30, (int)($opts['bar_area_pct'] ?? 10))) / 100;

		$raw_sum = $image_pct + $heading_pct + $desc_pct + $bar_pct_val;
		if ($raw_sum > 0) {
			$image_pct /= $raw_sum;
			$heading_pct /= $raw_sum;
			$desc_pct /= $raw_sum;
		}

		$heading_budget = (int)($total_height * $heading_pct);
		$desc_budget = (int)($total_height * $desc_pct);

	$h_pad = (int)(20 * $scale);
	$v_pad = (int)(15 * $scale);
	// @MODIFIED 2026-05-08 - Tighter vertical padding for heading band so the
	// larger font has more breathing room, reducing height-triggered scale-down.
	$h_v_pad = (int)(10 * $scale);
	$max_text_w = $this->canvas_width - ($h_pad * 2);

	$h_text = wp_strip_all_tags(html_entity_decode((string)($opts['social_bands']['heading'] ?? ''), ENT_QUOTES | ENT_XML1, 'UTF-8'));
	$d_text = wp_strip_all_tags(html_entity_decode((string)($opts['social_bands']['description'] ?? ''), ENT_QUOTES | ENT_XML1, 'UTF-8'));

	$accent_h = (int)(3 * $scale);
	$h_text_area_h = max(0, $heading_budget - ($h_v_pad * 2) - $accent_h);
	$d_text_area_h = max(0, $desc_budget - ($v_pad * 2));

	$this->heading_fitted_font_size = !empty($h_text) ? $this->auto_fit_font_size($h_text, $social_font, $h_font_size, $max_text_w, $h_text_area_h, true) : $h_font_size;
	$this->desc_fitted_font_size = !empty($d_text) ? $this->auto_fit_font_size($d_text, $social_font, $d_font_size, $max_text_w, $d_text_area_h) : $d_font_size;

		// @MODIFIED 2026-05-04 - Use direct Pango pixel height for accurate band sizing.
		// The old lines*line_h round-trip underestimated Nastaliq heights because
		// measure_font_line_height (GD/imagettfbbox) is inaccurate for Nastaliq stacking.
		$h_pango_h = !empty($h_text) ? $this->pango_measure_rendered_height($h_text, $this->heading_fitted_font_size, $social_font, $max_text_w) : 0;
		$d_pango_h = !empty($d_text) ? $this->pango_measure_rendered_height($d_text, $this->desc_fitted_font_size, $social_font, $max_text_w) : 0;

	if ($h_pango_h > 0) {
		$content_heading_h = (int)($h_pango_h + $h_v_pad * 2 + $accent_h);
	} else {
		$h_line_count = !empty($h_text) ? $this->pango_estimate_line_count($h_text, $this->heading_fitted_font_size, $social_font, $max_text_w) : 0;
		$h_line_h = !empty($h_text) ? $this->measure_font_line_height($this->heading_fitted_font_size, $social_font) : 0;
		$content_heading_h = ($h_line_h > 0 && $h_line_count > 0) ? (int)($h_line_h * $h_line_count + $h_v_pad * 2 + $accent_h) : 0;
	}

		if ($d_pango_h > 0) {
			$content_desc_h = (int)($d_pango_h + $v_pad * 2);
		} else {
			$d_line_count = !empty($d_text) ? $this->pango_estimate_line_count($d_text, $this->desc_fitted_font_size, $social_font, $max_text_w) : 0;
			$d_line_h = !empty($d_text) ? $this->measure_font_line_height($this->desc_fitted_font_size, $social_font) : 0;
			$content_desc_h = ($d_line_h > 0 && $d_line_count > 0) ? (int)($d_line_h * $d_line_count + $v_pad * 2) : 0;
		}

	$this->heading_band_height = max($content_heading_h, $heading_budget);
	$this->desc_band_height = max($content_desc_h, $desc_budget);

	// @MODIFIED 2026-05-08 - HEADING PRIORITY: Heading gets its required height first
	// (capped at 45% of combined text area). Description gets the remainder.
	// This prevents a long description from "stealing" the heading's height via
	// proportional shrinking, which caused headings to wrap and then shrink-to-fit
	// leaving wide empty margins.
	$max_combined = (int)($total_height * ($heading_pct + $desc_pct));
	$combined = $this->heading_band_height + $this->desc_band_height;
	if ($combined > $max_combined) {
		$heading_cap = (int)($max_combined * 0.45);
		$this->heading_band_height = min($this->heading_band_height, $heading_cap);
		$this->desc_band_height = max(0, $max_combined - $this->heading_band_height);

		$h_text_area_h_clamped = max(0, $this->heading_band_height - ($h_v_pad * 2) - $accent_h);
		$d_text_area_h_clamped = max(0, $this->desc_band_height - ($v_pad * 2));

		if (!empty($h_text)) {
			$this->heading_fitted_font_size = $this->auto_fit_font_size($h_text, $social_font, $h_font_size, $max_text_w, $h_text_area_h_clamped, true);
		}
		if (!empty($d_text)) {
			$this->desc_fitted_font_size = $this->auto_fit_font_size($d_text, $social_font, $d_font_size, $max_text_w, $d_text_area_h_clamped);
		}
	}

	// @MODIFIED 2026-05-08 - Minimum band height: if social_bands are requested but
	// text is missing, enforce a visible minimum so the band renders as an empty
	// colored strip (alerting to error) instead of collapsing to 0px and producing
	// a broken plain grid.
	if (!empty($opts['social_bands'])) {
		$min_band = (int)($total_height * 0.06);
		if ($this->heading_band_height < $min_band && !empty($opts['social_bands']['heading'])) {
			$this->heading_band_height = $min_band;
		}
		if ($this->desc_band_height < $min_band && !empty($opts['social_bands']['description'])) {
			$this->desc_band_height = $min_band;
		}
	}

		if (empty($social_font) || !file_exists($social_font)) {
			if (isset($this->logger)) {
				$this->logger->error('Social collage: Urdu font not found. Searched paths may be invalid. Expected in: ' . __DIR__ . '/../../assets/fonts/');
			}
		}

		$this->heading_font_size = $h_font_size;
		$this->desc_font_size = $d_font_size;
		$this->social_font_file = $social_font;
}

$this->image_area_height = $total_height - $this->bar_height - $this->heading_band_height - $this->desc_band_height;
        $this->height = (int)$total_height;

	$canvas = imagecreatetruecolor($this->width, $this->height);
	if (!$canvas) {
		return new WP_Error('dit_ts_collage_canvas_failed', 'Failed to create image canvas');
	}
	imagesavealpha($canvas, true);

        // Determine Border/Theme Color
        $theme_hex = (!empty($opts['border_color']) && preg_match('/^#[a-f0-9]{6}$/i', $opts['border_color']))
            ? $opts['border_color']
            : self::PALETTES[array_rand(self::PALETTES)];

        $opts['border_color'] = $theme_hex;

        if (empty($opts['bar_text_color'])) {
            $opts['bar_text_color'] = $this->get_contrasting_text_hex($theme_hex);
        }

        list($r, $g, $b) = sscanf($theme_hex, "#%02x%02x%02x");
        $theme_color = imagecolorallocate($canvas, $r, $g, $b);

        // Fill background with theme color
        imagefill($canvas, 0, 0, $theme_color);

        // Prepare source images
        $sources = [];
        $seen_hashes = []; // @MODIFIED 2026-02-24 - Tracking content hashes to prevent duplicates
        $temp_files = [];
        $errors = [];

        // @MODIFIED 2026-02-19 - Allow explicit target count for specific layouts (e.g. fashion 3-cols)
        // Default to 6 if not specified.
        $max_sources = isset($opts['target_count']) ? (int)$opts['target_count'] : 6;

        // @MODIFIED 2026-02-18 - Robust Loop: Try ALL candidates until we have enough
        foreach ($image_urls as $url) {
            if (count($sources) >= $max_sources) {
                break;
            }

            $err = '';
            // @MODIFIED 2026-02-24 - Load raw bytes first to check MD5 for deduplication
            $bytes = $this->load_image_bytes_from_url($url, $err);
            if ($bytes) {
                $hash = md5($bytes);
                if (in_array($hash, $seen_hashes, true)) {
                    continue; // Skip duplicate content
                }

                $img = @imagecreatefromstring($bytes);
                if ($img) {
                    $sources[] = $img;
                    $seen_hashes[] = $hash;
                } else {
                    $errors[] = "Failed to create image resource from string: " . substr($url, 0, 50) . '...';
                }
            } else {
                // Keep track of errors but don't stop
                $errors[] = $err ?: ("Failed to load image: " . substr($url, 0, 50) . '...');
            }
        }

        $final_count = count($sources);
        if ($final_count < 2) { // Need at least 2 for a collage (or 1 if single image support enabled, checking line 111 logic compatibility)
            // Re-check logic: line 111 returned error if input count < 1. 
            // Here we check loaded count. If we loaded 0, fail. If we loaded 1, it's just a single image passthrough?
            // Existing code said "Changed from 2 to 1" at line 188. Let's stick to 1 as minimum successful load.
            if ($final_count < 1) {
                imagedestroy($canvas);
                return new WP_Error(
                    'dit_ts_collage_sources_failed',
                    'Failed to load enough valid source images. Tried ' . count($image_urls) . ' candidates.',
                    ['errors' => array_slice($errors, 0, 5)]
                );
            }
        }

        // Draw Grid
        $this->draw_grid($canvas, $sources, $opts['layout'], $scale, $opts['crops'], $opts);

	// Draw Social Text Bands
	if (!empty($opts['social_bands'])) {
		$bands_ok = $this->draw_social_bands($canvas, $opts['social_bands'], $opts, $scale);
		if (!$bands_ok) {
			foreach ($sources as $r) {
				if (is_resource($r) || $r instanceof \GdImage) {
					@imagedestroy($r);
				}
			}
			imagedestroy($canvas);
			return new WP_Error(
				'dit_ts_collage_urdu_render_failed',
				'Urdu text rendering failed. Server requires (1) exec() enabled in PHP, (2) ImageMagick binary with Pango support compiled in, (3) Noto Nastaliq Urdu font registered in fontconfig. Run "convert -list font" on the server to verify Pango font availability.'
			);
		}
	}

        // Draw Bottom Bar (Color is already set by fill, but let's be explicit if needed)
        if (!empty($opts['bottom_text'])) {
            $this->draw_bottom_bar($canvas, $opts['bottom_text'], $opts, $scale);
        }

        // Cleanup source resources
        foreach ($sources as $r) {
            if (is_resource($r) || $r instanceof \GdImage) {
                @imagedestroy($r);
            }
        }

        // Save
        $ext = '.' . $opts['format'];
        $temp_file = \wp_tempnam('dit-ts-collage'); // @MODIFIED 2026-02-21 - Use global namespace
        // Rename
        $temp_file_ext = $temp_file . $ext;
        @rename($temp_file, $temp_file_ext);
        $temp_file = $temp_file_ext;

        $saved = false;
        if ($opts['format'] === 'png') {
            $saved = imagepng($canvas, $temp_file, 9);
            $type = 'image/png';
        } elseif ($opts['format'] === 'jpg' || $opts['format'] === 'jpeg') {
            $saved = imagejpeg($canvas, $temp_file, 90);
            $type = 'image/jpeg';
        } else {
            // WebP Default
            $saved = imagewebp($canvas, $temp_file, 90);
            $type = 'image/webp';
        }

        imagedestroy($canvas);

        if (!$saved || !file_exists($temp_file)) {
            return new WP_Error('dit_ts_collage_save_failed', 'Failed to write collage image to temp file');
        }

        // @MODIFIED 2026-02-21 - ensure_media_includes() moved to top of create_collage()

        $file_array = [
            'name'     => \sanitize_title($title) . '-collage' . $ext,
            'tmp_name' => $temp_file,
            'type'     => $type,
            'error'    => 0,
            'size'     => (int) (@\filesize($temp_file) ?: 0),
        ];

        $attachment_id = \media_handle_sideload($file_array, 0, $title);

        if (!is_wp_error($attachment_id) && $attachment_id) {
            $metadata = \wp_get_attachment_metadata($attachment_id);
            if (empty($metadata)) {
                $attach_file = \get_attached_file($attachment_id);
                if ($attach_file && \file_exists($attach_file)) {
                    $metadata = \wp_generate_attachment_metadata($attachment_id, $attach_file);
                    \wp_update_attachment_metadata($attachment_id, $metadata);
                }
            }
            \update_post_meta($attachment_id, '_wp_attachment_image_alt', $title);
        }

        @unlink($temp_file);

        return is_wp_error($attachment_id) ? $attachment_id : (int) $attachment_id;
    }

    private function ensure_media_includes(): void
    {
        if (function_exists('media_handle_sideload')) {
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    /**
     * Load raw image bytes from a URL.
     * Resolution order:
     *  1. attachment_url_to_postid() → get_attached_file() (fastest, no HTTP)
     *  2. Protocol-agnostic filesystem mapping via wp_upload_dir() (handles http/https mismatch)
     *  3. wp_safe_remote_get() with 5s timeout as last resort (fails fast instead of hanging)
     *
     * @param  string $url       Full attachment URL.
     * @param  string $error_out Populated on failure.
     * @return string|false      Raw bytes or false on failure.
     */
    private function load_image_bytes_from_url(string $url, string &$error_out)
    {
        $error_out = '';

        if (! filter_var($url, FILTER_VALIDATE_URL)) {
            // @MODIFIED 2026-07-07 - Non-ASCII URL normalization: URLs with EN DASH, em-dash,
            // Urdu/Arabic characters, or other non-ASCII bytes fail FILTER_VALIDATE_URL.
            // Percent-encode non-ASCII characters in the path segment so the URL becomes
            // valid. We store the ORIGINAL $url for filesystem lookups (Strategy 2) because
            // file_exists() operates on raw byte paths, not percent-encoded ones.
            $url_normalized = $this->normalize_url_non_ascii($url);
            if (! filter_var($url_normalized, FILTER_VALIDATE_URL)) {
                $error_out = 'Invalid URL (even after normalization): ' . $url;
                return false;
            }
            $url = $url_normalized;
        }

        // ── Strategy 1: attachment_url_to_postid ────────────────────────────
        // Fastest path. Works when the stored URL exactly matches $url.
        // @MODIFIED 2026-07-07 - Try normalized URL first, then original for non-ASCII.
        $att_id = attachment_url_to_postid($url);
        if (!$att_id) {
            // Retry with percent-encoded path (handles EN DASH, Urdu filenames, etc.)
            $url_encoded = $this->normalize_url_non_ascii($url);
            if ($url_encoded !== $url) {
                $att_id = attachment_url_to_postid($url_encoded);
            }
        }
        if ($att_id) {
            $path = get_attached_file($att_id);
            if ($path && file_exists($path) && is_readable($path)) {
                $bytes = @file_get_contents($path);
                if ($bytes !== false && $bytes !== '') {
                    return $bytes;
                }
            }
            // @MODIFIED 2026-07-07 - If file not found at DB path, try filesystem scan
            // for the attachment with a fuzzy filename match (handles rename timing).
            if ($path && ! file_exists($path)) {
                $fuzzy = $this->fuzzy_find_attachment_file($path);
                if ($fuzzy) {
                    $bytes = @file_get_contents($fuzzy);
                    if ($bytes !== false && $bytes !== '') {
                        return $bytes;
                    }
                }
            }
        }

        // ── Strategy 2: Protocol-agnostic filesystem mapping ─────────────────
        // Handles http/https mismatches (common with Cloudflare or mixed-content
        // setups where the stored baseurl differs from the request URL).
        $uploads       = wp_upload_dir();
        $base_url_raw  = untrailingslashit((string) ($uploads['baseurl'] ?? ''));
        $base_dir      = untrailingslashit((string) ($uploads['basedir'] ?? ''));

        // Strip protocol so http:// and https:// are treated identically.
        $proto_strip = static function (string $s): string {
            return preg_replace('#^https?://#', '//', $s);
        };

        $url_stripped      = $proto_strip($url);
        $base_url_stripped = $proto_strip($base_url_raw);

        if ($base_url_stripped !== '' && strpos($url_stripped, $base_url_stripped) === 0) {
            $rel  = ltrim(str_replace($base_url_stripped, '', $url_stripped), '/');
            $rel  = (string) preg_replace('/[?#].*$/', '', $rel); // strip query string / fragment
            $path = $base_dir . '/' . $rel;

            // Handle double-extension bug (file.webp.webp stored in some CDN configs).
            if (! file_exists($path) && preg_match('/\.(jpe?g|png|webp)\.(jpe?g|png|webp)$/i', $path)) {
                $alt = (string) preg_replace('/\.(jpe?g|png|webp)$/i', '', $path);
                if (file_exists($alt)) {
                    $path = $alt;
                }
            }

            // @MODIFIED 2026-07-07 - Non-ASCII path: if direct file_exists fails,
            // try percent-decoding the path (rawurldecode) to handle URLs that were
            // already percent-encoded by WordPress or CDN.
            if (! file_exists($path) && preg_match('/[^\x20-\x7E]/', $path)) {
                $decoded = rawurldecode($path);
                if ($decoded !== $path && file_exists($decoded)) {
                    $path = $decoded;
                }
            }

            if (file_exists($path) && is_readable($path)) {
                $bytes = @file_get_contents($path);
                if ($bytes !== false && $bytes !== '') {
                    return $bytes;
                }
            }

            // @MODIFIED 2026-07-07 - Fuzzy scan: if exact path fails, scan the
            // upload directory for files matching the basename pattern.
            if (! file_exists($path)) {
                $fuzzy = $this->fuzzy_find_attachment_file($path);
                if ($fuzzy) {
                    $bytes = @file_get_contents($fuzzy);
                    if ($bytes !== false && $bytes !== '') {
                        return $bytes;
                    }
                }
            }
        }

        // ── Strategy 3: HTTP fallback ────────────────────────────────────────
        // LAST RESORT ONLY. Timeout is 5s (not 15s) so it fails fast rather
        // than freezing the AJAX request when loopback HTTP is blocked.
        $resp = wp_safe_remote_get($url, [
            'timeout'     => 5,
            'redirection' => 2,
            'headers'     => ['User-Agent' => 'DIT-TrendStudio/CollageGenerator'],
        ]);

        if (is_wp_error($resp)) {
            $error_out = 'HTTP error: ' . $resp->get_error_message();
            return false;
        }

        if (wp_remote_retrieve_response_code($resp) !== 200) {
            $error_out = 'HTTP ' . wp_remote_retrieve_response_code($resp) . ' for: ' . substr($url, 0, 80);
            return false;
        }

        $body = wp_remote_retrieve_body($resp);
        if (empty($body)) {
            $error_out = 'Empty HTTP body for: ' . substr($url, 0, 80);
            return false;
        }

        return $body;
    }

    /**
     * Normalize non-ASCII characters in a URL by percent-encoding them in the path segment.
     * Handles EN DASH (U+2013), em-dash (U+2014), Urdu/Arabic characters, and other
     * multi-byte UTF-8 sequences that break FILTER_VALIDATE_URL and attachment_url_to_postid().
     *
     * @since 2.2.1
     */
    private function normalize_url_non_ascii(string $url): string
    {
        $parts = parse_url($url);
        if (empty($parts['path'])) {
            return $url;
        }

        $path = $parts['path'];
        // Only encode characters that are NOT already percent-encoded and NOT ASCII-safe.
        // This preserves existing %XX sequences while encoding raw non-ASCII bytes.
        $segments = explode('/', $path);
        foreach ($segments as &$seg) {
            if ($seg === '') continue;
            // Split out existing percent-encoded triplets to avoid double-encoding.
            $encoded_parts = preg_split('/(%[0-9A-Fa-f]{2})/', $seg, -1, PREG_SPLIT_DELIM_CAPTURE);
            foreach ($encoded_parts as &$ep) {
                if ($ep === '' || preg_match('/^%[0-9A-Fa-f]{2}$/', $ep)) continue;
                $ep = rawurlencode($ep);
            }
            unset($ep);
            $seg = implode('', $encoded_parts);
        }
        unset($seg);
        $parts['path'] = implode('/', $segments);

        $rebuild = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '');
        if (! empty($parts['port'])) $rebuild .= ':' . $parts['port'];
        $rebuild .= $parts['path'];
        if (! empty($parts['query'])) $rebuild .= '?' . $parts['query'];
        if (! empty($parts['fragment'])) $rebuild .= '#' . $parts['fragment'];

        return $rebuild;
    }

    /**
     * Fuzzy-find an attachment file on disk when the exact DB path fails.
     * Scans the parent directory for files matching the basename pattern (case-insensitive,
     * handles minor filename differences from renames).
     *
     * @since 2.2.1
     */
    private function fuzzy_find_attachment_file(string $expected_path): ?string
    {
        $dir  = dirname($expected_path);
        $base = basename($expected_path);

        if (! is_dir($dir)) {
            return null;
        }

        // Extract the core identifier from the filename (e.g., numeric prefix + slug).
        // Match everything before the final extension.
        $core = preg_replace('/\.[^.]+$/', '', $base);
        if (empty($core)) return null;

        $files = glob($dir . '/*' . $core . '*');
        if (! is_array($files) || empty($files)) {
            return null;
        }

        // Return the first match that is a readable image file.
        foreach ($files as $f) {
            if (is_file($f) && is_readable($f)) {
                $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
                    return $f;
                }
            }
        }

        return null;
    }

    private function draw_grid($canvas, array $sources, string $layout, int $scale, array $crops = [], array $opts = []): void
    {
        $num = count($sources);
        if ($num === 0) return;

        // @MODIFIED 2026-05-06 - gap_size=0 allows edge-to-edge image (no outer border)
        $gap = (int)(($opts['gap_size'] ?? 5) * $scale);
        $w = $this->width - (2 * $gap);
        $h = $this->image_area_height - $gap;
        $ox = $gap;
        $oy = $gap;

        $radius = (int)($opts['corner_radius'] ?? 0) * $scale;
        $blur = (int)($opts['blur_intensity'] ?? 5);

    $draw = function ($idx, $dx, $dy, $dw, $dh) use ($canvas, $sources, $crops, $radius, $blur) {
        if (!isset($sources[$idx])) return;
        $src = $sources[$idx];
        
        // @MODIFIED 2026-05-12 - Hero-First: Check if this is a single portrait image
        // If so, use 'contain' (letterbox) to prevent face cropping
        $is_single_portrait = (count($sources) === 1);
        $src_w = imagesx($src);
        $src_h = imagesy($src);
        $is_src_portrait = ($src_h > $src_w);

        // @MODIFIED Phase 12: Default to Full Crop (Cover) to fill space - Properly merged
        // @MODIFIED 2026-05-12 - Hero-First: Top-25% anchor for portraits to save faces
        $default_y = $is_src_portrait ? 25 : 50; 
        $default_crop = ['x' => 50, 'y' => $default_y, 'scale' => 1.0, 'full_crop' => true];
        
        // @MODIFIED 2026-05-12 - Hero-First: Force contain for single portrait images
        if ($is_single_portrait && $is_src_portrait) {
            $default_crop['full_crop'] = false;
            $default_crop['letterbox_color'] = !empty($opts['border_color']) ? $opts['border_color'] : '#0f1c34';
        }
        
        $c = array_merge($default_crop, $crops[$idx] ?? []);

        // Create temporary tile for rounding
        $tile = imagecreatetruecolor((int)$dw, (int)$dh);
        // magenta mask
        $magenta = imagecolorallocate($tile, 255, 0, 255);
        imagefill($tile, 0, 0, $magenta);
        imagecolortransparent($tile, $magenta);

        if ($c['full_crop'] ?? false) {
            $this->copy_and_cover($tile, $src, 0, 0, (int)$dw, (int)$dh, $c);
        } else {
            // @MODIFIED 2026-05-05 - Pass letterbox_color from crop config to copy_and_fit
            $letterbox = (string)($c['letterbox_color'] ?? '');
            $this->copy_and_fit($tile, $src, 0, 0, (int)$dw, (int)$dh, $c, $blur, $letterbox);
        }

        if ($radius > 0) {
            $this->apply_corner_radius($tile, $radius);
        }

        imagecopy($canvas, $tile, (int)$dx, (int)$dy, 0, 0, (int)$dw, (int)$dh);
        imagedestroy($tile);
    };

        switch ($num) {
            case 1:
                $draw(0, $ox, $oy, $w, $h);
                break;
            case 2:
                // @MODIFIED 2026-02-19 - Keep layout keys consistent with UI/CSS (2-cols, 2-rows).
                if ($layout === '2-rows') {
                    $row_h = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $w, $row_h);
                    $draw(1, $ox, $oy + $row_h + $gap, $w, $row_h);
                } else {
                    $col_w = (int)(($w - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $h);
                }
                break;
            case 3:
                if ($layout === '1-2') {
                    $col_w = (int)(($w - $gap) / 2);
                    $h_half = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $h_half);
                    $draw(2, $ox + $col_w + $gap, $oy + $h_half + $gap, $col_w, $h_half);
                } else {
                    $col_w = (int)(($w - 2 * $gap) / 3);
                    $draw(0, $ox, $oy, $col_w, $h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $h);
                    $draw(2, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h);
                }
                break;
            case 4:
                if ($layout === '2x2') {
                    $col_w = (int)(($w - $gap) / 2);
                    $row_h = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $row_h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $row_h);
                    $draw(2, $ox, $oy + $row_h + $gap, $col_w, $row_h);
                    $draw(3, $ox + $col_w + $gap, $oy + $row_h + $gap, $col_w, $row_h);
                } elseif ($layout === '2-1-1') {
                    $col_w = (int)(($w - 2 * $gap) / 3);
                    $h_half = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $h_half);
                    $draw(1, $ox, $oy + $h_half + $gap, $col_w, $h_half);
                    $draw(2, $ox + $col_w + $gap, $oy, $col_w, $h);
                    $draw(3, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h);
                } elseif ($layout === '1-1-2') {
                    $col_w = (int)(($w - 2 * $gap) / 3);
                    $h_half = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $h);
                    $draw(2, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h_half);
                    $draw(3, $ox + 2 * ($col_w + $gap), $oy + $h_half + $gap, $col_w, $h_half);
                } else {
                    // Default for Social Sharing: 2x2 if no layout specified
                    $col_w = (int)(($w - $gap) / 2);
                    $row_h = (int)(($h - $gap) / 2);
                    $draw(0, $ox, $oy, $col_w, $row_h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $row_h);
                    $draw(2, $ox, $oy + $row_h + $gap, $col_w, $row_h);
                    $draw(3, $ox + $col_w + $gap, $oy + $row_h + $gap, $col_w, $row_h);
                }
                break;
            case 5:
                $col_w = (int)(($w - 2 * $gap) / 3);
                $h_half = (int)(($h - $gap) / 2);
                if ($layout === '1-2-2') {
                    $draw(0, $ox, $oy, $col_w, $h);
                    $draw(1, $ox + $col_w + $gap, $oy, $col_w, $h_half);
                    $draw(2, $ox + $col_w + $gap, $oy + $h_half + $gap, $col_w, $h_half);
                    $draw(3, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h_half);
                    $draw(4, $ox + 2 * ($col_w + $gap), $oy + $h_half + $gap, $col_w, $h_half);
                } elseif ($layout === '2-1-2') {
                    $draw(0, $ox, $oy, $col_w, $h_half);
                    $draw(1, $ox, $oy + $h_half + $gap, $col_w, $h_half);
                    $draw(2, $ox + $col_w + $gap, $oy, $col_w, $h);
                    $draw(3, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h_half);
                    $draw(4, $ox + 2 * ($col_w + $gap), $oy + $h_half + $gap, $col_w, $h_half);
                } else {
                    $draw(0, $ox, $oy, $col_w, $h_half);
                    $draw(1, $ox, $oy + $h_half + $gap, $col_w, $h_half);
                    $draw(2, $ox + $col_w + $gap, $oy, $col_w, $h_half);
                    $draw(3, $ox + $col_w + $gap, $oy + $h_half + $gap, $col_w, $h_half);
                    $draw(4, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h);
                }
                break;
            case 6:
                $col_w = (int)(($w - 2 * $gap) / 3);
                $h_half = (int)(($h - $gap) / 2);
                $draw(0, $ox, $oy, $col_w, $h_half);
                $draw(1, $ox, $oy + $h_half + $gap, $col_w, $h_half);
                $draw(2, $ox + $col_w + $gap, $oy, $col_w, $h_half);
                $draw(3, $ox + $col_w + $gap, $oy + $h_half + $gap, $col_w, $h_half);
                $draw(4, $ox + 2 * ($col_w + $gap), $oy, $col_w, $h_half);
                $draw(5, $ox + 2 * ($col_w + $gap), $oy + $h_half + $gap, $col_w, $h_half);
                break;
        }
    }

    /**
     * @MODIFIED 2026-03-13 - Added logo rendering, Latin font for brand text,
     *                        auto-scaling to prevent overflow, removed Arabic font misuse
     */
    private function draw_bottom_bar($canvas, string $text, array $opts, int $scale): void
    {
        if (empty($text)) return;

        // ── Background ────────────────────────────────────────────────────
        $rgb   = $this->hex_to_rgb($opts['border_color'] ?: '#0f1c34');
        $bg    = imagecolorallocate($canvas, $rgb['r'], $rgb['g'], $rgb['b']);
        $bar_y = $this->height - $this->bar_height;
        imagefilledrectangle($canvas, 0, $bar_y, $this->width, $this->height, $bg);

        // Optional accent top border (2px logical)
        if (!empty($opts['bar_accent_line'])) {
            $gold_h = (int)(2 * $scale);
            $gold   = imagecolorallocate($canvas, 212, 175, 55);
            imagefilledrectangle($canvas, 0, $bar_y, $this->width, $bar_y + $gold_h, $gold);
        }

        // ── Logo ──────────────────────────────────────────────────────────
        $logo_rendered_w = 0;
        $logo_pad        = (int)(14 * $scale);

        $use_logo = !empty($opts['use_brand_logo']);
        $logo_path = $opts['logo_path'] ?? '';

        if ($use_logo && empty($logo_path)) {
            // Try WP attachment ID option
            $logo_id = (int)get_option('dit_ts_brand_logo_id', 0);
            if ($logo_id) {
                $logo_path = get_attached_file($logo_id) ?: '';
            }
        }

        if (!empty($logo_path) && file_exists($logo_path)) {
            $logo_bytes = @file_get_contents($logo_path);
            if ($logo_bytes) {
                $logo_gd = @imagecreatefromstring($logo_bytes);
                if ($logo_gd) {
                    $orig_lw = imagesx($logo_gd);
                    $orig_lh = imagesy($logo_gd);

                    if ($orig_lw > 0 && $orig_lh > 0) {
                        // Scale logo to fit bar, max 70% of bar height
                        $max_logo_h = (int)(($this->bar_height - $logo_pad * 2) * 0.70);
                        $max_logo_h = max((int)(24 * $scale), $max_logo_h);
                        $logo_h_r   = min($max_logo_h, $orig_lh);
                        $logo_w_r   = (int)round($logo_h_r * $orig_lw / $orig_lh);

                        // Vertical center in bar
                        $logo_y = $bar_y + (int)(($this->bar_height - $logo_h_r) / 2);
                        $logo_x = $logo_pad;

                        imagecopyresampled(
                            $canvas, $logo_gd,
                            $logo_x, $logo_y, 0, 0,
                            $logo_w_r, $logo_h_r,
                            $orig_lw, $orig_lh
                        );

                        $logo_rendered_w = $logo_w_r + $logo_pad;
                    }
                    imagedestroy($logo_gd);
                }
            }
        }

        // ── Text font resolution ──────────────────────────────────────────
        // Use a dedicated bar font (Latin/Roman) — NOT the Arabic font.
        // Arabic fonts produce incorrect bounding boxes for Latin glyphs,
        // causing the overflow seen in the previous output.
        $bar_font = $this->resolve_bar_font($opts);

        $text_hex = !empty($opts['bar_text_color'])
            ? (string) $opts['bar_text_color']
            : $this->get_contrasting_text_hex((string) ($opts['border_color'] ?: '#0f1c34'));

        $text_rgb = $this->hex_to_rgb($text_hex);
        $text_color = imagecolorallocate($canvas, $text_rgb['r'], $text_rgb['g'], $text_rgb['b']);

        if (empty($bar_font) || !file_exists($bar_font)) {
            // GD bitmap fallback — at least it won't overflow
            $font_id = 5;
            $fw = imagefontwidth($font_id);
            $fh = imagefontheight($font_id);
            $tx = (int)(($this->width - strlen($text) * $fw) / 2);
            $ty = $bar_y + (int)(($this->bar_height - $fh) / 2);
            imagestring($canvas, $font_id, max(0, $tx), $ty, $text, $text_color);
            return;
        }

        // ── Auto-scale font to fit available width ────────────────────────
        $font_size    = (int)(($opts['bar_font_size'] ?? 24) * $scale);
        $letter_spacing = (int)($opts['letter_spacing'] ?? 10) * $scale;
        $min_font     = (int)(8 * $scale);
        $h_pad        = (int)(20 * $scale);
        $available_w  = $this->width - $logo_rendered_w - $h_pad - (int)(10 * $scale);

        // Helper to get total width with spacing
        $get_total_w = function($fs, $spacing) use ($bar_font, $text) {
            $total_w = 0;
            $len = mb_strlen($text, 'UTF-8');
            for ($i = 0; $i < $len; $i++) {
                $char = mb_substr($text, $i, 1, 'UTF-8');
                $bbox = @imagettfbbox($fs, 0, $bar_font, $char);
                $cw = $bbox ? abs($bbox[4] - $bbox[0]) : (int)($fs * 0.6);
                $total_w += $cw;
                if ($i < $len - 1) {
                    $total_w += $spacing;
                }
            }
            return $total_w;
        };

        while ($font_size > $min_font) {
            $text_w = $get_total_w($font_size, $letter_spacing);
            if ($text_w <= $available_w) break;
            $font_size -= max(1, (int)($scale));
        }

        // Calculate text height for vertical centering
        $bbox   = @imagettfbbox($font_size, 0, $bar_font, $text);
        $text_h = $bbox ? abs($bbox[5] - $bbox[1]) : $font_size;

        $text_area_start = $logo_rendered_w + $h_pad;
        $text_area_w     = $this->width - $text_area_start - (int)(10 * $scale);
        
        // Final measurement for precise X
        $final_w = $get_total_w($font_size, $letter_spacing);
        $tx = $text_area_start + (int)(($text_area_w - $final_w) / 2);
        
        // Vertical centering: use font metrics for more stability
        // y_offset = bar_y + (bar_height / 2) + (text_height / 2)
        $ty = $bar_y + (int)(($this->bar_height + $text_h) / 2) - (int)(1 * $scale);

        // Character-by-character rendering for letter spacing
        $len = mb_strlen($text, 'UTF-8');
        $curr_x = $tx;
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($text, $i, 1, 'UTF-8');
            imagettftext($canvas, $font_size, 0, (int)$curr_x, (int)$ty, $text_color, $bar_font, $char);
            
            // Advance by char width + custom spacing
            $bbox = @imagettfbbox($font_size, 0, $bar_font, $char);
            $cw = $bbox ? abs($bbox[4] - $bbox[0]) : (int)($font_size * 0.6);
            $curr_x += $cw + $letter_spacing;
        }
    }

    /**
     * @MODIFIED 2026-04-20 - Reads dynamic colors strictly from injected $opts (SOC).
     * Fallbacks to hardcoded defaults only when opts are empty.
     */
	private function draw_social_bands($canvas, array $bands, array $opts, int $scale): bool
	{
		$heading_y = $this->image_area_height;
		$heading_h = $this->heading_band_height;
		$desc_y = $heading_y + $heading_h;
		$desc_h = $this->desc_band_height;

		$h_bg_rgb = $this->hex_to_rgb(!empty($opts['social_heading_bg']) ? $opts['social_heading_bg'] : '#0f1c34');
		$h_text_rgb = $this->hex_to_rgb(!empty($opts['social_heading_color']) ? $opts['social_heading_color'] : '#ffffff');
		$d_bg_rgb = $this->hex_to_rgb(!empty($opts['social_desc_bg']) ? $opts['social_desc_bg'] : '#500f19');
		$d_text_rgb = $this->hex_to_rgb(!empty($opts['social_desc_color']) ? $opts['social_desc_color'] : '#ffffff');

		$heading_bg_color = imagecolorallocate($canvas, $h_bg_rgb['r'], $h_bg_rgb['g'], $h_bg_rgb['b']);
		imagefilledrectangle($canvas, 0, $heading_y, $this->width, $heading_y + $heading_h, $heading_bg_color);

		$desc_bg_color = imagecolorallocate($canvas, $d_bg_rgb['r'], $d_bg_rgb['g'], $d_bg_rgb['b']);
		imagefilledrectangle($canvas, 0, $desc_y, $this->width, $desc_y + $desc_h, $desc_bg_color);

		$accent_h = (int)(3 * $scale);
		$gold = imagecolorallocate($canvas, 212, 175, 55);
		imagefilledrectangle($canvas, 0, $heading_y, $this->width, $heading_y + $accent_h, $gold);

		$silver = imagecolorallocate($canvas, 180, 180, 200);
		imagefilledrectangle($canvas, (int)(20 * $scale), $desc_y, $this->width - (int)(20 * $scale), $desc_y + (int)(1 * $scale), $silver);

		$heading_text_color = imagecolorallocate($canvas, $h_text_rgb['r'], $h_text_rgb['g'], $h_text_rgb['b']);
		$desc_text_color = imagecolorallocate($canvas, $d_text_rgb['r'], $d_text_rgb['g'], $d_text_rgb['b']);

	$font_file = $this->social_font_file ?: $this->resolve_social_font($opts);
	$h_font_size = $this->heading_fitted_font_size ?: $this->heading_font_size ?: (int)(36 * $scale);
	$d_font_size = $this->desc_fitted_font_size ?: $this->desc_font_size ?: (int)(26 * $scale);

	if (!empty($bands['heading'])) {
		if (!$this->render_urdu_band(
			$canvas, (string)$bands['heading'],
			$font_file, $h_font_size, $heading_y + $accent_h, $heading_h - $accent_h,
			$heading_text_color, $scale, (int)(10 * $scale)
		)) {
            return false;
            }
        }

        if (!empty($bands['description'])) {
			if (!$this->render_urdu_band(
				$canvas, (string)$bands['description'],
				$font_file, $d_font_size,
				$desc_y, $desc_h,
				$desc_text_color, $scale
			)) {
				return false;
			}
		}

		return true;
	}

    /**
     * Renders a single Urdu social band via Pango (system fontconfig).
     * Composites the rendered PNG onto the GD canvas. Logs error on failure.
     */
	private function render_urdu_band(
		$canvas,
		string $text,
		string $font_file,
		int $font_size,
		int $y_offset,
		int $band_height,
		$color,
		int $scale,
		int $v_pad_override = 0
	): bool {
		if (empty($font_file) || !file_exists($font_file)) {
			if (isset($this->logger)) {
				$this->logger->error('render_urdu_band: font file missing — ' . ($font_file ?: 'EMPTY') . '. Ensure NotoNastaliqUrdu-Regular.ttf exists in plugin assets/fonts/ directory.');
			}
			return false;
		}

		$text = wp_strip_all_tags(html_entity_decode($text, ENT_QUOTES | ENT_XML1, 'UTF-8'));

		if (empty($text)) {
			return true;
		}

		$h_pad = (int)(20 * $scale);
		$v_pad = ($v_pad_override > 0) ? $v_pad_override : (int)(15 * $scale);
		$text_area_w = $this->width - ($h_pad * 2);
		$text_area_h = $band_height - ($v_pad * 2);

		$rgb = imagecolorsforindex($canvas, $color);
		$fill = sprintf('#%02x%02x%02x', $rgb['red'], $rgb['green'], $rgb['blue']);

		$png_bytes = $this->urdu_pango_render($text, $font_file, $font_size, $fill, $text_area_w);

		if ($png_bytes !== null) {
			$overlay = @imagecreatefromstring($png_bytes);
			if ($overlay) {
				$ow = imagesx($overlay);
				$oh = imagesy($overlay);

		// @MODIFIED 2026-05-04 - Scale-down safety net: if Pango overlay overflows
		// the band in either dimension, proportionally scale it down instead of
		// hard-cropping. Hard-cropping cuts text mid-glyph; scaling preserves all
		// content legibly.
		$need_scale = false;
		$scale_factor = 1.0;
		if ($oh > $text_area_h && $text_area_h > 0) {
			$scale_factor = min($scale_factor, $text_area_h / $oh);
			$need_scale = true;
		}
		if ($ow > $text_area_w && $text_area_w > 0) {
			$scale_factor = min($scale_factor, $text_area_w / $ow);
			$need_scale = true;
		}
		if ($need_scale) {
			$new_w = max(1, (int)($ow * $scale_factor));
			$new_h = max(1, (int)($oh * $scale_factor));
			$scaled = imagecreatetruecolor($new_w, $new_h);
			imagesavealpha($scaled, true);
			imagefill($scaled, 0, 0, imagecolorallocatealpha($scaled, 0, 0, 0, 127));
			imagecopyresampled($scaled, $overlay, 0, 0, 0, 0, $new_w, $new_h, $ow, $oh);
			imagedestroy($overlay);
			$overlay = $scaled;
			$ow = $new_w;
			$oh = $new_h;
		}

			$x = $h_pad + (int)(($text_area_w - $ow) / 2);
			$y = $y_offset + $v_pad + (int)(($text_area_h - $oh) / 2);
			$y = max($y_offset, $y);
			// @MODIFIED 2026-05-05 - Hard clip: never render beyond band boundary
			$max_copy_h = min($oh, ($y_offset + $band_height) - $y);
			$max_copy_h = max(0, $max_copy_h);
			imagealphablending($canvas, true);
			imagesavealpha($canvas, true);
			if ($max_copy_h > 0 && $ow > 0) {
				imagecopy($canvas, $overlay, $x, $y, 0, 0, $ow, $max_copy_h);
			}
				imagedestroy($overlay);
				return true;
			}
		}

		if (isset($this->logger)) {
			$this->logger->error('render_urdu_band: Urdu rendering failed. Server requires (1) exec() enabled in PHP, (2) ImageMagick binary with Pango support, (3) Noto Nastaliq Urdu font registered in fontconfig. Check: is exec() disabled? Does "convert -list font" show Noto Nastaliq Urdu? Is /usr/bin/convert accessible?');
		}
		return false;
	}

	/**
	 * @MODIFIED 2026-05-04 - Use pango_measure_rendered_height() directly when available.
	 * The old approach computed lines * line_h, where line_h came from GD's imagettfbbox.
	 * For Nastaliq script, imagettfbbox underestimates line height by 20-30%, causing
	 * the binary search to select a font size that's too large. Using the actual Pango
	 * pixel height eliminates this measurement error.
	 */
	/**
	 * @MODIFIED 2026-05-05 - Nastaliq-aware safety factor (0.80) prevents overflow
	 * caused by extreme ascenders/descenders that GD/Pango bbox underestimates.
	 */
	private function auto_fit_font_size(string $text, string $font_file, int $original_font_size, int $text_area_w, int $text_area_h, bool $prefer_single_line = false): int
	{
		$min_font_size = (int)max(12, $original_font_size * 0.35);

		if ($text_area_h <= 0 || $text_area_w <= 0) {
			return $min_font_size;
		}

		$is_nastaliq = (strpos(strtolower(basename($font_file)), 'nastaliq') !== false);
		$fill_threshold = $is_nastaliq ? 0.88 : 0.92;

	// @MODIFIED 2026-05-08 - Single-line priority for headings:
	// Find the largest font size that keeps text on ONE line within width,
	// then verify it fits the height budget. Prevents wrap-then-shrink trap
	// where heading wraps to 2 lines, then shrinks proportionally to fit
	// height, leaving wide empty margins on left and right.
	if ($prefer_single_line) {
		$single_line_fs = $this->find_single_line_font_size($text, $font_file, $original_font_size, $min_font_size, $text_area_w);
		if ($single_line_fs >= $min_font_size) {
			$sl_pango_h = $this->pango_measure_rendered_height($text, $single_line_fs, $font_file, $text_area_w);
			$sl_h = ($sl_pango_h > 0) ? $sl_pango_h : $this->measure_font_line_height($single_line_fs, $font_file);
			if ($sl_h > 0 && $sl_h <= (int)($text_area_h * $fill_threshold)) {
				return $single_line_fs;
			}
		}
	}

		$pango_h = $this->pango_measure_rendered_height($text, $original_font_size, $font_file, $text_area_w);
		$use_pango_direct = ($pango_h > 0);

		if ($use_pango_direct) {
			if ($pango_h <= (int)($text_area_h * $fill_threshold)) {
				return $original_font_size;
			}
		} else {
			$lines_at_original = $this->pango_estimate_line_count($text, $original_font_size, $font_file, $text_area_w);
			$line_h_at_original = $this->measure_font_line_height($original_font_size, $font_file);
			$rendered_h_at_original = $lines_at_original * $line_h_at_original;
			if ($rendered_h_at_original <= (int)($text_area_h * $fill_threshold)) {
				return $original_font_size;
			}
		}

		$lo = $min_font_size;
		$hi = $original_font_size;
		$best = $lo;

		while ($lo <= $hi) {
			$mid = (int)(($lo + $hi) / 2);
			if ($mid <= 0) break;

			if ($use_pango_direct) {
				$h = $this->pango_measure_rendered_height($text, $mid, $font_file, $text_area_w);
				if ($h <= 0) {
					$lines = $this->pango_estimate_line_count($text, $mid, $font_file, $text_area_w);
					$line_h = $this->measure_font_line_height($mid, $font_file);
					$h = $lines * $line_h;
				}
			} else {
				$lines = $this->pango_estimate_line_count($text, $mid, $font_file, $text_area_w);
				$line_h = $this->measure_font_line_height($mid, $font_file);
				$h = $lines * $line_h;
			}

			if ($h <= (int)($text_area_h * $fill_threshold)) {
				$best = $mid;
				$lo = $mid + 1;
			} else {
				$hi = $mid - 1;
			}
		}

		return max($min_font_size, $best);
	}

	/**
	 * @MODIFIED 2026-05-08 - Binary search for the largest font size that keeps
	 * heading text on a single line within the available width. Prevents the
	 * "wrap-then-shrink" trap where a heading wraps to 2 lines, then the
	 * proportional scale-down to fit height also crushes the width, leaving
	 * large empty margins on both sides.
	 */
	private function find_single_line_font_size(string $text, string $font_file, int $original_font_size, int $min_font_size, int $max_width): int
	{
		$line_count_orig = $this->pango_estimate_line_count($text, $original_font_size, $font_file, $max_width);
		if ($line_count_orig <= 1) {
			return $original_font_size;
		}

		$lo = $min_font_size;
		$hi = $original_font_size;
		$best = $min_font_size;

		while ($lo <= $hi) {
			$mid = (int)(($lo + $hi) / 2);
			if ($mid <= 0) break;

			$lines = $this->pango_estimate_line_count($text, $mid, $font_file, $max_width);
			if ($lines <= 1) {
				$best = $mid;
				$lo = $mid + 1;
			} else {
				$hi = $mid - 1;
			}
		}

		return $best;
	}

	private function pango_measure_rendered_height(string $text, int $font_size, string $font_file, int $max_width): int
	{
		if ($text === '' || $font_size <= 0 || $max_width <= 0) {
			return 0;
		}

		$pango_size = $font_size * 1024;
		$font_family = $this->resolve_urdu_font_family($font_file);

		$markup = sprintf(
			'<span font_family="%s" font="%s" size="%d" foreground="#ffffff">%s</span>',
			htmlspecialchars($font_family, ENT_XML1 | ENT_QUOTES, 'UTF-8'),
			htmlspecialchars($font_file, ENT_XML1 | ENT_QUOTES, 'UTF-8'),
			$pango_size,
			htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8')
		);

		if ($this->is_exec_available()) {
			$tmp_markup = wp_tempnam('dit-ts-pango-h');
			try {
				file_put_contents($tmp_markup, $markup);
				putenv('MAGICK_TEMPORARY_PATH=' . dirname($tmp_markup));

				$convert = $this->get_convert_path();
				$cmd = sprintf(
					'%s -background none -alpha on -define pango:direction=rtl -size %dx pango:@%s -identify 2>/dev/null',
					escapeshellarg($convert),
					$max_width,
					escapeshellarg($tmp_markup)
				);

				$output = [];
				$ret = -1;
				@exec($cmd, $output, $ret);

				if ($ret === 0 && !empty($output)) {
					$last = end($output);
					if (preg_match('/(\d+)x(\d+)/', $last, $m)) {
						return (int)$m[2];
					}
				}
			} finally {
				@unlink($tmp_markup);
			}
		}

		if ($this->is_imagick_pango_available()) {
			$caption = null;
			try {
				$caption = new \Imagick();
				$caption->setBackgroundColor(new \ImagickPixel('transparent'));
				$caption->setPointSize((float)$font_size);
				$caption->setOption('pango:direction', 'rtl');
				$caption->newPseudoImage($max_width, 1, 'pango:' . $markup);

				$geo = $caption->getImageGeometry();
				$rendered_h = (int)($geo['height'] ?? 0);

				if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }

				if ($rendered_h > 0) {
					return $rendered_h;
				}
			} catch (\Exception $e) {
			} catch (\Throwable $e) {
			}
			if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }
		}

		return 0;
	}

	private function pango_estimate_line_count(string $text, int $font_size, string $font_file, int $max_width): int
	{
		if ($text === '' || $font_size <= 0 || $max_width <= 0) {
			return 1;
		}

		$pango_h = $this->pango_measure_rendered_height($text, $font_size, $font_file, $max_width);
		if ($pango_h > 0) {
			$line_h = $this->measure_font_line_height($font_size, $font_file);
			if ($line_h > 0) {
				return max(1, (int)ceil($pango_h / $line_h));
			}
			return 1;
		}

		if (function_exists('imagettfbbox') && !empty($font_file) && file_exists($font_file)) {
			$words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
			if (!empty($words)) {
				$line_h = $this->measure_font_line_height($font_size, $font_file);
				if ($line_h > 0) {
					$lines = 1;
					$current_w = 0;
					$space_w = (int)($font_size * 0.3);
					foreach ($words as $word) {
						$bbox = @imagettfbbox($font_size, 0, $font_file, $word);
						$word_w = $bbox ? abs($bbox[4] - $bbox[0]) : (int)(mb_strlen($word, 'UTF-8') * $font_size * 0.5);
						if ($current_w > 0 && ($current_w + $space_w + $word_w) > $max_width) {
							$lines++;
							$current_w = $word_w;
						} else {
							$current_w += ($current_w > 0 ? $space_w : 0) + $word_w;
						}
					}
					return max(1, $lines);
				}
			}
		}

		return 1;
	}

	private function urdu_pango_render(
		string $text,
		string $font_file,
		int $font_size,
		string $fill_color,
		int $max_width
	): ?string {
		$pango_size = $font_size * 1024;

		$font_family = $this->resolve_urdu_font_family($font_file);

	$markup = sprintf(
		'<span font_family="%s" font="%s" size="%d" foreground="%s">%s</span>',
		htmlspecialchars($font_family, ENT_XML1 | ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($font_file, ENT_XML1 | ENT_QUOTES, 'UTF-8'),
		$pango_size,
		htmlspecialchars($fill_color, ENT_XML1 | ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8')
	);

	// ── Strategy 1: exec() + CLI convert with pango: (primary working path) ──
	if ($this->is_exec_available()) {
		$tmp_markup = wp_tempnam('dit-ts-pango');
		$tmp_png = wp_tempnam('dit-ts-pango') . '.png';
		try {
			file_put_contents($tmp_markup, $markup);

			putenv('MAGICK_TEMPORARY_PATH=' . dirname($tmp_markup));

			$convert = $this->get_convert_path();
			$cmd = sprintf(
				'%s -background none -alpha on -define pango:direction=rtl -size %dx pango:@%s PNG32:%s 2>/dev/null',
				escapeshellarg($convert),
				$max_width,
				escapeshellarg($tmp_markup),
				escapeshellarg($tmp_png)
			);

			@exec($cmd, $out, $ret);

			if ($ret === 0 && file_exists($tmp_png) && filesize($tmp_png) >= 50) {
				$bytes = @file_get_contents($tmp_png);
				if ($bytes && strlen($bytes) > 50) {
					return $bytes;
				}
			}
		} finally {
			@unlink($tmp_markup);
			@unlink($tmp_png);
		}
	}

		// ── Strategy 2: Imagick PHP extension + pango: pseudo-image ──
		if ($this->is_imagick_pango_available()) {
            $caption = null;
            $im = null;

            try {
                $caption = new \Imagick();
                $caption->setBackgroundColor(new \ImagickPixel('transparent'));
                $caption->setPointSize((float)$font_size);
                $caption->setOption('pango:direction', 'rtl');
                $caption->newPseudoImage($max_width, 1, 'pango:' . $markup);

                $im = new \Imagick();
                $im->setBackgroundColor(new \ImagickPixel('transparent'));
                $im->newImage($max_width, $caption->getImageHeight(), new \ImagickPixel('transparent'));
                $im->compositeImage($caption, \Imagick::COMPOSITE_OVER, 0, 0);
                $im->setImageFormat('png');

                $png_bytes = $im->getImageBlob();

                if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }
                if ($im) { try { $im->destroy(); } catch (\Exception $e) {} }

                if ($png_bytes && strlen($png_bytes) > 20) {
                    return $png_bytes;
                }
            } catch (\Exception $e) {
                if (isset($this->logger)) {
                    $this->logger->warning('urdu_pango_render: Imagick pango: failed (' . $e->getMessage() . '), trying caption:');
                }
            } catch (\Throwable $e) {
            }

            if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }
            if ($im) { try { $im->destroy(); } catch (\Exception $e) {} }

            // Sub-fallback: Imagick caption: with pango:direction option
            try {
                $caption = new \Imagick();
                $caption->setBackgroundColor(new \ImagickPixel('transparent'));
                $caption->setFont($font_file);
                $caption->setPointSize((float)$font_size);
                $caption->setGravity(\Imagick::GRAVITY_CENTER);
                $caption->setOption('pango:direction', 'rtl');
                $caption->setOption('pango:alignment', 'center');
                $caption->newPseudoImage($max_width, 1, 'caption:' . $text);

                $im = new \Imagick();
                $im->setBackgroundColor(new \ImagickPixel('transparent'));
                $im->newImage($max_width, $caption->getImageHeight(), new \ImagickPixel('transparent'));
                $im->compositeImage($caption, \Imagick::COMPOSITE_OVER, 0, 0);
                $im->setImageFormat('png');

                $png_bytes = $im->getImageBlob();

                if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }
                if ($im) { try { $im->destroy(); } catch (\Exception $e) {} }

                if ($png_bytes && strlen($png_bytes) > 20) {
                    return $png_bytes;
                }
            } catch (\Exception $e) {
                if (isset($this->logger)) {
                    $this->logger->warning('urdu_pango_render: Imagick caption: also failed: ' . $e->getMessage());
                }
            } catch (\Throwable $e) {
            }

	if ($caption) { try { $caption->destroy(); } catch (\Exception $e) {} }
	if ($im) { try { $im->destroy(); } catch (\Exception $e) {} }
	}

	if (isset($this->logger)) {
		$this->logger->error('urdu_pango_render: FAILED. CLI exec=' . ($this->is_exec_available() ? 'available (convert at ' . $this->get_convert_path() . ')' : 'DISABLED') . ' | Imagick pango=' . ($this->is_imagick_pango_available() ? 'available' : 'unavailable') . ' | font=' . $font_file . ' | Fix: Enable exec() in PHP, install ImageMagick with Pango support, register Noto Nastaliq Urdu in fontconfig (fc-cache -fv).');
	}

	return null;
}

    private function resolve_urdu_font_family(string $font_file): string {
        static $cache = [];

        if (isset($cache[$font_file])) {
            return $cache[$font_file];
        }

        if ($this->is_exec_available()) {
            $cmd = 'fc-query ' . escapeshellarg($font_file) . ' 2>/dev/null';
            $output = [];
            $ret = -1;
            @exec($cmd, $output, $ret);

            if ($ret === 0 && !empty($output)) {
                $combined = implode("\n", $output);
                if (preg_match('/family:\s*"([^"]+)"/', $combined, $m)) {
                    $cache[$font_file] = trim($m[1]);
                    return $cache[$font_file];
                }
            }
        }

		$basename = strtolower(basename($font_file, '.ttf'));

		if (strpos($basename, 'nastaliq') !== false) {
			$cache[$font_file] = 'Noto Nastaliq Urdu';
			return $cache[$font_file];
		}
		if (strpos($basename, 'urdu') !== false) {
			$cache[$font_file] = 'Noto Sans Urdu';
			return $cache[$font_file];
		}

		$cache[$font_file] = 'Noto Nastaliq Urdu';
	return $cache[$font_file];
	}

	/**
     * Resolves the Urdu/Arabic font file for social bands.
     * @MODIFIED 2026-04-20 - Checks injected social_font option before filesystem scan.
     */
	private function resolve_social_font(array $opts = []): string
	{
		if (!empty($opts['font_file']) && file_exists($opts['font_file'])) {
			return $opts['font_file'];
		}

		$dir = __DIR__ . '/../../assets/fonts/';

		if (!empty($opts['social_font']) && file_exists($dir . basename($opts['social_font']))) {
			return $dir . basename($opts['social_font']);
		}

		$preferred = [
			'NotoNastaliqUrdu-Regular.ttf',
			'NotoNastaliqUrdu-Medium.ttf',
			'NotoSansArabic-Regular.ttf',
		];

		foreach ($preferred as $f) {
			$path = $dir . $f;
			if (file_exists($path) && is_readable($path)) {
				return $path;
			}
		}

		$fonts = glob($dir . '*.ttf') ?: [];
		foreach ($fonts as $path) {
			if (is_readable($path)) {
				return $path;
			}
		}

		if (isset($this->logger)) {
			$this->logger->error('No readable Urdu font found in: ' . $dir);
		}

		return '';
	}

    /**
     * Resolves font for the brand bar (Latin/Roman).
     * MUST NOT use the Arabic font — bounding box metrics are wrong for Latin glyphs.
     */
    private function resolve_bar_font(array $opts = []): string
    {
        // Explicit override
        if (!empty($opts['bar_font_file']) && file_exists($opts['bar_font_file'])) {
            return $opts['bar_font_file'];
        }

        $dir = __DIR__ . '/../../assets/fonts/';

        // Latin font preference order
        $preferred = [
            'EBGaramond-Bold.ttf',
            'Roboto-Bold.ttf',
            'OpenSans-Bold.ttf',
            'Lato-Bold.ttf',
            'Montserrat-Bold.ttf',
        ];

        foreach ($preferred as $f) {
            if (file_exists($dir . $f)) {
                return $dir . $f;
            }
        }

        // Last resort: any TTF that isn't Arabic
        $all = glob($dir . '*.ttf') ?: [];
        foreach ($all as $path) {
            $base = strtolower(basename($path));
            if (strpos($base, 'arabic') === false && strpos($base, 'urdu') === false && strpos($base, 'nastaliq') === false) {
                return $path;
            }
        }

return '';
    }

	private function is_exec_available(): bool
	{
		return $this->get_convert_path() !== '';
	}

	private function get_convert_path(): string
	{
		static $cache = null;
		if ($cache !== null) {
			return $cache;
		}
		$cache = '';
		if (!function_exists('exec') || !is_callable('exec')) {
			return '';
		}
		$disabled = array_map('trim', explode(',', ini_get('disable_functions') . ',' . ini_get('suhosin.executor.func.blacklist')));
		if (in_array('exec', $disabled, true)) {
			return '';
		}
		$candidates = ['/usr/bin/convert', '/usr/local/bin/convert', '/opt/homebrew/bin/convert'];
		foreach ($candidates as $path) {
			if (file_exists($path) && is_executable($path)) {
				$cache = $path;
				return $cache;
			}
		}
		$which = '';
		@exec('which convert 2>/dev/null', $which, $ret);
		if ($ret === 0 && !empty($which)) {
			$found = trim((string)reset($which));
			if ($found !== '' && file_exists($found)) {
				$cache = $found;
			}
		}
		return $cache;
	}

    private function is_imagick_pango_available(): bool
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $cache = false;
        if (!extension_loaded('imagick') || !class_exists('\Imagick')) {
            return false;
        }
        try {
            $test = new \Imagick();
            $test->newPseudoImage(10, 10, 'pango:test');
            $test->destroy();
            $cache = true;
        } catch (\Exception $e) {
        } catch (\Throwable $e) {
        }
        return $cache;
    }

    private function measure_font_line_height(int $font_size, string $font_file): int
    {
        if (empty($font_file) || !file_exists($font_file)) {
            return (int)($font_size * 1.6);
        }
        // @MODIFIED 2026-05-05 - Nastaliq-specific test string with stacking nuktas
        $is_nastaliq = (strpos(strtolower(basename($font_file)), 'nastaliq') !== false);
        $test_str = $is_nastaliq ? 'بھائی گھپلے جھگڑا' : 'کلمیگج';
        $bbox = @imagettfbbox($font_size, 0, $font_file, $test_str);
        if (!$bbox) {
            return (int)($font_size * 1.6);
        }
        $min_y = min($bbox[1], $bbox[3], $bbox[5], $bbox[7]);
        $max_y = max($bbox[1], $bbox[3], $bbox[5], $bbox[7]);
        $actual = abs($max_y - $min_y);
	$multiplier = $is_nastaliq ? 1.45 : 1.20;
	return (int)($actual * $multiplier) + (int)($font_size * 0.15);
	}

	private function get_contrasting_text_hex(string $bg_hex): string
    {
        $rgb = $this->hex_to_rgb($bg_hex);
        $yiq = (($rgb['r'] * 299) + ($rgb['g'] * 587) + ($rgb['b'] * 114)) / 1000;

        return $yiq >= 160 ? '#111111' : '#FFFFFF';
    }

    /** @MODIFIED Phase 10: Custom Blur Intensity | @MODIFIED 2026-05-05: letterbox_color for solid bg */
    private function copy_and_fit($canvas, $src, int $dx, int $dy, int $dw, int $dh, array $crop = ['x' => 50, 'y' => 50], int $blur_intensity = 5, string $letterbox_color = ''): void
    {
        $sw = imagesx($src);
        $sh = imagesy($src);
        if ($sw <= 0 || $sh <= 0 || $dw <= 0 || $dh <= 0) return;

        if ($letterbox_color !== '' && preg_match('/^#[a-f0-9]{6}$/i', $letterbox_color)) {
            // Letterbox mode: solid brand color fills margins — no blurry background
            list($r, $g, $b) = sscanf($letterbox_color, '#%02x%02x%02x');
            $solid = imagecolorallocate($canvas, (int)$r, (int)$g, (int)$b);
            imagefilledrectangle($canvas, $dx, $dy, $dx + $dw - 1, $dy + $dh - 1, $solid);
        } else {
            // Blurred background (existing behavior for multi-image tiles)
            $this->copy_and_cover($canvas, $src, $dx, $dy, $dw, $dh, ['x' => 50, 'y' => 50, 'scale' => 1.0]);
            $bg_tile = imagecreatetruecolor($dw, $dh);
            imagecopy($bg_tile, $canvas, 0, 0, $dx, $dy, $dw, $dh);
            $loops = max(1, min(15, $blur_intensity));
            for ($i = 0; $i < $loops; $i++) {
                imagefilter($bg_tile, IMG_FILTER_GAUSSIAN_BLUR);
            }
            imagecopy($canvas, $bg_tile, $dx, $dy, 0, 0, $dw, $dh);
            imagedestroy($bg_tile);
        }

        // Centered contain fit (same for both modes)
        $aspect_src = $sw / $sh;
        $aspect_dst = $dw / $dh;

        if ($aspect_src > $aspect_dst) {
            $fit_w = $dw;
            $fit_h = (int) round($dw / $aspect_src);
            $fx = $dx;
            $fy = $dy + (int)(($dh - $fit_h) / 2);
        } else {
            $fit_h = $dh;
            $fit_w = (int) round($dh * $aspect_src);
            $fx = $dx + (int)(($dw - $fit_w) / 2);
            $fy = $dy;
        }

        imagecopyresampled($canvas, $src, $fx, $fy, 0, 0, $fit_w, $fit_h, $sw, $sh);
    }

    private function draw_cover($dst, $src, int $dw, int $dh): void
    {
        $sw = imagesx($src);
        $sh = imagesy($src);
        if ($sw <= 0 || $sh <= 0) return;

        $aspect_src = $sw / $sh;
        $aspect_dst = $dw / $dh;

        if ($aspect_src > $aspect_dst) {
            $crop_w = (int) round($sh * $aspect_dst);
            $sx = (int) round(($sw - $crop_w) / 2);
            $sy = 0;
            $cw = $crop_w;
            $ch = $sh;
        } else {
            $crop_h = (int) round($sw / $aspect_dst);
            $sx = 0;
            $sy = (int) round(($sh - $crop_h) / 2);
            $cw = $sw;
            $ch = $crop_h;
        }

        imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $dw, $dh, $cw, $ch);
    }

    private function apply_soft_blur($img): void
    {
        for ($i = 0; $i < 4; $i++) {
            @imagefilter($img, IMG_FILTER_GAUSSIAN_BLUR);
        }
    }

    /**
     * Full Picture tile renderer (Cover style).
     * Fills the entire tile by cropping the image as needed.
     */
    private function copy_and_cover($canvas, $src, int $dx, int $dy, int $dw, int $dh, array $crop = ['x' => 50, 'y' => 50]): void
    {
        $sw = imagesx($src);
        $sh = imagesy($src);
        if ($sw <= 0 || $sh <= 0 || $dw <= 0 || $dh <= 0) return;

        $aspect_src = $sw / $sh;
        $aspect_dst = $dw / $dh;

        // Custom Scale support (e.g. 1.0 = fit, 2.0 = 2x zoom)
        $user_scale = isset($crop['scale']) ? (float)$crop['scale'] : 1.0;
        if ($user_scale < 0.5) $user_scale = 0.5;

        $pct_x = max(0, min(100, $crop['x'])) / 100;
        $pct_y = max(0, min(100, $crop['y'])) / 100;

        // Auto-shift focal point for very wide source images (composite collages)
        // to show one complete half instead of centering on the seam
        $wide_composite = ($aspect_src > $aspect_dst * 1.5);
        if ($wide_composite && $pct_x >= 0.4 && $pct_x <= 0.6) {
            $pct_x = 0.25;
            if (isset($this->logger)) {
                $this->logger->info('Collage wide-composite auto-shift', [
                    'sw'         => $sw,
                    'sh'         => $sh,
                    'aspect_src' => round($aspect_src, 3),
                    'aspect_dst' => round($aspect_dst, 3),
                    'old_pct_x'  => 0.5,
                    'new_pct_x'  => $pct_x,
                ]);
            }
        }

        if ($aspect_src > $aspect_dst) {
            // Source is wider: Base crop is constrained by height
            $base_crop_w = $sh * $aspect_dst;
            $base_crop_h = $sh;
        } else {
            // Source is taller: Base crop is constrained by width
            $base_crop_w = $sw;
            $base_crop_h = $sw / $aspect_dst;
        }

        // Apply Zoom (User Scale)
        // Zooming in means shrinking the crop area (viewing less of the image)
        $crop_w = (int) round($base_crop_w / $user_scale);
        $crop_h = (int) round($base_crop_h / $user_scale);

        // Ensure crop doesn't exceed source bounds
        $crop_w = min($sw, $crop_w);
        $crop_h = min($sh, $crop_h);

        // Calculate offsets based on user percentages
        // sx is the top-left X position of the crop area
        $sx = (int) round(($sw - $crop_w) * $pct_x);
        $sy = (int) round(($sh - $crop_h) * $pct_y);

        imagecopyresampled($canvas, $src, $dx, $dy, $sx, $sy, $dw, $dh, $crop_w, $crop_h);
    }
    private function hex_to_rgb(string $hex): array
    {
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) === 3) {
            $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
            $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
            $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
        } else {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        return ['r' => $r, 'g' => $g, 'b' => $b];
    }

    /** @MODIFIED Phase 10: Rounded Corners Helper */
    private function apply_corner_radius($img, int $radius): void
    {
        if ($radius <= 0) return;

        $w = imagesx($img);
        $h = imagesy($img);

        // Create a mask canvas
        $mask = imagecreatetruecolor($w, $h);
        $transparent = imagecolorallocate($mask, 255, 0, 255); // Magenta for transparency key
        imagefill($mask, 0, 0, $transparent);
        imagecolortransparent($mask, $transparent);

        $black = imagecolorallocate($mask, 0, 0, 0);

        // Draw the rounded rectangle on mask
        $r = min($radius, $w / 2, $h / 2);

        // Core rectangles
        imagefilledrectangle($mask, $r, 0, $w - $r, $h, $black);
        imagefilledrectangle($mask, 0, $r, $w, $h - $r, $black);

        // 4 corners
        imagefilledellipse($mask, $r, $r, $r * 2, $r * 2, $black);
        imagefilledellipse($mask, $w - $r, $r, $r * 2, $r * 2, $black);
        imagefilledellipse($mask, $r, $h - $r, $r * 2, $r * 2, $black);
        imagefilledellipse($mask, $w - $r, $h - $r, $r * 2, $r * 2, $black);

        // Apply mask to original image
        for ($x = 0; $x < $w; $x++) {
            for ($y = 0; $y < $h; $y++) {
                $color = imagecolorat($mask, $x, $y);
                if ($color === $transparent) {
                    imagesetpixel($img, $x, $y, $transparent);
                }
            }
        }
        imagecolortransparent($img, $transparent);
        imagedestroy($mask);
    }
}
