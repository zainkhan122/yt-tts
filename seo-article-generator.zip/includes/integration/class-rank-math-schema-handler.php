<?php

/**
 * RankMath Schema Handler
 * 
 * Handles programmatic write-time injection of SoftwareApplication schema for Rank Math.
 *
 * @package SEO_Article_Generator\Integration
 */

namespace SEO_Article_Generator\Integration;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles programmatic RankMath schema injection.
 */
class Rank_Math_Schema_Handler
{
    /**
     * Build and write native Rank Math SoftwareApplication schema meta.
     *
     * @param int    $post_id   Post ID to update.
     * @param string $permalink Optional pre-resolved permalink (avoids get_permalink() DB call).
     * @return bool Always true.
     */
	public static function write_software_schema($post_id, string $permalink = '')
	{
		$hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
		if (empty($hero_data) || !\is_array($hero_data)) {
			return false;
		}

        // [SSOT-FIX] Enforce canonical version across the version surface that
        // schema generation reads from. Hero_Data_Provider::get_canonical_version()
        // returns the value as-is from tech_specs; without enforce() the schema
        // can drift from the post title / hero / meta when AI hallucinates an
        // older version. Version_SSOT::enforce() mutates the article contract
        // by reference, so we build a contract-shaped array and read the
        // canonicalized version back out.
        if (class_exists('\SEO_Article_Generator\Publishing\Version_SSOT')) {
            $_ssot_contract = [
                'tech_specs'    => ['version' => (string)($hero_data['version'] ?? '')],
                'version'       => (string)($hero_data['version'] ?? ''),
                'hero_section'  => ['version' => (string)($hero_data['version'] ?? '')],
                'introduction'  => [],
                'whats_new'     => [],
            ];
            \SEO_Article_Generator\Publishing\Version_SSOT::enforce(
                $_ssot_contract,
                (string)($hero_data['version'] ?? '')
            );
            if (!empty($_ssot_contract['tech_specs']['version'])) {
                $hero_data['version'] = (string) $_ssot_contract['tech_specs']['version'];
            }
        }

        // Use injected permalink, fall back to Schema_Sync_Service cache,
        // only call get_permalink() as a last resort.
        if ($permalink === '') {
            $permalink = \SEO_Article_Generator\Services\Schema_Sync_Service::get_cached_permalink($post_id);
        }
        if ($permalink === '') {
            return false; // Cannot build schema without a valid URL.
        }

        $specs = self::build_software_schema_from_hero_data($post_id, $hero_data, $permalink);

        $rm_schema = [
            'metadata' => [
                'title'     => 'SoftwareApplication',
                '@type'     => 'SoftwareApplication',
                'isPrimary' => true,
            ],
        ];

        $rm_schema = array_merge($rm_schema, $specs);

        \update_post_meta($post_id, 'rank_math_schema_SoftwareApplication', $rm_schema);
        return true;
    }

    /**
     * Shared builder for full SoftwareApplication dictionary.
     * Extracts values from hero meta (materialized view) handling precise pricing and ratings.
     */
    public static function build_software_schema_from_hero_data($post_id, array $hero_data, $permalink)
    {
        // Date Modified Canonical Synchronization
        $modified_ts = (int)\get_post_meta($post_id, '_seo_gen_schema_modified', true);
        if (!$modified_ts) {
            $modified_ts = \get_post_time('U', true, $post_id) ?: \time();
        }

        /*
         * Build a canonical permalink that avoids trailingslashit() on query-param URLs
         * (e.g., ?p=26250 → ?p=26250/ is an invalid URL).
         */
        $clean_permalink = (string)$permalink;
        if (strpos($clean_permalink, '?') === false) {
            $clean_permalink = \trailingslashit($clean_permalink);
        }

        /*
         * Point mainEntityOfPage to Rank Math's WebPage @id anchor.
         * RM always generates the WebPage @id as {url}#webpage.
         * Using an @id reference keeps the graph consistent instead of
         * emitting a bare URL that RM cannot link back to its own nodes.
         */
        $webpage_id = rtrim($clean_permalink, '/') . '#webpage';

        $specs = [
            '@type'               => 'SoftwareApplication',
            'name'                => $hero_data['name'] ?? $hero_data['software_name'] ?? \get_the_title($post_id),
            'url'                 => $clean_permalink,
            'description'         => $hero_data['description'] ?? '',
            'softwareVersion'     => (string)($hero_data['version'] ?? ''),
            'operatingSystem'     => (string)($hero_data['operating_system'] ?? $hero_data['os_support'] ?? ''),
            'applicationCategory' => (string)($hero_data['application_category'] ?? ''),
            'fileSize'            => (string)($hero_data['fileSize'] ?? $hero_data['file_size'] ?? ''),
            'image'               => ['@id' => \esc_url_raw((string)($hero_data['image'] ?? $hero_data['software_logo'] ?? ''))],
            'dateModified'        => \gmdate(\DATE_W3C, $modified_ts),
            'mainEntityOfPage'    => ['@id' => $webpage_id],
        ];

        // [ISSUE-8 FIX] Use Rank Math Primary Category for applicationCategory if set.
        // This ensures schema entity type matches the breadcrumb/primary category (software TYPE, not OS).
        $primary_cat_id = (int) \get_post_meta($post_id, 'rank_math_primary_category', true);
        if ($primary_cat_id > 0) {
            $primary_term = \get_term($primary_cat_id, 'category');
            if ($primary_term && !\is_wp_error($primary_term)) {
                $specs['applicationCategory'] = \SEO_Article_Generator\Generator\Hero_Data_Provider::normalize_application_category_value($primary_term->slug);
            }
        }

        if (!empty($hero_data['publisher'])) {
            $publisher_name = (string)$hero_data['publisher'];
            /*
             * Give the software vendor a scoped @id fragment so Rank Math cannot
             * conflate it with the site's #person node (which has no Organization type
             * and a different identity). The fragment is relative and stable per vendor.
             */
            $publisher_id = '#publisher-' . \sanitize_title($publisher_name);
            $specs['publisher'] = [
                '@type' => 'Organization',
                '@id'   => $publisher_id,
                'name'  => $publisher_name,
            ];
        }

        // [ISSUE-3 FIX] Use live Rating_System data (source of truth) instead of stale hero_data meta cache.
        // Hero_Renderer (class-hero-renderer.php:55-62) reads from Rating_System::get_rating_data().
        // Schema must match visible Hero rating exactly per Google Structured Data Guidelines.
        //
        // [SSOT-FIX Drift #1] Honor editor_rating precedence before falling back to live average.
        // Mirrors Hero_Data_Provider::from_schema() line 96 and Hero_Renderer's editor_rating
        // lookup. Without this, Rank Math JSON-LD aggregateRating shows live user average
        // even when an editor set a manual override via the Hero Meta Box — failing Google
        // Structured Data validation because schema no longer matches the visible UI.
        $editor_rating = 0.0;
        $hero_meta = \get_post_meta( $post_id, 'seogenherodata', true );
        if ( is_array( $hero_meta ) && ! empty( $hero_meta['editor_rating'] ) ) {
            $editor_rating = (float) $hero_meta['editor_rating'];
        }
        if ( $editor_rating <= 0 && class_exists( '\SEO_Article_Generator\Services\Schema_Sync_Service' )
            && \SEO_Article_Generator\Services\Schema_Sync_Service::has_schema( $post_id ) ) {
            $schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( $post_id );
            if ( $schema instanceof \SEO_Article_Generator\Generator\Article_Schema
                && $schema->editor_rating > 0 ) {
                $editor_rating = (float) $schema->editor_rating;
            }
        }

        $rating_data = \SEO_Article_Generator\Frontend\Rating_System::get_rating_data($post_id);
        $rating = $editor_rating > 0
            ? $editor_rating
            : (float)( $rating_data['average'] ?? 0 );
        $count  = (int)($rating_data['count'] ?? 0);

        if ($rating > 0) {
            $specs['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => round($rating, 1),
                'bestRating'  => 5,
                'worstRating' => 1,
                'ratingCount' => $count > 0 ? $count : 10,
            ];
        }

        $price_mode = $hero_data['price_mode'] ?? 'free';
        if (empty($hero_data['price_mode'])) {
            $license = $hero_data['license'] ?? 'Free';
            if (stripos($license, 'free') !== false || stripos($license, 'open source') !== false || stripos($license, 'gpl') !== false) {
                $price_mode = 'free';
            } else {
                $price_mode = 'paid';
            }
        }

        $price_amount = (string)($hero_data['price_amount'] ?? '');

        if ($price_mode === 'free') {
            $specs['offers'] = [
                '@type'         => 'Offer',
                'price'         => '0',
                'priceCurrency' => 'USD',
                'availability'  => 'https://schema.org/InStock',
                'url'           => $clean_permalink,
            ];
        } elseif ($price_mode === 'paid' && $price_amount !== '') {
            $specs['offers'] = [
                '@type'         => 'Offer',
                'price'         => $price_amount,
                'priceCurrency' => 'USD',
                'availability'  => 'https://schema.org/InStock',
                'url'           => $clean_permalink,
            ];
        }

return \array_filter($specs, function($v) { return !empty($v) || $v === 0 || $v === '0'; });
    }

    /**
     * Register hooks for rating schema sync.
     *
     * @since 2.38.0
     * @return void
     */
    public static function register_hooks(): void
    {
        \add_action('seo_gen_rating_updated', [__CLASS__, 'refresh_schema_on_rating_update'], 10, 3);
    }

    /**
     * Refresh Rank Math SoftwareApplication schema when rating is updated.
     * Ensures schema aggregateRating matches live Hero rating (Google Structured Data Guidelines).
     *
     * @since 2.38.0
     * @param int     $post_id      Post ID.
     * @param float   $new_average  New average rating.
     * @param int     $new_count    New rating count.
     * @return void
     */
    public static function refresh_schema_on_rating_update(int $post_id, float $new_average, int $new_count): void
    {
        // Only refresh for plugin-owned posts with existing schema.
        if (class_exists('SEO_Article_Generator\Discovery\Post_Type_Classifier')) {
            $post_type = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify($post_id);
            if (!\SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned($post_type)) {
                return;
            }
        }

        // [SSOT-FIX Finding 17] Bump _seo_gen_schema_modified BEFORE re-writing the
        // schema so dateModified reflects the rating change. Otherwise Google Structured
        // Data validator reports stale dateModified for posts whose only mutation since
        // last publish was a user rating. Same UTC source as Schema_Sync_Service.
        if ( class_exists( '\SEO_Article_Generator\Utils\Plugin_Time' ) ) {
            \update_post_meta( $post_id, '_seo_gen_schema_modified', \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() );
        } else {
            \update_post_meta( $post_id, '_seo_gen_schema_modified', \time() );
        }

        // [SSOT-FIX Finding 9] Sync seogenherodata['rating'] + rating_count surgically.
        // The full save_schema() path is avoided here to keep rating-triggered refresh
        // O(1) — only rating + rating_count are mutated, leaving version, dates,
        // download_links, and every other hero field untouched (no full
        // Hero_Data_Provider rebuild). Rating is a single-field mutation, not a
        // schema-wide sync.
        //
        // [SSOT-FIX Finding 13] editor_rating precedence is preserved by consulting BOTH
        // sources: (a) seogenherodata['editor_rating'] set via Hero Meta Box UI by an
        // editor, and (b) schema->editor_rating set by AI generation. Hero_Data_Provider
        // ::from_schema() line 96 folds schema->editor_rating into hero_data['rating'],
        // but does NOT carry it forward as a separate seogenherodata key — so checking
        // seogenherodata alone misses AI-set overrides. We load the schema once to
       // replicate from_schema()'s exact precedence rule (single DB hit; suffices
        // on the infrequent AJAX vote path).
        $editor_rating = 0.0;
        $seogenherodata = \get_post_meta( $post_id, 'seogenherodata', true );
        if ( is_array( $seogenherodata ) && ! empty( $seogenherodata['editor_rating'] ) ) {
            $editor_rating = (float) $seogenherodata['editor_rating'];
        }
        if ( $editor_rating <= 0
            && class_exists( '\SEO_Article_Generator\Services\Schema_Sync_Service' ) ) {
            $schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( $post_id );
            if ( $schema instanceof \SEO_Article_Generator\Generator\Article_Schema
                && $schema->editor_rating > 0 ) {
                $editor_rating = (float) $schema->editor_rating;
            }
        }

        if ( is_array( $seogenherodata ) ) {
            if ( $editor_rating <= 0 ) {
                $seogenherodata['rating'] = (float) $new_average;
            }
            $seogenherodata['rating_count'] = (int) $new_count;
            $seogenherodata['review_count']  = (int) $new_count;
            \update_post_meta( $post_id, 'seogenherodata', $seogenherodata );
        }

        // Bump Cloudflare bypass transient so first visitor sees fresh rating.
        if ( function_exists( '\get_post_status' ) && \get_post_status( $post_id ) === 'publish' ) {
            \set_transient( 'seo_gen_hero_dirty_' . $post_id, 1, 60 );
        }

        self::write_software_schema($post_id);
    }
}

