<?php

/**
 * Phrase Variator
 *
 * Provides random alternative phrasings for fixed section headings
 * to reduce template fingerprinting in generated content.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Generator;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Randomizes section headings to reduce template patterns.
 *
 * Google's Helpful Content update penalizes formulaic content.
 * This class provides semantic variations for common headings.
 */
class Phrase_Variator
{
    /**
     * Alternative phrasings for common section headings.
     *
     * @var array
     */
    public static $alternatives = [
        'Key Features' => [
            'Main Features',
            'Key Features',
            'Notable Features',
            'Important Features',
        ],
        'Pros & Cons' => [
            'Advantages & Drawbacks',
            'Strengths & Weaknesses',
            'Benefits & Limitations',
            'What We Like & What Could Be Better',
        ],
        'Installation Guide' => [
            'How to Install',
            'Setup Instructions',
            'Getting Started',
            'Installation Steps',
        ],
        'System Requirements' => [
            'What You Need',
            'Hardware Requirements',
            'System Specifications',
            'Technical Requirements',
            'Required Specs',
        ],
        'Frequently Asked Questions' => [
            'Common Questions',
            'FAQ',
            'Questions & Answers',
        ],
        "What's New" => [
            'New in This Version',
            'What\'s New in Latest Version',
            'Highlights in New Version',
            'What\'s New in Current Version',
            'Changelog in Recent Version',
        ],
        'Alternatives & Competitors' => [
            'Similar Software',
            'Compare Alternatives',
            'Other Options',
        ],
        'Troubleshooting' => [
            'Common Issues & Fixes',
            'Problem Solving',
            'Fix Common Problems',
        ],
        'Technical Specifications' => [
            'Technical Details',
            'Software Specifications',
            'Tech Specs',
            'Product Specifications',
        ],
        'Competitors' => [
            'Top Alternatives to %s',
            'Best %s Alternatives',
            'Similar Software to %s',
            '%s vs. The Competition',
            'Other Options to Consider',
        ],
        'Quick Start & Pro Tips' => [
            'Pro Tips',
            'Power User Guide',
            'Why It Stands Out',
            'The Winning Edge',
            'Expert Tips',
            'How to Maximize It',
        ],
    ];

    /**
     * Session cache to ensure consistent headings within single generation.
     *
     * @var array
     */
    private static $session_cache = [];

    /**
     * Get a varied version of a section heading.
     *
     * Within the same session (article generation), the same phrase
     * will always return the same variation for consistency.
     *
     * @param string $phrase Original phrase (e.g., "Key Features").
     * @return string Varied phrase or original if no alternatives defined.
     */
    public static function vary(string $phrase): string
    {
        // Check session cache first
        if (isset(self::$session_cache[$phrase])) {
            return self::$session_cache[$phrase];
        }

        // Find alternatives (case-insensitive match)
        $normalized = self::normalize_phrase($phrase);
        $alternatives = null;

        foreach (self::$alternatives as $key => $options) {
            if (self::normalize_phrase($key) === $normalized) {
                $alternatives = $options;
                break;
            }
        }

        // No alternatives found - return original
        if ($alternatives === null) {
            self::$session_cache[$phrase] = $phrase;
            return $phrase;
        }

        // @MODIFIED 2025-12-30 v2.8.2: Original included with 20% probability
        if (mt_rand(1, 100) <= 20) {
            $selected = $phrase;
        } else {
            $selected = $alternatives[array_rand($alternatives)];
        }

        // Cache for consistency
        self::$session_cache[$phrase] = $selected;

        return $selected;
    }

    /**
     * Clear session cache (call between article generations).
     *
     * @return void
     */
    public static function reset_session(): void
    {
        self::$session_cache = [];
    }

    /**
     * Generate complete heading variation map for a post.
     * Variations are pulled from registry defaults and run through the generator.
     *
     * @since 2.8.2
     * @return array Section ID => varied heading text.
     */
    public static function generate_heading_map(): array
    {
        self::reset_session(); // Prevent bleed across posts in bulk/CLI

        $map      = [];
        $registry = Article_Schema::SECTION_REGISTRY;

        foreach ($registry as $key => $config) {
            if (empty($config['default'])) {
                continue;
            }

            // Use varied text if appropriate, else default
            $map[$key] = self::vary($config['default']);
        }

        // Alias support for legacy consumers
        if (isset($map['faqs'])) {
            $map['faq'] = $map['faqs'];
        }

        return $map;
    }

    /**
     * Check if phrase has alternatives defined.
     *
     * @param string $phrase Phrase to check.
     * @return bool True if alternatives exist.
     */
    public static function has_alternatives(string $phrase): bool
    {
        $normalized = self::normalize_phrase($phrase);

        foreach (array_keys(self::$alternatives) as $key) {
            if (self::normalize_phrase($key) === $normalized) {
                return true;
            }
        }

        return false;
    }

    /**
     * Normalize phrase for comparison.
     *
     * @param string $phrase Raw phrase.
     * @return string Normalized phrase.
     */
    private static function normalize_phrase(string $phrase): string
    {
        return strtolower(trim(preg_replace('/\s+/', ' ', $phrase)));
    }
}
