/**
 * Collage Maker – Grid + Split Card
 *
 * @package DIT_TrendStudio
 * @version 3.1.0
 *
 * Features:
 *  - Split Card: live canvas preview, HD export, Urdu/webfont support
 *  - Grid: live canvas preview mirroring PHP layout, HD server-side export
 *  - Per-image zoom slider (0.5x – 3x) with instant canvas update
 *  - Per-image swap button (replace one slot from Media Library)
 *  - Live font preview box showing sample text in selected typeface
 *  - Full RTL support, fitTextToBox with ellipsis fallback
 *  - CORS-safe image loading, CORS error surfaced to user
 *  - 150ms debounced preview rendering
 */
/* global jQuery, wp, ditTsCollage */
(function ($) {
    'use strict';

    if (typeof ditTsCollage === 'undefined') { return; }

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTANTS
    // ─────────────────────────────────────────────────────────────────────────

    var BASE_WIDTH = 1080;
    var BASE_HEIGHT = 1080;
    var TOP_STRIP_PERCENT = 0.55;
    var MIN_SPLIT_IMAGES = 2;
    var MAX_SPLIT_IMAGES = 3;
    var MAX_GRID_IMAGES = 6;
    var MIN_FONT_SIZE = 10;
    var PREVIEW_DEBOUNCE_MS = 150;
    var LAYOUT_PAD_X = Math.round(BASE_WIDTH * 0.05);
    var LAYOUT_PAD_Y = Math.round(BASE_HEIGHT * 0.025);
    var HEADING_BODY_GAP = Math.round(BASE_HEIGHT * 0.02);
    var LAYOUT_PAD_BOTTOM = Math.round(BASE_HEIGHT * 0.03);
    var FONT_FALLBACK = "'Noto Naskh Arabic','Noto Sans Urdu',Tahoma,Arial,sans-serif";

    // ─────────────────────────────────────────────────────────────────────────
    // DOM REFERENCES
    // ─────────────────────────────────────────────────────────────────────────

    var $templateSelect = $('#dit-ts-template');
    var $imageList = $('#dit-ts-image-list');
    var $addImagesBtn = $('#dit-ts-add-images');
    var $generateBtn = $('#dit-ts-generate-btn');
    var $resultActions = $('#dit-ts-result-actions');
    var $viewLink = $('#dit-ts-view-link');
    var $previewBox = $('#dit-ts-preview-box');
    var $placeholder = $previewBox.find('.dit-ts-placeholder');
    var $canvas = $('#dit-ts-split-canvas');
    var canvas = $canvas[0];
    var $gridResultImg = $('#dit-ts-grid-result-img');
    var $formatSelect = $('#dit-ts-output-format');
    var $titleInput = $('#dit-ts-collage-title');

    // Split Card
    var $headingInput = $('#dit-ts-split-heading');
    var $bodyInput = $('#dit-ts-split-body');
    var $headingSizeInput = $('#dit-ts-heading-size');
    var $headingSizeVal = $('#dit-ts-heading-size-val');
    var $bodySizeInput = $('#dit-ts-body-size');
    var $bodySizeVal = $('#dit-ts-body-size-val');
    var $headingLHInput = $('#dit-ts-heading-line-height');
    var $headingLHVal = $('#dit-ts-heading-line-height-val');
    var $bodyLHInput = $('#dit-ts-body-line-height');
    var $bodyLHVal = $('#dit-ts-body-line-height-val');
    var $mainFontSelect = $('#dit-ts-main-font');
    var $brandTextInput = $('#dit-ts-brand-text');
    var $brandBarHInput = $('#dit-ts-brand-bar-height');
    var $brandBarHVal = $('#dit-ts-brand-bar-height-val');
    var $logoSizeInput = $('#dit-ts-logo-size');
    var $logoSizeVal = $('#dit-ts-logo-size-val');
    var $logoPreview = $('#dit-ts-logo-preview');
    var $logoIdInput = $('#dit-ts-logo-id');
    var $selectLogoBtn = $('#dit-ts-select-logo');
    var $clearLogoBtn = $('#dit-ts-clear-logo');
    var $bodyBgInput = $('#dit-ts-body-bg-color');
    var $brandBgInput = $('#dit-ts-brand-bg-color');
    var $exportScaleSelect = $('#dit-ts-export-scale');
    var $fontPreviewSplit = $('#dit-ts-font-preview-split');
    // @MODIFIED 2026-03-01 - New refs for heading bg, brand bar font size/align
    var $headingBgInput = $('#dit-ts-heading-bg-color');
    var $bodyBgSplitInput = $('#dit-ts-body-bg-color-split');
    var $brandFontSizeInput = $('#dit-ts-brand-font-size');
    var $brandFontSizeVal = $('#dit-ts-brand-font-size-val');
    var $brandTextAlignSelect = $('#dit-ts-brand-text-align');
    // @MODIFIED 2026-03-01 - Brand letter spacing & watermark opacity
    var $brandLetterSpacingInput = $('#dit-ts-brand-letter-spacing');
    var $brandLetterSpacingVal = $('#dit-ts-brand-letter-spacing-val');
    var $watermarkOpacityInput = $('#dit-ts-watermark-opacity');
    var $watermarkOpacityVal = $('#dit-ts-watermark-opacity-val');

    // Grid
    var $gridImageCountSelect = $('#dit-ts-grid-image-count');
    var $gridLayoutSelect = $('#dit-ts-grid-layout');
    var $aspectRatioSelect = $('#dit-ts-aspect-ratio');
    var $customDims = $('#dit-ts-custom-dims');
    var $customWidthInput = $('#dit-ts-custom-width');
    var $customHeightInput = $('#dit-ts-custom-height');
    var $cornerRadiusInput = $('#dit-ts-corner-radius');
    var $cornerRadiusVal = $('#dit-ts-corner-radius-val');
    var $gridFontSelect = $('#dit-ts-grid-font');
    var $gridFontSizeInput = $('#dit-ts-grid-font-size');
    var $gridFontSizeVal = $('#dit-ts-grid-font-size-val');
    var $letterSpacingInput = $('#dit-ts-letter-spacing');
    var $letterSpacingVal = $('#dit-ts-letter-spacing-val');
    var $textAlignSelect = $('#dit-ts-text-align');
    var $gridLineHeightInput = $('#dit-ts-grid-line-height');
    var $gridLineHeightVal = $('#dit-ts-grid-line-height-val');
    var $borderColorInput = $('#dit-ts-border-color');
    var $blurIntensityInput = $('#dit-ts-blur-intensity');
    var $blurIntensityVal = $('#dit-ts-blur-intensity-val');
    var $isRetinaCheck = $('#dit-ts-is-retina');
    var $gridBottomTextInput = $('#dit-ts-grid-bottom-text');
    var $fontPreviewGrid = $('#dit-ts-font-preview-grid');

    // ─────────────────────────────────────────────────────────────────────────
    // STATE
    // ─────────────────────────────────────────────────────────────────────────

    var state = {
        template: 'split_card',

        /**
         * Each image object:
         * { id, url, thumb, filename, cropScale, cropX, cropY }
         * cropScale: 1.0 = no zoom, 2.0 = 2× zoom in, 0.5 = zoom out
         * cropX/cropY: 0–100, focal point percentage
         */
        images: [],
        logo: { 
            id: ditTsCollage.defaults.logoId || null, 
            url: ditTsCollage.defaults.logoUrl || null 
        },

        typography: {
            mainFontFamily: 'Noto Nastaliq Urdu',
            headingSize: 48,
            bodySize: 26,
            headingLineHeight: 1.5,
            bodyLineHeight: 1.5,
        },

        text: { heading: '', body: '', brand: '' },

        layout: {
            // @MODIFIED 2026-03-01 - Added letterSpacing and watermarkOpacity
            brandBar: { heightPercent: 8, logoScale: 60, fontSizePercent: 45, textAlign: 'left', letterSpacing: 0 },
            watermarkOpacity: 0
        },

        colors: {
            // @MODIFIED 2026-03-01 - Added headingBg for separate heading zone color
            headingBg: '#f5c518',
            bodyBg: '#ffffff',
            brandBg: '#111111',
        },

        grid: {
            imageCount: 6,
            layout: '',
            aspectRatio: '1:1',
            customWidth: 1080,
            customHeight: 1080,
            cornerRadius: 0,
            fontFilename: '',
            // @MODIFIED 2026-03-01 - Aligned defaults with ContentPipeline (font_size:24, letter_spacing:10, line_height:1.2)
            fontSize: 24,
            letterSpacing: 10,
            textAlign: 'center',
            lineHeight: 1.2,
            borderColor: '#000000',
            blurIntensity: 0,
            isRetina: false,
            bottomText: '',
        },

        fontsReady: false,
        imageCache: {},
        exportScale: 2,
    };

    var _debounceTimer = null;

    // ─────────────────────────────────────────────────────────────────────────
    // UTILITIES
    // ─────────────────────────────────────────────────────────────────────────

    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

    function isRtlText(t) {
        return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(String(t || ''));
    }

    function fontStr(weight, size, family) {
        return weight + ' ' + Math.round(size) + "px '" + family + "'," + FONT_FALLBACK;
    }

    function escHtml(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function debounce(fn, ms) {
        return function () {
            clearTimeout(_debounceTimer);
            _debounceTimer = setTimeout(fn, ms);
        };
    }

    function getLuminanceTextColor(hex) {
        hex = String(hex || '#ffffff').replace('#', '');
        if (hex.length === 3) { hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2]; }
        var r = parseInt(hex.substring(0, 2), 16) / 255;
        var g = parseInt(hex.substring(2, 4), 16) / 255;
        var b = parseInt(hex.substring(4, 6), 16) / 255;
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) > 0.55 ? '#1a1a1a' : '#f5f5f5';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FONT LOADING
    // ─────────────────────────────────────────────────────────────────────────

    function loadFonts() {
        if (!document.fonts || typeof document.fonts.load !== 'function') {
            state.fontsReady = true;
            return Promise.resolve();
        }
        var glyph = '\u0628';

        var fontsToLoad = [
            "400 48px 'Noto Nastaliq Urdu'",
            "700 48px 'Noto Nastaliq Urdu'",
            "400 48px 'Noto Naskh Arabic'",
            "700 48px 'Noto Naskh Arabic'",
            "400 48px 'Noto Sans Urdu'",
        ];

        // @MODIFIED 2026-03-01 - Preload custom local TTF fonts
        var fileFonts = Array.isArray(ditTsCollage.fonts) ? ditTsCollage.fonts : [];
        fileFonts.forEach(function (f) {
            if (f && f.filename) {
                fontsToLoad.push("400 48px '" + f.filename + "'");
            }
        });

        return Promise.all(fontsToLoad.map(function (s) {
            return document.fonts.load(s, glyph).catch(function () { return null; });
        })).then(function () { state.fontsReady = true; });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // IMAGE CACHE
    // ─────────────────────────────────────────────────────────────────────────

    function loadImage(url) {
        if (state.imageCache[url] instanceof HTMLImageElement) {
            return Promise.resolve(state.imageCache[url]);
        }
        return new Promise(function (resolve, reject) {
            var img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = function () { state.imageCache[url] = img; resolve(img); };
            img.onerror = function () { reject(new Error('Load failed: ' + url)); };
            img.src = url;
        });
    }

    function drawPlaceholderRect(ctx, x, y, w, h) {
        ctx.save();
        ctx.fillStyle = '#cccccc';
        ctx.fillRect(x, y, w, h);
        var sz = Math.round(Math.min(w, h) * 0.18);
        ctx.fillStyle = '#999999';
        ctx.font = sz + 'px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('\u{1F5BC}', x + w / 2, y + h / 2);
        ctx.restore();
    }

    /**
     * Draw image with cover-fit + per-image zoom and focal point.
     * Mirrors PHP copy_and_cover() logic exactly so preview = export.
     *
     * @param {number} cropScale  1.0 = normal, >1 = zoom in
     * @param {number} cropX      0–100 horizontal focal point %
     * @param {number} cropY      0–100 vertical focal point %
     */
    function drawCoverImage(ctx, img, x, y, w, h, cropScale, cropX, cropY) {
        if (!img || !img.naturalWidth) { return; }

        cropScale = Math.max(0.5, parseFloat(cropScale) || 1.0);
        cropX = typeof cropX === 'number' ? clamp(cropX, 0, 100) : 50;
        cropY = typeof cropY === 'number' ? clamp(cropY, 0, 100) : 50;

        var sw = img.naturalWidth;
        var sh = img.naturalHeight;
        var asr = sw / sh;
        var adr = w / h;

        // Auto-shift focal point for very wide source images (composite collages)
        // to show one complete half instead of centering on the seam
        if (asr > adr * 1.5 && cropX >= 40 && cropX <= 60) {
            cropX = 25;
        }

        var baseCropW = asr > adr ? sh * adr : sw;
        var baseCropH = asr > adr ? sh : sw / adr;

        var cropW = Math.min(sw, Math.round(baseCropW / cropScale));
        var cropH = Math.min(sh, Math.round(baseCropH / cropScale));
        var sx = Math.round((sw - cropW) * (cropX / 100));
        var sy = Math.round((sh - cropH) * (cropY / 100));

        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, w, h);
        ctx.clip();
        ctx.drawImage(img, sx, sy, cropW, cropH, x, y, w, h);
        ctx.restore();
    }

    /**
     * @MODIFIED 2026-03-01 - New drawFitImage for Grid blur background
     */
    function drawFitImage(ctx, img, x, y, w, h, cropScale, cropX, cropY) {
        if (!img || !img.naturalWidth) { return; }
        cropScale = Math.max(0.5, parseFloat(cropScale) || 1.0);
        cropX = typeof cropX === 'number' ? clamp(cropX, 0, 100) : 50;
        cropY = typeof cropY === 'number' ? clamp(cropY, 0, 100) : 50;
        var sw = img.naturalWidth, sh = img.naturalHeight;
        var asr = sw / sh, adr = w / h;
        var fitW = asr > adr ? w : h * asr;
        var fitH = asr > adr ? w / asr : h;
        fitW *= cropScale;
        fitH *= cropScale;
        var maxOffsetX = Math.max(0, fitW - w), maxOffsetY = Math.max(0, fitH - h);
        var cx = x + (w - fitW) / 2 + (maxOffsetX * ((50 - cropX) / 50));
        var cy = y + (h - fitH) / 2 + (maxOffsetY * ((50 - cropY) / 50));
        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, w, h);
        ctx.clip();
        ctx.drawImage(img, cx, cy, fitW, fitH);
        ctx.restore();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEXT ENGINE
    // ─────────────────────────────────────────────────────────────────────────

    function wrapText(ctx, text, maxWidth) {
        var trimmed = String(text || '').trim();
        if (!trimmed) { return []; }
        var words = trimmed.split(/\s+/);
        var lines = [], line = '';
        for (var i = 0; i < words.length; i++) {
            var cand = line ? line + ' ' + words[i] : words[i];
            if (ctx.measureText(cand).width > maxWidth && line !== '') {
                lines.push(line); line = words[i];
            } else { line = cand; }
        }
        if (line) { lines.push(line); }
        return lines;
    }

    function fitTextToBox(ctx, text, maxWidth, maxHeight, initSize, minSize, lhMult, family, weight) {
        var trimmed = String(text || '').trim();
        if (!trimmed) { return { lines: [], fontSize: initSize }; }
        weight = weight || '600';
        minSize = minSize || MIN_FONT_SIZE;
        lhMult = lhMult || 1.4;
        var fontSize = Math.max(minSize, Math.round(initSize));
        var lines;
        while (fontSize >= minSize) {
            ctx.font = fontStr(weight, fontSize, family);
            lines = wrapText(ctx, trimmed, maxWidth);
            if (!lines.length) { fontSize--; continue; }
            if (fontSize * lhMult * lines.length <= maxHeight) {
                return { lines: lines, fontSize: fontSize };
            }
            fontSize--;
        }
        fontSize = minSize;
        ctx.font = fontStr(weight, fontSize, family);
        lines = wrapText(ctx, trimmed, maxWidth);
        if (!lines.length) { lines = [trimmed.split(/\s+/)[0]]; }
        var maxLines = Math.max(1, Math.floor(maxHeight / (fontSize * lhMult)));
        lines = lines.slice(0, maxLines);
        var last = lines[lines.length - 1], ell = '\u2026';
        while (last.length > 1 && ctx.measureText(last + ell).width > maxWidth) { last = last.slice(0, -1); }
        lines[lines.length - 1] = last.trimRight() + ell;
        return { lines: lines, fontSize: fontSize };
    }

    function drawLines(ctx, lines, x, y, bw, lh, color, isRtl) {
        if (!lines || !lines.length) { return; }
        ctx.save();
        ctx.fillStyle = color || '#000000';
        ctx.textBaseline = 'top';
        if (isRtl) {
            ctx.direction = 'rtl'; ctx.textAlign = 'right';
            for (var i = 0; i < lines.length; i++) { ctx.fillText(lines[i], x + bw, y + i * lh); }
        } else {
            ctx.direction = 'ltr'; ctx.textAlign = 'left';
            for (var j = 0; j < lines.length; j++) { ctx.fillText(lines[j], x, y + j * lh); }
        }
        ctx.restore();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BRAND BAR  (Split Card)
    // ─────────────────────────────────────────────────────────────────────────

    // @MODIFIED 2026-03-01 - drawBrandBar now uses brandFontSizePercent + brandTextAlign
    function drawBrandBar(ctx, barY, barH, logoImg) {
        var L = state.layout.brandBar;
        var T = state.typography;
        var C = state.colors;

        ctx.save();
        ctx.fillStyle = C.brandBg;
        ctx.fillRect(0, barY, BASE_WIDTH, barH);

        var padX = Math.round(BASE_WIDTH * 0.04);
        var logoH = Math.round(barH * (L.logoScale / 100));
        var logoY = barY + Math.round((barH - logoH) / 2);
        var textX = padX;
        var textRight = BASE_WIDTH - padX;

        if (logoImg && logoImg.naturalWidth) {
            var asp = logoImg.naturalWidth / logoImg.naturalHeight;
            var logoW = Math.min(Math.round(logoH * asp), Math.round(BASE_WIDTH * 0.25));
            ctx.save();
            ctx.beginPath(); ctx.rect(padX, logoY, logoW, logoH); ctx.clip();
            ctx.drawImage(logoImg, padX, logoY, logoW, logoH);
            ctx.restore();
            textX = padX + logoW + Math.round(BASE_WIDTH * 0.02);
            textRight = BASE_WIDTH - padX;
        }

        var brand = String(state.text.brand || '').trim();
        if (brand) {
            var bRtl = isRtlText(brand);
            var fontPct = L.fontSizePercent || 45;
            var bSz = clamp(Math.round(barH * (fontPct / 100)), 12, 72);
            var align = L.textAlign || 'left';
            ctx.font = fontStr('700', bSz, T.mainFontFamily);
            ctx.fillStyle = '#ffffff';
            ctx.textBaseline = 'middle';
            // @MODIFIED 2026-03-01 - Applying letter spacing via modern canvas API
            if ('letterSpacing' in ctx && L.letterSpacing > 0) {
                ctx.letterSpacing = L.letterSpacing + 'px';
            }
            var midY = barY + barH / 2;
            if (bRtl) {
                ctx.direction = 'rtl'; ctx.textAlign = 'right';
                ctx.fillText(brand, textRight, midY);
            } else if (align === 'center') {
                ctx.direction = 'ltr'; ctx.textAlign = 'center';
                ctx.fillText(brand, textX + (textRight - textX) / 2, midY);
            } else if (align === 'right') {
                ctx.direction = 'ltr'; ctx.textAlign = 'right';
                ctx.fillText(brand, textRight, midY);
            } else {
                ctx.direction = 'ltr'; ctx.textAlign = 'left';
                ctx.fillText(brand, textX, midY);
            }
            if ('letterSpacing' in ctx) { ctx.letterSpacing = '0px'; } // reset
        }
        ctx.restore();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DRAW SPLIT CARD
    // ─────────────────────────────────────────────────────────────────────────

    // @MODIFIED 2026-03-01 - Complete rewrite: two separate color zones (heading + body),
    // body size is now truly independent from heading size.
    function drawSplitCard(ctx, imageEls, logoImg) {
        var T = state.typography;
        var C = state.colors;
        var LB = state.layout.brandBar;

        var brandBarH = Math.round(BASE_HEIGHT * (LB.heightPercent / 100));
        var imageStripH = Math.round(BASE_HEIGHT * TOP_STRIP_PERCENT);
        var brandBarY = BASE_HEIGHT - brandBarH;
        var tbX = LAYOUT_PAD_X, tbW = BASE_WIDTH - 2 * LAYOUT_PAD_X;

        // ── 1. Image strip
        var imgCount = Math.min(imageEls.length, MAX_SPLIT_IMAGES);
        var slotW = Math.floor(BASE_WIDTH / imgCount);
        for (var i = 0; i < imgCount; i++) {
            var sx = i * slotW;
            var sw = i === imgCount - 1 ? BASE_WIDTH - sx : slotW;
            var imgData = state.images[i];
            if (imageEls[i]) {
                drawCoverImage(ctx, imageEls[i], sx, 0, sw, imageStripH,
                    imgData ? imgData.cropScale : 1.0,
                    imgData ? imgData.cropX : 50,
                    imgData ? imgData.cropY : 50);
            } else {
                drawPlaceholderRect(ctx, sx, 0, sw, imageStripH);
            }
        }

        // @MODIFIED 2026-03-01 - 1a. Top-center watermark logo
        var opacity = state.layout.watermarkOpacity || 0;
        if (opacity > 0 && logoImg && logoImg.naturalWidth) {
            ctx.save();
            ctx.globalAlpha = opacity / 100;
            var asp = logoImg.naturalWidth / logoImg.naturalHeight;
            // Scale logo to ~15% of the split card width max, or 15% height
            var maxLogH = Math.round(imageStripH * 0.15);
            var lw = Math.min(Math.round(maxLogH * asp), Math.round(BASE_WIDTH * 0.25));
            var lh = Math.round(lw / asp);
            var lx = Math.round((BASE_WIDTH - lw) / 2);
            var ly = Math.round(LAYOUT_PAD_Y);
            ctx.drawImage(logoImg, lx, ly, lw, lh);
            ctx.restore();
        }

        // ── 2. Measure heading block first (own BG zone)
        var headingText = String(state.text.heading || '').trim();
        var bodyText = String(state.text.body || '').trim();
        var remainH = BASE_HEIGHT - imageStripH - brandBarH;

        // @MODIFIED 2026-03-01 - Fixed zone sizing and vertical centering.
        // Zones are given max allocated height to ensure consistency.
        var headingZoneH = Math.round(remainH * 0.45);
        var bodyZoneH = remainH - headingZoneH;

        var headingPadV = Math.round(LAYOUT_PAD_Y * 0.8);
        var bodyPadV = Math.round(LAYOUT_PAD_Y * 0.7);

        // ── 3. Draw heading background zone
        var headingZoneTop = imageStripH;
        ctx.fillStyle = C.headingBg;
        ctx.fillRect(0, headingZoneTop, BASE_WIDTH, headingZoneH);

        // ── 4. Measure and draw heading text centred vertically in zone
        if (headingText) {
            var hResult = fitTextToBox(ctx, headingText, tbW,
                headingZoneH - headingPadV * 2,
                T.headingSize, MIN_FONT_SIZE, T.headingLineHeight, T.mainFontFamily, '700');
            var hLineH = hResult.fontSize * T.headingLineHeight;
            var hBlockH = hLineH * hResult.lines.length;
            var hY = headingZoneTop + Math.max(headingPadV, (headingZoneH - hBlockH) / 2); // true center
            drawLines(ctx, hResult.lines, tbX, hY, tbW, hLineH,
                getLuminanceTextColor(C.headingBg), isRtlText(headingText));
        }

        // ── 5. Draw body background zone
        var bodyZoneTop = headingZoneTop + headingZoneH;
        ctx.fillStyle = C.bodyBg;
        ctx.fillRect(0, bodyZoneTop, BASE_WIDTH, bodyZoneH);

        // ── 6. Measure and draw body text centred vertically in zone
        if (bodyText) {
            var bResult = fitTextToBox(ctx, bodyText, tbW,
                bodyZoneH - bodyPadV * 2,
                T.bodySize, MIN_FONT_SIZE, T.bodyLineHeight, T.mainFontFamily, '400');
            var bLineH = bResult.fontSize * T.bodyLineHeight;
            var bBlockH = bLineH * bResult.lines.length;
            var bY = bodyZoneTop + Math.max(bodyPadV, (bodyZoneH - bBlockH) / 2); // true center
            drawLines(ctx, bResult.lines, tbX, bY, tbW, bLineH,
                getLuminanceTextColor(C.bodyBg), isRtlText(bodyText));
        }

        // ── 7. Brand bar
        drawBrandBar(ctx, brandBarY, brandBarH, logoImg);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SPLIT CARD PREVIEW
    // ─────────────────────────────────────────────────────────────────────────

    function renderSplitCardPreview() {
        if (!canvas) { return; }
        if (state.images.length < MIN_SPLIT_IMAGES) {
            $canvas.hide(); $placeholder.show(); return;
        }
        syncSplitStateFromControls();

        var imgPromises = state.images.slice(0, MAX_SPLIT_IMAGES).map(function (im) {
            return loadImage(im.url).catch(function () { return null; });
        });
        var logoPromise = state.logo.url
            ? loadImage(state.logo.url).catch(function () { return null; })
            : Promise.resolve(null);

        Promise.all(imgPromises.concat([logoPromise])).then(function (res) {
            var imgEls = res.slice(0, imgPromises.length);
            var logoImg = res[res.length - 1];

            canvas.width = BASE_WIDTH;
            canvas.height = BASE_HEIGHT;
            var ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, BASE_WIDTH, BASE_HEIGHT);
            drawSplitCard(ctx, imgEls, logoImg);

            $placeholder.hide();
            $gridResultImg.hide();
            $canvas.css('display', 'block');
        }).catch(function (e) {
            if (typeof console !== 'undefined') { console.warn('[DIT] Split preview:', e); }
        });
    }

    var debouncedPreview = debounce(renderSplitCardPreview, PREVIEW_DEBOUNCE_MS);

    // ─────────────────────────────────────────────────────────────────────────
    // SPLIT CARD EXPORT
    // ─────────────────────────────────────────────────────────────────────────

    function exportAndSave() {
        if (state.images.length < MIN_SPLIT_IMAGES) { return; }
        syncSplitStateFromControls();

        var scale = state.exportScale;
        var format = String($formatSelect.val() || 'webp');

        var imgPromises = state.images.slice(0, MAX_SPLIT_IMAGES).map(function (im) {
            return loadImage(im.url).catch(function () { return null; });
        });
        var logoPromise = state.logo.url
            ? loadImage(state.logo.url).catch(function () { return null; })
            : Promise.resolve(null);

        $generateBtn.prop('disabled', true).text('Saving…');

        Promise.all(imgPromises.concat([logoPromise])).then(function (res) {
            var imgEls = res.slice(0, imgPromises.length);
            var logoImg = res[res.length - 1];

            var ec = document.createElement('canvas');
            ec.width = BASE_WIDTH * scale;
            ec.height = BASE_HEIGHT * scale;
            var ctx = ec.getContext('2d');
            ctx.scale(scale, scale);
            drawSplitCard(ctx, imgEls, logoImg);

            var mimes = { webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png' };
            var mime = mimes[format] || 'image/webp';
            var q = format === 'png' ? 1 : 0.92;
            var dataUrl;

            try { dataUrl = ec.toDataURL(mime, q); }
            catch (e) {
                alert('Export blocked by CORS. Ensure images are served from the same domain or CDN has Access-Control-Allow-Origin headers.');
                $generateBtn.prop('disabled', false); updateGenerateButton(); return;
            }

            var title = String($titleInput.val() || '').trim() ||
                'Collage ' + new Date().toISOString().slice(0, 16).replace('T', ' ');

            $.post(ditTsCollage.ajaxUrl, {
                action: 'dit_ts_save_canvas_collage', nonce: ditTsCollage.nonce,
                data_url: dataUrl, format: format, collage_title: title,
            })
                .done(function (r) {
                    if (r && r.success && r.data && r.data.url) {
                        $viewLink.attr('href', r.data.url);
                        $resultActions.removeClass('hidden');
                    } else {
                        alert('Save failed: ' + ((r && r.data) ? r.data : 'Unknown error'));
                    }
                })
                .fail(function (xhr) { alert('AJAX: ' + (xhr.statusText || 'unknown')); })
                .always(function () { $generateBtn.prop('disabled', false); updateGenerateButton(); });

        }).catch(function (e) {
            alert('Render error: ' + (e && e.message ? e.message : 'unknown'));
            $generateBtn.prop('disabled', false); updateGenerateButton();
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GRID PREVIEW — Canvas mirrors PHP draw_grid() switch/case exactly
    // ─────────────────────────────────────────────────────────────────────────

    function clipRoundedRect(ctx, x, y, w, h, r) {
        r = Math.min(r, w / 2, h / 2);
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h - r);
        ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
        ctx.lineTo(x + r, y + h);
        ctx.arcTo(x, y + h, x, y + h - r, r);
        ctx.lineTo(x, y + r);
        ctx.arcTo(x, y, x + r, y, r);
        ctx.closePath();
    }

    function drawGridSlot(ctx, imageEl, imgData, x, y, w, h, radius) {
        if (imgData) { imgData.gridRect = { x: x, y: y, w: w, h: h }; }
        ctx.save();
        if (radius > 0) { clipRoundedRect(ctx, x, y, w, h, radius); ctx.clip(); }
        else { ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); }

        if (imageEl) {
            // @MODIFIED 2026-03-01 - Blur Support
            var blur = state.grid && state.grid.blurIntensity ? state.grid.blurIntensity : 0;
            if (blur > 0) {
                ctx.save();
                if ('filter' in ctx) { ctx.filter = 'blur(' + blur + 'px)'; }
                drawCoverImage(ctx, imageEl, x, y, w, h, 1.0, 50, 50);
                ctx.restore();
                drawFitImage(ctx, imageEl, x, y, w, h,
                    imgData ? (imgData.cropScale || 1.0) : 1.0,
                    imgData ? (imgData.cropX || 50) : 50,
                    imgData ? (imgData.cropY || 50) : 50);
            } else {
                drawCoverImage(ctx, imageEl, x, y, w, h,
                    imgData ? (imgData.cropScale || 1.0) : 1.0,
                    imgData ? (imgData.cropX || 50) : 50,
                    imgData ? (imgData.cropY || 50) : 50);
            }
        } else {
            drawPlaceholderRect(ctx, x, y, w, h);
        }
        ctx.restore();
    }

    function drawGridSlots(ctx, imageEls, imgDataArr, layout, cW, imageAreaH, cornerRadius) {
        var gap = 5;
        var w = cW - 2 * gap;
        var h = imageAreaH - gap;
        var ox = gap, oy = gap;
        var num = Math.min(imageEls.length, 6);
        var r = cornerRadius || 0;
        if (!num) { return; }

        function ds(idx, dx, dy, dw, dh) {
            drawGridSlot(ctx, imageEls[idx] || null, imgDataArr[idx] || null,
                dx, dy, Math.max(1, Math.round(dw)), Math.max(1, Math.round(dh)), r);
        }

        var cw, hh;
        switch (num) {
            case 1:
                ds(0, ox, oy, w, h); break;
            case 2:
                if (layout === '2-rows') {
                    hh = Math.floor((h - gap) / 2);
                    ds(0, ox, oy, w, hh); ds(1, ox, oy + hh + gap, w, hh);
                } else {
                    cw = Math.floor((w - gap) / 2);
                    ds(0, ox, oy, cw, h); ds(1, ox + cw + gap, oy, cw, h);
                }
                break;
            case 3:
                if (layout === '1-2') {
                    cw = Math.floor((w - gap) / 2); hh = Math.floor((h - gap) / 2);
                    ds(0, ox, oy, cw, h);
                    ds(1, ox + cw + gap, oy, cw, hh); ds(2, ox + cw + gap, oy + hh + gap, cw, hh);
                } else {
                    cw = Math.floor((w - 2 * gap) / 3);
                    ds(0, ox, oy, cw, h); ds(1, ox + cw + gap, oy, cw, h); ds(2, ox + 2 * (cw + gap), oy, cw, h);
                }
                break;
            case 4:
                cw = Math.floor((w - 2 * gap) / 3); hh = Math.floor((h - gap) / 2);
                if (layout === '2-1-1') {
                    ds(0, ox, oy, cw, hh); ds(1, ox, oy + hh + gap, cw, hh);
                    ds(2, ox + cw + gap, oy, cw, h); ds(3, ox + 2 * (cw + gap), oy, cw, h);
                } else if (layout === '1-1-2') {
                    ds(0, ox, oy, cw, h); ds(1, ox + cw + gap, oy, cw, h);
                    ds(2, ox + 2 * (cw + gap), oy, cw, hh); ds(3, ox + 2 * (cw + gap), oy + hh + gap, cw, hh);
                } else {
                    ds(0, ox, oy, cw, h);
                    ds(1, ox + cw + gap, oy, cw, hh); ds(2, ox + cw + gap, oy + hh + gap, cw, hh);
                    ds(3, ox + 2 * (cw + gap), oy, cw, h);
                }
                break;
            case 5:
                cw = Math.floor((w - 2 * gap) / 3); hh = Math.floor((h - gap) / 2);
                if (layout === '1-2-2') {
                    ds(0, ox, oy, cw, h);
                    ds(1, ox + cw + gap, oy, cw, hh); ds(2, ox + cw + gap, oy + hh + gap, cw, hh);
                    ds(3, ox + 2 * (cw + gap), oy, cw, hh); ds(4, ox + 2 * (cw + gap), oy + hh + gap, cw, hh);
                } else if (layout === '2-1-2') {
                    ds(0, ox, oy, cw, hh); ds(1, ox, oy + hh + gap, cw, hh);
                    ds(2, ox + cw + gap, oy, cw, h);
                    ds(3, ox + 2 * (cw + gap), oy, cw, hh); ds(4, ox + 2 * (cw + gap), oy + hh + gap, cw, hh);
                } else {
                    ds(0, ox, oy, cw, hh); ds(1, ox, oy + hh + gap, cw, hh);
                    ds(2, ox + cw + gap, oy, cw, hh); ds(3, ox + cw + gap, oy + hh + gap, cw, hh);
                    ds(4, ox + 2 * (cw + gap), oy, cw, h);
                }
                break;
            case 6: default:
                cw = Math.floor((w - 2 * gap) / 3); hh = Math.floor((h - gap) / 2);
                ds(0, ox, oy, cw, hh); ds(1, ox, oy + hh + gap, cw, hh);
                ds(2, ox + cw + gap, oy, cw, hh); ds(3, ox + cw + gap, oy + hh + gap, cw, hh);
                ds(4, ox + 2 * (cw + gap), oy, cw, hh); ds(5, ox + 2 * (cw + gap), oy + hh + gap, cw, hh);
                break;
        }
    }

    function drawGridBar(ctx, text, cW, cH, barH, bgColor, fontFamily, fontSize, textAlign) {
        ctx.save();
        ctx.fillStyle = bgColor || '#000000';
        ctx.fillRect(0, cH - barH, cW, barH);
        if (!text) { ctx.restore(); return; }

        var sz = clamp(Math.round(barH * 0.42), 12, 52);
        if (fontSize) { sz = clamp(Math.round(fontSize * (barH / 60)), 12, 52); }

        var lhMult = state.grid.lineHeight || 1.2;
        var lineH = sz * lhMult;
        var letterSpacing = state.grid.letterSpacing || 0;

        ctx.font = fontStr('700', sz, fontFamily || state.typography.mainFontFamily);
        var lines = text.split('\n');
        var totalTextH = lines.length * lineH;

        var startY = (cH - (barH / 2)) - (totalTextH / 2) + sz;
        var padX = Math.round(cW * 0.04);
        var rtl = isRtlText(text);

        if ('letterSpacing' in ctx) { ctx.letterSpacing = letterSpacing + 'px'; }
        ctx.fillStyle = '#ffffff';
        ctx.textBaseline = 'alphabetic';

        for (var i = 0; i < lines.length; i++) {
            var lineT = lines[i];
            var y = startY + (i * lineH);

            if (rtl) {
                ctx.direction = 'rtl'; ctx.textAlign = 'right';
                ctx.fillText(lineT, cW - padX, y);
            } else if (textAlign === 'left') {
                ctx.direction = 'ltr'; ctx.textAlign = 'left';
                ctx.fillText(lineT, padX, y);
            } else if (textAlign === 'right') {
                ctx.direction = 'ltr'; ctx.textAlign = 'right';
                ctx.fillText(lineT, cW - padX, y);
            } else {
                ctx.direction = 'ltr'; ctx.textAlign = 'center';
                ctx.fillText(lineT, cW / 2, y);
            }
        }

        if ('letterSpacing' in ctx) { ctx.letterSpacing = '0px'; }
        ctx.restore();
    }

    function resolveGridCanvasSize(g) {
        var cW = 800, cH = 800;
        var ar = g.aspectRatio || '1:1';
        var presets = { '1:1': [800, 800], '16:9': [800, 450], '9:16': [450, 800], '4:3': [800, 600], '4:5': [640, 800] };
        if (ar === 'custom') {
            cW = Math.max(200, g.customWidth || 1080);
            cH = Math.max(200, g.customHeight || 1080);
        } else if (ar === 'legacy') {
            cW = 700; cH = 412;
        } else if (presets[ar]) {
            cW = presets[ar][0]; cH = presets[ar][1];
        } else {
            var pts = String(ar).split(':');
            if (pts.length === 2) {
                var rw = parseInt(pts[0], 10), rh = parseInt(pts[1], 10);
                if (rw > 0 && rh > 0) { cW = 800; cH = Math.round(800 * rh / rw); }
            }
        }
        return { w: cW, h: cH };
    }

    function renderGridPreview() {
        if (!canvas) { return; }
        if (!state.images.length) {
            $canvas.hide(); $gridResultImg.hide(); $placeholder.show(); return;
        }

        syncGridStateFromControls();
        var g = state.grid;
        var dim = resolveGridCanvasSize(g);
        var cW = dim.w, cH = dim.h;
        var brandText = String(g.bottomText || '').trim();
        var barH = brandText ? Math.max(Math.round(cH * 0.08), 40) : 0;
        var imageAreaH = cH - barH;

        Promise.all(state.images.map(function (im) {
            return loadImage(im.url).catch(function () { return null; });
        })).then(function (imageEls) {
            canvas.width = cW;
            canvas.height = cH;
            var ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, cW, cH);

            ctx.fillStyle = g.borderColor || '#000000';
            ctx.fillRect(0, 0, cW, cH);

            drawGridSlots(ctx, imageEls, state.images, g.layout, cW, imageAreaH, g.cornerRadius);

            if (brandText && barH > 0) {
                drawGridBar(ctx, brandText, cW, cH, barH,
                    g.borderColor, state.typography.mainFontFamily,
                    g.fontSize, g.textAlign);
            }

            $placeholder.hide();
            $gridResultImg.hide();
            $canvas.css('display', 'block');
        }).catch(function (e) {
            if (typeof console !== 'undefined') { console.warn('[DIT] Grid preview:', e); }
        });
    }

    var debouncedGridPreview = debounce(renderGridPreview, PREVIEW_DEBOUNCE_MS);

    // ─────────────────────────────────────────────────────────────────────────
    // GRID EXPORT (Server-side)
    // ─────────────────────────────────────────────────────────────────────────

    function submitGridCollage() {
        if (!state.images.length) { return; }
        syncGridStateFromControls();

        var g = state.grid;
        var format = String($formatSelect.val() || 'webp');
        var title = String($titleInput.val() || '').trim() ||
            'Grid Collage ' + new Date().toISOString().slice(0, 16).replace('T', ' ');

        var crops = {};
        state.images.forEach(function (im, idx) {
            crops[idx] = {
                x: im.cropX || 50, y: im.cropY || 50,
                scale: im.cropScale || 1.0, full_crop: true,
            };
        });

        var postData = {
            action: 'dit_ts_generate_collage', nonce: ditTsCollage.nonce,
            images: state.images.map(function (im) { return im.id; }),
            collage_title: title, format: format,
            layout: g.layout, aspect_ratio: g.aspectRatio,
            custom_width: g.customWidth, custom_height: g.customHeight,
            corner_radius: g.cornerRadius, font_size: g.fontSize,
            letter_spacing: g.letterSpacing, text_align: g.textAlign,
            line_height: g.lineHeight, border_color: g.borderColor,
            blur_intensity: g.blurIntensity, is_retina: g.isRetina ? '1' : '0',
            bottom_text: g.bottomText, font_filename: g.fontFilename,
            crops: crops,
        };

        $generateBtn.prop('disabled', true).text('Generating…');
        $resultActions.addClass('hidden');

        $.post(ditTsCollage.ajaxUrl, postData)
            .done(function (r) {
                if (r && r.success && r.data && r.data.url) {
                    $gridResultImg.attr('src', r.data.url).css('display', 'block');
                    $canvas.hide(); $placeholder.hide();
                    $viewLink.attr('href', r.data.url);
                    $resultActions.removeClass('hidden');
                } else {
                    alert('Grid collage failed: ' + ((r && r.data) ? r.data : 'Unknown error'));
                }
            })
            .fail(function (xhr) { alert('AJAX: ' + (xhr.statusText || 'unknown')); })
            .always(function () { $generateBtn.prop('disabled', false); updateGenerateButton(); });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STATE SYNC
    // ─────────────────────────────────────────────────────────────────────────

    // @MODIFIED 2026-03-01 - Syncs all new split card controls
    function syncSplitStateFromControls() {
        state.typography.headingSize = parseInt($headingSizeInput.val(), 10) || 48;
        state.typography.bodySize = parseInt($bodySizeInput.val(), 10) || 26;
        state.typography.headingLineHeight = parseFloat($headingLHInput.val()) || 1.5;
        state.typography.bodyLineHeight = parseFloat($bodyLHInput.val()) || 1.5;

        var fv = String($mainFontSelect.val() || '');
        state.typography.mainFontFamily = fv.indexOf('web:') === 0 ? fv.replace('web:', '') :
            fv.indexOf('file:') === 0 ? fv.replace('file:', '') :
                fv || 'Noto Nastaliq Urdu';

        state.text.heading = String($headingInput.val() || '');
        state.text.body = String($bodyInput.val() || '');
        state.text.brand = String($brandTextInput.val() || '');

        state.layout.brandBar.heightPercent = parseInt($brandBarHInput.val(), 10) || 8;
        state.layout.brandBar.logoScale = parseInt($logoSizeInput.val(), 10) || 60;
        state.layout.brandBar.fontSizePercent = parseInt($brandFontSizeInput.val(), 10) || 45;
        state.layout.brandBar.textAlign = String($brandTextAlignSelect.val() || 'left');
        state.layout.brandBar.letterSpacing = parseInt($brandLetterSpacingInput.val(), 10) || 0;
        state.layout.watermarkOpacity = parseInt($watermarkOpacityInput.val(), 10) || 0;

        state.colors.headingBg = String($headingBgInput.val() || '#f5c518');
        state.colors.bodyBg = String(($bodyBgSplitInput.length ? $bodyBgSplitInput : $bodyBgInput).val() || '#ffffff');
        state.colors.brandBg = String($brandBgInput.val() || '#111111');
        state.exportScale = parseInt($exportScaleSelect.val(), 10) || 2;
    }

    function syncGridStateFromControls() {
        var g = state.grid;
        g.imageCount = parseInt($gridImageCountSelect.val(), 10) || 6;
        g.layout = String($gridLayoutSelect.val() || '');
        g.aspectRatio = String($aspectRatioSelect.val() || '1:1');
        g.customWidth = parseInt($customWidthInput.val(), 10) || 1080;
        g.customHeight = parseInt($customHeightInput.val(), 10) || 1080;
        g.cornerRadius = parseInt($cornerRadiusInput.val(), 10) || 0;
        // @MODIFIED 2026-03-01 - Aligned fallbacks with ContentPipeline defaults
        g.fontSize = parseInt($gridFontSizeInput.val(), 10) || 24;
        g.letterSpacing = parseInt($letterSpacingInput.val(), 10) || 10;
        g.textAlign = String($textAlignSelect.val() || 'center');
        g.lineHeight = parseFloat($gridLineHeightInput.val()) || 1.2;
        g.borderColor = String($borderColorInput.val() || '#000000');
        g.blurIntensity = parseInt($blurIntensityInput.val(), 10) || 0;
        g.isRetina = $isRetinaCheck.is(':checked');
        g.bottomText = String($gridBottomTextInput.val() || '');
        var gfv = String($gridFontSelect.val() || '');
        g.fontFilename = gfv.indexOf('file:') === 0 ? gfv.replace('file:', '') : gfv;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEMPLATE STATE
    // ─────────────────────────────────────────────────────────────────────────

    function getTemplate() {
        return String($templateSelect.val() || 'split_card') === 'grid' ? 'grid' : 'split_card';
    }

    function updateTemplateState() {
        state.template = getTemplate();
        if (state.template === 'split_card') {
            $('.dit-ts-split-only').removeClass('hidden').show();
            $('.dit-ts-grid-only').addClass('hidden').hide();
            $gridResultImg.hide();
            if (state.images.length >= MIN_SPLIT_IMAGES) { debouncedPreview(); }
            else { $canvas.hide(); $placeholder.show(); }
        } else {
            $('.dit-ts-grid-only').removeClass('hidden').show();
            $('.dit-ts-split-only').addClass('hidden').hide();
            $canvas.hide();
            if (state.images.length) { debouncedGridPreview(); }
            else { $placeholder.show(); }
        }
        updateGenerateButton();
    }

    function updateGenerateButton() {
        var min = state.template === 'split_card' ? MIN_SPLIT_IMAGES : 1;
        $generateBtn.prop('disabled', state.images.length < min);
        $generateBtn.text(state.template === 'split_card' ? 'Generate / Save (Split Card)' : 'Generate Grid Collage');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FONT SELECTOR + LIVE FONT PREVIEW BOX
    // ─────────────────────────────────────────────────────────────────────────

    function populateFonts() {
        var fileFonts = Array.isArray(ditTsCollage.fonts) ? ditTsCollage.fonts : [];
        var webFonts = Array.isArray(ditTsCollage.webFonts) ? ditTsCollage.webFonts : [];

        // @MODIFIED 2026-03-01 - Inject @font-face rules for local file fonts so Canvas can render them
        var styleId = 'dit-ts-custom-fonts-style';
        if (!document.getElementById(styleId)) {
            var cssText = '';
            fileFonts.forEach(function (f) {
                if (!f || !f.filename || !f.url) { return; }
                cssText += '@font-face {\n' +
                    '    font-family: "' + f.filename + '";\n' +
                    '    src: url("' + f.url + '") format("truetype");\n' +
                    '    font-weight: normal;\n' +
                    '    font-style: normal;\n' +
                    '    font-display: swap;\n' +
                    '}\n';
            });
            if (cssText) {
                var styleEl = document.createElement('style');
                styleEl.id = styleId;
                styleEl.innerHTML = cssText;
                document.head.appendChild(styleEl);
            }
        }

        $mainFontSelect.empty();
        webFonts.forEach(function (wf) {
            if (!wf || !wf.family) { return; }
            var def = wf.family === 'Noto Nastaliq Urdu';
            $mainFontSelect.append(new Option(wf.label || wf.family, 'web:' + wf.family, def, def));
        });
        fileFonts.forEach(function (f) {
            if (!f || !f.filename) { return; }
            $mainFontSelect.append(new Option(f.name, 'file:' + f.filename, false, false));
        });
        if (!$mainFontSelect.val() && webFonts.length) {
            $mainFontSelect.val('web:' + webFonts[0].family);
        }

        $gridFontSelect.find('option[value!=""]').remove();
        fileFonts.forEach(function (f) {
            if (!f || !f.filename) { return; }
            $gridFontSelect.append(new Option(f.name, 'file:' + f.filename, false, false));
        });

        updateFontPreview();
    }

    /**
     * Update the font preview boxes.
     * Split Card: uses Google webfont CSS already loaded in <head> → just set font-family.
     * Grid: file fonts aren't in browser CSS. We show font name as text and draw on canvas.
     */
    function updateFontPreview() {
        // Split Card preview
        var splitVal = String($mainFontSelect.val() || '');
        var splitFamily = splitVal.indexOf('web:') === 0 ? splitVal.replace('web:', '') :
            splitVal.indexOf('file:') === 0 ? splitVal.replace('file:', '') :
                'inherit';
        var splitFontStr = "'" + splitFamily + "'," + FONT_FALLBACK;
        $fontPreviewSplit.find('.dit-ts-fp-latin').css('font-family', splitFontStr);
        $fontPreviewSplit.find('.dit-ts-fp-urdu').css('font-family', splitFontStr);

        // Grid preview — show sample on a small canvas
        var gridVal = String($gridFontSelect.val() || '');
        var gridFamily = gridVal.indexOf('file:') === 0 ? gridVal.replace('file:', '') : 'system-ui';
        var gridFontStr = "'" + gridFamily + "'," + FONT_FALLBACK;
        $fontPreviewGrid.find('.dit-ts-fp-latin').css('font-family', gridFontStr);
        $fontPreviewGrid.find('.dit-ts-fp-urdu').css('font-family', gridFontStr);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GRID LAYOUT OPTIONS
    // ─────────────────────────────────────────────────────────────────────────

    function populateGridLayouts(imageCount) {
        $gridLayoutSelect.empty();
        var layouts = ditTsCollage.layouts || {};
        var options = layouts[imageCount] || layouts[String(imageCount)] || [];
        if (!options || !options.length) {
            $gridLayoutSelect.append(new Option('Default', 'default', true, true));
            return;
        }
        options.forEach(function (layout, idx) {
            var value = typeof layout === 'object' ? (layout.id || layout.value || String(idx)) : String(layout);
            var label = typeof layout === 'object' ? (layout.label || layout.name || ('Layout ' + (idx + 1))) : String(layout);
            $gridLayoutSelect.append(new Option(label, value, idx === 0, idx === 0));
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // IMAGE LIST — with per-image zoom slider and swap button
    // ─────────────────────────────────────────────────────────────────────────

    // @MODIFIED 2026-03-01 - Added move-up/move-down buttons per image item
    function renderImageList() {
        $imageList.empty();

        if (!state.images.length) {
            $imageList.html('<p class="dit-ts-empty-state">No images added yet.</p>');
            updateGenerateButton();
            return;
        }

        state.images.forEach(function (img, idx) {
            var scale = img.cropScale || 1.0;
            var total = state.images.length;
            var item = $(
                '<div class="dit-ts-image-item" id="dit-ts-img-' + img.id + '" data-id="' + img.id + '">' +
                '<span class="dit-ts-drag-handle dashicons dashicons-move"></span>' +
                '<img class="dit-ts-image-thumb" src="' + escHtml(img.thumb || img.url) + '" alt="">' +
                '<div class="dit-ts-image-meta">' +
                '<div class="dit-ts-row">' +
                '<span class="dit-ts-filename">' + escHtml(img.filename || 'Image ' + img.id) + '</span>' +
                '<div class="dit-ts-image-actions">' +
                '<button type="button" class="dit-ts-icon-btn dit-ts-move-up" data-id="' + img.id + '" title="Move up"' + (idx === 0 ? ' disabled' : '') + '>' +
                '<span class="dashicons dashicons-arrow-up-alt2"></span>' +
                '</button>' +
                '<button type="button" class="dit-ts-icon-btn dit-ts-move-down" data-id="' + img.id + '" title="Move down"' + (idx === total - 1 ? ' disabled' : '') + '>' +
                '<span class="dashicons dashicons-arrow-down-alt2"></span>' +
                '</button>' +
                '<button type="button" class="dit-ts-icon-btn dit-ts-swap-img" data-id="' + img.id + '" title="Swap image">' +
                '<span class="dashicons dashicons-image-rotate"></span>' +
                '</button>' +
                '<button type="button" class="dit-ts-icon-btn dit-ts-remove-img" data-id="' + img.id + '" title="Remove">' +
                '<span class="dashicons dashicons-trash"></span>' +
                '</button>' +
                '</div>' +
                '</div>' +
                '<div class="dit-ts-zoom-row">' +
                '<span class="dit-ts-zoom-label">Zoom</span>' +
                '<input type="range" class="dit-ts-zoom-slider" data-id="' + img.id + '" ' +
                'min="0.5" max="3.0" step="0.1" value="' + scale + '">' +
                '<span class="dit-ts-zoom-val">' + scale.toFixed(1) + 'x</span>' +
                '</div>' +
                '</div>' +
                '</div>'
            );
            $imageList.append(item);
        });

        initSortable();
        updateGenerateButton();
        triggerActivePreview();
    }

    function triggerActivePreview() {
        if (state.template === 'split_card') {
            if (state.images.length >= MIN_SPLIT_IMAGES) { debouncedPreview(); }
        } else {
            if (state.images.length) { debouncedGridPreview(); }
        }
    }

    function initSortable() {
        if (!$imageList.length || typeof $imageList.sortable !== 'function') { return; }
        if ($imageList.data('ui-sortable')) { $imageList.sortable('destroy'); }
        $imageList.sortable({
            items: '.dit-ts-image-item', handle: '.dit-ts-drag-handle', tolerance: 'pointer',
            update: function () {
                var newOrder = [];
                $imageList.find('.dit-ts-image-item').each(function () {
                    var id = parseInt(String($(this).attr('id') || '').replace('dit-ts-img-', ''), 10);
                    var img = state.images.find(function (m) { return m.id === id; });
                    if (img) { newOrder.push(img); }
                });
                if (newOrder.length === state.images.length) {
                    state.images = newOrder;
                    triggerActivePreview();
                }
            },
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MEDIA LIBRARY — Add images, Swap single image, Logo
    // ─────────────────────────────────────────────────────────────────────────

    var mediaFrame = null;

    function openMediaLibrary() {
        if (mediaFrame) { mediaFrame.open(); return; }
        mediaFrame = wp.media({ title: 'Select Images', button: { text: 'Add to Collage' }, multiple: true });
        mediaFrame.on('select', function () {
            var sel = mediaFrame.state().get('selection');
            var maxImg = state.template === 'split_card' ? MAX_SPLIT_IMAGES : MAX_GRID_IMAGES;
            var newImgs = [];
            sel.each(function (att) {
                var a = att.toJSON();
                if (state.images.some(function (im) { return im.id === a.id; })) { return; }
                var thumb = a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url;
                newImgs.push({
                    id: a.id, url: a.url, thumb: thumb,
                    filename: a.filename || ('image-' + a.id),
                    cropScale: 1.0, cropX: 50, cropY: 50
                });
            });
            state.images = state.images.concat(newImgs).slice(0, maxImg);
            renderImageList();
        });
        mediaFrame.open();
    }

    // @MODIFIED 2026-03-01 - Fixed broken openSwapLibrary (duplicated handler, missing braces)
    // Swap one specific image slot.
    function openSwapLibrary(targetId) {
        var swapFrame = wp.media({ title: 'Replace Image', button: { text: 'Replace' }, multiple: false });
        swapFrame.on('select', function () {
            var att = swapFrame.state().get('selection').first().toJSON();
            var idx = state.images.findIndex(function (im) { return im.id === targetId; });
            if (idx === -1) { return; }
            var thumb = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url;
            state.images[idx] = {
                id: att.id,
                url: att.url,
                thumb: thumb,
                filename: att.filename || ('image-' + att.id),
                cropScale: 1.0,
                cropX: 50,
                cropY: 50,
            };
            renderImageList();
        });
        swapFrame.open();
    }

    var logoFrame = null;

    function openLogoLibrary() {
        if (logoFrame) { logoFrame.open(); return; }
        logoFrame = wp.media({
            title: 'Select Logo', button: { text: 'Use as Logo' }, multiple: false,
            library: { type: 'image' }
        });
        logoFrame.on('select', function () {
            var att = logoFrame.state().get('selection').first().toJSON();
            state.logo.id = att.id;
            state.logo.url = att.url;
            $logoIdInput.val(att.id);
            $logoPreview.html('<img src="' + escHtml(att.url) + '" alt="Logo">');
            saveGlobalLogo(att.id);
            if (state.template === 'split_card') { debouncedPreview(); }
        });
        logoFrame.open();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EVENT BINDINGS
    // ─────────────────────────────────────────────────────────────────────────

    function bindEvents() {

        // Template switch
        $templateSelect.on('change', updateTemplateState);

        // Add images
        $addImagesBtn.on('click', openMediaLibrary);

        // Remove image
        $imageList.on('click', '.dit-ts-remove-img', function () {
            var id = parseInt($(this).attr('data-id'), 10);
            state.images = state.images.filter(function (im) { return im.id !== id; });
            if (state.template === 'split_card' && state.images.length < MIN_SPLIT_IMAGES) {
                $canvas.hide(); $placeholder.show();
            }
            renderImageList();
        });

        // @MODIFIED 2026-03-01 - Move up
        $imageList.on('click', '.dit-ts-move-up', function () {
            var id = parseInt($(this).attr('data-id'), 10);
            var idx = state.images.findIndex(function (im) { return im.id === id; });
            if (idx < 1) { return; }
            var tmp = state.images[idx - 1];
            state.images[idx - 1] = state.images[idx];
            state.images[idx] = tmp;
            renderImageList();
        });

        // @MODIFIED 2026-03-01 - Move down
        $imageList.on('click', '.dit-ts-move-down', function () {
            var id = parseInt($(this).attr('data-id'), 10);
            var idx = state.images.findIndex(function (im) { return im.id === id; });
            if (idx === -1 || idx >= state.images.length - 1) { return; }
            var tmp = state.images[idx + 1];
            state.images[idx + 1] = state.images[idx];
            state.images[idx] = tmp;
            renderImageList();
        });

        // Swap image
        $imageList.on('click', '.dit-ts-swap-img', function () {
            var id = parseInt($(this).attr('data-id'), 10);
            openSwapLibrary(id);
        });

        // Per-image zoom slider
        $imageList.on('input change', '.dit-ts-zoom-slider', function () {
            var id = parseInt($(this).attr('data-id'), 10);
            var val = parseFloat($(this).val()) || 1.0;
            var img = state.images.find(function (im) { return im.id === id; });
            if (img) { img.cropScale = val; }
            $(this).closest('.dit-ts-zoom-row').find('.dit-ts-zoom-val').text(val.toFixed(1) + 'x');
            triggerActivePreview();
        });

        // Generate button
        $generateBtn.on('click', function () {
            if (state.template === 'split_card') { exportAndSave(); }
            else { submitGridCollage(); }
        });

        // Logo
        $selectLogoBtn.on('click', openLogoLibrary);
        $clearLogoBtn.on('click', function () {
            state.logo = { id: null, url: null };
            $logoIdInput.val('');
            $logoPreview.empty();
            saveGlobalLogo(0);
            if (state.template === 'split_card') { debouncedPreview(); }
        });

        // ── Split Card controls ───────────────────────────────────────────

        function bindSplitRange($input, $display) {
            $input.on('input change', function () {
                $display.text($(this).val());
                if (state.template === 'split_card') { debouncedPreview(); }
            });
        }

        bindSplitRange($headingSizeInput, $headingSizeVal);
        bindSplitRange($bodySizeInput, $bodySizeVal);
        bindSplitRange($headingLHInput, $headingLHVal);
        bindSplitRange($bodyLHInput, $bodyLHVal);
        bindSplitRange($brandBarHInput, $brandBarHVal);
        bindSplitRange($logoSizeInput, $logoSizeVal);

        $headingInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        $bodyInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        $brandTextInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        $bodyBgInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        $brandBgInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });

        $mainFontSelect.on('change', function () {
            updateFontPreview();
            if (state.template === 'split_card') {
                loadFonts().then(function () { debouncedPreview(); });
            }
        });

        // @MODIFIED 2026-03-01 - New split card controls
        $headingBgInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        $bodyBgSplitInput.on('input', function () { if (state.template === 'split_card') { debouncedPreview(); } });
        bindSplitRange($brandFontSizeInput, $brandFontSizeVal);
        bindSplitRange($brandLetterSpacingInput, $brandLetterSpacingVal);
        bindSplitRange($watermarkOpacityInput, $watermarkOpacityVal);
        $brandTextAlignSelect.on('change', function () { if (state.template === 'split_card') { debouncedPreview(); } });

        // @MODIFIED 2026-03-01 - Drag-to-pan logic for canvas images
        var isPanning = false;
        var panStartX = 0, panStartY = 0;
        var panImageIdx = -1;
        var panInitCropX = 50, panInitCropY = 50;

        $canvas.on('mousedown', function (e) {
            if (!state.images.length || (state.template !== 'split_card' && state.template !== 'grid')) { return; }
            var rect = canvas.getBoundingClientRect();
            var mouseX = e.originalEvent.clientX - rect.left;
            var mouseY = e.originalEvent.clientY - rect.top;

            if (state.template === 'split_card') {
                var scaledY = mouseY / rect.height;
                // Only pan if clicking inside the image strip (top 55%)
                if (scaledY > TOP_STRIP_PERCENT) { return; }

                var scaledX = mouseX / rect.width;
                var imgCount = Math.min(state.images.length, MAX_SPLIT_IMAGES);
                panImageIdx = Math.min(Math.floor(scaledX * imgCount), imgCount - 1);
            } else if (state.template === 'grid') { // @MODIFIED 2026-03-01 - Support Grid Panning
                var canvasX = mouseX * (canvas.width / rect.width);
                var canvasY = mouseY * (canvas.height / rect.height);
                for (var i = 0; i < state.images.length; i++) {
                    var im = state.images[i];
                    if (im && im.gridRect) {
                        var gr = im.gridRect;
                        if (canvasX >= gr.x && canvasX <= gr.x + gr.w && canvasY >= gr.y && canvasY <= gr.y + gr.h) {
                            panImageIdx = i;
                            break;
                        }
                    }
                }
            }

            if (panImageIdx !== -1 && state.images[panImageIdx]) {
                isPanning = true;
                panStartX = e.originalEvent.clientX;
                panStartY = e.originalEvent.clientY;
                panInitCropX = state.images[panImageIdx].cropX || 50;
                panInitCropY = state.images[panImageIdx].cropY || 50;
                $canvas.css('cursor', 'grabbing');
            }
        });

        $(window).on('mousemove', function (e) {
            if (!isPanning || panImageIdx === -1) { return; }
            var dx = panStartX - e.originalEvent.clientX; // drag left -> shift image right (reduce cropX)
            var dy = panStartY - e.originalEvent.clientY;

            // Adjust crop parameters based on pixel delta. 
            // Modifying by ~0.15 gives a good panning feel.
            var newCropX = clamp(panInitCropX + (dx * 0.15), 0, 100);
            var newCropY = clamp(panInitCropY + (dy * 0.15), 0, 100);

            state.images[panImageIdx].cropX = newCropX;
            state.images[panImageIdx].cropY = newCropY;
            triggerActivePreview();
        });

        $(window).on('mouseup', function () {
            if (isPanning) {
                isPanning = false;
                panImageIdx = -1;
                $canvas.css('cursor', 'default');
            }
        });

        // @MODIFIED 2026-03-01 - Mouse wheel zoom on canvas (zooms image slot under cursor)
        $canvas.on('wheel', function (e) {
            e.preventDefault();
            if (!state.images.length || (state.template !== 'split_card' && state.template !== 'grid')) { return; }
            var rect = canvas.getBoundingClientRect();
            var mouseX = e.originalEvent.clientX - rect.left;
            var mouseY = e.originalEvent.clientY - rect.top;
            var hoverImageIdx = -1;

            if (state.template === 'split_card') {
                var scaledY = mouseY / rect.height;
                if (scaledY > TOP_STRIP_PERCENT) { return; }
                var scaledX = mouseX / rect.width;
                var imgCount = Math.min(state.images.length, MAX_SPLIT_IMAGES);
                hoverImageIdx = Math.min(Math.floor(scaledX * imgCount), imgCount - 1);
            } else if (state.template === 'grid') { // @MODIFIED 2026-03-01 - Support Grid Zooming
                var canvasX = mouseX * (canvas.width / rect.width);
                var canvasY = mouseY * (canvas.height / rect.height);
                for (var i = 0; i < state.images.length; i++) {
                    var im = state.images[i];
                    if (im && im.gridRect) {
                        var gr = im.gridRect;
                        if (canvasX >= gr.x && canvasX <= gr.x + gr.w && canvasY >= gr.y && canvasY <= gr.y + gr.h) {
                            hoverImageIdx = i;
                            break;
                        }
                    }
                }
            }

            var img = state.images[hoverImageIdx];
            if (!img) { return; }
            var delta = e.originalEvent.deltaY > 0 ? -0.1 : 0.1;
            img.cropScale = Math.round(clamp((img.cropScale || 1.0) + delta, 0.5, 3.0) * 10) / 10;
            // Update the matching zoom slider in image list
            $imageList.find('.dit-ts-zoom-slider[data-id="' + img.id + '"]').val(img.cropScale);
            $imageList.find('.dit-ts-zoom-slider[data-id="' + img.id + '"]')
                .closest('.dit-ts-zoom-row').find('.dit-ts-zoom-val').text(img.cropScale.toFixed(1) + 'x');
            triggerActivePreview();
        });

        $exportScaleSelect.on('change', function () { state.exportScale = parseInt($(this).val(), 10) || 2; });

        // ── Grid controls ─────────────────────────────────────────────────

        function bindGridRange($input, $display) {
            $input.on('input change', function () {
                $display.text($(this).val());
                if (state.template === 'grid') { debouncedGridPreview(); }
            });
        }

        bindGridRange($cornerRadiusInput, $cornerRadiusVal);
        bindGridRange($gridFontSizeInput, $gridFontSizeVal);
        bindGridRange($gridLineHeightInput, $gridLineHeightVal);

        // @MODIFIED 2026-03-01 - Letter spacing and blur also trigger grid canvas redraw
        bindGridRange($letterSpacingInput, $letterSpacingVal);
        bindGridRange($blurIntensityInput, $blurIntensityVal);

        $gridImageCountSelect.on('change', function () {
            populateGridLayouts(parseInt($(this).val(), 10) || 6);
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $gridLayoutSelect.on('change', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $aspectRatioSelect.on('change', function () {
            if ($(this).val() === 'custom') { $customDims.removeClass('hidden'); }
            else { $customDims.addClass('hidden'); }
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $customWidthInput.on('input change', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });
        $customHeightInput.on('input change', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $borderColorInput.on('input', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $gridBottomTextInput.on('input', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $gridFontSelect.on('change', function () {
            updateFontPreview();
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $textAlignSelect.on('change', function () {
            if (state.template === 'grid') { debouncedGridPreview(); }
        });

        $isRetinaCheck.on('change', function () {
            // Retina is export-only, no canvas change needed
        });
    }

    /**
     * @MODIFIED 2026-03-13 - Persist brand logo to global options
     */
    function saveGlobalLogo(id) {
        $.post(ditTsCollage.ajaxUrl, {
            action: 'dit_ts_save_brand_logo',
            nonce: ditTsCollage.nonce,
            logo_id: id
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────────────────

    function init() {
        populateFonts();
        populateGridLayouts(parseInt($gridImageCountSelect.val(), 10) || 6);
        updateTemplateState();
        
        // Load initial logo state if exists
        if (state.logo.id && state.logo.url) {
            $logoIdInput.val(state.logo.id);
            $logoPreview.html('<img src="' + escHtml(state.logo.url) + '" alt="Logo">');
        }

        bindEvents();

        // Pre-load fonts in background so first preview render is not delayed
        loadFonts();
    }

    $(document).ready(init);

}(jQuery));