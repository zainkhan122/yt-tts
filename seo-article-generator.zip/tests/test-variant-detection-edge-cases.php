<?php
/**
 * Comprehensive Edge Case & Boundary Condition Test: Variant Detection Fixes
 *
 * Test groups:
 * A: Linux extension detection (.snap, .flatpak, .pak)
 * B: Education/academic/home student variant normalization (normalize_variant_name)
 * C: ARM64/Apple Silicon architecture extraction (from extract_version_from_url)
 * D: Mac extension detection (.dmg, .pkg, .mac.pkg)
 * E: Variant normalization consistency (normalize_variant_name vs extract_variant_from_anchor_text_public)
 * F: Boundary conditions and cross-platform edge cases
 */

namespace {
    $base = dirname(__DIR__);

    if (!defined('ABSPATH')) define('ABSPATH', $base . '/');
    if (!defined('SEO_GEN_PLUGIN_DIR')) define('SEO_GEN_PLUGIN_DIR', $base . '/');
    if (!defined('SEO_GEN_PLUGIN_URL')) define('SEO_GEN_PLUGIN_URL', 'http://localhost/');
    if (!defined('SEO_GEN_VERSION')) define('SEO_GEN_VERSION', '2.30.0');
    if (!defined('WP_DEBUG')) define('WP_DEBUG', false);

    $mock_options = [
        'seo_gen_download_domain_denylist' => "prf.hn\nawin1.com",
        'seo_gen_download_allowlist' => '',
    ];

    if (!function_exists('get_option')) {
        function get_option($option, $default = false) { global $mock_options; return $mock_options[$option] ?? $default; }
    }
    if (!function_exists('wp_parse_url')) { function wp_parse_url($url, $c = -1) { return parse_url($url, $c); } }
    if (!function_exists('wp_parse_str')) { function wp_parse_str($s, &$r) { parse_str($s, $r); } }
    if (!function_exists('sanitize_text_field')) { function sanitize_text_field($s) { return trim(strip_tags(stripslashes($s))); } }
    if (!function_exists('wp_strip_all_tags')) {
        function wp_strip_all_tags($string, $remove_breaks = false) {
            $string = preg_replace('@<(script|style)[^>]*?>.*?</\\1>@si', '', $string);
            $string = strip_tags($string);
            return trim($string);
        }
    }
    if (!function_exists('__')) { function __($t, $d='default') { return $t; } }
    if (!function_exists('esc_attr')) { function esc_attr($t) { return htmlspecialchars($t, ENT_QUOTES, 'UTF-8'); } }

    require_once $base . '/includes/class-option-registry.php';
    require_once $base . '/includes/generator/class-download-link-helper.php';

    $DLH = '\SEO_Article_Generator\Generator\Download_Link_Helper';

    $passed = 0;
    $failed = 0;
    $group = '';

    function assert_eq($label, $expected, $actual) {
        global $passed, $failed, $group;
        $status = ($expected === $actual) ? 'PASS' : 'FAIL';
        if ($status === 'FAIL') {
            $expected_str = var_export($expected, true);
            $actual_str = var_export($actual, true);
            echo "  {$status}: {$group} / {$label} — expected={$expected_str}, got={$actual_str}\n";
            $failed++;
        } else {
            echo "  {$status}: {$group} / {$label}\n";
            $passed++;
        }
    }

    // ─────────────────────────────────────────────
    echo "=== VARIANT DETECTION — COMPREHENSIVE EDGE CASE TEST ===\n\n";

    // ═════════════════════════════════════════════
    // GROUP A: Linux Extension Detection
    // ═════════════════════════════════════════════
    $group = 'A: Linux Extensions';
    echo "--- {$group} ---\n";

    // A1: .snap detection
    assert_eq('.snap basic', 'Linux', $DLH::infer_platform_from_url('https://example.com/software.snap'));
    assert_eq('.snap with query', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.snap?v=2'));
    assert_eq('.snap mixed case', 'Linux', $DLH::infer_platform_from_url('https://example.com/App.SnAp'));

    // A2: .flatpak detection
    assert_eq('.flatpak basic', 'Linux', $DLH::infer_platform_from_url('https://example.com/software.flatpak'));
    assert_eq('.flatpak with query', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.flatpak?ref=latest'));

    // A3: .pak detection
    assert_eq('.pak basic', 'Linux', $DLH::infer_platform_from_url('https://example.com/software.pak'));
    assert_eq('.pak with query', 'Linux', $DLH::infer_platform_from_url('https://example.com/game.pak?dlc=1'));

    // A4: Existing Linux extensions still work (regression)
    assert_eq('.deb still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.deb'));
    assert_eq('.rpm still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.rpm'));
    assert_eq('.appimage still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.AppImage'));
    assert_eq('.tar.gz still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.tar.gz'));
    assert_eq('.tgz still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.tgz'));
    assert_eq('.tar.xz still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.tar.xz'));
    assert_eq('.tar.bz2 still works', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.tar.bz2'));

    echo "\n";

    // ═════════════════════════════════════════════
    // GROUP B: Education/Academic Variant Normalization
    // ═════════════════════════════════════════════
    $group = 'B: Education Variants';
    echo "--- {$group} ---\n";

    // B1: normalize_variant_name — education variants
    assert_eq('nvn: education', 'Education', $DLH::normalize_variant_name('education'));
    assert_eq('nvn: Education', 'Education', $DLH::normalize_variant_name('Education'));
    assert_eq('nvn: EDUCATION', 'Education', $DLH::normalize_variant_name('EDUCATION'));
    assert_eq('nvn: educational', 'Education', $DLH::normalize_variant_name('educational'));
    assert_eq('nvn: Educational', 'Education', $DLH::normalize_variant_name('Educational'));
    assert_eq('nvn: academic', 'Academic', $DLH::normalize_variant_name('academic'));
    assert_eq('nvn: Academic', 'Academic', $DLH::normalize_variant_name('Academic'));
    assert_eq('nvn: home student', 'Home Student', $DLH::normalize_variant_name('home student'));
    assert_eq('nvn: Home Student', 'Home Student', $DLH::normalize_variant_name('Home Student'));
    assert_eq('nvn: student', 'Student', $DLH::normalize_variant_name('student'));
    assert_eq('nvn: Student', 'Student', $DLH::normalize_variant_name('Student'));
    assert_eq('nvn: personal', 'Personal', $DLH::normalize_variant_name('personal'));
    assert_eq('nvn: Personal', 'Personal', $DLH::normalize_variant_name('Personal'));
    assert_eq('nvn: starter', 'Starter', $DLH::normalize_variant_name('starter'));
    assert_eq('nvn: Starter', 'Starter', $DLH::normalize_variant_name('Starter'));
    assert_eq('nvn: basic edition', 'Basic', $DLH::normalize_variant_name('basic edition'));
    assert_eq('nvn: free edition', 'Free', $DLH::normalize_variant_name('free edition'));
    assert_eq('nvn: home edition', 'Home', $DLH::normalize_variant_name('home edition'));

    // B2: Caps variants
    assert_eq('nvn: EDUCATION CAPS', 'Education', $DLH::normalize_variant_name('EDUCATION'));
    assert_eq('nvn: EDUCATIONAL CAPS', 'Education', $DLH::normalize_variant_name('EDUCATIONAL'));
    assert_eq('nvn: ACADEMIC CAPS', 'Academic', $DLH::normalize_variant_name('ACADEMIC'));
    assert_eq('nvn: HOME STUDENT CAPS', 'Home Student', $DLH::normalize_variant_name('HOME STUDENT'));
    assert_eq('nvn: STUDENT CAPS', 'Student', $DLH::normalize_variant_name('STUDENT'));
    assert_eq('nvn: PERSONAL CAPS', 'Personal', $DLH::normalize_variant_name('PERSONAL'));
    assert_eq('nvn: STARTER CAPS', 'Starter', $DLH::normalize_variant_name('STARTER'));

    echo "\n";

    // ═════════════════════════════════════════════
    // GROUP C: ARM64 / Apple Silicon Architecture Extraction
    // Uses extract_version_from_url() which returns composite "edition arch version" strings.
    // For architecture-only URLs, the result IS the architecture token.
    // ═════════════════════════════════════════════
    $group = 'C: ARM64 / Apple Silicon';
    echo "--- {$group} ---\n";

    // C1: ARM64 patterns via extract_version_from_url
    assert_eq('arch: arm64 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-arm64.dmg'));
    assert_eq('arch: aarch64 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-aarch64.dmg'));
    assert_eq('arch: apple silicon filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-apple-silicon.dmg'));
    assert_eq('arch: m1 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m1.dmg'));
    assert_eq('arch: m2 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m2.dmg'));
    assert_eq('arch: m3 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m3.dmg'));
    assert_eq('arch: m4 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m4.dmg'));
    assert_eq('arch: macarm64 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-macarm64.dmg'));
    assert_eq('arch: mac.arm64 filename', 'ARM64', $DLH::extract_version_from_url('https://example.com/app.mac.arm64.dmg'));
    // Note: standalone "silicon" is not detected — only "apple silicon" is in arch_map

    // C2: Intel x64 patterns
    assert_eq('arch: x64 filename', 'x64', $DLH::extract_version_from_url('https://example.com/app-x64.exe'));
    assert_eq('arch: amd64 filename', 'x64', $DLH::extract_version_from_url('https://example.com/app-amd64.exe'));
    assert_eq('arch: x86_64 filename', 'x64', $DLH::extract_version_from_url('https://example.com/app-x86_64.exe'));
    assert_eq('arch: 64bit filename', 'x64', $DLH::extract_version_from_url('https://example.com/app-64bit.exe'));
    assert_eq('arch: 64-bit filename', 'x64', $DLH::extract_version_from_url('https://example.com/app-64-bit.exe'));
    assert_eq('arch: intel filename', 'Intel', $DLH::extract_version_from_url('https://example.com/app-intel.dmg'));

    // C3: x32 patterns
    assert_eq('arch: x86 filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-x86.exe'));
    assert_eq('arch: 32bit filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-32bit.exe'));
    assert_eq('arch: 32-bit filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-32-bit.exe'));
    assert_eq('arch: i686 filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-i686.exe'));
    assert_eq('arch: i386 filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-i386.exe'));
    assert_eq('arch: win32 filename', 'x32', $DLH::extract_version_from_url('https://example.com/app-win32.exe'));

    // C4: ARM (non-64) detection
    assert_eq('arch: arm filename', 'ARM', $DLH::extract_version_from_url('https://example.com/app-arm.exe'));

    // C5: Universal detection
    assert_eq('arch: universal filename', 'Universal', $DLH::extract_version_from_url('https://example.com/app-universal.dmg'));

    // C6: Portable detection
    assert_eq('arch: portable filename', 'Portable', $DLH::extract_version_from_url('https://example.com/app-portable.exe'));

    echo "\n";

    // ═════════════════════════════════════════════
    // GROUP D: Mac Extension Detection
    // ═════════════════════════════════════════════
    $group = 'D: Mac Extensions';
    echo "--- {$group} ---\n";

    // D1: .dmg detection
    assert_eq('.dmg returns macOS', 'macOS', $DLH::infer_platform_from_url('https://cdn.example.org/firefox.dmg'));
    assert_eq('.dmg mixed case', 'macOS', $DLH::infer_platform_from_url('https://example.com/App.Dmg'));
    assert_eq('.dmg uppercase', 'macOS', $DLH::infer_platform_from_url('https://example.com/app.DMG'));

    // D2: .pkg detection
    assert_eq('.pkg returns macOS', 'macOS', $DLH::infer_platform_from_url('https://cdn.example.org/firefox.pkg'));
    assert_eq('.pkg mixed case', 'macOS', $DLH::infer_platform_from_url('https://example.com/App.Pkg'));
    assert_eq('.pkg uppercase', 'macOS', $DLH::infer_platform_from_url('https://example.com/app.PKG'));

    // D3: Firefox-style .mac.pkg detection
    assert_eq('.mac.pkg -> macOS', 'macOS', $DLH::infer_platform_from_url('https://cdn.mozilla.org/firefox.mac.pkg'));
    // Verify Intel architecture is also detected from .mac.pkg
    assert_eq('.mac.pkg -> Intel', 'Intel', $DLH::extract_version_from_url('https://cdn.mozilla.org/firefox.mac.pkg'));

    // D4: macOS detection does NOT match Windows .msi/.exe
    assert_eq('.exe is not macOS', 'Windows', $DLH::infer_platform_from_url('https://example.com/app.exe'));
    assert_eq('.msi is not macOS', 'Windows', $DLH::infer_platform_from_url('https://example.com/app.msi'));
    assert_eq('.appx is not macOS', 'Windows', $DLH::infer_platform_from_url('https://example.com/app.appx'));

    // D5: macOS detection does NOT match Linux extensions
    assert_eq('.deb is not macOS', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.deb'));
    assert_eq('.rpm is not macOS', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.rpm'));

    echo "\n";

    // ═════════════════════════════════════════════
    // GROUP E: Normalization Consistency
    // normalize_variant_name vs extract_variant_from_anchor_text_public
    // (the latter internally calls normalize_variant_label)
    // ═════════════════════════════════════════════
    $group = 'E: Normalization Consistency';
    echo "--- {$group} ---\n";

    // E1: Education variants — normalize_variant_name vs anchor extraction
    $education_inputs = [
        'Education' => 'Education',
        'Educational' => 'Education',
        'Academic' => 'Academic',
        'Home Student' => 'Home Student',
        'Student' => 'Student',
        'Personal' => 'Personal',
        'Starter' => 'Starter',
    ];
    foreach ($education_inputs as $input => $expected) {
        $nvn = $DLH::normalize_variant_name($input);
        // extract_variant_from_anchor_text_public strips "download" and common words,
        // then calls normalize_variant_label which should produce canonical form
        $extracted = $DLH::extract_variant_from_anchor_text_public($input, '', '');
        // The anchor extractor should produce the expected canonical label
        assert_eq("anchor({$input})={$expected}", $expected, $extracted);
        // normalize_variant_name should also produce the same canonical form
        assert_eq("nvn({$input})={$expected}", $expected, $nvn);
    }

    // E2: Architecture variants — normalize_variant_name consistency
    $arch_inputs = [
        '64-bit' => 'x64',
        'x64' => 'x64',
        'amd64' => 'x64',
        'win64' => 'x64',
        'x86_64' => 'x64',
        '32-bit' => 'x32',
        'x86' => 'x32',
        'win32' => 'x32',
        'i686' => 'x32',
        'i386' => 'x32',
        'arm64' => 'ARM64',
        'aarch64' => 'ARM64',
        'arm' => 'ARM',
        'intel' => 'Intel',
        'mac' => 'Intel',
        'universal' => 'Universal',
    ];
    foreach ($arch_inputs as $input => $expected) {
        $nvn = $DLH::normalize_variant_name($input);
        assert_eq("arch nvn({$input})={$expected}", $expected, $nvn);
    }

    // E3: Edition variants — anchor text extraction consistency
    $edition_inputs = [
        'Pro' => 'Pro',
        'Enterprise' => 'Enterprise',
        'Community' => 'Community',
        'Lite' => 'Lite',
        'Beta' => 'Beta',
        'Nightly' => 'Nightly',
        'Stable' => 'Stable',
        'Business' => 'Business',
        'Education' => 'Education',
    ];
    foreach ($edition_inputs as $input => $expected) {
        $extracted = $DLH::extract_variant_from_anchor_text_public($input, '', '');
        assert_eq("edition anchor({$input})={$expected}", $expected, $extracted);
    }

    echo "\n";

    // ═════════════════════════════════════════════
    // GROUP F: Boundary Conditions & Cross-Platform
    // ═════════════════════════════════════════════
    $group = 'F: Boundary Conditions';
    echo "--- {$group} ---\n";

    // F1: Empty and invalid inputs
    assert_eq('empty variant nvn', 'Standard', $DLH::normalize_variant_name(''));
    assert_eq('whitespace variant nvn', 'Standard', $DLH::normalize_variant_name('   '));
    assert_eq('empty variant anchor', '', $DLH::extract_variant_from_anchor_text_public('', '', ''));
    assert_eq('empty URL platform', '', $DLH::infer_platform_from_url(''));

    // F2: URL without extension
    assert_eq('url no extension', '', $DLH::infer_platform_from_url('https://example.com/download'));

    // F3: Linux extensions with query strings
    assert_eq('.snap with query', 'Linux', $DLH::infer_platform_from_url('https://example.com/firefox.snap?v=138'));
    assert_eq('.flatpak with long query', 'Linux', $DLH::infer_platform_from_url('https://example.com/app.flatpak?channel=stable&arch=x86_64'));

    // F4: Firefox nightmare — .mac.pkg extension + Intel arch
    $ff_url = 'https://cdn.mozilla.org/firefox-139.0a1.mac.pkg';
    assert_eq('firefox .mac.pkg -> macOS', 'macOS', $DLH::infer_platform_from_url($ff_url));
    assert_eq('firefox .mac.pkg -> Intel', 'Intel', $DLH::extract_version_from_url($ff_url));

    // F5: Architecture priority — arm64 beats generic 64
    assert_eq('arm64 priority over 64', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-arm64-64bit.dmg'));

    // F6: Edition keyword "edition" stripped from anchor text
    assert_eq('anchor "Business Edition" -> Business', 'Business', $DLH::extract_variant_from_anchor_text_public('Business Edition', '', ''));
    assert_eq('anchor "Education Edition" -> Education', 'Education', $DLH::extract_variant_from_anchor_text_public('Education Edition', '', ''));
    assert_eq('anchor "Free Edition" -> Free', 'Free', $DLH::extract_variant_from_anchor_text_public('Free Edition', '', ''));

    // F7: Duplicate variant dedup in anchor extraction
    assert_eq('anchor "Home Home" -> Home', 'Home', $DLH::extract_variant_from_anchor_text_public('Home Home', '', ''));
    assert_eq('anchor "Student Student" -> Student', 'Student', $DLH::extract_variant_from_anchor_text_public('Student Student', '', ''));

    // F8: macOS M1/M2/M3/M4 in URL
    assert_eq('M1 -> ARM64', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m1.dmg'));
    assert_eq('M2 -> ARM64', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m2.dmg'));
    assert_eq('M3 -> ARM64', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m3.dmg'));
    assert_eq('M4 -> ARM64', 'ARM64', $DLH::extract_version_from_url('https://example.com/app-m4.dmg'));

    // F9: Platform cross-contamination checks (must not leak)
    $snap_result = $DLH::infer_platform_from_url('https://example.com/app.snap');
    $flatpak_result = $DLH::infer_platform_from_url('https://example.com/app.flatpak');
    assert_eq('Linux .snap not Windows', true, $snap_result === 'Linux');
    assert_eq('Linux .flatpak not Windows', true, $flatpak_result === 'Linux');
    assert_eq('macOS .dmg not Linux', true, $DLH::infer_platform_from_url('https://example.com/app.dmg') === 'macOS');
    assert_eq('macOS .pkg not Linux', true, $DLH::infer_platform_from_url('https://example.com/app.pkg') === 'macOS');
    assert_eq('Windows .exe not macOS', true, $DLH::infer_platform_from_url('https://example.com/app.exe') === 'Windows');
    assert_eq('Android .apk not Linux', true, $DLH::infer_platform_from_url('https://example.com/app.apk') === 'Android');

    // F10: Anchor text with platform name stripped
    assert_eq('anchor "Download Education for Windows" -> Education', 'Education', $DLH::extract_variant_from_anchor_text_public('Download Education for Windows', '', 'Windows'));

    // F11: Existing architecture patterns still work after ARM64 additions
    assert_eq('x64 regression', 'x64', $DLH::normalize_variant_name('x64'));
    assert_eq('x32 regression', 'x32', $DLH::normalize_variant_name('x86'));
    assert_eq('ARM64 regression', 'ARM64', $DLH::normalize_variant_name('arm64'));
    assert_eq('ARM regression', 'ARM', $DLH::normalize_variant_name('arm'));
    assert_eq('Intel regression', 'Intel', $DLH::normalize_variant_name('intel'));
    assert_eq('mac -> Intel regression', 'Intel', $DLH::normalize_variant_name('mac'));

    // F12: Existing edition patterns still work after education additions
    assert_eq('Pro regression', 'Pro', $DLH::normalize_variant_name('pro'));
    assert_eq('Enterprise regression', 'Enterprise', $DLH::normalize_variant_name('enterprise'));
    assert_eq('LTS regression', 'LTS', $DLH::normalize_variant_name('lts'));
    assert_eq('ESR regression', 'ESR', $DLH::normalize_variant_name('esr'));
    assert_eq('Nightly regression', 'Nightly', $DLH::normalize_variant_name('nightly'));

    echo "\n";

    // ═════════════════════════════════════════════
    // SUMMARY
    // ═════════════════════════════════════════════
    echo "══════════════════════════════════════════════════════\n";
    echo "RESULTS: {$passed} PASSED, {$failed} FAILED\n";
    echo "══════════════════════════════════════════════════════\n";

    if ($failed > 0) {
        echo "SOME TESTS FAILED — REVIEW OUTPUT ABOVE.\n";
        exit(1);
    } else {
        echo "ALL EDGE CASE TESTS PASSED.\n";
        exit(0);
    }
}
