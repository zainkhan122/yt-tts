<?php

namespace SEO_Article_Generator\Tests\Fakes;

/**
 * Mock Link Finder for testing
 */
class Mock_Link_Finder extends \SEO_Article_Generator\Links\Link_Finder
{
    private $links = array();

    public function __construct($links = array())
    {
        $this->links = $links;
    }

    public function find_related($software_name, $category, $limit = 3)
    {
        return array_slice($this->links, 0, $limit);
    }
}
