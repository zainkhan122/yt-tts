<?php

/**
 * Threshold Config
 *
 * Single source of truth for all validation and scoring thresholds.
 * Both Validator and Scoring_Engine consume this configuration.
 *
 * @package SEO_Article_Generator
 * @since   1.9.0
 * @MODIFIED 2025-12-12 v1.9.0: New unified threshold configuration class
 * @MODIFIED 2025-12-12 v1.9.3: Scoring realignment for download-intent UX
 */

namespace SEO_Article_Generator\Validation;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Unified threshold configuration for validation and scoring
 */
class Threshold_Config
{
    /**
     * Get all thresholds for the specified mode
     *
     * @param string|null $mode Mode override (retained for API compatibility; value is ignored)
     * @return array Complete threshold configuration
     */
	public static function get($mode = null)
	{
		$mode = $mode ?? 'blog';

		$base_threshold = (int) get_option('seo_gen_validation_threshold', 75);
		$active_threshold = max(40, $base_threshold - 10);

        return array(
            // SCORING: Mode threshold for pass/fail
            // @MODIFIED 2026-01-05: Pulled from plugin settings
            'mode_threshold' => $active_threshold,

            // UNIQUENESS (0-100 score)
            // @MODIFIED 2026-01-05: Aligned with mode threshold
            'uniqueness' => array(
                'pass_threshold' => $active_threshold,
                'warning_threshold' => min(90, $active_threshold + 5),
            ),

            // META DESCRIPTION (8 pts max)
            'meta_description' => array(
                'full_min' => 150,
                'full_max' => 160,
                'partial_min' => 120,
                'partial_max' => 149,
                'low_min' => 100,
                'low_max' => 119,
                'error_above' => 160,
                'warning_below' => 150,
                'pts_full' => 8,
                'pts_partial' => 5,
                'pts_low' => 2,
            ),

            // KEYWORD DENSITY (6 pts max)
            // @MODIFIED v1.9.3: Reduced from 8 pts (SEO fluff rebalance)
            // @MODIFIED 2026-01-03 v2.13.0: Never block on density, only warn and affect scoring
            'keyword_density' => array(
                'full_min' => 1.0,
                'full_max' => 3.0,
                'partial_min' => 0.7,
                'partial_max' => 3.5,
                'low_min' => 0.5,
                'low_max' => 4.0,
                'warning_low' => 0.5,   // Warn only if extremely low
                'warning_high' => 4.0,  // Warn only if approaching spam
                'error_above' => PHP_FLOAT_MAX,  // Never block, only warn and score
                'pts_full' => 6,
                'pts_partial' => 4,
                'pts_low' => 1,
            ),

            // INTERNAL LINKS (6 pts max)
            // @MODIFIED v1.9.3: Reduced from 10 pts (users don't care about site architecture on download pages)
            // INTERNAL LINKS (0 pts - DEPRECATED)
            // @MODIFIED v2.7.6: Scored as 0 (deprecated feature)
            'internal_links' => array(
                'full_count' => 3,
                'partial_count' => 2,
                'low_count' => 1,
                'error_below' => 0,
                'warning_below' => 0,
                'pts_full' => 0,
                'pts_partial' => 0,
                'pts_low' => 0,
            ),

            // FEATURES (5 pts max)
            // @MODIFIED v1.9.2: Aligned with prompt "1-7 features ONLY if documented, fewer is better"
            'features' => array(
                'full_count' => 3,      // Was 5: 3 solid sourced features = full credit
                'partial_count' => 2,   // Was 3
                'low_count' => 1,
                'error_below' => 1,
		'warning_below' => 2, // Was 5/3: align with new full threshold
                'pts_full' => 5,
                'pts_partial' => 3,
                'pts_low' => 1,
            ),

            // FAQS (5 pts max)
            'faqs' => array(
                'full_count' => 3,
                'partial_count' => 1,
		'error_below' => 0,
		'warning_below' => 2,
                'pts_full' => 5,
                'pts_partial' => 2,
            ),

            // MOAT (quality + count gated separately; quality scored via validate_moat_quality, no pts here)
			'moat' => array(
				'full_count'   => 3,
				'max_count'    => 3,
		'min_count' => 0,
				'warning_below' => 1,
				'error_below'   => 0,
			),

            // CONTENT LENGTH (6 pts max)
            // @MODIFIED v1.9.2: Flattened curve - "short and honest beats long and vague"
            'content_length' => array(
                'full_min' => 600,      // Was 800: honest 650-word review gets full credit
                'full_max' => 1400,     // Was 1200: broader tolerance
                'partial_min' => 500,   // Was 600
                'partial_max' => 1600,  // Was 1400
                // Low tier removed: binary acceptable vs bloated
		'error_below' => 0,
                'score_loss_above' => 1600,  // Updated from 1500 to match partial_max
		'warning_above' => PHP_INT_MAX,
                'pts_full' => 6,
                'pts_partial' => 4,
                // pts_low removed: no low tier
            ),

            // INSTALLATION STEPS (10 pts max)
            // @MODIFIED v2.7.7: Increased from 8 pts (core download-intent UX)
            // @MODIFIED v1.9.3: Lite now requires at least 1 step (error_below: 0→1)
            'installation_steps' => array(
                'full_count' => 3,
                'partial_count' => 1,
		'error_below' => 1,
                'pts_full' => 10,
                'pts_partial' => 6,
            ),

            // EDITOR RATING (3 pts max)
            // @MODIFIED v1.9.3: Reduced from 5 pts (weak signal, easily gamed)
            'editor_rating' => array(
                'pts_max' => 3,
            ),

            // TITLE LENGTH (informational, no points)
            'title' => array(
                'optimal_min' => 50,
                'optimal_max' => 60,
                'warning_min' => 30,
                'warning_max' => 60,
            ),

            // FAQ KEYWORD OVERUSE
            'faq_keyword_max' => 3,

            // SENTENCE LENGTH
            'sentence_max_words' => 40,
        );
    }

    /**
     * Calculate points earned for a given metric value
     * @MODIFIED v1.9.1: Simplified to single code path (count-based vs range-based)
     *
     * @param string $metric Metric name (e.g., 'meta_description', 'keyword_density')
     * @param mixed  $value  Current value to evaluate
     * @param string $mode   Mode override (required for consistency)
     * @return int Points earned
     */
    public static function calculate_points($metric, $value, $mode = null)
    {
        $cfg = self::get($mode)[$metric] ?? null;
        if (!$cfg || !isset($cfg['pts_full'])) {
            return 0;
        }

        // COUNT-BASED: features, faqs, internal_links, installation_steps
        if (isset($cfg['full_count'])) {
            if ($value >= $cfg['full_count']) {
                return $cfg['pts_full'];
            }
            if (isset($cfg['partial_count']) && $value >= $cfg['partial_count']) {
                return $cfg['pts_partial'] ?? 0;
            }
            if (isset($cfg['low_count']) && $value >= $cfg['low_count']) {
                return $cfg['pts_low'] ?? 0;
            }
            return 0;
        }

        // RANGE-BASED: meta_description, content_length, keyword_density
        // All range metrics use full_min/full_max structure
        if (isset($cfg['full_min']) && isset($cfg['full_max'])) {
            // Full tier
            if ($value >= $cfg['full_min'] && $value <= $cfg['full_max']) {
                return $cfg['pts_full'];
            }
            // Partial tier
            if (isset($cfg['partial_min']) && isset($cfg['partial_max'])) {
                if ($value >= $cfg['partial_min'] && $value <= $cfg['partial_max']) {
                    return $cfg['pts_partial'] ?? 0;
                }
            }
            // Low tier
            if (isset($cfg['low_min']) && isset($cfg['low_max'])) {
                if ($value >= $cfg['low_min'] && $value <= $cfg['low_max']) {
                    return $cfg['pts_low'] ?? 0;
                }
            }
            // Outside all tiers = 0 points
            return 0;
        }

        return 0;
    }

    /**
     * Get lost points for a given metric value (full points - earned points)
     *
     * @param string $metric Metric name
     * @param mixed  $value  Current value
     * @param string $mode   Optional mode override
     * @return int Points lost
     */
    public static function get_lost_points($metric, $value, $mode = null)
    {
        $cfg = self::get($mode)[$metric] ?? null;
        if (!$cfg || !isset($cfg['pts_full'])) {
            return 0;
        }

        $earned = self::calculate_points($metric, $value, $mode);
        return $cfg['pts_full'] - $earned;
    }

    /**
     * Get legacy mode requirements (backward compatibility)
     *
     * @param string|null $mode Mode override
     * @return array Array with min_features, min_faqs, require_installation
     */
    public static function get_mode_requirements($mode = null)
    {
        $config = self::get($mode);
        return array(
            'min_features' => $config['features']['warning_below'],
            'min_faqs' => $config['faqs']['warning_below'],
            'require_installation' => $config['installation_steps']['error_below'] > 0,
        );
    }

    /**
     * Get mode pass threshold (backward compatibility)
     *
     * @param string|null $mode Mode override
     * @return int Threshold score (0-100)
     */
    public static function get_mode_threshold($mode = null)
    {
        return self::get($mode)['mode_threshold'];
    }
}
