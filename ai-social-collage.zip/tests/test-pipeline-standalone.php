<?php
/**
 * AI Social Collage — Standalone Pipeline Integration Test
 *
 * Runs WITHOUT WordPress. Mocks WP functions, loads plugin classes directly.
 * Tests the NEW buffer stats caching + API error parsing + quota + cooldown logic.
 *
 * Run:  php tests/test-pipeline-standalone.php
 */

// ═══════════════════════════════════════════════════════════════════════════
//  WORDPRESS FUNCTION STUBS
// ═══════════════════════════════════════════════════════════════════════════

$wp_options   = [];
$wp_transients = [];

// Mock $wpdb for Logger
$wpdb = new class {
    public $prefix = 'wp_';
    public function get_var( $q ) { return null; }
    public function insert( $t, $d, $f = [] ) { return true; }
    public function update( $t, $d, $w, $f = [], $fw = [] ) { return true; }
    public function prepare( $q, ...$a ) { return $q; }
    public function query( $q ) { return 0; }
    public function get_row( $q ) { return null; }
    public function get_results( $q ) { return []; }
    public function esc_like( $s ) { return $s; }
};
global $wpdb;

if ( ! defined( 'ABSPATH' ) )       define( 'ABSPATH', __DIR__ . '/../' );
if ( ! defined( 'HOUR_IN_SECONDS' ) ) define( 'HOUR_IN_SECONDS', 3600 );
if ( ! defined( 'MINUTE_IN_SECONDS' ) ) define( 'MINUTE_IN_SECONDS', 60 );

function get_option( $key, $default = false ) {
    global $wp_options;
    return array_key_exists( $key, $wp_options ) ? $wp_options[ $key ] : $default;
}

function update_option( $key, $value, $autoload = true ) {
    global $wp_options;
    $wp_options[ $key ] = $value;
    return true;
}

function delete_option( $key ) {
    global $wp_options;
    unset( $wp_options[ $key ] );
    return true;
}

function add_option( $key, $value = '', $autoload = 'yes' ) {
    global $wp_options;
    if ( ! array_key_exists( $key, $wp_options ) ) {
        $wp_options[ $key ] = $value;
    }
}

function get_transient( $key ) {
    global $wp_transients;
    if ( ! isset( $wp_transients[ $key ] ) ) {
        return false;
    }
    $entry = $wp_transients[ $key ];
    if ( $entry['expires'] > 0 && $entry['expires'] < time() ) {
        unset( $wp_transients[ $key ] );
        return false;
    }
    return $entry['value'];
}

function set_transient( $key, $value, $expiration = 0 ) {
    global $wp_transients;
    $wp_transients[ $key ] = [
        'value'   => $value,
        'expires' => $expiration > 0 ? time() + $expiration : 0,
    ];
}

function delete_transient( $key ) {
    global $wp_transients;
    unset( $wp_transients[ $key ] );
}

function sanitize_text_field( $str ) { return is_string( $str ) ? strip_tags( $str ) : $str; }
function sanitize_key( $str ) { return preg_replace( '/[^a-zA-Z0-9_\-]/', '', strtolower( (string) $str ) ); }
function sanitize_textarea_field( $str ) { return sanitize_text_field( $str ); }
function wp_unslash( $value ) { return is_string( $value ) ? stripslashes( $value ) : $value; }
function wp_json_encode( $data, $options = 0 ) { return json_encode( $data, $options ); }
function wp_strip_all_tags( $str ) { return strip_tags( $str ); }
function maybe_serialize( $data ) { return is_string( $data ) ? $data : serialize( $data ); }

class WP_Error {
    private $code, $message;
    public function __construct( $code = '', $message = '' ) { $this->code = $code; $this->message = $message; }
    public function get_error_message() { return $this->message; }
}

// ═══════════════════════════════════════════════════════════════════════════
//  TEST HARNESS
// ═══════════════════════════════════════════════════════════════════════════

$passed = 0;
$failed = 0;
$errors = [];

function test_assert( string $name, bool $condition, string $detail = '' ) {
    global $passed, $failed, $errors;
    if ( $condition ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $msg = "  FAIL  {$name}";
        if ( $detail ) $msg .= " — {$detail}";
        $errors[] = $msg;
        echo "{$msg}\n";
    }
}

function section( string $title ) {
    echo "\n══════════════════════════════════════════════════════════════\n";
    echo "  {$title}\n";
    echo "══════════════════════════════════════════════════════════════\n";
}

// ═══════════════════════════════════════════════════════════════════════════
//  LOAD PLUGIN CLASSES
// ═══════════════════════════════════════════════════════════════════════════

$base = __DIR__ . '/../core/';

require_once $base . 'Config.php';
require_once $base . 'Logger.php';
require_once $base . 'Services/APIErrorInfo.php';
require_once $base . 'Services/APIErrorParser.php';
require_once $base . 'Services/QuotaStateManager.php';
require_once $base . 'Services/ProviderCooldown.php';
require_once $base . 'Services/BufferIntegration.php';
require_once $base . 'Database/ApiCallManager.php';

use AiSocialCollage\Config;
use AiSocialCollage\Services\APIErrorParser;
use AiSocialCollage\Services\APIErrorInfo;
use AiSocialCollage\Services\QuotaStateManager;
use AiSocialCollage\Services\ProviderCooldown;
use AiSocialCollage\Services\BufferIntegration;

// ═══════════════════════════════════════════════════════════════════════════
//  1. BUFFER STATS CACHING (wp_options-based)
// ═══════════════════════════════════════════════════════════════════════════

section( '1. BUFFER STATS CACHING (wp_options)' );

test_assert(
    'OPTION_BUFFER_STATS_CACHE constant defined',
    defined( 'AiSocialCollage\Config::OPTION_BUFFER_STATS_CACHE' )
);

test_assert(
    'ACTION_REFRESH_BUFFER_STATS constant defined',
    defined( 'AiSocialCollage\Config::ACTION_REFRESH_BUFFER_STATS' )
);

// Write cache
$test_data = [
    'draft_count'     => 42,
    'daily_limit'     => 10,
    'draft_retention' => 7,
    'fetched_at'      => time(),
];
update_option( Config::OPTION_BUFFER_STATS_CACHE, $test_data );

$cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert(
    'Cache write → draft_count=42',
    ( $cache['draft_count'] ?? 0 ) === 42
);
test_assert(
    'Cache write → daily_limit=10',
    ( $cache['daily_limit'] ?? 0 ) === 10
);
test_assert(
    'Cache write → fetched_at is set',
    isset( $cache['fetched_at'] ) && $cache['fetched_at'] > 0
);

// Empty cache defaults
delete_option( Config::OPTION_BUFFER_STATS_CACHE );
$empty = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert(
    'Empty cache → draft_count defaults to 0',
    (int) ( $empty['draft_count'] ?? 0 ) === 0
);
test_assert(
    'Empty cache → daily_limit defaults to 5',
    (int) ( $empty['daily_limit'] ?? 5 ) === 5
);
test_assert(
    'Empty cache → retention defaults to Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS',
    (int) ( $empty['draft_retention'] ?? Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS ) === Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS
);

// ═══════════════════════════════════════════════════════════════════════════
//  2. API ERROR PARSING — ALL ERROR TYPES
// ═══════════════════════════════════════════════════════════════════════════

section( '2. API ERROR PARSING' );

// 2a. Gemini 429 RPD
$body = json_encode( [
    'error' => [
        'status' => 'RESOURCE_EXHAUSTED',
        'message' => 'Quota exceeded',
        'details' => [
            [
                '@type' => 'type.googleapis.com/google.rpc.QuotaFailure',
                'violations' => [[
                    'quotaId'      => 'RequestsPerDayPerProject',
                    'quotaMetric'  => 'generativelanguage.googleapis.com/requests_per_day',
                ]],
            ],
            [
                '@type' => 'type.googleapis.com/google.rpc.RetryInfo',
                'retryDelay' => '3600s',
            ],
        ],
    ],
] );
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 429, $body );
test_assert( 'Gemini 429 RPD → TYPE_QUOTA_RPD', $err->error_type === APIErrorInfo::TYPE_QUOTA_RPD );
test_assert( 'Gemini 429 RPD → is_retryable=true', $err->is_retryable === true );
test_assert( 'Gemini 429 RPD → retry_after ≥ 3600', $err->retry_after >= 3600 );
test_assert( 'Gemini 429 RPD → reset_at > now', $err->reset_at > time() );

// 2b. Gemini 429 RPM
$body = json_encode( [
    'error' => [
        'status' => 'RESOURCE_EXHAUSTED',
        'message' => 'RPM exceeded',
        'details' => [[
            '@type' => 'type.googleapis.com/google.rpc.QuotaFailure',
            'violations' => [[
                'quotaId' => 'RequestsPerMinutePerProject',
            ]],
        ]],
    ],
] );
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 429, $body );
test_assert( 'Gemini 429 RPM → TYPE_QUOTA_RPM', $err->error_type === APIErrorInfo::TYPE_QUOTA_RPM );

// 2c. Gemini 500
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 500, '{"error":{"status":"INTERNAL"}}' );
test_assert( 'Gemini 500 → TYPE_SERVER_OVERLOADED', $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED );
test_assert( 'Gemini 500 → is_retryable=true', $err->is_retryable === true );

// 2d. Gemini 401
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 401, '{"error":{"status":"UNAUTHENTICATED"}}' );
test_assert( 'Gemini 401 → TYPE_AUTH_FAILURE', $err->error_type === APIErrorInfo::TYPE_AUTH_FAILURE );
test_assert( 'Gemini 401 → is_retryable=false', $err->is_retryable === false );
test_assert( 'Gemini 401 → is_deterministic=true', $err->is_deterministic === true );

// 2e. Gemini 404
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 404, '{"error":{"status":"NOT_FOUND"}}' );
test_assert( 'Gemini 404 → TYPE_MODEL_NOT_FOUND', $err->error_type === APIErrorInfo::TYPE_MODEL_NOT_FOUND );

// 2f. Gemini 400
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 400, '{"error":{"status":"INVALID_ARGUMENT"}}' );
test_assert( 'Gemini 400 → TYPE_REQUEST_SHAPE', $err->error_type === APIErrorInfo::TYPE_REQUEST_SHAPE );
test_assert( 'Gemini 400 → is_deterministic=true', $err->is_deterministic === true );

// 2g. Gemini 408
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 408, '' );
test_assert( 'Gemini 408 → TYPE_TRANSIENT', $err->error_type === APIErrorInfo::TYPE_TRANSIENT );
test_assert( 'Gemini 408 → is_retryable=true', $err->is_retryable === true );

// 2h. Gemini 529
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 529, '{"error":{"status":"UNAVAILABLE"}}' );
test_assert( 'Gemini 529 → TYPE_SERVER_OVERLOADED', $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED );

// 2i. Generic Groq 429 RPD
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Rate limit: requests per day exceeded"}}' );
test_assert( 'Groq 429 "per day" → TYPE_QUOTA_RPD', $err->error_type === APIErrorInfo::TYPE_QUOTA_RPD );

// 2j. Generic Groq 429 RPM
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Rate limit: requests per minute"}}' );
test_assert( 'Groq 429 "per minute" → TYPE_QUOTA_RPM', $err->error_type === APIErrorInfo::TYPE_QUOTA_RPM );

// 2k. Generic Groq 429 TPM
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Token limit exceeded"}}' );
test_assert( 'Groq 429 "token" → TYPE_QUOTA_TPM', $err->error_type === APIErrorInfo::TYPE_QUOTA_TPM );

// 2l. Generic 502
$err = APIErrorParser::parse( 'groq', 502, 'Bad Gateway' );
test_assert( 'Groq 502 → TYPE_SERVER_OVERLOADED', $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED );

// 2m. WP_Error cURL timeout
$err = APIErrorParser::parse_wp_error( 'gemini', new WP_Error( 'http', 'cURL error 28: Connection timed out' ) );
test_assert( 'WP_Error cURL timeout → TYPE_TRANSIENT', $err->error_type === APIErrorInfo::TYPE_TRANSIENT );

// 2n. WP_Error connection refused
$err = APIErrorParser::parse_wp_error( 'gemini', new WP_Error( 'http', 'Connection refused' ) );
test_assert( 'WP_Error conn refused → TYPE_SERVER_OVERLOADED', $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED );

// 2o. WP_Error DNS
$err = APIErrorParser::parse_wp_error( 'gemini', new WP_Error( 'http', 'Could not resolve host' ) );
test_assert( 'WP_Error DNS → TYPE_TRANSIENT', $err->error_type === APIErrorInfo::TYPE_TRANSIENT );

// ═══════════════════════════════════════════════════════════════════════════
//  3. QUOTA STATE MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════

section( '3. QUOTA STATE MANAGEMENT' );

QuotaStateManager::reset_quota( 'test_provider' );

test_assert(
    'Fresh state → can_make_request=true',
    QuotaStateManager::can_make_request( 'test_provider' ) === true
);

QuotaStateManager::record_success( 'test_provider' );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After 1 success → rpm_used=1', $s['rpm_used'] === 1 );
test_assert( 'After 1 success → rpd_used=1', $s['rpd_used'] === 1 );

for ( $i = 0; $i < 5; $i++ ) QuotaStateManager::record_success( 'test_provider' );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After 6 successes → rpm_used=6', $s['rpm_used'] === 6 );
test_assert( 'After 6 successes → rpd_used=6', $s['rpd_used'] === 6 );

// RPD failure
$rpd_err = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPD, 'Daily limit', 'test_provider' );
$rpd_err->reset_at = time() + 3600;
QuotaStateManager::record_failure( 'test_provider', $rpd_err );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After RPD failure → rpd_used=rpd_limit', $s['rpd_used'] === $s['rpd_limit'] );
test_assert( 'After RPD failure → can_make_request=false', QuotaStateManager::can_make_request( 'test_provider' ) === false );

QuotaStateManager::reset_quota( 'test_provider' );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After reset → rpd_used=0', $s['rpd_used'] === 0 );

// RPM failure
$rpm_err = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPM, 'RPM limit', 'test_provider' );
QuotaStateManager::record_failure( 'test_provider', $rpm_err );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After RPM failure → rpm_used=rpm_limit', $s['rpm_used'] === $s['rpm_limit'] );
test_assert( 'After RPM failure → should_slow_down=true', QuotaStateManager::should_slow_down( 'test_provider' ) === true );

// Auth failure
QuotaStateManager::reset_quota( 'test_provider' );
$auth_err = new APIErrorInfo( APIErrorInfo::TYPE_AUTH_FAILURE, 'Bad key', 'test_provider' );
QuotaStateManager::record_failure( 'test_provider', $auth_err );
$s = QuotaStateManager::get_quota_status( 'test_provider' );
test_assert( 'After AUTH_FAILURE → rpm_used=rpm_limit', $s['rpm_used'] === $s['rpm_limit'] );
test_assert( 'After AUTH_FAILURE → rpd_used=rpd_limit', $s['rpd_used'] === $s['rpd_limit'] );

// next_safe_slot
$slot = QuotaStateManager::next_safe_slot_ts( 'test_provider' );
test_assert( 'next_safe_slot_ts ≥ now', $slot >= time() );

// Recommended interval
QuotaStateManager::reset_quota( 'test_provider' );
$interval = QuotaStateManager::get_recommended_interval( 'test_provider' );
test_assert( 'Recommended interval is positive', $interval > 0 );

QuotaStateManager::reset_quota( 'test_provider' );

// ═══════════════════════════════════════════════════════════════════════════
//  4. PROVIDER COOLDOWN
// ═══════════════════════════════════════════════════════════════════════════

section( '4. PROVIDER COOLDOWN' );

ProviderCooldown::reset_provider( 'test_cp' );

test_assert( 'Fresh → not in cooldown', ProviderCooldown::is_in_cooldown( 'test_cp' ) === false );

ProviderCooldown::set_cooldown( 'test_cp', 120 );
test_assert( 'After set_cooldown(120) → in cooldown', ProviderCooldown::is_in_cooldown( 'test_cp' ) === true );

$rem = ProviderCooldown::get_cooldown_remaining( 'test_cp' );
test_assert( 'Cooldown remaining > 0', $rem > 0 );
test_assert( 'Cooldown remaining ≤ 120', $rem <= 120 );

ProviderCooldown::mark_misconfigured( 'test_cp' );
test_assert( 'After mark_misconfigured → is_misconfigured', ProviderCooldown::is_misconfigured( 'test_cp' ) === true );

ProviderCooldown::reset_provider( 'test_cp' );
test_assert( 'After reset → not in cooldown', ProviderCooldown::is_in_cooldown( 'test_cp' ) === false );
test_assert( 'After reset → not misconfigured', ProviderCooldown::is_misconfigured( 'test_cp' ) === false );

// ═══════════════════════════════════════════════════════════════════════════
//  5. APIErrorInfo CLASSIFICATION
// ═══════════════════════════════════════════════════════════════════════════

section( '5. APIErrorInfo CLASSIFICATION' );

$types = [
    APIErrorInfo::TYPE_QUOTA_RPD        => [true,  false, true,  true ],
    APIErrorInfo::TYPE_QUOTA_RPM        => [true,  false, true,  false],
    APIErrorInfo::TYPE_QUOTA_TPM        => [true,  false, true,  false],
    APIErrorInfo::TYPE_QUOTA_UNKNOWN    => [true,  false, true,  false],
    APIErrorInfo::TYPE_SERVER_OVERLOADED=> [true,  false, true,  false],
    APIErrorInfo::TYPE_TRANSIENT        => [true,  false, false, false],
    APIErrorInfo::TYPE_AUTH_FAILURE     => [false, true,  false, false],
    APIErrorInfo::TYPE_MODEL_NOT_FOUND  => [false, true,  false, false],
    APIErrorInfo::TYPE_REQUEST_SHAPE    => [false, true,  false, false],
    APIErrorInfo::TYPE_UNKNOWN          => [false, false, false, false],
];

foreach ( $types as $type => $expected ) {
    $info = new APIErrorInfo( $type, 'test', 'gemini' );
    list( $exp_retry, $exp_det, $exp_quota, $exp_daily ) = $expected;
    test_assert( "{$type} → is_retryable={$exp_retry}", $info->is_retryable === $exp_retry );
    test_assert( "{$type} → is_deterministic={$exp_det}", $info->is_deterministic === $exp_det );
    test_assert( "{$type} → is_quota_error={$exp_quota}", $info->is_quota_error() === $exp_quota );
    test_assert( "{$type} → is_daily_quota={$exp_daily}", $info->is_daily_quota() === $exp_daily );
}

// ═══════════════════════════════════════════════════════════════════════════
//  6. BUFFER SCHEDULER ANCHOR CALCULATION
// ═══════════════════════════════════════════════════════════════════════════

section( '6. BUFFER SCHEDULER ANCHOR (0800/1600 UTC)' );

function calc_anchor( int $now ) {
    $hour   = (int) gmdate( 'G', $now );
    $minute = (int) gmdate( 'i', $now );
    $sec    = $minute * 60;
    if ( $hour < 8 )       return $now + ( ( 8 - $hour ) * 3600 - $sec );
    elseif ( $hour < 16 )  return $now + ( ( 16 - $hour ) * 3600 - $sec );
    else                   return $now + ( ( 24 - $hour + 8 ) * 3600 - $sec );
}

$cases = [
    [ '2026-06-24 03:00:00 UTC', 8,  '03:00 → 08:00' ],
    [ '2026-06-24 10:00:00 UTC', 16, '10:00 → 16:00' ],
    [ '2026-06-24 18:00:00 UTC', 8,  '18:00 → 08:00+1d' ],
    [ '2026-06-24 07:59:00 UTC', 8,  '07:59 → 08:00' ],
    [ '2026-06-24 15:59:00 UTC', 16, '15:59 → 16:00' ],
    [ '2026-06-24 23:59:00 UTC', 8,  '23:59 → 08:00+1d' ],
    [ '2026-06-24 00:00:00 UTC', 8,  '00:00 → 08:00' ],
    [ '2026-06-24 16:00:00 UTC', 8,  '16:00 → 08:00+1d' ],
];

foreach ( $cases as list( $ts_str, $expected_hour, $label ) ) {
    $ts   = strtotime( $ts_str );
    $anch = calc_anchor( $ts );
    $h    = (int) gmdate( 'G', $anch );
    test_assert( $label, $h === $expected_hour, 'Got hour: ' . gmdate( 'H:i', $anch ) );
}

// Verify 12h interval
test_assert( '12h interval = 43200s', 12 * HOUR_IN_SECONDS === 43200 );

// Verify PKT conversion
$t1300 = strtotime( '2026-06-24 13:00:00 +0500' );
test_assert( '1300 PKT = 0800 UTC', gmdate( 'H:i', $t1300 ) === '08:00' );
$t2100 = strtotime( '2026-06-24 21:00:00 +0500' );
test_assert( '2100 PKT = 16:00 UTC', gmdate( 'H:i', $t2100 ) === '16:00' );

// ═══════════════════════════════════════════════════════════════════════════
//  7. BUFFER DAILY LIMIT TRACKING
// ═══════════════════════════════════════════════════════════════════════════

section( '7. BUFFER DAILY LIMIT TRACKING' );

update_option( Config::OPTION_BUFFER_TRACKER, [ 'date' => '', 'ids' => [] ] );
update_option( Config::OPTION_BUFFER_DAILY_LIMIT, 5 );

test_assert( 'Fresh tracker → not reached', Config::buffer_daily_limit_reached() === false );

for ( $i = 0; $i < 5; $i++ ) Config::increment_buffer_tracker( 1000 + $i );
test_assert( 'After 5 increments (limit=5) → reached', Config::buffer_daily_limit_reached() === true );

$tracker = Config::get_buffer_tracker();
test_assert( 'Tracker has 5 ids', count( $tracker['ids'] ?? [] ) === 5 );
test_assert( 'Tracker has date', ! empty( $tracker['date'] ) );

delete_option( Config::OPTION_BUFFER_TRACKER );
delete_option( Config::OPTION_BUFFER_DAILY_LIMIT );

// ═══════════════════════════════════════════════════════════════════════════
//  7b. MULTI-ACCOUNT BUFFER HELPERS
// ═══════════════════════════════════════════════════════════════════════════

section( '7b. MULTI-ACCOUNT BUFFER HELPERS' );

test_assert( 'OPTION_BUFFER_ACCOUNTS constant exists', defined( Config::class . '::OPTION_BUFFER_ACCOUNTS' ) );
test_assert( 'get_buffer_accounts() callable', is_callable( [ Config::class, 'get_buffer_accounts' ] ) );
test_assert( 'get_active_buffer_accounts() callable', is_callable( [ Config::class, 'get_active_buffer_accounts' ] ) );
test_assert( 'get_buffer_account() callable', is_callable( [ Config::class, 'get_buffer_account' ] ) );
test_assert( 'get_buffer_account_token() callable', is_callable( [ Config::class, 'get_buffer_account_token' ] ) );
test_assert( 'get_buffer_account_daily_limit() callable', is_callable( [ Config::class, 'get_buffer_account_daily_limit' ] ) );
test_assert( 'validate_buffer_account() callable', is_callable( [ Config::class, 'validate_buffer_account' ] ) );
test_assert( 'save_buffer_accounts() callable', is_callable( [ Config::class, 'save_buffer_accounts' ] ) );
test_assert( 'increment_buffer_account_tracker() callable', is_callable( [ Config::class, 'increment_buffer_account_tracker' ] ) );
test_assert( 'buffer_account_daily_limit_reached() callable', is_callable( [ Config::class, 'buffer_account_daily_limit_reached' ] ) );

// Clean state
delete_option( Config::OPTION_BUFFER_ACCOUNTS );

$empty_accounts = Config::get_buffer_accounts();
test_assert( 'No accounts + no legacy → empty array', is_array( $empty_accounts ) && empty( $empty_accounts ) );

// Test validation
$valid_profile = Config::validate_buffer_account( [
	'id' => 'test_acct',
	'name' => 'Test Account',
	'api_key' => 'tok_abc123',
	'enabled' => true,
	'daily_limit' => 10,
	'share_mode' => 'draft',
	'channel_ids' => [ 'ch1', 'ch2' ],
] );
test_assert( 'validate_buffer_account returns valid profile', is_array( $valid_profile ) && $valid_profile['id'] === 'test_acct' );

$invalid_profile = Config::validate_buffer_account( [ 'id' => '', 'api_key' => 'x' ] );
test_assert( 'validate_buffer_account rejects empty id', $invalid_profile === null );

// Save and retrieve
$test_accounts = [
	[
		'id' => 'acct_a',
		'name' => 'Account A',
		'api_key' => 'key_a',
		'enabled' => true,
		'daily_limit' => 3,
		'share_mode' => 'draft',
		'channel_ids' => [],
		'channel_types' => [],
		'channel_templates' => [],
		'link_posts' => [],
		'channel_hashtags' => [],
		'pinterest_boards' => [],
		'pinterest_titles' => [],
		'channel_story_toggles' => [],
	],
	[
		'id' => 'acct_b',
		'name' => 'Account B',
		'api_key' => 'key_b',
		'enabled' => false,
		'daily_limit' => 8,
		'share_mode' => 'draft',
		'channel_ids' => [],
		'channel_types' => [],
		'channel_templates' => [],
		'link_posts' => [],
		'channel_hashtags' => [],
		'pinterest_boards' => [],
		'pinterest_titles' => [],
		'channel_story_toggles' => [],
	],
];
$saved = Config::save_buffer_accounts( $test_accounts );
test_assert( 'save_buffer_accounts returns 2 profiles', count( $saved ) === 2 );

$accounts = Config::get_buffer_accounts();
test_assert( 'get_buffer_accounts returns 2 accounts', count( $accounts ) === 2 );
test_assert( 'Account acct_a exists', isset( $accounts['acct_a'] ) );
test_assert( 'Account acct_b exists', isset( $accounts['acct_b'] ) );

$active = Config::get_active_buffer_accounts();
test_assert( 'Only 1 active account (acct_b is disabled)', count( $active ) === 1 );
test_assert( 'Active account is acct_a', isset( $active['acct_a'] ) );

$token = Config::get_buffer_account_token( 'acct_a' );
test_assert( 'Account token matches', $token === 'key_a' );

$limit = Config::get_buffer_account_daily_limit( 'acct_a' );
test_assert( 'Account daily limit = 3', $limit === 3 );

// Test per-account tracker
Config::increment_buffer_account_tracker( 'acct_a', 5001 );
Config::increment_buffer_account_tracker( 'acct_a', 5002 );
test_assert( 'Account tracker not reached at 2 (limit=3)', Config::buffer_account_daily_limit_reached( 'acct_a' ) === false );
Config::increment_buffer_account_tracker( 'acct_a', 5003 );
test_assert( 'Account tracker reached at 3 (limit=3)', Config::buffer_account_daily_limit_reached( 'acct_a' ) === true );
test_assert( 'Account B tracker not reached (different tracker)', Config::buffer_account_daily_limit_reached( 'acct_b' ) === false );

// Cleanup
delete_option( Config::OPTION_BUFFER_ACCOUNTS );
delete_option( Config::OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX . 'acct_a' );
delete_option( Config::OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX . 'acct_b' );

// ═══════════════════════════════════════════════════════════════════════════
//  8. JOB LOCK (transient-based)
// ═══════════════════════════════════════════════════════════════════════════

section( '8. JOB LOCK (transient)' );

$lock_key = 'ai_collage_job_lock_99999';
set_transient( $lock_key, time(), 600 );
test_assert( 'Lock set → get_transient returns value', false !== get_transient( $lock_key ) );
delete_transient( $lock_key );
test_assert( 'Lock deleted → get_transient returns false', false === get_transient( $lock_key ) );

// Simulate concurrent lock check
set_transient( $lock_key, time(), 600 );
$is_locked = ( false !== get_transient( $lock_key ) );
test_assert( 'Lock acquired → is_locked=true', $is_locked === true );
delete_transient( $lock_key );
$is_locked = ( false !== get_transient( $lock_key ) );
test_assert( 'Lock released → is_locked=false', $is_locked === false );

// ═══════════════════════════════════════════════════════════════════════════
//  9. API CALL TRACKING
// ═══════════════════════════════════════════════════════════════════════════

section( '9. API CALL TRACKING' );

$hash1 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'gemini', [ 'model' => 'flash', 'x' => 1 ] );
$hash2 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'gemini', [ 'model' => 'flash', 'x' => 1 ] );
test_assert( 'Hash deterministic (same input)', $hash1 === $hash2 );

$hash3 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'groq', [ 'model' => 'flash', 'x' => 1 ] );
test_assert( 'Different provider → different hash', $hash1 !== $hash3 );

$hash4 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'gemini', [ 'model' => 'flash', 'x' => 2 ] );
test_assert( 'Different payload → different hash', $hash1 !== $hash4 );

// ═══════════════════════════════════════════════════════════════════════════
//  10. BUFFER INTEGRATION CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════

section( '10. BUFFER INTEGRATION CONSTANTS' );

test_assert( 'API_BASE = https://api.buffer.com', BufferIntegration::API_BASE === 'https://api.buffer.com' );
test_assert( 'MAX_RETRY_ATTEMPTS = 3', BufferIntegration::MAX_RETRY_ATTEMPTS === 3 );
test_assert( 'RETRY_BASE_DELAY_US = 2000000', BufferIntegration::RETRY_BASE_DELAY_US === 2000000 );
test_assert( 'INTER_REQUEST_DELAY_US = 1500000', BufferIntegration::INTER_REQUEST_DELAY_US === 1500000 );

// ═══════════════════════════════════════════════════════════════════════════
//  11. END-TO-END: CACHE FLOW
// ═══════════════════════════════════════════════════════════════════════════

section( '11. END-TO-END: CACHE FLOW SIMULATION' );

update_option( Config::OPTION_BUFFER_ENABLED, true );
update_option( Config::OPTION_BUFFER_ACCESS_TOKEN, 'test-token' );
update_option( Config::OPTION_BUFFER_DAILY_LIMIT, 10 );
update_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, 3 );

// Simulate scheduler populates cache
update_option( Config::OPTION_BUFFER_STATS_CACHE, [
    'draft_count'     => 25,
    'daily_limit'     => 10,
    'draft_retention' => 3,
    'fetched_at'      => time(),
] );

// Simulate 5 dashboard loads — all read from cache
for ( $i = 0; $i < 5; $i++ ) {
    $cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
    $stats = [
        'enabled'         => (bool) get_option( Config::OPTION_BUFFER_ENABLED, false ),
        'has_token'       => ! empty( get_option( Config::OPTION_BUFFER_ACCESS_TOKEN, '' ) ),
        'daily_limit'     => (int) ( $cache['daily_limit'] ?? 5 ),
        'draft_retention' => (int) ( $cache['draft_retention'] ?? Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS ),
        'draft_count'     => (int) ( $cache['draft_count'] ?? 0 ),
    ];
    test_assert( "Load #{$i}: draft_count=25", $stats['draft_count'] === 25 );
    test_assert( "Load #{$i}: daily_limit=10", $stats['daily_limit'] === 10 );
    test_assert( "Load #{$i}: enabled=true", $stats['enabled'] === true );
    test_assert( "Load #{$i}: has_token=true", $stats['has_token'] === true );
}

// Simulate scheduler runs again 12h later
update_option( Config::OPTION_BUFFER_STATS_CACHE, [
    'draft_count'     => 30,
    'daily_limit'     => 10,
    'draft_retention' => 3,
    'fetched_at'      => time(),
] );

$cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert( 'After refresh: draft_count=30', (int) ( $cache['draft_count'] ?? 0 ) === 30 );

// Cleanup
delete_option( Config::OPTION_BUFFER_STATS_CACHE );
delete_option( Config::OPTION_BUFFER_ENABLED );
delete_option( Config::OPTION_BUFFER_ACCESS_TOKEN );
delete_option( Config::OPTION_BUFFER_DAILY_LIMIT );
delete_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS );

// ═══════════════════════════════════════════════════════════════════════════
//  12. CONFIG BUFFER HELPERS
// ═══════════════════════════════════════════════════════════════════════════

section( '11. CONFIG BUFFER HELPERS' );

test_assert( 'is_buffer_enabled() callable', is_callable( [ Config::class, 'is_buffer_enabled' ] ) );
test_assert( 'get_buffer_access_token() callable', is_callable( [ Config::class, 'get_buffer_access_token' ] ) );
test_assert( 'get_buffer_channels() callable', is_callable( [ Config::class, 'get_buffer_channels' ] ) );
test_assert( 'get_buffer_share_mode() callable', is_callable( [ Config::class, 'get_buffer_share_mode' ] ) );
test_assert( 'get_buffer_daily_limit() callable', is_callable( [ Config::class, 'get_buffer_daily_limit' ] ) );

test_assert( 'Default share mode = draft', Config::get_buffer_share_mode() === 'draft' );

delete_option( Config::OPTION_BUFFER_DAILY_LIMIT );
test_assert( 'Default daily limit = 5', Config::get_buffer_daily_limit() === 5 );

// ═══════════════════════════════════════════════════════════════════════════
//  SUMMARY
// ═══════════════════════════════════════════════════════════════════════════

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  RESULTS: {$passed} passed, {$failed} failed\n";
echo "══════════════════════════════════════════════════════════════\n";

if ( $failed > 0 ) {
    echo "\n  FAILED TESTS:\n";
    foreach ( $errors as $e ) echo "  {$e}\n";
    echo "\n";
    exit( 1 );
}

echo "\n  ALL TESTS PASSED ✓\n\n";
exit( 0 );
