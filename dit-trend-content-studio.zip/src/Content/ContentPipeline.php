<?php

/**
 * Article Generator
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New simplified generator for magazine content
 * @MODIFIED 2025-12-13 - Integrated Research_Orchestrator for Perplexity + Gemini pipeline
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Services\Media_Passthrough;
// PromptEngine is in same namespace but good to be explicit or use directly
use DIT\TrendStudio\Content\PromptEngine;
use DIT\TrendStudio\DTO\GenerationRequestDTO;
use DIT\TrendStudio\Content\PromptBuilder;
use DIT\TrendStudio\Content\PromptBlueprint;
use DIT\TrendStudio\Contracts\ContentGeneratorInterface;
use DIT\TrendStudio\Schema\Content_Schema;
use DIT\TrendStudio\AI\AI_Style_Guard;
use DIT\TrendStudio\Integrations\Gemini\Client as AI_Client;
use DIT\TrendStudio\Content\Media\MediaSelector; // @MODIFIED 2026-02-16 - Phase 2 smart visual selection

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Article Generator Pipeline
 * 
 * Uses PromptEngine for two-step pipeline:
 * - Primary: Perplexity (research) â†’ Gemini (writing)
 * - Fallback: Gemini with Google Search grounding
 */
class ContentPipeline implements ContentGeneratorInterface
{
    /**
     * Prompt engine instance responsible for orchestrating research and AI calls.
     *
     * @var PromptEngine
     */
    private PromptEngine $promptEngine;

    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Media Passthrough service
     *
     * @var Media_Passthrough|null
     */
    private ?Media_Passthrough $media_passthrough_service = null;

    /**
     * Content Cleaner service
     *
     * @var \DIT\TrendStudio\Services\Content_Cleaner|null
     */
    private $content_cleaner_service = null;

    /**
     * Option reader callback for testing
     *
     * @var callable|null
     */
    private $option_reader = null;

    /**
     * Constructor
     *
     * @MODIFIED 2025-12-13 - Changed from AI_Client to Research_Orchestrator
     *
     * @param PromptEngine                               $promptEngine      Prompt engine instance
     * @param Logger                                   $logger            Logger instance
     * @param Media_Passthrough|null                   $media_passthrough Optional Media Passthrough service
     * @param \DIT\TrendStudio\Services\Content_Cleaner|null $content_cleaner   Optional Content Cleaner service
     * @param callable|null                            $option_reader     Optional callback for get_option()
     */
    public function __construct(
        PromptEngine $promptEngine,
        Logger $logger,
        ?Media_Passthrough $media_passthrough = null,
        $content_cleaner = null,
        ?callable $option_reader = null
    ) {
        $this->promptEngine              = $promptEngine;
        $this->logger                    = $logger;
        $this->media_passthrough_service = $media_passthrough;
        $this->content_cleaner_service   = $content_cleaner;
        $this->option_reader             = $option_reader;
    }

    /**
     * Helper to get options (supports mocking)
     */
    private function get_option(string $key, $default = false)
    {
        if ($this->option_reader) {
            return ($this->option_reader)($key, $default);
        }
        return get_option($key, $default);
    }

    /**
     * Get structure blueprint based on search intent
     * @MODIFIED 2026-01-12 - NEW: Returns JSON schema/blueprint for intent-specific article structure
     *
     * @param string $intent   Search intent (commercial, informational, news, mixed)
     * @param string $vertical Content vertical (optional)
     * @return array Structure blueprint with required sections and formats
     */
    private function get_structure_blueprint(string $intent, string $vertical = 'general'): array
    {
        // Delegate blueprint selection to PromptBlueprint (new logic)
        return PromptBlueprint::getBlueprint($intent, $vertical);
    }

    /**
     * Legacy constructor for backward compatibility
     *
     * @MODIFIED 2025-12-13 - Provides backward compatibility during transition
     *
     * @param AI_Client $ai_client AI client instance
     * @param Logger    $logger    Logger instance
     * @return static
     */
    public static function from_ai_client(AI_Client $ai_client, Logger $logger): self
    {
        // Maintain backwards compatibility: wrap the AI client in a PromptEngine
        $promptEngine = new PromptEngine($ai_client, $logger);
        return new self($promptEngine, $logger);
    }

    /**
     * Factory method accepting a generic AI provider. Prefer this method
     * when using the new Contracts-based architecture.
     *
     * @param \DIT\TrendStudio\Contracts\AIProviderInterface $provider AI provider implementation
     * @param Logger                                         $logger
     * @return static
     */
    public static function from_ai_provider(\DIT\TrendStudio\Contracts\AIProviderInterface $provider, Logger $logger): self
    {
        $promptEngine = new PromptEngine($provider, $logger);
        return new self($promptEngine, $logger);
    }

    /**
     * Generate article from input data
     *
     * @param array $input_data Input data with idea info
     * @return array Article data array
     * @throws \Exception On generation failure
     */
    public function generateContent(array &$input_data): array
    {
        $this->logger->info('Starting article generation', array(
            'input' => array_keys($input_data),
            'method' => method_exists($this->promptEngine, 'get_expected_method') ? $this->promptEngine->get_expected_method() : 'unknown',
        ));

        // @MODIFIED 2026-02-07 - Normalize encoding to UTF-8 before processing (Issue #005)
        $input_data = $this->normalize_encoding($input_data);

        // If generating from idea CPT, enrich with stored data
        if (!empty($input_data['idea_id'])) {
            $input_data = $this->enrich_from_idea($input_data);
        }

        // @MODIFIED 2026-02-15 - Preserve raw idea text before tokenization for downstream services (Collage/Passthrough)
        $raw_idea_text = $input_data['idea_text'] ?? '';

        // @ADDED 2026-05-25 - Auto-fetch visual sourcing images
        if (!empty($input_data['auto_source_images'])) {
            $topic = $input_data['idea_title'] ?? '';
            if ($topic) {
                if (class_exists('DIT\TrendStudio\Services\Visual_Sourcing_Service')) {
                    $sourcing_service = new \DIT\TrendStudio\Services\Visual_Sourcing_Service($this->logger);
                    $source_html = $sourcing_service->source_images_for_topic($topic);
                    if ($source_html) {
                        $input_data['idea_text'] = $source_html . "\n\n" . ($input_data['idea_text'] ?? '');
                        $raw_idea_text = $input_data['idea_text']; // update raw_idea_text as well
                    }
                }
            }
        }

        // @MODIFIED 2026-02-15 - Tokenize source visuals before prompting
        // This hides raw <img> tags from the AI and enforces the image limit pre-generation.
        $input_data = $this->tokenize_source_visuals($input_data);

        // Build prompt data
        $prompt_data = $this->build_prompt_data($input_data);

        // @MODIFIED 2026-02-12 - Pass strategy override from Scheduler
		$strategy = $input_data['strategy_override'] ?? 'gemini';

	// Generate via prompt engine (direct generation via selected provider)
        $ai_response = $this->promptEngine->generate($prompt_data, $strategy);

        // MIDDLEWARE PHASE: Modular Post-Generation processing (Issue #ArchitecturalRefactor)
        $pipe = new \DIT\TrendStudio\Pipeline\MiddlewarePipe();
        $pipe->pipe(new \DIT\TrendStudio\Pipeline\Middleware\CleanResponseMiddleware())
            ->pipe(new \DIT\TrendStudio\Pipeline\Middleware\SwapVisualsMiddleware($this))
            ->pipe(new \DIT\TrendStudio\Pipeline\Middleware\MediaAlignmentMiddleware());

        $context = [
            'input_data' => $input_data,
            'vertical'   => $input_data['vertical'] ?? $this->get_option('dit_ts_content_vertical', 'showbiz'),
        ];

        $ai_response = $pipe->process($ai_response, $context);

        // Normalize to schema
        $schema = Content_Schema::from_ai_array($ai_response);
        $schema->idea_id = $input_data['idea_id'] ?? null;

        // Convert back to array for storage
        $article = $schema->to_array();

        // [NEW] Preserve meta tags from AI response for auto-tagging
        if (!empty($ai_response['meta_tags'])) {
            $article['_meta_tags'] = $ai_response['meta_tags'];
        }

		// [NEW] Preserve headline from AI response if present (overrides schema default)
		if (!empty($ai_response['headline'])) {
			// @MODIFIED 2026-02-14 - Strip HTML tags from headline (e.g. <strong>) to avoid malformed post titles
			$article['headline'] = strip_tags($ai_response['headline']);
		}

		if (!empty($ai_response['_sources_index'])) {
			$article['_sources_index'] = $ai_response['_sources_index'];
		}
		if (!empty($ai_response['_actual_provider'])) {
			$article['_actual_provider'] = $ai_response['_actual_provider'];
		}
		if (!empty($ai_response['_actual_model'])) {
			$article['_actual_model'] = $ai_response['_actual_model'];
		}

        // @MODIFIED 2025-12-14 - Fetch image suggestions for each section
        $article = $this->enrich_with_image_suggestions($article);

        // @since 2.2.0 - Generate local featured collage if images exist
        // @MODIFIED 2026-02-15 - Use $raw_idea_text to ensure Collage Generator sees all images
        $vertical = $input_data['vertical'] ?? $this->get_option('dit_ts_content_vertical', 'showbiz');
        $source_html = $raw_idea_text ?: ($input_data['idea_text'] ?? '');
        $article = $this->generate_featured_collage($article, $input_data, $vertical, $source_html);

        // Preserve generation method metadata
        if (!empty($ai_response['_generation_method'])) {
            $article['_generation_method'] = $ai_response['_generation_method'];
        }

        $this->logger->info('Article generated successfully', array(
            'headline' => $schema->headline,
            'sections' => count($schema->sections),
            'word_count' => $schema->get_word_count(),
            'method' => $article['_generation_method'] ?? 'unknown',
        ));

        // @MODIFIED 2026-02-15 - Strictly enforce culling limit for Media Passthrough
        // If we have a source_visual_map (culled list), construct the source blob ONLY from those allowed images.
        // This prevents Media_Passthrough from "discovering" the 35+ images we intentionally culled and dumping them.
        if (!empty($input_data['source_visual_map']) && is_array($input_data['source_visual_map'])) {
            $source_blob = '';
            foreach ($input_data['source_visual_map'] as $token => $data) {
                $source_blob .= ($data['tag'] ?? '') . "\n";
            }
            // Append source_urls usually for reference, but be careful not to re-introduce raw images if they are in there.
            // Generally safe as source_urls are usually just links, not full img tags.
            $source_blob .= "\n" . ($input_data['source_urls'] ?? '');
        } else {
            // Fallback for non-tokenized flows (though most should be tokenized now)
            $source_blob = (string) (($raw_idea_text ?: ($input_data['idea_text'] ?? '')) . "\n" . ($input_data['source_urls'] ?? ''));
        }

        $media_passthrough = $this->media_passthrough_service ?: new Media_Passthrough($this->logger);
        // @MODIFIED 2026-02-13 - Pass headline for alt text synchronization
        // @MODIFIED 2026-02-16 - Phase 3 fix: pass input_data and vertical to match new signature
        $article = $media_passthrough->ensure_media_passthrough($article, $input_data, $vertical);

        // @MODIFIED 2026-02-17 - Phase 3: Persist source_visual_map for separate rendering (e.g. PostComposer)
        if (!empty($input_data['source_visual_map'])) {
            $article['_source_visual_map'] = $input_data['source_visual_map'];
        }

        // @MODIFIED 2026-02-09 - Clean generated content (remove empty paragraphs, artifacts)
        // @MODIFIED 2026-02-14 - Defensive guard: ensure Content_Cleaner never destroys images
        $cleaner = $this->content_cleaner_service ?: new \DIT\TrendStudio\Services\Content_Cleaner();
        if (!empty($article['sections'])) {
            foreach ($article['sections'] as &$section) {
                if (!empty($section['body_html'])) {
                    $pre_clean = $section['body_html'];
                    $pre_img_count = preg_match_all('/<img\b/i', $pre_clean);

                    $section['body_html'] = $cleaner->clean_generated_content($section['body_html']);

                    $post_img_count = preg_match_all('/<img\b/i', $section['body_html']);

                    // GUARD: If cleaner removed images, revert and log
                    if ($post_img_count < $pre_img_count) {
                        $this->logger->error('Content_Cleaner removed images â€” reverting section', [
                            'before' => $pre_img_count,
                            'after'  => $post_img_count,
                            'lost'   => $pre_img_count - $post_img_count,
                        ]);
                        $section['body_html'] = $pre_clean;
                    }
                }
            }
            unset($section);
        }

        // @MODIFIED 2026-02-07 - Validate media URLs before returning (Issue #025)
        $article = $this->validate_media_urls($article);

        return $article;
    }

    /**
     * Generate article from input data (legacy alias).
     *
     * @param array $input_data
     * @return array
     * @deprecated Use generateContent() instead.
     */
    public function generate(array &$input_data): array
    {
        return $this->generateContent($input_data);
    }

    /**
     * Fetch image suggestions for article sections
     * @MODIFIED 2025-12-14 - Integration with Image_Suggester service
     *
     * @param array $article Article data
     * @return array Article with image_suggestions populated
     */
    private function enrich_with_image_suggestions(array $article): array
    {
        $suggester = new \DIT\TrendStudio\Services\Image_Suggester();

        // Skip if no API keys configured
        if (!$suggester->is_available()) {
            $this->logger->info('Image suggestions skipped - no API keys configured');
            return $article;
        }

        // Fetch suggestions for each section
        if (!empty($article['sections'])) {
            $article['sections'] = $suggester->fetch_for_sections($article['sections'], 3);
            $this->logger->info('Image suggestions fetched', array(
                'sections' => count($article['sections']),
            ));
        }

        return $article;
    }

    /**
     * @deprecated 2.2.0 - Use enrich_with_image_suggestions() instead
     * Compatibility wrapper for older jobs or cached code calling the old method
     */
    public function enrich_with_ai_images(array $article): array
    {
        $this->logger->warning('Deprecated method enrich_with_ai_images called. Redirecting to enrich_with_image_suggestions.');
        return $this->enrich_with_image_suggestions($article);
    }

    /**
     * Enrich input data from idea CPT
     *
     * @param array $input_data Raw input
     * @return array Enriched input
     */
    private function enrich_from_idea(array $input_data): array
    {
        $idea_id = (int) $input_data['idea_id'];
        $idea = get_post($idea_id);

        if (!$idea || $idea->post_type !== 'dit_idea') {
            return $input_data;
        }

        // Get idea metadata
        $source_url = get_post_meta($idea_id, '_dit_ts_source_url', true);
        $source_type = get_post_meta($idea_id, '_dit_ts_source_type', true);
        $provider_name = get_post_meta($idea_id, '_dit_ts_provider_name', true);

        // @MODIFIED 2026-01-24 - Force News Intent if stored in Idea
        $stored_intent = get_post_meta($idea_id, '_dit_search_intent', true);
        if ($stored_intent) {
            $input_data['search_intent'] = $stored_intent;
        }

        // Enrich input
        if (empty($input_data['idea_title'])) {
            $input_data['idea_title'] = $idea->post_title;
        }

        if (empty($input_data['idea_text'])) {
            $input_data['idea_text'] = $idea->post_content;
        }

        // @MODIFIED 2026-01-25 - Sanitize garbage HTML (ads, trackers, layout)
        // This ensures the AI gets clean data and image extraction targets valid images.
        if (!empty($input_data['idea_text'])) {
            $cleaner = new \DIT\TrendStudio\Services\Content_Cleaner();
            $input_data['idea_text'] = $cleaner->clean($input_data['idea_text']);
            // Log cleaned length for debugging
            $this->logger->info('Sanitized idea content', [
                'original_len' => strlen($idea->post_content),
                'cleaned_len' => strlen($input_data['idea_text'])
            ]);
        }

        // Add source URL if available
        if (!empty($source_url)) {
            $existing_urls = $input_data['source_urls'] ?? '';
            $input_data['source_urls'] = trim($existing_urls . "\n" . $source_url);
        }

        $this->logger->info('Enriched input from idea', array(
            'idea_id' => $idea_id,
            'source_type' => $source_type,
            'provider_name' => $provider_name,
        ));

        // @MODIFIED 2026-02-14 - Removed pre-generation renaming to avoid double-processing. 
        // Renaming now happens exclusively in Scheduler.php using the final generated headline.
        /*
        if (class_exists('DIT\TrendStudio\Services\Image_Renamer')) {
            $renamer = new \DIT\TrendStudio\Services\Image_Renamer($this->logger);
            $headline = $input_data['topic'] ?? $input_data['idea_title'] ?? $idea->post_title;

            // @MODIFIED 2026-02-13 - Enforce hard caps based on vertical
            $vertical = $input_data['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz');
            $max_images = ($vertical === 'fashion_pk') ? 15 : (($vertical === 'showbiz_pk') ? 10 : 0);

            $url_map = $renamer->rename_attachments_to_match_title($idea_id, $headline, $max_images);

            if (!empty($url_map)) {
                // Handle deleted images first to avoid partial matches
                if (!empty($url_map['_deleted_urls'])) {
                    foreach ($url_map['_deleted_urls'] as $del_url) {
                        if (!empty($input_data['idea_text'])) {
                            // Strip <img> tag matching this URL
                            $pattern = '/<img[^>]+src=["\']' . preg_quote($del_url, '/') . '["\'][^>]*>/i';
                            $input_data['idea_text'] = preg_replace($pattern, '', $input_data['idea_text']);
                        }
                    }
                    unset($url_map['_deleted_urls']);
                }

                foreach ($url_map as $old => $new) {
                    if (!empty($input_data['idea_text'])) {
                        $input_data['idea_text'] = str_replace($old, $new, $input_data['idea_text']);
                    }
                    if (!empty($input_data['source_urls'])) {
                        $input_data['source_urls'] = str_replace($old, $new, $input_data['source_urls']);
                    }
                }
                $this->logger->info('Synced renamed image URLs in source content', ['count' => count($url_map)]);
            }
        }
        */

        // @MODIFIED 2026-02-16 - STRICT LOCAL IMAGE POLICY v2
        // Keep images that are resolvable to a local attachment OR hosted on allowed local domains.
        // NOTE: Do NOT rely on post_parent relationships; many importers leave attachments unattached (post_parent = 0).
        $strict_local = (bool) apply_filters('dit_ts_strict_local_image_policy', true, (int) $idea_id, $input_data);

        if ($strict_local && ! empty($input_data['idea_text'])) {
            $site_host     = (string) wp_parse_url(home_url(), PHP_URL_HOST);
            $site_host_alt = (string) wp_parse_url(site_url(), PHP_URL_HOST);

            $default_hosts = array_values(array_unique(array_filter([$site_host, $site_host_alt])));

            // Allowlist can be extended (e.g. CDN subdomains) without code changes.
            $allowed_hosts = apply_filters('dit_ts_allowed_image_hosts', $default_hosts, (int) $idea_id, $input_data);
            $allowed_hosts = array_values(array_filter(array_map(static function ($h) {
                $h = strtolower(trim((string) $h));
                return $h !== '' ? $h : null;
            }, (array) $allowed_hosts)));

            // Scan for images and remove non-local ones.
            // @MODIFIED 2026-02-16 - Attachment-aware check (replaces post_parent dependency).
            $input_data['idea_text'] = preg_replace_callback(
                '/(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>)/i',
                function ($m) use ($allowed_hosts) {
                    $tag = $m[1];
                    $src = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($m[2]);

                    // 1) Attachment-resolvable URLs are local (even if unattached to the post).
                    $att_id = attachment_url_to_postid($src);
                    if (! empty($att_id)) {
                        return $tag;
                    }

                    // 2) Relative URLs are local.
                    $host = strtolower((string) parse_url($src, PHP_URL_HOST));
                    if ($host === '') {
                        return $tag;
                    }

                    // 3) Host allowlist (defaults to the site's host).
                    if (in_array($host, $allowed_hosts, true)) {
                        return $tag;
                    }

                    // Not local: remove it.
                    if ($this->logger) {
                        $this->logger->info('Strict Filter: Removed external image', ['src' => $src, 'host' => $host]);
                    }

                    return '';
                },
                (string) $input_data['idea_text']
            );
        }

        return $input_data;
    }

    /**
     * Build prompt data for AI
     * @MODIFIED 2025-12-27 - Added SEO targeting fields
     * @MODIFIED 2026-01-12 - Added editorial_angle and structure_blueprint for intent-based architecture
     *
     * @param array $input_data Input data
     * @return array Prompt data
     */
    private function build_prompt_data(array $input_data): array
    {
        // Use new DTO-based prompt builder for constructing the prompt
        $dto = new GenerationRequestDTO($input_data);
        return PromptBuilder::buildPrompt($dto);

        // Legacy code retained below for reference but unreachable
        $search_intent = $input_data['search_intent'] ?? 'mixed';
        $editorial_angle = $input_data['editorial_angle'] ?? 'neutral';
        $vertical = $input_data['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz');

        // Get structure blueprint based on intent
        $structure_blueprint = $this->get_structure_blueprint($search_intent, $vertical);

        return array(
            'idea_title' => $input_data['idea_title'] ?? '',
            'idea_text' => $input_data['idea_text'] ?? '',
            'vertical' => $vertical,
            'category' => $input_data['category'] ?? '',
            'source_urls' => $input_data['source_urls'] ?? '',
            // SEO targeting fields
            'primary_keyword' => $input_data['primary_keyword'] ?? '',
            'search_intent' => $search_intent,
            'secondary_keywords' => $input_data['secondary_keywords'] ?? '',
            // @MODIFIED 2026-01-12 - Intent-based architecture fields
            'editorial_angle' => $editorial_angle,
            'structure_blueprint' => $structure_blueprint,
            // @MODIFIED 2026-01-12 - Explicit constraints for the AI persona
            'role_definition' => $structure_blueprint['role'], // Tell the AI who it is
            'style_guide'     => $structure_blueprint['voice_guidelines'], // Tell it how to write
            'formatting_rules' => $structure_blueprint['formatting_directives'], // Tell it how to structure
        );
    }

    /**
     * Generate a local featured image collage from source images.
     *
     * @since 2.2.0
     * @MODIFIED 2026-02-19 - Prefer source_visual_map and idea_id media inventory; normalize relative URLs; force 3-cols for fashion_pk.
     *
     * @param array  $article
     * @param array  $input_data
     * @param string $vertical
     * @param string $source_html Raw (pre-tokenized) HTML/text for fallback parsing
     * @return array
     */
    private function generate_featured_collage(array $article, array $input_data, string $vertical = 'general', string $source_html = ''): array
    {
        // Check if Collage Generator exists
        if (!class_exists('DIT\TrendStudio\Services\Collage_Generator')) {
            $this->logger->warning('Collage Generator class not found');
            return $article;
        }

        $this->logger->info('Attempting to generate featured collage from source images', [
            'vertical' => $vertical,
        ]);

        $candidates = [];

        // 1) Prefer tokenized visual map (already capped for persona flows)
        if (!empty($input_data['source_visual_map']) && is_array($input_data['source_visual_map'])) {
            $map = $input_data['source_visual_map'];

            // Order tokens numerically: [VISUAL_0], [VISUAL_1]...
            uksort($map, static function ($a, $b) {
                $ai = (int) preg_replace('/\D+/', '', (string) $a);
                $bi = (int) preg_replace('/\D+/', '', (string) $b);
                return $ai <=> $bi;
            });

            foreach ($map as $token => $data) {
                $att_id = (int) ($data['attachment_id'] ?? $data['attachmentId'] ?? 0);
                if ($att_id > 0) {
                    $u = wp_get_attachment_url($att_id);
                    if (!empty($u)) {
                        $candidates[] = $u;
                        continue;
                    }
                }

                $u = (string) ($data['url'] ?? '');
                if ($u !== '') {
                    $candidates[] = $u;
                }
            }
        }

        // 2) If we have an idea_id, extract attachments directly from Gutenberg blocks / content
        if (!empty($input_data['idea_id']) && class_exists('DIT\TrendStudio\Services\Media_Inventory')) {
            try {
                $inv = new \DIT\TrendStudio\Services\Media_Inventory($this->logger);
                $inv_res = $inv->get_post_image_inventory((int) $input_data['idea_id']);

                foreach ((array) ($inv_res['ordered_ids'] ?? []) as $att_id) {
                    $u = wp_get_attachment_url((int) $att_id);
                    if (!empty($u)) {
                        $candidates[] = $u;
                    }
                }
            } catch (\Throwable $e) {
                $this->logger->warning('Media inventory for collage failed', [
                    'message' => $e->getMessage(),
                ]);
            }
        }

        // 3) Fallback regex parse on raw HTML (handles external)
        $fallback_html = $source_html ?: (string) ($input_data['idea_text'] ?? '');
        if ($fallback_html !== '') {
            // @MODIFIED 2026-02-24 - Optimize YouTube gathering in fallback: deduplicate by video ID
            if (preg_match_all('/(?:v=|v\/|embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $fallback_html, $yt_matches)) {
                $video_ids = array_unique($yt_matches[1]);
                foreach ($video_ids as $vid) {
                    $candidates[] = "https://img.youtube.com/vi/{$vid}/maxresdefault.jpg";
                    $candidates[] = "https://img.youtube.com/vi/{$vid}/1.jpg";
                    $candidates[] = "https://img.youtube.com/vi/{$vid}/2.jpg";
                    $candidates[] = "https://img.youtube.com/vi/{$vid}/3.jpg";
                }
            }

            if (preg_match_all('/<img[^>]+?\b(?:src|data-src|data-lazy-src)=["\'](.*?)["\'][^>]*>/i', $fallback_html, $m)) {
                foreach ($m[1] as $u) {
                    $candidates[] = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string((string) $u);
                }
            }
        }

        // Normalize + validate
        $valid = [];
        foreach ($candidates as $u) {
            $u = trim((string) $u);
            if ($u === '') {
                continue;
            }

            // Normalize protocol-relative / relative
            if (strpos($u, '//') === 0) {
                $u = (is_ssl() ? 'https:' : 'http:') . $u;
            } elseif (strpos($u, '/') === 0 && stripos($u, 'http') !== 0) {
                $u = home_url($u);
            } elseif (stripos($u, 'wp-content/') === 0) {
                $u = home_url('/' . ltrim($u, '/'));
            }

            // @MODIFIED 2026-06-21 - URL-encode non-ASCII characters in the path so FILTER_VALIDATE_URL
            // does not silently drop URLs whose filename contains Urdu/Arabic/other non-ASCII
            // characters (e.g. sideloaded featured image `عاصر-اظہر-.webp`). Only encodes characters
            // that are NOT already percent-encoded; preserves query/fragment intact.
            //
            // CRITICAL: we keep the ORIGINAL $u untouched for storage in $valid. Only a temporary
            // $u_for_validation variant is encoded. Reason: down-stream consumers (especially
            // Collage_Generator's Strategy 2 filesystem lookup via `file_exists()`) operate on
            // RAW filenames stored on disk. An encoded path passed downstream makes
            // file_exists() return FALSE (it queries the kernel with a different byte sequence),
            // silently breaking local image loading even after the validation barrier is fixed.
            $u_for_validation = $u;
            $u_parts = parse_url($u);
            if (!empty($u_parts['path']) && preg_match('/[^\x20-\x7E]/', $u_parts['path'])) {
                $path_segments = explode('/', $u_parts['path']);
                foreach ($path_segments as &$seg) {
                    if ($seg === '') continue;
                    // Split out any existing percent-encoded triplets and only encode raw non-ASCII.
                    $encoded_parts = preg_split('/(%[0-9A-Fa-f]{2})/', $seg, -1, PREG_SPLIT_DELIM_CAPTURE);
                    foreach ($encoded_parts as &$ep) {
                        if ($ep === '' || preg_match('/^%[0-9A-Fa-f]{2}$/', $ep)) continue;
                        $ep = rawurlencode($ep);
                    }
                    unset($ep);
                    $seg = implode('', $encoded_parts);
                }
                unset($seg);
                $rebuilt = ($u_parts['scheme'] ?? 'https') . '://' . ($u_parts['host'] ?? '');
                if (!empty($u_parts['port'])) $rebuilt .= ':' . $u_parts['port'];
                $rebuilt .= implode('/', $path_segments);
                if (!empty($u_parts['query'])) $rebuilt .= '?' . $u_parts['query'];
                if (!empty($u_parts['fragment'])) $rebuilt .= '#' . $u_parts['fragment'];
                $u_for_validation = $rebuilt;
            }

            $path = (string) (parse_url($u, PHP_URL_PATH) ?: '');
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
                continue;
            }

            if (!filter_var($u_for_validation, FILTER_VALIDATE_URL)) {
                continue;
            }

            $valid[] = $u;
        }

        $valid = array_values(array_unique($valid));

        // @MODIFIED 2026-06-22 - LAST-RESORT CANDIDATE INJECTION: when source content has no
        // usable images AND a source featured image exists locally, prepend its URL into $valid
        // so it flows through the SAME collage pipeline (dimension check + Collage_Generator).
        // This honors the spec: "Source featured image of source post for Generation of
        // featured collage for generated post is SUPPOSED to use featured collage generation
        // pipeline (NOT use featured image of source post as is for featured image of
        // generated post)." Therefore: NEVER assign _featured_collage_id = $thumb_id
        // directly; always let the collage generator produce the styled collage.
        $valid = $this->inject_source_thumbnail_into_valid($valid, $input_data);

        // @MODIFIED 2026-02-19 - Prefer local uploads first to reduce remote fetch failures
        // (improves determinism for featured collage generation on persona rewrites).
        $uploads = wp_upload_dir();
        $baseurl = (string) ($uploads['baseurl'] ?? '');
        $home = home_url('/');
        $local = [];
        $remote = [];
        foreach ($valid as $u) {
            if (($baseurl !== '' && strpos($u, $baseurl) === 0) || ($home !== '' && strpos($u, $home) === 0)) {
                $local[] = $u;
            } else {
                $remote[] = $u;
            }
        }
        $valid = array_merge($local, $remote);
        $unfiltered = $valid; // preserve before dimension filtering

        // @MODIFIED 2026-06-08 - Hero-First dimension filtering for persona verticals.
        // Only applies to featured collage selection. Tokenization and social collage untouched.
        if ($vertical === 'showbiz_pk' || $vertical === 'fashion_pk') {
            $filtered = [];
            foreach ($valid as $url) {
                [$w, $h] = $this->get_image_dimensions_from_url($url);

                $passes = false;
                if ($vertical === 'fashion_pk') {
                    // Portrait required (H>W), H >= 700px
                    $passes = ($w > 0 && $h > 0 && $h > $w && $h >= 700);
                } else {
                    // Showbiz: H >= 400px AND W >= 600px
                    $passes = ($h >= 400 && $w >= 600);
                }

                $this->logger->info('Collage dimension check', [
                    'url'    => substr($url, -50),
                    'w'      => $w,
                    'h'      => $h,
                    'passes' => $passes,
                ]);

                if ($passes) {
                    $filtered[] = $url;
                }
            }

            if (!empty($filtered)) {
                $valid = $filtered;
            } else {
                // No images passed dimension check — leave $valid empty.
                // Collage generation will fail, _featured_collage_id won't be set,
                // and Scheduler's media presence guard will force the post to pending.
                $this->logger->warning('Collage: 0 images passed dimension check. Post will be forced to pending.', [
                    'vertical'   => $vertical,
                    'candidates' => count($unfiltered),
                ]);
                $valid = [];
            }
        }

        if (count($valid) < 1) {
            // Distinguish: had candidates before dimension filter vs no candidates at all.
            // If the source post had images but ALL failed the persona dimension check,
            // force the post to pending (no collage = no featured image).
            // If the source post had ZERO images, use the source thumbnail as last resort.
            if (!empty($unfiltered)) {
                $this->logger->warning('Collage: images exist but 0 passed dimension check. Post will be forced to pending.', [
                    'vertical'   => $vertical,
                    'candidates' => count($unfiltered),
                ]);
                return $article;
            }

            $this->logger->info('No valid images found for collage');
            // @MODIFIED 2026-06-21 - LAST-RESORT: source content has no usable images.
            // Per spec: source post's featured image (already a LOCAL attachment, sideloaded
            // earlier by Idea_Importer) is used as the generated post's featured image ONLY
            // when the source content has no images. Local-only; no sideload here.
            $article = $this->fallback_featured_to_source_thumbnail($article, $input_data);
            return $article;
        }

        // REMOVE this old block:
        /*
        $bottom_text = (string) get_option('dit_ts_collage_bottom_text');
        if (empty($bottom_text)) {
            $bottom_text = 'DailyInfoTainment.Com';
        }

        $opts = [
            'vertical'       => $vertical,
            'bottom_text'    => $bottom_text,
            'is_retina'      => (bool) get_option('dit_ts_collage_retina', true),
            'bar_font_size'  => 24,
            'letter_spacing' => 10,
        ];
        */

        // ADD this instead:
        $brand_font = DIT_TS_PLUGIN_DIR . 'assets/fonts/EBGaramond-Bold.ttf';

        $opts = [
            'vertical'        => $vertical,
            'bottom_text'     => 'DailyInfoTainment.Com',
            'is_retina'       => (bool) get_option('dit_ts_collage_retina', true),
            'bar_font_file'   => file_exists($brand_font) ? $brand_font : '',
            'bar_font_size'   => 24,
            'letter_spacing'  => 10,
            'bar_text_color'  => '',     // auto-contrast in generator
            'bar_accent_line' => false,  // no gold line; text only
            'use_brand_logo'  => false,  // Featured collage must be text-only branding
        ];

        if ($vertical === 'fashion_pk' || $vertical === 'showbiz_pk') {
            // @MODIFIED 2026-06-08 - Adaptive target_count based on dimension filtering results.
            // Uses however many images passed Hero-First filtering (max 3).
            $collage_count = min(3, count($valid));
            $collage_inputs = array_slice($valid, 0, $collage_count);
            $layout_map = [1 => 'single', 2 => '2-cols', 3 => '3-cols'];
            $opts['layout'] = $layout_map[$collage_count] ?? '3-cols';
            $opts['target_count'] = $collage_count;
        } else {
            $collage_inputs = $valid;
            shuffle($collage_inputs);
            $collage_inputs = array_slice($collage_inputs, 0, 20);
        }

        try {
            $collage_service = new \DIT\TrendStudio\Services\Collage_Generator($this->logger);
            $title = (string) ($article['headline'] ?? 'Featured Image');

            $attachment_id = $collage_service->create_collage($collage_inputs, $title, $opts);

            // @MODIFIED 2026-02-19 - One retry for fashion_pk using next candidates (guards against transient loader failures).
            if ($vertical === 'fashion_pk' && (is_wp_error($attachment_id) || empty($attachment_id)) && count($valid) > 3) {
                $retry_inputs = array_slice($valid, 3, 15);
                if (!empty($retry_inputs)) {
                    $attachment_id = $collage_service->create_collage($retry_inputs, $title, $opts);
                }
            }

            if ($attachment_id && !is_wp_error($attachment_id)) {
                $article['_featured_collage_id'] = (int) $attachment_id;
                $this->logger->info('Collage generated and set as featured image', [
                    'attachment_id' => (int) $attachment_id,
                ]);
            } else {
                $this->logger->error('Collage generation failed', [
                    'error' => is_wp_error($attachment_id) ? $attachment_id->get_error_message() : 'Unknown error',
                ]);
                // @MODIFIED 2026-05-31 - FALLBACK: Use first valid source image as featured
                // image when collage generation fails, preventing posts from publishing
                // without any featured image / thumbnail.
                if (!empty($valid)) {
                    foreach ($valid as $fallback_url) {
                        $fallback_id = (int) attachment_url_to_postid($fallback_url);
                        if ($fallback_id > 0) {
                            $article['_featured_collage_id'] = $fallback_id;
                            $this->logger->info('Fallback featured image set from existing attachment', [
                                'attachment_id' => $fallback_id,
                                'source_url'    => $fallback_url,
                            ]);
                            break;
                        }
                    }
                    if (empty($article['_featured_collage_id'])) {
                        $fallback_url = $valid[0];
                        $tmp_file = @download_url($fallback_url, 15);
                        if (!is_wp_error($tmp_file)) {
                            $filetype = wp_check_filetype(basename(wp_parse_url($fallback_url, PHP_URL_PATH) ?: 'featured.jpg'));
                            $upload = [
                                'tmp_name' => $tmp_file,
                                'name'     => basename(wp_parse_url($fallback_url, PHP_URL_PATH) ?: 'featured.jpg'),
                                'type'     => $filetype['type'] ?? 'image/jpeg',
                            ];
                            $fallback_id = media_handle_sideload($upload, 0);
                            if (is_wp_error($fallback_id)) {
                                $this->logger->warning('Fallback sideload failed', ['error' => $fallback_id->get_error_message()]);
                                @unlink($tmp_file);
                            } else {
                                $article['_featured_collage_id'] = (int) $fallback_id;
                                $this->logger->info('Fallback featured image created via sideload', [
                                    'attachment_id' => (int) $fallback_id,
                                    'source_url'    => $fallback_url,
                                ]);
                            }
                        }
                    }
                }
                // @MODIFIED 2026-06-21 - LAST-RESORT FALLBACK: when $valid is empty (source
                // content had no usable images), use the source idea's _thumbnail_id. Strictly
                // local-only; never sideloads here (Idea_Importer already sideloaded it).
                // Only applies on empty-$valid path so source featured image does NOT compete
                // with content images (per spec: source featured image is last-resort).
                if (empty($valid) && empty($article['_featured_collage_id'])) {
                    $article = $this->fallback_featured_to_source_thumbnail($article, $input_data);
                }
            }
        } catch (\Throwable $e) {
            $this->logger->error('Collage generation failure', [
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ]);
            // @MODIFIED 2026-05-31 - FALLBACK on exception: same as above
            if (!empty($valid)) {
                foreach ($valid as $fallback_url) {
                    $fallback_id = (int) attachment_url_to_postid($fallback_url);
                    if ($fallback_id > 0) {
                        $article['_featured_collage_id'] = $fallback_id;
                        $this->logger->info('Fallback featured image set from existing attachment (exception path)', [
                            'attachment_id' => $fallback_id,
                            'source_url'    => $fallback_url,
                        ]);
                        break;
                    }
                }
            }
            // @MODIFIED 2026-06-21 - LAST-RESORT: exception path also honors the spec.
            if (empty($valid) && empty($article['_featured_collage_id'])) {
                $article = $this->fallback_featured_to_source_thumbnail($article, $input_data);
            }
        }

        return $article;
    }

    /**
     * @MODIFIED 2026-06-22 - Inject source featured image as a candidate URL into $valid so
     * the collage pipeline (dimension check + Collage_Generator) processes it the same way as
     * any other candidate. Per spec: "Source featured image of source post for Generation
     * of featured collage for generated post is SUPPOSED to use featured collage generation
     * pipeline (NOT use featured image of source post as is for featured image of generated
     * post). Therefore this helper MUST NOT set _featured_collage_id; it only PREPENDS the
     * source thumbnail URL into $valid so the existing pipeline produces a real collage.
     *
     * RULES:
     *   - Source featured image is used ONLY when source content has no usable images.
     *   - Local-only: attachment URL must match wp_upload_dir() baseurl. No sideload here;
     *     Idea_Importer sideloaded it earlier, so by this point it is locally hosted.
     *   - De-duplicated: if URL already in $valid, skip.
     *   - Returns $valid with the source thumb URL prepended (at position 0) so it becomes
     *     the FIRST candidate that the collage generator picks.
     *   - No-op when: idea_id missing, no _thumbnail_id exists, or attachment is not local.
     *
     * @param array $valid
     * @param array $input_data
     * @return array
     */
    private function inject_source_thumbnail_into_valid(array $valid, array $input_data): array
    {
        if (empty($input_data['idea_id'])) {
            return $valid;
        }

        $idea_id = (int) $input_data['idea_id'];
        $thumb_id = (int) get_post_thumbnail_id($idea_id);
        if ($thumb_id <= 0) {
            return $valid;
        }

        // Local-only guard: confirm the attachment is hosted under wp_upload_dir().
        $uploads      = wp_upload_dir();
        $uploads_url  = trailingslashit((string) ($uploads['baseurl'] ?? ''));
        $thumb_url    = (string) wp_get_attachment_url($thumb_id);
        if ($uploads_url === '' || $thumb_url === '' || strpos($thumb_url, $uploads_url) !== 0) {
            // Attachment is not local; per spec, do NOT sideload here. Bail out.
            return $valid;
        }

        // De-dup against existing $valid / prepend to position 0.
        if (in_array($thumb_url, $valid, true)) {
            return $valid;
        }
        array_unshift($valid, $thumb_url);

        $this->logger->info('Source idea _thumbnail_id injected as collage candidate (last-resort via pipeline)', [
            'attachment_id' => $thumb_id,
            'idea_id'       => $idea_id,
            'thumb_url'     => $thumb_url,
        ]);

        return $valid;
    }

    /**
     * @MODIFIED 2026-06-22 - TRUE-FINAL-SAFETY-NET ONLY: assign generated post's featured
     * image to the SOURCE idea post's featured image attachment AS-IS. Triggered only when
     * both: (a) the standard collage pipeline cannot produce a result (no $valid, OR collage
     * generation threw AND no fallback succeeded), AND (b) inject_source_thumbnail_into_valid
     * failed to add a usable candidate (vertical != fashion/showbiz so no unfiltered fallback,
     * so even after injection the source thumb was rejected by dimension check).
     *
     * For ALL normal cases (showbiz_pk / fashion_pk / general with valid $valid), the collage
     * pipeline produces _featured_collage_id and this helper is NEVER reached. Per spec this
     * helper is therefore a narrow safety net, not the standard path.
     *
     * RULES:
     *   - Local-only: attachment URL must match wp_upload_dir() baseurl. No sideload here.
     *   - No-op when: idea_id missing, no _thumbnail_id, attachment is not local, or
     *     _featured_collage_id already set.
     *
     * @param array $article
     * @param array $input_data
     * @return array
     */
    private function fallback_featured_to_source_thumbnail(array $article, array $input_data): array
    {
        if (!empty($article['_featured_collage_id'])) {
            return $article;
        }
        if (empty($input_data['idea_id'])) {
            return $article;
        }

        $idea_id = (int) $input_data['idea_id'];
        $thumb_id = (int) get_post_thumbnail_id($idea_id);
        if ($thumb_id <= 0) {
            return $article;
        }

        // Local-only guard: confirm the attachment is hosted under wp_upload_dir().
        $uploads = wp_upload_dir();
        $uploads_url = trailingslashit((string) ($uploads['baseurl'] ?? ''));
        $thumb_url = (string) wp_get_attachment_url($thumb_id);
        if ($uploads_url === '' || $thumb_url === '' || strpos($thumb_url, $uploads_url) !== 0) {
            // Attachment is not local; per spec, do NOT sideload here. Bail out.
            return $article;
        }

        $article['_featured_collage_id'] = $thumb_id;
        $this->logger->warning('TRULY-FINAL-SAFETY-NET: Source idea _thumbnail_id used AS-IS (collage pipeline failed for all candidates)', [
            'attachment_id' => $thumb_id,
            'idea_id'       => $idea_id,
            'thumb_url'     => $thumb_url,
        ]);

        return $article;
    }


    /**
     * Get image prompt based on search intent
     * @MODIFIED 2026-01-12 - NEW: Dynamic prompts for visual authenticity
     *
     * @param string $intent   Search intent
     * @param string $vertical Content vertical
     * @param string $heading  Section heading
     * @param string $body     Section body text
     * @return string Image generation prompt
     */
    private function get_image_prompt_for_intent(string $intent, string $vertical, string $heading, string $body): string
    {
        $context = wp_trim_words($body, 30);
        $negative = 'Avoid: render, 3d, plastic, glossy, cartoon, illustration, perfect symmetry, stock photo watermark.';

        switch ($intent) {
            case 'commercial':
                // Product review / comparison - authentic amateur style
                return sprintf(
                    "Amateur photography style, shot on iPhone, authentic, slightly messy room, first-person perspective, Reddit product photo aesthetic. Subject: %s. Context: %s. Natural lighting, realistic imperfections. %s",
                    $heading,
                    $context,
                    $negative
                );

            case 'news':
                // News article - photojournalism style
                return sprintf(
                    "Photojournalism style, candid shot, high shutter speed, gritty, realistic, documentary photography. Subject: %s. Context: %s. Natural moment captured, no posed shots. %s",
                    $heading,
                    $context,
                    $negative
                );

            case 'informational':
            case 'mixed':
            default:
                // Default editorial style
                return sprintf(
                    "Editorial photography for a %s magazine article. Subject: %s. Context: %s. High-end, professional lighting, cinematic style but authentic and human. %s",
                    $vertical,
                    $heading,
                    $context,
                    $negative
                );
        }
    }

    /**
     * Sideload binary AI image data into Media Library
     * @since 1.7.0
     *
     * @param string $binary_data Raw image data
     * @param string $filename    The desired filename
     * @param string $title       The attachment title
     * @return int|bool Attachment ID on success, false on failure
     */
    private function sideload_ai_image(string $binary_data, string $filename, string $title): int|bool
    {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $upload_dir = wp_upload_dir();
        // Check for upload directory errors
        if (!empty($upload_dir['error'])) {
            $this->logger->error('WP Upload Directory error', ['error' => $upload_dir['error']]);
            return false;
        }

        $file_path = $upload_dir['path'] . '/' . $filename;

        // Save binary data to file
        $saved = file_put_contents($file_path, $binary_data);
        if ($saved === false) {
            $this->logger->error('Failed to save AI image data to disk', ['path' => $file_path]);
            return false;
        }

        // Create attachment
        $attachment = [
            'post_mime_type' => 'image/png',
            'post_title'     => $title,
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];

        $attach_id = wp_insert_attachment($attachment, $file_path);

        if (is_wp_error($attach_id)) {
            $this->logger->error('Failed to insert AI image attachment', ['error' => $attach_id->get_error_message()]);
            return false;
        }

        // Generate metadata
        $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }

    /**
     * Normalize encoding to UTF-8
     * @since 2.4.0
     * @MODIFIED 2026-02-07 - Added encoding normalization (Issue #005)
     *
     * @param array $input_data Input data with research
     * @return array Input data with normalized encoding
     */
    private function normalize_encoding(array $input_data): array
    {
        // Skip if disabled
        if (!get_option('dit_ts_normalize_encoding', true)) {
            return $input_data;
        }

        // Normalize research content
        if (!empty($input_data['idea_text'])) {
            $input_data['idea_text'] = $this->fix_encoding($input_data['idea_text']);
        }

        if (!empty($input_data['research_content'])) {
            $input_data['research_content'] = $this->fix_encoding($input_data['research_content']);
        }

        if (!empty($input_data['source_urls'])) {
            $input_data['source_urls'] = $this->fix_encoding($input_data['source_urls']);
        }

        return $input_data;
    }

    /**
     * Fix text encoding to UTF-8
     *
     * @param string $text Text to fix
     * @return string Fixed text
     */
    private function fix_encoding(string $text): string
    {
        // Detect encoding
        $encoding = mb_detect_encoding($text, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'ASCII'], true);

        // Convert to UTF-8 if needed
        if ($encoding && $encoding !== 'UTF-8') {
            $text = mb_convert_encoding($text, 'UTF-8', $encoding);

            $this->logger->info('Encoding normalized', [
                'from' => $encoding,
                'to' => 'UTF-8',
                'length' => strlen($text),
            ]);
        }

        // Normalize Unicode (NFC form)
        if (class_exists('Normalizer')) {
            $text = \Normalizer::normalize($text, \Normalizer::FORM_C);
        }

        // Remove zero-width characters and other invisible junk
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text);

        // Remove BOMs
        $text = str_replace("\xEF\xBB\xBF", '', $text);

        return $text;
    }

    /**
     * Validate and fix broken media URLs
     * @since 2.4.0
     * @MODIFIED 2026-02-07 - Added media URL validation (Issue #025)
     *
     * @param array $article Article data
     * @return array Article with validated media URLs
     */
    private function validate_media_urls(array $article): array
    {
        // Skip if disabled
        if (!get_option('dit_ts_validate_media_urls', true)) {
            return $article;
        }

        // Validate hero image
        if (!empty($article['hero_image'])) {
            $url = $article['hero_image'];
            $validated = $this->validate_image_url($url);

            if ($validated !== $url) {
                $this->logger->warning('Hero image failed validation', [
                    'original' => $url,
                    'fallback' => $validated,
                ]);
                $article['hero_image'] = $validated;
            }
        }

        // Validate images in HTML content
        if (!empty($article['sections'])) {
            foreach ($article['sections'] as $idx => $section) {
                if (!empty($section['body_html'])) { // FIXED: Use body_html which is internal canonical name
                    $article['sections'][$idx]['body_html'] = $this->validate_html_images(
                        $section['body_html']
                    );
                }
            }
        }

        return $article;
    }

    /**
     * Validate single image URL with HEAD request (and GET fallback)
     *
     * @param string $url Image URL
     * @return string Validated URL or placeholder
     */
    public function validate_image_url(string $url): string
    {
        $url = trim($url);

        // @MODIFIED 2026-02-14 - Robustify: Remove AI escaping artifacts (e.g. \/, \")
        // and extract URL if a full tag was provided.
        $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($url); // Removes \ from \/ and \" and handles \u

        if (strpos($url, '<') === 0) {
            if (preg_match('/src=["\']([^"\']+)["\']/i', $url, $m)) {
                $url = $m[1];
            } elseif (preg_match('/cite=["\']([^"\']+)["\']/i', $url, $m)) {
                $url = $m[1];
            }
        }

        // Quick validation: check if URL is well-formed
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return $this->get_placeholder_image();
        }

        // @MODIFIED 2026-02-11 - Protect internal URLs from destructive placeholder replacement
        $site_url = site_url();
        $home_url = home_url();
        if (stripos($url, $site_url) !== false || stripos($url, $home_url) !== false) {
            return $url;
        }

        // 1. Try HEAD request with short timeout
        $response = wp_remote_head($url, [
            'timeout' => 5,
            'redirection' => 2,
        ]);

        $code = wp_remote_retrieve_response_code($response);

        if ($code === 200) {
            return $url;
        }

        // 2. @MODIFIED 2026-02-14 - Fallback: Some CDNs block HEAD requests with 403/405
        // Try a tiny GET request (first 512 bytes) to verify existence
        if ($code === 405 || $code === 403 || is_wp_error($response)) {
            $get_response = wp_remote_get($url, [
                'timeout' => 5,
                'redirection' => 2,
                'headers' => [
                    'Range' => 'bytes=0-511'
                ]
            ]);
            $get_code = wp_remote_retrieve_response_code($get_response);
            if ($get_code === 200 || $get_code === 206) {
                return $url;
            }
        }

        $this->logger->info('Image URL validation failed', [
            'url' => $url,
            'http_code' => $code,
            'error' => is_wp_error($response) ? $response->get_error_message() : 'none'
        ]);

        return $this->get_placeholder_image();
    }

    /**
     * Get placeholder image URL
     *
     * @return string Placeholder image URL
     */
    private function get_placeholder_image(): string
    {
        return apply_filters(
            'dit_ts_placeholder_image',
            'https://via.placeholder.com/1200x630?text=Image+Not+Available'
        );
    }

    /**
     * Validate images within HTML content
     *
     * @param string $html HTML content
     * @return string HTML with validated images
     */
    private function validate_html_images(string $html): string
    {
        // @MODIFIED 2026-02-14 - Support escaped quotes common in AI output
        return preg_replace_callback(
            '/<img[^>]+src=\\\\?["\']([^"\'\\\\]+)\\\\?["\'][^>]*>/i',
            function ($matches) {
                $img_tag = $matches[0];
                $src = $matches[1];

                $validated = $this->validate_image_url($src);

                if ($validated !== $src) {
                    return str_replace($src, $validated, $img_tag);
                }

                return $img_tag;
            },
            $html
        );
    }

    /**
     * Tokenize source visuals in idea_text
     * 
     * Hides <img> tags from the AI and forces use of [VISUAL_N] tokens.
     * Enforces a hard limit of 15 images pre-generation.
     *
     * Phase 2: smart-select top-N (default 15) rather than first-N.
     *
     * @since 2.10.0
     * @param array $input_data
     * @return array
     */
    private function tokenize_source_visuals(array $input_data): array
    {
        if (empty($input_data['idea_text'])) {
            return $input_data;
        }

        $vertical = (string) ($input_data['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz'));

        // Persona hard caps (do not allow UI overrides).
        // @MODIFIED 2026-02-19 - fashion_pk: keep first 15 visuals in source order. showbiz_pk: keep first 10 in source order.
        if ($vertical === 'fashion_pk') {
            $limit = 15;
            $mode  = 'legacy'; // first-N, preserves source order for placement
        } elseif ($vertical === 'showbiz_pk') {
            $limit = 10;
            $mode  = 'legacy'; // first-N, preserves source order for placement
        } else {
            // Admin-controlled cap (kept ~15 by default)
            $limit = (int) get_option('dit_ts_media_visual_limit', 15);
            $limit = max(1, min(30, $limit));

            // Selection mode (legacy keeps old behavior if needed)
            $mode = (string) get_option('dit_ts_media_selection_mode', 'smart');
            $mode = in_array($mode, ['smart', 'legacy'], true) ? $mode : 'smart';
        }

        if ($vertical === 'fashion_pk' || $vertical === 'showbiz_pk') {
            $this->logger->info('Persona media cap override', [
                'vertical' => $vertical,
                'limit'    => $limit,
                'mode'     => $mode,
            ]);
        }

        if ($mode === 'legacy') {
            // @MODIFIED 2026-05-06 - Phase 3: Extract heading/context for rich visual_map.
            // Legacy first-N now extracts heading and context for each <img> so PromptBuilder
            // sends semantic signal to the AI instead of empty descriptions.
            // @MODIFIED 2026-06-25 - Dimension-aware selection: sort by height desc before taking first-N.
            // Ensures tallest images (celebracy photos) are tokenized, not comment screenshots.
            $original_html = (string) $input_data['idea_text'];
            $visual_map = [];

            $inv = null;
            if (class_exists('DIT\\TrendStudio\\Services\\Media_Inventory')) {
                $inv = new \DIT\TrendStudio\Services\Media_Inventory($this->logger);
            }

            // Phase 1: find all <img> tags with positions, extract height for sorting
            $img_matches = [];
            preg_match_all(
                '/(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>)/i',
                $original_html,
                $img_matches,
                PREG_OFFSET_CAPTURE
            );

            $is_persona = (strpos($vertical, 'showbiz') !== false || strpos($vertical, 'fashion') !== false);

            if (!empty($img_matches[0])) {
                // Collect all candidates with height for sorting
                $all_candidates = [];
                for ($i = 0; $i < count($img_matches[0]); $i++) {
                    $tag_full = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($img_matches[1][$i][0] ?? '');
                    $raw_url  = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($img_matches[2][$i][0] ?? '');
                    $pos      = (int) ($img_matches[0][$i][1] ?? 0);

                    if ($tag_full === '' || $raw_url === '') {
                        continue;
                    }

                    // Extract height from <img> tag for dimension-aware sorting
                    $height = 0;
                    if (preg_match('/\bheight=["\'](\d+)["\']/i', $tag_full, $hm)) {
                        $height = (int) $hm[1];
                    }

                    $all_candidates[] = [
                        'src_index' => $i,
                        'tag'       => $tag_full,
                        'url'       => $raw_url,
                        'pos'       => $pos,
                        'height'    => $height,
                    ];
                }

                // Sort by height descending for persona verticals (tallest first)
                if ($is_persona && count($all_candidates) > $limit) {
                    usort($all_candidates, static function ($a, $b) {
                        return ($b['height'] ?? 0) <=> ($a['height'] ?? 0);
                    });
                    $this->logger->info('Legacy tokenization: dimension-aware sort applied', [
                        'vertical' => $vertical,
                        'total'    => count($all_candidates),
                        'limit'    => $limit,
                        'top_heights' => array_slice(array_column($all_candidates, 'height'), 0, $limit),
                    ]);
                }

                // Take top-N candidates (sorted by height if persona, else source order)
                $selected = array_slice($all_candidates, 0, $limit);
                // Re-sort selected by original source order for consistent token placement
                usort($selected, static function ($a, $b) {
                    return ($a['pos'] ?? 0) <=> ($b['pos'] ?? 0);
                });

                // Phase 2: extract context and build visual_map for selected candidates
                foreach ($selected as $idx => $cand) {
                    $tag_full = $cand['tag'];
                    $raw_url  = $cand['url'];
                    $pos      = $cand['pos'];

                    // Extract heading before this image
                    $before_html = substr($original_html, 0, $pos);
                    $heading     = '';
                    $heading_lvl = 0;
                    if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\\1>/is', $before_html, $hm)) {
                        $last_idx    = count($hm[0]) - 1;
                        $heading_lvl = (int) ($hm[1][$last_idx] ?? 0);
                        $heading     = trim((string) wp_strip_all_tags((string) ($hm[2][$last_idx] ?? '')));
                        $heading     = preg_replace('/\s+/', ' ', $heading);
                    }

                    // Context: look backward up to previous <img> boundary
                    $prev_img_pos = strrpos(substr($original_html, 0, $pos - 1), '<img');
                    $ctx_start = ($prev_img_pos !== false) ? $prev_img_pos + 1 : max(0, $pos - 300);
                    $ctx_start = max(0, $ctx_start);
                    $ctx_end   = min(strlen($original_html), $pos + strlen($tag_full) + 200);
                    $context   = substr($original_html, $ctx_start, $ctx_end - $ctx_start);
                    $context   = trim((string) wp_strip_all_tags((string) $context));
                    $context   = preg_replace('/\s+/', ' ', $context);
                    if (strlen($context) > 320) {
                        $context = substr($context, 0, 320);
                    }

                    // Preceding <p> text
                    $preceding_p = '';
                    if (preg_match('/<p[^>]*>(.*?)<\/p>\s*$/is', substr($original_html, 0, $pos), $p_m)) {
                        $preceding_p = trim((string) wp_strip_all_tags((string) ($p_m[1] ?? '')));
                        $preceding_p = preg_replace('/\s+/', ' ', $preceding_p);
                        if (strlen($preceding_p) > 160) {
                            $preceding_p = substr($preceding_p, 0, 160);
                        }
                    }

                    $token = "[VISUAL_{$idx}]";
                    $attachment_id = 0;
                    if ($inv) {
                        $attachment_id = (int) $inv->resolve_attachment_id_from_url($raw_url, (int) ($input_data['idea_id'] ?? 0));
                    }

                    $alt = '';
                    if (preg_match('/alt=["\']([^"\'\\\\]*)["\']/i', $tag_full, $alt_m)) {
                        $alt = $alt_m[1];
                    }

                    $visual_map[$token] = [
                        'url'           => $raw_url,
                        'tag'           => $tag_full,
                        'alt'           => $alt,
                        'type'          => 'image',
                        'attachment_id' => $attachment_id,
                        'heading'       => $heading,
                        'heading_lvl'   => $heading_lvl,
                        'context'       => $context,
                        'preceding_p'   => $preceding_p,
                    ];
                }

                // Phase 3: replace <img> tags with tokens in source order.
                // Selected images get [VISUAL_N] tokens; excess images are stripped.
                // Use source order index (src_index) since preg_replace_callback doesn't provide offset.
                $selected_src_indices = array_flip(array_column($selected, 'src_index'));
                $counter = 0;
                $src_counter = 0;
                $input_data['idea_text'] = preg_replace_callback(
                    '/(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>)/i',
                    function ($m) use (&$counter, &$src_counter, $limit, $selected_src_indices) {
                        if ($counter >= $limit) {
                            $src_counter++;
                            return '';
                        }
                        if (isset($selected_src_indices[$src_counter])) {
                            $token = "[VISUAL_{$counter}]";
                            $counter++;
                            $src_counter++;
                            return $token;
                        }
                        // Not selected — strip the tag
                        $src_counter++;
                        return '';
                    },
                    $original_html
                );
            }

            if (!empty($visual_map)) {
                $input_data['source_visual_map'] = $visual_map;
                $this->logger->info('Tokenized source visuals (legacy)', [
                    'vertical' => $vertical,
                    'limit'    => $limit,
                    'count'    => count($visual_map),
                ]);
            }

            return $input_data;
        }

        $res = MediaSelector::tokenize_images((string) $input_data['idea_text'], $limit, $vertical);

        $input_data['idea_text'] = (string) ($res['html'] ?? $input_data['idea_text']);

        $visual_map = (array) ($res['visual_map'] ?? []);
        if (!empty($visual_map)) {
            $input_data['source_visual_map'] = $visual_map;
        }

        $stats = (array) ($res['stats'] ?? []);
        $this->logger->info('Tokenized source visuals (smart)', [
            'vertical'    => $vertical,
            'limit'       => $limit,
            'candidates'  => (int) ($stats['candidates'] ?? 0),
            'selected'    => (int) ($stats['selected'] ?? 0),
        ]);

        return $input_data;
    }

    /**
     * Swap [VISUAL_N] tokens in AI response back to actual URLs/tags
     * @MODIFIED 2026-03-09 - Changed to public for Middleware access.
     */
    public function swap_visual_tokens_back(array $ai_response, array $input_data): array
    {
        if (empty($input_data['source_visual_map'])) {
            return $ai_response;
        }

        $map = $input_data['source_visual_map'];

        // @MODIFIED 2026-02-17 - Phase 4.1.1: In structured_blocks mode, never inject <img>.
        $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
        if ($pmode === 'structured_blocks') {
            $ai_response['_source_visual_map'] = $map;

            array_walk_recursive($ai_response, function (&$value) {
                if (!is_string($value) || $value === '') {
                    return;
                }
                $value = preg_replace('/\[(?:SOURCE_)?VISUAL_\d+\]/i', '', $value);
            });

            return $ai_response;
        }

        // Recursive walker to ensure tokens are replaced in sections, story_narrative, help text, etc.
        array_walk_recursive($ai_response, function (&$value) use ($map) {
            // @MODIFIED 2026-02-15 - Protect against non-string values more explicitly
            if (!is_string($value) || empty($value)) {
                return;
            }

            $value = preg_replace_callback('/\[(?:SOURCE_)?VISUAL_(\d+)\]/i', function ($m) use ($map) {
                $index = (int) $m[1];
                $token = "[VISUAL_{$index}]"; // Standardize on [VISUAL_N] for lookup

                if (isset($map[$token])) {
                    $tag = (string) $map[$token]['tag'];

                    // @MODIFIED 2026-02-16 - Normalizing to bare <img> to prevent wrapper leakage.
                    if (stripos($tag, '<img') !== false && !preg_match('/^\s*<img\b/i', $tag)) {
                        if (preg_match('/<img\b[^>]*>/i', $tag, $im)) {
                            $tag = $im[0];
                        }
                    }

                    // Preserve token identity for MediaMatcher deterministic alignment
                    if (stripos($tag, '<img') !== false && stripos($tag, 'data-dit-visual=') === false) {
                        $tag = preg_replace('/<img\b/i', '<img data-dit-visual="' . $index . '"', $tag, 1);
                    }

                    // @MODIFIED 2026-05-06 - Include preceding_p for richer semantic hint signal
                    $hint_raw = trim(
                        (string) (($map[$token]['heading'] ?? '') . ' ' . ($map[$token]['context'] ?? '') . ' ' . ($map[$token]['preceding_p'] ?? '') . ' ' . ($map[$token]['alt'] ?? ''))
                    );
                    if ($hint_raw !== '') {
                        $hint_raw = wp_strip_all_tags($hint_raw);
                        $hint_raw = preg_replace('/\s+/', ' ', (string) $hint_raw);
                        if (strlen($hint_raw) > 160) $hint_raw = substr($hint_raw, 0, 160);

                        if ($hint_raw !== '' && stripos($tag, 'data-dit-hint=') === false) {
                            $tag = preg_replace('/<img\b/i', '<img data-dit-hint="' . esc_attr($hint_raw) . '"', $tag, 1);
                        }
                    }

                    return $tag;
                }

                // LOG ORPHAN: AI hallucinated a token (Issue #AuditOrphans)
                if (defined('WP_DEBUG') && \WP_DEBUG) {
                    error_log("TrendStudio ContentPipeline: Orphan token detected: " . $m[0]);
                }
                return ''; // Strip orphan
            }, $value);
        });

        return $ai_response;
    }

    /**
     * Get image width and height from a URL.
     *
     * Resolution order:
     *  1. WP attachment metadata (fastest, local images)
     *  2. [0, 0] if unavailable
     *
     * @param string $url Full image URL.
     * @return array{0: int, 1: int} [width, height]
     */
    private function get_image_dimensions_from_url(string $url): array
    {
        $att_id = (int) attachment_url_to_postid($url);
        if ($att_id > 0) {
            $meta = wp_get_attachment_metadata($att_id);
            if (is_array($meta) && !empty($meta['width']) && !empty($meta['height'])) {
                return [(int) $meta['width'], (int) $meta['height']];
            }
        }
        return [0, 0];
    }
}
