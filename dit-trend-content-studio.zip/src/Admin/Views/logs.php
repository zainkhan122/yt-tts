<?php
/**
 * Error Logs View
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2026-05-31 - Added sidebar with log file browser, search, level filter, pagination
 */

if (!defined('ABSPATH')) {
    exit;
}

$logger     = \DIT\TrendStudio\Core\Plugin::get_instance()->get_logger();
$log_files  = $logger->get_available_log_files();
$today      = date('Y-m-d');
$first_file = !empty($log_files) ? $log_files[0]['filename'] : ('dit-ts-' . $today . '.log');
?>

<div class="wrap dit-ts-admin dit-ts-logs-page">
    <h1 class="wp-heading-inline"><?php esc_html_e('Error Logs', 'dit-trend-content-studio'); ?></h1>
    <hr class="wp-header-end">

    <div class="dit-ts-logs-layout">

        <!-- Sidebar: Log file browser -->
        <div class="dit-ts-logs-sidebar">
            <div class="dit-ts-logs-sidebar-header">
                <h2><?php esc_html_e('Available Logs', 'dit-trend-content-studio'); ?></h2>
                <span class="dit-ts-log-count"><?php echo esc_html(count($log_files)); ?></span>
            </div>

            <?php if (empty($log_files)): ?>
            <div class="notice notice-info inline" style="margin:10px;">
                <p><?php esc_html_e('No log files found.', 'dit-trend-content-studio'); ?></p>
            </div>
            <?php else: ?>
            <ul class="dit-ts-log-file-list" id="dit-ts-log-file-list">
                <?php foreach ($log_files as $idx => $file): ?>
                <li class="dit-ts-log-file-item<?php echo $idx === 0 ? ' active' : ''; ?>"
                    data-file="<?php echo esc_attr($file['filename']); ?>"
                    data-size="<?php echo esc_attr($file['size']); ?>">
                    <span class="dit-ts-log-file-name">
                        <span class="dashicons dashicons-media-text"></span>
                        <?php echo esc_html($file['date']); ?>
                    </span>
                    <span class="dit-ts-log-file-meta">
                        <?php echo esc_html(size_format($file['size'])); ?>
                    </span>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>

            <div class="dit-ts-logs-sidebar-actions">
                <button type="button" class="button button-small" id="dit-ts-clear-logs" title="<?php esc_attr_e('Delete ALL log files', 'dit-trend-content-studio'); ?>">
                    <span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px;vertical-align:middle;margin-top:-2px;"></span>
                    <?php esc_html_e('Clear All', 'dit-trend-content-studio'); ?>
                </button>
                <button type="button" class="button button-small" id="dit-ts-clear-archived" title="<?php esc_attr_e('Delete all logs except today', 'dit-trend-content-studio'); ?>">
                    <span class="dashicons dashicons-archive" style="font-size:14px;width:14px;height:14px;vertical-align:middle;margin-top:-2px;"></span>
                    <?php esc_html_e('Clear Archived', 'dit-trend-content-studio'); ?>
                </button>
                <a href="#" class="button button-small dit-ts-download-btn" id="dit-ts-download-log" target="_blank">
                    <span class="dashicons dashicons-download" style="font-size:14px;width:14px;height:14px;vertical-align:middle;margin-top:-2px;"></span>
                    <?php esc_html_e('Download', 'dit-trend-content-studio'); ?>
                </a>
            </div>

            <p class="description" style="padding: 8px 12px 0; margin:0; font-size:11px; color:#888;">
                <?php esc_html_e('Logs auto-delete after 3 days.', 'dit-trend-content-studio'); ?>
            </p>
        </div>

        <!-- Main content: Log viewer -->
        <div class="dit-ts-logs-main">

            <!-- Toolbar -->
            <div class="dit-ts-logs-toolbar">
                <div class="dit-ts-logs-toolbar-left">
                    <span id="dit-ts-current-file-name" class="dit-ts-current-file"><?php echo esc_html($first_file); ?></span>
                    <span id="dit-ts-log-stats" class="dit-ts-log-stats"></span>
                </div>
                <div class="dit-ts-logs-toolbar-right">
                    <select id="dit-ts-level-filter" class="dit-ts-filter-select">
                        <option value="ALL"><?php esc_html_e('All Levels', 'dit-trend-content-studio'); ?></option>
                        <option value="ERROR">ERROR</option>
                        <option value="WARNING">WARNING</option>
                        <option value="INFO">INFO</option>
                        <option value="DEBUG">DEBUG</option>
                    </select>
                    <input type="text" id="dit-ts-log-search" class="dit-ts-search-input" placeholder="<?php esc_attr_e('Search logs…', 'dit-trend-content-studio'); ?>" />
                </div>
            </div>

            <!-- Log table -->
            <div class="dit-ts-logs-table-wrap">
                <table class="wp-list-table widefat fixed striped dit-ts-logs-table">
                    <thead>
                        <tr>
                            <th style="width: 50px;"><?php esc_html_e('#', 'dit-trend-content-studio'); ?></th>
                            <th style="width: 140px;"><?php esc_html_e('Time', 'dit-trend-content-studio'); ?></th>
                            <th style="width: 80px;"><?php esc_html_e('Level', 'dit-trend-content-studio'); ?></th>
                            <th><?php esc_html_e('Message', 'dit-trend-content-studio'); ?></th>
                            <th style="width: 70px;"><?php esc_html_e('Details', 'dit-trend-content-studio'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="dit-ts-log-tbody">
                        <tr>
                            <td colspan="5" class="dit-ts-logs-loading">
                                <span class="spinner is-active" style="float:none;"></span>
                                <?php esc_html_e('Loading…', 'dit-trend-content-studio'); ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Empty state (hidden by default) -->
            <div id="dit-ts-logs-empty" class="notice notice-info inline hidden" style="margin-top:15px;">
                <p><?php esc_html_e('No log entries match your filters.', 'dit-trend-content-studio'); ?></p>
            </div>

            <!-- Pagination -->
            <div class="dit-ts-logs-pagination tablenav bottom" id="dit-ts-logs-pagination">
                <div class="tablenav-pages">
                    <span class="displaying-num" id="dit-ts-pagination-info"></span>
                    <span class="pagination-links">
                        <button type="button" class="button first-page" disabled title="<?php esc_attr_e('First page', 'dit-trend-content-studio'); ?>">&laquo;</button>
                        <button type="button" class="button prev-page" disabled title="<?php esc_attr_e('Previous page', 'dit-trend-content-studio'); ?>">&lsaquo;</button>
                        <span class="paging-input">
                            <input type="text" id="dit-ts-page-input" class="current-page" value="1" size="3" aria-describedby="table-paging" />
                            <?php esc_html_e('of', 'dit-trend-content-studio'); ?> <span class="total-pages" id="dit-ts-total-pages">1</span>
                        </span>
                        <button type="button" class="button next-page" disabled title="<?php esc_attr_e('Next page', 'dit-trend-content-studio'); ?>">&rsaquo;</button>
                        <button type="button" class="button last-page" disabled title="<?php esc_attr_e('Last page', 'dit-trend-content-studio'); ?>">&raquo;</button>
                    </span>
                </div>
                <div class="dit-ts-per-page">
                    <label for="dit-ts-per-page-select"><?php esc_html_e('Per page:', 'dit-trend-content-studio'); ?></label>
                    <select id="dit-ts-per-page-select">
                        <option value="50">50</option>
                        <option value="100">100</option>
                        <option value="200" selected>200</option>
                        <option value="500">500</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Site debug.log Viewer -->
    <hr style="margin-top:30px;">
    <h2 class="title" style="margin-top:20px;"><?php esc_html_e('Site debug.log Viewer', 'dit-trend-content-studio'); ?></h2>

    <form method="post" class="dit-ts-debug-log-path-form" style="margin-bottom:15px;">
        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><label for="dit-ts-debug-log-path"><?php esc_html_e('debug.log Path', 'dit-trend-content-studio'); ?></label></th>
                <td>
                    <input type="text" id="dit-ts-debug-log-path" name="dit_ts_debug_log_path" value="<?php echo esc_attr(get_option('dit_ts_debug_log_path', '')); ?>" class="regular-text code" placeholder="<?php esc_attr_e('/absolute/path/to/debug.log', 'dit-trend-content-studio'); ?>" />
                    <p class="description"><?php esc_html_e('Absolute server path to your WordPress debug.log file. Example: /web/logs/mysite/debug.log', 'dit-trend-content-studio'); ?></p>
                </td>
            </tr>
        </table>
        <?php wp_nonce_field('dit_ts_save_debug_log_path', 'dit_ts_debug_log_path_nonce'); ?>
        <button type="submit" class="button button-secondary" name="dit_ts_save_debug_log_path_btn" value="1"><?php esc_html_e('Save Path &amp; Load', 'dit-trend-content-studio'); ?></button>
        <?php if (get_option('dit_ts_debug_log_path')): ?>
        <a href="<?php echo esc_url(add_query_arg(['action' => 'dit_ts_download_debug_log', 'nonce' => wp_create_nonce('dit_ts_nonce')], admin_url('admin-ajax.php'))); ?>" class="button button-secondary" style="margin-left:10px;">
            <?php esc_html_e('Download debug.log', 'dit-trend-content-studio'); ?>
        </a>
        <?php endif; ?>
    </form>
</div>
