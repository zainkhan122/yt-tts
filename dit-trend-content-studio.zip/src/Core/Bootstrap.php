<?php

/**
 * Plugin Installer
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator
 */

namespace DIT\TrendStudio\Core;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin Installer/Bootstrap
 */
class Bootstrap
{
    /**
     * Database version
     *
     * @var string
     */
    const DB_VERSION = '1.1.3';

    /**
     * Run on plugin activation
     *
     * @return void
     */
	public static function activate()
	{
		// Create database tables
		self::create_tables();
		\DIT\TrendStudio\Database\Queue_Table::install();

		// Register custom post types (needs to be done before flush)
		self::register_post_types();

		// Set default options
		self::set_default_options();

		self::register_urdu_fonts_system();

        // @MODIFIED 2026-02-23 - Migration: Fix legacy branding "Daily InfoTainment" -> "DailyInfoTainment.Com"
        self::migrate_branding();

        // @MODIFIED 2026-04-25 - Migration: Simplify strategy values to 4-provider model
        self::migrate_strategy_simplification();

        // @MODIFIED 2026-04-30 - Migration: Convert flat custom provider options to structured providers array
        self::migrate_custom_providers();

        // Store current version
		update_option('dit_ts_version', DIT_TS_VERSION);
		update_option('dit_ts_db_version', self::DB_VERSION);

		// Set activation timestamp for uptime tracking
		if (!get_option('dit_ts_activated_timestamp', false)) {
			update_option('dit_ts_activated_timestamp', time(), false);
		}

		// Flush rewrite rules
		flush_rewrite_rules();
	}

    /**
     * Run on plugin deactivation
     * @MODIFIED 2025-12-13 - Fixed action name from 'dit_ts_import_ideas' to 'dit_ts_scheduled_import'
     *
     * @return void
     */
    public static function deactivate()
    {
        // Clear scheduled actions
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('dit_ts_process_job');
            as_unschedule_all_actions('dit_ts_scheduled_import');
            as_unschedule_all_actions('dit_ts_process_social_queue');
            // @MODIFIED 2026-06-01 - Unschedule the publish watchdog (recovers missed-schedule posts)
            as_unschedule_all_actions('dit_ts_publish_due_posts');
// @ADDED 2026-07-12 - Unschedule the OpenRouter free-model auto-sync on deactivation
            if (class_exists('DIT\\TrendStudio\\Services\\OpenRouterModelSync')) {
                as_unschedule_all_actions(
                    \DIT\TrendStudio\Services\OpenRouterModelSync::ACTION_HOOK,
                    array(),
                    \DIT\TrendStudio\Services\OpenRouterModelSync::AS_GROUP
                );
            } else {
                // Fallback hook string (the class may not load on deactivation flow)
                as_unschedule_all_actions('dit_ts_sync_openrouter_models');
            }

            // @ADDED 2026-07-17 - Unschedule the OpenCode Zen free-model auto-sync on deactivation
            if (class_exists('DIT\\TrendStudio\\Services\\OpenCodeZenModelSync')) {
                as_unschedule_all_actions(
                    \DIT\TrendStudio\Services\OpenCodeZenModelSync::ACTION_HOOK,
                    array(),
                    \DIT\TrendStudio\Services\OpenCodeZenModelSync::AS_GROUP
                );
            } else {
                // Fallback hook string (the class may not load on deactivation flow)
                as_unschedule_all_actions('dit_ts_sync_opencode_models');
            }
        }

 	// @MODIFIED 2026-02-24 - Clear WP-Cron fallbacks scheduled by Core\Plugin.
		wp_clear_scheduled_hook('dit_ts_cleanup_orphans');
		$cron_hook = 'dit_ts_process_social_queue';
		if (class_exists(\DIT\TrendStudio\Core\Social_Bootstrap::class, false)) {
			$cron_hook = \DIT\TrendStudio\Core\Social_Bootstrap::CRON_HOOK;
		} elseif (defined('DIT_TS_PLUGIN_DIR') && file_exists(DIT_TS_PLUGIN_DIR . 'src/Core/Social_Bootstrap.php')) {
			require_once DIT_TS_PLUGIN_DIR . 'src/Core/Social_Bootstrap.php';
			$cron_hook = \DIT\TrendStudio\Core\Social_Bootstrap::CRON_HOOK;
		}
	wp_clear_scheduled_hook($cron_hook);
	wp_clear_scheduled_hook('dit_ts_social_cleanup_cron');
	wp_clear_scheduled_hook('dit_ts_daily_cleanup');
	wp_clear_scheduled_hook('dit_ts_job_watchdog');
	wp_clear_scheduled_hook('dit_ts_scheduled_import');

        // @MODIFIED 2026-05-05 - Clear all quota pause state on deactivation
        // to prevent stale pauses from blocking publishing on reactivation.
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            $providers_to_clear = ['gemini', 'custom'];

            // Also clear pauses for any registered custom providers
            $custom_providers = get_option('dit_ts_custom_providers', []);
            if (is_string($custom_providers)) {
                $custom_providers = json_decode($custom_providers, true);
            }
            if (is_array($custom_providers)) {
                foreach ($custom_providers as $cp) {
                    $cp_id = isset($cp['id']) ? sanitize_key((string) $cp['id']) : '';
                    if ($cp_id !== '' && !in_array($cp_id, $providers_to_clear, true)) {
                        $providers_to_clear[] = $cp_id;
                    }
                }
            }

            foreach ($providers_to_clear as $provider) {
                \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::clear($provider);
            }
        }
	// Clear circuit breaker and quota state transients
        // @MODIFIED 2026-07-03 - Clear all Buffer account caches
        $buffer_accounts = \DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_accounts();
        foreach ($buffer_accounts as $acc_id => $account) {
            delete_transient('nm_buffer_org_id_' . $acc_id);
        }
        if (isset($GLOBALS['wpdb'])) {
            global $wpdb;
            $patterns = [
                $wpdb->esc_like('_transient_dit_ts_') . '%_circuit_%',
                $wpdb->esc_like('_transient_dit_ts_') . '%_quota_%',
                $wpdb->esc_like('dit_ts_') . '%_circuit_%',
                $wpdb->esc_like('_transient_nm_buffer_channels_') . '%',
                $wpdb->esc_like('_transient_nm_buffer_pinterest_boards_') . '%',
                $wpdb->esc_like('_transient_nm_buffer_org_id_') . '%',
            ];
            $placeholders = implode(' OR option_name LIKE ', array_fill(0, count($patterns), '%s'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE {$placeholders}",
                ...$patterns
            ));
        }
        delete_option('dit_ts_buffer_accounts');

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Register custom post types
     * @MODIFIED 2025-12-13 - Added dit_idea CPT for idea inbox
     *
     * @return void
     */
    public static function register_post_types()
    {
        // Idea Inbox CPT (admin-only, not public)
        register_post_type('dit_idea', array(
            'labels' => array(
                'name' => __('Ideas', 'dit-trend-content-studio'),
                'singular_name' => __('Idea', 'dit-trend-content-studio'),
                'add_new' => __('Add New', 'dit-trend-content-studio'),
                'add_new_item' => __('Add New Idea', 'dit-trend-content-studio'),
                'edit_item' => __('Edit Idea', 'dit-trend-content-studio'),
                'new_item' => __('New Idea', 'dit-trend-content-studio'),
                'view_item' => __('View Idea', 'dit-trend-content-studio'),
                'search_items' => __('Search Ideas', 'dit-trend-content-studio'),
                'not_found' => __('No ideas found', 'dit-trend-content-studio'),
                'not_found_in_trash' => __('No ideas found in Trash', 'dit-trend-content-studio'),
            ),
            'public' => true,   // @MODIFIED 2026-01-25 - True so WP Automatic can see it
            'publicly_queryable' => false, // Keep it hidden from frontend
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_menu' => false,
            'show_in_rest' => true, // Enable Block Editor support
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'has_archive' => false,
            'rewrite' => false,
            'query_var' => false,
        ));
    }

    /**
     * Create database tables
     *
     * @return void
     */
    private static function create_tables()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Table for generation jobs
        $jobs_table = $wpdb->prefix . 'dit_ts_jobs';
        // @MODIFIED 2026-01-30 - Added post_id column for dashboard linking
        $jobs_sql = "CREATE TABLE IF NOT EXISTS {$jobs_table} (
id BIGINT UNSIGNED AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
post_id BIGINT UNSIGNED DEFAULT NULL,
job_type VARCHAR(50) DEFAULT 'generation',
status VARCHAR(50) DEFAULT 'pending',
input_data LONGTEXT,
output_data LONGTEXT,
validation_results LONGTEXT,
error_message TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
completed_at DATETIME,
PRIMARY KEY (id),
INDEX idx_user_status (user_id, status),
INDEX idx_job_type (job_type),
INDEX idx_created (created_at),
INDEX idx_post_id (post_id),
INDEX idx_updated (updated_at)
) {$charset_collate} ENGINE=InnoDB;";

        // @MODIFIED 2026-03-07 - Table for social metadata (Urdu text + review state)
        $social_meta_table = $wpdb->prefix . 'dit_ts_social_meta';
        $social_meta_sql = "CREATE TABLE IF NOT EXISTS {$social_meta_table} (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            urdu_heading TEXT,
            urdu_description TEXT,
            hashtags TEXT,
            image_path VARCHAR(255),
            status VARCHAR(20) DEFAULT 'pending',
            selected_image_ids TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_post_id (post_id),
            INDEX idx_status (status),
            INDEX idx_created (created_at)
        ) {$charset_collate} ENGINE=InnoDB;";

        // Execute table creation
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($jobs_sql);
        dbDelta($social_meta_sql);
    }

    /**
     * Set default plugin options
     * @MODIFIED 2025-12-27 - Added strict inline citations default ON
     *
     * @return void
     */
    private static function set_default_options()
    {
        $defaults = array(
            'dit_ts_gemini_api_key' => '',
            'dit_ts_rss_feeds' => '',           // One URL per line
            'dit_ts_pinterest_token' => '',           // Optional
            'dit_ts_pinterest_boards' => '',           // Board IDs, comma-separated
            'dit_ts_import_schedule' => 'daily',      // hourly, daily, manual
            'dit_ts_default_category' => '',
            'dit_ts_default_tags' => array(),
            'dit_ts_content_vertical' => 'showbiz',    // showbiz, fashion, beauty
            'dit_ts_enable_logging' => true,
            'dit_ts_strict_inline_citations' => true,  // Editorial integrity mode ON by default
            'dit_ts_worker_limit' => 1,                // Default to 1 concurrent worker
            'dit_ts_enable_draft_cleanup' => false,    // Automated draft cleanup OFF by default
            'dit_ts_draft_cleanup_age_days' => 7,      // 7 days retention
	'dit_ts_draft_cleanup_delete_media' => false, // Don't delete media by default
	'dit_ts_social_cleanup_age_days' => 14, // 14 days social asset retention
    'dit_ts_enable_social_collage' => false,
    'dit_ts_collage_bottom_text' => 'DailyInfoTainment.Com',
        'dit_ts_collage_retina' => true,
        // @MODIFIED 2026-04-20 - Social Collage Aesthetics Defaults
        'dit_ts_social_font' => 'NotoNastaliqUrdu-Regular.ttf',
        'dit_ts_social_heading_bg' => '#0f1c34',
        'dit_ts_social_heading_color' => '#ffffff',
        'dit_ts_social_desc_bg' => '#500f19',
		'dit_ts_social_desc_color' => '#ffffff',
		// @ADDED 2026-04-24 - Site debug.log viewer path
		'dit_ts_debug_log_path' => '',
        // @ADDED 2026-04-25 - Custom Provider defaults
        'dit_ts_custom_api_key' => '',
        'dit_ts_custom_api_url' => '',
        'dit_ts_custom_model' => 'glm-4',
        'dit_ts_custom_model_custom' => '',
        // @ADDED 2026-04-30 - DeepSeek integration defaults (kept for BC / migration)
        'dit_ts_deepseek_api_key' => '',
        'dit_ts_deepseek_model' => 'deepseek-chat',
        // @ADDED 2026-04-30 - Structured custom provider system defaults
        'dit_ts_custom_providers' => [],
        'dit_ts_custom_default_provider' => '',
	'dit_ts_custom_fallback_config' => [
            'enable_model_fallback' => true,
            'enable_cross_provider_fallback' => false,
            'enable_universal_fallback' => false,
            'cross_provider_order' => [],
        ],
        // @MODIFIED 2026-07-03 - Buffer Integration defaults (multi-account)
        'dit_ts_buffer_accounts' => [],
	'dit_ts_dashboard_api_key' => '',
	);

        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                add_option($key, $value);
            }
        }
    }

    /**
     * Check if database needs upgrade
     *
     * @return bool
     */
    public static function needs_upgrade()
    {
        $current_version = get_option('dit_ts_db_version', '0.0.0');
        return version_compare($current_version, self::DB_VERSION, '<');
    }

    /**
     * Upgrade database if needed
     *
     * @return void
     */
    public static function upgrade()
    {
        if (self::needs_upgrade()) {
            self::create_tables();

            // Call Queue_Table install for schema migrations (lock_token column)
            \DIT\TrendStudio\Database\Queue_Table::install();

		// @MODIFIED 2026-02-23 - Migration: Fix legacy branding "Daily InfoTainment" -> "DailyInfoTainment.Com"
		self::migrate_branding();

        // @MODIFIED 2026-04-25 - Migration: Simplify strategy values to 4-provider model
        self::migrate_strategy_simplification();

        // @MODIFIED 2026-04-30 - Migration: Convert flat custom provider options to structured providers array
        self::migrate_custom_providers();

        // @MODIFIED 2026-05-08 - Migration: Add updated_at column to dit_ts_jobs for heartbeat tracking.
        // Self-healing queries rely on updated_at to detect stale/zombie jobs.
        global $wpdb;
        $jobs_table = $wpdb->prefix . 'dit_ts_jobs';
        // INFORMATION_SCHEMA queries can fail on some hosts (privileges, case sensitivity).
        // Use SHOW COLUMNS instead — it's more reliable and doesn't require extra privileges.
        $has_updated_at = $wpdb->get_results("SHOW COLUMNS FROM {$jobs_table} LIKE 'updated_at'");
        if (empty($has_updated_at)) {
            $wpdb->query("ALTER TABLE {$jobs_table} ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
            $wpdb->query("ALTER TABLE {$jobs_table} ADD INDEX idx_updated (updated_at)");
        }

        update_option('dit_ts_db_version', self::DB_VERSION);
        } else {
            // @MODIFIED 2026-06-01 - Defensive self-healing check: Ensure updated_at column is present even if DB version is up-to-date.
            // Running SHOW COLUMNS is rate-limited via transient to run at most once a day.
            if (false === get_transient('dit_ts_checked_jobs_schema')) {
                global $wpdb;
                $jobs_table = $wpdb->prefix . 'dit_ts_jobs';
                $has_updated_at = $wpdb->get_results("SHOW COLUMNS FROM {$jobs_table} LIKE 'updated_at'");
                if (empty($has_updated_at)) {
                    $wpdb->query("ALTER TABLE {$jobs_table} ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
                    $wpdb->query("ALTER TABLE {$jobs_table} ADD INDEX idx_updated (updated_at)");
                }
                set_transient('dit_ts_checked_jobs_schema', '1', DAY_IN_SECONDS);
            }
        }
    }

    /**
     * Migrate legacy branding strings in database settings
     *
     * @return void
     */
    private static function migrate_branding()
    {
        $current = (string) get_option('dit_ts_collage_bottom_text');

        // Legacy "Daily InfoTainment" or "Daily InfoTainment "
		if (trim($current) === 'Daily InfoTainment') {
			update_option('dit_ts_collage_bottom_text', 'DailyInfoTainment.Com');
		}
	}

	/**
	 * Migrate legacy AI strategy values to simplified 2-provider model.
	 *
	 * Maps old composite/deepseek/perplexity strategies to gemini/custom.
	 * Also maps old openrouter/groq strategies to gemini (those providers are
	 * no longer available as standalone, they are configurable via Custom Providers).
	 * Also migrates campaign-level strategy values stored in dit_ts_campaigns JSON.
	 *
	 * @since 2.28.0
	 * @return void
	 */
	public static function migrate_strategy_simplification()
	{
		$migrated = get_option('dit_ts_strategy_simplification_migrated', false);
		if ($migrated) {
			return;
		}

		$legacy_map = [
			'composite' => 'gemini',
			'gemini_only' => 'gemini',
			'composite_openrouter' => 'gemini',
			'openrouter_only' => 'gemini',
			'openrouter_primary' => 'gemini',
			'openrouter' => 'gemini',
			'composite_groq' => 'gemini',
			'groq_only' => 'gemini',
			'groq' => 'gemini',
		'composite_deepseek' => 'custom',
		'deepseek_only' => 'custom',
		'deepseek' => 'custom',
		'perplexity_only' => 'gemini',
		];

		// Migrate global strategy option
		$current = (string) get_option('dit_ts_ai_strategy', 'gemini');
		if (isset($legacy_map[$current])) {
			update_option('dit_ts_ai_strategy', $legacy_map[$current]);
		}

		// Migrate campaign-level strategies
		$campaigns = get_option('dit_ts_campaigns', []);
		if (is_array($campaigns)) {
			$dirty = false;
			foreach ($campaigns as &$campaign) {
				if (!empty($campaign['strategy']) && isset($legacy_map[$campaign['strategy']])) {
					$campaign['strategy'] = $legacy_map[$campaign['strategy']];
					$dirty = true;
				}
			}
			if ($dirty) {
				update_option('dit_ts_campaigns', $campaigns);
			}
		}

		update_option('dit_ts_strategy_simplification_migrated', '1');
	}

    public static function migrate_custom_providers(): void
    {
        $migrated = get_option('dit_ts_custom_providers_migrated', false);
        if ($migrated) {
            return;
        }

        $existing_providers = get_option('dit_ts_custom_providers', []);
        if (is_string($existing_providers)) {
            $existing_providers = json_decode($existing_providers, true);
        }
        if (!is_array($existing_providers)) {
            $existing_providers = [];
        }

        $providers = [];

        // Migrate flat custom provider options
        $old_key = (string) get_option('dit_ts_custom_api_key', '');
        $old_url = (string) get_option('dit_ts_custom_api_url', '');
        $old_model = (string) get_option('dit_ts_custom_model', 'glm-4');
        $old_model_custom = (string) get_option('dit_ts_custom_model_custom', '');

        if ($old_key !== '' || $old_url !== '') {
            $model_id = $old_model_custom !== '' ? $old_model_custom : $old_model;
            $providers[] = [
                'id' => 'custom-legacy',
                'name' => 'Custom Provider (Migrated)',
                'api_url' => $old_url,
                'api_key' => $old_key,
                'enable_web_search' => false,
                'web_search_config' => ['type' => 'none', 'search_engine' => 'search_pro', 'search_count' => 10],
                'models' => [
                    ['display_name' => $model_id, 'model_id' => $model_id],
                ],
                'fallback_enabled' => false,
            ];
        }

        // Migrate DeepSeek options into a provider profile
        $deepseek_key = (string) get_option('dit_ts_deepseek_api_key', '');
        if ($deepseek_key !== '') {
            $deepseek_model = (string) get_option('dit_ts_deepseek_model', 'deepseek-chat');
            $providers[] = [
                'id' => 'deepseek',
                'name' => 'DeepSeek (Migrated)',
                'api_url' => 'https://api.deepseek.com/v1',
                'api_key' => $deepseek_key,
                'enable_web_search' => false,
                'web_search_config' => ['type' => 'none', 'search_engine' => 'search_pro', 'search_count' => 10],
                'models' => [
                    ['display_name' => 'DeepSeek Chat', 'model_id' => 'deepseek-chat'],
                    ['display_name' => 'DeepSeek Reasoner', 'model_id' => 'deepseek-reasoner'],
                ],
                'fallback_enabled' => false,
            ];
        }

        // Merge with any existing structured providers (do not overwrite manual edits)
        if (!empty($existing_providers)) {
            $existing_ids = array_map(function ($p) { return $p['id'] ?? ''; }, $existing_providers);
            foreach ($providers as $new) {
                if (!in_array($new['id'], $existing_ids, true)) {
                    $existing_providers[] = $new;
                }
            }
            $providers = $existing_providers;
        }

        if (!empty($providers)) {
            update_option('dit_ts_custom_providers', $providers);
        }

        if (class_exists('\DIT\TrendStudio\Infrastructure\AI_Provider_Factory')) {
            \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::clear_custom_providers_cache();
        }

        // Set default provider if not set
        $default_provider = get_option('dit_ts_custom_default_provider', '');
        if ($default_provider === '' && !empty($providers)) {
            update_option('dit_ts_custom_default_provider', $providers[0]['id'] ?? '');
        }

        // Set fallback config defaults if not set
        $fallback_config = get_option('dit_ts_custom_fallback_config', []);
        if (!is_array($fallback_config) || empty($fallback_config)) {
            update_option('dit_ts_custom_fallback_config', [
                'enable_model_fallback' => true,
                'enable_cross_provider_fallback' => false,
                'enable_universal_fallback' => false,
                'cross_provider_order' => [],
            ]);
        }

        update_option('dit_ts_custom_providers_migrated', '1');
    }

    public static function register_urdu_fonts_system(): void
	{
		if (DIRECTORY_SEPARATOR === '\\') {
			return;
		}

		if (!defined('DIT_TS_PLUGIN_DIR')) {
			return;
		}

		$font_dir  = DIT_TS_PLUGIN_DIR . 'assets/fonts/';
		$conf_dir  = '/usr/local/share/fonts/dit-trendstudio';
		$conf_file = '/etc/fonts/conf.d/99-dit-trendstudio.conf';

		if (!is_dir($font_dir) || !is_readable($font_dir)) {
			return;
		}

		$urdu_fonts = glob($font_dir . '*Nastaliq*.ttf') ?: glob($font_dir . '*Urdu*.ttf') ?: [];
		if (empty($urdu_fonts)) {
			$urdu_fonts = glob($font_dir . '*.ttf') ?: [];
		}
		if (empty($urdu_fonts)) {
			return;
		}

		if (!is_dir($conf_dir)) {
			@mkdir($conf_dir, 0755, true);
		}

		$copied = false;
		foreach ($urdu_fonts as $src) {
			$dst = $conf_dir . '/' . basename($src);
			if (!file_exists($dst) || md5_file($src) !== md5_file($dst)) {
				if (@copy($src, $dst)) {
					@chmod($dst, 0644);
					$copied = true;
				}
			}
		}

		$fontconf_xml = '<?xml version="1.0"?>' . "\n"
			. '<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">' . "\n"
			. '<fontconfig>' . "\n"
			. '  <dir>' . $conf_dir . '</dir>' . "\n"
			. '</fontconfig>' . "\n";

		if (!file_exists($conf_file) || file_get_contents($conf_file) !== $fontconf_xml) {
			@file_put_contents($conf_file, $fontconf_xml);
			$copied = true;
		}

        if ($copied && function_exists('exec') && !in_array('exec', array_map('trim', explode(',', ini_get('disable_functions') . ',' . ini_get('suhosin.executor.func.blacklist'))), true)) {
            @exec('fc-cache -fv 2>/dev/null');
        }
	}
}
