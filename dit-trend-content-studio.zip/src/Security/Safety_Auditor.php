<?php

/**
 * Safety Auditor Module
 * 
 * Scans content for defamation risks and adult content to ensure magazine compliance.
 *
 * @package DIT_TrendStudio\Security
 * @since   1.4.0
 * @MODIFIED 2025-12-18 - Initial implementation for Phase 7.
 */

namespace DIT\TrendStudio\Security;

use DIT\TrendStudio\Schema\Content_Schema;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Analyzes article safety and compliance.
 */
class Safety_Auditor
{
    /**
     * Terminology that often signals defamation risk or unverified claims.
     */
    private const DEFAMATION_RISK_TERMS = [
        'alleged',
        'rumored',
        'scandal',
        'drug abuse',
        'affair',
        'arrested',
        'lawsuit',
        'fraud',
        'cheating',
        'bankrupt',
    ];

    /**
     * Adult/NSFW terms to flag for standard lifestyle vertical compliance.
     */
    private const NSFW_TERMS = [
        'naked',
        'explicit',
        'uncensored',
        'leaked video',
        'adult scene',
        'nsfw',
        'erotic',
    ];

    /**
     * Audit safety and compliance.
     *
     * @param Content_Schema $schema
     * @return array
     */
    public function audit(Content_Schema $schema): array
    {
        $issues = [];
        $pts_lost = 0;

        $body_html = '';
        foreach ($schema->sections as $section) {
            $body_html .= ' ' . $section['body_html'];
        }
        $full_text = wp_strip_all_tags($body_html);

        // 1. Defamation Risk Check
        $defamation_matches = [];
        foreach (self::DEFAMATION_RISK_TERMS as $term) {
            if (stripos($full_text, $term) !== false) {
                $defamation_matches[] = $term;
            }
        }

        if (!empty($defamation_matches)) {
            $issues[] = sprintf(
                'Defamation Risk: Detected sensitive terminology (%s). Ensure these claims are grounded in authoritative sources.',
                implode(', ', array_slice($defamation_matches, 0, 3))
            );
            $pts_lost += 15; // Heavy penalty for legal risk
        }

        // 2. NSFW/Adult content check
        $nsfw_matches = [];
        foreach (self::NSFW_TERMS as $term) {
            if (stripos($full_text, $term) !== false) {
                $nsfw_matches[] = $term;
            }
        }

        if (!empty($nsfw_matches)) {
            $issues[] = sprintf(
                'Compliance: Content contains potential NSFW keywords (%s). Verify before publishing.',
                implode(', ', array_slice($nsfw_matches, 0, 3))
            );
            $pts_lost += 25; // Critical penalty for brand safety
        }

        return [
            'issues'   => $issues,
            'pts_lost' => $pts_lost,
        ];
    }
}
