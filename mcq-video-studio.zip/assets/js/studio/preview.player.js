(function (window) {
  'use strict';

  /**
   * MCQVS_PreviewPlayer
   * Render loop orchestration (play/stop/scrub).
   * Owns RAF. Delegates timebase to MCQVS_TimelineEngine.
   */
  class MCQVS_PreviewPlayer {
    constructor(opts) {
      this._controller = opts && opts.controller ? opts.controller : null;
      this._timeline = opts && opts.timelineEngine ? opts.timelineEngine : null;
      this._raf = 0;
      this._running = false;
    }

    isRunning() {
      return !!this._running;
    }

    play() {
      if (!this._controller || !this._timeline) return;
      this.stop();
      this._running = true;
      const perf = (window.performance && typeof window.performance.now === 'function') ? window.performance.now() : Date.now();
      this._timeline.start(perf);
      this._tick();
    }

    stop() {
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = 0;
      }
      this._running = false;
      if (this._timeline) this._timeline.stop();
      if (this._controller) this._controller.state.animationId = null;
    }

    /**
     * Scrub without starting the RAF loop.
     */
    scrubTo(timelineMs) {
      if (!this._controller || !this._timeline) return;
      this.stop();
      this._timeline.seek(Number(timelineMs) || 0);
      this._controller._renderAt(this._timeline.now((window.performance && window.performance.now) ? window.performance.now() : Date.now()), true);
    }

    _tick() {
      if (!this._running || !this._controller || !this._timeline) return;

      const perf = (window.performance && typeof window.performance.now === 'function') ? window.performance.now() : Date.now();
      const timelineMs = this._timeline.now(perf);

      this._controller._renderAt(timelineMs, false);

      // Mirror RAF id into controller state (used by other code paths)
      this._raf = requestAnimationFrame(() => this._tick());
      this._controller.state.animationId = this._raf;
    }
  }

  window.MCQVS_PreviewPlayer = MCQVS_PreviewPlayer;
})(window);
