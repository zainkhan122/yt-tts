<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APIErrorParser {

	public static function parse( string $provider, int $http_code = 0, string $body = '', string $raw_message = '' ): APIErrorInfo {
		if ( empty( $body ) && ! empty( $raw_message ) && preg_match( '/:\s*(\{.+)/', $raw_message, $bm ) ) {
			$body = $bm[1];
		}

		if ( $provider === Config::PROVIDER_GEMINI ) {
			return self::parse_gemini( $http_code, $body );
		}

		return self::parse_generic( $provider, $http_code, $body, $raw_message );
	}

	public static function parse_wp_error( string $provider, \WP_Error $wp_error ): APIErrorInfo {
		$message = $wp_error->get_error_message();
		$error_lower = strtolower( $message );

		if ( strpos( $error_lower, 'curl error 28' ) !== false ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $message, $provider );
		}
		if ( strpos( $error_lower, 'timed out' ) !== false || strpos( $error_lower, 'timeout' ) !== false ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $message, $provider );
		}
		if ( strpos( $error_lower, 'connection refused' ) !== false || strpos( $error_lower, 'connection error' ) !== false ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_SERVER_OVERLOADED, $message, $provider );
		}
		if ( strpos( $error_lower, 'dns' ) !== false || strpos( $error_lower, 'resolve' ) !== false ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $message, $provider );
		}

		return new APIErrorInfo( APIErrorInfo::TYPE_UNKNOWN, $message, $provider );
	}

	private static function parse_gemini( int $http_code, string $body ): APIErrorInfo {
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			return self::parse_generic( Config::PROVIDER_GEMINI, $http_code, $body );
		}

		$error = $data['error'] ?? [];
		$status = $error['status'] ?? '';
		$message = $error['message'] ?? '';
		$details = $error['details'] ?? [];

		$raw = "Gemini HTTP {$http_code}: {$status} — {$message}";

		if ( $http_code === 429 || $status === 'RESOURCE_EXHAUSTED' ) {
			$error_info = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_UNKNOWN, $raw, Config::PROVIDER_GEMINI );

			foreach ( $details as $detail ) {
				$detail_type = $detail['@type'] ?? '';

				if ( strpos( $detail_type, 'QuotaFailure' ) !== false ) {
					$violations = $detail['violations'] ?? [];
					foreach ( $violations as $violation ) {
						$subject = $violation['subject'] ?? '';
						$quota_id = $violation['quotaId'] ?? '';
						$quota_metric = $violation['quotaMetric'] ?? '';
						$identifier = strtolower( $subject . ' ' . $quota_id . ' ' . $quota_metric );

						if ( strpos( $identifier, 'requests_per_day' ) !== false || strpos( $identifier, 'perday' ) !== false || strpos( $identifier, 'per_day' ) !== false ) {
							$error_info->error_type = APIErrorInfo::TYPE_QUOTA_RPD;
							$error_info->is_retryable = true;
							$error_info->is_deterministic = false;
							break;
						}
						if ( strpos( $identifier, 'requests_per_minute' ) !== false || strpos( $identifier, 'perminute' ) !== false || strpos( $identifier, 'per_minute' ) !== false ) {
							$error_info->error_type = APIErrorInfo::TYPE_QUOTA_RPM;
							break;
						}
						if ( strpos( $identifier, 'tokens_per_minute' ) !== false || strpos( $identifier, 'tokensperminute' ) !== false ) {
							$error_info->error_type = APIErrorInfo::TYPE_QUOTA_TPM;
							break;
						}
					}
				}

				if ( strpos( $detail_type, 'RetryInfo' ) !== false ) {
					$retry_delay = $detail['retryDelay'] ?? '';
					if ( preg_match( '/(\d+(?:\.\d+)?)/', $retry_delay, $m ) ) {
						$error_info->retry_after = (int) ceil( (float) $m[1] );
					}
				}
			}

			if ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_RPD ) {
				$error_info->reset_at = self::gemini_next_rpd_reset_ts();
			} elseif ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_RPM ) {
				// RPM errors don't have a reset timestamp - they reset after the window
			}

			return $error_info;
		}

		if ( in_array( $http_code, [ 500, 502, 503, 529 ], true ) || $status === 'UNAVAILABLE' || $status === 'INTERNAL' ) {
			$error_info = new APIErrorInfo( APIErrorInfo::TYPE_SERVER_OVERLOADED, $raw, Config::PROVIDER_GEMINI );

			foreach ( $details as $detail ) {
				if ( strpos( $detail['@type'] ?? '', 'RetryInfo' ) !== false ) {
					$retry_delay = $detail['retryDelay'] ?? '';
					if ( preg_match( '/(\d+(?:\.\d+)?)/', $retry_delay, $m ) ) {
						$error_info->retry_after = (int) ceil( (float) $m[1] );
					}
				}
			}

			return $error_info;
		}

		if ( $http_code === 401 || $http_code === 403 ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_AUTH_FAILURE, $raw, Config::PROVIDER_GEMINI );
		}

		if ( $http_code === 404 ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_MODEL_NOT_FOUND, $raw, Config::PROVIDER_GEMINI );
		}

		if ( in_array( $http_code, [ 400, 422 ], true ) ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_REQUEST_SHAPE, $raw, Config::PROVIDER_GEMINI );
		}

		if ( $http_code === 408 || $http_code === 504 ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $raw, Config::PROVIDER_GEMINI );
		}

		return new APIErrorInfo( APIErrorInfo::TYPE_UNKNOWN, $raw, Config::PROVIDER_GEMINI );
	}

	private static function parse_generic( string $provider, int $http_code, string $body, string $raw_message = '' ): APIErrorInfo {
		$raw = $raw_message ?: "HTTP {$http_code}: " . mb_substr( $body, 0, 200 );

		// Detect connection-level failures (cURL errors) when http_code is 0.
		// These are always transient and should NOT be classified as TYPE_UNKNOWN
		// because TYPE_UNKNOWN is non-retryable and breaks the entire fallback chain.
		if ( $http_code === 0 && ! empty( $raw_message ) ) {
			$msg_lower = strtolower( $raw_message );
			if ( strpos( $msg_lower, 'curl error 28' ) !== false ||
				 strpos( $msg_lower, 'timed out' ) !== false ||
				 strpos( $msg_lower, 'timeout' ) !== false ||
				 strpos( $msg_lower, 'connection error' ) !== false ||
				 strpos( $msg_lower, 'connection refused' ) !== false ||
				 strpos( $msg_lower, 'connection reset' ) !== false ||
				 strpos( $msg_lower, 'dns' ) !== false ||
				 strpos( $msg_lower, 'resolve' ) !== false ) {
				return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $raw, $provider );
			}
		}

		if ( $http_code === 429 ) {
			$error_info = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_UNKNOWN, $raw, $provider );

			$data = json_decode( $body, true );
			if ( is_array( $data ) ) {
				$error_msg = strtolower( $data['error']['message'] ?? $data['message'] ?? $data['error'] ?? '' );

				if ( strpos( $error_msg, 'per day' ) !== false || strpos( $error_msg, 'daily' ) !== false ) {
					$error_info->error_type = APIErrorInfo::TYPE_QUOTA_RPD;
				} elseif ( strpos( $error_msg, 'per minute' ) !== false || strpos( $error_msg, 'rpm' ) !== false ) {
					$error_info->error_type = APIErrorInfo::TYPE_QUOTA_RPM;
				} elseif ( strpos( $error_msg, 'token' ) !== false || strpos( $error_msg, 'tpm' ) !== false ) {
					$error_info->error_type = APIErrorInfo::TYPE_QUOTA_TPM;
				}
			}

			return $error_info;
		}

		if ( in_array( $http_code, [ 401, 403 ], true ) ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_AUTH_FAILURE, $raw, $provider );
		}

		if ( $http_code === 404 ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_MODEL_NOT_FOUND, $raw, $provider );
		}

		if ( in_array( $http_code, [ 400, 422 ], true ) ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_REQUEST_SHAPE, $raw, $provider );
		}

		if ( in_array( $http_code, [ 500, 502, 503, 529 ], true ) ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_SERVER_OVERLOADED, $raw, $provider );
		}

		if ( in_array( $http_code, [ 408, 504 ], true ) ) {
			return new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, $raw, $provider );
		}

		return new APIErrorInfo( APIErrorInfo::TYPE_UNKNOWN, $raw, $provider );
	}

	private static function gemini_next_rpd_reset_ts(): int {
		$pt = new \DateTimeZone( 'America/Los_Angeles' );
		$now = ( new \DateTimeImmutable( 'now', $pt ) );
		$next = $now->modify( 'tomorrow' )->setTime( 0, 0, 0 );
		return (int) $next->getTimestamp();
	}
}
