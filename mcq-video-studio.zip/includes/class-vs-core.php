<?php

/**
 * Video Studio Manager
 *
 * Integrates the Quiz Shorts Studio into the WP Admin.
 * Handles the Studio page rendering and data fetching via AJAX.
 *
 * @package MCQ_Video_Studio
 * @version 1.0
 */

if (! defined('ABSPATH')) {
	exit;
}

class VS_Core
{


	private static $instance = null;

	// @NEW 2026-01-05: Functional clusters for delegating AJAX logic
	// @MODIFIED 2026-02-25: Changed to public for VS_Smoke_Test visibility
	public $studio_handler;
	public $ai_quiz_handler;
	public $tts_handler;
	public $ai_tools_handler;
	public $asset_handler;
	public $stock_handler;
	public $branding_handler;
	public $content_planner;
	public $batch_handler; // @FIX: Defined to avoid dynamic property deprecation
	public $cover_handler; // @NEW 2026-07-30: Video Cover editor

	public static function init()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct()
	{
		if (!get_option('mcqvs_did_core_init_log')) {
			error_log('MCQVS: VS_Core constructor started');
			update_option('mcqvs_did_core_init_log', '1', 'no');
		}

		// @NEW 2026-01-18: Initialize Logger Hooks (Unified Telemetry System)
		VS_Error_Logger::get_instance()->init();

		// @MODIFIED 2026-01-05: Delegate logic to specialized handlers
		$this->studio_handler    = VS_AJAX_Studio_Handler::get_instance();
		$this->ai_quiz_handler   = VS_AJAX_AI_Quiz_Handler::get_instance();
		$this->tts_handler       = VS_AJAX_TTS_Handler::get_instance();
		$this->ai_tools_handler  = VS_AJAX_AI_Tools_Handler::get_instance();
		$this->asset_handler     = VS_AJAX_Asset_Handler::get_instance();
		$this->stock_handler     = VS_AJAX_Stock_Handler::get_instance();
		$this->batch_handler     = VS_AJAX_Batch_Handler::get_instance();
		$this->branding_handler  = VS_AJAX_Branding_Handler::get_instance();
		// @NEW 2026: Register the Pexels stock search AJAX verb that was previously orphaned.
		add_action('wp_ajax_mcqvs_search_stock_videos', array($this->stock_handler, 'ajax_search_stock_videos'));
		// @NEW 2026-02-16: Content Planner
		require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-content-planner.php';
		$this->content_planner   = VS_Content_Planner::get_instance();

		add_action('admin_menu', array($this, 'add_menu_page'), 20);
		add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
		// @MODIFIED 2026-02-25: Fixed bindings to use handler instances instead of $this
		// @NEW 2025-12-18: Data Fetching and Sources
		add_action('wp_ajax_mcqvs_get_studio_sources', array($this->studio_handler, 'ajax_get_studio_sources'));
		add_action('wp_ajax_mcqvs_get_studio_data', array($this->studio_handler, 'ajax_get_studio_data'));

		// @NEW: Server-side AI Handlers
		add_action('wp_ajax_mcqvs_generate_ai_quiz', array($this->ai_quiz_handler, 'ajax_generate_ai_quiz'));
		// @NEW 2025-12-19: AI News-Based Quiz Generator
		add_action('wp_ajax_mcqvs_generate_news_quiz', array($this->ai_quiz_handler, 'ajax_generate_news_quiz'));
		// @NEW 2026-01-17: Direct Topic Quiz Generator
		add_action('wp_ajax_mcqvs_generate_topic_quiz', array($this->ai_quiz_handler, 'ajax_generate_topic_quiz'));
		add_action('wp_ajax_mcqvs_generate_tts', array($this->tts_handler, 'ajax_generate_tts'));
		// @NEW 2025-12-17: AI Hook Generator
		add_action('wp_ajax_mcqvs_generate_hooks', array($this->ai_tools_handler, 'ajax_generate_hooks'));
		// @NEW 2025-12-18: SEO Metadata Generator
		add_action('wp_ajax_mcqvs_generate_seo', array($this->ai_tools_handler, 'ajax_generate_seo'));

		// @NEW 2025-12-18: Asset Library Persistence
		add_action('wp_ajax_mcqvs_save_studio_assets', array($this->asset_handler, 'ajax_save_studio_assets'));
		add_action('wp_ajax_mcqvs_get_studio_assets', array($this->asset_handler, 'ajax_get_studio_assets'));

		// @NEW 2025-12-18: TTS Settings Persistence
		// @FIX: Route to the handler that owns `ajax_save_tts_settings` (`VS_AJAX_Asset_Handler`).
		//       Previously misbound to `VS_AJAX_TTS_Handler` which never defined the method → fatal.
		add_action('wp_ajax_mcqvs_save_tts_settings', array($this->asset_handler, 'ajax_save_tts_settings'));

		// @NEW 2025-12-18: AI Background Generation
		add_action('wp_ajax_mcqvs_generate_ai_background', array($this->ai_tools_handler, 'ajax_generate_ai_background'));

		// @NEW 2025-12-18: ElevenLabs Handlers
		add_action('wp_ajax_mcqvs_generate_elevenlabs_tts', array($this->tts_handler, 'ajax_generate_elevenlabs_tts'));
		add_action('wp_ajax_mcqvs_get_elevenlabs_voices', array($this->tts_handler, 'ajax_get_elevenlabs_voices'));

		// @NEW 2025-12-18: FFmpeg & Fast Merge Handlers
		add_action('wp_ajax_mcqvs_check_ffmpeg', array($this->batch_handler, 'ajax_check_ffmpeg'));
		// @REMOVED 2026: `mcqvs_fast_merge_video` was bound to a method that was never defined
		//               (`VS_AJAX_Batch_Handler::ajax_fast_merge_video` does not exist) → PHP fatal.
		//               The whole batch handler class is deprecated; client-only FFmpeg.wasm is the
		//               sole render path now. Re-add the binding ONLY if you implement the method.

		// @NEW 2026-01-10: Asset Proxy for COEP compliance
		add_action('wp_ajax_mcqvs_proxy_asset', array($this, 'ajax_proxy_asset'));

		// @NEW 2026-01-30: Persist Self-Test result for activation gate + admin notices
		add_action('wp_ajax_mcqvs_save_selftest_report', array($this, 'ajax_save_selftest_report'));

		// @MODIFIED 2026-01-10: Removed server-side batch rendering AJAX actions
		// Client-only FFmpeg.wasm export is now the sole rendering path
		// Kept: ajax_check_ffmpeg (for diagnostics), ajax_fast_merge_video
		// Removed: mcqvs_start_batch_job, mcqvs_upload_frame_chunk, mcqvs_process_batch_job,
		//          mcqvs_get_job_status, mcqvs_pause_batch_job, mcqvs_resume_batch_job, mcqvs_cancel_batch_job

		// @NEW 2025-12-19: Branding Persistence
		add_action('wp_ajax_mcqvs_save_branding', array($this->branding_handler, 'ajax_save_branding'));
		add_action('wp_ajax_mcqvs_get_branding', array($this->branding_handler, 'ajax_get_branding'));
		// @NEW 2026-08-10: Branding Logo upload (Assets tab) — copies image into plugin assets folder
		add_action('wp_ajax_mcqvs_upload_branding_logo', array($this->branding_handler, 'ajax_upload_branding_logo'));
		add_action('wp_ajax_mcqvs_remove_branding_logo', array($this->branding_handler, 'ajax_remove_branding_logo'));
		add_action('wp_ajax_mcqvs_save_branding_position', array($this->branding_handler, 'ajax_save_branding_position'));

		// @NEW 2026-07-30: Video Cover Image Handler
		require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-cover-handler.php';
		$this->cover_handler = VS_AJAX_Cover_Handler::get_instance();
		add_action('wp_ajax_mcqvs_save_cover_config', array($this->cover_handler, 'ajax_save_cover_config'));
		add_action('wp_ajax_mcqvs_get_cover_config', array($this->cover_handler, 'ajax_get_cover_config'));

		// @NEW 2026-01-10: Project CRUD (DB-stored projects)
		add_action('wp_ajax_mcqvs_save_project', array($this, 'ajax_save_project'));
		add_action('wp_ajax_mcqvs_load_project', array($this, 'ajax_load_project'));
		add_action('wp_ajax_mcqvs_list_projects', array($this, 'ajax_list_projects'));
		add_action('wp_ajax_mcqvs_delete_project', array($this, 'ajax_delete_project'));

		// @NEW 2026-02-08: Content Calendar Endpoints
		add_action('wp_ajax_mcqvs_bulk_schedule', array($this, 'ajax_bulk_schedule'));
		add_action('wp_ajax_mcqvs_list_calendar_jobs', array($this, 'ajax_list_calendar_jobs'));
		add_action('wp_ajax_mcqvs_get_calendar_job', array($this, 'ajax_get_calendar_job'));
		add_action('wp_ajax_mcqvs_delete_calendar_job', array($this, 'ajax_delete_calendar_job'));
		// @NEW 2026-02-16: Content Planner Endpoints
		add_action('wp_ajax_mcqvs_generate_topic_plan', array($this->content_planner, 'ajax_generate_topic_plan'));
		add_action('wp_ajax_mcqvs_save_topic_plan', array($this->content_planner, 'ajax_save_topic_plan'));
		add_action('wp_ajax_mcqvs_approve_topic_plan', array($this->content_planner, 'ajax_approve_topic_plan'));

		// @NEW 2026-02-16: Auto-Runner Endpoints (Delegated to Job Repository / Content Planner)
		// For simplicity, we can route these through Content Planner or new Job Repo methods if they existed as AJAX handlers.
		// Content Planner is a good place for "Process Management".
        add_action('wp_ajax_mcqvs_get_next_pending_job', array($this->content_planner, 'ajax_get_next_pending_job'));
        add_action('wp_ajax_mcqvs_update_job_status', array($this->content_planner, 'ajax_update_job_status'));
        add_action('wp_ajax_mcqvs_get_job_questions', array($this->content_planner, 'ajax_get_job_questions'));
        // @NEW 2026: Register previously-orphaned batch + apply-job-settings endpoints.
        add_action('wp_ajax_mcqvs_get_batch_status', array($this->content_planner, 'ajax_get_batch_status'));
        add_action('wp_ajax_mcqvs_apply_job_settings', array($this, 'ajax_apply_job_settings'));

        // @NEW 2026-04-22: Job status poll (for headless render service)
        add_action('wp_ajax_mcqvs_get_job_status', array($this, 'ajax_get_job_status'));

        // @NEW 2026-04-22: Headless render auth verification
        add_action('wp_ajax_nopriv_mcqvs_verify_render_auth', array($this, 'ajax_verify_render_auth'));

        // @NEW 2026-04-22: Test headless setup
        add_action('wp_ajax_mcqvs_test_headless', array($this, 'ajax_test_headless'));
        // @FIX 1.4.9.43 (self-sufficient): one-click "Setup Server Environment"
        // — provisions Node (portable download), canvas + ffmpeg-static (npm)
        // and verifies, all from the admin UI without SSH.
        add_action('wp_ajax_mcqvs_setup_environment', array($this, 'ajax_setup_environment'));

        // @NEW 2026-07-04 (F5): Manually trigger server-side render for a queued job
        add_action('wp_ajax_mcqvs_render_now', array($this, 'ajax_render_now'));

        // @NEW 2026-07-03: Orphan render process cleanup
        add_action('mcqvs_kill_orphan_render', array('VS_Headless_Renderer', 'kill_orphan_render'), 10, 2);
        // @FIX 2026-07-13: Early liveness probe — reaps instantly-dead renders ~30s after spawn
        add_action('mcqvs_render_liveness', array('VS_Headless_Renderer', 'reap_dead_render'), 10, 1);
        // @FIX CRITICAL: Cron-based orphan kill fallback — ensures orphaned renders are reaped
        // even if the AS queue isn't processed. Runs every 5 minutes as a safety net.
        add_action('mcqvs_orphan_kill_cron', array('VS_Headless_Renderer', 'cron_orphan_kill'), 10, 1);

	// @NEW 2026-02-23: Global video counter + BG video listing
	add_action('wp_ajax_mcqvs_increment_video_count', array($this, 'ajax_increment_video_count'));
	add_action('wp_ajax_mcqvs_list_bg_videos', array($this, 'ajax_list_bg_videos'));

	// @NEW 2026-04-24: Video Format Toggle (shorts/youtube)
	add_action('wp_ajax_mcqvs_save_video_format', array($this, 'ajax_save_video_format'));

		// @NEW 2026-01-09: Initialize Log Viewer
		VS_Log_Viewer::get_instance()->init();

		// @NEW 2026-01-27: Load Dedicated MCQ System Classes
		require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-job-repository.php';
		require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-mcq-repository.php';
		require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-validation-service.php';
        require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-action-scheduler-worker.php';
        require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-bridge-api.php';
        require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-headless-renderer.php';
        require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-video-url-handler.php';

        // Init Worker
        VS_Action_Scheduler_Worker::init();
 // Init Bridge
 VS_Bridge_API::init();
 // Init Video URL Handler (registers mcqvs_update_video_url + mcqvs_upload_to_r2 AJAX actions)
        VS_AJAX_Video_URL_Handler::init();

		// @NEW 2026-02-25: Initialize Smoke Test early to ensure AJAX action registration
		if (class_exists('VS_Smoke_Test')) {
			VS_Smoke_Test::init();
		}
	}

	/**
	 * Helper: Get versioned asset string
	 * @MODIFIED 2026-02-02: Use plugin version by default; switch to cache-busting only when MCQVS_DEV_MODE is true
	 * @return string Version string for wp_enqueue_*
	 */
	private function get_asset_version()
	{
		return MCQVS_DEV_MODE ? time() : MCQVS_VERSION;
	}

	/**
	 * Generate @font-face CSS with dynamic asset URL.
	 * Supports external assets location via mcqvs_assets_url().
	 */
	private function get_font_face_css()
	{
		$u = mcqvs_assets_url( 'fonts/' );
		return <<<CSS
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:500;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:800;font-style:normal;font-display:swap}
@font-face{font-family:'Inter';src:url({$u}Inter-Bold.ttf) format('truetype');font-weight:900;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:500;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:800;font-style:normal;font-display:swap}
@font-face{font-family:'Outfit';src:url({$u}Outfit-Bold.ttf) format('truetype');font-weight:900;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Bold.ttf) format('truetype');font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Bold.ttf) format('truetype');font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Bold.ttf) format('truetype');font-weight:500;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Bold.ttf) format('truetype');font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Black.ttf) format('truetype');font-weight:800;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto';src:url({$u}Roboto-Black.ttf) format('truetype');font-weight:900;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto Mono';src:url({$u}RobotoMono-Bold.ttf) format('truetype');font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Roboto Mono';src:url({$u}RobotoMono-Bold.ttf) format('truetype');font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'Bangers';src:url({$u}Bangers-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Permanent Marker';src:url({$u}PermanentMarker-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Orbitron';src:url({$u}Orbitron-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Press Start 2P';src:url({$u}PressStart2P-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Creepster';src:url({$u}Creepster-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Cinzel';src:url({$u}Cinzel-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Audiowide';src:url({$u}Audiowide-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Open Sans';src:url({$u}OpenSans-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Lato';src:url({$u}Lato-Bold.ttf);font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Lato';src:url({$u}Lato-Bold.ttf);font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:'Lato';src:url({$u}Lato-Bold.ttf);font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'Playfair Display';src:url({$u}PlayfairDisplay-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Quicksand';src:url({$u}Quicksand-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Rajdhani';src:url({$u}Rajdhani-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Electrolize';src:url({$u}Electrolize-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Exo 2';src:url({$u}Exo2-Regular.ttf) format('truetype');font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'Exo 2';src:url({$u}Exo2-Regular.ttf) format('truetype');font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'Nosifer';src:url({$u}Nosifer-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'VT323';src:url({$u}VT323-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Share Tech Mono';src:url({$u}ShareTechMono-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Patrick Hand';src:url({$u}PatrickHand-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'EB Garamond';src:url({$u}EBGaramond-Bold.ttf);font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:'EB Garamond';src:url({$u}EBGaramond-Bold.ttf);font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:'EB Garamond';src:url({$u}EBGaramond-Bold.ttf);font-weight:900;font-style:normal;font-display:swap}
@font-face{font-family:'Fira Code';src:url({$u}FiraCode-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'JetBrains Mono';src:url({$u}JetBrainsMono-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
@font-face{font-family:'Bebas Neue';src:url({$u}BebasNeue-Regular.ttf);font-weight:normal;font-style:normal;font-display:swap}
@font-face{font-family:'Oswald';src:url({$u}Oswald-Bold.ttf);font-weight:bold;font-style:normal;font-display:swap}
CSS;
	}

	/**
	 * Helper: Get option with legacy fallback
	 * Standardizes read logic: check 'mcqvs_' (canonical), then 'MCQVS_' (legacy)
	 */
	private function get_config_option($key_suffix, $default = '')
	{
		// Canonical (lowercase)
		$val = get_option('mcqvs_' . $key_suffix);
		if ($val !== false && $val !== '') {
			return $val;
		}
		// Legacy (uppercase keys as formerly saved)
		return get_option('MCQVS_' . $key_suffix, $default);
	}

	/**
	 * Add "Video Studio" submenu
	 *
	 * @MODIFIED 2025-12-01: Added i18n support for menu strings
	 */
	public function add_menu_page()
	{
		// Top-level menu points to Dashboard
		add_menu_page(
			__('Video Studio', 'mcq-video-studio'),
			__('Video Studio', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-dashboard',
			array(VS_Settings::init(), 'render_dashboard_page'),
			'dashicons-video-alt3',
			50
		);

		// Dashboard submenu (same slug as parent — first submenu inherits parent highlight)
		add_submenu_page(
			'mcqvs-dashboard',
			__('Dashboard', 'mcq-video-studio'),
			__('Dashboard', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-dashboard',
			array(VS_Settings::init(), 'render_dashboard_page')
		);

		// Studio Editor
		add_submenu_page(
			'mcqvs-dashboard',
			__('Studio Editor', 'mcq-video-studio'),
			__('Studio Editor', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-editor',
			array($this, 'render_studio_page')
		);

		// @NEW (cross-file audit): Headless render-runner.
		//              A dedicated `admin.php?page=mcqvs-render` page used by `render.js`
		//              when invoked by the Action Scheduler headless pipeline. Loads ONLY
		//              the encoding modules (WebCodecs/Web Worker + PlanBuilder +
		//              TemplateManager + UnifiedRenderer + auto-runner bootstrap) and
		//              intentionally skips the full Studio UI bundle so Playwright can
		//              reach `domcontentloaded` without waiting for the entire WordPress
		//              admin chrome to finish loading. Not exposed as a submenu item —
		//              it is internal-only and not user-clickable.
		add_submenu_page(
			'',
			__('Render Runner', 'mcq-video-studio'),
			__('Render Runner', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-render',
			array($this, 'render_runner_page')
		);

		// Content Planner
		add_submenu_page(
			'mcqvs-dashboard',
			__('Content Planner', 'mcq-video-studio'),
			__('Content Planner', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-content-planner',
			array($this->content_planner, 'render_page')
		);

		// @FIX 1.5.0 (menu order): Video Scheduler placed immediately AFTER Content
		// Planner (per user request). Registered here (priority 20) so it lands in the
		// intended position; the scheduler class no longer self-registers to avoid a
		// duplicate item at the end of the menu.
		add_submenu_page(
			'mcqvs-dashboard',
			__('Video Scheduler', 'mcq-video-studio'),
			__('Video Scheduler', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-video-scheduler',
			array(VS_Video_Scheduler::init(), 'render_admin_page')
		);

		// Settings — all configuration tabs
		add_submenu_page(
			'mcqvs-dashboard',
			__('Settings', 'mcq-video-studio'),
			__('Settings', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-settings',
			array(VS_Settings::init(), 'render_settings_page')
		);

		// Error Logs — dedicated page
		add_submenu_page(
			'mcqvs-dashboard',
			__('Error Logs', 'mcq-video-studio'),
			__('Error Logs', 'mcq-video-studio'),
			'manage_options',
			'mcqvs-logs',
			array(VS_Log_Viewer::get_instance(), 'render_page')
		);
	}


	/**
	 * Render System Health Page
	 * 
	 * @param bool $is_tab Whether rendering as a tab inside Dashboard.
	 */
	public function render_system_health_page($is_tab = false)
	{
		if (! current_user_can('manage_options')) {
			wp_die(esc_html__('Access denied', 'mcq-video-studio'));
		}

		$active_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'server';

$current_subtab = 'client';
if (isset($_GET['subtab']) && !empty($_GET['subtab'])) {
$current_subtab = sanitize_text_field($_GET['subtab']);
} elseif (isset($_SERVER['REQUEST_URI'])) {
parse_str(parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY), $query_params);
if (isset($query_params['subtab'])) {
$current_subtab = sanitize_text_field($query_params['subtab']);
}
}
?>
		<div class="<?php echo $is_tab ? 'vs-tab-content' : 'wrap'; ?>" id="mcqvs-system-health-wrapper">
			<?php if (!$is_tab) : ?>
				<h1 class="wp-heading-inline"><?php echo esc_html__('🩺 System Health & Diagnostics', 'mcq-video-studio'); ?></h1>
				<hr class="wp-header-end">
			<?php endif; ?>

<nav class="nav-tab-wrapper" style="margin-bottom: 20px;">
<a href="?page=mcqvs-settings&tab=health&subtab=client" class="nav-tab <?php echo 'client' === $current_subtab ? 'nav-tab-active' : ''; ?>">
<?php esc_html_e('Client Self-Test', 'mcq-video-studio'); ?>
</a>
<a href="?page=mcqvs-settings&tab=health&subtab=server" class="nav-tab <?php echo 'server' === $current_subtab ? 'nav-tab-active' : ''; ?>">
<?php esc_html_e('Server Smoke Test', 'mcq-video-studio'); ?>
</a>
</nav>

<div class="mcqvs-health-tab-content">
<?php
if ('server' === $current_subtab) : ?>
<?php
if (class_exists('VS_Smoke_Test')) {
VS_Smoke_Test::init()->render_ui();
} else {
echo '<div class="notice notice-error"><p>' . esc_html__('Smoke Test Engine not loaded.', 'mcq-video-studio') . '</p></div>';
}
?>
<?php elseif ('client' === $current_subtab) : ?>
<?php
$this->render_self_test_content();
?>
<?php endif; ?>
</div>
 </div>
	<?php
	}
	public function enqueue_assets($hook)
	{
		// Only load assets on plugin admin pages
		if (!isset($_GET['page']) || !in_array($_GET['page'], array('mcqvs-dashboard', 'mcqvs-settings', 'mcqvs-logs', 'mcqvs-system-health', 'mcqvs-editor', 'mcqvs-content-planner', 'mcqvs-render'), true)) {
			return;
		}

		// @NEW 2025-12-19: Enable WordPress Media Library for logo upload
		wp_enqueue_media();

		// @MODIFIED 2026-01-20: Removed Google Fonts enqueue - using local fonts in assets/fonts/
		// Local fonts are loaded via @font-face in vs-video-studio.css



		// @MODIFIED 2026-01-20: Only enqueue ffmpeg-util.js (provides fetchFile utility for asset loading)
		// NOTE: ffmpeg.js (the encoder) is NOT needed - we use mp4-muxer for encoding
		$util_path = MCQVS_PLUGIN_URL . 'assets/js/ffmpeg/';
		wp_enqueue_script('mcqvs-ffmpeg-util', $util_path . 'ffmpeg-util.js', array(), $this->get_asset_version(), true);

		// @NEW 2025-12-19: JSZip for efficient frame uploads in server-side batch rendering
		wp_enqueue_script(
			'jszip',
			'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
			array(),
			'3.10.1',
			true
		);

		// @NEW 2025-12-01: Text Effects Library
		wp_enqueue_script(
			'mcqvs-text-effects',
			MCQVS_PLUGIN_URL . 'assets/js/vs-text-effects.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-17: Animation Engine
		wp_enqueue_script(
			'mcqvs-animation-engine',
			MCQVS_PLUGIN_URL . 'assets/js/vs-animation-engine.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-18: MP4 Muxer for WebCodecs Hardware Encoding
		wp_enqueue_script(
			'mcqvs-mp4-muxer',
			MCQVS_PLUGIN_URL . 'assets/js/mp4-muxer/mp4-muxer.min.js',
			array(),
			'5.1.3',
			true
		);

		// @NEW 2025-12-17: TTS Manager (Edge TTS, Google Cloud TTS, Web Speech API)
		wp_enqueue_script(
			'mcqvs-tts-manager',
			MCQVS_PLUGIN_URL . 'assets/js/vs-tts-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-17: Video Templates (17 professional templates)
		wp_enqueue_script(
			'mcqvs-video-templates',
			MCQVS_PLUGIN_URL . 'assets/js/vs-video-templates.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-17: Audio Manager (SFX, music, ducking)
		wp_enqueue_script(
			'mcqvs-audio-manager',
			MCQVS_PLUGIN_URL . 'assets/js/vs-audio-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// Studio CSS
		wp_enqueue_style(
			'mcqvs-video-studio-css',
			MCQVS_PLUGIN_URL . 'assets/css/vs-video-studio.css',
			array(),
			$this->get_asset_version()
		);

		// @NEW 2026-07-03: Dynamic @font-face with correct asset URL (supports external assets)
		wp_add_inline_style( 'mcqvs-video-studio-css', $this->get_font_face_css() );

		// @NEW 2025-12-17: Template Manager
		wp_enqueue_script(
			'mcqvs-template-manager',
			MCQVS_PLUGIN_URL . 'assets/js/vs-template-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-17: SEO Generator
		wp_enqueue_script(
			'mcqvs-seo-generator',
			MCQVS_PLUGIN_URL . 'assets/js/vs-seo-generator.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-18: Timeline Scrubber
		wp_enqueue_script(
			'mcqvs-timeline',
			MCQVS_PLUGIN_URL . 'assets/js/vs-timeline.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-18: Asset Library
		wp_enqueue_script(
			'mcqvs-asset-library',
			MCQVS_PLUGIN_URL . 'assets/js/vs-asset-library.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2025-12-18: AI Background Studio
		wp_enqueue_script(
			'mcqvs-ai-background-studio',
			MCQVS_PLUGIN_URL . 'assets/js/vs-ai-background-studio.js',
			array('jquery'),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-07-30: Video Cover Editor
		wp_enqueue_script(
			'mcqvs-cover-editor',
			MCQVS_PLUGIN_URL . 'assets/js/vs-cover-editor.js',
			array('jquery', 'mcqvs-studio-controller'),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-17: Timeline Logic Manager
		wp_enqueue_script(
			'mcqvs-timeline-manager',
			MCQVS_PLUGIN_URL . 'assets/js/class-vs-timeline-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-17: Resource Manager (Memory Safety)
		wp_enqueue_script(
			'mcqvs-resource-manager',
			MCQVS_PLUGIN_URL . 'assets/js/vs-resource-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-18: Toast Manager (UX Polish)
		wp_enqueue_script(
			'mcqvs-toast-manager',
			MCQVS_PLUGIN_URL . 'assets/js/vs-toast-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-18: Unified Telemetry Logger (Must load before Studio)
		wp_enqueue_script(
			'mcqvs-logger',
			MCQVS_PLUGIN_URL . 'assets/js/vs-logger.js',
			array('jquery'),
			$this->get_asset_version(),
			true
		);

		// @NEW 2026-01-25: Unified Renderer (Parity Engine)
		wp_enqueue_script(
			'mcqvs-unified-renderer',
			MCQVS_PLUGIN_URL . 'assets/js/vs-unified-renderer.js',
			array(),
			$this->get_asset_version(),
			true
		);


		// @NEW 2026-01-30: Core Render Pipeline (RenderPlan + Preflight + JobManager)
		wp_enqueue_script(
			'mcqvs-render-plan',
			MCQVS_PLUGIN_URL . 'assets/js/core/render-plan.js',
			array(),
			$this->get_asset_version(),
			true
		);
		wp_enqueue_script(
			'mcqvs-render-plan-validator',
			MCQVS_PLUGIN_URL . 'assets/js/core/render-plan-validator.js',
			array('mcqvs-render-plan'),
			$this->get_asset_version(),
			true
		);
		wp_enqueue_script(
			'mcqvs-asset-cache',
			MCQVS_PLUGIN_URL . 'assets/js/core/asset-cache.js',
			array(),
			$this->get_asset_version(),
			true
		);
		wp_enqueue_script(
			'mcqvs-preflight',
			MCQVS_PLUGIN_URL . 'assets/js/core/preflight.js',
			array('mcqvs-asset-cache', 'mcqvs-render-plan'),
			$this->get_asset_version(),
			true
		);
		wp_enqueue_script(
			'mcqvs-job-manager',
			MCQVS_PLUGIN_URL . 'assets/js/core/job-manager.js',
			array(),
			$this->get_asset_version(),
			true
		);
		wp_enqueue_script(
			'mcqvs-schema-validate',
			MCQVS_PLUGIN_URL . 'assets/js/core/schema-validate.js',
			array(),
			$this->get_asset_version(),
			true
		);

		wp_enqueue_script(
			'mcqvs-diagnostics',
			MCQVS_PLUGIN_URL . 'assets/js/core/diagnostics.js',
			array('mcqvs-render-plan', 'mcqvs-preflight', 'mcqvs-asset-cache', 'mcqvs-job-manager'),
			$this->get_asset_version(),
			true
		);

		$page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';

		// @NEW (cross-file audit): Headless render-runner asset bundle.
		//              When the page is `mcqvs-render`, enqueue ONLY the encoding
		//              modules + the tiny render-runner bootstrap. Do NOT load the
		//              Studio UI Bundle (`studio.controller.js`, `studio.ui.js`,
		//              `studio.export.js`, `studio.audio.js`, `studio.preview.js`,
		//              asset library, toast manager, …); they are unused by the
		//              headless encode pipeline and would re-introduce the very
		//              network surface that causes `networkidle` to time out.
		if ($page === 'mcqvs-render') {
			$version = $this->get_asset_version();
			$assets_url = MCQVS_PLUGIN_URL . 'assets/';

			// 1. Logger (kept; worker + export manager reference MCQVSLogger).
			wp_enqueue_script('mcqvs-studio-logger', $assets_url . 'js/studio/studio.logger.js', array(), $version, true);

			// 2. Encoding-only modules + their declared dependencies.
			//    Mirrors `importScripts(...)` from vs-render-worker.js dependencies
			//    + the encoding-plan build chain used by startExport().
			wp_enqueue_script('mcqvs-animation-engine', $assets_url . 'js/vs-animation-engine.js', array('mcqvs-studio-logger'), $version, true);
			wp_enqueue_script('mcqvs-video-templates', $assets_url . 'js/vs-video-templates.js', array(), $version, true);
			wp_enqueue_script('mcqvs-template-manager', $assets_url . 'js/vs-template-manager.js', array('mcqvs-video-templates', 'mcqvs-animation-engine'), $version, true);
			wp_enqueue_script('mcqvs-text-effects', $assets_url . 'js/vs-text-effects.js', array(), $version, true);
			wp_enqueue_script('mcqvs-unified-renderer', $assets_url . 'js/vs-unified-renderer.js', array('mcqvs-template-manager'), $version, true);
			wp_enqueue_script('mcqvs-render-plan', $assets_url . 'js/core/render-plan.js', array(), $version, true);
			wp_enqueue_script('mcqvs-render-plan-validator', $assets_url . 'js/core/render-plan-validator.js', array('mcqvs-render-plan'), $version, true);

			// 3. Plan builder + audio router + timeline engine (needed by the export
			//    manager's plan construction path; keep them — they are small).
			wp_enqueue_script('mcqvs-timeline-engine', $assets_url . 'js/studio/timeline.engine.js', array(), $version, true);
			wp_enqueue_script('mcqvs-audio-router', $assets_url . 'js/studio/audio.router.js', array(), $version, true);
			wp_enqueue_script('mcqvs-plan-builder', $assets_url . 'js/studio/plan.builder.js', array('mcqvs-render-plan', 'mcqvs-video-templates'), $version, true);

			// 4. Export manager — this is where startExport lives (vs-render-worker.js
			//    is dynamically loaded by studio.export.js on demand).
			wp_enqueue_script('mcqvs-studio-export', $assets_url . 'js/studio/studio.export.js', array('mcqvs-studio-logger'), $version, true);

			// 5. NEW tiny render-runner bootstrap that runs `_autoRunnerLoop` directly
			//    without spinning up the full Studio UI.
			// @FIX (audit): Declare the full encoding chain as dependencies so WordPress
			//        guarantees these globals exist BEFORE render-runner.js evaluates:
			//          - mcqvs-plan-builder     → window.MCQVS_PlanBuilder (buildFromState)
			//          - mcqvs-video-templates  → window.MCQVS_VideoTemplates (used by ExportManager)
			//          - mcqvs-template-manager → window.MCQVS_TemplateManager
			//          - mcqvs-unified-renderer → window.MCQVS_UnifiedRenderer
			//          - mcqvs-studio-export    → window.MCQVS_ExportManager
			//        Previously only `['mcqvs-studio-logger','mcqvs-studio-export']` were
			//        listed; a missing mcqvs-plan-builder let render-runner capture an
			//        undefined PlanBuilder at eval time and time out the readiness gate.
			wp_enqueue_script(
				'mcqvs-render-runner',
				$assets_url . 'js/studio/render-runner.js',
				array(
					'mcqvs-studio-logger',
					'mcqvs-studio-export',
					'mcqvs-plan-builder',
					'mcqvs-video-templates',
					'mcqvs-template-manager',
					'mcqvs-unified-renderer',
					'mcqvs-render-plan',
					'mcqvs-render-plan-validator',
				),
				$version,
				true
			);

			// 6. Localize the SAME config the Studio controller uses, so the runner
			//    can call ajaxPost() against the same endpoints as `_autoRunnerLoop`.
			//    We can recycle `MCQVS_Config` because the runner only needs
			//    `ajaxUrl`, `nonce`, `videoFormat`, `canvasSize`, `assetsUrl`, and
			//    a handful of TTS/audio flags the auto-runner references.
			$runner_config = $this->get_studio_config_array();
			wp_localize_script('mcqvs-render-runner', 'MCQVS_Config', $runner_config);
			wp_localize_script('mcqvs-render-runner', 'MCQVSConfig', $runner_config);
		}

		// Studio JS - only on Studio page
		// @MODIFIED 2026-02-09: Include new editor page slug
		// @MODIFIED 2026-02-16: Include Content Planner for shared dependencies (Controller, Templates)
		if (in_array($page, array('mcqvs-dashboard', 'mcqvs-editor', 'mcqvs-content-planner'), true)) {
			// @MODIFIED 2026-02-01: Modular Video Studio Architecture
			$version = $this->get_asset_version();
			$assets_url = MCQVS_PLUGIN_URL . 'assets/';

			// 1. Logger (Global Telemetry - Must load first)
			wp_enqueue_script('mcqvs-studio-logger', $assets_url . 'js/studio/studio.logger.js', array(), $version, true);



			// 2. Core Modules (Parallel Loading)
			// @PATCH: Hard-stop any legacy/monolithic studio bundles if any other hook registers them.
			// Hard-stop any legacy/old monolith bundles (safe no-ops if not registered)
			wp_dequeue_script('mcqvs-video-studio');
			wp_deregister_script('mcqvs-video-studio');

			wp_dequeue_script('mcqvs-video-studio-legacy');
			wp_deregister_script('mcqvs-video-studio-legacy');

			wp_dequeue_script('vs-video-studio');
			wp_deregister_script('vs-video-studio');

			wp_dequeue_script('mcqvs-video-studio-js');
			wp_deregister_script('mcqvs-video-studio-js');

			// 2b. Studio Modules (MUST load before studio.audio)
			wp_enqueue_script('mcqvs-timeline-engine', $assets_url . 'js/studio/timeline.engine.js', array(), $version, true);
			wp_enqueue_script('mcqvs-audio-router', $assets_url . 'js/studio/audio.router.js', array(), $version, true);
			wp_enqueue_script('mcqvs-plan-builder', $assets_url . 'js/studio/plan.builder.js', array('mcqvs-render-plan', 'mcqvs-video-templates'), $version, true);
			wp_enqueue_script('mcqvs-preview-player', $assets_url . 'js/studio/preview.player.js', array(), $version, true);

			// 2. Core Modules
			wp_enqueue_script('mcqvs-studio-preview', $assets_url . 'js/studio/studio.preview.js', array('mcqvs-studio-logger'), $version, true);
			wp_enqueue_script('mcqvs-studio-export', $assets_url . 'js/studio/studio.export.js', array('mcqvs-studio-logger'), $version, true);
			wp_enqueue_script('mcqvs-studio-audio', $assets_url . 'js/studio/studio.audio.js', array('mcqvs-studio-logger', 'mcqvs-audio-router', 'mcqvs-plan-builder'), $version, true);

			wp_enqueue_script(
				'mcqvs-studio-ui',
				$assets_url . 'js/studio/studio.ui.js',
				array('mcqvs-studio-logger', 'mcqvs-video-templates'),
				$version,
				true
			);

			// 3. Main Controller (Orchestrator)
			wp_enqueue_script(
				'mcqvs-studio-controller',
				$assets_url . 'js/studio/studio.controller.js',
				array(
					'jquery',
					'mcqvs-studio-logger',
					'mcqvs-studio-preview',
					'mcqvs-studio-export',
					'mcqvs-studio-audio',
					'mcqvs-studio-ui',
					// Legacy dependencies required by controller logic
					'mcqvs-video-templates',
					'mcqvs-audio-manager',
					'mcqvs-unified-renderer',
					'mcqvs-timeline',
					'mcqvs-animation-engine',
					// @FIX 2026-07-31: Declare these as explicit dependencies so WordPress
					//       guarantees the globals exist BEFORE studio.controller.js evaluates.
					//       `MCQVS_TemplateManager` (mcqvs-template-manager) is asserted by
					//       loadDependencies() and was previously only loaded via the shared
					//       enqueue block — a stale/cached or reordered bundle left it missing
					//       and aborted studio init with "Missing modules: MCQVS_TemplateManager".
					//       `mcqvs-tts-manager` is initialized by the controller constructor.
					'mcqvs-template-manager',
					'mcqvs-tts-manager',
					// @NEW 2026-02-02: Modular dependencies
					'mcqvs-timeline-engine',
					'mcqvs-audio-router',
					'mcqvs-plan-builder',
					'mcqvs-preview-player'
				),
				$version,
				true
			);

			// @NOTE: studio.controller.js now uses MCQVS_Config but likely maintains compat with mcqvsStudioConfig
			// We keep mcqvsStudioConfig localization below as it contains deep settings not present in the lightweight MCQVS_Config
			// If the new controller needs specific keys from MCQVS_Config, we should add them to mcqvsStudioConfig or localize both.

			// Pass lightweight config for modular components


			// Note: The global mcqvsStudioConfig (line 621) still runs and provides detailed settings (tts, audio, etc).

		}

		// @NEW 2026-02-16: Content Planner Script (Only on planner page)
		if (isset($_GET['page']) && $_GET['page'] === 'mcqvs-content-planner') {
			wp_enqueue_script(
				'mcqvs-content-planner',
				MCQVS_PLUGIN_URL . 'assets/js/studio/vs-content-planner.js',
				array('jquery', 'mcqvs-studio-controller'),
				$this->get_asset_version(),
				true
			);

        // Localize for Planner
        wp_localize_script('mcqvs-content-planner', 'mcqvs_planner_config', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mcqvs_studio_nonce'),
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
            'model' => get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview'),
            'deliveryMode' => get_option('mcqvs_delivery_mode', 'local'),
            // @FIX 1.4.9.53 (global STOP): Content Planner shows a stopped banner
            // and blocks "Start AI Generation" while the flag is set.
            'globalStopped' => function_exists('mcqvs_is_global_stopped') ? mcqvs_is_global_stopped() : false,
        ));
		}

		// Self-Test JS - only on System Health page
		if ($page === 'mcqvs-system-health' || ($page === 'mcqvs-settings' && isset($_GET['tab']) && $_GET['tab'] === 'health')) {
			// @NEW 2026-02-01: Modular Studio Architecture (Self-Test Parity)
			// 1. Logger first
			wp_enqueue_script('mcqvs-studio-logger', MCQVS_PLUGIN_URL . 'assets/js/studio/studio.logger.js', array(), $this->get_asset_version(), true);

			// 2. Core modules (parallel)
			wp_enqueue_script('mcqvs-studio-preview', MCQVS_PLUGIN_URL . 'assets/js/studio/studio.preview.js', array('mcqvs-studio-logger'), $this->get_asset_version(), true);
			wp_enqueue_script('mcqvs-studio-export', MCQVS_PLUGIN_URL . 'assets/js/studio/studio.export.js', array('mcqvs-studio-logger'), $this->get_asset_version(), true);
			wp_enqueue_script('mcqvs-audio-router', MCQVS_PLUGIN_URL . 'assets/js/studio/audio.router.js', array(), $this->get_asset_version(), true);
			wp_enqueue_script('mcqvs-plan-builder', MCQVS_PLUGIN_URL . 'assets/js/studio/plan.builder.js', array('mcqvs-render-plan', 'mcqvs-video-templates'), $this->get_asset_version(), true);

			wp_enqueue_script('mcqvs-studio-audio', MCQVS_PLUGIN_URL . 'assets/js/studio/studio.audio.js', array('mcqvs-studio-logger', 'mcqvs-audio-router', 'mcqvs-plan-builder'), $this->get_asset_version(), true);
			wp_enqueue_script('mcqvs-preview-player', MCQVS_PLUGIN_URL . 'assets/js/studio/preview.player.js', array(), $this->get_asset_version(), true);

			// Missing Modular Deps (Fix for "unregistered dependency" notices)
			wp_enqueue_script('mcqvs-timeline-engine', MCQVS_PLUGIN_URL . 'assets/js/studio/timeline.engine.js', array(), $this->get_asset_version(), true);
			wp_enqueue_script(
				'mcqvs-studio-ui',
				MCQVS_PLUGIN_URL . 'assets/js/studio/studio.ui.js',
				array('mcqvs-studio-logger', 'mcqvs-video-templates'),
				$this->get_asset_version(),
				true
			);


			// 3. Controller with modular deps
			wp_enqueue_script(
				'mcqvs-studio-controller',
				MCQVS_PLUGIN_URL . 'assets/js/studio/studio.controller.js',
				array(
					'jquery',
					'mcqvs-studio-logger',
					'mcqvs-studio-preview',
					'mcqvs-studio-export',
					'mcqvs-studio-audio',
					'mcqvs-studio-ui',
					'mcqvs-video-templates',
					'mcqvs-audio-manager',
					'mcqvs-unified-renderer',
					'mcqvs-timeline',
					'mcqvs-animation-engine',
					// @FIX 2026-07-31: Explicit deps (see Studio controller enqueue above).
					'mcqvs-template-manager',
					'mcqvs-tts-manager',
					// @NEW 2026-02-02: Modular dependencies
					'mcqvs-timeline-engine',
					'mcqvs-audio-router',
					'mcqvs-plan-builder',
					'mcqvs-preview-player'
				),
				$this->get_asset_version(),
				true
			);


			// @NEW 2026-02-03: Hard fail logging if self-test bundle is missing (prevents silent no-op UI)
			$selftest_rel = 'assets/js/vs-self-test.js';
			$selftest_abs = MCQVS_PLUGIN_DIR . $selftest_rel;

			if (!file_exists($selftest_abs)) {
				if (class_exists('VS_Error_Logger')) {
					VS_Error_Logger::get_instance()->log('Self-test script missing: ' . $selftest_abs, 'error');
				} else {
					error_log('[MCQVS] Self-test script missing: ' . $selftest_abs);
				}
			}

			wp_enqueue_script(
				'mcqvs-self-test-js',
				MCQVS_PLUGIN_URL . $selftest_rel,
				// @MODIFIED 2026-02-02: Added modular studio deps (Timeline, Router, Builder)
				// @NEW 2026-06-29: Added mcqvs-studio-logger so Diagnostics logger regression
				//                 guard (F2) can assert against window.MCQVSLogger.export().
				array('jquery', 'mcqvs-logger', 'mcqvs-studio-logger', 'mcqvs-studio-controller', 'mcqvs-video-templates', 'mcqvs-template-manager', 'mcqvs-unified-renderer', 'mcqvs-render-plan', 'mcqvs-render-plan-validator', 'mcqvs-asset-cache', 'mcqvs-preflight', 'mcqvs-job-manager', 'mcqvs-schema-validate', 'mcqvs-diagnostics', 'mcqvs-timeline-engine', 'mcqvs-audio-router', 'mcqvs-plan-builder', 'mcqvs-preview-player'),
				$this->get_asset_version(),
				true
			);

			// Smoke Test Runner
			wp_enqueue_script(
				'mcqvs-smoke-test-runner',
				MCQVS_PLUGIN_URL . 'assets/js/vs-smoke-test-runner.js',
				array('jquery', 'mcqvs-studio-controller'),
				$this->get_asset_version(),
				true
			);
		}



		$page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';

		// Localize for Studio (Main)
		// @MODIFIED 2026-02-02: Merge all legacy mcqvsStudioConfig keys into MCQVS_Config (single source of truth)
		// @MODIFIED 2026-02-09: Include new editor page slug
		// @MODIFIED 2026-02-16: Include Content Planner for shared config
 if (in_array($page, array('mcqvs-dashboard', 'mcqvs-editor', 'mcqvs-content-planner'), true)) {
 // @FIX: Single source of truth — get_studio_config_array() now contains ALL keys (rootUrl, version, etc.)
 $unified_config = $this->get_studio_config_array();

 // Primary localization (Canonical Name expected by Controller)
 wp_localize_script('mcqvs-studio-controller', 'MCQVSConfig', $unified_config);
 // Back-compat alias (safe)
 wp_localize_script('mcqvs-studio-controller', 'MCQVS_Config', $unified_config);
 }

 // Localize for System Health (Self-Test + Smoke Test)
 if ($page === 'mcqvs-system-health' || ($page === 'mcqvs-settings' && isset($_GET['tab']) && $_GET['tab'] === 'health')) {
  $health_config = array(
  'assetsUrl' => mcqvs_assets_url(),
  'pluginUrl' => MCQVS_PLUGIN_URL,
 'nonce' => wp_create_nonce('mcqvs_studio_nonce'),
 'ajaxurl' => admin_url('admin-ajax.php'),
 );

 wp_localize_script('mcqvs-self-test-js', 'mcqvsSelfTestConfig', $health_config);
wp_localize_script('mcqvs-smoke-test-runner', 'mcqvsSystemHealth', array(
'ajaxurl' => admin_url('admin-ajax.php'),
'ajaxUrl' => admin_url('admin-ajax.php'),
'nonce' => wp_create_nonce('mcqvs_studio_nonce'), // @FIX: Unified nonce (was mcqvs_settings_nonce)
));
 }



	}

	/**
	 * Build Studio Configuration Array
	 * Helper method to keep enqueue_assets clean and reusable
	 * 
	 * @return array
	 */
 private function get_studio_config_array()
 {
 // @NEW 2025-12-01: Phase 4 - Extensible Template System
 $custom_templates = apply_filters('mcqvs_video_studio_templates', array());
 $custom_templates = apply_filters('MCQVS_video_studio_templates', $custom_templates);

	// @NEW 2025-12-01: Phase 4, Task 12 - Configurable Video Generation Parameters
	// @MODIFIED 2026-04-24: Format-aware canvas size (shorts=1080x1920, youtube=1920x1080)
	$video_format = get_option('mcqvs_video_format', 'shorts');
	$default_canvas = ($video_format === 'youtube') ? array('width' => 1920, 'height' => 1080) : array('width' => 1080, 'height' => 1920);
	$canvas_size = apply_filters('mcqvs_video_studio_canvas_size', $default_canvas);
	$canvas_size = apply_filters('MCQVS_video_studio_canvas_size', $canvas_size);

 $fps = apply_filters('mcqvs_video_studio_fps', 30);
 $fps = apply_filters('MCQVS_video_studio_fps', $fps);

 $question_duration = apply_filters('mcqvs_video_studio_question_duration', 10);
 $question_duration = apply_filters('MCQVS_video_studio_question_duration', $question_duration);

 $batch_size = apply_filters('mcqvs_video_studio_batch_size', 5);
 $batch_size = apply_filters('MCQVS_video_studio_batch_size', $batch_size);

 // @NEW 2025-12-01: Text Effects System
 $text_effect_styles = apply_filters('mcqvs_video_studio_text_effect_styles', array());
 $text_effect_styles = apply_filters('MCQVS_video_studio_text_effect_styles', $text_effect_styles);

	// @FIX: Complete SSOT — all MCQVSConfig keys unified here (no split between function and merge block)
	return array(
		'ajaxurl' => admin_url('admin-ajax.php'),
		'ajaxUrl' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('mcqvs_studio_nonce'),
  'rootUrl' => MCQVS_PLUGIN_URL,
  'assetsUrl' => mcqvs_assets_url(),
  'version' => $this->get_asset_version(),
  'isDevelopment' => defined('WP_DEBUG') && WP_DEBUG,
  'deliveryMode' => get_option('mcqvs_delivery_mode', 'local'),
  'defaultLogo' => mcqvs_assets_url( 'images/logo-placeholder.png' ),
 'customTemplates' => $custom_templates,
		'canvasSize' => $canvas_size,
		'videoFormat' => $video_format,
 'fps' => $fps,
 'questionDuration' => $question_duration,
 'batchSize' => $batch_size,
 'textEffectStyles' => $text_effect_styles,
 // @NEW 2026-08-11: Explanation toggle — seeded into the Studio editor defaults so
 // preview/export match the Settings > Defaults & Scheduling checkbox.
 'showExplanation' => get_option('mcqvs_show_explanation', false) ? true : false,
 // @FIX 1.4.9.52: Studio seeds its "Show Hook Text On Video" toggle from the same
 // persisted option the Content Planner uses (mcqvs_planner_hook_visible), so the
 // Studio editor no longer resets to ON after every refresh — it reflects the
 // user's last choice across the whole plugin.
 'defaultHookVisible' => get_option('mcqvs_planner_hook_visible', true) !== false,
 // @FIX 1.4.9.53 (global STOP): the browser Studio Auto-Runner checks this on
 // every poll and halts when the dashboard "Stop Everything" is active.
 'globalStopped' => function_exists('mcqvs_is_global_stopped') ? mcqvs_is_global_stopped() : false,
  'tts' => array(
  'provider' => get_option('mcqvs_tts_provider', get_option('MCQVS_video_studio_tts_provider', 'webspeech')),
  'defaultVoice' => get_option('mcqvs_tts_default_voice', 'en-US-AriaNeural'),
  'googleApiKey' => get_option('mcqvs_google_cloud_tts_key', get_option('MCQVS_google_cloud_tts_key', '')),
  'voiceRotationEnabled' => get_option('mcqvs_tts_voice_rotation_enabled', false),
  'speakOptions' => get_option('mcqvs_tts_speak_options', true),
  // @FIX 1.4.9.49 (TTS SSOT): expose the new Settings knobs so Studio seeds from
  // them (single source of truth) instead of its own hardcoded defaults.
  'enabled' => (bool) get_option('mcqvs_tts_enabled', true),
  'rate' => (float) get_option('mcqvs_tts_rate', 1.2),
  'speakHook' => (bool) get_option('mcqvs_tts_speak_hook', true),
  'speakAnswer' => (bool) get_option('mcqvs_tts_speak_answer', true),
  'speakCta' => (bool) get_option('mcqvs_tts_speak_cta', false),
  'edgeVoices' => class_exists('VS_Settings') ? VS_Settings::get_edge_english_voices() : array(),
  ),
  'audio' => array(
  'basePath' => mcqvs_assets_url(),
 'sfxEnabled' => true,
 'musicEnabled' => true,
 'library' => array(
 'music' => $this->scan_audio_directory('music'),
  'sfx' => array(
  'tick' => $this->scan_audio_directory('sfx/tick'),
  'correct' => $this->scan_audio_directory('sfx/correct'),
  'wrong' => $this->scan_audio_directory('sfx/wrong'),
  'reveal' => $this->scan_audio_directory('sfx/reveal'),
  'transition' => $this->scan_audio_directory('sfx/transition'),
  ),
 ),
 ),
	'options' => array(
		'azureRegion' => $this->get_config_option('azure_tts_region', 'eastus'),
		'azureKey' => $this->get_config_option('azure_tts_key', ''),
		'googleKey' => $this->get_config_option('google_cloud_tts_key', ''),

	),
	'branding' => get_option('MCQVS_studio_branding', array()),
	);
 }

	/**
	 * Render the Studio Page (HTML Container)
	 */
public function render_studio_page()
{
$video_format = get_option('mcqvs_video_format', 'shorts');
// @MODIFIED 2025-12-01: Added i18n support for access denied message
if (! current_user_can('manage_options')) {
			wp_die(esc_html__('Access denied', 'mcq-video-studio'));
		}
	?>
		<div class="wrap" id="mcqvs-video-studio-wrapper">
			<h1 class="wp-heading-inline"><?php echo esc_html__('🎥 Quiz Shorts Studio', 'mcq-video-studio'); ?></h1>
			<hr class="wp-header-end">

			<!-- Studio App Container -->
			<div id="mcqvs-video-studio-app">
				<div id="mcqvs-notifications" class="mcqvs-notifications"></div>

	<!-- Controls Sidebar -->
		<div class="studio-sidebar">

		<!-- @NEW 2026-04-24: Video Format Toggle -->
		<div class="control-group mcqvs-format-group">
			<h3>📐 Video Format</h3>
			<div class="form-row">
				<div class="mcqvs-format-toggle">
					<button type="button" class="mcqvs-format-btn<?php echo ($video_format !== 'youtube') ? ' active' : ''; ?>" data-format="shorts">📱 Shorts</button>
					<button type="button" class="mcqvs-format-btn<?php echo ($video_format === 'youtube') ? ' active' : ''; ?>" data-format="youtube">🖥️ YouTube</button>
				</div>
				<p class="description" style="font-size:10px; color:#666; margin-top:6px;">Shorts: 1080×1920 (9:16) • YouTube: 1920×1080 (16:9)</p>
			</div>
		</div>

		<!-- Data Source Section -->
					<div class="control-group">
						<h3>📂 Data Source</h3>
						<div class="form-row">
							<label>Source Type:</label>
							<select id="sourceType">
								<option value="topic">Topic</option>
								<option value="exam">Exam</option>
								<!-- @NEW 2026-01-27: Dedicated Bank -->
								<option value="bank_topic">Dedicated Bank (NEW)</option>
							</select>
						</div>
						<div class="form-row">
							<label>Select Item:</label>
							<select id="sourceItem">
								<option value="">Loading...</option>
							</select>
							<p class="description" style="font-size:10px; color:#666; margin-top:4px;">
								⬇️ Sorted by question count (highest first)
							</p>
						</div>
						<button id="loadDataBtn" class="button button-primary">Load Questions</button>

						<!-- @NEW 2025-12-19: AI News Quiz Generator -->
						<hr style="margin: 15px 0; border:0; border-top:1px solid #eee;">
						<div class="ai-news-section">
							<label><strong>📰 Generate from News</strong></label>
							<p class="description">Create quiz from trending headlines</p>
							<div class="form-row" style="margin-top:8px;">
								<input type="text" id="newsTopicInput" placeholder="e.g. Climate Change, Tech AI, Sports" style="width:100%;">
							</div>
							<div class="form-row" style="display:flex; gap:8px; align-items:center; margin-top:8px;">
								<label style="font-size:12px;">Questions:</label>
								<input type="number" id="newsQuestionCount" min="3" max="30" value="5" style="width:70px;">
								<button id="generateNewsQuizBtn" class="button button-secondary" style="flex:1;">
									✨ Generate
								</button>
							</div>
						</div>
					</div>

					<!-- @NEW 2026-01-17: Direct Topic Quiz Generator -->
					<div class="control-group">
						<label><strong>📚 Generate from Topic (Exam Focused)</strong></label>
						<p class="description">Create highly engaging, relevant MCQs for specific exams.</p>
						<div class="form-row" style="margin-top:8px;">
							<input type="text" id="topicQuizInput" placeholder="e.g. Solar System, Indian History, Biology" style="width:100%;">
						</div>
						<div class="form-row" style="display:flex; gap:8px; align-items:center; margin-top:8px;">
							<label style="font-size:12px;">Questions:</label>
							<input type="number" id="topicQuestionCount" min="3" max="30" value="5" style="width:70px;">
							<button id="generateTopicQuizBtn" class="button button-secondary" style="flex:1;">
								✨ Generate
							</button>
						</div>
					</div>

					<!-- Question Selection Section -->
					<div class="control-group question-selector-section" id="questionSelectorSection" style="display:none;">
						<h3>📝 Select Questions</h3>
						<div class="form-row" style="display:flex; gap:8px; margin-bottom:10px;">
							<button type="button" id="selectAllQuestionsBtn" class="button button-small">Select All</button>
							<button type="button" id="deselectAllQuestionsBtn" class="button button-small">Deselect All</button>
							<span id="questionCountDisplay" style="margin-left:auto; font-size:12px; color:#666;">0 selected</span>
						</div>
						<div id="questionSelectorDropdown" class="question-selector-dropdown">
							<!-- Questions loaded here as compact checkboxes -->
						</div>
						<!-- @NEW 2026-02-11: Pagination for browsing bank -->
						<div class="mcqvs-pagination-row" style="display:flex; align-items:center; gap:8px; margin-top:10px; border-top:1px solid #eee; padding-top:10px;">
							<button type="button" id="prevQuestionsBtn" class="button button-small" disabled>◀ Prev</button>
							<span id="pageIndicator" style="font-size:11px; color:#666; flex:1; text-align:center;">Page 1</span>
							<button type="button" id="nextQuestionsBtn" class="button button-small" disabled>Next ▶</button>
						</div>
					</div>

					<!-- Batch Mode Section -->
					<div class="control-group batch-mode-group">
						<h3>🚀 Batch Generation</h3>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="batchModeToggle"> Enable Batch Mode
							</label>
						</div>
						<div id="batchControls" style="display:none;">
							<!-- @NEW 2026-07-04 (F5): Honest Server-Side Rendering row.
							     The previous #serverRenderRow was an unchecked checkbox with
							     no JS handler. Replaced with a real "Render on Server" button
							     that POSTs `mcqvs_render_now` to spawn the Playwright headless
							     Chromium render for the currently-loaded/selected job. -->
							<div class="form-row" id="serverRenderRow" style="margin-top:8px; padding:10px; background:#e0f2fe; border:1px solid #7dd3fc; border-radius:6px;">
								<label style="font-weight:600; color:#0369a1;">⚡ Server-Side Rendering (Playwright + Chromium)</label>
								<p class="description" style="font-size:10px; color:#075985;">Uploads frames to your VPS and renders via headless Chromium. Requires the Headless tab to be installed and enabled.</p>
								<div style="display:flex; gap:8px; margin-top:8px;">
									<button id="renderNowBtn" type="button" class="button button-secondary" style="flex:1;">🚀 Render on Server</button>
									<a href="<?php echo esc_url(admin_url('admin.php?page=mcqvs-settings&tab=headless')); ?>" class="button button-small">⚙️ Headless Setup</a>
								</div>
								<div id="renderNowStatus" style="display:none; margin-top:8px; font-size:11px;"></div>
							</div>
							<p class="description">Generates videos in chunks of 5 questions.</p>
							<div class="progress-bar">
								<div id="batchProgress" style="width: 0%"></div>
							</div>
							<div id="batchStatus">Ready</div>
							<!-- @NEW 2026-02-23: Frame/ETA display for batch exports (Fix 7) -->
							<div id="batchProgressDetail" style="display:none; font-size:10px; color:#666; margin-top:4px; display:flex; justify-content:space-between;">
								<span id="batchFrameCount">Frame: 0 / 0</span>
								<span id="batchETA">ETA: --</span>
							</div>
							<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
								<button id="startBatchBtn" class="button button-hero button-primary" style="flex:1;">Start Batch</button>
								<!-- @NEW 2025-12-19: Pause/Resume/Cancel Buttons for Server Mode -->
								<button id="pauseBatchBtn" class="button button-secondary" style="display:none;">⏸️ Pause</button>
								<button id="resumeBatchBtn" class="button button-secondary" style="display:none;">▶️ Resume</button>
								<button id="cancelBatchBtn" class="button button-link-delete" style="display:none;">🚫 Cancel</button>
							</div>
						</div>
					</div>

					<!-- @NEW 2026-02-23: Queue Auto-Runner (processes Content Planner jobs) -->
					<div class="control-group auto-runner-group">
						<h3>🤖 Queue Auto-Runner</h3>
						<p class="description" style="font-size:11px; opacity:0.7; margin-bottom:10px;">Automatically processes jobs scheduled from the Content Planner. Keep this tab open.</p>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="queueRunnerToggle"> Enable Queue Runner
							</label>
						</div>
						<div id="queueRunnerControls" style="display:none; margin-top:10px;">
							<div id="queueRunnerStatus" style="font-size:12px; font-weight:600; color:#7dd3fc; margin-bottom:8px;">Status: Idle</div>
							<div id="queueRunnerProgressContainer" style="display:none; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:6px; padding:10px; margin-bottom:10px;">
								<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
									<span id="queueRunnerProgressLabel" style="font-size:11px; font-weight:600; color:#ccc;">Rendering...</span>
									<span id="queueRunnerProgressPercent" style="font-size:12px; font-weight:700; color:#7dd3fc;">0%</span>
								</div>
								<div style="height:8px; background:rgba(255,255,255,0.1); border-radius:4px; overflow:hidden;">
									<div id="queueRunnerProgressBar" style="width:0%; height:100%; background:linear-gradient(90deg, #7dd3fc, #38bdf8); border-radius:4px; transition:width 0.3s ease;"></div>
								</div>
								<div style="display:flex; justify-content:space-between; margin-top:4px; font-size:10px; color:#888;">
									<span id="queueRunnerProgressFrames">Frame: 0 / 0</span>
									<span id="queueRunnerProgressETA">ETA: --</span>
								</div>
							</div>
							<div id="queueRunnerJobCount" style="font-size:11px; color:#888; margin-bottom:8px;"></div>
							<div style="display:flex; gap:8px;">
								<button id="stopQueueRunnerBtn" class="button button-secondary" style="display:none;">⏹ Stop Runner</button>
							</div>
						</div>
					</div>

					<!-- Branding Section -->
					<div class="control-group">
						<h3>🎨 Branding</h3>

						<!-- @MODIFIED 2026-08-10: Logo upload removed from Studio — managed in Settings → Assets.
						     This row shows the current logo as read-only so the user sees what will render.
						     upload/remove/position are handled exclusively by the Settings Assets tab. -->
						<div class="form-row">
							<label>Brand Logo:</label>
							<div id="studioLogoReadonly" style="display:flex; align-items:center; gap:10px;">
								<img id="logoPreview" src="" alt="Logo" style="max-height:50px; max-width:100px; border-radius:4px; display:none;">
								<p class="description" id="studioLogoEmptyMsg">Set in Settings → Assets</p>
							</div>
						</div>

						<div class="form-row">
							<label>Brand Name:</label>
							<input type="text" id="brandName" value="TheQuizWire">
						</div>

						<!-- @NEW 2026-01-17: Quiz Name Field -->
						<div class="form-row">
							<label>Quiz Name:</label>
							<input type="text" id="quizName" value="Iran Quiz">
						</div>
						<div class="form-row">
							<label>Hook Text:</label>
							<input type="text" id="hookText" value="Can you score 5/5?">
						</div>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="hookVisibleToggle" <?php checked(get_option('mcqvs_planner_hook_visible', true)); ?>>
								Show Hook Text On Video
							</label>
							<p class="description">Turn off to keep the hook voice-only (TTS will still say it if enabled).</p>
						</div>
						<!-- @NEW 2025-12-17: AI Hook Generator UI -->
						<div class="form-row">
							<label>AI Hooks:</label>
							<div class="ai-hooks-row">
								<select id="hookSelect">
									<option value="">Generate viral hooks...</option>
								</select>
								<button type="button" id="generateHooksBtn" class="button button-secondary" title="Generate AI Hooks">🔄</button>
							</div>
							<p class="description">
								AI generates 5 viral hook suggestions. Select to apply.
							</p>
						</div>

						<!-- @NEW 2025-12-19: CTA Presets -->
						<div class="form-row">
							<label>CTA Style:</label>
						<select id="ctaStyle">
							<option value="custom">✏️ Custom Text</option>
							<option value="score" selected>🎯 Comment your score X/X? (score challenge)</option>
							<option value="subscribe">🔔 Subscribe & Hit the Bell!</option>
							<option value="like">❤️ Like if you scored 5/5!</option>
							<option value="comment">💬 Comment your score!</option>
							<option value="share">📢 Share with a friend!</option>
							<option value="link">🔗 Link in Bio!</option>
						</select>
						</div>

						<!-- @FIX 1.4.9.58: no hardcoded CTA — default is the score challenge
						     "Comment your score 👇". The CTA Text row is hidden unless the
						     user picks "Custom Text" (and turns Rank off). CSV has no CTA
						     column, so imported videos use this same default. -->
						<div class="form-row" id="customCtaRow" style="display:none;">
							<label>CTA Text:</label>
							<input type="text" id="ctaText" value="Comment your score 👇">
						</div>
						<!-- @MODIFIED 2025-11-30: Phase 4 - Rank System CTA Toggle -->
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="useRankSystemToggle" checked>
								Use Rank System CTA (Higher Engagement)
							</label>
							<p class="description">
								Toggle off to use custom CTA text above. Rank system boosts comments by 25-30%.
							</p>
						</div>
						<!-- @NEW 2026-08-11: Copy Pinned Comment — paste into the comment box on the
						     published short/reel and pin it. Drives the comment signal + site traffic. -->
						<div class="form-row">
							<button type="button" class="button button-secondary" id="copyPinnedCommentBtn" style="width:100%;">
								📌 Copy Pinned Comment
							</button>
							<p class="description">
								Copies the comment text (hook + score challenge + site link) to your
								clipboard — paste it under the published video and PIN it.
							</p>
						</div>
					</div>

					<!-- @NEW 2026-07-30: Video Cover Preview Section -->
					<div class="control-group">
						<h3>🖼️ Video Cover</h3>
						<p class="description" style="font-size:11px; opacity:0.7; margin-bottom:8px;">First frame of your video — used as thumbnail on social media.</p>
						<div id="cover-editor-container">
							<div style="text-align:center; padding:10px; color:#888; font-size:11px;">
								<div class="spinner" style="float:none; margin:0 auto 6px;"></div>
								Loading cover editor...
							</div>
						</div>
					</div>

					<!-- @NEW 2025-12-01: Text Effects Section -->
					<div class="control-group">
						<h3>✨ Text Effects</h3>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="enableTextEffects" checked>
								Enable Professional Text Effects
							</label>
							<p class="description">
								Turn off for A/B testing (Control Group).
							</p>
						</div>
						<div class="form-row" id="textEffectsOptions">
							<label>Effect Style:</label>
							<select id="textEffectStyle">
								<option value="classicBold" selected>Classic Bold (Default)</option>
								<option value="neonGlow">Neon Glow (Viral TikTok)</option>
								<option value="goldLuxury">Gold Luxury (Premium)</option>
								<option value="3dPop">3D Pop (Playful)</option>
								<option value="minimalClean">Minimal Clean (Simple)</option>
								<option value="comicBold">Comic Bold (Fun)</option>
								<option value="fireIce">Fire & Ice (Dramatic)</option>
								<option value="retroArcade">Retro Arcade (80s)</option>
								<option value="elegantSerif">Elegant Serif (Classy)</option>
								<option value="glitchEffect">Glitch Effect (Cyberpunk)</option>
							</select>
						</div>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="showTextEffectPreview">
								Show Live Preview
							</label>
						</div>
						<div id="textEffectPreviewContainer" style="display:none; margin-top:10px; border:1px solid #ddd; background:#222; border-radius:4px; padding:15px; text-align:center;">
							<canvas id="textEffectPreviewCanvas" width="360" height="120" style="width:100%; height:auto;"></canvas>
							<p style="color:#aaa; font-size:10px; margin:5px 0 0;">Preview of selected style</p>
						</div>
					</div>

					<!-- @MODIFIED 2025-12-17: Expanded template selector with 17 templates -->
					<div class="control-group">
						<h3>🎨 Design & Templates</h3>

						<!-- @NEW 2025-12-19: Professional Template Grid -->
						<div class="mcqvs-template-browser">
							<div class="mcqvs-template-tabs">
								<button type="button" class="mcqvs-tab active" data-category="all">All</button>
								<button type="button" class="mcqvs-tab" data-category="professional">Professional</button>
								<button type="button" class="mcqvs-tab" data-category="energetic">Energetic</button>
								<button type="button" class="mcqvs-tab" data-category="themed">Themed</button>
								<button type="button" class="mcqvs-tab" data-category="educational">Educational</button>
								<button type="button" class="mcqvs-tab" data-category="gaming">Gaming</button>
							</div>

							<div id="templateGrid" class="mcqvs-template-grid">
								<!-- Populated by JS -->
							</div>

							<!-- Hidden input to maintain state compatibility -->
							<input type="hidden" id="templateSelect" value="trivia">
						</div>
						<div class="form-row">
							<label>Video Background:</label>
							<!-- @MODIFIED 2026-02-23: Dropdown picker from preset library (Fix 2) -->
							<select id="bgVideoSelect" style="width:100%;">
								<option value="">None (use template default)</option>
								<!-- Populated dynamically via AJAX -->
							</select>
							<video id="bgVideoPreview" style="display:none; width:100%; max-height:120px; border-radius:6px; margin-top:6px; object-fit:cover;" muted loop></video>
							<p class="description" style="font-size:10px; margin-top:4px;">Or upload custom:</p>
							<input type="file" id="bgVideoUpload" accept="video/*">
						</div>
						<!-- @MODIFIED 2025-11-30: Added Split Screen upload for viral retention -->
						<div class="form-row">
							<label>Split Screen (Bottom 30%):</label>
							<input type="file" id="splitScreenUpload" accept="video/*">
						</div>
					</div>


					<!-- @NEW 2025-12-20: Professional Audio Suite -->
					<div class="control-group">
						<h3>🎵 Audio & SFX
							<div class="mcqvs-toggles" style="float:right; display:flex; gap:15px; font-size:14px;">
								<label class="mcqvs-toggle-wrapper" style="display:flex; align-items:center;">
									<input type="checkbox" id="enableSFXToggle" checked>
									<span style="margin-left:5px;">SFX</span>
								</label>
								<label class="mcqvs-toggle-wrapper" style="display:flex; align-items:center;">
									<input type="checkbox" id="enableMusicToggle" checked>
									<span style="margin-left:5px;">Music</span>
								</label>
							</div>
						</h3>

						<div class="mcqvs-audio-suite">
							<!-- Tabs -->
							<div class="mcqvs-audio-tabs">
								<button type="button" class="mcqvs-audio-tab active" data-tab="sfx">Sound Effects</button>
								<button type="button" class="mcqvs-audio-tab" data-tab="music">Background Music</button>
								<button type="button" class="mcqvs-audio-tab" data-tab="voice">Voiceover</button>
							</div>

							<!-- SFX Tab -->
							<div id="audio-tab-sfx" class="mcqvs-audio-panel active">
								<!-- Tick Section -->
								<div class="mcqvs-sound-group">
									<div style="display:flex; justify-content:space-between; align-items:center;">
										<h4>⏱️ Tick Sound</h4>
										<button type="button" class="button button-small toggle-sound-library" data-target="sfx-tick-options">Browse Library</button>
									</div>
									<div class="mcqvs-sound-options" id="sfx-tick-options" style="display:none;">
										<!-- Populated by JS -->
									</div>
									<div class="mcqvs-custom-upload">
										<label>Or upload custom:</label>
										<input type="file" id="upload-tick" accept="audio/*">
									</div>
								</div>

								<!-- Correct Section -->
								<div class="mcqvs-sound-group">
									<div style="display:flex; justify-content:space-between; align-items:center;">
										<h4>✅ Correct Sound</h4>
										<button type="button" class="button button-small toggle-sound-library" data-target="sfx-correct-options">Browse Library</button>
									</div>
									<div class="mcqvs-sound-options" id="sfx-correct-options" style="display:none;">
										<!-- Populated by JS -->
									</div>
									<div class="mcqvs-custom-upload">
										<label>Or upload custom:</label>
										<input type="file" id="upload-correct" accept="audio/*">
									</div>
								</div>

							<!-- Wrong Section -->
							<div class="mcqvs-sound-group">
								<div style="display:flex; justify-content:space-between; align-items:center;">
									<h4>❌ Wrong Sound</h4>
									<button type="button" class="button button-small toggle-sound-library" data-target="sfx-wrong-options">Browse Library</button>
								</div>
								<div class="mcqvs-sound-options" id="sfx-wrong-options" style="display:none;">
									<!-- Populated by JS -->
								</div>
								<div class="mcqvs-custom-upload">
									<label>Or upload custom:</label>
									<input type="file" id="upload-wrong" accept="audio/*">
								</div>
							</div>

							<!-- @NEW 2026-07-02: Reveal Section -->
							<div class="mcqvs-sound-group">
								<div style="display:flex; justify-content:space-between; align-items:center;">
									<h4>🔔 Reveal Sound</h4>
									<button type="button" class="button button-small toggle-sound-library" data-target="sfx-reveal-options">Browse Library</button>
								</div>
								<div class="mcqvs-sound-options" id="sfx-reveal-options" style="display:none;">
									<!-- Populated by JS -->
								</div>
								<div class="mcqvs-custom-upload">
									<label>Or upload custom:</label>
									<input type="file" id="upload-reveal" accept="audio/*">
								</div>
							</div>

							<!-- @NEW 2026-07-02: Transition Section -->
							<div class="mcqvs-sound-group">
								<div style="display:flex; justify-content:space-between; align-items:center;">
									<h4>🔄 Transition Sound</h4>
									<button type="button" class="button button-small toggle-sound-library" data-target="sfx-transition-options">Browse Library</button>
								</div>
								<div class="mcqvs-sound-options" id="sfx-transition-options" style="display:none;">
									<!-- Populated by JS -->
								</div>
								<div class="mcqvs-custom-upload">
									<label>Or upload custom:</label>
									<input type="file" id="upload-transition" accept="audio/*">
								</div>
							</div>
							</div>

							<!-- Music Tab -->
							<div id="audio-tab-music" class="mcqvs-audio-panel">
								<div class="mcqvs-sound-group">
									<h4>🎼 Background Music</h4>
									<p class="description">Add background music to your video</p>
									<div class="mcqvs-custom-upload">
										<input type="file" id="bgMusicUpload" accept="audio/*">
									</div>
								</div>
							</div>

							<!-- Voice Tab -->
							<div id="audio-tab-voice" class="mcqvs-audio-panel">
								<div class="mcqvs-sound-group">
									<h4>🎙️ Text-to-Speech Voice</h4>
									<div class="setting-row">
										<label class="switch-label">
											<span>Enable TTS Voiceover In Export</span>
											<label class="studio-switch">
												<input type="checkbox" id="enableVoiceoverToggle">
												<span class="slider round"></span>
											</label>
										</label>
										<p class="description" style="margin-left: 24px;">Adds narrated audio to the final MP4 (question + options + correct answer).</p>
									</div>
									<div class="form-row">
										<label>Voice:</label>
										<select id="voiceSelect"></select>
									</div>
									<div class="form-row">
										<label>Speech rate:</label>
										<input type="range" id="ttsSpeechRate" min="0.6" max="1.4" step="0.05" value="1.05">
										<span id="ttsSpeechRateValue" style="min-width:52px; display:inline-block; text-align:right;">1.05x</span>
									</div>
									<p class="description" style="margin-left: 24px;">0.6x (slow) to 1.4x (fast). Applies to exported voiceover and Test Voice.</p>
									<div class="form-row">
										<label>Answer phrase:</label>
										<input type="text" id="ttsAnswerPhrase" placeholder="e.g. Correct option is">
									</div>
									<p class="description" style="margin-left: 24px;">Used for reveal narration. Supports {letter} and {option} placeholders.</p>
									<button id="testVoiceBtn" class="button button-small">Test Voice</button>
									<div class="form-row" style="margin-top:10px;">
										<label class="toggle-label"><input type="checkbox" id="ttsSpeakHookToggle" checked> Speak Hook</label>
										<label class="toggle-label" style="display:block; margin-top:6px;"><input type="checkbox" id="ttsSpeakOptionsToggle" checked> Speak Options</label>
										<label class="toggle-label" style="display:block; margin-top:6px;"><input type="checkbox" id="ttsSpeakAnswerToggle" checked> Speak Correct Answer</label>
										<label class="toggle-label" style="display:block; margin-top:6px;"><input type="checkbox" id="ttsSpeakCtaToggle"> Speak CTA (Outro)</label>
									</div>
									<!-- @MODIFIED 2026-01-07: Audio Suite Toggle -->
									<div class="setting-row">
										<label class="switch-label">
											<span>Enable Audio Suite</span>
											<label class="studio-switch">
												<input type="checkbox" id="enableMasterAudioToggle" checked>
												<span class="slider round"></span>
											</label>
										</label>
									</div>
									<p class="description" style="margin-left: 24px;">When disabled, preview will be silent. Enable to hear SFX and background music.</p>
								</div>
							</div>
						</div>
					</div> <!-- @MODIFIED 2026-01-07: Close Audio Suite control-group -->

					<!-- @NEW 2025-12-18: AI & Services Settings (Hardening) -->
					<div class="control-group" id="ttsSettingsGroup">
						<h3>🔑 AI & Services Settings</h3>
						<p class="description">Configure your API keys for premium TTS and AI features.</p>

						<div class="form-row">
							<label>TTS Provider:</label>
							<select id="ttsProvider">
                <option value="webspeech">Web Speech API (Free / Limited)</option>
                <option value="edge">Edge TTS (Free / High Quality)</option>
                <option value="google">Google Cloud TTS (Premium)</option>
                <option value="azure">Azure Cognitive TTS (Premium)</option>
                <option value="elevenlabs">ElevenLabs (Pro Clone)</option>
							</select>
						</div>

						<div id="googleTtsSettings" class="tts-sub-settings" style="display:none;">
							<div class="form-row">
								<label>Google Cloud API Key:</label>
								<input type="password" id="googleApiKey" value="<?php echo esc_attr($this->get_config_option('google_cloud_tts_key', '')); ?>">
							</div>
						</div>

						<div id="azureTtsSettings" class="tts-sub-settings" style="display:none;">
							<div class="form-row">
								<label>Azure API Key:</label>
								<input type="password" id="azureApiKey" value="<?php echo esc_attr($this->get_config_option('azure_tts_key', '')); ?>">
							</div>
							<div class="form-row">
								<label>Azure Region:</label>
								<input type="text" id="azureRegion" value="<?php echo esc_attr($this->get_config_option('azure_tts_region', 'eastus')); ?>" placeholder="e.g. eastus">
							</div>
						</div>

						<div id="elevenlabsTtsSettings" class="tts-sub-settings" style="display:none;">
							<div class="form-row">
								<label>ElevenLabs API Key:</label>
								<input type="password" id="elevenlabsApiKey" value="<?php echo esc_attr($this->get_config_option('elevenlabs_api_key', '')); ?>">
							</div>
							<button id="refreshElevenlabsVoicesBtn" class="button button-small" style="width:100%; margin-top:5px;">🔄 Refresh Cloned Voices</button>
						</div>

						<button id="saveTtsSettingsBtn" class="button button-secondary">💾 Save AI Settings</button>
					</div>

					<!-- AI & Tools -->
					<div class="control-group">
						<h3>🤖 AI & Tools</h3>
						<!-- @MODIFIED: Removed Client-Side API Key Input -->
						<p class="description">AI features use keys from Plugin Settings.</p>

						<!-- @MODIFIED 2026-02-23: Standardized IDs wired in studio.ui.js -->
						<button id="generateQuizBtn" class="button button-secondary">✨ Generate Quiz (use News/Topic)</button>
						<button id="generateBackgroundBtn" class="button button-secondary">🖼️ Generate AI Background</button>

						<div class="studio-actions-row">
							<button id="exportJsonBtn" class="button button-small">Export JSON</button>
							<label class="button button-small">
								Import JSON <input type="file" id="importJsonInput" accept=".json" style="display:none;">
							</label>
						</div>
						<button id="captureThumbnailBtn" class="button button-small">📸 Capture Thumbnail</button>
					</div>

					<!-- @MODIFIED 2025-12-17: Enhanced Export Section with flexibility options -->
					<div class="control-group">
						<h3>💾 Export Settings</h3>
						<div class="form-row">
							<label>Platform:</label>
							<select id="exportPlatform">
								<option value="all" selected>All Platforms</option>
								<option value="youtube">YouTube</option>
								<option value="tiktok">TikTok</option>
								<option value="instagram">Instagram</option>
							</select>
						</div>
						<div class="form-row">
							<label>Quality:</label>
							<select id="exportQuality">
								<option value="draft">Draft (720p, faster)</option>
								<option value="final" selected>Final (1080p)</option>
							</select>
						</div>
						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="includeWatermark" checked>
								Include Watermark
							</label>
						</div>
						<div class="studio-actions-row">
							<button id="previewBtn" class="button button-secondary">▶ Preview</button>
							<button id="downloadBtn" class="button button-primary">⬇ Download</button>
						</div>
					</div>

					<!-- @NEW 2025-12-17: Brand Kit Presets -->
					<div class="control-group">
						<h3>💼 Brand Kit</h3>
						<div class="form-row">
							<label>Saved Presets:</label>
							<select id="brandKitSelect" style="width:100%;">
								<option value="">No saved presets</option>
							</select>
						</div>
						<div class="studio-actions-row">
							<button id="saveBrandKitBtn" class="button button-secondary">💾 Save Current</button>
							<button id="loadBrandKitBtn" class="button button-secondary">📂 Load</button>
						</div>
						<p class="description">
							Save logo, colors, fonts, and template as reusable presets.
						</p>
					</div>

					<!-- @NEW 2025-12-18: High-Performer SEO Metadata Generator -->
					<div class="control-group">
						<h3>🔍 SEO Metadata (High-Performer)</h3>
						<p class="description">Generate viral search-optimized data for TikTok, Shorts, and Reels.</p>

						<div class="form-row">
							<label class="toggle-label">
								<input type="checkbox" id="seoAutoGenerate" checked>
								Auto-generate SEO after AI quiz generation
							</label>
						</div>

						<div class="form-row">
							<label>Target Keyphrases:</label>
							<input type="text" id="seoKeywords" placeholder="e.g. general knowledge, trivia quiz, fun facts" style="width:100%;">
							<p class="description" style="font-size:10px;">Primary keywords the algorithm should index.</p>
						</div>

						<button id="generateSEOBtn" class="button button-secondary" style="width:100%;">✨ Generate SEO Data</button>

						<div id="seoResults" style="margin-top:10px; display:none;">
							<label>Optimized Title:</label>
							<input type="text" id="seoTitle" style="width:100%; font-weight:bold;" readonly>

							<label style="margin-top:8px; display:block;">Algorithm-Rich Description:</label>
							<textarea id="seoDescription" rows="4" style="width:100%; font-size:12px;" readonly></textarea>

							<label style="margin-top:8px; display:block;">3-3-3 Hashtags:</label>
							<input type="text" id="seoTags" style="width:100%;" readonly>

							<div style="display:flex; gap:5px; margin-top:10px;">
								<button id="copySEOBtn" class="button button-secondary" style="flex:1;">📋 Copy All</button>
								<button id="applyToExportBtn" class="button button-small" style="flex:1;" title="Apply to current export metadata">🚀 Apply</button>
							</div>
						</div>
					</div>

					<!-- @NEW 2025-12-18: Asset Library -->
					<div class="control-group">
						<h3>🖼️ Asset Library</h3>
						<p class="description">Reusable backgrounds and custom fonts.</p>
						<div class="asset-tabs">
							<button class="asset-tab-btn active" data-tab="backgrounds">BGs</button>
							<button class="asset-tab-btn" data-tab="fonts">Fonts</button>
							<button class="asset-tab-btn" data-tab="stock-videos">Stock</button>
						</div>
						<div id="assetList" class="asset-list-container">
							<!-- Assets loaded here -->
						</div>
						<div class="form-row">
							<button id="addAssetBtn" class="button button-secondary">➕ Add Current BG to Library</button>
						</div>
					</div>

					<!-- @NEW 2026-02-16: Content Planner Moved to Dedicated Page (mcqvs-content-planner) -->

					<!-- @NEW 2025-12-18: Job Manager UI -->
					<div class="control-group">
						<h3>📊 Job Manager</h3>
						<p class="description">Track rendering history and retry failed jobs.</p>
						<div id="jobList" style="max-height:200px; overflow-y:auto; background:#fff; border:1px solid #eee; border-radius:4px; padding:5px;">
							<p class="description">No jobs in history.</p>
						</div>
						<div style="margin-top:10px;">
							<button id="clearJobsBtn" class="button button-link" style="color:red; font-size:11px;">Clear All History</button>
						</div>
					</div>

					<!-- @NEW 2026-01-30: Diagnostics Tab (Production Support) -->
					<div class="control-group" id="mcqvs-diagnostics-panel">
						<h3>🩺 Diagnostics</h3>
						<p class="description">Generate a support-ready snapshot (plan + preflight + job state + logs).</p>
						<div class="studio-actions-row" style="gap:6px; flex-wrap:wrap;">
							<button id="mcqvsDiagRefreshBtn" class="button button-secondary">Refresh</button>
							<button id="mcqvsDiagCopyJsonBtn" class="button button-secondary">📋 Copy JSON</button>
							<button id="mcqvsDiagCopyLogsBtn" class="button button-secondary">📋 Copy Logs</button>
							<button id="mcqvsDiagDownloadJsonBtn" class="button button-secondary">⬇️ Download JSON</button>
							<!-- @NEW 2026-06-29: Logs-only download for full audit trail without the renderPlan/shapes payload -->
							<button id="mcqvsDiagDownloadLogsBtn" class="button button-secondary">⬇️ Download Logs</button>
							<button id="mcqvsDiagClearLogsBtn" class="button button-small">Clear Logs</button>
						</div>
						<textarea id="mcqvsDiagOutput" rows="10" readonly style="width:100%; margin-top:8px; font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; font-size:11px; background:#0b1220; color:#d1d5db; border:1px solid #1f2937; border-radius:6px; padding:8px;"></textarea>
						<p class="description" style="font-size:10px;">Tip: paste JSON/logs into your ticket. Logs include worker telemetry and preflight failures.</p>
					</div>

				</div>

				<!-- Preview Area -->
				<div class="studio-preview">
					<!-- @NEW 2026-01-18: Export Progress Bar -->
					<div id="exportProgressPanel" style="display:none; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; border-radius: 12px; padding: 16px 24px; margin: 0 auto 15px auto; box-shadow: 0 4px 20px rgba(0,0,0,0.3); min-width: 400px; max-width: 100%; width: calc(100% - 40px);">
						<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px; gap: 20px;">
							<span id="exportStatusText" style="color:#00f0ff; font-weight:600; font-size:15px; white-space:nowrap;">🎬 Preparing export...</span>
							<span id="exportPercentText" style="color:#94a3b8; font-size:14px; font-family:monospace; font-weight:600;">0%</span>
						</div>
						<div style="background:#0f172a; border-radius:8px; height:14px; overflow:hidden; border:1px solid #1e293b;">
							<div id="exportProgressBar" style="height:100%; width:0%; background: linear-gradient(90deg, #06b6d4, #3b82f6, #8b5cf6); border-radius:8px; transition: width 0.3s ease;"></div>
						</div>
						<div style="display:flex; justify-content:space-between; margin-top:10px; font-size:12px; color:#64748b;">
							<span id="exportJobInfo">Job: --</span>
							<span id="exportTimeInfo">--</span>
						</div>
					</div>

					<div id="previewScreen"<?php echo ($video_format === 'youtube') ? ' class="mcqvs-format-youtube"' : ''; ?>>
						<!-- Canvas injected here -->
						<canvas id="previewCanvas"></canvas>
					</div>
					<!-- @NEW 2025-12-18: Scrubbable Timeline -->
					<div class="studio-timeline">
						<div class="timeline-scrubber-row">
							<input type="range" id="timelineScrubber" min="0" max="1000" value="0">
						</div>
						<div class="timeline-controls-row">
							<button type="button" id="timelinePlayBtn" class="timeline-play-btn" title="Play/Pause">
								<span class="dashicons dashicons-controls-play"></span>
							</button>
							<div class="time-display">
								<span id="timelineCurrentTime">00:00</span>
								<span class="time-divider">/</span>
								<span id="timelineTotalDuration">00:00</span>
							</div>
						</div>
					</div>
					<div id="questionSelector" class="question-list-compact">
						<!-- Questions loaded here by JS -->
					</div>
				</div>

				<!-- @NEW 2026-02-16: Models (Hidden) -->
				<div id="contentPlannerModal" class="mcqvs-modal" style="display:none;">
					<div class="mcqvs-modal-content" style="max-width:800px;">
						<div class="mcqvs-modal-header">
							<h2>📅 30-Day Content Planner</h2>
							<span class="mcqvs-close-modal">&times;</span>
						</div>
						<div class="mcqvs-modal-body">
							<div class="form-row">
								<label>Niche / Topic(s):</label>
								<input type="text" id="plannerNiche" placeholder="e.g. 90s Nostalgia, Science Facts, Geography ... (Comma separate for multiple)" style="width:100%;">
							</div>
							<button id="generatePlanBtn" class="button button-primary">Generate Plan (AI)</button>

							<div id="plannerResults" style="margin-top:20px; display:none;">
								<h3>Review Topics</h3>
								<textarea id="plannerTopicsJson" rows="15" style="width:100%; font-family:monospace; font-size:12px;"></textarea>
								<p class="description">Edit JSON array directly if needed.</p>

								<div class="studio-actions-row" style="margin-top:15px; justify-content:flex-end;">
									<button id="approvePlanBtn" class="button button-primary">✅ Approve & Schedule All</button>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
		<?php if (defined('WP_DEBUG') && WP_DEBUG) : ?>
			<script>
				(function() {
					const required = [
						'#mcqvs-notifications',
						'#templateGrid',
						'.mcqvs-template-tabs',
						'.mcqvs-audio-tabs',
						'.mcqvs-audio-tab[data-tab="sfx"]',
						'#audio-tab-sfx',
						'#audio-tab-music',
						'#audio-tab-voice',
						'#uploadLogoBtn',
						'#logoPreview',
						'#brandLogoUrl',
						'#bgVideoUpload',
						'#previewBtn',
						'#downloadBtn'
					];
					const missing = required.filter(sel => !document.querySelector(sel));
					if (missing.length) {
						console.error('[MCQVS] MARKUP CONTRACT FAILED. Missing:', missing);
					}
				})();
			</script>
		<?php endif; ?>
	<?php
	}

	/**
	 * @NEW (cross-file audit): render_runner_page
	 *
	 * Lightweight admin page used ONLY by render.js when triggered by the
	 * Action Scheduler headless pipeline (via `run_headless_render_queue` →
	 * `handle_render_claim_action` → `VS_Headless_Renderer::render_job`).
	 *
	 * Unlike `render_studio_page()`, this page:
	 *   - does NOT enqueue the Studio UI bundle (`studio.controller.js`,
	 *     `studio.ui.js`, `studio.audio.js`, asset library, toast manager, …)
	 *   - does NOT depend on the entire WordPress admin chrome to reach `networkidle`
	 *   - loads ONLY the encoding modules (Web Worker + PlanBuilder + TemplateManager
	 *     + UnifiedRenderer) and a tiny runner script that performs the same
	 *     `auto_run_job=X` → `_autoRunnerLoop()` flow the Studio page would
	 *   - stamps `window.__MCQVSRenderRunnerActiveJob` and `__MCQVSRenderRunnerReady`
	 *     so render.js's `waitForFunction` resolves immediately
	 *
	 * No capability downgrade here — the headless render auth token is at most
	 * `exSubscriber`-style (see VS_Headless_Renderer::maybe_auth_from_cookie +
	 * ensure_render_user), so we still gate on `manage_options` via the auto-
	 * auth handler. The cookie + `is_admin()` + `$_GET['auto_run']` triple gate
	 * is unchanged vs the Studio page path.
	 */
	public function render_runner_page()
	{
		// @FIX (audit): Diagnose readiness-timeout failures from the SERVER side. If
		//        auth fails here, `wp_die` fires, the inline `__MCQVSRenderRunnerMounted`
		//        sentinel below never executes, render-runner.js never runs, and render.js's
		//        30s readiness gate times out with no actionable reason. Log the actual
		//        auth state so the log shows exactly why the page died.
		$current_user_id = get_current_user_id();
		$can_manage = current_user_can('manage_options');
		$has_auth_cookie = !empty($_COOKIE['mcqvs_render_auth']);
		$auth_token = $has_auth_cookie ? sanitize_text_field(wp_unslash($_COOKIE['mcqvs_render_auth'])) : '';
		$cookie_job_id = isset($_GET['job_id']) ? sanitize_text_field(wp_unslash($_GET['job_id'])) : (isset($_GET['auto_run_job']) ? sanitize_text_field(wp_unslash($_GET['auto_run_job'])) : '');
		$transient_exists = ($cookie_job_id && $auth_token) ? (bool) get_transient('mcqvs_render_auth_' . $cookie_job_id) : false;
		$verified_transient = ($cookie_job_id) ? (bool) get_transient('mcqvs_render_auth_verified_' . $cookie_job_id) : false;
		if (class_exists('VS_Error_Logger')) {
			VS_Error_Logger::get_instance()->log(
				'render_runner_page auth gate: user_id=' . $current_user_id . ' can_manage=' . ($can_manage ? '1' : '0') .
				' has_auth_cookie=' . ($has_auth_cookie ? '1' : '0') . ' token_len=' . strlen($auth_token) .
				' job_id=' . $cookie_job_id . ' auth_transient_exists=' . ($transient_exists ? '1' : '0') .
				' verified_transient=' . ($verified_transient ? '1' : '0'),
				$can_manage ? 'info' : 'error',
				array('job_id' => $cookie_job_id, '_type' => 'general')
			);
		}

		// @FIX: Mirror the Studio page's auth gate. The headless auth cookie handler
		//              logs the `mcqvs_render` user in only when both `is_admin()` is
		//              true and `$_GET['auto_run']=1`, both of which are satisfied
		//              here. We do NOT `wp_die` for missing capability because the
		//              auth cookie elevates the request before this runs — if for
		//              any reason the cookie fails, that's a render.js fatal error,
		//              not a generic 403.
		if (! current_user_can('manage_options')) {
			wp_die(esc_html__('Access denied', 'mcq-video-studio'));
		}

		$job_id = isset($_GET['auto_run_job']) ? sanitize_text_field(wp_unslash($_GET['auto_run_job'])) : '';
		?>
		<style>
			#mcqvs-render-runner { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 16px; background: #0a0a0a; color: #e0e0e0; font-family: "Inter", "Roboto", "Outfit", sans-serif; }
			#mcqvs-render-runner .status { font-size: 14px; opacity: 0.85; }
			#mcqvs-render-runner .job { font-size: 12px; color: #888; }
		</style>
		<div id="mcqvs-render-runner">
			<div class="status" id="mcqvs-render-runner-status">Initializing headless render…</div>
			<div class="job" id="mcqvs-render-runner-job"><?php echo esc_html($job_id); ?></div>
		</div>
		<?php
		/**
		 * Stamps that the runner page has mounted BEFORE the encoding bundles
		 * finish loading. This is the early handshake used by render.js's
		 * `page.waitForFunction(...)` to know the page is live.
		 *
		 * We also seed job ID on `window` so the runner JS does not need to
		 * re-parse the URL.
		 *
		 * @FIX (cross-file audit): Previously this page emitted its own full HTML
		 * document (<!DOCTYPE html><html>...). This caused admin-footer.php's
		 * enqueued scripts to be injected AFTER </html>, making them execute in
		 * the "post-document" phase where they never properly run. The result was
		 * `render-runner.js` never executing, `__MCQVSRenderRunnerReady` never set,
		 * and render.js's 30s readiness gate timing out with `runner_failed_to_bootstrap`.
		 */
		?>
		<script>
			window.__MCQVSRenderRunnerActiveJob = <?php echo wp_json_encode($job_id); ?>;
			window.__MCQVSRenderRunnerMounted = true;
		</script>
		<?php
	}

	/**
	 * AJAX: Fetch List of Topics/Exams (Sources)
	 * @MODIFIED 2026-01-05: Delegated to VS_AJAX_Studio_Handler
	 */
	public function ajax_get_studio_sources()
	{
		try {
			$this->studio_handler->ajax_get_studio_sources();
		} catch (\Throwable $e) {
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
					'file'    => $e->getFile(),
					'line'    => $e->getLine(),
				)
			);
		}
	}

	/**
	 * AJAX: Fetch Questions for a specific Topic/Exam
	 * @MODIFIED 2026-01-05: Delegated to VS_AJAX_Studio_Handler
	 */
	public function ajax_get_studio_data()
	{
		try {
			$this->studio_handler->ajax_get_studio_data();
		} catch (\Throwable $e) {
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
					'file'    => $e->getFile(),
					'line'    => $e->getLine(),
					'trace'   => $e->getTraceAsString(),
				)
			);
		}
	}



	/**
	 * @NEW 2026-01-10: Asset Proxy for COEP Compliance
	 * 
	 * Proxies external URLs and serves them with Cross-Origin-Resource-Policy header.
	 * Required for COEP: require-corp mode when loading external images/videos.
	 *
	 * @since 1.2.0
	 */
	/**
	 * @MODIFIED 2026-01-10: Hardening - Stream to temp file, strict host validation
	 * Proxy external assets with CORP header for COEP compliance
	 * Security: No memory bomb, no redirects, strict domain match
	 */
	public function ajax_proxy_asset()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$url = isset($_GET['url']) ? esc_url_raw(wp_unslash($_GET['url'])) : '';

		if (empty($url)) {
			wp_send_json_error('URL required');
		}

		// @MODIFIED 2026-01-10: Strict host validation via exact match (no stripos)
		$allowed_hosts = array(
			'images.pexels.com',
			'videos.pexels.com',
			'pixabay.com',
			// WordPress uploads
			parse_url(wp_upload_dir()['baseurl'], PHP_URL_HOST),
			// Current site domain
			parse_url(home_url(), PHP_URL_HOST),
		);

		$url_host = strtolower(parse_url($url, PHP_URL_HOST));

		// Strict exact match - no substring matching
		if (!in_array($url_host, array_map('strtolower', $allowed_hosts), true)) {
			VS_Error_Logger::get_instance()->log(
				'Asset proxy blocked: domain not allowed',
				'warning',
				array('host' => $url_host, 'url' => $url)
			);
			wp_send_json_error('Domain not allowed: ' . esc_html($url_host));
		}

		// @MODIFIED 2026-01-10: Stream to temp file (avoid memory bomb for large assets)
		$tmp_file = wp_tempnam('mcqvs_asset_');
		if (!$tmp_file) {
			wp_send_json_error('Failed to create temp file');
		}

		// Fetch with streaming, no redirects (SSRF protection)
		$response = wp_remote_get($url, array(
			'timeout'     => 60,
			'sslverify'   => true,
			'stream'      => true,
			'filename'    => $tmp_file,
			'redirection' => 0, // No redirects - prevents SSRF/open-redirect
		));

		if (is_wp_error($response)) {
			@unlink($tmp_file);
			VS_Error_Logger::get_instance()->log(
				'Asset proxy fetch failed',
				'error',
				array('url' => $url, 'error' => $response->get_error_message())
			);
			wp_send_json_error('Fetch failed: ' . $response->get_error_message());
		}

		$response_code = wp_remote_retrieve_response_code($response);
		if ($response_code !== 200) {
			@unlink($tmp_file);
			wp_send_json_error('Upstream returned: ' . $response_code);
		}

		// Get content type and file size
		$content_type = wp_remote_retrieve_header($response, 'content-type');
		$file_size = filesize($tmp_file);

		if (!$file_size || $file_size === 0) {
			@unlink($tmp_file);
			wp_send_json_error('Empty response from upstream');
		}

		// @NEW 2026-02-01: Strict Content-Type Validation
		$safe_types = array('image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm', 'audio/mpeg', 'audio/wav');
		if (!in_array(strtolower($content_type), $safe_types, true)) {
			@unlink($tmp_file);
			wp_send_json_error('Blocked unsafe content type: ' . esc_html($content_type));
		}

		// Output with CORP header for COEP compliance
		header('Content-Type: ' . ($content_type ?: 'application/octet-stream'));
		header('Content-Length: ' . $file_size);
		header('Cross-Origin-Resource-Policy: cross-origin');
		header('Cache-Control: public, max-age=86400'); // Cache for 1 day

		// Stream file to output and cleanup
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_readfile
		readfile($tmp_file);
		@unlink($tmp_file);
		exit;
	}

	/**
	 * @NEW 2025-12-19: Save Branding Settings
	 * Persists logo URL, position, and CTA preset to wp_options
	 */
	/**
	 * @MODIFIED 2026-01-05: Delegated to VS_AJAX_Branding_Handler
	 */
	public function ajax_save_branding()
	{
		try {
			$this->branding_handler->ajax_save_branding();
		} catch (\Throwable $e) {
			wp_send_json_error(array('message' => $e->getMessage()));
		}
	}

	/**
	 * @NEW 2025-12-19: Get Branding Settings
	 * Retrieves saved branding settings for initialization
	 */
	/**
	 * @MODIFIED 2026-01-05: Delegated to VS_AJAX_Branding_Handler
	 */
	public function ajax_get_branding()
	{
		try {
			$this->branding_handler->ajax_get_branding();
		} catch (\Throwable $e) {
			wp_send_json_error(array('message' => $e->getMessage()));
		}
	}

	// ============================================================
	// @NEW 2026-01-10: Project CRUD AJAX Handlers
	// ============================================================

	/**
	 * Save project to database
	 */
	public function ajax_save_project()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$data = array(
			'project_id' => isset($_POST['project_id']) ? absint($_POST['project_id']) : 0,
			'title'      => isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '',
			'template'   => isset($_POST['template']) ? sanitize_text_field(wp_unslash($_POST['template'])) : 'modern',
			'settings'   => isset($_POST['settings']) ? json_decode(wp_unslash($_POST['settings']), true) : array(),
			'questions'  => isset($_POST['questions']) ? json_decode(wp_unslash($_POST['questions']), true) : array(),
		);

		$project_repo = VS_Project_Repository::init();
		$project_id = $project_repo->save_from_frontend($data);

		if (is_wp_error($project_id)) {
			wp_send_json_error($project_id->get_error_message());
		}

		$questions = $data['questions'] ?? array();
		$question_count = count($questions);

		if ($question_count > 0) {
			$job_repo = VS_Job_Repository::init();

			$job_settings = isset($data['settings']) ? $data['settings'] : array();
			$job_settings['source'] = 'project';
			$job_settings['project_id'] = $project_id;

			$job_id = $job_repo->create_job(array(
				'project_id'     => $project_id,
				'topic_id'       => 0,
				'question_count' => $question_count,
				'platform'       => $job_settings['platform'] ?? 'all',
				'status'         => VS_Job_Status::PENDING,
				'quiz_data'      => $questions,
				'settings'       => $job_settings,
				'scheduled_at'   => gmdate('Y-m-d H:i:s'),
			));

			if (!is_wp_error($job_id)) {
				$project_repo->update_status($project_id, VS_Project_Status::DRAFT, array(
					'job_id' => $job_id
				));

				VS_Error_Logger::get_instance()->log('Auto-created job for project', 'info', array(
					'project_id' => $project_id,
					'job_id' => $job_id
				));
			}
		}

		wp_send_json_success(array(
			'project_id' => $project_id,
			'job_id' => $job_id ?? null
		));
	}

	/**
	 * Load project from database
	 */
	public function ajax_load_project()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$project_id = isset($_POST['project_id']) ? absint($_POST['project_id']) : 0;
		if (!$project_id) {
			wp_send_json_error('Project ID required');
		}

		$repo = VS_Project_Repository::init();
		$project = $repo->get_project($project_id);

		if (!$project) {
			wp_send_json_error('Project not found');
		}

		wp_send_json_success($project);
	}

	/**
	 * List user projects
	 */
	public function ajax_list_projects()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$repo = VS_Project_Repository::init();
		$projects = $repo->get_user_projects(get_current_user_id(), 20);

		wp_send_json_success(array('projects' => $projects));
	}

	/**
	 * Delete project
	 */
	public function ajax_delete_project()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$project_id = isset($_POST['project_id']) ? absint($_POST['project_id']) : 0;
		if (!$project_id) {
			wp_send_json_error('Project ID required');
		}

		$repo = VS_Project_Repository::init();
		$deleted = $repo->delete_project($project_id);

		if (!$deleted) {
			wp_send_json_error('Failed to delete project');
		}

		wp_send_json_success(array('deleted' => true));
	}

	/**
	 * Persist Self-Test report (client-side diagnostics)
	 * Used for activation gating + admin notices.
	 */
	public function ajax_save_selftest_report()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$raw_report = isset($_POST['report']) ? wp_unslash($_POST['report']) : '';
		if (!$raw_report) {
			wp_send_json_error('Report required');
		}

		$report = json_decode($raw_report, true);
		if (!is_array($report)) {
			wp_send_json_error('Invalid report JSON');
		}

		$status = (isset($report['overall']) && $report['overall'] === 'pass') ? 'pass' : 'fail';
		update_option('mcqvs_selftest_status', $status);
		update_option('mcqvs_selftest_last_run', time());

		// Store a bounded report snapshot (avoid option bloat)
		$snapshot = wp_json_encode($report);
		if (is_string($snapshot) && strlen($snapshot) > 150000) {
			$snapshot = substr($snapshot, 0, 150000) . '...';
		}
		update_option('mcqvs_selftest_last_report', $snapshot);

		wp_send_json_success(array('status' => $status));
	}

	/**
	 * Render the System Health components (Self-Test internal content).
	 */
	private function render_self_test_content()
	{
	?>
		<div class="notice notice-info" style="max-width: 1100px;">
			<p style="margin:8px 0;">
				<strong>What this does:</strong> Validates template schema, builds/validates RenderPlan, runs asset preflight, then initializes the WebCodecs worker and renders 1 frame.
				If this page passes, your admin environment is capable of deterministic preview/export.
			</p>
		</div>

		<div style="display:flex; gap:16px; align-items:flex-end; max-width: 1100px; margin-bottom: 12px;">
			<div>
				<label for="mcqvsSelfTestTemplate"><strong>Template</strong></label><br>
				<select id="mcqvsSelfTestTemplate">
					<optgroup label="Professional">
						<option value="corporate" selected>Corporate</option>
						<option value="elegant">Elegant</option>
					</optgroup>
					<optgroup label="Neon">
						<option value="neon">Neon</option>
						<option value="fire">Fire</option>
						<option value="electric">Electric</option>
					</optgroup>
					<optgroup label="School">
						<option value="classroom">Classroom</option>
						<option value="science">Science</option>
						<option value="history">History</option>
					</optgroup>
				</select>
			</div>

			<button type="button" id="mcqvsSelfTestRunBtn" class="button button-primary">Run Self-Test</button>
			<button type="button" id="mcqvsSelfTestDownloadBtn" class="button button-secondary">⬇️ Download Report</button>
		</div>

		<table class="widefat striped" style="max-width: 1100px;">
			<thead>
				<tr>
					<th style="width: 240px;">Test</th>
					<th style="width: 120px;">Status</th>
					<th>Details</th>
				</tr>
			</thead>
			<tbody>
				<tr id="mcqvsSelfTestRow_schema" data-status="">
					<td>Template schema</td>
					<td><span class="mcqvs-st-status"></span></td>
					<td><span class="mcqvs-st-detail"></span></td>
				</tr>
				<tr id="mcqvsSelfTestRow_renderplan" data-status="">
					<td>Render plan</td>
					<td><span class="mcqvs-st-status"></span></td>
					<td><span class="mcqvs-st-detail"></span></td>
				</tr>
				<tr id="mcqvsSelfTestRow_preflight" data-status="">
					<td>Asset preflight</td>
					<td><span class="mcqvs-st-status"></span></td>
					<td><span class="mcqvs-st-detail"></span></td>
				</tr>
				<!-- @NEW 2026-06-29: Regression guard for diagnostics buffer (was silently empty in production before F2) -->
				<tr id="mcqvsSelfTestRow_logger" data-status="">
					<td>Diagnostics logger</td>
					<td><span class="mcqvs-st-status"></span></td>
					<td><span class="mcqvs-st-detail"></span></td>
				</tr>
				<tr id="mcqvsSelfTestRow_worker" data-status="">
					<td><strong>Worker init + 1-frame render</strong></td>
					<td class="mcqvs-st-status">—</td>
					<td class="mcqvs-st-detail"></td>
				</tr>
				<tr id="mcqvsSelfTestRow_pipeline" data-status="">
					<td><strong>Mini export pipeline (encode)</strong></td>
					<td class="mcqvs-st-status">—</td>
					<td class="mcqvs-st-detail"></td>
				</tr>
			</tbody>
		</table>

		<h2 style="max-width:1100px; margin-top: 18px;">Log</h2>
		<textarea id="mcqvsSelfTestLog" style="width:100%; max-width:1100px; height: 260px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"></textarea>
<?php
	}



	// ============================================================
	// @NEW 2026-02-08: Content Calendar AJAX Handlers
	// ============================================================

	/**
	 * AJAX: Bulk Schedule
	 */
	public function ajax_bulk_schedule()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$topic = sanitize_text_field($_POST['topic'] ?? '');
		$total_questions = absint($_POST['total_questions'] ?? 30);
		$questions_per_video = absint($_POST['questions_per_video'] ?? 5);
		$start_date = sanitize_text_field($_POST['start_date'] ?? '');
		$frequency = sanitize_text_field($_POST['frequency'] ?? 'daily');
		$settings = isset($_POST['settings']) ? json_decode(wp_unslash($_POST['settings']), true) : array();

		if (empty($topic) || empty($start_date)) {
			wp_send_json_error('Topic and start date are required.');
		}

		$scheduler = VS_Bulk_Scheduler::init();
		$result = $scheduler->handle_bulk_request(
			$topic,
			$total_questions,
			$questions_per_video,
			$start_date,
			$frequency,
			$settings
		);

		if (is_wp_error($result)) {
			wp_send_json_error($result->get_error_message());
		}

		wp_send_json_success($result);
	}

	/**
	 * AJAX: List Calendar Jobs
	 */
	public function ajax_list_calendar_jobs()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$job_repo = VS_Job_Repository::init();
		$valid_statuses = array(
			VS_Job_Status::PENDING,
			VS_Job_Status::READY_FOR_RENDER,
			VS_Job_Status::RENDERING,
			VS_Job_Status::COMPLETED
		);

		global $wpdb;
		$table = $job_repo->get_table_name();
		$placeholders = implode(',', array_fill(0, count($valid_statuses), '%s'));

		$jobs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status IN ({$placeholders}) ORDER BY scheduled_at ASC",
				$valid_statuses
			),
			ARRAY_A
		);

		foreach ($jobs as &$job) {
			if (!empty($job['quiz_data'])) {
				$job['quiz_data'] = json_decode($job['quiz_data'], true);
			}
			if (!empty($job['settings'])) {
				$job['settings'] = json_decode($job['settings'], true);
			}
		}

		wp_send_json_success(array('jobs' => $jobs));
	}

	/**
	 * AJAX: Get Calendar Job
	 */
	public function ajax_get_calendar_job()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$job_id = sanitize_text_field($_POST['job_id'] ?? '');

		if (empty($job_id)) {
			wp_send_json_error('Job ID is required.');
		}

		$job_repo = VS_Job_Repository::init();
		$job = $job_repo->get_job($job_id);

		if (!$job) {
			wp_send_json_error('Job not found.');
		}

		if (!empty($job['quiz_data'])) {
			$job['quiz_data'] = VS_Job_Repository::normalize_quiz_data($job['quiz_data']);
		}
		if (!empty($job['settings'])) {
			$job['settings'] = json_decode($job['settings'], true);
		}

		wp_send_json_success(array('job' => $job));
	}

	/**
	 * AJAX: Delete Calendar Job
	 */
	public function ajax_delete_calendar_job()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$job_id = sanitize_text_field($_POST['job_id'] ?? '');

		if (empty($job_id)) {
			wp_send_json_error('Job ID is required.');
		}

		$job_repo = VS_Job_Repository::init();

		if ($job_repo->delete_job($job_id)) {
			wp_send_json_success(array('message' => 'Job deleted.'));
		} else {
			wp_send_json_error('Failed to delete job.');
		}
	}

	/**
	 * AJAX: Get Batch Status
	 */
	public function ajax_get_batch_status()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error('Access denied');
		}

		$batch_id = sanitize_text_field($_POST['batch_id'] ?? '');

		if (empty($batch_id)) {
			wp_send_json_error('Batch ID is required.');
		}

		$batch_meta = get_option('mcqvs_batch_' . $batch_id);

		if (!$batch_meta) {
			wp_send_json_error('Batch not found.');
		}

		wp_send_json_success(array('batch' => $batch_meta));
	}
	/**
	 * @NEW 2026-02-14: Scan a subdirectory in assets/audio for MP3 files.
	 * Helps automate the audio library for the Studio.
	 */
	private function scan_audio_directory($subdir)
	{
		$dir = mcqvs_assets_dir( 'audio/' . $subdir );
		$assets_url = mcqvs_assets_url( 'audio/' . $subdir . '/' );
		$results = array();

		if (! is_dir($dir)) {
			return $results;
		}

		$files = glob($dir . '/*.mp3');
		if (! $files) {
			return $results;
		}

		foreach ($files as $file) {
			$filename = basename($file);
			$name = str_replace(array('-', '_'), ' ', pathinfo($filename, PATHINFO_FILENAME));
			$name = ucwords($name);

			$results[] = array(
				'id'   => pathinfo($filename, PATHINFO_FILENAME),
				'name' => $name,
				'url'  => $assets_url . $filename,
			);
		}

		return $results;
	}

	/**
	 * AJAX: Increment global video created counter.
	 * Called from JS when any export completes (manual, batch, auto-runner).
	 * @NEW 2026-02-23
	 */
	public function ajax_increment_video_count()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Forbidden');
		}

		VS_Error_Logger::increment_video_count();
		wp_send_json_success(array('message' => 'Video count incremented.'));
	}

	/**
	 * AJAX: List background videos from assets/bg-videos/ folder.
	 * Returns categorized JSON grouped by video name prefix.
	 * @NEW 2026-02-23
	 */
	public function ajax_list_bg_videos()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Forbidden');
		}

		$dir = mcqvs_assets_dir( 'bg-videos/' );
		$url_base = mcqvs_assets_url( 'bg-videos/' );
		$categories = array();

		if (is_dir($dir)) {
			$files = glob($dir . '*.mp4');
			foreach ($files as $file) {
				$filename = basename($file);
				// Extract category from filename: "Abstract Art (1).mp4" -> "Abstract Art"
				$category = preg_replace('/\s*\(\d+\)$/', '', pathinfo($filename, PATHINFO_FILENAME));
				$category = ucwords(trim($category));

				if (!isset($categories[$category])) {
					$categories[$category] = array();
				}

				$categories[$category][] = array(
					'filename' => $filename,
					'url'      => $url_base . $filename,
					'size'     => filesize($file),
				);
			}
		}

	wp_send_json_success(array('categories' => $categories));
	}

	// @NEW 2026-04-24: Save video format preference (shorts/youtube)
	public function ajax_save_video_format()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error('Forbidden');
		}

		$format = isset($_POST['format']) ? sanitize_text_field(wp_unslash($_POST['format'])) : 'shorts';
		if (!in_array($format, array('shorts', 'youtube'), true)) {
			wp_send_json_error('Invalid format');
		}

		update_option('mcqvs_video_format', $format);
		wp_send_json_success(array('format' => $format));
	}

	public function ajax_get_job_status()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Job ID required');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);

        if (!$job) {
            wp_send_json_error('Job not found');
        }

        $lock_exists = false;
        $buffer_client = class_exists('VS_Buffer_Client') ? VS_Buffer_Client::init() : null;
        if ($buffer_client) {
            $lock_key = 'mcqvs_job_lock_' . $job_id;
            $lock_exists = (bool) get_transient($lock_key);
        }

        wp_send_json_success(array(
            'status'           => $job['status'],
            'video_url'        => $job['video_url'] ?? '',
            'job_id'           => $job['job_id'],
            'claim_lock_exists' => $lock_exists,
        ));
    }

    /**
     * @NEW 2026-07-04 (F5): Manually kick off a server-side headless render for a
     *          single job. This is the bridge that closes the Studio
     *          "Server-Side Rendering" toggle so the user does not have to wait
     *          up to 5 minutes for the Action Scheduler cron.
     *
     *          - Validates the caller is an admin.
     *          - Returns WP_Error if Chromium or Node is misconfigured.
     *          - Marks the job as `rendering` so the Studio queue-runner UI updates.
     */
    public function ajax_render_now()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Job ID required');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (!$job) {
            wp_send_json_error('Job not found');
        }

        // Guard: only allow rendering jobs that haven't already finished/failed.
        if (in_array($job['status'], array(VS_Job_Status::COMPLETED, VS_Job_Status::FAILED), true)) {
            wp_send_json_error('Job already finalized: ' . $job['status']);
        }

        if (!class_exists('VS_Headless_Renderer')) {
            wp_send_json_error('Headless renderer class is missing');
        }

        // Don't double-spawn.
        if (VS_Headless_Renderer::get_instance()->is_render_running($job_id)) {
            wp_send_json_success(array('job_id' => $job_id, 'already_running' => true));
        }

        $result = VS_Headless_Renderer::get_instance()->render_job($job_id);
        if (is_wp_error($result)) {
            $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $result->get_error_message()));
            wp_send_json_error($result->get_error_message());
        }

        // Best-effort state flip so the Studio poll UI shows "rendering" immediately.
        if ($job['status'] !== VS_Job_Status::RENDERING) {
            $job_repo->update_status($job_id, VS_Job_Status::RENDERING);
        }

        wp_send_json_success(array(
            'job_id' => $job_id,
            'spawned_at' => time(),
            'pid' => absint(get_transient('mcqvs_render_pid_' . $job_id)),
        ));
    }

    public function ajax_verify_render_auth()
    {
        $job_id = sanitize_text_field($_POST['job_id'] ?? $_GET['job_id'] ?? '');
        $token = sanitize_text_field($_POST['token'] ?? $_GET['token'] ?? '');

        if (empty($job_id) || empty($token)) {
            wp_send_json_error('Missing parameters');
        }

        $rate_key = 'mcqvs_auth_attempts_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
        $attempts = absint(get_transient($rate_key));
        if ($attempts > 10) {
            wp_send_json_error('Too many attempts. Wait 5 minutes.');
        }
        set_transient($rate_key, $attempts + 1, 300);

        if (VS_Headless_Renderer::verify_auth_token($job_id, $token)) {
            delete_transient($rate_key);
            // @FIX: Auto-create the render service user if missing — previously every headless
            //       render came back "Render user not configured".
            $render_user_id = VS_Headless_Renderer::ensure_render_user();
            if (empty($render_user_id)) {
                wp_send_json_error('Render user not configured and could not be auto-created');
            }
            wp_set_current_user($render_user_id);
            // @FIX: Subscriber doesn't have `edit_posts`. Bump to `contributor` on creation so
            //       the headless browser can read the studio sources/data via AJAX (which checks
            //       `manage_options` for unauth and `edit_posts` for auto-runner endpoints).
            $u = get_userdata($render_user_id);
            if ($u && !in_array('contributor', (array) $u->roles, true) && !in_array('administrator', (array) $u->roles, true)) {
                $u->add_role('contributor');
            }
            wp_send_json_success(array('authenticated' => true));
        } else {
            wp_send_json_error('Invalid or expired token');
        }
    }

    public function ajax_test_headless()
    {
 check_ajax_referer('mcqvs_studio_nonce', 'nonce');
 if (!current_user_can('manage_options')) {
 wp_send_json_error('Forbidden');
 }

        $node_path = get_option('mcqvs_node_path', '/usr/bin/node');
	if (empty($node_path)) {
		$node_path = '/usr/bin/node';
	}
        $render_service = MCQVS_PLUGIN_DIR . 'render-service';
        $results = array();

        // 1) Node.js
        if (!file_exists($node_path) || !is_executable($node_path)) {
            $results['node'] = 'NOT FOUND at ' . $node_path;
        } else {
            $results['node'] = 'FOUND: ' . trim((string) shell_exec(escapeshellarg($node_path) . ' --version 2>&1'));
        }

        // 2) FFmpeg (reuse the plugin's auto-detector)
        $ffmpeg = class_exists('VS_Headless_Renderer') ? VS_Headless_Renderer::auto_detect_ffmpeg() : '';
        $results['ffmpeg'] = $ffmpeg ? 'FOUND: ' . $ffmpeg : 'NOT FOUND (install ffmpeg)';

        // 3) node-canvas (native module required by render-node.js)
        $canvas_ok = false;
        if (file_exists($node_path) && is_dir($render_service . '/node_modules')) {
            // Must run from render-service so Node resolves its local node_modules/canvas.
            $probe = shell_exec('cd ' . escapeshellarg($render_service) . ' && ' . escapeshellarg($node_path) . ' -e "require(\'canvas\');console.log(\'ok\')" 2>&1');
            $canvas_ok = (trim((string) $probe) === 'ok');
        }
        if ($canvas_ok) {
            $results['node_canvas'] = 'OK';
        } elseif (is_dir($render_service . '/node_modules/canvas') && !file_exists($render_service . '/node_modules/canvas/build/Release/canvas.node')) {
            // @FIX 1.4.9.40: npm >= 12 blocks install scripts by default, so `npm install`
            // can leave node_modules/canvas present WITHOUT the native binary (node-pre-gyp
            // never ran). The plugin now auto-fixes this (allowScripts in package.json +
            // `npm rebuild canvas` fallback); this message tells the admin how to do it by hand.
            // NOTE: node must run FROM the render-service dir — `require('canvas')` from
            // another cwd (e.g. the home dir) fails even when canvas is fine.
            $results['node_canvas'] = 'BROKEN — canvas folder exists but the native binary is missing (npm 12 blocked node-pre-gyp). Auto-heal ran; if still failing run in ' . $render_service . ': npm install-scripts approve canvas && npm rebuild canvas';
        } else {
            $results['node_canvas'] = 'MISSING — click "Setup Server Environment" below (one-click, no SSH) or run: cd ' . $render_service . ' && npm install';
        }

        // 4) Template fonts — renderer checks assets_js_dir/fonts (assets/js/fonts) but
        //    many installs keep fonts at assets/fonts, so accept both layouts.
        $fonts_candidates = array(
            dirname($render_service) . '/assets/js/fonts',
            dirname($render_service) . '/assets/fonts',
        );
        $fonts_found = '';
        foreach ($fonts_candidates as $fc) {
            if (is_dir($fc)) { $fonts_found = $fc; break; }
        }
        $results['fonts'] = $fonts_found ? 'FOUND: ' . $fonts_found : 'MISSING: ' . implode(' | ', $fonts_candidates);

        // 5) Edge TTS — only required if voiceover is enabled
        $results['tts'] = 'Optional — required only if voiceover is enabled (outbound wss://speech.platform.bing.com)';

        wp_send_json_success($results);
    }

    /**
     * @FIX 1.4.9.43 (self-sufficient): One-click "Setup Server Environment".
     *
     * Provisions the whole headless stack from the admin UI — no SSH needed:
     *  1. Node.js: if missing or < 18, downloads a portable linux-x64/arm64
     *     build into uploads/mcq-video-studio/runtime/ and sets mcqvs_node_path.
     *  2. Render deps: force `npm install` in render-service → canvas 3.x
     *     (N-API prebuild), ffmpeg-static (bundled static ffmpeg), ws.
     *  3. Verifies: node --version, canvas require(), ffmpeg detection, fonts.
     */
    /**
     * @FIX 1.4.9.44 (self-sufficient): Download + extract a portable Node.js into
     * uploads/mcq-video-studio/runtime/ and point mcqvs_node_path at it. Used when
     * no usable node (or no usable npm) is available to PHP — makes the plugin
     * fully independent of the VPS's Node setup.
     *
     * @return array{ok:bool,node?:string,message:string}
     */
    private function provision_portable_node()
    {
        $node_ver = 'v22.23.2'; // LTS-era, verified against the full render pipeline
        $arch = strtolower((string) php_uname('m'));
        $map = array('x86_64' => 'x64', 'amd64' => 'x64', 'aarch64' => 'arm64', 'arm64' => 'arm64');
        $node_arch = isset($map[$arch]) ? $map[$arch] : '';
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'LIN' || empty($node_arch)) {
            return array('ok' => false, 'message' => 'Cannot auto-provision Node on this OS/arch (' . PHP_OS . '/' . $arch . ') — install Node >= 18 manually.');
        }
        if (!class_exists('PharData')) {
            return array('ok' => false, 'message' => 'PHP PharData extension missing — cannot extract portable Node. Install Node >= 18 manually.');
        }

        $uploads = wp_upload_dir();
        $runtime_dir = trailingslashit($uploads['basedir']) . 'mcq-video-studio/runtime';
        if (!is_dir($runtime_dir)) {
            @wp_mkdir_p($runtime_dir);
        }
        $tarball = 'node-' . $node_ver . '-linux-' . $node_arch . '.tar.gz';
        $url = 'https://nodejs.org/dist/' . $node_ver . '/' . $tarball;
        $tmp = trailingslashit($runtime_dir) . $tarball;

        $dl = wp_remote_get($url, array('timeout' => 600, 'stream' => true, 'filename' => $tmp));
        if (is_wp_error($dl) || !file_exists($tmp) || filesize($tmp) < 1000000) {
            @unlink($tmp);
            return array('ok' => false, 'message' => 'Node download failed: ' . (is_wp_error($dl) ? $dl->get_error_message() : 'file too small'));
        }

        try {
            $phar = new PharData($tmp);
            $phar->extractTo($runtime_dir, null, true);
            $node_bin = trailingslashit($runtime_dir) . 'node-' . $node_ver . '-linux-' . $node_arch . '/bin/node';
            @unlink($tmp);
            if (@is_executable($node_bin)) {
                update_option('mcqvs_node_path', $node_bin);
                return array('ok' => true, 'node' => $node_bin, 'message' => 'Portable Node provisioned: ' . $node_bin);
            }
            return array('ok' => false, 'message' => 'Node extracted but binary not found at ' . $node_bin);
        } catch (\Throwable $e) {
            @unlink($tmp);
            return array('ok' => false, 'message' => 'Node extraction failed: ' . $e->getMessage());
        }
    }

    public function ajax_setup_environment()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        if (function_exists('set_time_limit')) {
            @set_time_limit(0);
        }
        @ini_set('memory_limit', '512M');
        if (function_exists('ini_set')) {
            @ini_set('max_execution_time', '600');
        }

        $steps = array();
        $errors = array();

        // ---------- 1) Node.js ----------
        $node_path = get_option('mcqvs_node_path', '');
        $node_ok = false;
        if (!empty($node_path) && @is_executable($node_path)) {
            $ver = trim((string) @shell_exec(escapeshellarg($node_path) . ' --version 2>&1'));
            $node_ok = (preg_match('/v(\d+)\./', (string) $ver, $m) && (int) $m[1] >= 18);
            $steps['node'] = $node_ok
                ? 'Using configured Node ' . $ver . ' (' . $node_path . ')'
                : 'Configured node ' . $ver . ' is too old (< 18) or broken — will provision portable.';
        }
        if (!$node_ok) {
            $which = trim((string) @shell_exec('which node 2>/dev/null'));
            if (!empty($which) && @is_executable($which)) {
                $ver = trim((string) @shell_exec(escapeshellarg($which) . ' --version 2>&1'));
                $node_ok = (preg_match('/v(\d+)\./', (string) $ver, $m) && (int) $m[1] >= 18);
                if ($node_ok) {
                    update_option('mcqvs_node_path', $which);
                    $steps['node'] = 'Using system Node ' . $ver . ' (' . $which . ')';
                }
            }
        }

        if (!$node_ok) {
            $pn = $this->provision_portable_node();
            $steps['node'] = $pn['message'];
            if (!$pn['ok']) {
                $errors[] = $pn['message'];
            }
        }

        // ---------- 2) Render deps (canvas + ffmpeg-static + ws) ----------
        $deps_ok = false;
        $deps_log = '';
        if (class_exists('VS_Installer')) {
            $res = VS_Installer::force_install_render_deps();
            $deps_log = trim((string) $res['log']);
            $steps['deps'] = $res['ok']
                ? 'npm install OK — canvas 3.x + ffmpeg-static + ws ready.'
                : 'npm install finished with issues (see log).';
            $deps_ok = $res['ok'];
        } else {
            $errors[] = 'VS_Installer class not loaded.';
        }

        // ---------- 2b) Retry once with a portable Node ----------
        // Covers servers where the system node exists but has NO usable npm for
        // PHP (nvm-only installs, bare-binary node in /usr/bin). The plugin's own
        // portable node ships npm, so installs succeed regardless of the host.
        if (!$deps_ok) {
            $pn = $this->provision_portable_node();
            if ($pn['ok']) {
                $res2 = VS_Installer::force_install_render_deps();
                $deps_ok = $res2['ok'];
                $deps_log .= "\n" . trim((string) $res2['log']);
                $steps['node_retry'] = $pn['message'] . ($deps_ok ? ' — npm install OK on retry.' : ' — npm install still failed.');
            } else {
                $steps['node_retry'] = 'Portable-Node retry skipped: ' . $pn['message'];
            }
        }
        if (!$deps_ok && !empty($deps_log)) {
            $errors[] = 'npm install did not fully succeed: ' . substr($deps_log, 0, 500);
        }

        // ---------- 3) Final verification ----------
        $verify = array();
        $node_use = get_option('mcqvs_node_path', '/usr/bin/node');
        if (@is_executable($node_use)) {
            $verify['node'] = trim((string) @shell_exec(escapeshellarg($node_use) . ' --version 2>&1'));
        } else {
            $verify['node'] = 'NOT FOUND at ' . $node_use;
        }
        $render_service = MCQVS_PLUGIN_DIR . 'render-service';
        $canvas_probe = shell_exec('cd ' . escapeshellarg($render_service) . ' && ' . escapeshellarg($node_use) . ' -e "require(\'canvas\');console.log(\'ok\')" 2>&1');
        $verify['canvas'] = (trim((string) $canvas_probe) === 'ok') ? 'OK' : 'FAIL — ' . trim((string) $canvas_probe);
        $ffmpeg = class_exists('VS_Headless_Renderer') ? VS_Headless_Renderer::auto_detect_ffmpeg() : '';
        $verify['ffmpeg'] = $ffmpeg ? $ffmpeg : 'NOT FOUND';
        $verify['fonts'] = is_dir($render_service . '/../assets/fonts') ? $render_service . '/../assets/fonts' : (is_dir($render_service . '/../assets/js/fonts') ? $render_service . '/../assets/js/fonts' : 'MISSING');

        wp_send_json_success(array(
            'steps'  => $steps,
            'errors' => $errors,
            'verify' => $verify,
            'all_ok' => empty($errors) && $verify['canvas'] === 'OK' && $verify['ffmpeg'] !== 'NOT FOUND' && $verify['node'] !== 'NOT FOUND',
        ));
    }

    /**
     * AJAX: Apply polled-job settings to staging state.
     *
     * The auto-runner browsers (`mcqvs-studio-controller` and `StudioPreview`)
     * previously called `mcqvs_apply_job_settings` from JS but the action was never
     * bound. This endpoint simply returns the job's normalized settings and lets
     * the client re-hydrate state — it does NOT mutate DB rows, since the canonical
     * settings now live in `vs_jobs.settings` (JSON) and the in-memory state is
     * the only thing that needs to apply.
     *
     * @since 1.4.9.0
     */
    public function ajax_apply_job_settings()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Job ID required');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (! $job) {
            wp_send_json_error('Job not found');
        }

        $settings = json_decode($job['settings'] ?? '{}', true);
        if (! is_array($settings)) {
            $settings = array();
        }

        $questions = json_decode($job['quiz_data'] ?? '[]', true);
        if (! is_array($questions)) {
            $questions = array();
        }

        wp_send_json_success(array(
            'job_id'    => $job_id,
            'settings'  => $settings,
            'questions' => $questions,
            'status'    => $job['status'] ?? VS_Job_Status::PENDING,
        ));
    }
}
