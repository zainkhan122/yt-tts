<?php

namespace DIT\TrendStudio\Core;

use DIT\TrendStudio\Services\Collage_Generator;
use DIT\TrendStudio\Services\Social_Queue_Manager;

class Social_Bootstrap
{
    const SOCIAL_IMAGE_META_KEY = '_dit_ts_social_collage_id';
    const JETPACK_META_KEY = '_wpas_mess'; // correct key (not _wpas_messages)
    const JETPACK_IMAGE_META = '_wpas_media_src';
    const JETPACK_SOCIAL_OPTIONS = '_wpas_options'; // modern Jetpack Social reads this for share image
    const CRON_HOOK = 'dit_ts_process_social_queue';
    const CRON_INTERVAL = 'dit_ts_every_5_min';
    const ASYNC_COLLAGE_HOOK = 'dit_ts_async_generate_social_collage';

    public static function update_jetpack_social_options(int $post_id, int $media_id, string $media_url, string $source = 'media-library'): void
    {
        $options = (array) \get_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, true);
        $options['attached_media'] = [
            ['id' => $media_id, 'url' => $media_url, 'type' => 'image'],
        ];
        $options['media_source'] = $source;
        \update_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, $options);
    }

    public static function resolve_collage_url(int $post_id): string
    {
        $collage_id = (int) get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        if (!$collage_id) return '';

        $url = wp_get_attachment_url($collage_id);
        if (!empty($url)) return $url;

        $parent = (int) get_post_field('post_parent', $collage_id);
        if ($parent > 0 && $parent !== $post_id) {
            wp_update_post(['ID' => $collage_id, 'post_parent' => $post_id]);
            $url = wp_get_attachment_url($collage_id);
        }

        return $url ?: '';
    }

    private $logger;
    private Collage_Generator $generator;
    private Social_Queue_Manager $queue;

    public function __construct($logger, Collage_Generator $generator, Social_Queue_Manager $queue)
    {
        $this->logger = $logger;
        $this->generator = $generator;
        $this->queue = $queue;
    }

    public function init(): void
    {
        \add_action('transition_post_status', [$this, 'handle_status_transition'], 5, 3);
        \add_action(self::ASYNC_COLLAGE_HOOK, [$this, 'async_generate_collage']);
        \add_action(self::CRON_HOOK, [$this, 'process_queue']);
        \add_filter('cron_schedules', [$this, 'register_cron_interval']);

        // @MODIFIED 2026-05-07 - Register unconditionally. Jetpack Social standalone may not
        // define JETPACK__VERSION but still responds to the jetpack_images_get_images filter.
        // Priority 0 ensures this runs BEFORE other image-getting filters.
        \add_filter('jetpack_images_get_images', [$this, 'force_jetpack_collage_image'], 0, 3);

        // @ADDED 2026-05-19 - Filter to control per-network Jetpack sharing
        \add_filter('wpas_submit_post?', [$this, 'filter_jetpack_network'], 10, 4);

        if (!\wp_next_scheduled(self::CRON_HOOK)) {
            \wp_schedule_event(time(), self::CRON_INTERVAL, self::CRON_HOOK);
        }
    }

    public function register_cron_interval(array $schedules): array
    {
        $schedules[self::CRON_INTERVAL] = [
            'interval' => 5 * \MINUTE_IN_SECONDS,
            'display' => 'Every 5 Minutes (DIT Social Queue)',
        ];
        return $schedules;
    }

    public function handle_status_transition(string $new_status, string $old_status, \WP_Post $post): void
    {
        if ($post->post_type !== 'post') return;

        // @MODIFIED 2026-05-15 - Allow both auto-generated ('1') AND manually published posts.
        // Empty/missing _dit_ts_generated means manual publish — still share socially.
        // Block only 'queued' and 'processing' states to prevent duplicate shares during job pipeline.
        $gen_flag = (string) get_post_meta($post->ID, '_dit_ts_generated', true);
        if (in_array($gen_flag, ['queued', 'processing'], true)) return;

        if ($new_status === 'publish' && $old_status === 'publish') {
            return;
        }

        if ($new_status === 'publish') {
            // @MODIFIED 2026-05-08 - Block social distribution for Roman Urdu posts.
            // If the language gate in Scheduler forced draft but an editor manually publishes,
            // the _dit_ts_language_flag persists. Skip collage + queue build for these posts.
            $lang_flag = get_post_meta($post->ID, '_dit_ts_language_flag', true);
            if ($lang_flag === 'roman_urdu') {
                if ($this->logger) {
                    $this->logger->warning("Social bootstrap skipped for post {$post->ID}: Roman Urdu language flag set. Post content is not in English.");
                }
                return;
            }

            global $wpdb;
		$table = $wpdb->prefix . 'dit_ts_social_meta';
		// @FIXED 2026-05-09: DO NOT automatically mark Urdu assets as 'completed' on publish.
		// The Social Queue page needs to show these items for manual review and collage generation.
		// Status will only be updated to 'completed' when collage generation succeeds.
	}

// @MODIFIED 2026-05-09 - REMOVED async collage scheduling for 'future' posts.
        // Race condition: This hook fires BEFORE Scheduler::auto_publish_job writes Urdu assets
        // to dit_ts_social_meta table, causing "Urdu assets missing" aborts.
        // FIX: Scheduler::auto_publish_job now generates collage SYNCHRONOUSLY after all data is ready.
        // Keep only sync_to_jetpack for Jetpack integration.
        if ($new_status === 'draft') {
            if (get_option('dit_ts_jetpack_enabled', false)) {
                $this->sync_to_jetpack($post->ID);
            }
            return;
        }
        if ($new_status === 'future') {
            // @MODIFIED 2026-05-11 - CRITICAL FIX: Do NOT call sync_to_jetpack() when collage
            // doesn't exist yet. This transition fires inside wp_insert_post() BEFORE the
            // Scheduler's synchronous collage generation (Scheduler.php:2561). Calling
            // sync_to_jetpack() here writes the FEATURED IMAGE URL to _wpas_media_src because
            // _dit_ts_social_collage_id is empty. When Jetpack reads _wpas_media_src at publish
            // time, it finds the featured image — NOT the social collage.
            // FIX: Only sync if collage already exists. Otherwise, Scheduler::auto_publish_job
            // will generate the collage synchronously and call sync_to_jetpack() itself (line 2564).
            $collage_id = (int)\get_post_meta($post->ID, self::SOCIAL_IMAGE_META_KEY, true);
            $collage_exists = ($collage_id && \wp_get_attachment_url($collage_id));
            if (!$collage_exists) {
                // Collage not ready — Scheduler will generate it and sync to Jetpack afterward.
                // Writing _wpas_media_src now would overwrite with featured image URL.
                // @MODIFIED 2026-06-07 - Write _wpas_skip_publicize_ meta NOW even when deferring
                // sync_to_jetpack(). Without this, Jetpack Social on WP.com shares to ALL networks
                // because the skip meta is missing. The skip meta is the ONLY reliable mechanism
                // for async Jetpack Social sharing (wpas_submit_post? filter only fires synchronously).
                if (get_option('dit_ts_jetpack_enabled', false) && class_exists('\Jetpack\Publicize')) {
                    try {
                        $networks = (array) get_option('dit_ts_jetpack_networks', []);
                        $service_key_map = ['instagram-business' => 'instagram'];
                        // @FIXED 2026-06-08 - Use get_all_connections() (XML-RPC/ transient cache)
                        // as primary. Connections::get_all_for_user() calls WPCOM REST API which
                        // silently returns empty on many Jetpack sites.
                        $pub = new \Jetpack\Publicize();
                        $raw = $pub->get_all_connections();
                        $conns = [];
                        if (!empty($raw) && is_array($raw)) {
                            foreach ($raw as $svc_name => $svc_conns) {
                                if (is_array($svc_conns)) {
                                    foreach ($svc_conns as $c) {
                                        $conns[] = [
                                            'connection_id' => $c['connection_data']['id'] ?? '',
                                            'id'            => $c['connection_data']['token_id'] ?? '',
                                            'service_name'  => $svc_name,
                                        ];
                                    }
                                }
                            }
                        }
                        if (empty($conns) && class_exists('\Automattic\Jetpack\Publicize\Connections')) {
                            $conns = \Automattic\Jetpack\Publicize\Connections::get_all_for_user();
                        }
                        $skip_count = 0;
                        foreach ($conns as $conn) {
                            $conn_id = $conn['connection_id'] ?? $conn['id'] ?? '';
                            $svc = $conn['service_name'] ?? '';
                            $lookup_key = $service_key_map[$svc] ?? $svc;
                            if (!empty($conn_id) && isset($networks[$lookup_key])) {
                                if (empty($networks[$lookup_key])) {
                                    \update_post_meta($post->ID, '_wpas_skip_publicize_' . $conn_id, 1);
                                    \update_post_meta($post->ID, '_wpas_skip_' . $svc, 1);
                                    $skip_count++;
                                } else {
                                    \delete_post_meta($post->ID, '_wpas_skip_publicize_' . $conn_id);
                                    \delete_post_meta($post->ID, '_wpas_skip_' . $svc);
                                }
                            }
                        }
                        if ($this->logger) {
                            $this->logger->info("Social bootstrap: deferred skip meta for post {$post->ID}", [
                                'connections_found' => count($conns),
                                'networks_skipped'  => $skip_count,
                            ]);
                        }
                    } catch (\Throwable $e) {
                        if ($this->logger) {
                            $this->logger->warning("Social bootstrap: deferred skip meta failed for post {$post->ID}: " . $e->getMessage());
                        }
                    }
                }
                if ($this->logger) {
                    $this->logger->info("Social bootstrap: deferring sync_to_jetpack for future post {$post->ID} — collage not yet generated (Scheduler will handle).");
                }
                return;
            }
            if (get_option('dit_ts_jetpack_enabled', false)) {
                $this->sync_to_jetpack($post->ID);
            }
            return;
        }

        if ($new_status === 'publish') {
            $collage_id = (int)\get_post_meta($post->ID, self::SOCIAL_IMAGE_META_KEY, true);
            if (!$collage_id || !\wp_get_attachment_url($collage_id)) {
                $generated = $this->maybe_generate_social_collage($post->ID);
                if (!$generated) {
                    if ($this->logger) {
                        $this->logger->warning(
                            'Social collage generation failed at publish. Slot 1 (collage) will be skipped in drip queue.',
                            ['post_id' => $post->ID]
                        );
                    }
                }
            }

            // @MODIFIED 2026-05-15 - Jetpack sharing (if enabled)
            if (get_option('dit_ts_jetpack_enabled', false)) {
                $this->sync_to_jetpack($post->ID);
            }

            // @MODIFIED 2026-07-03 - Buffer sharing (multi-account)
            // Runs synchronously during publish. Iterates all enabled Buffer accounts.
            // Buffer will use social collage if already generated, otherwise falls back to featured image.
            if (!empty(\DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_enabled_accounts())) {
                try {
                    $buffer_queue = new \DIT\TrendStudio\Integrations\Buffer\Queue_Manager($this->logger);
                    $buffer_queue->share_to_buffer($post->ID);
                } catch (\Throwable $e) {
                    if ($this->logger) {
                        $this->logger->error("Buffer sharing failed for post {$post->ID}: " . $e->getMessage());
                    }
                }
            }

            $this->queue->build_queue($post->ID);

            if (function_exists('as_has_scheduled_action') && function_exists('as_schedule_single_action')) {
                if (!as_has_scheduled_action('dit_ts_process_social_queue', [], 'ditts-social')) {
                    as_schedule_single_action(time() + 10, 'dit_ts_process_social_queue', [], 'ditts-social');
                }
            } else {
                if (!wp_next_scheduled(self::CRON_HOOK)) {
                    wp_schedule_single_event(time() + 30, self::CRON_HOOK);
                }
            }

            if ($this->logger) {
                $this->logger->info("Social queue built for post {$post->ID} and async dispatch scheduled.");
            }
        }
    }

    /**
     * Async cron callback — generates collage for draft/future posts in background.
     */
 	public function async_generate_collage(int $post_id): void
 	{
 		$attachment_id = $this->maybe_generate_social_collage($post_id);
 		if ($attachment_id) {
 			if (get_option('dit_ts_jetpack_enabled', false)) {
 				$this->sync_to_jetpack($post_id);
 			}
			global $wpdb;
			$table = $wpdb->prefix . 'dit_ts_social_meta';
			$wpdb->query($wpdb->prepare(
				"UPDATE {$table} SET status = 'completed' WHERE post_id = %d AND status = 'pending'",
				$post_id
			));
		}
	}

    /**
     * Recurring cron callback — processes due drip queue jobs.
     */
    public function process_queue(): void
    {
        $this->queue->process_due_jobs();
    }

    /**
     * Extracts the first $limit image URLs from a post.
     * Priority: featured image → plugin meta → post content <img> tags.
     *
     * @MODIFIED 2026-07-07 - Added $min_width/$min_height dimension filtering to reject
     * small social media screenshots and thumbnails. Defaults to 0 (no filtering) for
     * backward compatibility.
     */
    private function get_post_image_urls(int $post_id, int $limit = 2, bool $only_vertical = false, int $min_width = 0, int $min_height = 0): array
    {
        $urls = [];
        $candidates = [];

        // 1. Plugin-stored attachment IDs meta (_dit_ts_images) - PRIORITY
        $meta_ids = \get_post_meta($post_id, '_dit_ts_images', true);
        if (is_array($meta_ids)) {
            foreach ($meta_ids as $att_id) {
                $candidates[] = (int) $att_id;
            }
        }

        // 2. Featured image (Fallback)
        $thumb_id = (int) \get_post_thumbnail_id($post_id);
        if ($thumb_id && !in_array($thumb_id, $candidates, true)) {
            $candidates[] = $thumb_id;
        }

        // Filter candidates by orientation and minimum dimensions
        foreach ($candidates as $att_id) {
            $meta = \wp_get_attachment_metadata($att_id);
            $w = $meta['width'] ?? 0;
            $h = $meta['height'] ?? 0;

            if ($only_vertical) {
                if ($h <= $w && $w > 0) continue; // Skip landscape/square
            }

            // @MODIFIED 2026-07-07 - Reject small images (social media screenshots,
            // Facebook UI elements, comment thumbnails, etc.)
            if ($min_width > 0 && $w > 0 && $w < $min_width) continue;
            if ($min_height > 0 && $h > 0 && $h < $min_height) continue;

            $url = \wp_get_attachment_url($att_id);
            if ($url && !in_array($url, $urls, true)) {
                $urls[] = $url;
                if (count($urls) >= $limit) break;
            }
        }

        if (count($urls) >= $limit) return array_slice($urls, 0, $limit);

        // 3. Post content image tags (Last resort)
        if (count($urls) < $limit) {
            $post = \get_post($post_id);
            if ($post && !empty($post->post_content)) {
                preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $post->post_content, $matches);
                foreach ($matches[1] ?? [] as $src) {
                    $src = \esc_url_raw($src);
                    if ($src && !in_array($src, $urls, true)) {
                        $urls[] = $src;
                        if (count($urls) >= $limit) break;
                    }
                }
            }
        }

        return array_slice($urls, 0, $limit);
    }

    /**
     * Generates the 4:5 Urdu social collage. Idempotent.
     */
    public function maybe_generate_social_collage(int $post_id): int|false
    {
        if (!get_option('dit_ts_enable_social_collage', false)) {
            return false;
        }

        $existing = (int)get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        if ($existing && wp_get_attachment_url($existing)) {
            $existing_url = wp_get_attachment_url($existing);
            if (get_option('dit_ts_jetpack_enabled', false)) {
                update_post_meta($post_id, self::JETPACK_IMAGE_META, $existing_url);
                self::update_jetpack_social_options($post_id, $existing, $existing_url);
            }
            return $existing;
        }

	$urdu_head = get_post_meta($post_id, '_dit_ts_urdu_heading', true);
	$urdu_desc = get_post_meta($post_id, '_dit_ts_urdu_description', true);
	$_hashtags_raw = get_post_meta($post_id, '_dit_ts_hashtags', true);
	$hashtags_raw = is_array($_hashtags_raw) ? implode(' ', $_hashtags_raw) : (string) $_hashtags_raw;

	// @MODIFIED 2026-05-08 - Strip tags and trim BEFORE the DB fallback check
	$urdu_head = trim(wp_strip_all_tags((string)$urdu_head));
	$urdu_desc = trim(wp_strip_all_tags((string)$urdu_desc));

	if (empty($urdu_head) || empty($urdu_desc)) {
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT urdu_heading, urdu_description, hashtags
			FROM {$wpdb->prefix}dit_ts_social_meta
			WHERE post_id = %d AND status IN ('pending','completed','published')
			ORDER BY id DESC LIMIT 1",
			$post_id
		), ARRAY_A);
		if ($row) {
			$urdu_head = $urdu_head ?: trim(wp_strip_all_tags((string) $row['urdu_heading']));
			$urdu_desc = $urdu_desc ?: trim(wp_strip_all_tags((string) $row['urdu_description']));
			$hashtags_raw = $hashtags_raw ?: (string) $row['hashtags'];
		}
	}

	// Clean up legacy machine-translation artifacts if present in older DB entries
	$urdu_head = str_replace(['اپنے پتن', 'پتن', 'پیشکش کار'], ['اپنے شوہر', 'شوہر', 'اینکر'], $urdu_head);
	$urdu_desc = str_replace(['اپنے پتن', 'پتن', 'پیشکش کار'], ['اپنے شوہر', 'شوہر', 'اینکر'], $urdu_desc);

	// @MODIFIED 2026-05-07 - HARD GUARD: If Urdu assets are missing, no collage at all.
        // Social collage is ONLY for social sharing and REQUIRES Urdu text. Without it,
        // any previously generated collage and social meta are stale — clean them up.
        if (empty($urdu_head) || empty($urdu_desc)) {
            $stale_collage_id = (int) get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
            if ($stale_collage_id > 0) {
                $parent = (int) get_post_field('post_parent', $stale_collage_id);
                if ($parent === 0 || $parent === $post_id) {
                    \wp_delete_attachment($stale_collage_id, true);
                }
            }
            \delete_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY);
            \delete_post_meta($post_id, '_dit_ts_social_image_url');
            \delete_post_meta($post_id, self::JETPACK_IMAGE_META);
            \delete_post_meta($post_id, self::JETPACK_META_KEY);
            \delete_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS);
            if ($this->logger) {
                $this->logger->warning("Social collage aborted for post {$post_id}: Urdu assets missing. Stale social meta cleaned.");
            }
            return false;
        }

        $vertical = get_post_meta($post_id, 'vertical', true) ?: 'general';
        $is_fashion = ($vertical === 'fashion' || \has_category('fashion', $post_id));

        // @MODIFIED 2026-04-22 - Use the already-generated featured collage image
        // as the single top image instead of re-gathering separate source images.
        // This economizes effort: the featured image already contains the curated
        // photo grid, so we reuse it directly as the top section of the social collage.
        $featured_id = (int)\get_post_thumbnail_id($post_id);
        $featured_url = $featured_id ? \wp_get_attachment_url($featured_id) : '';

        $image_urls = [];
        if ($featured_url) {
            $image_urls[] = $featured_url;
        }

        // Fallback: if no featured image, try the old image-gathering method
        // @MODIFIED 2026-07-07 - Apply Hero-First dimension filtering to reject small
        // social media screenshots (Facebook UI, comment thumbnails, reaction buttons).
        // showbiz_pk: W>=600 AND H>=400; fashion_pk: H>=700 (portrait); general: no filter.
        if (empty($image_urls)) {
            $limit = $is_fashion ? 3 : 2;
            $min_w = 0;
            $min_h = 0;
            if ($vertical === 'showbiz_pk' || $vertical === 'showbiz') {
                $min_w = 600;
                $min_h = 400;
            } elseif ($vertical === 'fashion_pk' || $vertical === 'fashion') {
                $min_h = 700;
            }
            $image_urls = $this->get_post_image_urls($post_id, $limit, false, $min_w, $min_h);
        }

        if (empty($image_urls)) {
            if ($this->logger) {
                $this->logger->warning("No images for collage on post $post_id (featured and fallback both empty)");
            }
            return false;
        }

        // Strip hashtags from collage description
        $parsed = Social_Queue_Manager::split_desc_and_hashtags((string)$urdu_desc, (string)$hashtags_raw);
        $clean_desc = $parsed['desc'];

        $brand_text = get_option('dit_ts_brand_bar_text', get_bloginfo('name'));
        $brand_color = get_option('dit_ts_brand_bar_color', '#1a1a2e');
        // @MODIFIED 2026-05-05 - Read brand bar settings from new UI fields
        $brand_text_color = get_option('dit_ts_brand_bar_text_color', '');
        $brand_logo_id = (int) get_option('dit_ts_brand_logo_id', 0);
        $brand_logo_path = $brand_logo_id ? (get_attached_file($brand_logo_id) ?: '') : '';
        $brand_bar_font_size = (int) get_option('dit_ts_brand_bar_font_size', 24);
        $brand_bar_letter_spacing = (int) get_option('dit_ts_brand_bar_letter_spacing', 10);
        $brand_bar_accent_line = (bool) get_option('dit_ts_brand_bar_accent_line', false);
        $font_name = get_option('dit_ts_social_font', 'NotoNastaliqUrdu-Regular.ttf');
        $font_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . basename($font_name);

        // @MODIFIED 2026-04-21 - Ensure font fallback and log errors
        $final_font_path = $font_path;
        if (!file_exists($font_path)) {
            // Try fallback fonts in order of preference
            $fallbacks = [
                'NotoNastaliqUrdu-Regular.ttf',
                'NotoNastaliqUrdu-Medium.ttf',
                'NotoSansArabic-Regular.ttf',
            ];
            foreach ($fallbacks as $fb) {
                $fb_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . $fb;
                if (file_exists($fb_path)) {
                    $final_font_path = $fb_path;
                    break;
                }
            }
            // Log font resolution issue
            if ($this->logger) {
                $this->logger->error("Social collage: Font '$font_name' not found at '$font_path'. Using fallback: '$final_font_path'");
            }
        }

        $using_featured = ($featured_url && count($image_urls) === 1);
        $layout_key = $using_featured ? 'single' : ($is_fashion ? '3-cols' : '2-cols');
        $target_count = $using_featured ? 1 : ($is_fashion ? 3 : 2);

        $attachment_id = $this->generator->create_collage(
            array_values(array_filter($image_urls)),
            \get_the_title($post_id) . ' Social',
            [
                'aspect_ratio' => '4:5',
                'layout' => $layout_key,
                'target_count' => $target_count,
                'social_bands' => [
                    'heading' => (string)$urdu_head,
                    'description' => (string)$clean_desc,
                ],
                'bottom_text' => $brand_text,
                'border_color' => $brand_color,
                'font_file' => $final_font_path,
                'heading_font_size' => (int)\get_option('dit_ts_social_h_size', 42),
                'desc_font_size' => (int)\get_option('dit_ts_social_d_size', 28),
                'image_area_pct' => (int)\get_option('dit_ts_social_image_pct', 55),
                'heading_area_pct' => (int)\get_option('dit_ts_social_heading_pct', 10),
                'desc_area_pct' => (int)\get_option('dit_ts_social_desc_pct', 25),
                'bar_area_pct' => (int)\get_option('dit_ts_social_bar_pct', 10),
                'logo_path' => $brand_logo_path,
                'use_brand_logo' => !empty($brand_logo_path),
                'bar_font_size' => $brand_bar_font_size,
                'bar_text_color' => $brand_text_color,
                'letter_spacing' => $brand_bar_letter_spacing,
                'bar_accent_line' => $brand_bar_accent_line,
                'corner_radius' => (int)\get_option('dit_ts_social_radius', 0),
                // @MODIFIED 2026-05-05 - Featured image is a pre-composed collage: fit it fully
                // with solid brand-color letterbox bars instead of cover crop or blurry background.
                // Individual source images keep cover crop with top-bias to preserve faces.
                'crops' => $using_featured
                    ? [['x' => 50, 'y' => 50, 'scale' => 1.0, 'full_crop' => false, 'letterbox_color' => $brand_color]]
                    : [['x' => 50, 'y' => 25, 'scale' => 1.0, 'full_crop' => true]],
                'gap_size' => $using_featured ? 0 : 5,
                'is_retina' => true,
                'format' => 'jpg',
                'social_font' => basename($final_font_path),
                'social_heading_bg' => (string)\get_option('dit_ts_social_heading_bg', '#0f1c34'),
                'social_heading_color' => (string)\get_option('dit_ts_social_heading_color', '#ffffff'),
                'social_desc_bg' => (string)\get_option('dit_ts_social_desc_bg', '#500f19'),
                'social_desc_color' => (string)\get_option('dit_ts_social_desc_color', '#ffffff'),
            ]
        );

        if (is_wp_error($attachment_id)) {
            if ($this->logger) {
                $this->logger->error("Collage generation failed for post $post_id: " . $attachment_id->get_error_message());
            }
            return false;
        }

        update_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, $attachment_id);
        $collage_url = wp_get_attachment_url($attachment_id);
        if (get_option('dit_ts_jetpack_enabled', false)) {
            update_post_meta($post_id, self::JETPACK_IMAGE_META, $collage_url);
            self::update_jetpack_social_options($post_id, $attachment_id, $collage_url);
        }

        if ($this->logger) {
            $this->logger->info("Collage #$attachment_id generated for post $post_id");
        }
        return $attachment_id;
    }

    /**
     * Overrides Jetpack OpenGraph/Publicize images
     */
    public function force_jetpack_collage_image(array $images, int $post_id, array $args): array
    {
        if (!get_option('dit_ts_jetpack_enabled', false)) {
            return $images;
        }

        $collage_url = self::resolve_collage_url($post_id);

        if (empty($collage_url)) {
            return $images;
        }

        $context = $args['context'] ?? '';
        if (!in_array($context, ['publicize', 'opengraph', 'twitter', ''], true)) {
            return $images;
        }

        if (!is_array($images)) {
            $images = [];
        }

        array_unshift($images, [
            'type' => 'image',
            'from' => 'custom',
            'src' => $collage_url,
            'href' => $collage_url
        ]);

        $current_media_src = \get_post_meta($post_id, self::JETPACK_IMAGE_META, true);
        if ($current_media_src !== $collage_url) {
            \update_post_meta($post_id, self::JETPACK_IMAGE_META, $collage_url);
        }
        $collage_id = (int) \get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        if ($collage_id) {
            self::update_jetpack_social_options($post_id, $collage_id, $collage_url);
        }

        return $images;
    }

    /**
     * @MODIFIED 2026-05-19 - Added per-network custom message support.
     * Global _wpas_mess is kept as fallback; per-connection _wpas_mess_{id} is written when custom templates exist.
     *
     * @param int $post_id Post ID.
     * @return bool True if successfully synced, false otherwise.
     */
    public function sync_to_jetpack(int $post_id): bool
    {
	$urdu_head = get_post_meta($post_id, '_dit_ts_urdu_heading', true);
	$urdu_desc = get_post_meta($post_id, '_dit_ts_urdu_description', true);
	$hashtags = get_post_meta($post_id, '_dit_ts_hashtags', true);
	if (is_array($hashtags)) {
		$hashtags = implode(' ', $hashtags);
	}

	// @MODIFIED 2026-05-08 - Strip tags and trim BEFORE fallback check
	$urdu_head = trim(wp_strip_all_tags((string)$urdu_head));
	$urdu_desc = trim(wp_strip_all_tags((string)$urdu_desc));

	if (empty($urdu_head) || empty($urdu_desc)) {
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT urdu_heading, urdu_description, hashtags
			FROM {$wpdb->prefix}dit_ts_social_meta
			WHERE post_id = %d AND status IN ('pending','completed','published')
			ORDER BY id DESC LIMIT 1",
			$post_id
		), ARRAY_A);
		if ($row) {
			$urdu_head = $urdu_head ?: trim(wp_strip_all_tags((string) $row['urdu_heading']));
			$urdu_desc = $urdu_desc ?: trim(wp_strip_all_tags((string) $row['urdu_description']));
			$hashtags = $hashtags ?: (string) $row['hashtags'];
		}
	}

        // @MODIFIED 2026-05-07 - HARD GUARD: No Urdu message without BOTH heading + description.
        // Collage is not generated without Urdu, so _wpas_mess must not be written either.
        // CRITICAL FIX: DO NOT delete featured collage - preserve it as fallback for social sharing.
        // Social collage is generated asynchronously AFTER publish via async_generate_collage.
        // The Jetpack/_wpas_media_src will be updated when social collage is ready.
        if (empty($urdu_head) || empty($urdu_desc)) {
            \delete_post_meta($post_id, self::JETPACK_META_KEY);
            $thumb_id = (int) \get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $thumb_url = \wp_get_attachment_url($thumb_id);
                \update_post_meta($post_id, self::JETPACK_IMAGE_META, $thumb_url);
                self::update_jetpack_social_options($post_id, $thumb_id, $thumb_url, 'featured-image');
            } else {
                \delete_post_meta($post_id, self::JETPACK_IMAGE_META);
                \delete_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS);
            }
            return false;
        }

        // Use the shared splitter — no more duplicated closures
        $parsed = Social_Queue_Manager::split_desc_and_hashtags((string)$urdu_desc, (string)$hashtags);
        $link = $this->queue->resolve_permalink((string)$post_id);

        // Global template as fallback
        $global_template = get_option('dit_ts_jetpack_template', "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}");

        $message_data = [
            '{urdu_head}' => wp_strip_all_tags(html_entity_decode(trim((string)$urdu_head), ENT_QUOTES | ENT_HTML5, 'UTF-8')),
            '{urdu_desc}' => $parsed['desc'],
            '{hashtags}'  => $parsed['tags'],
            '{link}'      => $link,
        ];

        // 1. Set the global message (legacy compatibility + fallback)
        $global_message = str_replace(
            array_keys($message_data),
            array_values($message_data),
            $global_template
        );
        $global_message = preg_replace("/\n{3,}/", "\n\n", trim($global_message));
        \update_post_meta($post_id, self::JETPACK_META_KEY, $global_message);

        // 2. Set per-network messages (if custom templates exist)
        $network_templates = (array) get_option('dit_ts_jetpack_network_templates', []);

        if (class_exists('\Jetpack\Publicize')) {
            // @FIXED 2026-06-08 - Use get_all_connections() (XML-RPC/transient cache) as primary.
            // Connections::get_all_for_user() calls WPCOM REST API which silently returns empty
            // on many Jetpack sites. get_all_connections() reads from the transient populated
            // by XML-RPC which is reliable.
            $publicize = new \Jetpack\Publicize();
            $raw = $publicize->get_all_connections();
            $connections = [];
            if (!empty($raw) && is_array($raw)) {
                foreach ($raw as $svc_name => $svc_conns) {
                    if (is_array($svc_conns)) {
                        foreach ($svc_conns as $c) {
                            $connections[] = [
                                'connection_id' => $c['connection_data']['id'] ?? '',
                                'id'            => $c['connection_data']['token_id'] ?? '',
                                'service_name'  => $svc_name,
                            ];
                        }
                    }
                }
            }
            if (empty($connections) && class_exists('\Automattic\Jetpack\Publicize\Connections')) {
                $connections = \Automattic\Jetpack\Publicize\Connections::get_all_for_user();
            }

            foreach ($connections as $conn) {
                // connection_id = globally unique ID used by _wpas_skip_publicize_ and _wpas_done_
                // id = token_id/unique_id used by legacy _wpas_skip_ and _wpas_done_ checks
                $conn_id = $conn['connection_id'] ?? $conn['id'] ?? '';
                $service_name = $conn['service_name'] ?? '';

                if (empty($conn_id) || empty($service_name)) {
                    continue;
                }

                $service_key_map = [
                    'instagram-business' => 'instagram',
                ];
                $setting_key = $service_key_map[$service_name] ?? $service_name;

                $custom_template = $network_templates[$setting_key] ?? '';

                if (!empty($custom_template)) {
                    $custom_message = str_replace(
                        array_keys($message_data),
                        array_values($message_data),
                        $custom_template
                    );
                    $custom_message = preg_replace("/\n{3,}/", "\n\n", trim($custom_message));
                    // Write to _wpas_connection_overrides (Jetpack modern per-connection customization)
                    $overrides = (array) \get_post_meta($post_id, '_wpas_connection_overrides', true);
                    $overrides[$conn_id] = ['message' => $custom_message];
                    \update_post_meta($post_id, '_wpas_connection_overrides', $overrides);
                } else {
                    $overrides = (array) \get_post_meta($post_id, '_wpas_connection_overrides', true);
                    unset($overrides[$conn_id]);
                    if (!empty($overrides)) {
                        \update_post_meta($post_id, '_wpas_connection_overrides', $overrides);
                    } else {
                        \delete_post_meta($post_id, '_wpas_connection_overrides');
                    }
                }

                // Gate per-network sharing via skip meta (primary async mechanism)
                $network_enabled = (array) get_option('dit_ts_jetpack_networks', []);
                $is_enabled = !empty($network_enabled[$setting_key]);

                if ($is_enabled) {
                    \delete_post_meta($post_id, '_wpas_skip_publicize_' . $conn_id);
                    \delete_post_meta($post_id, '_wpas_skip_' . $service_name);
                } else {
                    \update_post_meta($post_id, '_wpas_skip_publicize_' . $conn_id, 1);
                    \update_post_meta($post_id, '_wpas_skip_' . $service_name, 1);
                }
            }

            if ($this->logger) {
                $this->logger->info("sync_to_jetpack: connections processed for post {$post_id}", [
                    'connections_found' => count($connections),
                    'networks_enabled'  => array_keys(array_filter((array) get_option('dit_ts_jetpack_networks', []))),
                ]);
            }
        }

        // @MODIFIED 2026-05-11 - CRITICAL FIX: Write _wpas_options (Jetpack Social's ACTUAL image source).
        $collage_id = (int) \get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        $share_url = '';
        if ($collage_id) {
            $url = \wp_get_attachment_url($collage_id);
            if (!empty($url)) {
                $share_url = $url;
            } else {
                $parent = (int) \get_post_field('post_parent', $collage_id);
                if ($parent > 0 && $parent !== $post_id) {
                    \wp_update_post(['ID' => $collage_id, 'post_parent' => $post_id]);
                    $share_url = \wp_get_attachment_url($collage_id);
                }
            }
        }
        if (!empty($share_url)) {
            \update_post_meta($post_id, self::JETPACK_IMAGE_META, $share_url);
            self::update_jetpack_social_options($post_id, $collage_id, $share_url);
        } elseif (!$collage_id) {
            $thumb_id = (int) \get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $thumb_url = \wp_get_attachment_url($thumb_id);
                \update_post_meta($post_id, self::JETPACK_IMAGE_META, $thumb_url);
                self::update_jetpack_social_options($post_id, $thumb_id, $thumb_url, 'featured-image');
            } else {
                \delete_post_meta($post_id, self::JETPACK_IMAGE_META);
                $options = (array) \get_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, true);
                unset($options['attached_media'], $options['media_source']);
                if (!empty($options)) {
                    \update_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, $options);
                } else {
                    \delete_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS);
                }
            }
        }

        return true;
    }

    /**
     * @ADDED 2026-05-19 - Filters whether a post should be publicized to a given service.
     * Hooked to `wpas_submit_post?` (priority 10, 4 args).
     * Controls per-service enable/disable based on plugin settings.
     *
     * @param bool $should_share Should the post be publicized to this service? Default true.
     * @param int $post_id Post ID.
     * @param string $service_name Service name (e.g., 'facebook', 'linkedin').
     * @param array $connection The connection data.
     * @return bool
     */
    public function filter_jetpack_network(bool $should_share, int $post_id, string $service_name, array $connection): bool
    {
        if (!get_option('dit_ts_jetpack_enabled', false)) {
            return $should_share;
        }

        $networks = (array) get_option('dit_ts_jetpack_networks', []);

        if (empty($networks)) {
            $known = ['facebook', 'instagram', 'threads', 'linkedin', 'tumblr', 'mastodon', 'nextdoor', 'bluesky'];
            foreach ($known as $svc) {
                $networks[$svc] = true;
            }
            update_option('dit_ts_jetpack_networks', $networks);
        }

        // @MODIFIED 2026-06-07 - Map Jetpack service names to plugin setting keys.
        // Jetpack uses 'instagram-business' internally; plugin UI stores 'instagram'.
        $service_key_map = [
            'instagram-business' => 'instagram',
        ];
        $lookup_key = $service_key_map[$service_name] ?? $service_name;

        if (!isset($networks[$lookup_key])) {
            return $should_share;
        }

return !empty($networks[$lookup_key]);
    }

    /**
     * Get Jetpack Stats (traffic/visitors) for the site
     *
     * @param string $period 'day', 'week', 'month', 'year'
     * @return array
     */
    public function get_site_stats($period = 'day')
    {
        $stats = array(
            'views'           => 0,
            'visitors'        => 0,
            'period'          => $period,
            'top_posts'       => array(),
            'referrers'       => array(),
            'search_terms'    => array(),
            'clicks'          => 0,
            'error'           => '',
        );

        // Check if Jetpack Stats module is active
        if (!class_exists('Jetpack_Stats') && !function_exists('stats_get_csv')) {
            $stats['error'] = 'Jetpack Stats module not active';
            return $stats;
        }

        try {
            // Get views and visitors for the period
            $end_date = date('Y-m-d');
            $start_date = $this->get_period_start_date($period);

            // Use Jetpack Stats API
            $views = $this->get_views($start_date, $end_date);
            $visitors = $this->get_visitors($start_date, $end_date);
            $top_posts = $this->get_top_posts($start_date, $end_date, 10);
            $referrers = $this->get_referrers($start_date, $end_date, 10);
            $search_terms = $this->get_search_terms($start_date, $end_date, 10);

            $stats['views'] = (int) $views;
            $stats['visitors'] = (int) $visitors;
            $stats['top_posts'] = $top_posts;
            $stats['referrers'] = $referrers;
            $stats['search_terms'] = $search_terms;
        } catch (\Throwable $e) {
            if ($this->logger) {
                $this->logger->error('Jetpack Stats error: ' . $e->getMessage());
            }
            $stats['error'] = $e->getMessage();
        }

        return $stats;
    }

    /**
     * Get start date for period
     */
    private function get_period_start_date($period)
    {
        switch ($period) {
            case 'day':
                return date('Y-m-d');
            case 'week':
                return date('Y-m-d', strtotime('-7 days'));
            case 'month':
                return date('Y-m-d', strtotime('-30 days'));
            case 'year':
                return date('Y-m-d', strtotime('-365 days'));
            default:
                return date('Y-m-d');
        }
    }

    /**
     * Get total views for date range
     */
    private function get_views($start_date, $end_date)
    {
        if (function_exists('stats_get_csv')) {
            $result = stats_get_csv('postviews', array(
                'period' => 'custom',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'summarize' => true,
            ));
            if (is_array($result) && !empty($result[0]['views'])) {
                return $result[0]['views'];
            }
        }
        return 0;
    }

    /**
     * Get total visitors for date range
     */
    private function get_visitors($start_date, $end_date)
    {
        if (function_exists('stats_get_csv')) {
            $result = stats_get_csv('postviews', array(
                'period' => 'custom',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'summarize' => true,
            ));
            if (is_array($result) && !empty($result[0]['visitors'])) {
                return $result[0]['visitors'];
            }
        }
        return 0;
    }

    /**
     * Get top posts for date range
     */
    private function get_top_posts($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('postviews', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $posts = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $post_id = isset($row['post_id']) ? (int) $row['post_id'] : 0;
                $title = $post_id > 0 ? get_the_title($post_id) : (isset($row['title']) ? $row['title'] : 'Unknown');
                $posts[] = array(
                    'post_id' => $post_id,
                    'title'   => $title,
                    'url'     => $post_id > 0 ? get_permalink($post_id) : (isset($row['permalink']) ? $row['permalink'] : ''),
                    'views'   => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $posts;
    }

    /**
     * Get referrers for date range
     */
    private function get_referrers($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('referrers', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $referrers = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $referrers[] = array(
                    'referrer' => isset($row['referrer']) ? $row['referrer'] : 'Direct',
                    'views'    => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $referrers;
    }

    /**
     * Get search terms for date range
     */
    private function get_search_terms($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('searchterms', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $terms = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $terms[] = array(
                    'term'  => isset($row['term']) ? $row['term'] : '',
                    'views' => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $terms;
    }

    /**
     * Check if Jetpack Stats is available
     */
    public static function is_stats_available()
    {
        return class_exists('Jetpack_Stats') || function_exists('stats_get_csv');
    }

}
