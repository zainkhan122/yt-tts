/**
 * MCQVS Asset Cache
 * In-memory + optional IndexedDB cache for fetched/decoded assets.
 *
 * Goals:
 * - Reduce flakiness (retries, transient CDN issues)
 * - Reduce latency (reuse decoded buffers)
 * - Scale across sessions via IndexedDB (best-effort)
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const DEFAULTS = {
    persist: true,
    dbName: "mcqvs_asset_cache",
    dbVersion: 1,
    versionKey: "v9",
    maxBytes: 50 * 1024 * 1024, // 50MB
    timeoutMs: 12000,
  };

  function _supportsIDB() {
    try {
      return !!window.indexedDB;
    } catch (e) {
      return false;
    }
  }

  function _openDB(dbName, dbVersion) {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(dbName, dbVersion);

      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("ab")) db.createObjectStore("ab");
        if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
      };

      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error("IndexedDB open failed"));
    });
  }

  function _tx(db, store, mode = "readonly") {
    return db.transaction([store], mode).objectStore(store);
  }

  function _idbGet(db, store, key) {
    return new Promise((resolve, reject) => {
      const req = _tx(db, store, "readonly").get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function _idbPut(db, store, key, value) {
    return new Promise((resolve, reject) => {
      const req = _tx(db, store, "readwrite").put(value, key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  function _idbDel(db, store, key) {
    return new Promise((resolve, reject) => {
      const req = _tx(db, store, "readwrite").delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  function _idbKeys(db, store) {
    return new Promise((resolve, reject) => {
      const keys = [];
      const cursorReq = _tx(db, store, "readonly").openCursor();
      cursorReq.onsuccess = () => {
        const cur = cursorReq.result;
        if (!cur) return resolve(keys);
        keys.push(cur.key);
        cur.continue();
      };
      cursorReq.onerror = () => reject(cursorReq.error);
    });
  }

  function create(opts = {}) {
    const cfg = { ...DEFAULTS, ...(opts || {}) };

    const audioBuffer = new Map(); // key -> AudioBuffer
    const arrayBuffer = new Map(); // key -> ArrayBuffer
    const imageBitmap = new Map(); // key -> ImageBitmap

    const idb = {
      enabled: !!cfg.persist && _supportsIDB(),
      db: null,
      ready: null,
      async init() {
        if (!this.enabled) return null;
        if (this.ready) return this.ready;
        this.ready = _openDB(cfg.dbName, cfg.dbVersion)
          .then((db) => {
            this.db = db;
            return db;
          })
          .catch((e) => {
            console.warn("[MCQVS Cache] IndexedDB disabled:", e?.message || e);
            this.enabled = false;
            return null;
          });
        return this.ready;
      },
    };

    const _key = (url) => `${cfg.versionKey}::${String(url || "")}`;

    async function _enforceBudget() {
      if (!idb.enabled || !idb.db) return;
      try {
        const metaKeys = await _idbKeys(idb.db, "meta");
        const metas = [];
        for (const k of metaKeys) {
          const m = await _idbGet(idb.db, "meta", k);
          if (m) metas.push({ key: k, ...m });
        }

        let total = metas.reduce((s, m) => s + (Number(m.bytes) || 0), 0);
        if (total <= cfg.maxBytes) return;

        // Evict LRU
        metas.sort((a, b) => (Number(a.lastAccess || 0) - Number(b.lastAccess || 0)));
        for (const m of metas) {
          if (total <= cfg.maxBytes) break;
          await _idbDel(idb.db, "ab", m.key);
          await _idbDel(idb.db, "meta", m.key);
          total -= Number(m.bytes) || 0;
        }
      } catch (e) {
        // Budget enforcement is best-effort.
      }
    }

    return {
      config: cfg,
      idb,

      async fetchArrayBuffer(url, opts2 = {}) {
        if (!url) throw new Error("fetchArrayBuffer: url required");
        const key = _key(url);

        if (arrayBuffer.has(key)) return arrayBuffer.get(key);

        // Attempt persistent cache first
        await idb.init();
        if (idb.enabled && idb.db) {
          try {
            const cached = await _idbGet(idb.db, "ab", key);
            if (cached && cached.byteLength) {
              arrayBuffer.set(key, cached);
              // touch meta
              _idbPut(idb.db, "meta", key, {
                bytes: cached.byteLength,
                lastAccess: Date.now(),
              }).catch(() => {});
              return cached;
            }
          } catch (e) {
            // ignore
          }
        }

        const ctrl = new AbortController();
        const timeoutMs = Number(opts2.timeoutMs || cfg.timeoutMs);
        const t = setTimeout(() => ctrl.abort(), timeoutMs);

        try {
          const res = await fetch(url, { signal: ctrl.signal, cache: "force-cache" });
          if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
          const buf = await res.arrayBuffer();
          arrayBuffer.set(key, buf);

          if (idb.enabled && idb.db) {
            _idbPut(idb.db, "ab", key, buf)
              .then(() => _idbPut(idb.db, "meta", key, { bytes: buf.byteLength, lastAccess: Date.now() }))
              .then(() => _enforceBudget())
              .catch(() => {});
          }
          return buf;
        } finally {
          clearTimeout(t);
        }
      },

      async decodeAudio(ctx, url, opts2 = {}) {
        if (!ctx) throw new Error("decodeAudio: AudioContext required");
        if (!url) throw new Error("decodeAudio: url required");
        const key = _key(url);
        if (audioBuffer.has(key)) return audioBuffer.get(key);

        const buf = await this.fetchArrayBuffer(url, opts2);
        const decoded = await ctx.decodeAudioData(buf.slice(0));
        audioBuffer.set(key, decoded);
        return decoded;
      },

      async loadImageBitmap(url, opts2 = {}) {
        if (!url) throw new Error("loadImageBitmap: url required");
        const key = _key(url);
        if (imageBitmap.has(key)) return imageBitmap.get(key);

        const buf = await this.fetchArrayBuffer(url, opts2);
        const blob = new Blob([buf]);
        const bmp = await createImageBitmap(blob);
        imageBitmap.set(key, bmp);
        return bmp;
      },
      getStats() {
        // Best-effort memory stats; does not include decoded AudioBuffer internal allocations
        const mem = {
          arrayBufferItems: arrayBuffer.size,
          audioBufferItems: audioBuffer.size,
          imageBitmapItems: imageBitmap.size,
        };
        return {
          persist: !!opts.persist,
          dbName: opts.dbName,
          dbVersion: opts.dbVersion,
          versionKey: opts.versionKey,
          maxBytes: opts.maxBytes,
          memory: mem,
        };
      },

      clear() {
        audioBuffer.clear();
        arrayBuffer.clear();
        imageBitmap.clear();
      },
    };
  }

  window.MCQVS_AssetCache = { create };
})(window);
