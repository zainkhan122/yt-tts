<?php

/**
 * Generation Service Class
 * Version: 1.6 - Implemented Topic Batch Generation
 *
 * @MODIFIED: Replaced all function_exists() checks with class_exists().
 * @MODIFIED: Replaced all procedural logging calls with static class methods.
 * @MODIFIED: Passed topic name to check_duplicate() for optimized semantic search.
 * @MODIFIED: generate_mcqs_from_topics_sync() now fetches a batch of 3 questions
 * in a single API call instead of one-by-one, removing the for loop.
 */

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class NM_Generation_Service
{


	/**
	 * Check if generation is already running
	 */
	public static function is_generation_locked($type = 'general')
	{
		$lock_key  = 'nm_generation_lock_' . $type;
		$lock_time = get_transient($lock_key);

		if ($lock_time) {
			$elapsed = time() - $lock_time;
			if ($elapsed > 600) { // 10 minute lock
				delete_transient($lock_key);
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Acquire generation lock
	 */
	public static function acquire_generation_lock($type = 'general')
	{
		$lock_key = 'nm_generation_lock_' . $type;
		set_transient($lock_key, time(), 600); // 10 minute lock
	}

	/**
	 * Release generation lock
	 */
	public static function release_generation_lock($type = 'general')
	{
		$lock_key = 'nm_generation_lock_' . $type;
		delete_transient($lock_key);
	}

	/**
	 * Wrapper for API calls with retry logic
	 */
	public static function call_api_with_retry($callback, $args = array(), $max_retries = 3, $retry_delay = 5)
	{
		$attempt    = 0;
		$last_error = '';

		while ($attempt < $max_retries) {
			++$attempt;
			try {
				$result = call_user_func_array($callback, $args);
				if ($result['success']) {
					return $result; // Success
				}
				$last_error = $result['error'] ?? 'Unknown error';

				if (self::is_permanent_error($last_error)) {
					break;
				}
				if ($attempt < $max_retries) {
					sleep($retry_delay);
					$retry_delay *= 2;
				}
			} catch (Exception $e) {
				$last_error = $e->getMessage();
				if ($attempt < $max_retries) {
					sleep($retry_delay);
					$retry_delay *= 2;
				}
			}
		}
		return array(
			'success'  => false,
			'error'    => "Failed after {$max_retries} attempts. Last error: {$last_error}",
			'attempts' => $attempt,
		);
	}

	/**
	 * Check if error is permanent
	 */
	public static function is_permanent_error($error_message)
	{
		$permanent_errors = array('invalid api key', 'api key not set', 'permission denied', 'invalid request', '400', '401', '403', 'quota exceeded');
		$error_lower      = strtolower($error_message);
		foreach ($permanent_errors as $permanent) {
			if (strpos($error_lower, $permanent) !== false) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Rate limiting tracker
	 */
	public static function check_rate_limit($api_type = 'gemini')
	{
		$limit_key  = 'nm_api_rate_limit_' . $api_type;
		$calls_made = get_transient($limit_key);

		if ($calls_made === false) {
			set_transient($limit_key, 1, 60);
			return array(
				'allowed'   => true,
				'remaining' => 59,
			);
		}
		$max_per_minute = 60;
		if ($calls_made >= $max_per_minute) {
			return array(
				'allowed'     => false,
				'remaining'   => 0,
				'retry_after' => 60,
			);
		}
		set_transient($limit_key, $calls_made + 1, 60);
		return array(
			'allowed'   => true,
			'remaining' => $max_per_minute - $calls_made - 1,
		);
	}

	/**
	 * Track daily MCQ generation for dashboard charts
	 */
	public static function track_daily_generation_stats($count)
	{
		if ($count <= 0) {
			return;
		}
		$today = current_time('Y-m-d');
		$stats = get_option('nm_daily_generation_stats', array());
		if (! isset($stats[$today])) {
			$stats[$today] = 0;
		}
		$stats[$today] += $count;
		$keys             = array_keys($stats);
		if (count($keys) > 30) {
			$keys_to_remove = array_slice($keys, 0, count($keys) - 30);
			foreach ($keys_to_remove as $key) {
				unset($stats[$key]);
			}
		}
		update_option('nm_daily_generation_stats', $stats, false);
	}
	/**
	 * Resolve blueprint context for a given exam slug.
	 *
	 * Returns a compact context array that can be passed to NM_API_Client:
	 * [
	 *   'exam_slug'      => 'css',
	 *   'difficulty'     => 'medium',
	 *   'cognitive_level'=> 'apply',
	 *   'prompt_hint'    => '...'
	 * ]
	 */
	public static function get_exam_blueprint_context($exam_slug)
	{
		$exam_slug = sanitize_key($exam_slug);
		if (empty($exam_slug)) {
			return array();
		}

		$all_blueprints = get_option('nm_exam_blueprints', array());
		if (! is_array($all_blueprints) || empty($all_blueprints[$exam_slug])) {
			// At least carry the exam slug so the API client can mention it
			return array('exam_slug' => $exam_slug);
		}

		$cfg = $all_blueprints[$exam_slug];

		$difficulty_dist = isset($cfg['difficulty']) && is_array($cfg['difficulty'])
			? $cfg['difficulty']
			: array();
		$bloom_dist      = isset($cfg['bloom']) && is_array($cfg['bloom'])
			? $cfg['bloom']
			: array();

		$difficulty      = self::pick_from_distribution($difficulty_dist, 'medium');
		$cognitive_level = self::pick_from_distribution($bloom_dist, 'understand');

		$prompt_hint = isset($cfg['prompt_hint']) ? (string) $cfg['prompt_hint'] : '';

		return array(
			'exam_slug'       => $exam_slug,
			'difficulty'      => $difficulty,
			'cognitive_level' => $cognitive_level,
			'prompt_hint'     => $prompt_hint,
		);
	}

	/**
	 * Helper: pick a key from a percentage distribution array, e.g.
	 * ['easy'=>20,'medium'=>60,'hard'=>20].
	 */
	private static function pick_from_distribution($dist, $fallback)
	{
		if (! is_array($dist) || empty($dist)) {
			return $fallback;
		}

		// Normalise to positive integers
		$filtered = array();
		foreach ($dist as $key => $val) {
			$val = (int) $val;
			if ($val > 0) {
				$filtered[$key] = $val;
			}
		}
		if (empty($filtered)) {
			return $fallback;
		}

		$total = array_sum($filtered);
		if ($total <= 0) {
			return $fallback;
		}

		$rand       = mt_rand(1, $total);
		$cumulative = 0;

		foreach ($filtered as $key => $val) {
			$cumulative += $val;
			if ($rand <= $cumulative) {
				return $key;
			}
		}

		return $fallback;
	}
	// ===================================================================================
	// CORE MCQ GENERATION LOGIC
	// ===================================================================================

	public static function generate_mcqs_from_news_sync($categories_to_process = array(), $override_status = null)
	{
		if (self::is_generation_locked('news')) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('⚠️ News Generation Skipped: Already running', 'warning');
			}
			return array(0, array('ERROR: News generation is already running. Please wait.'));
		}
		self::acquire_generation_lock('news');

		$news_generation_enabled = get_option('nm_news_generation_enabled', 0);
		if (! $news_generation_enabled) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('⚠️ News Generation Blocked: Disabled in settings', 'warning');
			}
			self::release_generation_lock('news');
			return array(0, array('INFO: News-based MCQ generation is disabled in settings. Skipping.'));
		}

		$trigger_type    = ! empty($categories_to_process) ? 'Manual' : 'Cron';
		$categories_list = ! empty($categories_to_process) ? implode(', ', array_map('ucfirst', $categories_to_process)) : 'Auto';
		$run_id          = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::start_run(strtolower($trigger_type), 'news', $categories_list) : null;
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity("🔄 {$trigger_type} News Generation Started (Categories: {$categories_list})", 'info');
		}

		try {
			$log             = array();
			$new_mcq_count   = 0;
			$duplicate_count = 0;
			$error_count     = 0;
			// @NEW 9.2.0: Collect stories + generated MCQs for the per-batch roundup article.
			$batch_articles = array();
			$batch_mcqs     = array();
			$log[]           = 'INFO: Starting news-based generation at ' . current_time('mysql');

			$gemini_api_key = NM_API_Client::get_gemini_api_key();
			$gnews_api_key  = NM_API_Client::get_gnews_api_key();

			$similarity_threshold = floatval(get_option('nm_similarity_threshold', 0.70));
			$detector             = new NM_Advanced_Duplicate_Detector($gemini_api_key, $similarity_threshold);

			if (empty($gemini_api_key) || empty($gnews_api_key)) {
				$log[] = 'ERROR: API key for Gemini or GNews is missing.';
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity("❌ {$trigger_type} News Generation Failed: API keys missing", 'error');
				}
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::finish_run($run_id, 0, 0, ++$error_count, 'missing keys');
				}
				self::release_generation_lock('news');
				return array(0, $log);
			}

			$country    = get_option('nm_news_country', 'us');
			$categories = ! empty($categories_to_process) ? $categories_to_process : (get_option('nm_news_categories', array()));

			if (empty($categories)) {
				$log[] = 'ERROR: No news categories selected.';
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity("❌ {$trigger_type} News Generation Failed: No categories selected", 'error');
				}
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::finish_run($run_id, 0, 0, ++$error_count, 'no categories');
				}
				self::release_generation_lock('news');
				return array(0, $log);
			}

			foreach ($categories as $category) {
				$log[]     = 'INFO: Fetching news for category: ' . ucfirst($category);
				$gnews_url = 'https://gnews.io/api/v4/top-headlines?category=' . urlencode($category) . '&lang=en&country=' . urlencode($country) . '&max=5&apikey=' . urlencode($gnews_api_key);
				$response  = wp_remote_get($gnews_url, array('timeout' => 30));

				if (is_wp_error($response)) {
					$log[] = 'ERROR: GNews API Error. ' . $response->get_error_message();
					++$error_count;
					continue;
				}
				$news_data = json_decode(wp_remote_retrieve_body($response), true);
				if (empty($news_data['articles'])) {
					$log[] = 'INFO: No articles found for category: ' . $category;
					continue;
				}

				$log[]              = 'SUCCESS: Found ' . count($news_data['articles']) . ' articles.';
				$generated_this_run = 0;

				foreach ($news_data['articles'] as $index => $article) {
					if ($generated_this_run >= 2) {
						break;
					}
					if (empty($article['description'])) {
						continue;
					}

					$article_text = $article['title'] . '. ' . $article['description'];
					$log[]        = "INFO: Processing article: '" . substr($article['title'], 0, 60) . "...'";

					$rate_check = self::check_rate_limit('gemini');
					if (! $rate_check['allowed']) {
						$log[] = "WARN: Rate limit reached. Waiting {$rate_check['retry_after']} seconds...";
						sleep($rate_check['retry_after']);
					}

					$exam_slug     = get_option('nm_default_exam_for_news', '');
					$blueprint_ctx = self::get_exam_blueprint_context($exam_slug);
					$api_response  = self::call_api_with_retry(array(NM_API_Client::get_instance(), 'generate_mcq_from_text'), array($article_text, $blueprint_ctx), 3);

					if ($api_response['success'] && ! empty($api_response['data']['question'])) {
						$mcq_data        = $api_response['data'];
						$topic_map       = array(
							'business'      => array(
								'topic'    => 'Business and Economics',
								'subtopic' => 'Business',
							),
							'entertainment' => array(
								'topic'    => 'Arts & Culture',
								'subtopic' => 'Entertainment',
							),
							'health'        => array(
								'topic'    => 'Food & Cuisine',
								'subtopic' => 'General Health',
							),
							'technology'    => array(
								'topic'    => 'Technology and Computing',
								'subtopic' => 'General Technology',
							),
							'sports'        => array(
								'topic'    => 'Sports',
								'subtopic' => 'General Sports',
							),
							'science'       => array(
								'topic'    => 'Science',
								'subtopic' => 'General Science',
							),
							'general'       => array(
								'topic'    => 'Miscellaneous',
								'subtopic' => 'General News',
							),
							'nation'        => array(
								'topic'    => 'Miscellaneous',
								'subtopic' => 'National News',
							),
						);
						$args_for_saving = array('api_key' => $gemini_api_key);
						if (isset($topic_map[$category])) {
							$args_for_saving['topic']    = $topic_map[$category]['topic'];
							$args_for_saving['subtopic'] = $topic_map[$category]['subtopic'];
						} else {
							$args_for_saving['topic']    = 'Miscellaneous';
							$args_for_saving['subtopic'] = ucfirst($category);
						}

						$duplicate_check = $detector->check_duplicate($mcq_data['question'], $args_for_saving['topic']);

						if (! $duplicate_check['is_duplicate']) {

							// ✅ NEW v7.3.7: Add E-A-T Data
							// @FIX 9.5.2: Do NOT hard-code author_name here. Leaving it empty lets
							// save_mcq_post_unified() assign a random named author (post_author +
							// mcq_author_name together), so wp-admin and the frontend byline agree.
							$mcq_data['source_name']  = ! empty($source_name) ? $source_name : 'News Source';
							$mcq_data['source_url']   = $article['url'] ?? '';
							$mcq_data['fact_checked'] = 'yes';

							// Apply Override Status if set
							if ($override_status) {
								$args_for_saving['post_status'] = $override_status;
							}

							$post_id = NM_Post_Type_Manager::save_mcq_post_unified($mcq_data, $args_for_saving);

							if ($post_id) {
								$log[] = 'SUCCESS: New MCQ created (ID: ' . $post_id . ')';
								if (class_exists('NM_Generation_Logger')) {
									NM_Generation_Logger::nm_log_activity(
										"Created MCQ from NEWS ({$category})",
										'success',
										array(
											'source_type' => 'news',
											'source_ref'  => $category,
											'mcq_id'      => $post_id,
											'question'    => $mcq_data['question'],
										)
									);
								}
								++$new_mcq_count;
								++$generated_this_run;

								// @NEW 9.2.0: Buffer this story + MCQ for the per-batch article.
								$batch_articles[] = array(
									'title'       => isset( $article['title'] ) ? $article['title'] : '',
									'description' => isset( $article['description'] ) ? $article['description'] : '',
									'url'         => isset( $article['url'] ) ? $article['url'] : '',
									'source_name' => isset( $article['source']['name'] ) ? $article['source']['name'] : '',
									'category'    => $category,
								);
								$batch_mcqs[]     = array(
									'post_id'   => $post_id,
									'question'  => isset( $mcq_data['question'] ) ? $mcq_data['question'] : '',
									'topic'     => isset( $args_for_saving['topic'] ) ? $args_for_saving['topic'] : '',
									'subtopic'  => isset( $args_for_saving['subtopic'] ) ? $args_for_saving['subtopic'] : '',
									'permalink' => get_permalink( $post_id ),
								);
							}
						} else {
							$method     = $duplicate_check['method'] ?? 'unknown';
							$similarity = isset($duplicate_check['similarity']) ? round($duplicate_check['similarity'] * 100, 1) . '%' : 'N/A';
							$log[]      = "INFO: Duplicate detected via {$method} (similarity: {$similarity}). Skipping.";
							if (class_exists('NM_Generation_Logger')) {
								NM_Generation_Logger::nm_log_duplicate_detection(
									$method,
									$duplicate_check['similarity'] ?? null,
									array(
										'source_type' => 'news',
										'source_ref'  => $category,
										'question'    => $mcq_data['question'],
									)
								);
							}
							++$duplicate_count;
						}
					} else {
						$log_msg = (isset($api_response['data']['question']) && $api_response['data']['question'] === null) ? 'AI rejected content (unsuitable)' : ($api_response['error'] ?? 'Unknown API error.');
						$log[]   = "ERROR: GEMINI API (News): {$log_msg}";
						++$error_count;
						if (class_exists('NM_Generation_Logger')) {
							NM_Generation_Logger::nm_log_activity(
								'Gemini API Error (NEWS): ' . $log_msg,
								'error',
								array(
									'source_type' => 'news',
									'source_ref'  => $category,
									'error_code'  => 'api_error',
									'question'    => $article['title'],
								)
							);
						}
					}
					if ($index < count($news_data['articles']) - 1 && $generated_this_run < 2) {
						$log[] = 'INFO: Pausing 7 seconds...';
						sleep(7);
					}
				}
			}

			// @NEW 9.2.0: Generate ONE roundup article per news batch (per run of this cron).
			// Twice-daily news cron => ~2 fresh articles/day. Draft by default; auto-publish optional.
			if ( ! empty( $batch_mcqs ) && class_exists( 'NM_News_Article_Generator' ) ) {
				if ( NM_News_Article_Generator::is_enabled() ) {
					$article_id = NM_News_Article_Generator::generate_for_batch( $batch_articles, $batch_mcqs );
					if ( is_wp_error( $article_id ) ) {
						$log[] = 'ARTICLE SKIP: ' . $article_id->get_error_message();
						if ( class_exists( 'NM_Generation_Logger' ) ) {
							NM_Generation_Logger::nm_log_activity( 'News article generation skipped: ' . $article_id->get_error_message(), 'warning' );
						}
					} else {
						$log[] = 'SUCCESS: News roundup article created (ID: ' . $article_id . ', status: ' . get_post_status( $article_id ) . ')';
						if ( class_exists( 'NM_Generation_Logger' ) ) {
							NM_Generation_Logger::nm_log_activity( 'News roundup article created (ID: ' . $article_id . ', status: ' . get_post_status( $article_id ) . ')', 'success' );
						}
					}
				}
			}

			$log[] = 'INFO: News generation finished. Total new MCQs: ' . $new_mcq_count;
			if (class_exists('NM_Generation_Logger')) {
				if ($new_mcq_count > 0) {
					NM_Generation_Logger::nm_log_activity("✅ {$trigger_type} News Generation Completed: {$new_mcq_count} MCQ(s) created, {$duplicate_count} duplicates filtered, {$error_count} errors", 'success');
				} else {
					NM_Generation_Logger::nm_log_activity("ℹ️ {$trigger_type} News Generation Completed: No new MCQs (" . ($duplicate_count > 0 ? 'all were duplicates' : 'no suitable content') . ')', 'info');
				}
			}
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::finish_run($run_id, $new_mcq_count, $duplicate_count, $error_count, 'news sync');
			}
			self::release_generation_lock('news');
			if ($new_mcq_count > 0) {
				self::track_daily_generation_stats($new_mcq_count);
			}
			return array($new_mcq_count, $log);
		} catch (Exception $e) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::finish_run($run_id, $new_mcq_count ?? 0, $duplicate_count ?? 0, ($error_count ?? 0) + 1, 'exception');
			}
			self::release_generation_lock('news');
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("❌ {$trigger_type} News Generation Failed: " . $e->getMessage(), 'error');
			}
			return array(0, array('ERROR: Exception occurred: ' . $e->getMessage()));
		}
	}

	public static function generate_mcqs_from_topics_sync($topic_ids_to_process = array(), $override_status = null)
	{
		if (self::is_generation_locked('topic')) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('⚠️ Topic Generation Skipped: Already running', 'warning');
			}
			return array(0, array('ERROR: Topic generation is already running. Please wait.'));
		}
		self::acquire_generation_lock('topic');

		$topic_generation_enabled = get_option('nm_topic_generation_enabled', 0);
		if (! $topic_generation_enabled) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('⚠️ Topic Generation Blocked: Disabled in settings', 'warning');
			}
			self::release_generation_lock('topic');
			return array(0, array('INFO: Topic-based MCQ generation is disabled in settings. Skipping.'));
		}

		$trigger_type = ! empty($topic_ids_to_process) ? 'Manual' : 'Cron';
		$topic_count  = ! empty($topic_ids_to_process) ? count($topic_ids_to_process) : 'Auto (1)';
		$run_id       = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::start_run(strtolower($trigger_type), 'topic', (string) $topic_count . ' topic(s)') : null;
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity("🔄 {$trigger_type} Topic Generation Started (Processing: {$topic_count} topic(s))", 'info');
		}

		try {
			$log             = array();
			$new_mcq_count   = 0;
			$duplicate_count = 0;
			$error_count     = 0;

			$gemini_api_key = NM_API_Client::get_gemini_api_key();

			$similarity_threshold = floatval(get_option('nm_similarity_threshold', 0.70));
			$detector             = new NM_Advanced_Duplicate_Detector($gemini_api_key, $similarity_threshold);

			if (empty($gemini_api_key)) {
				$log[] = 'ERROR: Gemini API key is missing.';
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity("❌ {$trigger_type} Topic Generation Failed: API key missing", 'error');
				}
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::finish_run($run_id, 0, 0, ++$error_count, 'missing key');
				}
				self::release_generation_lock('topic');
				return array(0, $log);
			}
			$num_questions     = get_option('nm_topic_mcq_count', 1);
			$topics_to_iterate = array();

			if (! empty($topic_ids_to_process)) {
				$log[]             = 'INFO: Manual trigger detected. Processing specified topic(s).';
				$topics_to_iterate = $topic_ids_to_process;
			} else {
				$log[]         = 'INFO: Cron trigger detected. Finding next topic to process.';
				$all_topic_ids = get_option('nm_topic_list_ids', array());
				if (empty($all_topic_ids)) {
					$log[] = 'INFO: No topics specified in settings for cron generation.';
					if (class_exists('NM_Generation_Logger')) {
						NM_Generation_Logger::nm_log_activity("ℹ️ {$trigger_type} Topic Generation Skipped: No topics configured", 'info');
					}
					if (class_exists('NM_Generation_Logger')) {
						NM_Generation_Logger::finish_run($run_id, 0, 0, $error_count, 'no topics configured');
					}
					self::release_generation_lock('topic');
					return array(0, $log);
				}
				$last_index = get_option('nm_last_processed_topic_index', -1);
				$next_index = $last_index + 1;
				if ($next_index >= count($all_topic_ids)) {
					$next_index = 0;
				}
				$topic_id_for_this_run = $all_topic_ids[$next_index];
				$topics_to_iterate[]   = $topic_id_for_this_run;
				update_option('nm_last_processed_topic_index', $next_index);
				$log[] = "INFO: Processing topic at index {$next_index} (ID: {$topic_id_for_this_run}).";
			}

			foreach ($topics_to_iterate as $topic_id) {
				$term = get_term($topic_id, 'topic');
				if (! $term || is_wp_error($term)) {
					$log[] = "ERROR: Could not find term with ID: {$topic_id}. Skipping.";
					++$error_count;
					continue;
				}

				// ✅ START MODIFICATION: Removed the $existing_question_titles query.
				// $existing_questions_query = new WP_Query([...]);
				// $existing_question_titles = [];
				// if ($existing_questions_query->have_posts()) $existing_question_titles = wp_list_pluck($existing_questions_query->posts, 'post_title');
				// ✅ END MODIFICATION

				$child_name      = $term->name;
				$parent_name     = ($term->parent) ? get_term($term->parent, 'topic')->name : '';
				$full_topic_name = ($parent_name ? $parent_name . ' -> ' : '') . $child_name;
				$log[]           = "INFO: Generating batch of MCQs for topic: '{$full_topic_name}'";

				// ✅ START MODIFICATION: Removed the 'for' loop
				// for ($i = 0; $i < $num_questions; $i++) {

				// Check rate limit *before* the API call
				$rate_check = self::check_rate_limit('gemini');
				if (! $rate_check['allowed']) {
					$log[] = "WARN: Rate limit reached. Waiting {$rate_check['retry_after']} seconds...";
					sleep($rate_check['retry_after']);
				}

				// Call the API *once* to get a batch of questions
				// ✅ MODIFICATION: Removed $existing_question_titles from the call
				// Call the API *once* to get a batch of questions
				$exam_slug     = get_option('nm_default_exam_for_topics', '');
				$blueprint_ctx = self::get_exam_blueprint_context($exam_slug);

				$api_response = self::call_api_with_retry(
					array(NM_API_Client::get_instance(), 'generate_mcq_from_topic'),
					array($child_name, $parent_name, $num_questions, array(), $blueprint_ctx),
					3
				);

				// ✅ MODIFICATION: Check for 'questions' array instead of 'question'
				if ($api_response['success'] && ! empty($api_response['data']['questions'])) {

					$questions_from_api = $api_response['data']['questions'];
					$log[]              = 'SUCCESS: AI returned ' . count($questions_from_api) . ' questions. Checking for duplicates...';

					// ✅ MODIFICATION: Loop through the *results* from the single API call
					foreach ($questions_from_api as $mcq_data) {
						if (empty($mcq_data['question'])) {
							$log[] = 'INFO: Skipping one item in batch (empty question).';
							++$error_count;
							continue;
						}

						// Run duplicate check for each question
						$duplicate_check = $detector->check_duplicate($mcq_data['question'], $parent_name);

						if (! $duplicate_check['is_duplicate']) {

							// ✅ NEW v7.3.7: Add E-A-T Data
							// @FIX 9.5.2: Do NOT hard-code author_name here (it blocked the random
							// named-author rotation in save_mcq_post_unified). Also removed the dead
							// 'post_author' save-arg: save_mcq_post_unified never read it, and the
							// rotation now sets post_author + mcq_author_name consistently.
                $mcq_data['source_name'] = $term->name . ' Knowledge Database';
							$mcq_data['fact_checked'] = 'yes';

							$save_args = array(
								'topic'       => $parent_name,
								'subtopic'    => $child_name,
								'api_key'     => $gemini_api_key,
							);
							if ($override_status) {
								$save_args['post_status'] = $override_status;
							}

							// Attempt save
							$post_id = NM_Post_Type_Manager::save_mcq_post_unified($mcq_data, $save_args);

							// ✅ LOGGING: Check for failure
							if (! $post_id || is_wp_error($post_id)) {
								$err_msg = is_wp_error($post_id) ? $post_id->get_error_message() : 'Unknown DB Error';
								$log[] = "ERROR: Failed to save MCQ. DB said: {$err_msg}";
								if (class_exists('NM_Generation_Logger')) {
									NM_Generation_Logger::nm_log_activity("❌ Save Failed: {$err_msg}", 'error');
								}
								++$error_count;
								continue; // Skip success block
							}

							// Ensure $post_id is valid before proceeding
							if ($post_id) {
								$log[] = "SUCCESS: New MCQ saved (ID: {$post_id}).";
								if (class_exists('NM_Generation_Logger')) {
									NM_Generation_Logger::nm_log_activity(
										"Created MCQ from TOPIC ({$full_topic_name})",
										'success',
										array(
											'source_type' => 'topic',
											'source_ref'  => $full_topic_name,
											'mcq_id'      => $post_id,
											'question'    => $mcq_data['question'],
										)
									);
								}
								++$new_mcq_count;
								// $existing_question_titles[] = $mcq_data['question']; // No longer needed
							}
						} else {
							$method     = $duplicate_check['method'] ?? 'unknown';
							$similarity = isset($duplicate_check['similarity']) ? round($duplicate_check['similarity'] * 100, 1) . '%' : 'N/A';
							$log[]      = "INFO: Duplicate detected via {$method} (similarity: {$similarity}). Skipping.";
							++$duplicate_count;
							if (class_exists('NM_Generation_Logger')) {
								NM_Generation_Logger::nm_log_duplicate_detection(
									$method,
									$duplicate_check['similarity'] ?? null,
									array(
										'source_type' => 'topic',
										'source_ref'  => $full_topic_name,
										'question'    => $mcq_data['question'],
									)
								);
							}
						}
					} // end foreach loop
				} else {
					// This block now handles the failure of the *entire batch*
					$log_msg = (isset($api_response['data']['question']) && $api_response['data']['question'] === null) ? 'AI rejected content (unsuitable)' : ($api_response['error'] ?? 'Unknown API error.');
					$log[]   = "ERROR: GEMINI API (Topic Batch): {$log_msg}";
					++$error_count;
					if (class_exists('NM_Generation_Logger')) {
						NM_Generation_Logger::nm_log_activity(
							'Gemini API Error (TOPIC BATCH): ' . $log_msg,
							'error',
							array(
								'source_type' => 'topic',
								'source_ref'  => $full_topic_name,
								'error_code'  => 'api_error',
								'question'    => "Topic: {$full_topic_name}",
							)
						);
					}
				}

				// ✅ MODIFICATION: Removed the 'sleep(7)' call
				// if ($i < $num_questions - 1) { $log[] = "INFO: Pausing 7 seconds..."; sleep(7); }
				// } // ✅ MODIFICATION: Removed the closing brace for the 'for' loop
			}
			$log[] = "INFO: Topic generation finished. Total new MCQs: {$new_mcq_count}.";
			if (class_exists('NM_Generation_Logger')) {
				if ($new_mcq_count > 0) {
					NM_Generation_Logger::nm_log_activity("✅ {$trigger_type} Topic Generation Completed: {$new_mcq_count} MCQ(s) created, {$duplicate_count} duplicates filtered, {$error_count} errors", 'success');
				} else {
					NM_Generation_Logger::nm_log_activity("ℹ️ {$trigger_type} Topic Generation Completed: No new MCQs (" . ($duplicate_count > 0 ? 'all were duplicates' : 'no suitable content') . ')', 'info');
				}
			}
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::finish_run($run_id, $new_mcq_count, $duplicate_count, $error_count, 'topic sync');
			}
			self::release_generation_lock('topic');
			if ($new_mcq_count > 0) {
				self::track_daily_generation_stats($new_mcq_count);
			}
			return array($new_mcq_count, $log);
		} catch (Exception $e) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::finish_run($run_id, $new_mcq_count ?? 0, $duplicate_count ?? 0, ($error_count ?? 0) + 1, 'exception');
			}
			self::release_generation_lock('topic');
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("❌ {$trigger_type} Topic Generation Failed: " . $e->getMessage(), 'error');
			}
			return array(0, array('ERROR: Exception occurred: ' . $e->getMessage()));
		}
	}
}
