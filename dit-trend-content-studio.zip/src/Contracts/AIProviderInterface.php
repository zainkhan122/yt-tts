<?php

namespace DIT\TrendStudio\Contracts;

/**
 * Contract for AI providers used by the TrendStudio pipeline.
 *
 * Implementations must wrap external AI vendors (e.g. Gemini, OpenAI)
 * behind a consistent interface so that the rest of the plugin can
 * operate without vendor-specific knowledge.
 */
interface AIProviderInterface
{
    /**
     * Generate an article or long-form content from structured prompt data.
     *
     * @param array $promptData Structured prompt data describing the desired output.
     * @return array AI response data in associative array form.
     */
    public function generate(array $promptData): array;

    /**
     * Generate content using research data. This method should be used
     * when the provider supports research+generation flows (e.g. Perplexity+Gemini).
     *
     * @param array $promptData Structured prompt data.
     * @param array $researchData Normalised research information.
     * @return array AI response data in associative array form.
     */
    public function generateFromResearch(array $promptData, array $researchData): array;

    /**
     * Generate generic JSON from a custom prompt. Useful for strategy
     * blueprints and other utility agents.
     *
     * @param string $prompt The complete prompt text.
     * @return array Parsed JSON structure.
     */
    public function generateCustomJson(string $prompt): array;
    /**
     * Get the name of the model being used by this provider.
     *
     * @return string
     */
    public function get_model(): string;
}
