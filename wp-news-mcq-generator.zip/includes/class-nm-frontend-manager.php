<?php

/**
 * Frontend Manager
 *
 * @version 1.3 - Implemented Site-Wide Dark Mode (FOUC Fix & Toggle)
 *
 * @MODIFIED: Added inject_dark_mode_fouc_fix() to run in wp_head (priority 0).
 * @MODIFIED: Replaced add_login_logout_to_nav_menu() with a new version
 * that includes the 3-state (Light/Dark/Auto) theme toggle.
 */

if (! defined('ABSPATH')) {
	exit;
}

require_once NM_PLUGIN_PATH . 'includes/class-nm-publication-scheduler.php';

class NM_Frontend_Manager
{


	/**
	 * Initialize all frontend hooks
	 */
	public static function init()
	{
		// --- ✅ NEW: Dark Mode FOUC Fix (Step 1) ---
		// This MUST run with high priority (0) in the <head>
		add_action('wp_head', array(self::class, 'inject_dark_mode_fouc_fix'), 0);

		// --- Hooks from 21-related-questions.php ---
		add_filter('the_content', array(self::class, 'display_related_questions'), 99);

		// --- Hooks from 22-social-sharing.php ---
		add_filter('the_content', array(self::class, 'add_social_share_buttons'), 98);

		// --- Hooks from 9-seo-integration.php ---
		add_filter('rank_math/json_ld', array(self::class, 'nm_master_schema_handler'), 99, 2);
		// (Sitewide WebSite/Organization are handled by Rank Math when it is active;
		//  output_sitewide_schema() emits them only when Rank Math is absent.)

		// --- Hooks from main plugin file ---
		add_action('after_setup_theme', array(self::class, 'setup_theme_filters'));
		add_filter('wp_nav_menu_items', array(self::class, 'add_login_logout_to_nav_menu'), 20, 2);
		add_action('wp_enqueue_scripts', array(self::class, 'enqueue_nav_link_styles'));

		// Our custom OG tags for MCQ single pages
		add_action('wp_head', array(self::class, 'output_custom_mcq_og_tags'), 1);

		// @NEW 9.2.0: Site-wide WebSite (SitelinksSearchBox) + Organization JSON-LD
		add_action('wp_head', array(self::class, 'output_sitewide_schema'), 5);

		// Disable Rank Math OG only on MCQs, inside Rank Math's own head hook
		add_action('rank_math/head', array(self::class, 'remove_rankmath_duplicate_tags'), 5);

        // Initialize Publication Scheduler
        NMPublicationScheduler::init();
	}
	public static function output_custom_mcq_og_tags()
	{
		if (! is_singular('mcq')) {
			return;
		}

		$post_id = get_the_ID();

		// Use the stored MCQ question as title; fall back to post title
		$question       = get_post_meta($post_id, 'mcq_question', true);
		$fallback_title = get_the_title($post_id);
		$custom_title   = $question ? $question : $fallback_title;

		// Build a compact description from the options
		$options            = get_post_meta($post_id, 'mcq_options', true);
		$custom_description = 'Test your knowledge with this quiz question!';

		if (is_array($options) && ! empty($options)) {
			$option_texts        = array_slice(
				array_map('wp_strip_all_tags', array_values($options)),
				0,
				4
			);
			$custom_description .= ' Options include: ' . implode(', ', $option_texts) . '.';

			if (strlen($custom_description) > 297) {
				$custom_description = substr($custom_description, 0, 294) . '...';
			}
		}

 $og_image = self::get_mcq_social_image($post_id);
 $og_url = get_permalink($post_id);
 $og_image_mime = self::detect_og_image_mime($og_image);
 ?>
 <meta property="og:type" content="article" />
 <meta property="og:url" content="<?php echo esc_url($og_url); ?>" />
 <meta property="og:title" content="<?php echo esc_attr($custom_title); ?>" />
 <meta property="og:description" content="<?php echo esc_attr($custom_description); ?>" />
 <?php if ($og_image) : ?>
 <meta property="og:image" content="<?php echo esc_url($og_image); ?>" />
 <meta property="og:image:secure_url" content="<?php echo esc_url(set_url_scheme($og_image, 'https')); ?>" />
 <meta property="og:image:width" content="1200" />
 <meta property="og:image:height" content="630" />
 <?php if ($og_image_mime) : ?>
 <meta property="og:image:type" content="<?php echo esc_attr($og_image_mime); ?>" />
 <?php endif; ?>
 <meta name="twitter:image" content="<?php echo esc_url($og_image); ?>" />
 <?php endif; ?>
 <meta name="twitter:card" content="summary_large_image" />
 <meta name="twitter:title" content="<?php echo esc_attr($custom_title); ?>" />
 <meta name="twitter:description" content="<?php echo esc_attr($custom_description); ?>" />
 <?php
	}
	/**
	 * Removes Rank Math's OG tags on MCQ singles
	 * so only our custom OG block is output.
	 */
	public static function remove_rankmath_duplicate_tags()
	{
		// Only act on single MCQ posts
		if (! is_singular('mcq')) {
			return;
		}

		// Per Rank Math docs: remove all OG actions for this request
		remove_all_actions('rank_math/opengraph/facebook');
		remove_all_actions('rank_math/opengraph/twitter');
	}

 private static function detect_og_image_mime($image_url)
 {
 if (empty($image_url)) {
 return false;
 }
 $path = wp_parse_url($image_url, PHP_URL_PATH);
 if ($path && preg_match('/\.webp$/i', $path)) {
 return 'image/webp';
 }
 if ($path && preg_match('/\.(jpe?g)$/i', $path)) {
 return 'image/jpeg';
 }
 if ($path && preg_match('/\.png$/i', $path)) {
 return 'image/png';
 }
 if ($path && preg_match('/\.gif$/i', $path)) {
 return 'image/gif';
 }
 return false;
 }

 /**
 * Get social media image for MCQ with intelligent fallback hierarchy
 *
 * Fallback Order:
 * 0. Stored _nm_social_image_url post meta (single source of truth)
 * 1. Exam taxonomy image (most specific, e.g. "CSS Exam")
 * 2. Subtopic image (child topic, e.g. "Constitutional Law")
 * 3. Parent topic image (e.g. "Law & Governance")
 * 4. Site-wide default image (from settings)
 *
 * @param int $post_id MCQ post ID
 * @return string|false Image URL or false if no image found
 */
 private static function get_mcq_social_image($post_id)
 {
 $stored_url = get_post_meta($post_id, '_nm_social_image_url', true);
 if ($stored_url) {
 return set_url_scheme($stored_url, 'https');
 }

 if (class_exists('NM_Social_Image_Generator')) {
 $version = get_post_meta($post_id, '_nm_social_image_version', true);
 if ($version) {
 $upload_dir = wp_upload_dir();
 $file_path = $upload_dir['basedir'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp';
 if (file_exists($file_path)) {
 $file_url = set_url_scheme($upload_dir['baseurl'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp', 'https');
 return $file_url;
 }
 }
 }
 // 1. Try Exam taxonomy image (Highest Priority)
		$exam_terms = wp_get_post_terms($post_id, 'nm_exam', array('number' => 1));
		if (! empty($exam_terms) && ! is_wp_error($exam_terms)) {
			$image_id = get_term_meta($exam_terms[0]->term_id, 'exam_image', true);
			if ($image_id) {
				$image_url = wp_get_attachment_image_url($image_id, 'large');
				if ($image_url) {
					return $image_url;
				}
			}
		}

		// 2. Try Topic taxonomy (child topics first, then parent)
		// Order by parent DESC to get child topics before parents
		$topics = wp_get_post_terms(
			$post_id,
			'topic',
			array(
				'orderby' => 'parent',
				'order'   => 'DESC',
			)
		);
		if (! empty($topics) && ! is_wp_error($topics)) {
			foreach ($topics as $topic) {
				$image_id = get_term_meta($topic->term_id, 'topic_image', true);
				if ($image_id) {
					$image_url = wp_get_attachment_image_url($image_id, 'large');
					if ($image_url) {
						return $image_url;
					}
				}
			}
		}

		// 3. Fallback to site default (if set in settings)
		$default_image = get_option('nm_default_social_image', '');
		if (! empty($default_image)) {
			// Could be either a URL or attachment ID
			if (is_numeric($default_image)) {
				$image_url = wp_get_attachment_image_url($default_image, 'large');
				return $image_url ? $image_url : false;
			} else {
				return esc_url($default_image);
			}
		}

		return false;
	}
	// =========================================================================
	// ✅ NEW: DARK MODE FOUC FIX (Step 1)
	// =========================================================================

	/**
	 * Injects a blocking script in the <head> to prevent FOUC (Flash of Unstyled Content)
	 * This applies 'dark-mode' to the <html> tag before the body renders.
	 */
	public static function inject_dark_mode_fouc_fix()
	{
		// This JS is minified to run as fast as possible.
		// It checks localStorage for a 'nm-theme' preference.
		// If 'dark', it applies the class.
		// If 'light', it does nothing.
		// If 'auto' or null, it checks the OS preference.
		$script = "
(function() {
    try {
        var theme = localStorage.getItem('nm-theme') || 'auto';
        if (theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark-mode');
        }
    } catch (e) {
        console.error('Error applying dark mode theme.', e);
    }
})();
        ";
		echo '<script>' . $script . '</script>';
	}

	// =========================================================================
	// HIDE ADMIN BAR & ADD NAV LINKS (Modified for Step 2)
	// =========================================================================

	public static function setup_theme_filters()
	{
		if (is_user_logged_in()) {
			$user = wp_get_current_user();
			if (! current_user_can('manage_options') && (in_array('subscriber', $user->roles) || in_array('quiz_taker', $user->roles))) {
				show_admin_bar(false);
			}
		}
	}

	/**
	 * ✅ MODIFIED: This function NO LONGER adds the dark mode toggle.
	 * It only adds the Login/Logout links.
	 */
	public static function add_login_logout_to_nav_menu($items, $args)
	{
		$target_menus = apply_filters('nm_login_menu_locations', array('primary', 'main_menu', 'header-menu', 'menu-1', 'mobile_menu'));

		if (in_array($args->theme_location, $target_menus)) {
			$dashboard_url = esc_url(home_url('/mcq-dashboard/'));
			$logout_url    = esc_url(wp_logout_url(home_url('/mcq-login/')));
			$link_class    = 'menu-link nm-nav-item';

			if (is_user_logged_in()) {
				$is_dashboard     = is_page('mcq-dashboard');
				$dashboard_active = $is_dashboard ? ' active' : '';
				$items           .= '<li class="menu-item nm-nav-item-dashboard' . $dashboard_active . '"><a href="' . $dashboard_url . '" class="' . $link_class . $dashboard_active . '">My Dashboard</a></li>';
				$items           .= '<li class="menu-item nm-nav-item-logout"><a href="' . $logout_url . '" class="' . $link_class . ' logout">Logout</a></li>';
			} else {
				// Do nothing. User will add "Login" and "Sign Up" manually.
			}
		}
		return $items;
	}

	/**
	 * ✅ MODIFIED: This function now also enqueues the dark-mode.js script
	 */
	public static function enqueue_nav_link_styles()
	{
		// Enqueue the CSS for the nav links and toggle
		if (file_exists(NM_PLUGIN_PATH . 'assets/css/top-nav.css')) {
			wp_enqueue_style('nm-top-nav-css', NM_PLUGIN_URL . 'assets/css/top-nav.css', array(), filemtime(NM_PLUGIN_PATH . 'assets/css/top-nav.css'));
		}

		// Enqueue the JS for the toggle
		if (file_exists(NM_PLUGIN_PATH . 'assets/js/dark-mode.js')) {
			wp_enqueue_script(
				'nm-dark-mode-js',
				NM_PLUGIN_URL . 'assets/js/dark-mode.js',
				array('jquery'),
				filemtime(NM_PLUGIN_PATH . 'assets/js/dark-mode.js'),
				true
			);
		}
	}

	// =========================================================================
	// 21-related-questions.php LOGIC (✅ MODIFIED)
	// =========================================================================

	public static function display_related_questions($content)
	{
		if (! is_singular('mcq') || ! in_the_loop() || ! is_main_query()) {
			return $content;
		}

		if (get_option('nm_enable_related_questions', 1) != 1) {
			return $content;
		}

		$post_id      = get_the_ID();
		$related_html = self::get_related_questions_html($post_id);

		if (! empty($related_html)) {
			$content .= $related_html;
		}

		return $content;
	}

	/**
	 * ✅ MODIFIED: Removed all inline styles for Dark Mode compatibility.
	 * Styles are now in single-mcq.css and top-nav.css.
	 */
	private static function get_related_questions_html($post_id)
	{
		$count        = get_option('nm_related_questions_count', 5);
		$related_mcqs = self::get_related_mcqs($post_id, $count);

		if (empty($related_mcqs)) {
			return '';
		}

		ob_start();
	?>
		<div class="nm-related-questions">
			<h3>🔗 Related Questions You May Like</h3>
			<ul>
				<?php foreach ($related_mcqs as $mcq) : ?>
					<li>
						<a href="<?php echo esc_url(get_permalink($mcq->ID)); ?>">
							📝 <?php echo esc_html($mcq->post_title); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php
		return ob_get_clean();
	}

	private static function get_related_mcqs($post_id, $count)
	{
		// @MODIFIED v9.0.3 - Cache related questions for 12 hours
		$transient_key = 'nm_related_' . $post_id . '_' . $count;
		$cached        = get_transient($transient_key);
		if ($cached !== false) {
			return $cached;
		}

		$topics = wp_get_post_terms($post_id, 'topic', array('fields' => 'ids'));

		if (empty($topics) || is_wp_error($topics)) {
			return array();
		}

		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => 'publish',
			'posts_per_page' => $count,
			'post__not_in'   => array($post_id),
			'no_found_rows'  => true, // Performance optimization
			'tax_query'      => array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'term_id',
					'terms'    => $topics,
					'operator' => 'IN',
				),
			),
		);

		$related = get_posts($args);
		set_transient($transient_key, $related, 12 * HOUR_IN_SECONDS);
		return $related;
	}

	// =========================================================================
	// 22-social-sharing.php LOGIC (✅ MODIFIED)
	// =========================================================================

	/**
	 * ✅ MODIFIED: Removed container inline styles for Dark Mode compatibility.
	 * Styles for <a> tags are kept as they are brand-specific.
	 */
	public static function add_social_share_buttons($content)
	{
		if (! is_singular('mcq') || ! in_the_loop() || ! is_main_query()) {
			return $content;
		}

		if (get_option('nm_enable_social_sharing', 0) != 1) {
			return $content;
		}

		$post_id  = get_the_ID();
		$post_url = get_permalink();

		// Prefer the stored MCQ question text over the post title
		$question   = get_post_meta($post_id, 'mcq_question', true);
		$post_title = $question ? $question : get_the_title($post_id);
		$excerpt    = wp_trim_words(wp_strip_all_tags($post_title), 28, 'â€¦');

		// 1. WhatsApp â€“ match homepage/JS format exactly
		$whatsapp_msg  = "🧠 Daily Quiz Challenge\n\n";
		$whatsapp_msg .= $excerpt . "\n\n";
		$whatsapp_msg .= "Tap to see the options and the correct answer:\n" . $post_url;

		$whatsapp_url = 'https://api.whatsapp.com/send?text=' . rawurlencode($whatsapp_msg);

		// 2. X / Twitter â€“ match WhatsApp format for consistency
		$twitter_msg  = "🧠 Daily Quiz Challenge\n\n";
		$twitter_msg .= $excerpt . "\n\n";
		$twitter_msg .= "Tap to see the options and the correct answer:\n";
		// Note: Twitter Intent URL param handling is specific, new lines are supported.

		$twitter_url = 'https://x.com/intent/tweet?text=' . urlencode($twitter_msg) . '&url=' . urlencode($post_url);

		// 3. Facebook (Relies on OG Tags)
		// Facebook ignores the 'quote' parameter in modern APIs, relying entirely on the OG tags we fixed earlier.
		$facebook_url = 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode($post_url);

		// 4. LinkedIn (Professional Context)
		$linkedin_summary = 'Test your knowledge with this daily quiz question. Essential for competitive exam preparation.';
		$linkedin_url     = 'https://www.linkedin.com/shareArticle?mini=true&url=' . urlencode($post_url) . '&title=' . urlencode('🧠 Quiz: ' . $post_title) . '&summary=' . urlencode($linkedin_summary) . '&source=' . urlencode(get_bloginfo('name'));

		// --- Build the $share_links array ---
		$share_links = array(
			'twitter'  => $twitter_url,
			'facebook' => $facebook_url,
			'whatsapp' => $whatsapp_url,
			'linkedin' => $linkedin_url,
		);

		$share_html = '<div class="nm-social-share">';
		$share_html .= '<h4>💡 Found this helpful? Share with friends!</h4>';
		$share_html .= '<div class="nm-share-buttons">';
		$share_html .= '<a href="' . esc_url($share_links['facebook']) . '" target="_blank" rel="noopener" class="nm-share-btn nm-share-facebook">Facebook</a>';
		$share_html .= '<a href="' . esc_url($share_links['twitter']) . '" target="_blank" rel="noopener" class="nm-share-btn nm-share-twitter">X</a>';
		$share_html .= '<a href="' . esc_url($share_links['whatsapp']) . '" target="_blank" rel="noopener" class="nm-share-btn nm-share-whatsapp">WhatsApp</a>';
		$share_html .= '<a href="#" class="nm-share-btn nm-share-copy-link" data-link="' . esc_url($post_url) . '">Copy Link</a>';
		$share_html .= '</div></div>';

		return $content . $share_html;
	}

	// =========================================================================
	// 9-seo-integration.php LOGIC (Unchanged)
	// =========================================================================

	public static function nm_master_schema_handler($data, $jsonld)
	{
		if (is_singular('mcq')) {
			return self::nm_handle_single_mcq_schema($data, $jsonld);
		}
		if (is_tax('topic')) {
			return self::nm_handle_topic_archive_schema($data, $jsonld);
		}
		if (self::nm_is_shortcode_page()) {
			return self::nm_handle_homepage_schema($data, $jsonld);
		}
		return $data;
	}

	/**
	 * @NEW 9.2.0: Emit site-wide WebSite (SitelinksSearchBox) + Organization JSON-LD.
	 * These help search engines and AI/answer engines understand the site and surface
	 * a search box. Output once, only on the front end, when Rank Math hasn't already
	 * provided these (to avoid duplicates we merge defensively by @type).
	 */
	public static function output_sitewide_schema()
	{
		if (is_admin()) {
			return;
		}

		// @FIX 9.3.1 (SSOT): Rank Math already emits WebSite + Organization (as a
		// Person+Organization node). Outputting our own WebSite/Organization would create
		// DUPLICATES. Detect Rank Math robustly via its version constant and emit NOTHING
		// when it is active — Rank Math fully owns sitewide schema. Only when Rank Math is
		// absent do we emit WebSite + Organization here.
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) || class_exists( 'RankMath\\RankMath' ) ) {
			return;
		}

		$home_url   = home_url('/');
		$site_name  = get_bloginfo('name');
		$schema     = array();

		$schema[] = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'@id'             => $home_url . '#website',
			'url'             => $home_url,
			'name'            => $site_name,
			'potentialAction' => array(
				array(
					'@type'       => 'SearchAction',
					'target'      => array(
						'@type'       => 'EntryPoint',
						'urlTemplate' => $home_url . '?s={search_term_string}',
					),
					'query-input' => 'required name=search_term_string',
				),
			),
		);

		$logo = '';
		$custom_logo_id = get_theme_mod('custom_logo');
		if ($custom_logo_id) {
			$logo = wp_get_attachment_image_url($custom_logo_id, 'full');
		}
		$org = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Organization',
			'@id'      => $home_url . '#organization',
			'name'     => $site_name,
			'url'      => $home_url,
		);
		if ($logo) {
			$org['logo'] = $logo;
		}
		$schema[] = $org;

		echo '<script type="application/ld+json" id="nm-sitewide-schema">' . wp_json_encode($schema) . '</script>' . "\n";
	}

	private static function nm_handle_single_mcq_schema($data, $jsonld)
	{
		if (isset($data['Article'])) {
			unset($data['Article']);
		}
		if (isset($data['FAQPage'])) {
			unset($data['FAQPage']);
		}
		$post_id            = get_the_ID();
		$options            = get_post_meta($post_id, 'mcq_options', true);
		$correct_answer_key = get_post_meta($post_id, 'mcq_answer', true);
		$explanation        = get_post_meta($post_id, 'mcq_explanation', true);
		if (empty($options) || ! is_array($options) || empty($correct_answer_key) || ! isset($options[$correct_answer_key])) {
			return $data;
		}
		$suggested_answers = array();
		$accepted_answer   = null;
		$position          = 0;
		foreach ($options as $key => $value) {
			$answer_object = array(
				'@type'          => 'Answer',
				'text'           => esc_html($value),
				'encodingFormat' => 'text/html',
				'position'       => $position,
			);
			if ($key === $correct_answer_key) {
				$answer_object['comment'] = array(
					'@type' => 'Comment',
					'text'  => 'This is the correct answer.',
				);
				if (! empty($explanation)) {
					$answer_object['answerExplanation'] = array(
						'@type' => 'Comment',
						'text'  => esc_html($explanation),
					);
				}
				$accepted_answer = $answer_object;
			} else {
				$answer_object['comment'] = array(
					'@type' => 'Comment',
					'text'  => 'Consider why this might not be the best answer.',
				);
				$suggested_answers[]      = $answer_object;
			}
			++$position;
		}
		if ($accepted_answer === null) {
			$accepted_answer = array(
				'@type'          => 'Answer',
				'text'           => 'Answer not available',
				'encodingFormat' => 'text/html',
				'position'       => 0,
			);
		}
		$topics                                = wp_get_post_terms($post_id, 'topic', array('fields' => 'names'));
		$topic_name                            = ! empty($topics) && ! is_wp_error($topics) ? $topics[0] : 'General Knowledge';
		$topic_terms                           = wp_get_post_terms($post_id, 'topic');
		$topic_slug                            = ! empty($topic_terms) && ! is_wp_error($topic_terms) ? $topic_terms[0]->name : 'General Knowledge';
		// Use stored MCQ question as title; fall back to post title
		// @MODIFIED v9.0.3 - Align schema name/text with metadata and OG tags
		$question_meta = get_post_meta($post_id, 'mcq_question', true);
		$custom_title  = $question_meta ? $question_meta : get_the_title($post_id);

		$question_data                         = array(
			'@type'                => 'Question',
			'@id'                  => get_permalink($post_id) . '#question',
			'name'                 => esc_html($custom_title),
			'text'                 => esc_html($custom_title),
			'encodingFormat'       => 'text/html',
			'eduQuestionType'      => 'Multiple choice',
			'learningResourceType' => 'Practice problem',
			'educationalLevel'     => 'Competitive Exam Preparation',
			'typicalAgeRange'      => '18-35',
			'assesses'             => esc_html($topic_slug) . ' knowledge',
			'acceptedAnswer'       => $accepted_answer,
			'suggestedAnswer'      => $suggested_answers,
		);
		$question_data['educationalAlignment'] = array(
			'@type'         => 'AlignmentObject',
			'alignmentType' => 'educationalSubject',
			'targetName'    => esc_html($topic_name),
		);
		$author_name = get_post_meta($post_id, 'mcq_author_name', true);
		if (empty($author_name)) {
			$post_author_id = get_post_field('post_author', $post_id);
			$user = get_userdata($post_author_id);
			$author_name = $user ? $user->display_name : get_bloginfo('name');
		}

		$question_data['author'] = array(
			'@type' => 'Person',
			'name'  => esc_html($author_name),
			'url'   => home_url(),
		);
		$source_url              = get_post_meta($post_id, 'mcq_source_url', true);
		$source_name             = get_post_meta($post_id, 'mcq_source_name', true);
		if (! empty($source_url) && ! empty($source_name)) {
			$question_data['isBasedOn'] = array(
				'@type' => 'CreativeWork',
				'name'  => esc_html($source_name),
				'url'   => esc_url($source_url),
			);
		}
		$fact_checked = get_post_meta($post_id, 'mcq_fact_checked', true);
		if ($fact_checked === 'yes') {
			$question_data['reviewedBy'] = array(
				'@type' => 'Organization',
				'name'  => get_bloginfo('name'),
			);
		}
		$difficulty = get_post_meta($post_id, 'mcq_difficulty', true);
		if (! empty($difficulty)) {
			$question_data['comment'] = array(
				'@type' => 'Comment',
				'text'  => 'Difficulty: ' . ucfirst(esc_html($difficulty)),
			);
		}

		// ✅ NEW v7.3.7: Add Exam Tags to Schema Keywords
		$exam_tags = wp_get_post_terms($post_id, 'nm_exam', array('fields' => 'names'));
		if (! empty($exam_tags) && ! is_wp_error($exam_tags)) {
			$question_data['keywords'] = implode(', ', $exam_tags);
		}

		$data['Quiz'] = array(
			'@type'            => 'Quiz',
			'@id'              => get_permalink($post_id) . '#quiz',
			'name'             => esc_html($custom_title),
			'description'      => 'Test your knowledge with this ' . esc_html($topic_name) . ' quiz question',
			'about'            => array(
				'@type' => 'Thing',
				'name'  => esc_html($topic_name),
			),
			'educationalLevel' => 'Competitive Exam Preparation',
			'typicalAgeRange'  => '18-35',
			'hasPart'          => array($question_data),
		);
		return $data;
	}

	/**
	 * ✅ NEW v7.3.7: Render Aesthetic E-A-T Attribution Box
	 * Displays Author, Source, Fact-Checked status, and Difficulty
	 */
	public static function nm_display_mcq_attribution($post_id)
	{
		$author_name    = get_post_meta($post_id, 'mcq_author_name', true);
		$source_name    = get_post_meta($post_id, 'mcq_source_name', true);
		$source_url     = get_post_meta($post_id, 'mcq_source_url', true);
		$fact_checked   = get_post_meta($post_id, 'mcq_fact_checked', true);
		$difficulty     = get_post_meta($post_id, 'mcq_difficulty', true);
		$published_date = get_the_date('d M Y', $post_id);
		$modified_date  = get_the_modified_date('d M Y', $post_id);

		// ✅ MODIFIED v9.0.3: Dynamic fallback for E-A-T compliance
		if (empty($author_name)) {
			$post_author_id = get_post_field('post_author', $post_id);
			$user           = get_userdata($post_author_id);
			$author_name    = $user ? $user->display_name : get_bloginfo('name');
		}

		// Date Logic: Show "Last Updated" if modified > 24h after publish
		$date_label   = 'Published';
		$date_display = $published_date;
		if (strtotime($modified_date) > strtotime($published_date) + 86400) {
			$date_label   = 'Last Updated';
			$date_display = $modified_date;
		}

	?>
		<div class="nm-eat-box">
			<div class="nm-eat-item nm-eat-author">
				<?php
				// @NEW 9.2.0: Real-author vibe — show the author's avatar (local/Gravatar/initials).
				$author_id = get_post_field('post_author', $post_id);
				if ($author_id && class_exists('NM_News_Article_Generator') && method_exists('NM_News_Article_Generator', 'get_author_avatar_url')) {
					$avatar_url = NM_News_Article_Generator::get_author_avatar_url($author_id, 48);
					echo '<span class="nm-eat-avatar"><img src="' . esc_url($avatar_url) . '" alt="' . esc_attr($author_name) . '" width="48" height="48" loading="lazy" style="border-radius:50%;vertical-align:middle;margin-right:8px;width:48px;height:48px;object-fit:cover;"></span>';
				}
				?>
				<div class="nm-eat-content">
					<span class="nm-eat-label">By</span>
					<span class="nm-eat-value"><?php echo esc_html($author_name); ?></span>
				</div>
			</div>

			<?php if (! empty($source_name)) : ?>
				<div class="nm-eat-item nm-eat-source">
					<span class="nm-eat-icon">🌐</span>
					<div class="nm-eat-content">
						<span class="nm-eat-label">Source</span>
						<span class="nm-eat-value">
							<?php
							// SEO Strategy: Text only, no external link
							echo esc_html($source_name);
							?>
						</span>
					</div>
				</div>
			<?php endif; ?>

			<div class="nm-eat-item nm-eat-fact-checked">
				<span class="nm-eat-icon">✅</span>
				<div class="nm-eat-content">
					<span class="nm-eat-label">Fact Checked</span>
				</div>
			</div>

			<?php if (! empty($difficulty)) : ?>
				<div class="nm-eat-item nm-eat-difficulty">
					<span class="nm-eat-icon">📊</span>
					<div class="nm-eat-content">
						<span class="nm-eat-label">Difficulty</span>
						<span class="nm-eat-value"><?php echo ucfirst(esc_html($difficulty)); ?></span>
					</div>
				</div>
			<?php endif; ?>

			<div class="nm-eat-item nm-eat-date">
				<span class="nm-eat-icon">📅</span>
				<div class="nm-eat-content">
					<span class="nm-eat-label"><?php echo esc_html($date_label); ?></span>
					<span class="nm-eat-value"><?php echo esc_html($date_display); ?></span>
				</div>
			</div>
		</div>
<?php
	}
	private static function nm_handle_topic_archive_schema($data, $jsonld)
	{
		if (isset($data['Article'])) {
			unset($data['Article']);
		}
		if (isset($data['WebPage'])) {
			unset($data['WebPage']);
		}
		$current_topic = get_queried_object();
		if (! $current_topic || ! isset($current_topic->name)) {
			return $data;
		}
		if (! class_exists('NM_AJAX_Frontend') || ! method_exists('NM_AJAX_Frontend', 'nm_get_mcqs')) {
			return $data;
		}
		$initial_mcqs = NM_AJAX_Frontend::nm_get_mcqs(
			array(
				'count' => 10,
				'topic' => $current_topic->slug,
			)
		);
		if (empty($initial_mcqs)) {
			return $data;
		}
		$question_list = array();
		foreach ($initial_mcqs as $mcq) {
			$question_data = self::nm_build_question_from_mcq_data($mcq, $current_topic->name);
			if ($question_data) {
				$question_list[] = $question_data;
			}
		}
		if (empty($question_list)) {
			return $data;
		}
		$quiz_schema = array(
			'@type'            => 'Quiz',
			'@id'              => get_term_link($current_topic) . '#quiz',
			'name'             => esc_html($current_topic->name) . ' MCQs Quiz',
			'description'      => $current_topic->description ?: 'Practice questions for ' . esc_html($current_topic->name),
			'educationalLevel' => 'Competitive Exam Preparation',
			'typicalAgeRange'  => '18-35',
			'about'            => array(
				'@type' => 'Thing',
				'name'  => esc_html($current_topic->name),
			),
			'hasPart'          => $question_list,
		);
		$faq_schema  = array(
			'@type'      => 'FAQPage',
			'@id'        => get_term_link($current_topic) . '#faq',
			'mainEntity' => array(
				array(
					'@type'          => 'Question',
					'name'           => 'How often are the ' . esc_html($current_topic->name) . ' MCQs updated?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Our quiz is updated multiple times daily with new questions from current events.',
					),
				),
				array(
					'@type'          => 'Question',
					'name'           => 'Where are these ' . esc_html($current_topic->name) . ' questions sourced from?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Questions are curated from reputable news outlets, focusing on factual information relevant for competitive exams.',
					),
				),
				array(
					'@type'          => 'Question',
					'name'           => 'Can I practice ' . esc_html($current_topic->name) . ' MCQs on mobile devices?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Absolutely! Our platform is fully responsive and works seamlessly on all devices.',
					),
				),
			),
		);
		$args        = array(
			'post_type'      => 'mcq',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'tax_query'      => array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'term_id',
					'terms'    => $current_topic->term_id,
				),
			),
		);
		$query       = new WP_Query($args);
		$total_mcqs  = $query->found_posts;
		wp_reset_postdata();
		$description = $current_topic->description;
		if (! empty($description)) {
			$description = preg_replace('/<\/?h[1-6][^>]*>/', '', $description);
			$description = wp_kses_post($description);
			$description = trim($description);
		}
		if (empty($description)) {
			$description = 'Test your knowledge with our comprehensive collection of ' . esc_html($current_topic->name) . ' questions. Practice ' . $total_mcqs . ' MCQs updated daily from current affairs and news.';
		}
		$data['CollectionPage'] = array(
			'@type'         => 'CollectionPage',
			'@id'           => get_term_link($current_topic) . '#webpage',
			'name'          => esc_html($current_topic->name) . ' MCQs',
			'description'   => $description,
			'url'           => get_term_link($current_topic),
			'inLanguage'    => 'en-US',
			'isPartOf'      => array(
				'@type' => 'WebSite',
				'@id'   => home_url('/') . '#website',
				'name'  => get_bloginfo('name'),
				'url'   => home_url('/'),
			),
			'about'         => array(
				'@type' => 'Thing',
				'name'  => esc_html($current_topic->name),
			),
			'numberOfItems' => $total_mcqs,
			'hasPart'       => array($quiz_schema, $faq_schema),
			'mainEntity'    => array('@id' => get_term_link($current_topic) . '#quiz'),
		);
		return $data;
	}
	private static function nm_handle_homepage_schema($data, $jsonld)
	{
		if (isset($data['Article'])) {
			unset($data['Article']);
		}
		if (! class_exists('NM_AJAX_Frontend') || ! method_exists('NM_AJAX_Frontend', 'nm_get_mcqs')) {
			return $data;
		}
		// @FIX 9.3.2 (SEO): Trim the homepage Quiz schema to the TOP 5 questions instead
		// of 10. Embedding 10 full Q&A blocks bloats the JSON-LD and risks being treated
		// as keyword-stuffed/ignored by Google. A 5-question representative Quiz keeps the
		// rich entity (better than ItemList for an interactive quiz page) while staying
		// lean. The FAQPage block is kept — it's valuable for People-Also-Ask and AI engines.
		$initial_mcqs = NM_AJAX_Frontend::nm_get_mcqs(
			array(
				'count' => 5,
				'topic' => '',
			)
		);
		if (empty($initial_mcqs)) {
			return $data;
		}
		$question_list = array();
		foreach ($initial_mcqs as $mcq) {
			$question_data = self::nm_build_question_from_mcq_data($mcq, 'General Knowledge');
			if ($question_data) {
				$question_list[] = $question_data;
			}
		}
		if (empty($question_list)) {
			return $data;
		}
		$page_title      = self::nm_get_current_page_title();
		$current_url     = is_front_page() ? home_url('/') : get_permalink();
		$quiz_schema     = array(
			'@type'            => 'Quiz',
			'@id'              => $current_url . '#quiz',
			'name'             => esc_html($page_title) . ' - Daily MCQs Quiz',
			'description'      => 'Practice multiple choice questions for competitive exams covering various topics including current affairs, updated daily',
			'educationalLevel' => 'Competitive Exam Preparation',
			'typicalAgeRange'  => '18-35',
			'about'            => array(
				'@type' => 'Thing',
				'name'  => 'General Knowledge and Current Affairs',
			),
			'hasPart'          => $question_list,
		);
		$faq_schema      = array(
			'@type'      => 'FAQPage',
			'@id'        => $current_url . '#faq',
			'mainEntity' => array(
				array(
					'@type'          => 'Question',
					'name'           => 'How often are the MCQs updated?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Our quiz is updated multiple times daily with new questions from current events and latest news.',
					),
				),
				array(
					'@type'          => 'Question',
					'name'           => 'Where are these questions sourced from?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Questions are curated from reputable news outlets, focusing on factual information relevant for competitive exams like CSS, PMS, NTS, FPSC, and PPSC.',
					),
				),
				array(
					'@type'          => 'Question',
					'name'           => 'Can I practice on mobile devices?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Absolutely! Our platform is fully responsive and works seamlessly on all devices including smartphones, tablets, and desktops.',
					),
				),
				array(
					'@type'          => 'Question',
					'name'           => 'Are the MCQs free to practice?',
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => 'Yes! All our quizzes and MCQs are completely free to access and practice anytime, anywhere.',
					),
				),
			),
		);
		$data['WebPage'] = array(
			'@type'       => 'WebPage',
			'@id'         => $current_url . '#webpage',
			'name'        => esc_html($page_title),
			'description' => 'Practice free MCQs and quizzes for competitive exams. Daily updated questions covering current affairs, general knowledge, and exam preparation.',
			'url'         => $current_url,
			'inLanguage'  => 'en-US',
			'isPartOf'    => array(
				'@type' => 'WebSite',
				'@id'   => home_url('/') . '#website',
				'name'  => get_bloginfo('name'),
				'url'   => home_url('/'),
			),
			'hasPart'     => array($quiz_schema, $faq_schema),
			'mainEntity'  => array('@id' => $current_url . '#quiz'),
		);
		return $data;
	}
	private static function nm_build_question_from_mcq_data($mcq, $topic_name)
	{
		if (! isset($mcq['options']) || ! is_array($mcq['options']) || empty($mcq['answer'])) {
			return null;
		}
		$suggested_answers = array();
		$accepted_answer   = null;
		$position          = 0;
		foreach ($mcq['options'] as $option_key => $option_text) {
			$is_correct    = ($option_key === $mcq['answer']);
			$answer_object = array(
				'@type'          => 'Answer',
				'text'           => esc_html($option_text),
				'encodingFormat' => 'text/html',
				'position'       => $position,
			);
			if ($is_correct) {
				$answer_object['comment'] = array(
					'@type' => 'Comment',
					'text'  => 'This is the correct answer.',
				);
				if (! empty($mcq['explanation'])) {
					$answer_object['answerExplanation'] = array(
						'@type' => 'Comment',
						'text'  => esc_html($mcq['explanation']),
					);
				}
				$accepted_answer = $answer_object;
			} else {
				$answer_object['comment'] = array(
					'@type' => 'Comment',
					'text'  => 'Consider the question carefully.',
				);
				$suggested_answers[]      = $answer_object;
			}
			++$position;
		}
		if ($accepted_answer === null) {
			$accepted_answer = array(
				'@type'          => 'Answer',
				'text'           => 'Answer not available',
				'encodingFormat' => 'text/html',
				'position'       => 0,
			);
		}
		$post_id = isset($mcq['id']) ? $mcq['id'] : 0;
		$author_name = '';
		if ($post_id) {
			$author_name = get_post_meta($post_id, 'mcq_author_name', true);
			if (empty($author_name)) {
				$post_author_id = get_post_field('post_author', $post_id);
				$author_user = get_userdata($post_author_id);
				$author_name = $author_user ? $author_user->display_name : get_bloginfo('name');
			}
		}

		$question_data = array(
			'@type'                => 'Question',
			'name'                 => esc_html($mcq['question']),
			'text'                 => esc_html($mcq['question']),
			'encodingFormat'       => 'text/html',
			'eduQuestionType'      => 'Multiple choice',
			'learningResourceType' => 'Practice problem',
			'educationalLevel'     => 'Competitive Exam Preparation',
			'typicalAgeRange'      => '18-35',
			'assesses'             => esc_html($topic_name) . ' knowledge',
			'acceptedAnswer'       => $accepted_answer,
			'suggestedAnswer'      => $suggested_answers,
			'educationalAlignment' => array(
				'@type'         => 'AlignmentObject',
				'alignmentType' => 'educationalSubject',
				'targetName'    => esc_html($topic_name),
			),
		);

		if (!empty($author_name)) {
			$question_data['author'] = array(
				'@type' => 'Person',
				'name'  => esc_html($author_name),
			);
		}

		return $question_data;
	}
	private static function nm_is_shortcode_page()
	{
		if (! empty($GLOBALS['nm_has_mcq_shortcode'])) {
			return true;
		}
		global $post;
		if (is_home() && ! is_front_page()) {
			$page_id = get_option('page_for_posts');
			if ($page_id) {
				$post_content = get_post_field('post_content', $page_id);
				return has_shortcode($post_content, 'display_mcqs');
			}
		} elseif (is_front_page() && get_option('show_on_front') === 'page') {
			$page_id = get_option('page_on_front');
			if ($page_id) {
				$post_content = get_post_field('post_content', $page_id);
				return has_shortcode($post_content, 'display_mcqs');
			}
		} elseif (is_page() && isset($post->post_content)) {
			return has_shortcode($post->post_content, 'display_mcqs');
		}
		return false;
	}
	private static function nm_get_current_page_title()
	{
		if (is_front_page() && get_option('show_on_front') === 'page') {
			$page_id = get_option('page_on_front');
			$title   = get_the_title($page_id);
			return ! empty($title) ? $title : get_bloginfo('name');
		} elseif (is_home() && ! is_front_page()) {
			$page_id = get_option('page_for_posts');
			return $page_id ? get_the_title($page_id) : get_bloginfo('name');
		} else {
			$title = get_the_title();
			return ! empty($title) ? $title : get_bloginfo('name');
		}
	}
}
?>
