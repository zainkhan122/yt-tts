<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BufferIntegration {

    const API_BASE = 'https://api.buffer.com';

    const MAX_RETRY_ATTEMPTS     = 3;
    const RETRY_BASE_DELAY_US    = 2000000;
    const INTER_REQUEST_DELAY_US = 1500000;

    const SCHEDULED_POSTS_LIMIT   = 10;   // Buffer free-plan queue capacity per channel
    const SCHEDULED_SNAPSHOT_TTL  = 300;  // seconds — cached until next error or success
    const PENDING_RETRY_GRACE_SEC   = 300;  // retry N seconds after the slot frees
    const PENDING_SHARES_MAX       = 200;
    const PENDING_MAX_RETRY_ATTEMPTS         = 2;  // cap for transient/hard errors (network, 4xx, etc.)
    const PENDING_MAX_RETRY_ATTEMPTS_QUEUE   = 5;  // cap for queue-full (Buffer's "10 scheduled" cap is rate-driven, not a fault)

    private static $queue_retry_depth = 0;

    /**
     * In-process blacklist of Buffer post ids whose editPost(shareNow) was rejected
     * by Buffer-side validation ("Invalid post: Post must have either text or media.,
     * Facebook posts require a type"). Retrying the same broken id within the same
     * request cycle only produces identical warnings and never frees a queue slot.
     * Keyed by account_id so multi-account setups don't bleed.
     *
     * @var array<string, array<string, true>>
     */
    private static $unshareable_buffer_post_ids = [];

    private static function token_for( string $account_id ): string {
        return Config::get_buffer_account_token( $account_id );
    }

    private static function cache_key( string $suffix, string $account_id ): string {
        return $suffix . '_' . $account_id;
    }

    public static function share( int $post_id, int $attachment_id = 0, string $only_account_id = '' ): bool {
        if ( ! Config::is_buffer_enabled() ) {
            Logger::debug( 'buffer_disabled', null, [ 'post_id' => $post_id ] );
            return false;
        }

        $accounts = Config::get_active_buffer_accounts();
        if ( empty( $accounts ) ) {
            if ( $only_account_id !== '' && $only_account_id !== 'default' ) {
                return false;
            }
            return self::share_to_account( $post_id, $attachment_id, 'default' );
        }

        $shared_any = false;
        foreach ( $accounts as $acct_id => $acct ) {
            if ( $only_account_id !== '' && $acct_id !== $only_account_id ) {
                continue;
            }
            if ( Config::buffer_account_daily_limit_reached( $acct_id ) ) {
                Logger::warning( 'buffer_account_daily_limit', null, [
                    'post_id' => $post_id,
                    'account_id' => $acct_id,
                ] );
                continue;
            }
            if ( self::share_to_account( $post_id, $attachment_id, $acct_id ) ) {
                $shared_any = true;
            }
        }
        return $shared_any;
    }

    private static function share_to_account( int $post_id, int $attachment_id, string $account_id ): bool {
        $token = self::token_for( $account_id );

        $post = get_post( $post_id );
        if ( ! $post ) {
            Logger::warning( 'buffer_post_not_found', null, [ 'post_id' => $post_id ] );
            return false;
        }

        $channels = Config::get_buffer_account_channels( $account_id );
        $share_mode = Config::get_buffer_account_share_mode( $account_id );

        // Draft/Idea-mode posts do not require the WP post to be published yet.
        // YouTube channels follow the same account Share Mode as every other channel.
        $publish_required = ! in_array( $share_mode, [ 'draft', 'ideas' ], true );

        if ( $publish_required && $post->post_status !== 'publish' ) {
            Logger::debug( 'buffer_skipping_unpublished', null, [
                'post_id' => $post_id,
                'post_status' => $post->post_status,
                'share_mode' => $share_mode,
            ] );
            return false;
        }

        if ( $share_mode !== 'ideas' && empty( $channels ) ) {
            Logger::warning( 'buffer_no_channels', null, [ 'post_id' => $post_id ] );
            return false;
        }

        if ( $share_mode !== 'ideas' ) {
            $cached_channels = get_option( self::cache_key( 'ai_collage_buffer_channels_cache', $account_id ) );
            if ( ! is_array( $cached_channels ) || empty( $cached_channels ) ) {
                self::get_channels( $account_id );
            }
        }

        // AUDIT F1: Deduplication must happen inside the per-channel loop, AFTER
        // detect_service() has resolved the service for the current channel. A
        // pre-loop filter (as it was written) captured an undefined $service
        // variable and compared every key against the empty service suffix, so
        // it never matched any record produced by record_share() (which always
        // writes the resolved service). Net effect: every retry re-shared the
        // post to every channel. The dedup is now correctly applied below in
        // the foreach, immediately after $service is known.
        $is_video = self::is_video_attachment( $attachment_id );
        // Use loose comparison (==) instead of strict (===) because some older
        // ingests via sideload_featured_image may store the meta value as integer 1
        // instead of string '1'. MySQL meta_query finds it via type coercion, but
        // PHP strict comparison would reject it, causing Buffer sharing to silently
        // fail after a successful R2 upload.
        $is_ai_reel = $is_video && $attachment_id > 0 && get_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, true ) == '1';

        // For video content: NEVER fall back to local/source URLs. Only share the
        // AI-generated reel's R2 URL. If R2 upload hasn't completed, skip sharing
        // entirely (Buffer should never see the raw source video).
        if ( $is_video ) {
            if ( ! $is_ai_reel ) {
                Logger::warning( 'buffer_skipping_non_ai_video', null, [
                    'post_id' => $post_id,
                    'attachment_id' => $attachment_id,
                    'reason' => 'Attachment is a video but is NOT the AI-generated reel (META_IS_AI_COLLAGE != 1). Refusing to share source video.',
                ], '500', 'Refusing to share non-AI-collage video on Buffer.' );
                return false;
            }

            // Priority 1: attachment meta (set by VideoRenderer::maybe_upload_to_r2)
            $r2_url = $attachment_id > 0 ? get_post_meta( $attachment_id, '_ai_collage_r2_url', true ) : '';
            if ( ! empty( $r2_url ) ) {
                $image_url = $r2_url;
                Logger::debug( 'buffer_using_r2_url', null, [
                    'post_id' => $post_id,
                    'attachment_id' => $attachment_id,
                    'r2_url' => $r2_url,
                ], '200' );
            } else {
                // Priority 2: job table video_url (set after R2 upload)
                global $wpdb;
                $jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
                $job = $wpdb->get_row( $wpdb->prepare(
                    "SELECT video_url FROM $jobs_table WHERE post_id = %d AND video_url IS NOT NULL AND video_url != '' ORDER BY id DESC LIMIT 1",
                    $post_id
                ) );
                if ( $job && ! empty( $job->video_url ) ) {
                    $image_url = $job->video_url;
                    Logger::debug( 'buffer_using_job_video_url', null, [
                        'post_id' => $post_id,
                        'video_url' => $job->video_url,
                    ], '200' );
                } else {
                    // No R2 URL available — refuse to share. NEVER fall back to
                    // local attachment URL for video posts.
                    Logger::error( 'buffer_skipping_video_no_r2_url', null, [
                        'post_id' => $post_id,
                        'attachment_id' => $attachment_id,
                        'reason' => 'AI reel has no R2 URL (upload pending or failed). Buffer sharing skipped to prevent source video leak.',
                    ], '500', 'Video post has no R2 URL; refusing to share local attachment URL.' );
                    return false;
                }
            }
        } elseif ( $attachment_id > 0 ) {
            // Image content — use local attachment URL
            $image_url = wp_get_attachment_url( $attachment_id ) ?: '';
        }

        $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
        $auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

        $headline = $auto_meta['ai_headline'] ?? '';
        if ( empty( $headline ) ) {
            $headline = get_post_field( 'post_title', $post_id );
        }

        $description = $auto_meta['ai_detailed_description'] ?? $auto_meta['ai_hook'] ?? '';
        if ( empty( $description ) ) {
            $description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30, '…' );
        }

        $x_content = $auto_meta['x_content'] ?? '';
		$x_hashtags = '';
		if ( ! empty( $auto_meta['ai_x_hashtags'] ) && is_array( $auto_meta['ai_x_hashtags'] ) ) {
			$x_hashtags = implode( ' ', array_slice( $auto_meta['ai_x_hashtags'], 0, 5 ) );
		}
		$x_description = $auto_meta['ai_x_description'] ?? '';

		$mentions = '';
		if ( ! empty( $auto_meta['ai_mentions'] ) && is_array( $auto_meta['ai_mentions'] ) ) {
			$mentions = implode( ' ', array_slice( $auto_meta['ai_mentions'], 0, 10 ) );
		}

		// ── YT placeholders ────────────────────────────────────────────────
		// The AI already produces a YouTube Shorts title and description for every
		// job: ContentRewriter asks for yt_title / yt_description and
		// validate_rewrite_json() keeps them, so they land in post meta as
		// ai_yt_title / ai_yt_description. Until now they were only reachable from
		// the YouTube channel branch. Surface them here so {yt_title} and
		// {yt_description} work in ANY Buffer template — global, per-channel and
		// story captions.
		$yt_title = '';
		if ( ! empty( $auto_meta['ai_yt_title'] ) ) {
			$yt_title = is_array( $auto_meta['ai_yt_title'] )
				? implode( ' ', $auto_meta['ai_yt_title'] )
				: (string) $auto_meta['ai_yt_title'];
		}

		$yt_description = '';
		if ( ! empty( $auto_meta['ai_yt_description'] ) ) {
			$raw = is_array( $auto_meta['ai_yt_description'] )
				? implode( "\n", $auto_meta['ai_yt_description'] )
				: (string) $auto_meta['ai_yt_description'];
			$yt_description = self::format_yt_description( $raw );
		}

        $default_hashtags = self::get_hashtags( $post_id );
        if ( ! empty( $default_hashtags ) && stripos( $default_hashtags, '#Shorts' ) === false ) {
            $default_hashtags = '#Shorts ' . $default_hashtags;
        }
        $post_url = Config::is_buffer_account_link_disabled( $account_id ) ? '' : get_permalink( $post_id );

        $channel_templates = Config::get_buffer_account_channel_templates( $account_id );
        $channel_types = Config::get_buffer_account_channel_types( $account_id );
        $link_posts = Config::get_buffer_account_link_posts( $account_id );
        $channel_hashtags = Config::get_buffer_account_channel_hashtags( $account_id );
        $channel_story_templates = Config::get_buffer_account_channel_story_templates( $account_id );

        $shared_count = 0;

        if ( $share_mode === 'ideas' ) {
            $norm_headline = self::normalize_text( $headline );
            $norm_description = self::normalize_text( $description );
            $result = self::create_idea( $norm_headline, $norm_description, $default_hashtags, $account_id );
            if ( $result['success'] ) {
                $shared_count++;
                self::record_share( $post_id, 'idea', 'organization', '', 'ideas', $account_id );
                Logger::info( Config::LOG_ACTION_BUFFER_SHARE, null, [
                    'post_id' => $post_id,
                    'mode' => 'ideas',
                    'account_id' => $account_id,
                ], '200', 'Created Buffer Idea for post ' . $post_id . ' via account ' . $account_id );
            } else {
                Logger::warning( 'buffer_idea_failed', null, [
                    'post_id' => $post_id,
                    'error' => $result['error'] ?? 'Unknown error',
                ] );
            }
        } else {
            $batch_jobs = [];
            $channel_count = count( $channels );
            Logger::debug( 'buffer_channel_loop_start', null, [
                'post_id' => $post_id,
                'account_id' => $account_id,
                'channel_count' => $channel_count,
                'is_video' => $is_video,
                'channels' => array_values( $channels ),
            ] );

            foreach ( $channels as $channel_id ) {
                if ( ! is_string( $channel_id ) || empty( $channel_id ) ) {
                    Logger::debug( 'buffer_channel_skipped_invalid', null, [
                        'post_id' => $post_id,
                        'channel_id' => $channel_id ?? 'null',
                    ] );
                    continue;
                }

                $service = self::detect_service( $channel_id, $account_id );

                Logger::debug( 'buffer_channel_detected', null, [
                    'post_id' => $post_id,
                    'channel_id' => $channel_id,
                    'service' => $service,
                ] );

                if ( $service === 'tiktok' && Config::buffer_account_tiktok_daily_limit_reached( $account_id ) ) {
                    Logger::warning( 'buffer_tiktok_daily_limit', null, [
                        'post_id' => $post_id,
                        'account_id' => $account_id,
                        'channel_id' => $channel_id,
                    ] );
                    continue;
                }

                // YouTube channels follow the account-level share mode; only
                // Idea mode is meaningless for YouTube (ideas are account-level
                // text backlogs, not per-channel video posts).
                $channel_share_mode = $share_mode;
                if ( $service === 'youtube' ) {
                    if ( ! $is_video ) {
                        // Buffer YouTube channels only accept video posts; a
                        // text/image post would be rejected by Buffer with a
                        // validation error. Skip instead of erroring.
                        Logger::debug( 'buffer_youtube_skipped_non_video', null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                            'account_id' => $account_id,
                        ] );
                        continue;
                    }
                    if ( $channel_share_mode === 'ideas' ) {
                        // Buffer Ideas are account-level text backlogs, not
                        // per-channel video posts — meaningless for YouTube.
                        Logger::debug( 'buffer_youtube_ideas_skipped', null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                            'account_id' => $account_id,
                        ] );
                        continue;
                    }
                }

                if ( ! in_array( $channel_share_mode, [ 'draft', 'ideas' ], true ) && $post->post_status !== 'publish' ) {
                    Logger::debug( 'buffer_channel_skipping_unpublished', null, [
                        'post_id' => $post_id,
                        'channel_id' => $channel_id,
                        'service' => $service,
                        'share_mode' => $channel_share_mode,
                    ] );
                    continue;
                }

                $active_hashtags = ! empty( $channel_hashtags[ $channel_id ] ) ? $channel_hashtags[ $channel_id ] : $default_hashtags;

                $channel_desc = ( $service === 'twitter' && ! empty( $x_content ) ) ? $x_content : $description;

				if ( $service === 'youtube' && ! empty( $auto_meta['ai_yt_description'] ) ) {
					$channel_desc = self::format_yt_description( $auto_meta['ai_yt_description'] );
				}

$template = $channel_templates[ $channel_id ] ?? '';
				if ( ! empty( $template ) ) {
					$text = self::compile_template( $template, $headline, $channel_desc, $active_hashtags, $post_url, $x_hashtags, $x_description, $mentions, $yt_title, $yt_description, $x_content );
				} else {
					$text = self::compile_template( Config::get_buffer_account_global_template( $account_id ), $headline, $channel_desc, $active_hashtags, $post_url, $x_hashtags, $x_description, $mentions, $yt_title, $yt_description, $x_content );
				}

                $text = self::normalize_text( $text );
                $configured_type = self::validate_post_type( $service, $channel_types[ $channel_id ] ?? 'post' );
                $post_type = self::resolve_post_type_for_content( $service, $configured_type, $is_video );

                Logger::debug( 'buffer_channel_post_type', null, [
                    'post_id' => $post_id,
                    'channel_id' => $channel_id,
                    'service' => $service,
                    'configured_type' => $configured_type,
                    'resolved_type' => $post_type,
                    'is_video' => $is_video,
                ] );

                if ( $service === 'instagram' && empty( $image_url ) ) {
                    Logger::warning( 'buffer_instagram_no_image', null, [
                        'post_id' => $post_id,
                        'channel_id' => $channel_id,
                    ] );
                    continue;
                }

                if ( $service === 'pinterest' ) {
                    $boards = Config::get_buffer_account_pinterest_boards( $account_id );
                    if ( empty( $boards[ $channel_id ] ?? '' ) ) {
                        Logger::warning( 'buffer_pinterest_no_board', null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                        ] );
                        continue;
                    }
                }

                $text = self::adapt_text_for_service( $text, $service, $post_type );
                $metadata = self::build_metadata( $service, $post_type, $link_posts, $channel_id, $post_url, $post_id, $account_id );
                $should_share_story = Config::should_buffer_account_share_to_story( $account_id, $channel_id ) && in_array( $service, [ 'instagram', 'facebook' ], true );

                $batch_jobs[] = [
                    'alias'      => 'c_' . md5( $channel_id . '_post' ),
                    'post_id'    => $post_id,
                    'channel_id' => $channel_id,
                    'text'       => $text,
                    'image_url'  => $image_url,
                    'metadata'   => $metadata,
                    'service'    => $service,
                    'is_story'   => false,
                    'is_video'   => $is_video,
                    'post_type'  => $post_type,
                    'share_mode' => $channel_share_mode,
                ];

                Logger::debug( 'buffer_channel_batch_added', null, [
                    'post_id' => $post_id,
                    'channel_id' => $channel_id,
                    'service' => $service,
                    'post_type' => $post_type,
                    'has_media' => ! empty( $image_url ),
                    'is_video' => $is_video,
                ] );

                if ( $should_share_story && ! empty( $image_url ) ) {
                    $story_metadata = self::build_metadata( $service, 'story', $link_posts, $channel_id, $post_url, $post_id, $account_id );
                    $story_template = $channel_story_templates[ $channel_id ] ?? '';
					if ( ! empty( $story_template ) ) {
						$story_text = self::compile_template( $story_template, $headline, $channel_desc, $active_hashtags, $post_url, $x_hashtags, $x_description, $mentions, $yt_title, $yt_description, $x_content );
						$story_text = self::normalize_text( $story_text );
					} else {
						$story_text = $text;
					}
                    $story_text = self::adapt_text_for_service( $story_text, $service, 'story' );
                    $batch_jobs[] = [
                        'alias'      => 's_' . md5( $channel_id . '_story' ),
                        'post_id'    => $post_id,
                        'channel_id' => $channel_id,
                        'text'       => $story_text,
                        'image_url'  => $image_url,
                        'metadata'   => $story_metadata,
                        'service'    => $service,
                        'is_story'   => true,
                        'is_video'   => $is_video,
                        'post_type'  => 'story',
                        'share_mode' => $channel_share_mode,
                    ];
                }
            }

            if ( ! empty( $batch_jobs ) ) {
                // AUDIT F1: per-(channel, service, is_story) dedup against
                // META_BUFFER_SHARE_HISTORY. record_share() writes
                // `channel_id . '_story'` for story shares and the raw
                // channel_id for feed posts, so a successful feed post does
                // NOT block the story share (and vice versa). This runs after
                // the foreach so is_story is known for every job. Jobs that
                // were already shared are dropped from the batch — they are
                // not re-sent to Buffer. Channel-level dedup would be too
                // coarse for IG/FB post+story pairs, since a feed-post
                // success would otherwise block a pending story retry.
                $share_history = get_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, true );
                if ( is_array( $share_history ) && ! empty( $share_history ) ) {
                    $already_shared = [];
                    foreach ( $share_history as $entry ) {
                        if ( ! isset( $entry['channel_id'], $entry['service'] ) ) {
                            continue;
                        }
                        $recorded_channel = (string) $entry['channel_id'];
                        $recorded_service = (string) $entry['service'];
                        $is_story_recorded = str_ends_with( $recorded_channel, '_story' );
                        $base_channel = $is_story_recorded ? substr( $recorded_channel, 0, -6 ) : $recorded_channel;
                        $key = $base_channel . '|' . $recorded_service . '|' . ( $is_story_recorded ? '1' : '0' );
                        $already_shared[ $key ] = true;
                    }

                    $batch_jobs = array_values( array_filter( $batch_jobs, function ( $job ) use ( $already_shared, $post_id ) {
                        $is_story = ! empty( $job['is_story'] );
                        $key = $job['channel_id'] . '|' . $job['service'] . '|' . ( $is_story ? '1' : '0' );
                        if ( isset( $already_shared[ $key ] ) ) {
                            Logger::debug( 'buffer_channel_already_shared', null, [
                                'post_id'    => $post_id,
                                'channel_id' => $job['channel_id'],
                                'service'    => $job['service'],
                                'is_story'   => $is_story,
                            ] );
                            return false;
                        }
                        return true;
                    } ) );

                    if ( empty( $batch_jobs ) ) {
                        Logger::debug( 'buffer_no_batch_jobs_after_dedup', null, [
                            'post_id' => $post_id,
                            'account_id' => $account_id,
                        ] );
                    }
                }

                if ( empty( $batch_jobs ) ) {
                    // Nothing left to send — the dedup cleared every job.
                    Logger::debug( 'buffer_share_summary', null, [
                        'post_id' => $post_id,
                        'account_id' => $account_id,
                        'shared_count' => 0,
                        'is_video' => $is_video,
                        'note' => 'all_channels_already_shared',
                    ] );
                    return $shared_count > 0;
                }

                $batch_results = self::create_batched_posts( $batch_jobs, $share_mode, $account_id );

                foreach ( $batch_jobs as $job ) {
                    $alias = $job['alias'];
                    $channel_id = $job['channel_id'];
                    $service = $job['service'];
                    $is_story = $job['is_story'];
                    $result = $batch_results[ $alias ] ?? [ 'success' => false, 'error' => 'No result returned from batch' ];

                    if ( $result['success'] ) {
                        $shared_count++;
                        $buffer_post_id = $result['post_id'] ?? '';
                        $effective_mode = $job['share_mode'] ?? $share_mode;
                        $mode_recorded = $is_story ? $effective_mode . '_story' : $effective_mode;
                        $channel_recorded = $is_story ? $channel_id . '_story' : $channel_id;
                        $log_msg = 'Shared to ' . $service . ( $is_story ? ' STORY' : '' ) . ' (' . trim( self::channel_name( $channel_id, $account_id ) . ' ' . $channel_id ) . ', mode: ' . $mode_recorded . ')';

                        Logger::debug( 'buffer_share_result', null, [
                            'post_id' => $post_id,
                            'buffer_post_id' => $buffer_post_id,
                            'share_mode' => $mode_recorded,
                            'due_at' => $result['due_at'] ?? '',
                        ] );

                        self::record_share( $post_id, $channel_recorded, $service, $result['due_at'] ?? '', $mode_recorded, $buffer_post_id, $account_id );

                        if ( $service === 'tiktok' ) {
                            Config::increment_buffer_account_tiktok_tracker( $account_id, $post_id );
                        }

                        Logger::info( Config::LOG_ACTION_BUFFER_SHARE, null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                            'service' => $service,
                            'mode' => $mode_recorded,
                        ], '200', $log_msg );

                    } elseif ( ! empty( $result['deferred'] ) ) {
                        Logger::warning( 'buffer_share_deferred', null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                            'channel_name' => self::channel_name( $channel_id, $account_id ),
                            'account_id' => $account_id,
                            'retry_at' => $result['retry_at'] ?? '',
                            'reason' => $result['defer_reason'] ?? 'queue_full',
                            'error' => $result['error'] ?? '',
                        ] );
                        $blocked_channels[ $channel_id ] = isset( $result['retry_at'] ) ? gmdate( 'Y-m-d\TH:i:s', (int) $result['retry_at'] ) : '';
                        // Queue-full deferrals wait for the slot-bound retry time;
                        // transient upstream failures retry after the plain grace window.
                        $defer_reason = (string) ( $result['defer_reason'] ?? 'queue_full' );
                        $earliest_due_at = $defer_reason === 'invalid_json_transient' ? '' : $blocked_channels[ $channel_id ];
                        // AUDIT F4: pass the defer_reason so queue-full entries
                        // get the higher retry budget (5 attempts) and transient
                        // failures stick to the strict 2-attempt cap.
                        self::defer_pending_share( $post_id, $attachment_id, $account_id, $earliest_due_at, $defer_reason );
                    } else {
                        Logger::warning( 'buffer_share_failed', null, [
                            'post_id' => $post_id,
                            'channel_id' => $channel_id,
                            'channel_name' => self::channel_name( $channel_id, $account_id ),
                            'is_story' => $is_story,
                            'error' => $result['error'] ?? 'Unknown error',
                        ] );
                        self::defer_pending_share( $post_id, $attachment_id, $account_id, '' );
                    }
                }
            } else {
                Logger::debug( 'buffer_no_batch_jobs', null, [
                    'post_id' => $post_id,
                    'account_id' => $account_id,
                    'channel_count' => $channel_count,
                ] );
            }
        }

        Logger::debug( 'buffer_share_summary', null, [
            'post_id' => $post_id,
            'account_id' => $account_id,
            'shared_count' => $shared_count,
            'is_video' => $is_video,
        ] );

        if ( $shared_count > 0 ) {
            Config::increment_buffer_account_tracker( $account_id, $post_id );
            self::invalidate_scheduled_snapshot( $account_id );
        }

        return $shared_count > 0;
    }

    private static function create_batched_posts( array $jobs, string $share_mode, string $account_id = 'default', bool $force_share_now = false ): array {
        $token = self::token_for( $account_id );
        if ( empty( $token ) || empty( $jobs ) ) {
            $err = [ 'success' => false, 'error' => empty( $token ) ? 'No access token' : 'No jobs provided' ];
            return array_fill_keys( array_column( $jobs, 'alias' ), $err );
        }

        $due_at = gmdate( 'Y-m-d\TH:i:s', time() + 300 ) . '.000Z';
        $mutation_parts = [];

        foreach ( $jobs as $job ) {
            $job_share_mode = $job['share_mode'] ?? $share_mode;
            $input_parts = [
                'channelId: "' . self::graphql_escape( $job['channel_id'] ) . '"',
                'text: "' . self::graphql_escape( $job['text'] ) . '"',
                'schedulingType: automatic',
            ];

            if ( $force_share_now ) {
                // Publish immediately. A post created with mode: shareNow is sent
                // straight to "Sent" and does NOT consume a scheduled-slot, so it
                // bypasses Buffer's "10 scheduled posts" queue limit entirely. Used
                // as a fallback when the queue is full and no slot could be freed.
                $input_parts[] = 'mode: shareNow';
            } elseif ( $job_share_mode === 'draft' ) {
                $input_parts[] = 'mode: addToQueue';
                $input_parts[] = 'saveToDraft: true';
            } elseif ( $job_share_mode === 'auto' ) {
                $input_parts[] = 'mode: addToQueue';
            } else {
                $input_parts[] = 'mode: customScheduled';
                $input_parts[] = 'dueAt: "' . $due_at . '"';
            }

            if ( ! empty( $job['image_url'] ) ) {
                $escaped_url = self::graphql_escape( $job['image_url'] );
                if ( ! empty( $job['is_video'] ) ) {
                    $input_parts[] = 'assets: [ { video: { url: "' . $escaped_url . '", metadata: { thumbnailOffset: 1000 } } } ]';
                } else {
                    $input_parts[] = 'assets: [ { image: { url: "' . $escaped_url . '" } } ]';
                }
            }

            $metadata_gql = self::build_metadata_graphql( $job['metadata'] );
            if ( ! empty( $metadata_gql ) ) {
                $input_parts[] = $metadata_gql;
            }

            $alias = $job['alias'];
            $mutation_parts[] = $alias . ': createPost( input: { ' . implode( ', ', $input_parts ) . ' } ) { ... on PostActionSuccess { post { id text dueAt } } ... on MutationError { message } }';
        }

        $mutation = 'mutation CreateBatchedPosts { ' . implode( ' ', $mutation_parts ) . ' }';

        $api_result = self::api_request( [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8',
            ],
            'body'    => wp_json_encode( [ 'query' => $mutation ] ),
            'timeout' => 30,
        ], 'create_batched_posts' );

        $results = [];
        foreach ( $jobs as $job ) {
            $results[ $job['alias'] ] = [ 'success' => false, 'error' => 'Unknown error' ];
        }

        if ( $api_result['wp_error'] ) {
            foreach ( $jobs as $job ) {
                $results[ $job['alias'] ]['error'] = $api_result['error_message'];
            }
            return $results;
        }

        if ( $api_result['status_code'] === 429 ) {
            Logger::warning( 'buffer_create_batched_posts_rate_limited_exhausted', null, [
                'attempts' => self::MAX_RETRY_ATTEMPTS,
            ] );
            // AUDIT F5: when api_request bails out due to the inline-sleep
            // ceiling, the per-job result must carry `deferred => true` +
            // `defer_reason => 'rate_limited'` so the per-job loop routes
            // through the deferred path (defer_pending_share), which uses
            // the higher PENDING_MAX_RETRY_ATTEMPTS_QUEUE budget. Without
            // this flag, 429s hit the hard-fail else branch with the strict
            // 2-attempt cap and Buffer's "10 scheduled" rate window can
            // close the loop before the retry ever fires.
            foreach ( $jobs as $job ) {
                $results[ $job['alias'] ] = [
                    'success'      => false,
                    'deferred'     => true,
                    'defer_reason' => 'rate_limited',
                    'retry_at'     => time() + self::PENDING_RETRY_GRACE_SEC,
                    'error'        => 'Rate limited by Buffer API',
                ];
            }
            return $results;
        }

        $data = json_decode( $api_result['body'], true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $status_code = (int) ( $api_result['status_code'] ?? 0 );
            $body        = (string) ( $api_result['body'] ?? '' );
            $body_sample = trim( preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $body ) );
            $body_sample = mb_substr( $body_sample, 0, 500 );

            // A body that fails to parse is either a gateway/HTML error page
            // (Cloudflare 5xx/403, empty body) or a truncated JSON stream.
            // Only a 4xx status (other than 429) is a deterministic client
            // rejection; everything else is transient and must be deferred for
            // retry_pending_shares() instead of being dropped as a hard failure.
            $transient = ! ( $status_code >= 400 && $status_code < 500 && $status_code !== 429 );

            Logger::warning( 'buffer_create_batched_posts_invalid_json', null, [
                'status_code' => $status_code,
                'body_length' => strlen( $body ),
                'body_excerpt' => $body_sample,
                'transient'   => $transient,
            ] );

            foreach ( $jobs as $job ) {
                if ( $transient ) {
                    $results[ $job['alias'] ]['error']          = 'Invalid JSON response (HTTP ' . $status_code . ')';
                    $results[ $job['alias'] ]['deferred']       = true;
                    $results[ $job['alias'] ]['defer_reason']   = 'invalid_json_transient';
                    $results[ $job['alias'] ]['retry_at']       = time() + self::PENDING_RETRY_GRACE_SEC;
                } else {
                    $results[ $job['alias'] ]['error'] = 'Invalid JSON response (HTTP ' . $status_code . ')';
                }
            }
            return $results;
        }

        $errors = $data['errors'] ?? [];
        if ( ! empty( $errors ) ) {
            $msg = $errors[0]['message'] ?? 'GraphQL error';
            foreach ( $jobs as $job ) {
                $results[ $job['alias'] ]['error'] = $msg;
            }
            return $results;
        }

        $responseData = $data['data'] ?? [];
        $retry_attempted = [];
        foreach ( $jobs as $job ) {
            $alias = $job['alias'];
            // An earlier sibling's queue-full recycle already retried this alias
            // (post+story pairs are retried together); skip its stale original result.
            if ( ! empty( $results[ $alias ]['success'] ) || isset( $retry_attempted[ $alias ] ) ) {
                continue;
            }
            $aliasData = $responseData[ $alias ] ?? null;

            if ( ! $aliasData ) {
                $results[ $alias ]['error'] = 'No data returned for alias';
                continue;
            }

            if ( ! empty( $aliasData['message'] ) ) {
                $results[ $alias ]['error'] = $aliasData['message']; // MutationError

                // Scheduled-posts / queue limit reached for this channel: try to
                // free slots (publish oldest scheduled post(s) now) and retry once.
                // IG/FB post+story pairs consume 2 slots, so both jobs of the pair
                // are counted and retried together.
                if ( self::is_queue_limit_error( $aliasData['message'] ) ) {
                    // Collect every job in this batch that ALSO hit the queue limit
                    // on the same channel. All of them need a freed slot before any
                    // queued retry can succeed (siblings that already succeeded kept
                    // their slot).
                    $retry_jobs = [];
                    foreach ( $jobs as $j ) {
                        if ( ( $j['channel_id'] ?? '' ) !== $job['channel_id'] ) {
                            continue;
                        }
                        $j_data = $responseData[ $j['alias'] ] ?? null;
                        $j_msg  = ( is_array( $j_data ) && isset( $j_data['message'] ) ) ? (string) $j_data['message'] : '';
                        if ( $j_msg !== '' && self::is_queue_limit_error( $j_msg ) ) {
                            $retry_jobs[] = $j;
                        }
                    }

                    if ( empty( $retry_jobs ) ) {
                        $retry_jobs[] = $job;
                    }

                    $queue_published = false;

                    // Strategy 1: free slots by publishing the oldest scheduled
                    // post(s) now, then re-queue. IG/FB post+story pairs consume 2
                    // slots, so all jobs of the pair are counted and retried together.
                    if ( Config::get_buffer_account_queue_full_action( $account_id ) === 'publish_oldest' && self::$queue_retry_depth < 1 ) {
                        self::$queue_retry_depth++;
                        try {
                            $slots_needed = count( $retry_jobs );
                            $freed        = 0;
                            for ( $i = 0; $i < $slots_needed; $i++ ) {
                                // Snapshot is invalidated by each successful publish_scheduled_post_now()
                                // (via invalidate_scheduled_snapshot), so re-fetch picks the next earliest.
                                $snapshot = self::get_cached_scheduled_status( $account_id );
                                $st       = $snapshot[ $job['channel_id'] ] ?? null;
                                if ( ! is_array( $st ) || empty( $st['earliest_id'] ) ) {
                                    break;
                                }
                                if ( self::publish_scheduled_post_now( $st['earliest_id'], $account_id ) ) {
                                    $freed++;
                                } else {
                                    break;
                                }
                            }

                            if ( $freed >= $slots_needed ) {
                                $retry_results = self::create_batched_posts( $retry_jobs, $share_mode, $account_id );
                                $retry_ok      = false;
                                foreach ( $retry_jobs as $rj ) {
                                    $rr = $retry_results[ $rj['alias'] ] ?? null;
                                    if ( is_array( $rr ) && ! empty( $rr['success'] ) ) {
                                        $results[ $rj['alias'] ] = $rr;
                                        $retry_ok = true;
                                    } elseif ( is_array( $rr ) && ! empty( $rr['error'] ) ) {
                                        $results[ $rj['alias'] ]['error'] = $rr['error'];
                                    }
                                    $retry_attempted[ $rj['alias'] ] = true;
                                }
                                if ( $retry_ok ) {
                                    Logger::info( 'buffer_retry_after_slot_freed', null, [
                                        'post_id'     => $job['post_id'] ?? 0,
                                        'channel_id'  => $job['channel_id'],
                                        'channel_name' => self::channel_name( $job['channel_id'], $account_id ),
                                        'account_id'  => $account_id,
                                        'slots_freed' => $freed,
                                    ], '200', 'Buffer queue was full; published ' . $freed . ' oldest scheduled post(s) and retried ' . count( $retry_jobs ) . ' job(s) successfully for ' . trim( self::channel_name( $job['channel_id'], $account_id ) . ' ' . $job['channel_id'] ) );
                                }
                                $queue_published = true;
                            }
                        } finally {
                            self::$queue_retry_depth--;
                        }
                    }

                    // Strategy 2 (fallback): no slot could be freed (queue action is
                    // 'wait', publish_oldest failed, or no earliest post found). Do
                    // not drop or defer the post — publish it IMMEDIATELY with
                    // mode: shareNow. A shareNow post is sent straight to "Sent" and
                    // does not consume a scheduled-slot, so it bypasses Buffer's
                    // "10 scheduled posts" queue limit entirely.
                    if ( ! $queue_published ) {
                        $retry_results = self::create_batched_posts( $retry_jobs, $share_mode, $account_id, true );
                        $retry_ok      = false;
                        foreach ( $retry_jobs as $rj ) {
                            $rr = $retry_results[ $rj['alias'] ] ?? null;
                            if ( is_array( $rr ) && ! empty( $rr['success'] ) ) {
                                $results[ $rj['alias'] ] = $rr;
                                $retry_ok = true;
                            } elseif ( is_array( $rr ) && ! empty( $rr['error'] ) ) {
                                $results[ $rj['alias'] ]['error'] = $rr['error'];
                            }
                            $retry_attempted[ $rj['alias'] ] = true;
                        }
                        if ( $retry_ok ) {
                            Logger::info( 'buffer_retry_published_immediately', null, [
                                'post_id'    => $job['post_id'] ?? 0,
                                'channel_id' => $job['channel_id'],
                                'channel_name' => self::channel_name( $job['channel_id'], $account_id ),
                                'account_id' => $account_id,
                                'jobs'       => count( $retry_jobs ),
                            ], '200', 'Buffer queue was full; published ' . count( $retry_jobs ) . ' job(s) immediately (shareNow) for ' . trim( self::channel_name( $job['channel_id'], $account_id ) . ' ' . $job['channel_id'] ) . ' to bypass the scheduled-post limit' );
                        } else {
                            // Even immediate publish failed — defer so the post is
                            // retried later instead of being silently lost.
                            $results[ $alias ]['deferred'] = true;
                            $results[ $alias ]['retry_at'] = time() + self::PENDING_RETRY_GRACE_SEC;
                        }
                    }
                    continue;
                }
                continue;
            }

            $post_data = $aliasData['post'] ?? null;
            if ( $post_data ) {
                $results[ $alias ] = [
                    'success' => true,
                    'post_id' => $post_data['id'] ?? '',
                    'due_at'  => $post_data['dueAt'] ?? ( ( $job_share_mode === 'draft' || $force_share_now ) ? '' : $due_at ),
                ];
            } else {
                $results[ $alias ]['error'] = 'Post data missing';
            }
        }

        return $results;
    }

    private static function create_idea( string $headline, string $description, string $hashtags, string $account_id = 'default' ): array {
        if ( empty( trim( $headline ) ) && empty( trim( $description ) ) ) {
            return [ 'success' => false, 'error' => 'Empty headline and description' ];
        }

        $token = self::token_for( $account_id );

        $org_id = self::get_organization_id( $token, $account_id );
        if ( empty( $org_id ) ) {
            return [ 'success' => false, 'error' => 'No organization found' ];
        }

        $title_source = ! empty( trim( $headline ) ) ? $headline : mb_substr( $description, 0, 200 );
        $title = self::graphql_escape( mb_substr( $title_source, 0, 200 ) );
        $text_parts = [ $description ];
        if ( ! empty( trim( $hashtags ) ) ) {
            $text_parts[] = $hashtags;
        }
        $text = self::graphql_escape( implode( "\n\n", $text_parts ) );

        $mutation = 'mutation CreateIdea { createIdea( input: { organizationId: "' . self::graphql_escape( $org_id ) . '", content: { title: "' . $title . '", text: "' . $text . '" } } ) { ... on Idea { id content { title text } } ... on MutationError { message } } }';

        $api_result = self::api_request( [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8',
            ],
            'body'    => wp_json_encode( [ 'query' => $mutation ] ),
            'timeout' => 30,
        ], 'create_idea' );

        if ( $api_result['wp_error'] ) {
            return [ 'success' => false, 'error' => $api_result['error_message'] ];
        }

        if ( $api_result['status_code'] === 429 ) {
            Logger::warning( 'buffer_create_idea_rate_limited_exhausted', null, [
                'attempts' => self::MAX_RETRY_ATTEMPTS,
            ] );
            return [ 'success' => false, 'error' => 'Rate limited by Buffer API after ' . self::MAX_RETRY_ATTEMPTS . ' retries' ];
        }

        $data = json_decode( $api_result['body'], true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $status_code = (int) ( $api_result['status_code'] ?? 0 );
            $body_sample = trim( (string) $api_result['body'] );
            Logger::warning( 'buffer_create_idea_invalid_json', null, [
                'status_code' => $status_code,
                'body_length' => strlen( (string) $api_result['body'] ),
                'body_excerpt' => mb_substr( $body_sample, 0, 500 ),
            ] );
            return [ 'success' => false, 'error' => 'Invalid JSON response (HTTP ' . $status_code . ')' ];
        }

        $errors = $data['errors'] ?? [];
        if ( ! empty( $errors ) ) {
            $msg = $errors[0]['message'] ?? 'GraphQL error';
            return [ 'success' => false, 'error' => $msg ];
        }

        $idea_data = $data['data']['createIdea'] ?? null;

        if ( empty( $idea_data ) || ! isset( $idea_data['id'] ) ) {
            $mutation_error = ( is_array( $idea_data ) && isset( $idea_data['message'] ) ) ? $idea_data['message'] : 'No idea data returned';
            return [ 'success' => false, 'error' => $mutation_error ];
        }

        return [
            'success' => true,
            'post_id' => $idea_data['id'] ?? '',
            'due_at'  => '',
        ];
    }

    private static function build_metadata( string $service, string $post_type, array $link_posts, string $channel_id, string $post_url, int $post_id = 0, string $account_id = 'default' ): array {
        $metadata = [];

        // ── YT placeholders ────────────────────────────────────────────────
        // build_metadata() has its own scope: the $yt_title / $yt_description
        // defined in share_to_account() do NOT exist here. Deriving them again
        // (under $ai_yt_* names) keeps the Pinterest and YouTube title templates
        // working without passing null into compile_template() — which would be
        // a TypeError, since those parameters are typed `string`.
        $auto_meta = $post_id > 0 ? get_post_meta( $post_id, Config::META_AUTO_META, true ) : [];
        $auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

        $ai_yt_title = '';
        if ( ! empty( $auto_meta['ai_yt_title'] ) ) {
            $ai_yt_title = is_array( $auto_meta['ai_yt_title'] )
                ? implode( ' ', $auto_meta['ai_yt_title'] )
                : (string) $auto_meta['ai_yt_title'];
        }

        $ai_yt_description = '';
        if ( ! empty( $auto_meta['ai_yt_description'] ) ) {
            $ai_yt_description = is_array( $auto_meta['ai_yt_description'] )
                ? implode( "\n", $auto_meta['ai_yt_description'] )
                : (string) $auto_meta['ai_yt_description'];
        }

        switch ( $service ) {
            case 'facebook':
                $meta = [ 'type' => $post_type ];
                if ( ! empty( $link_posts[ $channel_id ] ) && $post_type !== 'story' ) {
                    $meta['linkAttachment'] = [ 'url' => $post_url ];
                }
                $metadata['facebook'] = $meta;
                break;

            case 'instagram':
                $metadata['instagram'] = [
                    'type' => $post_type,
                    'shouldShareToFeed' => $post_type !== 'story',
                ];
                break;

            case 'linkedin':
                $meta = [];
                if ( ! empty( $link_posts[ $channel_id ] ) ) {
                    $meta['linkAttachment'] = [ 'url' => $post_url ];
                }
                if ( ! empty( $meta ) ) {
                    $metadata['linkedin'] = $meta;
                }
                break;

            case 'pinterest':
                $boards = Config::get_buffer_account_pinterest_boards( $account_id );
                $titles = Config::get_buffer_account_pinterest_titles( $account_id );
                $board_id = $boards[ $channel_id ] ?? '';
                $title_template = $titles[ $channel_id ] ?? '{headline}';
                $pin_headline_source = $post_id > 0 ? get_post_field( 'post_title', $post_id ) : '';
                $pin_title = self::compile_template( $title_template, $pin_headline_source, '', '', $post_url, '', '', '', $ai_yt_title, $ai_yt_description );
                $pin_title = mb_substr( $pin_title, 0, 100 );

                $pinterest_meta = [];
                if ( ! empty( $board_id ) ) {
                    $pinterest_meta['boardServiceId'] = $board_id;
                }
                if ( ! empty( $pin_title ) ) {
                    $pinterest_meta['title'] = $pin_title;
                }
                if ( ! empty( $post_url ) ) {
                    $pinterest_meta['url'] = $post_url;
                }
                if ( ! empty( $pinterest_meta ) ) {
                    $metadata['pinterest'] = $pinterest_meta;
                }
                break;

            case 'youtube':
                // YoutubePostMetadataInput: `title` and `categoryId` are REQUIRED
                // on create (Buffer API docs). Always send a valid title and a
                // valid category id so createPost never fails validation. All
                // other fields (privacy, madeForKids, license, ...) are optional
                // and Buffer applies its defaults when omitted.
                $yt_titles = Config::get_buffer_account_youtube_titles( $account_id );
                $yt_cats   = Config::get_buffer_account_youtube_categories( $account_id );

                $title_source = $post_id > 0 ? get_post_field( 'post_title', $post_id ) : '';
                $yt_title = self::compile_template( $yt_titles[ $channel_id ] ?? '', $title_source, '', '', $post_url, '', '', '', $ai_yt_title, $ai_yt_description );
                if ( $yt_title === '' ) {
                    if ( $ai_yt_title !== '' ) {
                        $yt_title = $ai_yt_title;
                    } elseif ( ! empty( $auto_meta['ai_headline'] ) ) {
                        $yt_title = (string) $auto_meta['ai_headline'];
                    } else {
                        $yt_title = $title_source;
                    }
                }

                $yt_cat = $yt_cats[ $channel_id ] ?? '';
                if ( ! array_key_exists( $yt_cat, Config::BUFFER_YOUTUBE_CATEGORIES ) ) {
                    $yt_cat = Config::DEFAULT_YOUTUBE_CATEGORY_ID;
                }

                // YoutubePostMetadataInput does NOT define a 'type' field. Sending
                // one makes Buffer reject the ENTIRE mutation (all aliases in the
                // batch fail), not only the YouTube job. title/categoryId below are
                // the only fields required by the schema.
                $youtube_meta = [];
                $yt_title = trim( $yt_title );
                if ( $yt_title !== '' ) {
                    $youtube_meta['title'] = mb_substr( $yt_title, 0, 100 );
                }
                $youtube_meta['categoryId'] = $yt_cat;
                // YoutubePrivacy: 'private'/'unlisted' keep the video invisible
                // and editable in YouTube Studio until the owner flips it public
                // (Buffer defaults to 'public' when omitted).
                $youtube_meta['privacy'] = Config::get_buffer_account_youtube_privacy( $account_id );
                $metadata['youtube'] = $youtube_meta;
                break;
        }

        return $metadata;
    }
    private static function validate_post_type( string $service, string $post_type ): string {
        $valid_types = [
            'facebook'  => [ 'post', 'story', 'reel' ],
            'instagram' => [ 'post', 'story', 'reel' ],
            'twitter'   => [ 'post' ],
            'linkedin'  => [ 'post' ],
            'pinterest' => [ 'post' ],
            'youtube'   => [ 'post', 'video' ],
            'threads'   => [ 'post', 'story' ],
            'tiktok'    => [ 'post', 'video' ],
        ];
        $allowed = $valid_types[ $service ] ?? [ 'post' ];
        return in_array( $post_type, $allowed, true ) ? $post_type : 'post';
    }

    private static function adapt_text_for_service( string $text, string $service, string $post_type ): string {
        $limit = Config::get_buffer_service_caption_limit( $service );
        if ( $limit <= 0 ) {
            return $text;
        }

        $text = trim( $text );
        if ( mb_strlen( $text ) <= $limit ) {
            return $text;
        }

        // Keep the trailing hashtag block intact ("hashtags used as is") and
        // truncate only the caption/description part. The regex matches a tail
        // that consists solely of #tokens; any #tokens mid-caption fall back
        // to the plain truncation below.
        $description = $text;
        $hashtags    = '';
        if ( preg_match( '/^(.*?)(\s+#\S+(?:\s+#\S+)*)$/us', $text, $m ) ) {
            $description = $m[1];
            $hashtags    = trim( $m[2] );
        }

        $hashtag_len = $hashtags !== '' ? mb_strlen( $hashtags ) + 1 : 0; // +1 separating space
        $budget      = $limit - $hashtag_len;

        if ( $budget <= 0 ) {
            return $hashtags;
        }

        if ( mb_strlen( $description ) > $budget ) {
            $description = mb_substr( $description, 0, max( 1, $budget - 1 ) ) . '…';
        }

        return trim( $description ) . ( $hashtags !== '' ? ' ' . $hashtags : '' );
    }

	private static function compile_template( string $template, string $headline, string $description, string $hashtags, string $link, string $x_hashtags = '', string $x_description = '', string $mentions = '', string $yt_title = '', string $yt_description = '', string $x_content = '' ): string {

		// Fall back to the generic fields so a template using {yt_title} or
		// {yt_description} renders something sensible rather than going blank when
		// the AI did not return YouTube metadata for that particular post.
		if ( $yt_title === '' ) {
			$yt_title = $headline;
		}

		if ( $yt_description === '' ) {
			$yt_description = $description;
		}

	$data = [
		'{headline}'       => $headline,
		'{description}'    => $description,
		'{hashtags}'       => $hashtags,
		'{link}'           => $link,
		'{X-CONTENT}'      => $x_content,
		'{x_hashtags}'     => $x_hashtags,
		'{x_description}'  => $x_description,
		'{question}'       => $headline,
		'{options}'        => $description,
		'{tags}'           => $hashtags,
		'{mentions}'       => $mentions,
		'{yt_title}'       => $yt_title,
		'{yt_description}' => $yt_description,
	];

	$result = str_replace( array_keys( $data ), array_values( $data ), $template );
	return preg_replace( "/\n{3,}/", "\n\n", trim( $result ) );
}

	/**
	 * Parse post content (Gutenberg or classic) into Buffer-ready fields.
	 * Used by PostObserver::sync_user_edits_to_meta() to sync edits back to META_AUTO_META.
	 *
	 * @param string $content     The post_content to parse.
	 * @param array  $fallback_meta Fallback META_AUTO_META values for fields not found in content.
	 * @return array Parsed fields: ai_headline, ai_hook, ai_detailed_description, ai_hashtags, ai_mentions, x_content, x_hashtags, x_description.
	 */
	public static function parse_post_content_for_buffer( string $content, array $fallback_meta = [] ): array {
		$result = [
			'ai_headline'             => '',
			'ai_hook'                 => '',
			'ai_detailed_description' => '',
			'ai_hashtags'             => [],
			'ai_mentions'             => [],
			'x_content'               => '',
			'x_hashtags'              => [],
			'x_description'           => '',
		];

		if ( empty( $content ) ) {
			return $result;
		}

		// 1) Try Gutenberg block parsing
		if ( function_exists( 'parse_blocks' ) && has_blocks( $content ) ) {
			$blocks = parse_blocks( $content );
			$text_parts = []; // plain description paragraphs
			$tags_parts = []; // hashtags-only paragraphs (general tags)
			$x_parts    = []; // paragraphs with text AND hashtags (the X/Twitter text)
			foreach ( $blocks as $block ) {
				if ( ! in_array( $block['blockName'], [ 'core/paragraph', 'core/heading' ], true ) ) {
					continue;
				}
				$raw = $block['innerContent'][0] ?? '';
				if ( $raw === '' ) {
					continue;
				}
				// Decode entities (esc_html output) so '&#039;' cannot be
				// mistaken for the hashtag '#039' and user-visible text is matched.
				$text = wp_strip_all_tags( html_entity_decode( $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
				$text = trim( $text );
				if ( $text === '' ) {
					continue;
				}
				// Headline lives in post_title; never fold it into the description.
				if ( $block['blockName'] === 'core/heading' ) {
					continue;
				}
				$has_tag = (bool) preg_match( '/#[\p{L}\p{N}_]+/u', $text );
				$text_only = trim( preg_replace( '/#[\p{L}\p{N}_]+\s*/u', '', $text ) );
				if ( $has_tag && $text_only !== '' ) {
					$x_parts[] = $text; // text + hashtags -> X/Twitter paragraph
				} elseif ( $has_tag ) {
					$tags_parts[] = $text; // hashtags only -> general tags paragraph
				} else {
					$text_parts[] = $text; // plain text -> description paragraph
				}
			}
			$full_text = implode( ' ', array_merge( $text_parts, $tags_parts ) );
			// Earlier X-like paragraphs stay plain description text; only the LAST
			// one is the X paragraph (matches the producer block layout).
			$x_main = ! empty( $x_parts ) ? array_pop( $x_parts ) : '';
			if ( ! empty( $x_parts ) ) {
				$full_text = trim( $full_text . ' ' . implode( ' ', array_map( function ( $p ) {
					return trim( preg_replace( '/#[\p{L}\p{N}_]+\s*/u', '', $p ) );
				}, $x_parts ) ) );
			}
		} else {
			// 2) Classic editor fallback
			$full_text = wp_strip_all_tags( html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			$x_main    = '';
		}

		// Extract hashtags (#tag)
		if ( preg_match_all( '/#[\p{L}\p{N}_]+/u', $full_text, $m ) ) {
			$result['ai_hashtags'] = array_values( array_unique( $m[0] ) );
		}

		// Extract mentions (@handle)
		if ( preg_match_all( '/@[\w.]+/', $full_text, $m ) ) {
			$result['ai_mentions'] = array_values( array_unique( $m[0] ) );
		}

		// Description = text without hashtags/mentions (headline excluded)
		$clean = preg_replace( '/#[\p{L}\p{N}_]+\s*/u', '', $full_text );
		$clean = preg_replace( '/@[\w.]+\s*/', '', $clean );
		// Preserve the AI-curated value verbatim when the content paragraph is
		// unchanged; when the user edited it, keep the FULL edited text (no word
		// budget). Consumers apply their own per-service limits at share time
		// (see apply_caption_limit + twitter fallback below); wp_trim_words with
		// a default $more would append the literal entity '&hellip;' to meta.
		if ( trim( $clean ) !== '' && ! empty( $fallback_meta['ai_detailed_description'] )
			&& preg_replace( '/\s+/u', ' ', trim( $clean ) ) === preg_replace( '/\s+/u', ' ', trim( (string) $fallback_meta['ai_detailed_description'] ) ) ) {
			$result['ai_detailed_description'] = (string) $fallback_meta['ai_detailed_description'];
		} else {
			$result['ai_detailed_description'] = trim( $clean );
		}
		// No hook block exists in the generated schema; let the caller keep the meta hook.
		$result['ai_hook'] = '';

		// X/Twitter specific — derived ONLY from the X paragraph (the user-editable X text)
		if ( $x_main !== '' ) {
			if ( preg_match_all( '/#[\p{L}\p{N}_]+/u', $x_main, $m ) ) {
				$result['x_hashtags'] = array_slice( array_values( array_unique( $m[0] ) ), 0, 5 );
			}
			$x_clean = trim( preg_replace( '/#[\p{L}\p{N}_]+\s*/u', '', $x_main ) );
			$x_clean = preg_replace( '/@[\w.]+\s*/', '', $x_clean );
		} else {
			$x_clean = '';
		}

		// Preserve the AI-curated X text verbatim when the X paragraph is unchanged.
		if ( $x_clean !== '' && ! empty( $fallback_meta['ai_x_description'] )
			&& preg_replace( '/\s+/u', ' ', trim( $x_clean ) ) === preg_replace( '/\s+/u', ' ', trim( (string) $fallback_meta['ai_x_description'] ) ) ) {
			$result['x_description'] = (string) $fallback_meta['ai_x_description'];
		} else {
			$result['x_description'] = trim( $x_clean );
		}
		$result['x_content'] = $result['x_description'] . ( $result['x_hashtags'] ? ' ' . implode( ' ', $result['x_hashtags'] ) : '' );

		return $result;
	}

    private static function detect_service( string $channel_id, string $account_id = 'default' ): string {
        $channels = self::get_channels( $account_id );
        if ( is_array( $channels ) ) {
            foreach ( $channels as $ch ) {
                if ( ( $ch['id'] ?? '' ) === $channel_id ) {
                    return strtolower( $ch['service'] ?? 'unknown' );
                }
            }
        }

        foreach ( Config::BUFFER_SERVICES as $svc ) {
            if ( strpos( $channel_id, $svc ) !== false ) {
                return $svc;
            }
        }

        return 'unknown';
    }

    /**
     * Resolve a human-readable channel name from the cached Buffer channels
     * (the same SSOT used by detect_service). Returns '' when unknown so
     * callers can fall back to the channel id in log messages.
     */
    private static function channel_name( string $channel_id, string $account_id = 'default' ): string {
        $channels = self::get_channels( $account_id );
        if ( is_array( $channels ) ) {
            foreach ( $channels as $ch ) {
                if ( ( $ch['id'] ?? '' ) === $channel_id ) {
                    return (string) ( $ch['name'] ?? '' );
                }
            }
        }
        return '';
    }

    private static function record_share( int $post_id, string $channel_id, string $service, string $due_at, string $mode = 'auto', string $buffer_post_id = '', string $account_id = 'default' ): void {
        $history = get_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, true );
        if ( ! is_array( $history ) ) {
            $history = [];
        }

        $history[] = [
            'channel_id' => $channel_id,
            'service' => $service,
            'post_id' => $post_id,
            'buffer_post_id' => $buffer_post_id,
            'due_at' => $due_at,
            'mode' => $mode,
            'account_id' => $account_id,
            'shared_at' => current_time( 'mysql', true ),
        ];

        update_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, $history );
    }

    public static function get_channels( string $account_id = 'default' ): array {
        $token = self::token_for( $account_id );
        if ( empty( $token ) ) {
            return [];
        }

        $cached = get_option( self::cache_key( 'ai_collage_buffer_channels_cache', $account_id ) );
        if ( is_array( $cached ) && ! empty( $cached ) ) {
            return $cached;
        }

        $org_id = self::get_organization_id( $token, $account_id );
        if ( empty( $org_id ) ) {
            return [];
        }

        $query = 'query { channels( input: { organizationId: "' . self::graphql_escape( $org_id ) . '" } ) { id name service avatar isQueuePaused } }';

        $response = wp_remote_post( self::API_BASE, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json; charset=utf-8',
            ],
            'body' => wp_json_encode( [ 'query' => $query ] ),
            'timeout' => 30,
        ]);

        if ( is_wp_error( $response ) ) {
            Logger::warning( 'buffer_channels_fetch_failed', null, [ 'error' => $response->get_error_message(), 'account_id' => $account_id ] );
            return [];
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        $channels = $data['data']['channels'] ?? [];
        if ( ! empty( $channels ) ) {
            update_option( self::cache_key( 'ai_collage_buffer_channels_cache', $account_id ), $channels, false );
        }

        return $channels;
    }

    private static function get_organization_id( string $token, string $account_id = 'default' ): string {
        $cache_key = self::cache_key( 'ai_collage_buffer_org_id', $account_id );
        $cached = get_transient( $cache_key );
        if ( ! empty( $cached ) ) {
            return $cached;
        }

        $query = 'query { account { organizations { id name } } }';

        $response = wp_remote_post( self::API_BASE, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json; charset=utf-8',
            ],
            'body' => wp_json_encode( [ 'query' => $query ] ),
            'timeout' => 30,
        ]);

        if ( is_wp_error( $response ) ) {
            return '';
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        $orgs = $data['data']['account']['organizations'] ?? [];
        if ( empty( $orgs ) ) {
            return '';
        }

        $org_id = $orgs[0]['id'] ?? '';
        if ( ! empty( $org_id ) ) {
            set_transient( $cache_key, $org_id, HOUR_IN_SECONDS );
        }

        return $org_id;
    }

    public static function get_pinterest_boards( string $channel_id, string $account_id = 'default' ): array {
        $token = self::token_for( $account_id );
        if ( empty( $token ) ) {
            return [];
        }

        $cache_key = self::cache_key( 'ai_collage_buffer_pinterest_boards_' . md5( $channel_id ), $account_id );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $query = 'query { channel( input: { id: "' . self::graphql_escape( $channel_id ) . '" } ) { metadata { ... on PinterestMetadata { boards { serviceId name } } } } }';

        $response = wp_remote_post( self::API_BASE, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json; charset=utf-8',
            ],
            'body' => wp_json_encode( [ 'query' => $query ] ),
            'timeout' => 30,
        ]);

        if ( is_wp_error( $response ) ) {
            return [];
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        $boards = $data['data']['channel']['metadata']['boards'] ?? [];
        if ( ! empty( $boards ) ) {
            set_transient( $cache_key, $boards, 15 * MINUTE_IN_SECONDS );
        }

        return $boards;
    }

    public static function clear_all_caches( string $account_id = '' ): void {
        if ( $account_id !== '' ) {
            delete_transient( self::cache_key( 'ai_collage_buffer_org_id', $account_id ) );
            delete_option( self::cache_key( 'ai_collage_buffer_channels_cache', $account_id ) );
            self::invalidate_scheduled_snapshot( $account_id );
            $channels = Config::get_buffer_account_channels( $account_id );
            foreach ( $channels as $channel_id ) {
                delete_transient( self::cache_key( 'ai_collage_buffer_pinterest_boards_' . md5( $channel_id ), $account_id ) );
            }
            return;
        }
        $accounts = Config::get_active_buffer_accounts();
        if ( ! empty( $accounts ) ) {
            foreach ( $accounts as $acct_id => $acct ) {
                self::clear_all_caches( $acct_id );
            }
        }
        delete_transient( 'ai_collage_buffer_org_id' );
        delete_option( 'ai_collage_buffer_channels_cache' );
        delete_transient( 'ai_collage_buffer_draft_count' );
        delete_transient( 'ai_collage_buffer_scheduled_posts' );
        delete_transient( 'ai_collage_buffer_scheduled_status' );
        $channels = Config::get_option_array( Config::OPTION_BUFFER_CHANNELS, [] );
        foreach ( $channels as $channel_id ) {
            delete_transient( 'ai_collage_buffer_pinterest_boards_' . md5( $channel_id ) );
        }
    }

    public static function delete_batched_posts( array $post_ids, string $account_id = 'default' ): array {
        $token = self::token_for( $account_id );
        $results = array_fill_keys( $post_ids, false );

        if ( empty( $token ) || empty( $post_ids ) ) {
            return $results;
        }

        $mutation_parts = [];
        $aliases = [];
        foreach ( $post_ids as $index => $id ) {
            $alias = 'del_' . $index;
            $aliases[ $alias ] = $id;
            $mutation_parts[] = $alias . ': deletePost( input: { id: "' . self::graphql_escape( $id ) . '" } ) { ... on DeletePostSuccess { id } ... on MutationError { message } }';
        }

        $mutation = 'mutation DeleteBatchedPosts { ' . implode( ' ', $mutation_parts ) . ' }';

        $response = wp_remote_post( self::API_BASE, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8',
            ],
            'body'    => wp_json_encode( [ 'query' => $mutation ] ),
            'timeout' => 30,
        ] );

        if ( is_wp_error( $response ) ) {
            Logger::warning( 'buffer_delete_batched_posts_failed', null, [
                'error' => $response->get_error_message(),
            ] );
            return $results;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        if ( $status_code === 429 ) {
            Logger::warning( 'buffer_delete_batched_posts_rate_limited', null, [] );
            return $results;
        }
        if ( $status_code >= 400 ) {
            Logger::warning( 'buffer_delete_batched_posts_http_error', null, [ 'status_code' => $status_code ] );
            return $results;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return $results;
        }

        $responseData = $data['data'] ?? [];
        foreach ( $aliases as $alias => $id ) {
            $aliasData = $responseData[ $alias ] ?? null;
            if ( $aliasData && isset( $aliasData['id'] ) ) {
                $results[ $id ] = true;
            } elseif ( ! empty( $aliasData['message'] ) ) {
                Logger::warning( 'buffer_delete_post_mutation_error', null, [
                    'buffer_post_id' => $id,
                    'error' => $aliasData['message'],
                ] );
            }
        }

        return $results;
    }

    public static function get_draft_posts_from_buffer( string $account_id = 'default' ): array {
        $token = self::token_for( $account_id );
        if ( empty( $token ) ) {
            return [];
        }

        $org_id = self::get_organization_id( $token, $account_id );
        if ( empty( $org_id ) ) {
            return [];
        }

        $all_drafts = [];
        $after_cursor = null;
        $has_next = true;

        while ( $has_next ) {
            $pagination = '';
            if ( $after_cursor ) {
                $pagination = ', after: "' . self::graphql_escape( $after_cursor ) . '"';
            }

            $query = 'query GetDraftPosts { posts( input: { organizationId: "' . self::graphql_escape( $org_id ) . '", filter: { status: [draft] } }, first: 50' . $pagination . ' ) { edges { node { id text createdAt channelId } } pageInfo { hasNextPage endCursor } } }';

            $response = wp_remote_post( self::API_BASE, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json; charset=utf-8',
                ],
                'body' => wp_json_encode( [ 'query' => $query ] ),
                'timeout' => 30,
            ] );

            if ( is_wp_error( $response ) ) {
                Logger::warning( 'buffer_drafts_fetch_failed', null, [ 'error' => $response->get_error_message() ] );
                break;
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            if ( json_last_error() !== JSON_ERROR_NONE ) {
                break;
            }

            $errors = $data['errors'] ?? [];
            if ( ! empty( $errors ) ) {
                Logger::warning( 'buffer_drafts_fetch_graphql_error', null, [
                    'error' => $errors[0]['message'] ?? 'Unknown error',
                ] );
                break;
            }

            $edges = $data['data']['posts']['edges'] ?? [];
            foreach ( $edges as $edge ) {
                $node = $edge['node'] ?? [];
                if ( ! empty( $node['id'] ) ) {
                    $all_drafts[] = [
                        'id'          => $node['id'],
                        'text'        => $node['text'] ?? '',
                        'created_at'  => $node['createdAt'] ?? '',
                        'channel_id'  => $node['channelId'] ?? '',
                    ];
                }
            }

            $page_info = $data['data']['posts']['pageInfo'] ?? [];
            $has_next = ! empty( $page_info['hasNextPage'] );
            $after_cursor = $page_info['endCursor'] ?? null;

            if ( $has_next && empty( $after_cursor ) ) {
                Logger::warning( 'buffer_drafts_pagination_no_cursor', null, [] );
                break;
            }

            if ( $has_next ) {
                usleep( self::INTER_REQUEST_DELAY_US );
            }
        }

        Logger::debug( 'buffer_drafts_fetched', null, [
            'total_drafts' => count( $all_drafts ),
        ] );

        return $all_drafts;
    }

    public static function get_draft_count_from_buffer( string $account_id = 'default' ): int {
        $cache_key = self::cache_key( 'ai_collage_buffer_draft_count', $account_id );
        $cached_count = get_transient( $cache_key );
        if ( $cached_count !== false ) {
            return (int) $cached_count;
        }

        $token = self::token_for( $account_id );
        if ( empty( $token ) ) {
            return 0;
        }

        $org_id = self::get_organization_id( $token, $account_id );
        if ( empty( $org_id ) ) {
            return 0;
        }

        $total = 0;
        $after_cursor = null;
        $has_next = true;

        while ( $has_next ) {
            $pagination = '';
            if ( $after_cursor ) {
                $pagination = ', after: "' . self::graphql_escape( $after_cursor ) . '"';
            }

            $query = 'query GetDraftCount { posts( input: { organizationId: "' . self::graphql_escape( $org_id ) . '", filter: { status: [draft] } }, first: 50' . $pagination . ' ) { edges { node { id } } pageInfo { hasNextPage endCursor } } }';

            $response = wp_remote_post( self::API_BASE, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json; charset=utf-8',
                ],
                'body' => wp_json_encode( [ 'query' => $query ] ),
                'timeout' => 15,
            ] );

            if ( is_wp_error( $response ) ) {
                break;
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            if ( json_last_error() !== JSON_ERROR_NONE ) {
                break;
            }

            $errors = $data['errors'] ?? [];
            if ( ! empty( $errors ) ) {
                Logger::warning( 'buffer_draft_count_graphql_error', null, [
                    'error' => $errors[0]['message'] ?? 'Unknown error',
                ] );
                break;
            }

            $edges = $data['data']['posts']['edges'] ?? [];
            $total += count( $edges );

            $page_info = $data['data']['posts']['pageInfo'] ?? [];
            $has_next = ! empty( $page_info['hasNextPage'] );
            $after_cursor = $page_info['endCursor'] ?? null;

            if ( $has_next && empty( $after_cursor ) ) {
                Logger::warning( 'buffer_draft_count_pagination_no_cursor', null, [] );
                break;
            }

            if ( $has_next ) {
                usleep( self::INTER_REQUEST_DELAY_US );
            }
        }

        set_transient( $cache_key, $total, HOUR_IN_SECONDS );

        return $total;
    }

    /**
     * Fetch all currently scheduled (queued) Buffer posts for an account's organization.
     * Sorted by dueAt ascending so the first entry of a channel is the next post to go out.
     * Cached briefly (SCHEDULED_SNAPSHOT_TTL) to avoid hammering the API per share.
     */
    public static function get_scheduled_posts_from_buffer( string $account_id = 'default' ): array {
        $cache_key = self::cache_key( 'ai_collage_buffer_scheduled_posts', $account_id );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $token = self::token_for( $account_id );
        if ( empty( $token ) ) {
            return [];
        }

        $org_id = self::get_organization_id( $token, $account_id );
        if ( empty( $org_id ) ) {
            return [];
        }

        $all_posts = [];
        $after_cursor = null;
        $has_next = true;

        while ( $has_next ) {
            $pagination = '';
            if ( $after_cursor ) {
                $pagination = ', after: "' . self::graphql_escape( $after_cursor ) . '"';
            }

            $query = 'query GetScheduledPosts { posts( input: { organizationId: "' . self::graphql_escape( $org_id ) . '", filter: { status: [scheduled] } }, first: 50' . $pagination . ' ) { edges { node { id channelId dueAt status metadata { __typename ... on FacebookPostMetadata { type } ... on InstagramPostMetadata { type } ... on LinkedInPostMetadata { type } ... on TwitterPostMetadata { type } ... on PinterestPostMetadata { type } ... on ThreadsPostMetadata { type } ... on TiktokPostMetadata { type } ... on YoutubePostMetadata { type } ... on MastodonPostMetadata { type } ... on BlueskyPostMetadata { type } ... on GoogleBusinessPostMetadata { type } } } } pageInfo { hasNextPage endCursor } } }';

            $response = wp_remote_post( self::API_BASE, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json; charset=utf-8',
                ],
                'body' => wp_json_encode( [ 'query' => $query ] ),
                'timeout' => 15,
            ] );

            if ( is_wp_error( $response ) ) {
                Logger::warning( 'buffer_scheduled_fetch_failed', null, [
                    'error' => $response->get_error_message(),
                    'account_id' => $account_id,
                ] );
                break;
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            if ( json_last_error() !== JSON_ERROR_NONE ) {
                break;
            }

            $errors = $data['errors'] ?? [];
            if ( ! empty( $errors ) ) {
                Logger::warning( 'buffer_scheduled_fetch_graphql_error', null, [
                    'error' => $errors[0]['message'] ?? 'Unknown error',
                    'account_id' => $account_id,
                ] );
                break;
            }

            $edges = $data['data']['posts']['edges'] ?? [];
            foreach ( $edges as $edge ) {
                $node = $edge['node'] ?? [];
                if ( ! empty( $node['id'] ) ) {
                    $metadata = $node['metadata'] ?? [];
                    $post_type = ! empty( $metadata['type'] ) ? (string) $metadata['type'] : 'post';
                    $all_posts[] = [
                        'id'         => $node['id'],
                        'channel_id' => $node['channelId'] ?? '',
                        'due_at'     => $node['dueAt'] ?? '',
                        'status'     => $node['status'] ?? 'scheduled',
                        'post_type'  => $post_type,
                    ];
                }
            }

            $page_info = $data['data']['posts']['pageInfo'] ?? [];
            $has_next = ! empty( $page_info['hasNextPage'] );
            $after_cursor = $page_info['endCursor'] ?? null;

            if ( $has_next && empty( $after_cursor ) ) {
                Logger::warning( 'buffer_scheduled_pagination_no_cursor', null, [ 'account_id' => $account_id ] );
                break;
            }

            if ( $has_next ) {
                usleep( self::INTER_REQUEST_DELAY_US );
            }
        }

        usort( $all_posts, function ( $a, $b ) {
            return strcmp( (string) ( $a['due_at'] ?? '' ), (string) ( $b['due_at'] ?? '' ) );
        } );

        if ( ! empty( $all_posts ) ) {
            set_transient( $cache_key, $all_posts, self::SCHEDULED_SNAPSHOT_TTL );
        }

        return $all_posts;
    }

    /**
     * Map of channel_id => [ count, earliest_id, earliest_due_at, earliest_post_type ] for scheduled posts.
     * Overdue posts (dueAt in the past) are excluded because Buffer's editPost(shareNow)
     * rejects them with a validation error, and retrying them only wastes the retry slot.
     */
    public static function get_channel_scheduled_status( string $account_id = 'default' ): array {
        $status = [];
        $now    = gmdate( 'Y-m-d\TH:i:s' ) . '.000Z';
        foreach ( self::get_scheduled_posts_from_buffer( $account_id ) as $post ) {
            $channel_id = (string) ( $post['channel_id'] ?? '' );
            if ( $channel_id === '' ) {
                continue;
            }
            if ( ! empty( $post['due_at'] ) && $post['due_at'] < $now ) {
                continue;
            }
            if ( ! isset( $status[ $channel_id ] ) ) {
                $status[ $channel_id ] = [
                    'count'             => 0,
                    'earliest_id'       => '',
                    'earliest_due_at'   => '',
                    'earliest_post_type' => 'post',
                ];
            }
            $status[ $channel_id ]['count']++;
            if ( empty( $status[ $channel_id ]['earliest_due_at'] ) || ( $post['due_at'] ?? '' ) < $status[ $channel_id ]['earliest_due_at'] ) {
                $status[ $channel_id ]['earliest_id']         = (string) $post['id'];
                $status[ $channel_id ]['earliest_due_at']     = (string) ( $post['due_at'] ?? '' );
                $status[ $channel_id ]['earliest_post_type']  = $post['post_type'] ?? 'post';
            }
        }
        return $status;
    }

    /**
     * Publish a queued Buffer post immediately (editPost mode: shareNow) to free a scheduled slot.
     * On Buffer-side validation failures ("Post must have either text or media", "require a type"),
     * the post id is blacklisted in-process and the scheduled snapshot is invalidated so subsequent
     * queue-full retries do not keep retrying the same broken id.
     */
    public static function publish_scheduled_post_now( string $buffer_post_id, string $account_id = 'default' ): bool {
        $token = self::token_for( $account_id );
        if ( empty( $token ) || empty( $buffer_post_id ) ) {
            return false;
        }

        if ( self::is_blacklisted_buffer_post( $buffer_post_id, $account_id ) ) {
            Logger::warning( 'buffer_edit_share_now_blacklisted', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id'     => $account_id,
                'error'          => 'Skipped previously unfixable Buffer post',
            ] );
            return false;
        }

        // Buffer's EditPostInput does not accept a 'type' field - the post type is
        // immutable after creation. Only CreatePostInput accepts 'type'.
        $mutation = 'mutation PublishScheduledNow { editPost( input: { id: "' . self::graphql_escape( $buffer_post_id ) . '", mode: shareNow, schedulingType: automatic } ) { ... on PostActionSuccess { post { id status } } ... on MutationError { message } } }';

        $api_result = self::api_request( [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8',
            ],
            'body'    => wp_json_encode( [ 'query' => $mutation ] ),
            'timeout' => 30,
        ], 'edit_post_share_now' );

        if ( $api_result['wp_error'] ) {
            Logger::warning( 'buffer_edit_share_now_failed', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id' => $account_id,
                'error' => $api_result['error_message'],
            ] );
            return false;
        }

        $data = json_decode( $api_result['body'], true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $status_code = (int) ( $api_result['status_code'] ?? 0 );
            $body_sample = trim( (string) $api_result['body'] );
            Logger::warning( 'buffer_edit_share_now_invalid_json', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id'     => $account_id,
                'status_code'    => $status_code,
                'body_length'    => strlen( (string) $api_result['body'] ),
                'body_excerpt'   => mb_substr( $body_sample, 0, 500 ),
            ] );
            return false;
        }

        $errors = $data['errors'] ?? [];
        if ( ! empty( $errors ) ) {
            $msg = $errors[0]['message'] ?? 'GraphQL error';
            Logger::warning( 'buffer_edit_share_now_failed', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id' => $account_id,
                'error' => $msg,
            ] );
            if ( self::is_buffer_validation_error( $msg ) ) {
                // The scheduled post is broken (no text/media or missing Facebook
                // type) and can never be published via editPost. Blacklisting alone
                // leaves it sitting in Buffer's queue, still consuming 1 of the 10
                // slots, so the caller's slot-freeing retry never succeeds. Delete
                // it instead so the slot is actually reclaimed.
                if ( self::delete_buffer_post_to_free_slot( $buffer_post_id, $account_id ) ) {
                    return true;
                }
                self::blacklist_buffer_post( $buffer_post_id, $account_id );
            }
            return false;
        }

        $mutation_error = $data['data']['editPost']['message'] ?? null;
        if ( ! empty( $mutation_error ) ) {
            Logger::warning( 'buffer_edit_share_now_failed', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id' => $account_id,
                'error' => $mutation_error,
            ] );
            if ( self::is_buffer_validation_error( $mutation_error ) ) {
                if ( self::delete_buffer_post_to_free_slot( $buffer_post_id, $account_id ) ) {
                    return true;
                }
                self::blacklist_buffer_post( $buffer_post_id, $account_id );
            }
            return false;
        }

        if ( empty( $data['data']['editPost']['post']['id'] ?? '' ) ) {
            Logger::warning( 'buffer_edit_share_now_failed', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id' => $account_id,
                'error' => 'No post data returned',
            ] );
            return false;
        }

        self::invalidate_scheduled_snapshot( $account_id );

        return true;
    }

    /**
     * Delete a broken scheduled Buffer post so its queue slot is actually freed.
     *
     * Used as a fallback when editPost(shareNow) rejects the post with a validation
     * error (missing text/media or missing Facebook type). Those posts can never be
     * published via editPost, and merely blacklisting them leaves them occupying one
     * of the 10 queue slots, which blocks every subsequent share on that channel.
     * Deleting the post removes it from the queue and reclaims the slot. Returns
     * true only when the post was actually deleted by Buffer.
     */
    private static function delete_buffer_post_to_free_slot( string $buffer_post_id, string $account_id = 'default' ): bool {
        $results = self::delete_batched_posts( [ $buffer_post_id ], $account_id );
        $deleted = ! empty( $results[ $buffer_post_id ] );

        if ( $deleted ) {
            Logger::warning( 'buffer_scheduled_post_deleted_to_free_slot', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id'     => $account_id,
            ] );
            self::invalidate_scheduled_snapshot( $account_id );
        } else {
            Logger::warning( 'buffer_scheduled_post_delete_failed', null, [
                'buffer_post_id' => $buffer_post_id,
                'account_id'     => $account_id,
            ] );
        }

        return $deleted;
    }

    /**
     * Detect Buffer-side validation errors that make a scheduled post permanently
     * un-shareable via editPost(shareNow).  Such posts should be skipped on retry.
     */
    private static function is_buffer_validation_error( string $message ): bool {
        $msg = strtolower( $message );
        return strpos( $msg, 'must have either text or media' ) !== false
            || strpos( $msg, 'require a type' ) !== false;
    }

    private static function is_blacklisted_buffer_post( string $buffer_post_id, string $account_id ): bool {
        return isset( self::$unshareable_buffer_post_ids[ $account_id ][ $buffer_post_id ] );
    }

    private static function blacklist_buffer_post( string $buffer_post_id, string $account_id ): void {
        if ( ! isset( self::$unshareable_buffer_post_ids[ $account_id ] ) ) {
            self::$unshareable_buffer_post_ids[ $account_id ] = [];
        }
        self::$unshareable_buffer_post_ids[ $account_id ][ $buffer_post_id ] = true;
        self::invalidate_scheduled_snapshot( $account_id );
    }

    /**
     * Get scheduled-posts channel status from cache (transient), fetching from
     * Buffer only on the first error.  The cache is invalidated on successful
     * shares so that the next error triggers a fresh fetch.
     */
    private static function get_cached_scheduled_status( string $account_id = 'default' ): array {
        $cache_key = self::cache_key( 'ai_collage_buffer_scheduled_status', $account_id );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $status = self::get_channel_scheduled_status( $account_id );
        if ( ! empty( $status ) ) {
            set_transient( $cache_key, $status, self::SCHEDULED_SNAPSHOT_TTL );
        }

        return $status;
    }

    public static function invalidate_scheduled_snapshot( string $account_id = 'default' ): void {
        delete_transient( self::cache_key( 'ai_collage_buffer_scheduled_posts', $account_id ) );
        delete_transient( self::cache_key( 'ai_collage_buffer_scheduled_status', $account_id ) );
    }

    private static function is_queue_limit_error( string $message ): bool {
        $msg = strtolower( trim( $message ) );
        return strpos( $msg, 'limit' ) !== false
            && ( strpos( $msg, 'scheduled' ) !== false || strpos( $msg, 'queue' ) !== false );
    }

    /**
     * Persist a deferred share (wait mode) so it retries when a queue slot frees up.
     *
     * @param string $defer_reason  'queue_full' or 'rate_limited' allow more
     *                              attempts (both are rate-driven, not a fault);
     *                              any other value uses the strict 2-attempt cap.
     */
    public static function defer_pending_share( int $post_id, int $attachment_id, string $account_id, string $earliest_due_at = '', string $defer_reason = '' ): void {
        $pending = get_option( Config::OPTION_BUFFER_PENDING_SHARES, [] );
        if ( ! is_array( $pending ) ) {
            $pending = [];
        }

        $key = $account_id . '|' . $post_id . '|' . $attachment_id;
        $existing_retry_count = isset( $pending[ $key ]['retry_count'] ) ? (int) $pending[ $key ]['retry_count'] : 0;

        $max_attempts = in_array( $defer_reason, [ 'queue_full', 'rate_limited' ], true )
            ? self::PENDING_MAX_RETRY_ATTEMPTS_QUEUE
            : self::PENDING_MAX_RETRY_ATTEMPTS;

        if ( $existing_retry_count >= $max_attempts ) {
            Logger::warning( 'buffer_pending_share_max_retries_reached', null, [
                'post_id'      => (int) $post_id,
                'account_id'   => (string) $account_id,
                'retry_count'  => $existing_retry_count,
                'defer_reason' => $defer_reason,
                'max_attempts' => $max_attempts,
            ] );
            return;
        }

        $retry_at = time() + self::PENDING_RETRY_GRACE_SEC;
        if ( ! empty( $earliest_due_at ) ) {
            try {
                $due_dt = new \DateTime( $earliest_due_at, new \DateTimeZone( 'UTC' ) );
                $retry_at = $due_dt->getTimestamp() + self::PENDING_RETRY_GRACE_SEC;
            } catch ( \Exception $e ) {
                // keep default retry_at
            }
        }

        $pending[ $key ] = [
            'post_id'       => (int) $post_id,
            'attachment_id' => (int) $attachment_id,
            'account_id'    => (string) $account_id,
            'retry_at'      => (int) $retry_at,
            'retry_count'   => $existing_retry_count,
            // AUDIT F5: persist the reason so retry_pending_shares() can pick
            // the matching cap (queue_full / rate_limited use 5 attempts,
            // anything else uses 2). Without this, an entry persisted with
            // defer_reason='rate_limited' would be re-capped at 2 by the
            // generic >= PENDING_MAX_RETRY_ATTEMPTS check.
            'defer_reason'  => $defer_reason,
        ];

        if ( count( $pending ) > self::PENDING_SHARES_MAX ) {
            uasort( $pending, function ( $a, $b ) {
                return (int) ( $a['retry_at'] ?? 0 ) <=> (int) ( $b['retry_at'] ?? 0 );
            } );
            $pending = array_slice( $pending, 0, self::PENDING_SHARES_MAX, true );
        }

        update_option( Config::OPTION_BUFFER_PENDING_SHARES, $pending );

        Logger::warning( 'buffer_pending_share_deferred', null, [
            'post_id' => (int) $post_id,
            'account_id' => (string) $account_id,
            'retry_at' => (int) $retry_at,
            'earliest_due_at' => $earliest_due_at,
            'retry_count' => $existing_retry_count,
        ] );
    }

    /**
     * Process due pending shares (called by the ACTION_RETRY_BUFFER_PENDING cron action).
     * A pending entry is removed once the share succeeds for at least one channel —
     * if it is still fully blocked, share() re-defers it with an updated retry time.
     */
    public static function retry_pending_shares(): void {
        $pending = get_option( Config::OPTION_BUFFER_PENDING_SHARES, [] );
        if ( ! is_array( $pending ) || empty( $pending ) ) {
            return;
        }

        $now = time();
        $due = [];
        foreach ( $pending as $key => $entry ) {
            if ( (int) ( $entry['retry_at'] ?? 0 ) <= $now ) {
                $due[ $key ] = $entry;
            }
        }

        if ( empty( $due ) ) {
            return;
        }

        foreach ( $due as $key => $entry ) {
            $post_id = (int) ( $entry['post_id'] ?? 0 );
            $attachment_id = (int) ( $entry['attachment_id'] ?? 0 );
            $account_id = (string) ( $entry['account_id'] ?? 'default' );
            $retry_count = (int) ( $entry['retry_count'] ?? 0 );
            // AUDIT F5: honor the entry's own defer_reason when picking the cap.
            // queue_full / rate_limited entries were persisted with the higher
            // PENDING_MAX_RETRY_ATTEMPTS_QUEUE budget; without this lookup,
            // retry_pending_shares() would give up after 2 attempts and the
            // post would be silently abandoned despite the higher budget.
            $entry_defer_reason = (string) ( $entry['defer_reason'] ?? '' );
            $max_attempts = in_array( $entry_defer_reason, [ 'queue_full', 'rate_limited' ], true )
                ? self::PENDING_MAX_RETRY_ATTEMPTS_QUEUE
                : self::PENDING_MAX_RETRY_ATTEMPTS;

            if ( $post_id <= 0 || ! get_post( $post_id ) ) {
                unset( $pending[ $key ] );
                continue;
            }

            if ( $retry_count >= $max_attempts ) {
                Logger::warning( 'buffer_pending_share_giving_up', null, [
                    'post_id'      => $post_id,
                    'account_id'   => $account_id,
                    'retry_count'  => $retry_count,
                    'defer_reason' => $entry_defer_reason,
                    'max_attempts' => $max_attempts,
                ] );
                unset( $pending[ $key ] );
                continue;
            }

            Logger::info( 'buffer_pending_share_retry', null, [
                'post_id' => $post_id,
                'account_id' => $account_id,
                'retry_count' => $retry_count,
            ], '200' );

            if ( self::share( $post_id, $attachment_id, $account_id ) ) {
                unset( $pending[ $key ] );
                Logger::info( 'buffer_pending_share_success', null, [
                    'post_id' => $post_id,
                    'account_id' => $account_id,
                ], '200', 'Deferred Buffer share for post ' . $post_id . ' completed after a queue slot freed up.' );
            } else {
                $new_retry_count = $retry_count + 1;
                $backoff_seconds = self::PENDING_RETRY_GRACE_SEC * pow( 2, $retry_count );
                $pending[ $key ]['retry_count'] = $new_retry_count;
                $pending[ $key ]['retry_at'] = $now + $backoff_seconds;
                Logger::warning( 'buffer_pending_share_still_blocked', null, [
                    'post_id' => $post_id,
                    'account_id' => $account_id,
                    'retry_count' => $new_retry_count,
                    'backoff_seconds' => $backoff_seconds,
                ] );
            }
        }

        update_option( Config::OPTION_BUFFER_PENDING_SHARES, $pending );
    }

    public static function invalidate_draft_count_cache( string $account_id = '' ): void {
        if ( $account_id !== '' ) {
            delete_transient( self::cache_key( 'ai_collage_buffer_draft_count', $account_id ) );
            return;
        }
        delete_transient( 'ai_collage_buffer_draft_count' );
    }

    public static function delete_all_buffer_drafts( string $account_id = '' ): array {
        if ( $account_id !== '' ) {
            return self::delete_account_buffer_drafts( $account_id );
        }
        $accounts = Config::get_active_buffer_accounts();
        $total_deleted = 0;
        $total_failed  = 0;
        $total_found   = 0;
        if ( ! empty( $accounts ) ) {
            foreach ( $accounts as $acct_id => $acct ) {
                $result = self::delete_account_buffer_drafts( $acct_id );
                $total_deleted += $result['deleted'];
                $total_failed  += $result['failed'];
                $total_found   += $result['total'];
            }
        } else {
            $result = self::delete_account_buffer_drafts( 'default' );
            $total_deleted = $result['deleted'];
            $total_failed  = $result['failed'];
            $total_found   = $result['total'];
        }
        return [ 'deleted' => $total_deleted, 'failed' => $total_failed, 'total' => $total_found ];
    }

    private static function delete_account_buffer_drafts( string $account_id ): array {
        $drafts = self::get_draft_posts_from_buffer( $account_id );
        if ( empty( $drafts ) ) {
            return [ 'deleted' => 0, 'failed' => 0, 'total' => 0 ];
        }

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 );
        }
        if ( function_exists( 'ignore_user_abort' ) ) {
            @ignore_user_abort( true );
        }

        $deleted = 0;
        $failed = 0;
        $total = count( $drafts );
        $start_time = time();
        $max_runtime = 240;

        $chunks = array_chunk( $drafts, 20 );

        foreach ( $chunks as $chunk ) {
            if ( ( time() - $start_time ) > $max_runtime ) {
                Logger::warning( 'buffer_drafts_delete_timeout', null, [
                    'deleted' => $deleted,
                    'remaining' => $total - $deleted - $failed,
                ] );
                break;
            }

            $ids = array_column( $chunk, 'id' );
            $results = self::delete_batched_posts( $ids, $account_id );

            foreach ( $chunk as $draft ) {
                $buffer_post_id = $draft['id'];
                if ( ! empty( $results[ $buffer_post_id ] ) ) {
                    $deleted++;
                    Logger::debug( 'buffer_draft_deleted_manual', null, [
                        'buffer_post_id' => $buffer_post_id,
                        'text_preview' => mb_substr( $draft['text'], 0, 50 ),
                    ] );
                } else {
                    $failed++;
                    Logger::warning( 'buffer_draft_delete_failed_manual', null, [
                        'buffer_post_id' => $buffer_post_id,
                    ] );
                }
            }

            usleep( 1100000 ); // Respect rate limits between batches
        }

        self::cleanup_local_share_metadata();
        self::invalidate_draft_count_cache( $account_id );

        Logger::info( 'buffer_drafts_manual_delete_complete', null, [
            'deleted' => $deleted,
            'failed' => $failed,
            'total' => $total,
            'account_id' => $account_id,
        ], '200', 'Manually deleted ' . $deleted . ' of ' . $total . ' Buffer drafts for account ' . $account_id );

        return [ 'deleted' => $deleted, 'failed' => $failed, 'total' => $total ];
    }

    public static function cleanup_old_drafts( int $retention_days = 2 ): int {
        if ( ! Config::is_buffer_enabled() ) {
            Logger::debug( 'buffer_cleanup_disabled', null, [ 'retention_days' => $retention_days ] );
            return 0;
        }

        $cutoff = time() - ( $retention_days * DAY_IN_SECONDS );
        Logger::info( 'buffer_cleanup_starting', null, [
            'retention_days' => $retention_days,
            'cutoff_timestamp' => $cutoff,
            'cutoff_gmt' => gmdate( 'Y-m-d H:i:s', $cutoff ),
        ], '200', 'Starting Buffer draft cleanup with retention ' . $retention_days . ' days' );

        $accounts = Config::get_active_buffer_accounts();
        if ( empty( $accounts ) ) {
            $accounts = [ 'default' => [ 'id' => 'default' ] ];
        }

        $total_deleted = 0;
        foreach ( $accounts as $acct_id => $acct ) {
            $total_deleted += self::cleanup_account_old_drafts( $acct_id, $cutoff );
        }

        if ( $total_deleted > 0 ) {
            self::cleanup_local_share_metadata();
        }

        Logger::debug( 'buffer_drafts_cleanup_complete', null, [
            'deleted_count' => $total_deleted,
            'retention_days' => $retention_days,
        ] );

        return $total_deleted;
    }

    private static function cleanup_account_old_drafts( string $account_id, int $cutoff ): int {
        $drafts = self::get_draft_posts_from_buffer( $account_id );
        if ( empty( $drafts ) ) {
            return 0;
        }

        $to_delete = [];
        foreach ( $drafts as $draft ) {
            $created_at = $draft['created_at'] ?? '';
            if ( ! empty( $created_at ) ) {
                try {
                    $created_dt = new \DateTime( $created_at, new \DateTimeZone( 'UTC' ) );
                    $created_timestamp = $created_dt->getTimestamp();
                } catch ( \Exception $e ) {
                    $created_timestamp = false;
                }

                if ( $created_timestamp !== false && $created_timestamp > $cutoff ) {
                    continue;
                }
            }
            $to_delete[] = $draft;
        }

        if ( empty( $to_delete ) ) {
            return 0;
        }

        $deleted = 0;
        $chunks = array_chunk( $to_delete, 20 );

        foreach ( $chunks as $chunk ) {
            $ids = array_column( $chunk, 'id' );
            $results = self::delete_batched_posts( $ids, $account_id );

            foreach ( $chunk as $draft ) {
                $buffer_post_id = $draft['id'];
                if ( ! empty( $results[ $buffer_post_id ] ) ) {
                    $deleted++;
                    Logger::info( 'buffer_draft_deleted', null, [
                        'buffer_post_id' => $buffer_post_id,
                        'created_at' => $draft['created_at'] ?? '',
                        'account_id' => $account_id,
                    ], '200', 'Deleted old Buffer draft ' . $buffer_post_id . ' (account: ' . $account_id . ')' );
                }
            }

            usleep( 1100000 );
        }

        if ( $deleted > 0 ) {
            self::invalidate_draft_count_cache( $account_id );
        }

        return $deleted;
    }

    private static function cleanup_local_share_metadata(): void {
        $args = [
            'post_type'      => 'post',
            'post_status'    => 'any',
            'posts_per_page' => 200,
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'     => Config::META_BUFFER_SHARE_HISTORY,
                    'compare' => 'EXISTS',
                ],
            ],
        ];

        $posts = get_posts( $args );
        foreach ( $posts as $wp_post_id ) {
            $history = get_post_meta( $wp_post_id, Config::META_BUFFER_SHARE_HISTORY, true );
            if ( ! is_array( $history ) || empty( $history ) ) {
                continue;
            }

            $filtered = array_filter( $history, function ( $entry ) {
                $mode = $entry['mode'] ?? '';
                return $mode !== 'draft';
            } );

            if ( empty( $filtered ) ) {
                delete_post_meta( $wp_post_id, Config::META_BUFFER_SHARE_HISTORY );
            } elseif ( count( $filtered ) !== count( $history ) ) {
                update_post_meta( $wp_post_id, Config::META_BUFFER_SHARE_HISTORY, array_values( $filtered ) );
            }
        }
    }

    private static function get_hashtags( int $post_id ): string {
        $generated = get_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, true );
        if ( is_array( $generated ) && ! empty( $generated ) ) {
            $clean = [];
            foreach ( $generated as $tag ) {
                $tag = trim( $tag );
                $tag = ltrim( $tag, '#' );
                $tag = preg_replace( '/[^\p{L}\p{N}_]/u', '', $tag );
                if ( ! empty( $tag ) && mb_strlen( $tag, 'UTF-8' ) >= 2 ) {
                    $clean[] = '#' . $tag;
                }
            }
            if ( ! empty( $clean ) ) {
                return "\xE2\x80\x8E" . implode( ' ', array_slice( array_unique( $clean ), 0, 5 ) );
            }
        }

        $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
        if ( is_array( $auto_meta ) && ! empty( $auto_meta['ai_hashtags'] ) ) {
            $clean = [];
            foreach ( $auto_meta['ai_hashtags'] as $tag ) {
                $tag = trim( $tag );
                $tag = ltrim( $tag, '#' );
                $tag = preg_replace( '/[^\p{L}\p{N}_]/u', '', $tag );
                if ( ! empty( $tag ) && mb_strlen( $tag, 'UTF-8' ) >= 2 ) {
                    $clean[] = '#' . $tag;
                }
            }
            if ( ! empty( $clean ) ) {
                return "\xE2\x80\x8E" . implode( ' ', array_slice( array_unique( $clean ), 0, 5 ) );
            }
        }

        return '';
    }

    private static function build_metadata_graphql( array $metadata ): string {
        $parts = [];
        foreach ( $metadata as $key => $value ) {
            if ( is_array( $value ) ) {
                $inner = [];
                foreach ( $value as $k => $v ) {
                    // 'type' and 'privacy' are GraphQL enums and must be sent
                    // unquoted (privacy: private), not as JSON strings.
                    if ( ( $k === 'type' || $k === 'privacy' ) && is_string( $v ) && ! is_numeric( $v ) ) {
                        $inner[] = $k . ': ' . $v;
                    } elseif ( is_bool( $v ) ) {
                        $inner[] = $k . ': ' . ( $v ? 'true' : 'false' );
                    } elseif ( is_array( $v ) ) {
                        $nested = [];
                        foreach ( $v as $nk => $nv ) {
                            if ( is_bool( $nv ) ) {
                                $nested[] = $nk . ': ' . ( $nv ? 'true' : 'false' );
                            } elseif ( is_string( $nv ) ) {
                                $nested[] = $nk . ': "' . self::graphql_escape( $nv ) . '"';
                            }
                        }
                        if ( ! empty( $nested ) ) {
                            $inner[] = $k . ': { ' . implode( ', ', $nested ) . ' }';
                        }
                    } elseif ( is_string( $v ) ) {
                        $inner[] = $k . ': "' . self::graphql_escape( $v ) . '"';
                    }
                }
                if ( ! empty( $inner ) ) {
                    $parts[] = $key . ': { ' . implode( ', ', $inner ) . ' }';
                }
            } elseif ( is_bool( $value ) ) {
                $parts[] = $key . ': ' . ( $value ? 'true' : 'false' );
            } elseif ( is_string( $value ) ) {
                $parts[] = $key . ': "' . self::graphql_escape( $value ) . '"';
            }
        }
        return ! empty( $parts ) ? 'metadata: { ' . implode( ', ', $parts ) . ' }' : '';
    }

    /**
     * Reformat a raw YouTube description so that the channel link and the
     * hashtag block each sit on their own line, separated from the rest by a
     * blank line. The AI is instructed to emit newline-separated sections, but
     * this guard guarantees the link (http(s)://...) and the trailing #hashtags
     * never end up glued to the prose on a single line regardless of model
     * output. Real newlines already produced by the AI are preserved.
     */
    private static function format_yt_description( string $description ): string {
        $description = trim( $description );
        if ( $description === '' ) {
            return $description;
        }

        // Split the trailing hashtag block off so it always lands on its own line.
        $hashtags = '';
        if ( preg_match( '/^(.*?)(\s+#\S+(?:\s+#\S+)*)$/us', $description, $m ) ) {
            $description = trim( $m[1] );
            $hashtags    = trim( $m[2] );
        }

        // Force the channel link onto its own line (blank-line padding).
        $description = preg_replace( '/\s*(https?:\/\/\S+)\s*/u', "\n\n$1", $description );

        // Collapse runs of 3+ newlines and re-trim.
        $description = preg_replace( "/\n{3,}/", "\n\n", trim( $description ) );

        $segments = array_values( array_filter( array_map( 'trim', preg_split( '/\n+/', $description ) ), 'strlen' ) );
        $out       = implode( "\n\n", $segments );

        if ( $hashtags !== '' ) {
            $out .= ( $out !== '' ? "\n\n" : '' ) . $hashtags;
        }

        return $out;
    }

    private static function normalize_text( string $text ): string {
        $text = str_replace( [ "\r\n", "\r" ], "\n", $text );
        $text = preg_replace( '/(?<!\\\\)\\\\n/', "\n", $text );
        $text = preg_replace( "/\n{3,}/", "\n\n", $text );
        if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
            $text = mb_convert_encoding( $text, 'UTF-8', 'UTF-8' );
        }
        return $text;
    }

    private static function graphql_escape( string $value ): string {
        return str_replace(
            [ '\\', '"', "\n", "\r" ],
            [ '\\\\', '\\"', '\\n', '\\r' ],
            $value
        );
    }

    /**
     * Detect whether the attachment is video content.
     *
     * Checks META_CONTENT_TYPE first (set by VideoRenderer), then falls back to MIME type.
     */
    private static function is_video_attachment( int $attachment_id ): bool {
        if ( $attachment_id <= 0 ) {
            return false;
        }

        $content_type = get_post_meta( $attachment_id, Config::META_CONTENT_TYPE, true );
        if ( $content_type === Config::CONTENT_TYPE_VIDEO ) {
            return true;
        }

        $mime = get_post_mime_type( $attachment_id );
        if ( ! empty( $mime ) && strpos( $mime, 'video/' ) === 0 ) {
            return true;
        }

        return false;
    }

    /**
     * Map content type to the correct Buffer post type per service.
     *
     * For video content:
     *   - facebook/instagram → 'reel'
     *   - youtube/tiktok     → 'video'
     *   - others             → 'post' (no video-specific type)
     *
     * For image content, returns the user-configured post_type unchanged.
     */
    private static function resolve_post_type_for_content( string $service, string $configured_type, bool $is_video ): string {
        if ( ! $is_video ) {
            return $configured_type;
        }

        $video_type_map = [
            'facebook'  => 'reel',
            'instagram' => 'reel',
            'youtube'   => 'video',
            'tiktok'    => 'video',
        ];

        return $video_type_map[ $service ] ?? $configured_type;
    }

    // AUDIT F5: hard ceiling for the inline retry sleep.
    //
    // Buffer's `Retry-After` header can be many HOURS long (e.g. 74218s ≈ 20h
    // is what production logs show on 429 storms). Sleeping for that long
    // inside a single PHP request — which is what the original code did —
    // freezes the worker, kills the WP request at its own timeout, and the
    // per-job `defer_pending_share()` call is never reached. The post is
    // silently abandoned.
    //
    // Cap the inline sleep to 30s. If Buffer's hint is longer, do NOT sleep
    // inline; instead break out of the retry loop immediately and return the
    // 429 to the caller, which will then call `defer_pending_share()` and the
    // post is retried by the 5-minute `ACTION_RETRY_BUFFER_PENDING` cron.
    const RETRY_SLEEP_CEILING_US = 30_000_000; // 30 seconds

    private static function api_request( array $args, string $context_label = 'api_request' ): array {
        $attempt = 0;
        $last_status_code = 0;
        $last_error_message = '';
        $body = '';
        $response = null;

        while ( $attempt < self::MAX_RETRY_ATTEMPTS ) {
            $attempt++;

            $response = wp_remote_post( self::API_BASE, $args );

            if ( is_wp_error( $response ) ) {
                $last_error_message = $response->get_error_message();
                Logger::warning( 'buffer_' . $context_label . '_wp_error', null, [
                    'attempt' => $attempt,
                    'error'   => $last_error_message,
                ] );

                if ( $attempt < self::MAX_RETRY_ATTEMPTS ) {
                    $delay_us = self::RETRY_BASE_DELAY_US * ( 1 << ( $attempt - 1 ) );
                    if ( $delay_us > self::RETRY_SLEEP_CEILING_US ) {
                        // Inline sleep is too long; bail so defer_pending_share
                        // can retry later via the cron.
                        Logger::warning( 'buffer_' . $context_label . '_sleep_ceiling_bail', null, [
                            'attempt'    => $attempt,
                            'delay_us'   => $delay_us,
                            'ceiling_us' => self::RETRY_SLEEP_CEILING_US,
                            'reason'     => 'inline_retry_would_exceed_ceiling',
                        ] );
                        break;
                    }
                    usleep( $delay_us );
                    continue;
                }
                break;
            }

            $last_status_code = (int) wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );

            if ( $last_status_code === 429 || $last_status_code === 503 || $last_status_code >= 500 ) {
                $retry_after_header = wp_remote_retrieve_header( $response, 'retry-after' );
                $delay_us = 0;

                if ( is_numeric( $retry_after_header ) ) {
                    $delay_us = (int) $retry_after_header * 1000000;
                } else {
                    $delay_us = self::RETRY_BASE_DELAY_US * ( 1 << ( $attempt - 1 ) );
                }

                Logger::warning( 'buffer_' . $context_label . '_rate_limited', null, [
                    'attempt'               => $attempt,
                    'status_code'           => $last_status_code,
                    'retry_after_seconds'   => is_numeric( $retry_after_header ) ? (int) $retry_after_header : null,
                    'backoff_us'            => $delay_us,
                ] );

                if ( $attempt < self::MAX_RETRY_ATTEMPTS ) {
                    if ( $delay_us > self::RETRY_SLEEP_CEILING_US ) {
                        // Inline retry would block the request for too long.
                        // Bail with the 429 so the caller can defer.
                        Logger::warning( 'buffer_' . $context_label . '_sleep_ceiling_bail', null, [
                            'attempt'             => $attempt,
                            'delay_us'            => $delay_us,
                            'ceiling_us'          => self::RETRY_SLEEP_CEILING_US,
                            'status_code'         => $last_status_code,
                            'retry_after_seconds' => is_numeric( $retry_after_header ) ? (int) $retry_after_header : null,
                            'reason'              => 'inline_retry_would_exceed_ceiling',
                        ] );
                        break;
                    }
                    usleep( $delay_us );
                    continue;
                }
            }

            break;
        }

        return [
            'body'          => $body,
            'status_code'   => $last_status_code,
            'wp_error'      => $last_error_message !== '',
            'error_message' => $last_error_message,
        ];
    }

}
