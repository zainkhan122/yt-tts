<?php
/**
 * Uninstall Handler for News MCQ Generator Plugin
 * * This file runs when the plugin is uninstalled via WordPress admin.
 * It handles cleanup based on user preferences.
 *
 * @FIX: Removed a stray closing brace '}' at the end of the file.
 * @FIX: Removed potential UTF-8 BOM and leading whitespace.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Get user preference for preserving settings
$preserve_settings = get_option('nm_preserve_settings_on_uninstall', 'yes');

// Only delete settings if user explicitly chose to remove them
if ($preserve_settings !== 'yes') {
    
    // ========================================
    // DELETE ALL PLUGIN OPTIONS
    // ========================================
    
    // Main settings array
    delete_option('nm_settings');
    
    // Individual API keys and configurations
    delete_option('nm_gemini_api_key');
    delete_option('nm_gnews_api_key');
    delete_option('nm_news_country');
    delete_option('nm_news_categories');
    
    // Cron schedules
    delete_option('nm_cron_schedule');
    delete_option('nm_topic_cron_schedule');
    
    // Feed importer settings
    delete_option('nm_mcq_feed_url');
    
    // Topic generation settings
    delete_option('nm_topic_list_ids');
    delete_option('nm_topic_mcq_count');
    
    // Duplicate detection settings
    delete_option('nm_similarity_threshold');
    delete_option('nm_duplicate_action');
    
    // Email digest settings
    delete_option('nm_email_digest_enabled');
    delete_option('nm_email_digest_frequency');
    delete_option('nm_email_digest_time');
    
    // Advanced settings
    delete_option('nm_cache_duration');
    delete_option('nm_enable_optimizer');
    delete_option('nm_max_questions_per_topic');
    
} else {
    // Keep settings but log that they were preserved
    error_log('MCQ Generator: Settings preserved on uninstall (user preference)');
}

// ========================================
// ALWAYS CLEAN TEMPORARY DATA
// ========================================

// Clear temporary processing flags
delete_option('nm_next_category_index');
delete_option('nm_last_processed_topic_index');
delete_option('nm_optimizer_initial_sync_done');
delete_option('nm_last_cron_run');
delete_option('nm_generation_in_progress');

// Clear all transients (temporary cache data)
global $wpdb;
$wpdb->query( $wpdb->prepare(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
    $wpdb->esc_like('_transient_nm_') . '%',
    $wpdb->esc_like('_transient_timeout_nm_') . '%'
) );

// ========================================
// DROP CUSTOM DATABASE TABLES
// ========================================

// Check if user wants to remove database tables
$remove_tables = get_option('nm_remove_tables_on_uninstall', 'no');

if ($remove_tables === 'yes') {
    $nm_tables_to_drop = array(
        'nm_mcq_data',
        'mcq_embeddings',
        'nm_subscribers',
        'nm_security_log',
        'nm_generation_runs',
        'nm_generation_events',
        'nm_rate_limits',
        'nm_points_log',
        'nm_user_answers',
        'nm_certificates',
        'nm_notifications',
        'nm_user_sessions',
        'nm_quiz_sessions',
        'nm_question_usage',
    );
    foreach ($nm_tables_to_drop as $nm_table) {
        $wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS %i", $wpdb->prefix . $nm_table ) );
    }
    
    error_log('MCQ Generator: Custom database tables removed on uninstall');
} else {
    error_log('MCQ Generator: Custom database tables preserved on uninstall (user preference)');
}

// ========================================
// DELETE ALL MCQ POSTS (OPTIONAL)
// ========================================

$delete_posts = get_option('nm_delete_posts_on_uninstall', 'no');

if ($delete_posts === 'yes') {
    // Get all MCQ posts
    $mcq_posts = get_posts([
        'post_type' => 'mcq',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'fields' => 'ids'
    ]);
    
    // Delete each post permanently
    foreach ($mcq_posts as $post_id) {
        wp_delete_post($post_id, true); // Force delete
    }
    
    // Delete topic taxonomy terms
    $terms = get_terms([
        'taxonomy' => 'topic',
        'hide_empty' => false,
        'fields' => 'ids'
    ]);
    
    foreach ($terms as $term_id) {
        wp_delete_term($term_id, 'topic');
    }
    
    error_log('MCQ Generator: All MCQ posts and topics deleted on uninstall');
} else {
    error_log('MCQ Generator: MCQ posts and topics preserved on uninstall (user preference)');
}

// ========================================
// CLEAR SCHEDULED CRON JOBS
// ========================================

// Clear all plugin cron jobs
$nm_cron_hooks = array(
    'nm_generate_mcqs_cron',
    'nm_generate_mcqs_from_topics_cron',
    'nm_feed_import_cron',
    'nm_generate_current_affairs_mcq_cron',
    'nm_ca_queue_worker_cron',
    'nm_current_affairs_cron_hook',
    'nm_current_affairs_queue_worker_cron',
    'nm_initial_sync_cron',
    'nm_weekly_db_cleanup',
    'nm_monthly_buffer_history_cleanup',
    'nm_cleanup_rate_limits_cron',
    'nm_cleanup_notifications_cron',
    'nm_cleanup_security_logs_cron',
    'nm_daily_story_image_cleanup',
    'nm_recalculate_leaderboards_cron',
    'nm_email_digest_cron',
    'nm_send_daily_digest',
    'nm_embedding_backfill_cron',
    'nm_cleanup_old_mcqs_cron',
    'nm_generate_social_image_cron',
);
foreach ($nm_cron_hooks as $nm_hook) {
    wp_clear_scheduled_hook($nm_hook);
}

// ========================================
// DELETE USER META (OPTIONAL)
// ========================================

$delete_user_data = get_option('nm_delete_user_data_on_uninstall', 'no');

if ($delete_user_data === 'yes') {
    // Delete user MCQ history
    $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s", 'nm_mcq_history' ) );
    
    // Delete user preferences
    $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s", $wpdb->esc_like('nm_') . '%' ) );
    
    error_log('MCQ Generator: User data deleted on uninstall');
}

// Final cleanup message
error_log('MCQ Generator: Plugin uninstalled successfully');

// Flush rewrite rules one last time
flush_rewrite_rules();
