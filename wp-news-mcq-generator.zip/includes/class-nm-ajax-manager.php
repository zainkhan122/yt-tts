<?php
if (! defined('ABSPATH')) {
	exit;
}

/**
 * AJAX Manager Class (Refactored)
 * Version: 4.0
 *
 * This class is now responsible ONLY for registering all AJAX hooks.
 * The handler functions have been moved to:
 * - NM_AJAX_Frontend
 * - NM_AJAX_Dashboard
 * - NM_AJAX_Admin
 */

class NM_AJAX_Manager
{



	/**
	 * Initialize all AJAX hooks.
	 */
	public static function init()
	{
		// ============================================================================
		// Frontend MCQ Handlers (NM_AJAX_Frontend)
		// ============================================================================
		add_action('wp_ajax_fetch_mcqs', array('NM_AJAX_Frontend', 'nm_fetch_mcqs_callback'));
		add_action('wp_ajax_nopriv_fetch_mcqs', array('NM_AJAX_Frontend', 'nm_fetch_mcqs_callback'));
		add_action('wp_ajax_fetch_sub_topics', array('NM_AJAX_Frontend', 'nm_fetch_sub_topics_callback'));
		add_action('wp_ajax_nopriv_fetch_sub_topics', array('NM_AJAX_Frontend', 'nm_fetch_sub_topics_callback'));
		add_action('wp_ajax_report_mcq', array('NM_AJAX_Frontend', 'nm_report_mcq_callback'));
		add_action('wp_ajax_nopriv_report_mcq', array('NM_AJAX_Frontend', 'nm_report_mcq_callback'));
		add_action('wp_ajax_nm_load_more_mcqs', array('NM_AJAX_Frontend', 'nm_ajax_load_more_mcqs'));
		add_action('wp_ajax_nopriv_nm_load_more_mcqs', array('NM_AJAX_Frontend', 'nm_ajax_load_more_mcqs'));

		// ============================================================================
		// Quiz Shortcode Handlers (NM_AJAX_Frontend)
		// ============================================================================
		add_action('wp_ajax_nm_search_topics', array('NM_AJAX_Frontend', 'nm_search_topics_callback'));
		add_action('wp_ajax_nopriv_nm_search_topics', array('NM_AJAX_Frontend', 'nm_search_topics_callback'));
		add_action('wp_ajax_nm_generate_quiz', array('NM_AJAX_Frontend', 'nm_generate_quiz_callback'));
		add_action('wp_ajax_nopriv_nm_generate_quiz', array('NM_AJAX_Frontend', 'nm_generate_quiz_callback'));
		add_action('wp_ajax_nm_log_quiz_activity', array('NM_AJAX_Frontend', 'nm_log_quiz_activity_handler'));

		// ============================================================================
		// Unified Answer Tracking (NM_AJAX_Frontend)
		// ============================================================================
		add_action('wp_ajax_track_answer', array('NM_AJAX_Frontend', 'nm_track_answer_callback'));

		// ============================================================================
		// User Dashboard & Settings Handlers (NM_AJAX_Dashboard)
		// ============================================================================
		add_action('wp_ajax_nm_update_user_profile', array('NM_AJAX_Dashboard', 'nm_update_user_profile_handler'));
		add_action('wp_ajax_nm_change_user_password', array('NM_AJAX_Dashboard', 'nm_change_user_password_handler'));
		add_action('wp_ajax_nm_delete_user_account', array('NM_AJAX_Dashboard', 'nm_delete_user_account_handler'));
		add_action('wp_ajax_nm_get_recent_activity', array('NM_AJAX_Dashboard', 'nm_ajax_get_recent_activity'));
		add_action('wp_ajax_nm_get_performance_chart', array('NM_AJAX_Dashboard', 'nm_ajax_get_performance_chart'));
		add_action('wp_ajax_nm_get_topic_progress', array('NM_AJAX_Dashboard', 'nm_ajax_get_topic_progress'));

		// ============================================================================
		// Admin Dashboard Handlers (NM_AJAX_Admin)
		// ============================================================================
		add_action('wp_ajax_nm_get_dashboard_stats', array('NM_AJAX_Admin', 'nm_get_dashboard_stats'));
		add_action('wp_ajax_nm_get_duplicate_stats', array('NM_AJAX_Admin', 'nm_get_duplicate_stats'));
		add_action('wp_ajax_nm_get_activity_stats', array('NM_AJAX_Admin', 'nm_get_activity_stats'));
		add_action('wp_ajax_nm_get_activity_log', array('NM_AJAX_Admin', 'nm_get_activity_log'));
		add_action('wp_ajax_nm_get_system_health', array('NM_AJAX_Admin', 'nm_get_system_health'));
		add_action('wp_ajax_nm_get_top_topics', array('NM_AJAX_Admin', 'nm_get_top_topics'));
		add_action('wp_ajax_nm_get_reported_mcqs', array('NM_AJAX_Admin', 'nm_get_reported_mcqs'));
		add_action('wp_ajax_nm_clear_activity_log', array('NM_AJAX_Admin', 'nm_clear_activity_log'));
		add_action('wp_ajax_nm_get_blueprint_stats', array('NM_AJAX_Admin', 'nm_get_blueprint_stats')); // ✅ NEW
		add_action('wp_ajax_nm_get_buffer_stats', array('NM_AJAX_Admin', 'nm_get_buffer_stats')); // ✅ Buffer Dashboard
		add_action('wp_ajax_nm_refresh_buffer_channels', array('NM_AJAX_Admin', 'nm_refresh_buffer_channels')); // ✅ Buffer Refresh
		add_action('wp_ajax_nm_ajax_reset_stuck_crons', array('NM_AJAX_Admin', 'nm_ajax_reset_stuck_crons')); // ✅ Fix Handler

		// ============================================================================
		// Admin Generation & Backfill Handlers (NM_AJAX_Admin)
		// ============================================================================
		add_action('wp_ajax_nm_run_generation_for_category', array('NM_AJAX_Admin', 'nm_run_generation_for_category_callback'));
		add_action('wp_ajax_nm_run_generation_for_topic', array('NM_AJAX_Admin', 'nm_run_generation_for_topic_callback'));
		add_action('wp_ajax_nm_get_mcqs_without_embedding', array('NM_AJAX_Admin', 'nm_get_mcqs_without_embedding_callback'));
		add_action('wp_ajax_nm_backfill_single_embedding', array('NM_AJAX_Admin', 'nm_backfill_single_embedding_callback'));
		add_action('wp_ajax_nm_migrate_embeddings', array('NM_AJAX_Admin', 'nm_migrate_embeddings_callback'));
		add_action('wp_ajax_nm_get_embedding_stats', array('NM_AJAX_Admin', 'nm_get_embedding_stats_callback'));
		add_action('wp_ajax_nm_cleanup_orphaned_embeddings', array('NM_AJAX_Admin', 'nm_cleanup_orphaned_embeddings_callback'));
		add_action('wp_ajax_nm_truncate_embeddings', array('NM_AJAX_Admin', 'nm_truncate_embeddings_callback'));
		add_action('wp_ajax_nm_backfill_eat_data', array('NM_AJAX_Admin', 'nm_backfill_eat_data_callback'));

		// ============================================================================
		// Admin Tool Handlers (NM_AJAX_Admin)
		// ============================================================================
		add_action('wp_ajax_nm_run_feed_import', array('NM_AJAX_Admin', 'nm_run_feed_import_callback'));
		add_action('wp_ajax_nm_scan_batch', array('NM_AJAX_Admin', 'ajax_scan_batch_handler'));
		add_action('wp_ajax_nm_consolidate_duplicates', array('NM_AJAX_Admin', 'ajax_consolidate_duplicates_handler'));
		add_action('wp_ajax_nm_test_news_sources', array('NM_AJAX_Admin', 'nm_test_news_sources_callback'));
		add_action('wp_ajax_nm_sync_post_authors', array('NM_AJAX_Admin', 'nm_sync_post_authors_callback'));
		add_action('wp_ajax_nm_assign_random_authors', array('NM_AJAX_Admin', 'nm_assign_random_authors_callback'));
		// @NEW 9.5.5: Convert generated posts to Gutenberg blocks (batched migration).
		add_action('wp_ajax_nm_convert_blocks', array('NM_AJAX_Admin', 'nm_convert_blocks_callback'));
		add_action('wp_ajax_nm_run_daily_roundup', array('NM_AJAX_Admin', 'nm_run_daily_roundup_callback'));
		add_action('wp_ajax_nm_run_pdf_archive', array('NM_AJAX_Admin', 'nm_run_pdf_archive_callback'));

		// ============================================================================
		// Content Calendar AJAX (NM_AJAX_Admin)
		// ============================================================================
		add_action('wp_ajax_nm_bulk_generate_batch', array('NM_AJAX_Admin', 'nm_bulk_generate_batch'));

		// ============================================================================
		// ✅ NEW: Dedicated Logs Page AJAX (NM_AJAX_Admin)
		//   - list  -> paginated, filtered rows from nm_generation_events
		//   - stats -> severity breakdown + retention window
		//   - purge -> retention-window or full truncate (mode=all)
		//   - download -> CSV stream (file stream, returns content-disposition)
		// ============================================================================
		add_action('wp_ajax_nm_get_logs_page', array('NM_AJAX_Admin', 'nm_get_logs_page'));
		add_action('wp_ajax_nm_get_logs_stats', array('NM_AJAX_Admin', 'nm_get_logs_stats'));
		add_action('wp_ajax_nm_purge_logs', array('NM_AJAX_Admin', 'nm_purge_logs'));
		add_action('wp_ajax_nm_download_logs_csv', array('NM_AJAX_Admin', 'nm_download_logs_csv'));

	// Dashboard Integration
	add_action('wp_ajax_nm_generate_dashboard_key', array('NM_AJAX_Admin', 'nm_generate_dashboard_key'));
	}

	// All handler functions have been moved to the new classes.
	// This file now only contains the init() method.
}
