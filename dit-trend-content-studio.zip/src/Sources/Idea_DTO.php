<?php

/**
 * Idea Data Transfer Object
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New file for sourcing layer
 */

namespace DIT\TrendStudio\Sources;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * DTO for imported ideas from source providers
 */
class Idea_DTO
{
    /**
     * Idea title
     *
     * @var string
     */
    public string $title = '';

    /**
     * Source URL where idea was found
     *
     * @var string
     */
    public string $source_url = '';

    /**
     * Source type: rss, pinterest, manual
     *
     * @var string
     */
    public string $source_type = '';

    /**
     * Provider name (e.g., "NYT Fashion RSS")
     *
     * @var string
     */
    public string $provider_name = '';

    /**
     * Short excerpt/description
     *
     * @var string
     */
    public string $excerpt = '';

    /**
     * Full content (HTML)
     * @var string
     */
    public string $content = '';

    /**
     * Featured image URL
     *
     * @var string
     */
    public string $image_url = '';

    /**
     * Original publish date from source (ISO 8601)
     *
     * @var string
     */
    public string $published_at = '';

    /**
     * When this idea was fetched (ISO 8601)
     *
     * @var string
     */
    public string $fetched_at = '';

    /**
     * Content hash for deduplication
     *
     * @var string
     */
    public string $content_hash = '';

    /**
     * Raw data from provider (for debugging)
     *
     * @var array
     */
    public array $raw_data = array();

    /**
     * Create from array
     *
     * @param array $data Raw data array
     * @return self
     */
    public static function from_array(array $data): self
    {
        $dto = new self();
        $dto->title = $data['title'] ?? '';
        $dto->source_url = $data['source_url'] ?? '';
        $dto->source_type = $data['source_type'] ?? '';
        $dto->provider_name = $data['provider_name'] ?? '';
        $dto->excerpt = $data['excerpt'] ?? '';
        $dto->content = $data['content'] ?? $data['excerpt'] ?? ''; // Fallback to excerpt if no content
        $dto->image_url = $data['image_url'] ?? '';
        $dto->published_at = $data['published_at'] ?? '';
        $dto->fetched_at = $data['fetched_at'] ?? gmdate('c');
        $dto->raw_data = $data['raw_data'] ?? array();

        // Generate content hash for deduplication
        if (empty($data['content_hash'])) {
            $dto->content_hash = md5($dto->title . $dto->source_url);
        } else {
            $dto->content_hash = $data['content_hash'];
        }

        return $dto;
    }

    /**
     * Convert to array
     *
     * @return array
     */
    public function to_array(): array
    {
        return array(
            'title' => $this->title,
            'source_url' => $this->source_url,
            'source_type' => $this->source_type,
            'provider_name' => $this->provider_name,
            'excerpt' => $this->excerpt,
            'content' => $this->content,
            'image_url' => $this->image_url,
            'published_at' => $this->published_at,
            'fetched_at' => $this->fetched_at,
            'content_hash' => $this->content_hash,
            'raw_data' => $this->raw_data,
        );
    }
}
