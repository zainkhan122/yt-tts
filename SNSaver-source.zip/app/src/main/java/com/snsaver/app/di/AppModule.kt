package com.snsaver.app.di
import android.content.Context
import androidx.room.Room
import androidx.work.WorkManager
import com.google.gson.Gson
import com.snsaver.app.data.db.*
import com.snsaver.app.data.repository.DownloadRepositoryImpl
import com.snsaver.app.domain.repository.DownloadRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class) object AppModule{
 @Provides @Singleton fun gson()=Gson()
 @Provides @Singleton fun http()=OkHttpClient.Builder().connectTimeout(30,TimeUnit.SECONDS).readTimeout(2,TimeUnit.MINUTES).followRedirects(true).build()
 @Provides @Singleton fun db(@ApplicationContext c:Context)=Room.databaseBuilder(c,AppDatabase::class.java,"snsaver.db").build()
 @Provides fun dao(db:AppDatabase)=db.downloads()
 @Provides @Singleton fun repo(impl:DownloadRepositoryImpl):DownloadRepository=impl
 @Provides @Singleton fun work(@ApplicationContext c:Context)=WorkManager.getInstance(c)
}
