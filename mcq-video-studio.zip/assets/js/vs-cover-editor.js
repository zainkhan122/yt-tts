/**
 * MCQ Video Studio — Cover Editor
 *
 * Renders a live preview of the video cover (first frame thumbnail)
 * using the same template system so the cover matches the final video.
 *
 * @package MCQ_Video_Studio
 * @since 1.5.0
 */

(function (global) {
  "use strict";

  const MCQVS_CoverEditor = {
    initialized: false,
    previewCanvas: null,
    previewCtx: null,
    currentConfig: {},
    brandingData: {},

    /**
     * Initialize the cover editor on a given container element.
     * @param {HTMLElement} container
     * @param {Object} opts
     */
    init(container, opts) {
      if (this.initialized) return;
      this.initialized = true;
      this.opts = opts || {};
      this.container = container;
      this._buildUI();
      this._loadConfig();
    },

    _buildUI() {
      const self = this;
      const c = this.container;

      c.innerHTML = `
        <div class="cover-editor" style="padding:12px;">
          <div class="cover-editor-preview" style="text-align:center; margin-bottom:12px;">
            <canvas class="cover-preview-canvas" width="270" height="480"
              style="width:270px; height:480px; border-radius:12px; background:#000; box-shadow:0 4px 20px rgba(0,0,0,0.3);">
            </canvas>
          </div>
          <div class="cover-editor-controls">
            <div class="form-row" style="margin-bottom:8px;">
              <label style="display:flex; align-items:center; gap:8px; font-size:12px;">
                <input type="checkbox" class="cover-toggle" checked>
                Enable Video Cover
              </label>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <label style="font-size:12px; display:block; margin-bottom:2px;">Cover Image Source</label>
              <select class="cover-mode" style="width:100%;">
                <option value="scene">Cover scene (branded)</option>
                <option value="first_q_mid">First question (mid-timer)</option>
              </select>
              <p class="description" style="font-size:10px; opacity:0.75; margin:3px 0 0;">
                "First question" uses the frame at 50% of the first question's duration as the
                cover/poster image (all 4 options + half timer). Works in the Studio preview and
                in server-rendered videos (Content Planner / headless) for the extracted cover PNG.
              </p>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <label style="display:flex; align-items:center; gap:8px; font-size:12px;">
                <input type="checkbox" class="cover-show-logo" checked>
                Show Logo
              </label>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <label style="font-size:12px; display:block; margin-bottom:2px;">Brand Size</label>
              <select class="cover-brand-size" style="width:100%;">
                <option value="large">Large</option>
                <option value="medium">Medium</option>
                <option value="small">Small</option>
              </select>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <label style="font-size:12px; display:block; margin-bottom:2px;">Badge Style</label>
              <select class="cover-badge-style" style="width:100%;">
                <option value="gold">Gold (Default)</option>
                <option value="accent">Template Accent</option>
                <option value="minimal">Minimal</option>
              </select>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <label style="font-size:12px; display:block; margin-bottom:2px;">Background Color</label>
              <div style="display:flex; gap:6px; align-items:center;">
                <input type="color" class="cover-bg-color" value="#1a1a2e" style="width:42px; height:28px; padding:0; border:1px solid #ccc; border-radius:4px; cursor:pointer;">
                <input type="text" class="cover-bg-color-text" placeholder="Auto (template)" style="flex:1;">
                <button type="button" class="button cover-bg-color-clear" style="font-size:11px; padding:2px 8px;" title="Clear and use template defaults">Auto</button>
              </div>
              <div class="cover-bg-palette" style="display:flex; flex-wrap:wrap; gap:4px; margin-top:6px;"></div>
              <p class="description cover-template-note" style="font-size:10px; opacity:0.7; margin:4px 0 0;">Template: —</p>
            </div>
            <button type="button" class="button button-secondary cover-refresh-btn" style="width:100%; margin-top:4px;">
              Refresh Preview
            </button>
            <button type="button" class="button button-primary cover-save-btn" style="width:100%; margin-top:6px;">
              Save Cover Settings
            </button>
          </div>
        </div>
      `;

      this.previewCanvas = c.querySelector('.cover-preview-canvas');
      this.previewCtx = this.previewCanvas.getContext('2d');

      // Bind color picker + text input sync
      const colorInput = c.querySelector('.cover-bg-color');
      const colorText = c.querySelector('.cover-bg-color-text');
      colorInput.addEventListener('input', () => {
        const v = colorInput.value || '';
        colorText.value = v;
        self._renderPreview();
      });
      colorText.addEventListener('input', () => {
        const v = (colorText.value || '').trim();
        if (/^#([0-9a-fA-F]{6})$/.test(v)) {
          colorInput.value = v;
          self._renderPreview();
        }
      });
      const clearBtn = c.querySelector('.cover-bg-color-clear');
      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          colorInput.value = '#1a1a2e';
          colorText.value = '';
          self._renderPreview();
        });
      }

      // Bind events
      c.querySelector('.cover-refresh-btn').addEventListener('click', () => self._renderPreview());
      c.querySelector('.cover-save-btn').addEventListener('click', () => self._saveConfig());
      c.querySelectorAll('.cover-editor-controls select, .cover-editor-controls input').forEach(el => {
        if (el === colorInput || el === colorText) return;
        el.addEventListener('change', () => self._renderPreview());
        el.addEventListener('input', () => self._renderPreview());
      });

      // Watch template selection so preview refreshes when template changes
      self._watchTemplateChanges();

      // Watch branding inputs so cover preview updates when user changes brand/quiz name
      const watchBranding = (sel, key) => {
        const el = document.getElementById(sel);
        if (el) {
          el.addEventListener('input', () => {
            self.brandingData[key] = el.value;
            self._renderPreview();
          });
          el.addEventListener('change', () => {
            self.brandingData[key] = el.value;
            self._renderPreview();
          });
        }
      };
      watchBranding('brandName', 'brand_name');
      watchBranding('quizName', 'quiz_name');

      // Poll #quizName input for programmatic changes (applyQuestions sets .value directly
      // which doesn't fire input/change events, so the cover editor misses topic updates)
      let _lastQuizPoll = '';
      setInterval(() => {
        const el = document.getElementById('quizName');
        const val = el ? el.value.trim() : '';
        if (val && val !== _lastQuizPoll) {
          _lastQuizPoll = val;
          self.brandingData.quiz_name = val;
          self._renderPreview();
        }
      }, 800);

      // Watch logo preview image URL changes
      const logoPreview = document.getElementById('logoPreview');
      if (logoPreview) {
        const observer = new MutationObserver(() => {
          if (logoPreview.src && logoPreview.naturalWidth > 0) {
            self.brandingData.logo_url = logoPreview.src;
            self._renderPreview();
          }
        });
        observer.observe(logoPreview, { attributes: true, attributeFilter: ['src'] });
      }
    },

    _loadConfig() {
      const self = this;
      const jobId = this.opts.jobId || '';

      if (!jobId) {
        // Load branding only (no active job)
        if (global.MCQVSConfig && global.MCQVSConfig.ajaxUrl) {
          jQuery.post(global.MCQVSConfig.ajaxUrl, {
            action: 'mcqvs_get_cover_config',
            nonce: global.MCQVSConfig.nonce,
            job_id: '',
          }, (resp) => {
            if (resp.success) {
              self.brandingData = resp.data.branding || {};
              self.currentConfig = resp.data.cover_config || {};
              self._applyConfigToUI();
              self._renderPreview();
            }
          });
        }
        return;
      }

      if (global.MCQVSConfig && global.MCQVSConfig.ajaxUrl) {
        jQuery.post(global.MCQVSConfig.ajaxUrl, {
          action: 'mcqvs_get_cover_config',
          nonce: global.MCQVSConfig.nonce,
          job_id: jobId,
        }, (resp) => {
          if (resp.success) {
            self.brandingData = resp.data.branding || {};
            self.currentConfig = resp.data.cover_config || {};
            self._applyConfigToUI();
            self._renderPreview();
          }
        });
      }
    },

    _applyConfigToUI() {
      const c = this.currentConfig;
      this._setCheck('.cover-toggle', c.enabled !== false);
      this._setCheck('.cover-show-logo', c.show_logo !== false);
      this._setSelect('.cover-brand-size', c.brand_size || 'large');
      this._setSelect('.cover-badge-style', c.badge_style || 'gold');
      this._setSelect('.cover-mode', c.mode || 'scene');
      const savedBg = (c.bg_color || '').trim();
      const textEl = this.container.querySelector('.cover-bg-color-text');
      const colorEl = this.container.querySelector('.cover-bg-color');
      if (textEl) textEl.value = savedBg;
      if (colorEl && /^#([0-9a-fA-F]{6})$/.test(savedBg)) colorEl.value = savedBg;
      this._renderPalette();
    },

    _gatherConfig() {
      const textEl = this.container.querySelector('.cover-bg-color-text');
      const colorEl = this.container.querySelector('.cover-bg-color');
      const textVal = (textEl && textEl.value ? textEl.value : '').trim();
      const colorVal = (colorEl && colorEl.value ? colorEl.value : '').trim();
      const bgColor = textVal || colorVal || '';
      const modeEl = this.container.querySelector('.cover-mode');
      return {
        enabled: this.container.querySelector('.cover-toggle').checked,
        show_logo: this.container.querySelector('.cover-show-logo').checked,
        brand_size: this.container.querySelector('.cover-brand-size').value,
        badge_style: this.container.querySelector('.cover-badge-style').value,
        bg_color: bgColor,
        mode: (modeEl && (modeEl.value === 'first_q_mid' || modeEl.value === 'scene')) ? modeEl.value : 'scene',
      };
    },

    /**
     * Render color swatches derived from the currently selected template.
     */
    _renderPalette() {
      const paletteEl = this.container.querySelector('.cover-bg-palette');
      if (!paletteEl) return;
      const colors = this._resolveColors();
      const candidates = [];
      if (colors.primary) candidates.push(colors.primary);
      if (colors.secondary) candidates.push(colors.secondary);
      if (colors.accent) candidates.push(colors.accent);
      // Fallback palette when no template colors are available
      const fallback = ['#1a1a2e', '#16213e', '#0f3460', '#2C3E50', '#3498DB', '#0D0221', '#0D0D0D', '#1A0000'];
      const pool = candidates.length ? candidates : fallback;
      paletteEl.innerHTML = '';
      pool.forEach((hex) => {
        const sw = document.createElement('button');
        sw.type = 'button';
        sw.className = 'cover-bg-swatch';
        sw.title = hex;
        sw.setAttribute('data-color', hex);
        sw.style.cssText = `width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,0.25);background:${hex};cursor:pointer;padding:0;`;
        sw.addEventListener('click', () => {
          const colorEl = this.container.querySelector('.cover-bg-color');
          const textEl = this.container.querySelector('.cover-bg-color-text');
          if (colorEl) colorEl.value = hex;
          if (textEl) textEl.value = hex;
          this._renderPreview();
        });
        paletteEl.appendChild(sw);
      });
    },

    /**
     * Resolve current template colors from MCQVSVideoTemplates.
     * Reads the selected card (which the studio maintains via .selected),
     * the legacy #templateSelect input, or falls back to defaults.
     */
    _resolveColors() {
      const fallback = {
        primary: '#1a1a2e',
        secondary: '#16213e',
        accent: '#00f0ff',
        text: '#ffffff',
        textSecondary: '#bdc3c7',
      };
      let tplId = '';
      const selected = document.querySelector('.mcqvs-template-card.selected');
      if (selected && selected.dataset && selected.dataset.template) {
        tplId = selected.dataset.template;
      }
      if (!tplId) {
        const legacy = document.getElementById('templateSelect');
        if (legacy && legacy.value) tplId = legacy.value;
      }
      let tpl = null;
      if (tplId && window.MCQVSVideoTemplates && typeof window.MCQVSVideoTemplates.get === 'function') {
        tpl = window.MCQVSVideoTemplates.get(tplId);
      }
      if (!tpl && tplId && window.MCQVS_VideoTemplates && window.MCQVS_VideoTemplates.templates) {
        tpl = window.MCQVS_VideoTemplates.templates[tplId] || null;
      }
      const noteEl = this.container.querySelector('.cover-template-note');
      if (noteEl) noteEl.textContent = `Template: ${tpl && tpl.name ? tpl.name : (tplId || 'default')}`;
      if (tpl && tpl.colors) {
        return Object.assign({}, fallback, tpl.colors);
      }
      return fallback;
    },

    /**
     * Watch template-card selection + global state so the preview repaints
     * whenever the user changes the active template.
     */
    _watchTemplateChanges() {
      const self = this;
      const grid = document.querySelector('.mcqvs-template-grid') || document.body;
      const repaint = () => {
        self._renderPalette();
        self._renderPreview();
      };
      if (grid) {
        const mo = new MutationObserver(() => repaint());
        mo.observe(grid, { subtree: true, attributes: true, attributeFilter: ['class'], childList: true });
      }
      // Fallback: poll the legacy #templateSelect value (covers render-runner flow)
      let lastTpl = '';
      setInterval(() => {
        const sel = document.getElementById('templateSelect');
        const cur = sel ? sel.value : '';
        if (cur && cur !== lastTpl) {
          lastTpl = cur;
          repaint();
        }
      }, 1500);
    },

    _setCheck(sel, val) {
      const el = this.container.querySelector(sel);
      if (el) el.checked = !!val;
    },
    _setSelect(sel, val) {
      const el = this.container.querySelector(sel);
      if (el) el.value = val;
    },

    _getPreviewDimensions() {
      try {
        const ctrl = global.MCQVS_Controller || global.MCQVS_StudioController;
        const state = (ctrl && ctrl.state) ? ctrl.state : ((ctrl && typeof ctrl.getInstance === 'function') ? (ctrl.getInstance() || {}).state : null);
        if (state && state.videoFormat === 'youtube') {
          return { cw: 480, ch: 270, isLandscape: true };
        }
      } catch (e) { /* ignore */ }
      return { cw: 270, ch: 480, isLandscape: false };
    },

    _renderPreview() {
      const ctx = this.previewCtx;
      const dims = this._getPreviewDimensions();
      const cw = dims.cw;
      const ch = dims.ch;
      const cfg = this._gatherConfig();
      const branding = this.brandingData;

      // Resize canvas to match current format
      const canvas = this.previewCanvas;
      if (canvas) {
        canvas.width = cw;
        canvas.height = ch;
        canvas.style.width = cw + 'px';
        canvas.style.height = ch + 'px';
      }

      // Sync cover config to controller so main preview/export use same settings
      this._pushToController(cfg);

      // Clear
      ctx.clearRect(0, 0, cw, ch);

      // @FIX 2026-08-11 (WYSIWYG): The cover card must show the EXACT same frame the
      //       video renders. Previously it hand-rolled drawBackground+drawQuestion /
      //       drawCover directly, which BYPASSED the branding layer, corner logo and
      //       post-processing — so the card showed only the bare question card while the
      //       preview / server renders showed brand header + quiz name + timer. Now both
      //       modes render through the FULL template.render() pipeline (background →
      //       branding → scene routing → corner logo → post-FX), the same path the
      //       preview (_renderAt → unified renderer → template.render) and the headless
      //       server use. Falls back to the legacy hand-rolled draw if the template
      //       manager isn't loaded yet.
      const _tm = global.MCQVS_TemplateManager;
      const _ctrl = global.MCQVS_Controller || global.MCQVS_StudioController;
      const _cs = (_ctrl && _ctrl.state) ? _ctrl.state : null;
      if (_tm && typeof _tm.getTemplate === 'function') {
        try {
          const _tplId = (_cs && (_cs.templateId || _cs.currentTemplate)) || 'trivia';
          const _tpl = _tm.getTemplate(_tplId);
          if (_tpl && typeof _tpl.render === 'function') {

            const _logoImg = this._findLogoImg();
            const _assets = _logoImg ? { logoImage: _logoImg } : {};
            const _baseState = {
              currentTemplate: _tplId,
              templateId: _tplId,
              brandName: branding.brand_name || (_cs && _cs.brandName) || 'Quiz Master',
              quizName: branding.quiz_name || (_cs && _cs.quizName) || '',
              hookText: (_cs && _cs.hookText) || this.brandingData.hook_text || '',
              hookVisible: (_cs ? _cs.hookVisible !== false : true),
              brandLogoImage: _logoImg,
              logoPosition: (_cs && _cs.logoPosition) || 'all',
              coverConfig: Object.assign({}, cfg),
              templateColors: this._resolveColors(),
              templateFonts: (_cs && _cs.templateFonts) || null,
              templateEffects: (_cs && _cs.templateEffects) || null,
              fontOverride: (_cs && _cs.fontOverride) || null,
              textEffects: (_cs && _cs.textEffects) || null,
              bgImage: null,
              bgVideoFrames: null,
              bgVideoFrameDur: 33.33,
              fxEvents: [],
              sfxEvents: [],
            };

            // @NEW 2026-08-11: "First question (mid-timer)" cover mode — render the first
            //       question scene at 50% of its duration through the FULL pipeline so the
            //       card shows exactly what the server extracts (brand header, quiz name,
            //       question, all 4 options, half timer, corner logo, post-FX).
            if (cfg.mode === 'first_q_mid' && _cs && Array.isArray(_cs.questions) && _cs.questions.length) {
              const _q0 = _cs.questions[0];
              if (_q0 && (_q0.question || _q0.text)) {
                const _timing = (_cs && _cs.timing) || { hookIntro: 1200, outroDuration: 3200, questionTotal: 7700, questionPhases: { intro: 600, reading: 5100, reveal: 2000 } };
                const _qTotal = Number(_timing.questionTotal || 7700);
                const _reveal = Number((_timing.questionPhases && _timing.questionPhases.reveal) || 2000);
                const _within = Math.max(200, _qTotal / 2);
                const _revealStart = Math.max(0, _qTotal - _reveal);
                const _phase = _within < _revealStart ? 'question' : 'reveal';
                const _qOpts = Array.isArray(_q0.options) ? _q0.options.map(v => String(v == null ? '' : v).trim()) : [];
                const _qContent = {
                  id: 'q0',
                  question: String(_q0.question || _q0.text || 'Question'),
                  options: _qOpts.length >= 2 ? _qOpts : ['Option A', 'Option B', 'Option C', 'Option D'],
                  correct: (typeof _q0.correct === 'number') ? _q0.correct : (parseInt(_q0.correct, 10) || 0),
                  difficulty: _q0.difficulty || '',
                  explanation: _q0.explanation || '',
                };
                const _qState = Object.assign({}, _baseState, {
                  currentSceneId: 'q0',
                  activeScene: { type: 'question', id: 'q0', content: _qContent },
                  animationPhase: _phase,
                  elapsed: _within, elapsedInScene: _within, time: _within, prevElapsed: Math.max(0, _within - 41),
                  timing: _timing,
                });
                _tpl.render(ctx, _qState, _assets);

                if (cfg.enabled === false) {
                  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
                  ctx.fillRect(0, 0, cw, ch);
                  ctx.fillStyle = '#FFFFFF';
                  ctx.font = `bold ${Math.round(Math.min(cw, ch) * 0.08)}px Inter, sans-serif`;
                  ctx.textAlign = 'center';
                  ctx.textBaseline = 'middle';
                  ctx.fillText('Cover Disabled', cw / 2, ch / 2);
                }

                this._lastWysiwyg = true;
                return;
              }
            }

            const _state = Object.assign({}, _baseState, {
              currentSceneId: 'cover',
              activeScene: { id: 'cover', type: 'cover' },
              animationPhase: 'cover',
              elapsed: 500, elapsedInScene: 500, time: 500, prevElapsed: 458,
              timing: (_cs && _cs.timing) || { hookIntro: 1200, outroDuration: 3200, questionTotal: 7700, questionPhases: { intro: 600, reading: 5100, reveal: 2000 } },
            });
            _tpl.render(ctx, _state, _assets);

            // "Disabled" overlay — the real video skips the cover scene entirely.
            if (cfg.enabled === false) {
              ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
              ctx.fillRect(0, 0, cw, ch);
              ctx.fillStyle = '#FFFFFF';
              ctx.font = `bold ${Math.round(Math.min(cw, ch) * 0.08)}px Inter, sans-serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText('Cover Disabled', cw / 2, ch / 2);
            }

            this._lastWysiwyg = true;
            return;
          }
        } catch (_e) {
          // fall through to the legacy draw below
        }
      }
      this._lastWysiwyg = false;

      // Resolve colors from the currently selected template
      const colors = this._resolveColors();

      // Draw gradient background
      const grad = ctx.createLinearGradient(0, 0, cw, ch);
      if (cfg.bg_color) {
        grad.addColorStop(0, cfg.bg_color);
        grad.addColorStop(1, this._adjustBrightness(cfg.bg_color, -30));
      } else {
        grad.addColorStop(0, colors.primary);
        grad.addColorStop(0.5, colors.secondary);
        grad.addColorStop(1, this._adjustBrightness(colors.primary, 20));
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, cw, ch);

      const cx = cw / 2;
      const scale = cfg.brand_size === 'large' ? 1.0 : cfg.brand_size === 'medium' ? 0.75 : 0.55;

      // Logo
      if (cfg.show_logo && branding.logo_url) {
        // If logo image is loaded on the page, draw it
        const img = this._findLogoImg();
        if (img) {
          const size = Math.round(56 * scale);
          const y = Math.round(ch * 0.28);
          ctx.save();
          ctx.shadowBlur = 16;
          ctx.shadowColor = 'rgba(0,0,0,0.4)';
          ctx.drawImage(img, cx - size / 2, y, size, size);
          ctx.restore();
        }
      }

      // Brand name
      let brandFontSize = Math.round(22 * scale);
      ctx.font = `bold ${brandFontSize}px Inter, Roboto, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const brandName = branding.brand_name || 'Quiz Master';
      ctx.shadowBlur = 12;
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.fillStyle = colors.accent;
      const brandY = cfg.show_logo && branding.logo_url
        ? Math.round(ch * 0.42)
        : Math.round(ch * 0.36);
      ctx.fillText(brandName, cx, brandY);

      // Quiz name badge (wraps to multiple lines for long names)
      const quizName = (branding.quiz_name || '').trim();
      if (quizName) {
        const padding = 14;
        const maxBoxWidth = cw - 24; // leave 12px margin each side
        const quizMinFontSize = Math.round(brandFontSize * 0.5);
        const lineGap = 4;

        // Try to find a font size + word-break that fits the maxBoxWidth
        const wrapped = this._wrapTextToBox(ctx, quizName, maxBoxWidth - padding * 2, brandFontSize, quizMinFontSize);
        const lines = wrapped.lines;
        const quizFontSize = wrapped.fontSize;

        const textWidth = wrapped.maxLineWidth;
        const boxWidth = Math.min(maxBoxWidth, textWidth + padding * 3);
        const lineHeight = quizFontSize + lineGap;
        const boxHeight = (lines.length * lineHeight) - lineGap + padding;
        const badgeY = cfg.show_logo && branding.logo_url
          ? Math.round(ch * 0.54)
          : Math.round(ch * 0.48);
        const badgeX = cx - boxWidth / 2;

        // Badge background
        const badgeGrad = ctx.createLinearGradient(badgeX, badgeY, badgeX + boxWidth, badgeY + boxHeight);
        let badgeBorder = '#FFD700';
        let badgeBg1 = 'rgba(40, 40, 60, 0.95)';
        let badgeBg2 = 'rgba(20, 20, 30, 0.95)';
        let badgeText = '#FFD700';
        if (cfg.badge_style === 'accent' && colors.accent) {
          badgeBorder = colors.accent;
          badgeText = colors.accent;
        } else if (cfg.badge_style === 'minimal') {
          badgeBorder = 'rgba(255,255,255,0.2)';
          badgeBg1 = 'rgba(255,255,255,0.08)';
          badgeBg2 = 'rgba(255,255,255,0.04)';
          badgeText = '#FFFFFF';
        }
        badgeGrad.addColorStop(0, badgeBg1);
        badgeGrad.addColorStop(1, badgeBg2);
        ctx.fillStyle = badgeGrad;
        ctx.strokeStyle = badgeBorder;
        ctx.lineWidth = cfg.badge_style === 'minimal' ? 1 : 2;
        const radius = Math.round(Math.min(boxWidth, boxHeight) * 0.25);
        this._roundRect(ctx, badgeX, badgeY, boxWidth, boxHeight, radius);
        ctx.fill();
        ctx.stroke();

        ctx.shadowBlur = 0;
        ctx.fillStyle = badgeText;
        ctx.font = `bold ${quizFontSize}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const startY = badgeY + padding / 2 + quizFontSize / 2;
        lines.forEach((ln, i) => {
          ctx.fillText(ln, cx, startY + i * lineHeight);
        });
      }

      ctx.shadowBlur = 0;

      // Show "disabled" overlay when cover is turned off
      if (cfg.enabled === false) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(0, 0, cw, ch);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = `bold ${Math.round(Math.min(cw, ch) * 0.08)}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('Cover Disabled', cx, ch / 2);
      }
    },

    /**
     * Greedy word-wrap into lines that fit `maxTextWidth`.
     * Auto-shrinks font size (down to minFontSize) when a single word exceeds
     * the available width. Returns lines + resolved fontSize + widest line.
     */
    _wrapTextToBox(ctx, text, maxTextWidth, startFontSize, minFontSize) {
      let fontSize = startFontSize || minFontSize;
      const tryWrap = (size) => {
        ctx.font = `bold ${size}px Inter, sans-serif`;
        const words = String(text).split(/\s+/).filter(Boolean);
        const lines = [];
        let current = '';
        let widest = 0;
        for (let i = 0; i < words.length; i++) {
          const word = words[i];
          const candidate = current ? (current + ' ' + word) : word;
          const w = ctx.measureText(candidate).width;
          if (w <= maxTextWidth) {
            current = candidate;
            widest = Math.max(widest, ctx.measureText(current).width);
          } else if (!current) {
            // Single word that exceeds width: hard-break by chars
            let chunk = '';
            for (const ch of word) {
              const t = chunk + ch;
              if (chunk && ctx.measureText(t).width > maxTextWidth) {
                lines.push(chunk);
                widest = Math.max(widest, ctx.measureText(chunk).width);
                chunk = ch;
              } else {
                chunk = t;
              }
            }
            current = chunk;
            if (current) widest = Math.max(widest, ctx.measureText(current).width);
          } else {
            lines.push(current);
            widest = Math.max(widest, ctx.measureText(current).width);
            current = word;
          }
        }
        if (current) {
          lines.push(current);
          widest = Math.max(widest, ctx.measureText(current).width);
        }
        return { lines, widest };
      };

      let result = tryWrap(fontSize);
      while (result.lines.some((l) => ctx.measureText(l).width > maxTextWidth) && fontSize > minFontSize) {
        fontSize -= 1;
        result = tryWrap(fontSize);
      }
      return { lines: result.lines, fontSize: fontSize, maxLineWidth: result.widest };
    },

    _findLogoImg() {
      // Try to find a loaded logo image in the DOM
      const brandingPanel = document.querySelector('.branding-preview-logo');
      if (brandingPanel && brandingPanel.tagName === 'IMG' && brandingPanel.naturalWidth > 0) {
        return brandingPanel;
      }
      // Look for any img with logo URL
      if (this.brandingData.logo_url) {
        const imgs = document.querySelectorAll('img');
        for (const img of imgs) {
          if (img.src === this.brandingData.logo_url && img.naturalWidth > 0) {
            return img;
          }
        }
      }
      return null;
    },

    _adjustBrightness(hex, percent) {
      const num = parseInt(hex.replace('#', ''), 16);
      const r = Math.min(255, Math.max(0, (num >> 16) + percent));
      const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + percent));
      const b = Math.min(255, Math.max(0, (num & 0x0000FF) + percent));
      return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
    },

    _roundRect(ctx, x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
    },

    _saveConfig() {
      const self = this;
      const cfg = this._gatherConfig();
      const jobId = this.opts.jobId || '';

      // Push to controller state so preview/export use same cover settings
      this._pushToController(cfg);

      if (!global.MCQVSConfig || !global.MCQVSConfig.ajaxUrl) return;

      jQuery.post(global.MCQVSConfig.ajaxUrl, {
        action: 'mcqvs_save_cover_config',
        nonce: global.MCQVSConfig.nonce,
        job_id: jobId,
        ...cfg,
      }, (resp) => {
        if (resp.success) {
          self.currentConfig = cfg;
        }
      });
    },

    /**
     * Push cover config to the Studio Controller state so drawCover()
     * in the template manager uses the same settings for preview + export.
     */
    _pushToController(cfg) {
      try {
        const ctrl = global.MCQVS_Controller || global.MCQVS_StudioController;
        const target = (ctrl && ctrl.state) ? ctrl : ((ctrl && typeof ctrl.getInstance === 'function') ? (ctrl.getInstance() || ctrl) : null);
        if (target && target.state) {
          target.state.coverConfig = Object.assign({}, target.state.coverConfig || {}, cfg);
        }
        // @FIX 2026-08-11 (Disable toggle): plan.builder only omits the cover scene
        // when coverConfig.enabled === false — but the render plan is CACHED, and
        // _renderAt(0) re-renders the cached plan. Invalidating the plan here forces
        // the next _renderAt(0) (debounced below) to REBUILD without the cover scene,
        // so "Disable Video Cover" actually takes effect in the preview/export.
        if (target && typeof target._invalidateRenderPlan === 'function') {
          try { target._invalidateRenderPlan(); } catch (_) { }
        }
        // Debounced re-render of main preview at t=0 so cover changes are visible
        if (this._mainPreviewTimer) clearTimeout(this._mainPreviewTimer);
        this._mainPreviewTimer = setTimeout(() => {
          try {
            const c = global.MCQVS_Controller || global.MCQVS_StudioController;
            const t = (c && c.state) ? c : ((c && typeof c.getInstance === 'function') ? (c.getInstance() || c) : null);
            if (t && typeof t._renderAt === 'function' && t._ctx && t._renderer) {
              t._renderAt(0, true);
            }
          } catch (_) { }
        }, 80);
      } catch (e) { /* ignore — controller may not be loaded yet */ }
    },

    /**
     * Refresh cover preview from controller state (branding fields).
     */
    refreshFromState(state) {
      if (!state) return;
      if (state.brandName != null) this.brandingData.brand_name = state.brandName;
      if (state.quizName != null) this.brandingData.quiz_name = state.quizName;
      // @FIX 2026-08-11: Persist the hook text into the card's state so the WYSIWYG
      //       cover preview shows the real hook-first cover (not just brand+quizName).
      if (state.hookText != null) this.brandingData.hook_text = state.hookText;
      if (state.brandLogoUrl || state.logoPath) {
        this.brandingData.logo_url = state.brandLogoUrl || state.logoPath;
      }
      if (state.brandLogoImage && typeof state.brandLogoImage.src === 'string') {
        this.brandingData.logo_url = state.brandLogoImage.src;
      }
      this._renderPreview();
    },

    /**
     * Set current job/project ID so save/load uses the correct record.
     */
    setJobId(jobId) {
      this.opts = this.opts || {};
      this.opts.jobId = jobId || '';
      this._loadConfig();
    },
  };

  global.MCQVS_CoverEditor = MCQVS_CoverEditor;

  // Auto-initialize when DOM is ready and container exists
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      const container = document.getElementById('cover-editor-container');
      if (container && container.getAttribute('data-initialized') !== '1') {
        container.setAttribute('data-initialized', '1');
        MCQVS_CoverEditor.init(container, { jobId: '' });
      }
    });
  } else {
    const container = document.getElementById('cover-editor-container');
    if (container && container.getAttribute('data-initialized') !== '1') {
      container.setAttribute('data-initialized', '1');
      MCQVS_CoverEditor.init(container, { jobId: '' });
    }
  }
})(window);
