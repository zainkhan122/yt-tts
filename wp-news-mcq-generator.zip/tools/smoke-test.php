<?php
/**
 * Simple CLI smoke test for nm_get_mcqs_standard()
 *
 * Usage (from plugin folder):
 *   php tools/smoke-test.php
 */

// Locate WordPress root: plugin -> /wp-content/plugins/ -> WordPress root
$wp_root = dirname(__DIR__, 4);

$wp_load = $wp_root . '/wp-load.php';
if ( ! file_exists( $wp_load ) ) {
    echo "FAIL: Could not find wp-load.php at {$wp_load}\n";
    exit(1);
}

require $wp_load;

if ( ! class_exists( 'NM_AJAX_Frontend' ) ) {
    echo "FAIL: NM_AJAX_Frontend class is not loaded. Is the plugin active?\n";
    exit(1);
}

$args = [
    'count'           => 3,
    'topic'           => '',
    'exam'            => '',
    'exclude_ids'     => [],
    'month'           => '',
    'difficulty'      => '',
    'cognitive_level' => '',
];

$result = NM_AJAX_Frontend::nm_get_mcqs_standard( $args );

$errors = [];

if ( ! is_array( $result ) || empty( $result ) ) {
    $errors[] = 'Result is not a non-empty array.';
} else {
    foreach ( $result as $index => $mcq ) {
        $n = $index + 1;

        if ( empty( $mcq['is_card'] ) ) {
            $errors[] = "MCQ #{$n} missing is_card=true.";
        }

        if ( ! array_key_exists( 'html', $mcq ) ) {
            $errors[] = "MCQ #{$n} missing html key.";
            continue;
        }

        if ( trim( (string) $mcq['html'] ) === '' ) {
            $errors[] = "MCQ #{$n} has empty html.";
        } elseif ( strpos( $mcq['html'], 'nm-mcq-item nm-mcq-card' ) === false ) {
            $errors[] = "MCQ #{$n} html does not contain unified card classes.";
        }
    }
}

if ( ! empty( $errors ) ) {
    echo "❌ FAIL: nm_get_mcqs_standard() issues detected:\n";
    foreach ( $errors as $e ) {
        echo " - {$e}\n";
    }
    exit(1);
}

echo "✅ OK: nm_get_mcqs_standard() returned valid card HTML for " . count( $result ) . " MCQs.\n";
exit(0);

