#!/usr/bin/env python3
"""Write DIR/visual_plan.json from script + needs. Does not render.

  python3 tools/plan_visual.py DIR [--patch-needs]
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

ROOT = Path("/home/user")
IDS = json.loads((ROOT / "tools/visual_identities.json").read_text())
REG = ROOT / "tools/topic_register.json"

MODE_BY_KIND = {
    "face": "character",
    "place": "environment",
    "object": "object",
    "diagram": "mechanism",
    "motion": "mechanism",
}

IDENTITY_BY_MODE = {
    "symbol": "id.jung_symbol",
    "character": "id.relationship_character",
    "mechanism": "id.cognitive_mechanism",
    "environment": "id.existential_environment",
    "object": "id.long_object_diagram",
}


def topic_id(base: Path) -> str:
    n = base.name.replace("short_", "")
    if n.startswith("video_"):
        try:
            return f"v{int(n.replace('video_', '')):02d}"
        except ValueError:
            return n
    return n


def family_of(tid: str) -> str:
    if not REG.exists():
        return ""
    data = json.loads(REG.read_text())
    for e in data.get("entries") or []:
        if e.get("id") == tid:
            return e.get("family_id") or ""
    return ""


def pick_mode(needs: list, tid: str, form: str) -> str:
    fam = family_of(tid)
    if fam == "fam.ambiguous-loss":
        return "symbol"
    if fam == "fam.decision-overcrowd":
        return "mechanism"
    if form == "long":
        return "object"
    kinds = [n.get("kind") for n in needs if n.get("kind")]
    if kinds:
        from collections import Counter
        k, _ = Counter(kinds).most_common(1)[0]
        return MODE_BY_KIND.get(k, "symbol")
    return "symbol"


def motif_for(mode: str, tid: str, text: str) -> str:
    # s02 owns doors; new mechanism films must not default to doors
    if tid == "s02":
        return "six door-slabs and a maze line"
    if tid == "s01":
        return "living / death split and phone that still types"
    ident = {i["id"]: i for i in IDS["identities"]}
    iid = IDENTITY_BY_MODE[mode]
    return ident[iid]["motif"]


def load_needs(base: Path) -> list:
    p = base / "beat_needs.json"
    if not p.exists():
        return []
    data = json.loads(p.read_text())
    return data.get("needs") or data


def plan(base: Path) -> dict:
    tid = topic_id(base)
    form = "short" if "short" in base.name else "long"
    needs = load_needs(base)
    vo = (base / "voiceover.txt").read_text(encoding="utf-8") if (base / "voiceover.txt").exists() else ""
    mode = pick_mode(needs, tid, form)
    iid = IDENTITY_BY_MODE[mode]
    ident = next(i for i in IDS["identities"] if i["id"] == iid)
    beats = []
    prev_hf = None
    for i, n in enumerate(needs):
        hf = n.get("hf")
        intent = n.get("visual_intent") or n.get("label") or n.get("start") or ""
        trans = "cut"
        if mode == "mechanism":
            trans = "overlap"
        elif mode == "environment":
            trans = "weather-dissolve"
        elif mode == "character":
            trans = "gap-hold"
        elif mode == "symbol":
            trans = "occlude"
        cam = ident["camera"]
        if hf and hf == prev_hf:
            trans = "must-change-machine"
        prev_hf = hf
        beats.append({
            "i": i,
            "visual_intent": intent,
            "camera": cam,
            "transition": trans,
            "hf": hf,
        })
    return {
        "schema": "visual_plan_v1",
        "topic_id": tid,
        "family_id": family_of(tid),
        "mode": mode,
        "identity_id": iid,
        "motif": motif_for(mode, tid, vo),
        "palette": ident["palette"],
        "type": ident["type"],
        "feasibility": "stills_gsap",
        "forbidden_motifs": ident.get("forbidden_motifs") or [],
        "beats": beats,
        "note": "Custom index.html is the film. hf ids are fallback only.",
    }


def patch_needs(base: Path, vp: dict):
    p = base / "beat_needs.json"
    if not p.exists():
        return
    data = json.loads(p.read_text())
    needs = data.get("needs") or data
    for n, b in zip(needs, vp["beats"]):
        n.setdefault("visual_intent", b["visual_intent"])
        n.setdefault("transition", b["transition"])
        n.setdefault("camera", b["camera"])
    if isinstance(data, dict) and "needs" in data:
        data["needs"] = needs
        p.write_text(json.dumps(data, indent=2) + "\n")
    else:
        p.write_text(json.dumps(needs, indent=2) + "\n")


def main():
    args = sys.argv[1:]
    if not args or args[0].startswith("-"):
        print("usage: plan_visual.py DIR [--patch-needs]")
        sys.exit(1)
    base = Path(args[0]).resolve()
    vp = plan(base)
    (base / "visual_plan.json").write_text(json.dumps(vp, indent=2) + "\n")
    if "--patch-needs" in args:
        patch_needs(base, vp)
    print("wrote", base / "visual_plan.json", "mode", vp["mode"], "identity", vp["identity_id"])
    sys.exit(0)


if __name__ == "__main__":
    main()
