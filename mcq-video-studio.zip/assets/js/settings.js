/**
 * Video Studio Settings JS
 *
 * @package MCQ_Video_Studio
 * @since 1.0.0
 */

(function ($) {
  "use strict";

  var i18n = mcqvsSettings.i18n;

  /**
   * Test Buffer connection (per-account; account_id comes from the card).
   */
  $(document).on("click", ".mcqvs-test-buffer", function () {
    var $btn = $(this);
    var accountId = $btn.data("account-id") || "";
    var $card = $btn.closest(".mcqvs-buffer-account-card");
    var $status = $card.length
      ? $card.find(".mcqvs-buffer-account-status")
      : $("#mcqvs-buffer-status");
    var data = {
      action: "mcqvs_test_buffer",
      nonce: mcqvsSettings.nonce,
    };
    if (accountId) data.account_id = accountId;

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(i18n.testing);

    $.post(mcqvsSettings.ajaxUrl, data, function (response) {
      $btn.prop("disabled", false);
      $status.removeClass("loading");

      if (response.success) {
        $status
          .addClass("success")
          .text(i18n.success + " " + response.data.message);
      } else {
        $status.addClass("error").text(i18n.failed + response.data);
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $status
        .removeClass("loading")
        .addClass("error")
        .text(i18n.failed + "Network error");
    });
  });

  /**
   * Refresh Buffer channels from API (per-account; renders into the card).
   */
  $(document).on("click", ".mcqvs-refresh-buffer-channels", function () {
    var $btn = $(this);
    var accountId = $btn.data("account-id") || "";
    var $card = $btn.closest(".mcqvs-buffer-account-card");
    var $status = $card.length
      ? $card.find(".mcqvs-buffer-account-status")
      : $("#mcqvs-buffer-status");
    var $wrap = $card.length
      ? $card.find(".mcqvs-account-channels-wrap")
      : $("#mcqvs-buffer-channels-wrap");
    var $loading = $("#mcqvs-buffer-channels-loading");
    var data = {
      action: "mcqvs_refresh_buffer_channels",
      nonce: mcqvsSettings.nonce,
    };
    if (accountId) data.account_id = accountId;

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text("Refreshing channels...");
    $loading.show();

    $.post(mcqvsSettings.ajaxUrl, data, function (response) {
      $btn.prop("disabled", false);
      $loading.hide();
      $status.removeClass("loading");

      if (response.success) {
        $status.addClass("success").text(response.data.message);
        renderBufferChannels(response.data.channels, $wrap);
      } else {
        $status.addClass("error").text(i18n.failed + response.data);
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $loading.hide();
      $status
        .removeClass("loading")
        .addClass("error")
        .text(i18n.failed + "Network error");
    });
  });

  /**
   * Render the Buffer channels table inside an account card after refresh.
   */
  function renderBufferChannels(channels, $wrap) {
    $wrap = $wrap || $("#mcqvs-buffer-channels-wrap");
    if (!channels || channels.length === 0) {
      $wrap.html('<p class="mcqvs-no-channels-msg" style="color:#999;">No channels found. Make sure this Buffer account has connected social channels.</p>');
      return;
    }

    var validTypes = {
      facebook: ["post", "story", "reel"],
      instagram: ["post", "story", "reel"],
      twitter: ["post"],
      linkedin: ["post"],
      pinterest: ["post"],
      youtube: ["post", "video"],
      // @FIX 2026-08-10: Threads does NOT support stories on Buffer — only posts.
      threads: ["post"],
      tiktok: ["post", "video"],
      mastodon: ["post"],
      bluesky: ["post"],
      google: ["post"]
    };
    var linkServices = ["facebook", "linkedin"];

    var html = '<table class="widefat fixed striped mcqvs-account-channels">';
    html += "<thead><tr>";
    html += '<th style="width:50px;">Enable</th>';
    html += "<th>Channel</th>";
    html += '<th style="width:110px;">Service</th>';
    html += '<th style="width:130px;">Post Type</th>';
    html += '<th style="width:100px;">Link Post</th>';
    html += "</tr></thead><tbody class='mcqvs-account-channels-body'>";

    for (var i = 0; i < channels.length; i++) {
      var ch = channels[i];
      var svc = ch.service || "unknown";
      var types = validTypes[svc] || ["post"];
      var showLink = linkServices.indexOf(svc) !== -1;

      html += "<tr>";
      html += '<td><input type="checkbox" class="mcqvs-ch-enable" value="' + ch.id + '" checked /></td>';
      html += "<td><strong>" + (ch.displayName || ch.name || ch.id) + "</strong><br><small style='color:#888;'>" + ch.id + "</small></td>";
      html += '<td><span class="mcqvs-service-badge">' + svc.charAt(0).toUpperCase() + svc.slice(1) + "</span></td>";
      html += '<td><select class="mcqvs-ch-type">';
      for (var t = 0; t < types.length; t++) {
        html += '<option value="' + types[t] + '">' + types[t].charAt(0).toUpperCase() + types[t].slice(1) + "</option>";
      }
      html += "</select></td>";
      html += "<td>";
      if (showLink) {
        html += '<input type="checkbox" class="mcqvs-ch-link" value="1" />';
      } else {
        html += '<span style="color:#aaa;">&mdash;</span>';
      }
      html += "</td>";
      html += "</tr>";
    }

    html += "</tbody></table>";
    $wrap.html(html);
  }

  /**
   * Test R2 connection.
   */
  $("#mcqvs-test-r2").on("click", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-r2-status");

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(i18n.testing);

    $.post(
      mcqvsSettings.ajaxUrl,
      {
        action: "mcqvs_test_r2",
        nonce: mcqvsSettings.nonce,
      },
      function (response) {
        $btn.prop("disabled", false);
        $status.removeClass("loading");

        if (response.success) {
          $status.addClass("success").text(i18n.success);
        } else {
          $status.addClass("error").text(i18n.failed + response.data);
        }
      }
    ).fail(function () {
      $btn.prop("disabled", false);
      $status
        .removeClass("loading")
        .addClass("error")
        .text(i18n.failed + "Network error");
    });
  });

  /**
   * Run automation manually.
   */
  $("#mcqvs-run-automation").on("click", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-automation-status");

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(i18n.running);

    $.post(
      mcqvsSettings.ajaxUrl,
      {
        action: "mcqvs_run_automation",
        nonce: mcqvsSettings.nonce,
      },
      function (response) {
        $btn.prop("disabled", false);
        $status.removeClass("loading");

        if (response.success) {
          $status
            .addClass("success")
            .text(i18n.jobCreated + response.data.jobs_created);
        } else {
          $status.addClass("error").text(i18n.failed + response.data);
        }
      }
    ).fail(function () {
      $btn.prop("disabled", false);
      $status
        .removeClass("loading")
        .addClass("error")
        .text(i18n.failed + "Network error");
    });
  });

  /**
   * Test Headless Rendering setup.
   */
  $("#mcqvs-test-headless").on("click", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-headless-status");

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(i18n.testing);

    $.post(
      mcqvsSettings.ajaxUrl,
      {
        action: "mcqvs_test_headless",
        nonce: mcqvsSettings.nonce,
      },
      function (response) {
        $btn.prop("disabled", false);
        $status.removeClass("loading");

        if (response.success) {
          var out = JSON.stringify(response.data, null, 2);
          $status.addClass("success").html("<pre>" + out + "</pre>");
        } else {
          $status.addClass("error").text(i18n.failed + response.data);
        }
      }
    ).fail(function () {
      $btn.prop("disabled", false);
      $status.removeClass("loading").addClass("error").text(i18n.failed + "Network error");
    });
  });

  /**
   * Check Migration Status
   */
  $("#mcqvs-check-migration").on("click", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-migration-check-status");
    $btn.prop("disabled", true);
    $status.text(i18n.testing || "Checking...");

    $.post(
      mcqvsSettings.ajaxUrl,
      {
        action: "mcqvs_get_migration_status",
        nonce: mcqvsSettings.nonce
      },
      function (response) {
        $btn.prop("disabled", false);
        if (response.success) {
          $status.text("Found " + response.data.total + " legacy posts pending migration.");
        } else {
          $status.text("Error: " + response.data);
        }
      }
    );
  });

  /**
   * Run Migration (Batch)
   */
  $("#mcqvs-run-migration").on("click", function () {
    var $btn = $(this);
    var $progress = $("#mcqvs-migration-progress");
    var $bar = $("#mcqvs-migration-bar");
    var $log = $("#mcqvs-migration-log");

    $btn.prop("disabled", true);
    $progress.show();
    $log.text("Starting migration...");
    $bar.css("width", "0%");

    var processed = 0;
    var total = 0;

    // 1. Get Total First
    $.post(mcqvsSettings.ajaxUrl, { action: "mcqvs_get_migration_status", nonce: mcqvsSettings.nonce }, function (res) {
      if (res.success) {
        total = parseInt(res.data.total);
        if (total === 0) {
          $log.text("Nothing to migrate!");
          $btn.prop("disabled", false);
          return;
        }
        $log.text("Migrating " + total + " items...");
        runBatch();
      } else {
        $log.text("Failed to start: " + res.data);
        $btn.prop("disabled", false);
      }
    });

    function runBatch() {
      $.post(
        mcqvsSettings.ajaxUrl,
        {
          action: "mcqvs_run_migration",
          nonce: mcqvsSettings.nonce,
          offset: 0 // Always 0 because we filter out migrated ones logic
        },
        function (response) {
          if (response.success) {
            var stats = response.data;
            processed += stats.migrated;
            var errors = stats.errors;

            // Update logic: total might change if we use offset logic differently, 
            // but assumed total is fixed snapshots. 
            // Actually, let's just use percentage of (Processed / Initial Total)
            // If processed > total (due to race conditions), cap at 100

            var pct = Math.min(100, Math.round((processed / total) * 100));
            $bar.css("width", pct + "%");
            $log.text("Migrated: " + processed + " | Errors: " + errors + " | Remaining: " + stats.remaining);

            if (!stats.done && stats.remaining > 0) {
              runBatch();
            } else {
              $log.text("Migration Complete! " + processed + " items migrated.");
              $btn.prop("disabled", false);
              $bar.css("width", "100%");
            }
          } else {
            $log.text("Error in batch: " + response.data);
            $btn.prop("disabled", false);
          }
        }
      ).fail(function () {
        $log.text("Network error. Retrying...");
        setTimeout(runBatch, 2000);
      });
    }
  });

  /**
   * Test API Connection (Gemini or Custom Provider).
   */
  $(document).on("click", ".mcqvs-test-api-btn", function () {
    var $btn = $(this);
    var provider = $btn.data("provider");
    var $status = $( ".mcqvs-test-status[data-provider='" + provider + "']" );

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(i18n.testing);

    // @FIX F-DATA-LOSS: Sync hidden JSON before reading field values so any unsaved
    // edits in the card survive a tab switch immediately after the test.
    try { syncHiddenJson(); } catch (e) {}

    var postData = {
      action: "mcqvs_test_" + (provider === "gemini" ? "gemini" : "custom_provider"),
      nonce: mcqvsSettings.nonce,
    };

    if (provider !== "gemini") {
      postData.provider_id = provider;
      var $card = $btn.closest(".mcqvs-provider-card");
      postData.temp_name = $card.find('[data-field="name"]').val() || "";
      postData.temp_url = $card.find('[data-field="api_url"]').val() || "";
      postData.temp_key = $card.find('[data-field="api_key"]').val() || "";
      var models = [];
      $card.find(".mcqvs-models-list .mcqvs-model-row").each(function () {
        var mid = $(this).find(".cp-model-id").val();
        var mname = $(this).find(".cp-model-name").val();
        if (mid) models.push({ model_id: mid, display_name: mname || mid });
      });
      postData.temp_models = JSON.stringify(models);
    }

    $.post(mcqvsSettings.ajaxUrl, postData, function (response) {
      $btn.prop("disabled", false);
      $status.removeClass("loading");
      if (response.success) {
        var d = response.data;
        $status.addClass("success").text(i18n.success + " Model: " + (d.model || "") + ", Provider: " + (d.provider || ""));
      } else {
        $status.addClass("error").text(i18n.failed + (response.data || "Unknown error"));
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $status.removeClass("loading").addClass("error").text(i18n.failed + "Network error");
    });
  });

  /**
   * Save Custom Provider (AJAX, not form submit).
   */
  $(document).on("click", ".mcqvs-save-custom-provider", function () {
    var $btn = $(this);
    var providerId = $btn.data("provider-id");
    var $card = $btn.closest(".mcqvs-provider-card");
    var $status = $(".mcqvs-test-status[data-provider='" + providerId + "']");

    var profile = { id: providerId };
    $card.find(".cp-field").each(function () {
      var field = $(this).data("field");
      if (field === "supports_json_schema" || field === "enable_web_search" || field === "fallback_enabled") {
        profile[field] = $(this).is(":checked");
      } else {
        profile[field] = $(this).val();
      }
    });
    var models = [];
    $card.find(".mcqvs-models-list .mcqvs-model-row").each(function () {
      var mid = $(this).find(".cp-model-id").val();
      var mname = $(this).find(".cp-model-name").val();
      if (mid) models.push({ model_id: mid, display_name: mname || mid });
    });
    profile.models = models;

    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text("Saving...");

    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_save_custom_provider",
      nonce: mcqvsSettings.nonce,
      profile: JSON.stringify(profile),
    }, function (response) {
      $btn.prop("disabled", false);
      $status.removeClass("loading");
      if (response.success) {
        $status.addClass("success").text(response.data.message || "Saved!");
        var hiddenJson = $("#mcqvs_custom_providers_json").val();
        try { syncHiddenJson(); } catch(e) {}
      } else {
        $status.addClass("error").text("Save failed: " + (response.data || "Unknown error"));
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $status.removeClass("loading").addClass("error").text("Network error");
    });
  });

  /**
   * Delete Custom Provider.
   */
  $(document).on("click", ".mcqvs-delete-custom-provider", function () {
    if (!confirm("Delete this custom provider?")) return;
    var $btn = $(this);
    var providerId = $btn.data("provider-id");

    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_delete_custom_provider",
      nonce: mcqvsSettings.nonce,
      provider_id: providerId,
    }, function (response) {
      if (response.success) {
        $btn.closest(".mcqvs-provider-card").fadeOut(300, function () { $(this).remove(); });
        $("#mcqvs_api_provider option[value='" + providerId + "']").remove();
      } else {
        alert("Delete failed: " + (response.data || "Unknown"));
      }
    });
  });

  /**
   * Add Model row to a custom provider.
   */
  $(document).on("click", ".mcqvs-add-model", function () {
    var profileId = $(this).data("profile-id");
    var $list = $(".mcqvs-models-list[data-profile-id='" + profileId + "']");
    var $row = $('<div class="mcqvs-model-row">' +
      '<input type="text" class="cp-model-id" value="" placeholder="model-id" />' +
      '<input type="text" class="cp-model-name" value="" placeholder="Display Name" />' +
      '<button type="button" class="button button-small mcqvs-remove-model" title="Remove model">&times;</button>' +
      '</div>');
    $list.append($row);
  });

  /**
   * Remove Model row.
   */
  $(document).on("click", ".mcqvs-remove-model", function () {
    $(this).closest(".mcqvs-model-row").remove();
  });

  /**
   * Add New Custom Provider (creates a blank card).
   */
  $("#mcqvs-add-custom-provider").on("click", function () {
    var newId = "prov_" + Math.floor(Date.now() / 1000) + "_" + Math.random().toString(36).substring(2, 7);
    var html = '<div class="mcqvs-provider-card" data-provider="' + newId + '" data-custom="1" data-profile-id="' + newId + '">' +
      '<div class="mcqvs-provider-card-header">' +
        '<h4>New Custom Provider</h4>' +
        '<div><button type="button" class="button button-small mcqvs-delete-custom-provider" data-provider-id="' + newId + '" style="color:#d63638;">Delete</button></div>' +
      '</div>' +
      '<div class="mcqvs-provider-card-body">' +
        '<div class="form-field"><label>Name</label><input type="text" class="cp-field" data-field="name" value="" placeholder="e.g. DeepSeek" /></div>' +
        '<div class="form-field"><label>API URL</label><input type="url" class="cp-field regular-text" data-field="api_url" value="" placeholder="https://api.deepseek.com/v1" /></div>' +
        '<div class="form-field"><label>API Key</label><input type="password" class="cp-field" data-field="api_key" value="" /></div>' +
        '<div class="form-field"><label>Models</label>' +
          '<div class="mcqvs-models-list" data-profile-id="' + newId + '">' +
            '<div class="mcqvs-model-row"><input type="text" class="cp-model-id" value="" placeholder="model-id" /><input type="text" class="cp-model-name" value="" placeholder="Display Name" /><button type="button" class="button button-small mcqvs-remove-model" title="Remove model">&times;</button></div>' +
          '</div>' +
          '<button type="button" class="button button-small mcqvs-add-model" data-profile-id="' + newId + '">+ Add Model</button>' +
        '</div>' +
        '<div class="form-field"><label>Options</label>' +
          '<label style="width:auto;font-weight:normal;margin-right:15px;"><input type="checkbox" class="cp-field" data-field="supports_json_schema" value="1" /> JSON Schema</label>' +
          '<label style="width:auto;font-weight:normal;margin-right:15px;"><input type="checkbox" class="cp-field" data-field="enable_web_search" value="1" /> Web Search</label>' +
          '<label style="width:auto;font-weight:normal;"><input type="checkbox" class="cp-field" data-field="fallback_enabled" value="1" /> Fallback</label>' +
        '</div>' +
        '<div class="form-field"><label>Test</label>' +
          '<button type="button" class="button button-secondary mcqvs-test-api-btn" data-provider="' + newId + '">Test Connection</button>' +
          '<button type="button" class="button button-primary mcqvs-save-custom-provider" data-provider-id="' + newId + '" style="margin-left:8px;">Save Provider</button>' +
          '<span class="mcqvs-status mcqvs-test-status" data-provider="' + newId + '"></span>' +
        '</div>' +
      '</div>' +
    '</div>';

    $("#mcqvs-custom-providers-container").append(html);
    $("#mcqvs_api_provider").append('<option value="' + newId + '">New Custom Provider (unsaved)</option>');
  });

  function syncHiddenJson() {
    var providers = [];
    var $container = $("#mcqvs-custom-providers-container");
    if ($container.length === 0) { return; }
    $container.find(".mcqvs-provider-card").each(function () {
      var $card = $(this);
      var profile = { id: $card.data("profile-id") || $card.data("provider") };
      $card.find(".cp-field").each(function () {
        var field = $(this).data("field");
        if (field === "supports_json_schema" || field === "enable_web_search" || field === "fallback_enabled") {
          profile[field] = $(this).is(":checked");
        } else {
          profile[field] = $(this).val();
        }
      });
      var models = [];
      $card.find(".mcqvs-models-list .mcqvs-model-row").each(function () {
        var mid = $(this).find(".cp-model-id").val();
        var mname = $(this).find(".cp-model-name").val();
        if (mid) models.push({ model_id: mid, display_name: mname || mid });
      });
      profile.models = models;
      providers.push(profile);
    });
    $("#mcqvs_custom_providers_json").val(JSON.stringify(providers));
  }

  $("#mcqvs-reset-rotation-failures").on("click", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-rotation-reset-status");
    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text("Resetting...");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_reset_rotation",
      nonce: mcqvsSettings.nonce,
    }, function (response) {
      $btn.prop("disabled", false);
      $status.removeClass("loading");
      if (response.success) {
        $status.addClass("success").text("Reset! Reload the page to see updated queue.");
      } else {
        $status.addClass("error").text("Error: " + (response.data || "Unknown"));
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $status.removeClass("loading").addClass("error").text("Network error");
    });
  });

  $("form").on("submit", function () {
    syncBuiltinCustomModels();
    syncHiddenJson();
  });

  // @FIX F-DATA-LOSS: Keep the hidden JSON in sync with every edit made inside any
  // provider card so tab switching / page reload doesn't lose unsaved field state.
  $(document).on("input change", ".mcqvs-provider-card input, .mcqvs-provider-card select, .mcqvs-custom-models-list input", function () {
    try { syncHiddenJson(); syncBuiltinCustomModels(); } catch (e) {}
  });

  // @FIX F-DATA-LOSS: Serialize hidden JSON before unloading the page so the next
  // page load (after a Save on another tab) still sees the latest provider values
  // when the user comes back without explicitly saving here.
  $(window).on("beforeunload", function () {
    try { syncHiddenJson(); syncBuiltinCustomModels(); } catch (e) {}
  });

  $(document).on("click", ".mcqvs-add-builtin-model", function () {
    var provider = $(this).data("provider");
    var $list = $(".mcqvs-custom-models-list[data-provider='" + provider + "']");
    var $row = $('<div class="mcqvs-model-row">' +
      '<input type="text" class="builtin-model-id" value="" placeholder="model-id" />' +
      '<input type="text" class="builtin-model-name" value="" placeholder="Display Name" />' +
      '<button type="button" class="button button-small mcqvs-remove-builtin-model" title="Remove">&times;</button>' +
      '</div>');
    $list.append($row);
  });

  $(document).on("click", ".mcqvs-remove-builtin-model", function () {
    $(this).closest(".mcqvs-model-row").remove();
  });

  function syncBuiltinCustomModels() {
    var $list = $(".mcqvs-custom-models-list");
    if ($list.length === 0) { return; }
    $list.each(function () {
      var provider = $(this).data("provider");
      var models = [];
      $(this).find(".mcqvs-model-row").each(function () {
        var mid = $(this).find(".builtin-model-id").val();
        var mname = $(this).find(".builtin-model-name").val();
        if (mid) models.push({ model_id: mid, display_name: mname || mid });
      });
      var hiddenId = "#mcqvs_gemini_custom_models_json";
      $(hiddenId).val(JSON.stringify(models));
    });
  }

  // @NEW 2026-07-07: Dashboard "Reset Stuck Pipeline" emergency button.
  $(document).on("click", "#mcqvs-reset-stuck", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-reset-stuck-status");
    var confirmMsg = mcqvsSettings.i18n.resetStuckConfirm || "Force-reset any wedged/stuck render jobs back to the queue? The next cron will re-spawn them.";
    confirmMsg += "\n\nA 7-minute cooldown is applied to prevent instant re-pickup. Rendering counts should drop to 0.";
    if (!confirm(confirmMsg)) {
      return;
    }
    $btn.prop("disabled", true);
    $status.removeClass("success error").addClass("loading").text(mcqvsSettings.i18n.resetting || "Resetting...");

    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_reset_stuck_pipeline",
      nonce: mcqvsSettings.nonce,
      scope: "rendering"
    }, function (response) {
      $btn.prop("disabled", false);
      $status.removeClass("loading");
      if (response.success) {
        var msg = response.data.message || "Done.";
        var extra = "";
        if (response.data.after) {
          var a = response.data.after;
          extra = " Now: rendering=" + (a.rendering || 0) +
                  ", queued=" + ((a.pending || 0) + (a.ready_for_render || 0)) +
                  ", completed=" + (a.completed || 0) + ".";
        }
        if (response.data.orphan_claims) {
          extra += " (cancelled " + response.data.orphan_claims + " orphan claim(s))";
        }
        extra += " The pipeline is on a 7-minute cooldown to prevent immediate re-pickup. Reloading in 3s...";
        $status.addClass("success").text(msg + extra);
        setTimeout(function () { location.reload(); }, 3000);
      } else {
        $status.addClass("error").text("Failed: " + (response.data || "Unknown error"));
      }
    }).fail(function () {
      $btn.prop("disabled", false);
      $status.removeClass("loading").addClass("error").text("Network error");
    });
  });

  // @FIX 1.4.9.53 (global STOP): Dashboard "Stop Everything" button.
  // Kills live renders, cancels all queues/crons/AI batches, blocks new Buffer
  // posts. NON-destructive — no tables/options deleted. Resume restarts.
  $(document).on("click", "#mcqvs-stop-all", function () {
    var $btn = $(this);
    var confirmMsg = "STOP EVERYTHING?\n\nThis will:\n• Kill all running video renders (mid-render jobs return to Ready and re-render on Resume)\n• Cancel all queues, cron tasks and AI question-generation batches\n• Stop new Buffer posts (already-sent posts cannot be recalled)\n• Pause the Studio Auto-Runner\n\nNo data is deleted — jobs, plan, bank and settings stay intact.\n\nClick Resume on this Dashboard to start again.";
    if (!confirm(confirmMsg)) {
      return;
    }
    $btn.prop("disabled", true).text("Stopping\u2026");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_stop_all",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false);
      if (response.success) {
        alert(response.data.message || "Stopped everything.");
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        $btn.text("⏹ Stop Everything");
        alert("Stop failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("⏹ Stop Everything");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Stop failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : " — see server/PHP error log"));
    });
  });

  // @FIX 1.4.9.53 (global STOP): Dashboard "Resume" button (shown while stopped).
  // @FIX 1.4.9.54: Resume also SKIPS overdue calendar jobs (publish date passed
  // while stopped) — they're marked Cancelled, so no late flood on your feeds.
  $(document).on("click", "#mcqvs-resume-all", function () {
    var $btn = $(this);
    if (!confirm("Resume the pipeline?\n\n• Overdue jobs (publish date passed while stopped) will be SKIPPED — marked Cancelled, no late flood.\n• Future jobs stay on schedule; cron tasks re-register and ready jobs render.")) {
      return;
    }
    $btn.prop("disabled", true).text("Resuming\u2026");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_resume_all",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false);
      if (response.success) {
        alert(response.data.message || "Resumed.");
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        $btn.text("▶ Resume");
        alert("Resume failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("▶ Resume");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Resume failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : " — see server/PHP error log"));
    });
  });

  // @NEW 2026-07-08: Dashboard "Reset Plugin" master button.
  $(document).on("click", "#mcqvs-reset-plugin", function () {
    var $btn = $(this);
    var confirmMsg = mcqvsSettings.i18n.resetPluginConfirm || "WARNING: This will TRUNCATE all plugin tables except the MCQ bank. Continue?";
    if (!confirm(confirmMsg)) {
      return;
    }
    $btn.prop("disabled", true).text(mcqvsSettings.i18n.resetPlugin || "Resetting Plugin\u2026");

    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_reset_plugin",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Reset Plugin");
      if (response.success) {
        alert(response.data.message || "Reset complete.");
        // Give the server a moment to finish, then reload to the fresh dashboard.
        setTimeout(function () { location.reload(); }, 2000);
      } else {
        alert("Reset failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Reset Plugin");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Reset failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : " — see server/PHP error log"));
    });
  });

  // @FIX 1.4.9.43 (self-sufficient): Settings > Headless "Setup Server Environment".
  // Provisions Node + canvas + ffmpeg from the admin UI — no SSH.
  $(document).on("click", "#mcqvs-setup-env", function () {
    var $btn = $(this);
    var $status = $("#mcqvs-setup-env-status");
    var original = $btn.text();
    $btn.prop("disabled", true).text("Setting up\u2026 (can take 1-3 min on first run)");
    $status.removeClass("success error").addClass("loading").text("Provisioning Node.js + canvas + ffmpeg\u2026");

    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_setup_environment",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text(original);
      $status.removeClass("loading");
      if (response.success) {
        var d = response.data || {};
        var lines = [];
        if (d.steps) { $.each(d.steps, function (k, v) { lines.push(k + ": " + v); }); }
        if (d.verify) { lines.push("--- verification ---"); $.each(d.verify, function (k, v) { lines.push(k + ": " + v); }); }
        if (d.errors && d.errors.length) { lines.push("--- errors ---"); $.each(d.errors, function (i, e) { lines.push("* " + e); }); }
        if (d.all_ok) { $status.addClass("success"); } else { $status.addClass("error"); }
        $status.html("<pre style=\"text-align:left;max-height:320px;overflow:auto;\">" + lines.join("\n").replace(/</g, "&lt;") + "</pre>");
      } else {
        $status.addClass("error").text("Setup failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text(original);
      $status.removeClass("loading").addClass("error");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      $status.text("Setup failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ": " + msg : " — see server/PHP error log"));
    });
  });

  // @FIX 1.4.9.41 (data-loss): "Restore Safety Backup" buttons (Dashboard header
  // #mcqvs-restore-backup + Settings > Data #mcqvs-restore-backup-data).
  // Refills missing Content Planner / batch tracker / batches / retention
  // settings / API keys from the last auto-backup. Never overwrites existing data.
  $(document).on("click", "#mcqvs-restore-backup, #mcqvs-restore-backup-data", function () {
    var $btn = $(this);
    var confirmMsg = "Restore missing data (Content Planner, batch tracker, batches, retention settings) from the last auto-backup? Only missing values are refilled — existing data is never overwritten.";
    if (!confirm(confirmMsg)) {
      return;
    }
    $btn.prop("disabled", true).text("Restoring\u2026");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_restore_backup",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Restore Safety Backup");
      if (response.success) {
        alert((response.data && response.data.message) || "Restore complete.");
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        alert("Restore failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Restore Safety Backup");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Restore failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : " — see server/PHP error log"));
    });
  });

  // @NEW 2026-07-30: Dashboard "Clear Ready Jobs" button.
  $("#mcqvs-clear-ready").on("click", function () {
    var $btn = $(this);
    if (!confirm("Delete all ready-for-render jobs? This cannot be undone.")) {
      return;
    }
    $btn.prop("disabled", true).text("Clearing...");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_clear_ready_jobs",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Clear");
      if (response.success) {
        alert(response.data.message);
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        alert("Failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Clear");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Request failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : ""));
    });
  });

  // @NEW 2026-07-30: Dashboard "Clear Queued Jobs" button.
  $("#mcqvs-clear-queued").on("click", function () {
    var $btn = $(this);
    if (!confirm("Delete all queued (pending) jobs? This cannot be undone.")) {
      return;
    }
    $btn.prop("disabled", true).text("Clearing...");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_clear_queued_jobs",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Clear");
      if (response.success) {
        alert(response.data.message);
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        alert("Failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Clear");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Request failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : ""));
    });
  });

  // @NEW 2026-07-30: Dashboard "Clear Questions" button (Questions Generated KPI).
  $("#mcqvs-clear-questions").on("click", function () {
    var $btn = $(this);
    if (!confirm("Delete ALL questions from the MCQ bank? This cannot be undone.")) {
      return;
    }
    $btn.prop("disabled", true).text("Clearing...");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_clear_questions",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Clear Questions");
      if (response.success) {
        alert(response.data.message);
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        alert("Failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Clear Questions");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Request failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : ""));
    });
  });

  // @NEW 2026-07-30: Dashboard "Clear Full Queue" button (Jobs in Queue KPI).
  $("#mcqvs-clear-queue").on("click", function () {
    var $btn = $(this);
    if (!confirm("Delete all pending and ready-for-render jobs? This cannot be undone.")) {
      return;
    }
    $btn.prop("disabled", true).text("Clearing...");
    $.post(mcqvsSettings.ajaxUrl, {
      action: "mcqvs_clear_queue",
      nonce: mcqvsSettings.nonce
    }, function (response) {
      $btn.prop("disabled", false).text("Clear Queue");
      if (response.success) {
        alert(response.data.message);
        setTimeout(function () { location.reload(); }, 1500);
      } else {
        alert("Failed: " + (response.data || "Unknown error"));
      }
    }).fail(function (xhr) {
      $btn.prop("disabled", false).text("Clear Queue");
      var msg = xhr.responseText ? xhr.responseText.replace(/<[^>]+>/g, "").trim().slice(0, 500) : "";
      alert("Request failed (HTTP " + (xhr.status || "?") + ")" + (msg ? ":\n" + msg : ""));
    });
  });

  // @NEW 2026-07-18: Live render progress polling for dashboard pipeline jobs table.
  (function () {
      var pollInterval = null;
      var pollFrequency = 5000; // 5 seconds

      function startProgressPolling() {
          if (pollInterval) {
              clearInterval(pollInterval);
          }
          pollInterval = setInterval(updateRenderProgress, pollFrequency);
          updateRenderProgress(); // Initial run
      }

      function stopProgressPolling() {
          if (pollInterval) {
              clearInterval(pollInterval);
              pollInterval = null;
          }
      }

      function updateRenderProgress() {
          var $renderRows = jQuery('.mcqvs-render-progress');
          if ($renderRows.length === 0) {
              stopProgressPolling();
              return;
          }

          $renderRows.each(function () {
              var $row = jQuery(this);
              var jobId = $row.data('job-id');
              if (!jobId) return;

              var $bar = $row.find('.mcqvs-render-progress-bar');
              var $pct = $row.find('.mcqvs-render-progress-pct');

              jQuery.post(mcqvsSettings.ajaxUrl, {
                  action: 'mcqvs_get_render_progress',
                  nonce: mcqvsSettings.nonce,
                  job_id: jobId
              }, function (response) {
                  if (response.success && response.data) {
                      var progress = parseInt(response.data.progress, 10);
                      var status = response.data.status || 'unknown';

                      if (progress >= 0 && progress <= 100) {
                          if ($bar.length) $bar.css('width', progress + '%');
                          if ($pct.length) $pct.text(progress + '%');
                      }

                      // Stop polling for completed/failed jobs
                      if (status === 'completed' || status === 'failed') {
                          $row.removeClass('mcqvs-render-progress');
                          if (status === 'completed') {
                              if ($bar.length) $bar.css('width', '100%');
                              if ($pct.length) $pct.text('100%').css('color', '#22c55e');
                          }
                      }
                  }
              });
          });

          // If no more rendering jobs, stop polling
          if (jQuery('.mcqvs-render-progress').length === 0) {
              stopProgressPolling();
          }
      }

      // Start polling when dashboard is loaded
      if (jQuery('.mcqvs-render-progress').length > 0) {
          startProgressPolling();
      }

      // Clean up on page unload
      jQuery(window).on('beforeunload', stopProgressPolling);
  })();

  // @NEW 2026-08-01: Buffer Multi-Account Management (per-account cards)
  (function ($) {
    var $accountsWrap = $('#mcqvs-buffer-accounts-wrap');
    var $loading = $('#mcqvs-buffer-accounts-loading');

    function showLoading(show) {
      $loading.toggle(show);
      $accountsWrap.toggle(!show);
    }

    function ajax(action, data, callback) {
      data = data || {};
      data.action = action;
      data.nonce = mcqvsSettings.nonce;
      $.post(mcqvsSettings.ajaxUrl, data, function (response) {
        if (callback) callback(response);
      }).fail(function () {
        if (callback) callback({ success: false, data: 'Network error' });
      });
    }

    function reloadAccountsTable() {
      location.reload(); // Simplest: full reload to keep PHP-rendered cards in sync
    }

    // Save account (collects every setting + selected channels inside the card)
    $accountsWrap.on('click', '.mcqvs-save-account', function () {
      var $btn = $(this);
      var accountId = $btn.data('account-id');
      var $card = $btn.closest('.mcqvs-buffer-account-card');

      var channels = [];
      var channel_types = {};
      var channel_link_posts = {};
      var channel_captions = {};
      var channel_post_to_story = {};
      $card.find('.mcqvs-ch-enable:checked').each(function () {
        var $row = $(this).closest('tr');
        var cid = $(this).val();
        channels.push(cid);
        channel_types[cid] = $row.find('.mcqvs-ch-type').val() || 'post';
        if ($row.find('.mcqvs-ch-link').is(':checked')) {
          channel_link_posts[cid] = 1;
        }
        // @NEW 2026-08-10: Per-channel caption / story overrides. We collect
        // these for EVERY enabled channel so the server has a canonical map
        // (empty strings included) — the registry sanitizes.
        var capVal = $card.find('.mcqvs-ch-caption[data-channel-id="' + cid + '"]').val();
        if (typeof capVal === 'string' && capVal.trim() !== '') {
          channel_captions[cid] = capVal;
        }
        // @FIX 2026-08-13: Always send 1/0 for EVERY enabled channel (not just
        // checked ones). An object containing only checked ticks becomes {} when
        // the user unchecks all — jQuery drops empty nested objects from the
        // serialized body, so PHP receives no channel_post_to_story key at all,
        // update_account() skips the save, and the tick "comes back" on refresh.
        channel_post_to_story[cid] = $row.find('.mcqvs-ch-story').is(':checked') ? 1 : 0;
      });

      var data = {
        account_id: accountId,
        label: $card.find('.mcqvs-account-label').val(),
        token: $card.find('.mcqvs-account-token').val(),
        enabled: $card.find('.mcqvs-account-toggle').is(':checked'),
        daily_limit: parseInt($card.find('.mcqvs-account-daily-limit').val(), 10) || 0,
        scheduling_mode: $card.find('.mcqvs-account-scheduling-mode').val(),
        caption_template: $card.find('.mcqvs-account-caption-template').val(),
        youtube_title: $card.find('.mcqvs-account-youtube-title').val(),
        youtube_category: $card.find('.mcqvs-account-youtube-category').val(),
        channels: channels,
        channel_types: channel_types,
        channel_link_posts: channel_link_posts,
        // @NEW 2026-08-10: Per-channel maps. Sent as JS objects so PHP reads
        // them as $_POST arrays; the server-side sanitizer on the registry
        // validates the keys + values before persisting.
        channel_captions: channel_captions,
        channel_post_to_story: channel_post_to_story,
      };

      $btn.prop('disabled', true).text('Saving...');
      ajax('mcqvs_save_buffer_account', data, function (response) {
        $btn.prop('disabled', false).text('Save Account');
        if (response.success) {
          $card.find('.mcqvs-account-token').val('');
          $btn.addClass('button-primary').text('Saved!');
          setTimeout(function () { $btn.removeClass('button-primary').text('Save Account'); }, 2000);
        } else {
          alert('Save failed: ' + (response.data || 'Unknown error'));
        }
      });
    });

    // @NEW 2026-08-10: Pencil icon toggles the per-channel caption editor row.
    // The detail row sits immediately after the channel row; we flip its
    // display and update the pencil visual state so the user can see which
    // channels have a custom caption configured.
    $accountsWrap.on('click', '.mcqvs-ch-caption-toggle', function (e) {
      e.preventDefault();
      var $btn = $(this);
      var cid = $btn.data('channel-id');
      var $card = $btn.closest('.mcqvs-buffer-account-card');
      var $detail = $card.find('.mcqvs-channel-detail-row[data-channel-id="' + cid + '"]');
      if (!$detail.length) return;
      var isHidden = $detail.is(':hidden') || $detail.css('display') === 'none';
      $detail.toggle(isHidden);
      $btn.toggleClass('mcqvs-ch-caption-active', isHidden);
    });

    // @NEW 2026-08-10: Live char-counter for the per-channel caption editor.
    // Shows "X / limit" so the user knows when a Twitter/X caption is about
    // to be truncated at push time. Pure UX; the actual truncation happens
    // server-side via truncate_caption_for_service().
    $accountsWrap.on('input', '.mcqvs-ch-caption', function () {
      var $ta = $(this);
      var $row = $ta.closest('.mcqvs-channel-detail-row');
      var cid = $ta.data('channel-id');
      var $card = $ta.closest('.mcqvs-buffer-account-card');
      var $dataRow = $card.find('.mcqvs-channel-row[data-channel-id="' + cid + '"]');
      var limit = parseInt($dataRow.data('char-limit'), 10) || 0;
      var counter = $row.find('.mcqvs-ch-caption-counter');
      if (!counter.length) {
        counter = $('<span class="mcqvs-ch-caption-counter" style="float:right;font-size:11px;color:#64748b;font-weight:400;"></span>');
        $ta.before(counter);
      }
      var len = ($ta.val() || '').length;
      if (limit > 0) {
        counter.text(len + ' / ' + limit + ' chars');
        counter.css('color', len > limit ? '#dc2626' : '#64748b');
      } else {
        counter.text(len + ' chars');
        counter.css('color', '#64748b');
      }
    });
    // Trigger the counter once on load so previously-saved values show their length.
    $accountsWrap.find('.mcqvs-ch-caption').trigger('input');

    // Toggle enabled
    $accountsWrap.on('change', '.mcqvs-account-toggle', function () {
      var $toggle = $(this);
      var $card = $toggle.closest('.mcqvs-buffer-account-card');
      var $saveBtn = $card.find('.mcqvs-save-account');
      $saveBtn.prop('disabled', false); // Enable save button when changed
    });

    // Set as default
    $accountsWrap.on('change', '.mcqvs-set-default-account', function () {
      var accountId = $(this).val();
      ajax('mcqvs_set_default_buffer_account', { account_id: accountId }, function (response) {
        if (response.success) {
          reloadAccountsTable();
        } else {
          alert('Failed: ' + (response.data || 'Unknown error'));
        }
      });
    });

    // Delete account
    $accountsWrap.on('click', '.mcqvs-delete-account', function () {
      if (!confirm(mcqvsSettings.i18n.deleteAccountConfirm || 'Delete this Buffer account? This cannot be undone.')) return;
      var accountId = $(this).data('account-id');
      ajax('mcqvs_delete_buffer_account', { account_id: accountId }, function (response) {
        if (response.success) {
          reloadAccountsTable();
        } else {
          alert('Delete failed: ' + (response.data || 'Unknown error'));
        }
      });
    });

    // Toggle the collapsed "Add New Buffer Account" card
    // Delegated on document so it works regardless of DOM timing / re-renders.
    $(document).on('click', '#mcqvs-toggle-add-account', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $btn = $(this);
      var $body = $btn.closest('.mcqvs-add-account-card').find('.mcqvs-add-account-body');
      if (!$body.length) {
        alert('Add Account form body not found.');
        return;
      }
      var hidden = $body.is(':hidden');
      $body.toggle(hidden);
      $btn.text(hidden ? 'Hide Form' : 'Show Form');
    });

    // Add new account
    // Use delegated binding on document so it survives any DOM re-render and
    // works even if the button isn't present at script-execution time.
    $(document).on('click', '#mcqvs-add-buffer-account', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $btn = $(this);
      var data = {
        label: $('#mcqvs-new-account-label').val(),
        token: $('#mcqvs-new-account-token').val(),
        enabled: $('#mcqvs-new-account-enabled').is(':checked'),
        daily_limit: parseInt($('#mcqvs-new-account-daily-limit').val(), 10) || 0,
        scheduling_mode: $('#mcqvs-new-account-scheduling-mode').val(),
        caption_template: $('#mcqvs-new-account-caption-template').val(),
      };

      if (!data.label || !data.token) {
        alert('Label and token are required.');
        return;
      }

      $btn.prop('disabled', true).text('Adding...');
      showLoading(true);

      ajax('mcqvs_add_buffer_account', data, function (response) {
        $btn.prop('disabled', false).text('Add Account');
        showLoading(false);
        if (response.success) {
          $('#mcqvs-new-account-label').val('');
          $('#mcqvs-new-account-token').val('');
          $('#mcqvs-new-account-daily-limit').val(0);
          $('#mcqvs-new-account-caption-template').val('');
          reloadAccountsTable();
        } else {
          alert('Add failed: ' + (response.data || 'Unknown error'));
        }
      });
    });
    // @NEW 2026-08-10: Branding Logo upload (Assets tab).
    // Copies the selected Media Library image into the plugin assets folder via
    // AJAX (mcqvs_upload_branding_logo) and persists MCQVS_studio_branding.logo_url.
    (function ($) {
      var $selectBtn = $("#mcqvs-logo-select");
      if ($selectBtn.length === 0) return;

      var $preview = $("#mcqvs-logo-preview");
      var $empty = $("#mcqvs-logo-preview-empty");
      var $removeBtn = $("#mcqvs-logo-remove");
      var $spinner = $("#mcqvs-logo-spinner");
      var $status = $("#mcqvs-logo-status");
      var $posSelect = $("#mcqvs-logo-position");
      var $posSpinner = $("#mcqvs-logo-pos-spinner");
      var $posStatus = $("#mcqvs-logo-pos-status");

      function showStatus($el, msg, isError) {
        if (!$el || !$el.length) return;
        $el.text(msg).css("color", isError ? "#d63638" : "#2271b1");
      }

      // Select from Media Library
      $selectBtn.on("click", function (e) {
        e.preventDefault();
        var frame = wp.media({
          title: "Select Branding Logo",
          library: { type: "image" },
          button: { text: "Use this logo" },
          multiple: false
        });
        frame.on("select", function () {
          var attachment = frame.state().get("selection").first().toJSON();
          if (!attachment || !attachment.id) return;
          $spinner.addClass("is-active");
          showStatus($status, "Copying logo into plugin assets...");
          $.post(mcqvsSettings.ajaxUrl, {
            action: "mcqvs_upload_branding_logo",
            nonce: mcqvsSettings.nonce,
            attachment_id: attachment.id
          }, function (response) {
            $spinner.removeClass("is-active");
            if (response.success && response.data) {
              var url = response.data.logo_url || attachment.url || "";
              if (url) {
                $preview.attr("src", url).show();
                $empty.hide();
                $removeBtn.show();
              }
              showStatus($status, response.data.message || "Logo saved!", false);
            } else {
              showStatus($status, response.data || "Upload failed", true);
            }
          }).fail(function () {
            $spinner.removeClass("is-active");
            showStatus($status, "Network error during upload", true);
          });
        });
        frame.open();
      });

      // Remove logo
      $removeBtn.on("click", function (e) {
        e.preventDefault();
        if (!window.confirm("Remove the branding logo? Videos will render without a logo until you upload a new one.")) return;
        $spinner.addClass("is-active");
        showStatus($status, "Removing...");
        $.post(mcqvsSettings.ajaxUrl, {
          action: "mcqvs_remove_branding_logo",
          nonce: mcqvsSettings.nonce
        }, function (response) {
          $spinner.removeClass("is-active");
          if (response.success) {
            $preview.attr("src", "").hide();
            $empty.show();
            $removeBtn.hide();
            showStatus($status, "Logo removed", false);
          } else {
            showStatus($status, response.data || "Remove failed", true);
          }
        }).fail(function () {
          $spinner.removeClass("is-active");
          showStatus($status, "Network error during remove", true);
        });
      });

      // Save logo position (persisted to MCQVS_studio_branding.logo_pos)
      $posSelect.on("change", function () {
        $posSpinner.addClass("is-active");
        showStatus($posStatus, "Saving...");
        $.post(mcqvsSettings.ajaxUrl, {
          action: "mcqvs_save_branding_position",
          nonce: mcqvsSettings.nonce,
          logo_pos: $posSelect.val()
        }, function (response) {
          $posSpinner.removeClass("is-active");
          if (response.success) {
            showStatus($posStatus, "Position saved", false);
          } else {
            showStatus($posStatus, response.data || "Save failed", true);
          }
        }).fail(function () {
          $posSpinner.removeClass("is-active");
          showStatus($posStatus, "Network error", true);
        });
      });
    })(jQuery);

  })(jQuery);

})(jQuery);

