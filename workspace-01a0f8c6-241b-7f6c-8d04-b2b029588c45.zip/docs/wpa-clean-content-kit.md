# WPA Clean-Content Kit v3 — FINAL (regex box EMPTY)
2026-08-29. v2's "Image Source:.*" rule TRUNCATED posts to one image: WPA appends
the s modifier to every regex (core.php:1784: preg_replace('{'.$search.'}su')),
so .* ate everything from the first caption to the end of the article
(reproduced: 50,631 chars -> 548, 84 imgs -> 1). v3 removes ALL regex rules.

## Settings that work (stylesatlife campaign 31240)

### CSS visual strip (selector type: class) — BARE names, no tag., one per row
```
google-ad
ad-block
adsbygoogle
pinterest-share-button
img-caption
```
Kills: AdSense blocks, Pinterest Save buttons, "Image Source: Shutterstock" captions
(with their text — this is why no regex is needed).

### REGEX find/replace box
```
(EMPTY — no rules)
```
History: src-quoting rule unnecessary (admin inserts skip kses; browsers render
unquoted src fine). Image Source rule catastrophically unsafe with WPA's silent
`s` modifier. LESSON: never put `.*` to end-of-line in WPA regexes — dot always
crosses newlines.

### Strip HTML tags = ON, allowed list (angle brackets, no commas)
```
<p><h2><h3><h4><h5><strong><em><b><i><u><ul><ol><li><img><blockquote><table><tr><td><th><tbody>
```
Verified via log math: 49811 -> 28043 after strip = images retained (+~7k chars
of img tags vs text-only 18432).

## Re-run after any campaign edit
1. Delete bad draft(s)
2. Campaign → Delete cache (WPA dedupe + feed cache + image cache otherwise reuse)
3. Run campaign; verify log shows featured image set + no leftover junk

## Expected result: full article, ~38 images (hotlinked, unquoted src — renders fine),
## headings/paragraphs/lists, zero ads/buttons/captions/wrappers.

## shaadidukaan.com — VALIDATED CONFIG (2026-08-29, tested on real 29.7K input, ZERO junk, 53/53 imgs kept)
Campaign: /vogue/category/mehendi-design/feed/ · original-content mode (URLs soft-404 but return full HTML — fine)
Why rewrite: [^\n]* rules are line-structure-dependent (real input has 13.5K-char lines — one match eats 11K chars).
All rules below are tag-bounded (cannot cross </p> or >).

### Regex strip box (raw HTML):
<div class="mob-tit">.*?</div>|         <- Posted By/Last Updated/Post View/Comments + dup title  [1x]
<img[^>]*blog-featured[^>]*>|           <- duplicate lead image [1x]
<img[^>]*CTA[^>]*>|                     <- promo banners [2x]
<ul\b[^>]*class="look-ul"[^>]*>.*?</ul>|<- vendor list [1x]

### Search/Replace box (# separator):
<p\b[^>]*>(?:(?!</p>).)*?provides you with a complete guide(?:(?!</p>).)*?</p>#   <- 2nd-para promo, surgical [1x]
<p\b[^>]*>(?:(?!</p>).)*?Top vendors are getting booked(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?Book Now:(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?(?:Also|More) Checkout(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?also looking for(?:(?!</p>).)*?</p>#
<p\b[^>]*>\s*(?:<[^>]+>\s*)*(?:Image|Images|Picture|Photo|Pic|Source|Credit|Credits|Courtesy|Visual|Shared|Found|Research|Inspired|Based|Reference|Referenced|Reported|Captured)(?:\s+(?:By|On|From|via|Via|Credit|Credits|Courtesy))?\s*[:：][^<]{0,60}\s*(?:<[^>]+>\s*)*</p>#   <- ALL credit lines [53x]
<p\b[^>]*>[^<]*Get Your Personal Wedding Planner[^<]*</p>#
😊?\s*Get Your Personal Wedding Planner[^<]*call/chat with us[^<]*#
<p>\s*call/chat with us\s*</p>#
<p\b[^>]*>The post .*? appeared first on Shaadidukaan\.</p>#
<p\b[^>]*class="lab-part"[^>]*>.*?</p>#
<p\b[^>]*>\s*(?:<[^>]+>\s*)*</p>#       <- empty-para sweeper
(?:If|if)\s*you.{0,3}re\s*also\s*looking\s*for[^<]*#  <- loose-text vendor lead-in

Result on test article: 53 imgs, 2 h2, 22 h3, 24 paras, zero junk markers.

## shaadidukaan — CAMPAIGN-HARDENED boxes (post-mortem of 5 posts: bel, teej, bejewelled, moon, royal-front-hand)
Changes vs single-post config: cross-link rule generalized (Also Checkout: / Also Check:- / More Checkout:- / Read More:- / Also Read:- all in ONE rule).
Junk verified per post: credits x11 label variants (incl "Pic via:-", "Captured By:", "Based On:"), Top vendors promo (all posts),
Also Check/Read cross-links, vendor list, planner, CTA imgs. Share/Related-Tags = OUTSIDE extraction container (never imported).

### STRIP BOX (unchanged):
<div class="mob-tit">.*?</div>|
<img[^>]*blog-featured[^>]*>|
<img[^>]*CTA[^>]*>|
<ul\b[^>]*class="look-ul"[^>]*>.*?</ul>|

### REPLACE BOX (final, # separator):
<p\b[^>]*>(?:(?!</p>).)*?provides you with a complete guide(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?Top vendors are getting booked(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?Book Now:(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?(?:(?:Also|More)\s*(?:Check|Read)|Read\s*More|Must\s*Read)(?:(?!</p>).)*?</p>#
<p\b[^>]*>(?:(?!</p>).)*?also looking for(?:(?!</p>).)*?</p>#
<p\b[^>]*>\s*(?:<[^>]+>\s*)*(?:Image|Images|Picture|Photo|Pic|Source|Credit|Credits|Courtesy|Visual|Shared|Found|Research|Inspired|Based|Reference|Referenced|Reported|Captured)(?:\s+(?:By|On|From|via|Via|Credit|Credits|Courtesy))?\s*[:：][^<]{0,60}\s*(?:<[^>]+>\s*)*</p>#
<p\b[^>]*>[^<]*Get Your Personal Wedding Planner[^<]*</p>#
😊?\s*Get Your Personal Wedding Planner[^<]*call/chat with us[^<]*#
<p>\s*call/chat with us\s*</p>#
<p\b[^>]*>The post .*? appeared first on Shaadidukaan\.</p>#
<p\b[^>]*class="lab-part"[^>]*>.*?</p>#
<p\b[^>]*>\s*(?:<[^>]+>\s*)*</p>#
(?:If|if)\s*you.{0,3}re\s*also\s*looking\s*for[^<]*#

## DWI — Multi-page scraper FINAL (5-post audit: front-hand, personalized-bridal, simple-beautiful, indian-bridal-makeup, bridal-lehenga — ALL CLEAN, imgs 109/51/32 kept; makeup+lehenga are text-only guides BY DESIGN)

- Type: Multiple pages · URL: https://destinationweddingsindia.com/category/mehndi-bridal-styling/ (7 posts, no pagination)
- LINK extraction: CSS / class / entire-meta-link / outer / multiple  (validated: hrefs == exactly the 7 article URLs)
- CONTENT extraction: CSS / class / post-content / inner
- TITLE: Auto detect (all 5 titles clean, e.g. "Front Hand Mehndi Design 2026: 100+ Bridal & Simple Ideas"); og:image present on all 5
- VISUAL junk removal (content tab, XPath entries):
  //*[contains(@class,"dwiac-twrap")]
  //*[contains(@class,"wp-block-rank-math-toc-block")]
  //*[contains(@class,"wp-block-buttons")]
  //*[contains(@class,"wp-block-spacer")]
  //*[contains(@class,"link_wrap")]
  //pre[contains(@class,"wp-block-preformatted")]
  //style
  //script
- REPLACE box (# separator) — 13 rules, all tempered (no bare .*):
  <blockquote\b[^>]*>(?:(?!</blockquote>).)*?Enquire\s+Now(?:(?!</blockquote>).)*?</blockquote>#
  <p\b[^>]*>(?:(?!</p>).)*?(?:Email:|Connect with us to start planning)(?:(?!</p>).)*?</p>#
  <p\b[^>]*>Or connect with the team[^<]*</p>#
  <p\b[^>]*>[^<]*simple conversation[^<]*</p>#
  <p\b[^>]*>(?:(?!</p>).)*?we handle the rest(?:(?!</p>).)*?</p>#
  <p\b[^>]*>(?:(?!</p>).)*?our team is here to make the process(?:(?!</p>).)*?</p>#
  <h2[^>]*>(?:\s*<[^>]+>)*\s*About the Author(?:\s*<[^>]+>)*\s*</h2>#
  <p\b[^>]*>(?:\s*<[^>]+>)*\s*About the Author(?:(?!</p>).)*?</p>#
  <p\b[^>]*>(?:(?!</p>).)*?most trusted destination wedding venue booking platform(?:(?!</p>).)*?</p>#
  Mehndi Done\.?[^<]*#
  Find Your Venue[^<]*#
  <h2[^>]*>\s*Table of Contents\s*</h2>\s*<ul\b[^>]*>.*?</ul>#
  <p\b[^>]*>\s*(?:<[^>]+>\s*)*</p>#
- Strip tags ON + standard allowed list. //style+//script are CRITICAL (PHP strip_tags keeps their TEXT; WPA only guards script natively).
- Audit traps found & handled: inline <style> with .dwiac CSS text (front-hand), <pre> contact blocks (lehenga), p-form Email/Phone (makeup/simple), About-the-Author h2+boast-para (personalized/simple), Enquire blockquote (personalized), ToC block (front-hand+simple), CTA buttons+Mehndi Done/Find Your Venue (simple), dwiac city-grid (front-hand).

## shaadidukaan — FEED ABANDONED (2026-08-29): /vogue/ feed URLs = real 404 pages (verified). Feed content copies inconsistent (bel=full, teej=3 imgs) => 1-image posts. USE MULTI instead:
- Multi URL: https://www.shaadidukaan.com/blog-category/mehendi-design
- Link method REGEX (WPA adds {…}is, group 1 = URL): <a[^>]*href="(https://www\.shaadidukaan\.com/blog/[a-z0-9-]+\.html)"
  (selects exactly the 9 article cards; excludes /blog-category/ tiles, /blog/author/, footer — none end in .html under /blog/)
- Content: CSS class blog-discription, inner (mob-tit + blog-featured img live OUTSIDE it — their strip rules become harmless backstops)
- Cleaning boxes: UNCHANGED (same template as validated)
- Old Feed campaign: disable. Note: bel re-imports once via /blog/ URL (full version) — delete old draft if dupe unwanted.

---

## mirelleinspo.com — Multi-page FINAL (2026-08-30, 8/8 posts CLEAN, 75/75 imgs kept+absolutized, 0 junk)
Winner of nail-site audit (891 posts, ~5-8 posts/DAY, static Astro HTML, no WAF). 4 distinct article
templates verified (guide/listicle/trends/tutorial) — all share the same body anatomy.

### Campaign settings
```
Type:              Multiple Pages
URL:               https://mirelleinspo.com/blog
Page 2 URL:        (EMPTY — ?page=2/3/30 are byte-identical fakes; never configure)
Link method:       XPath
Link XPath:        //details//ul[contains(concat(' ',normalize-space(@class),' '),' grid ')]/li/a[contains(@href,'/blog/')]
Link wrap:         outer   (REQUIRED — inner returns anchor text only, href regex finds nothing)
Link size:         multiple  → 109 links per run
Content method:    CSS
Content class:     prose-content-magazine
Content wrap:      inner
Content size:      multiple  (every template = exactly 3 <article> sections; implode joins them)
CSS visual strip:  (EMPTY)
Strip HTML tags:   ON, standard allowed list
```

### Replace box (# separator), IN THIS ORDER — all three load-bearing (rule 3 added 2026-08-30)
```
<svg.*?</svg>#
src="/#src="https://mirelleinspo.com/
<p [^>]*inspo-gallery-link[^>]*>.*?</p>#
```
- Rule 2 is THE campaign: all body imgs are relative (`/images/blog/...`). Replace box runs at
  core.php:1784 BEFORE the image-cache loop (~1879) → srcs are absolute in time for local download
  + featured image. Verified 75/75 imgs absolutized, 0 broken, 0 dupes, all with alt.
- Rule 3 (SITE EVOLVED): on 2026-08-30 the owner added a new CTA after every body image —
  `<p class="inspo-gallery-link"><a href="/inspo/...">Explore ... inspiration gallery</a></p>`.
  Caught in the user's first live import (tattoo-nail-art: 7 CTAs). Rule kills exactly these
  (verified: 7 removed / 7 imgs untouched on live post; 0 hits = harmless no-op on older posts).
  Pattern is attribute-tolerant (`<p [^>]*inspo...`) in case they add classes. Re-check new posts
  for MORE new elements — this site ships changes without notice.

### Why this shape (traps mapped)
- Body = the 3 `<article class="prose-content-magazine">` blocks (own h2 sections + inline FAQ).
  Related/teaser cards are DIVS — do NOT strip //article here (that deletes the body; sim caught it).
- `bg-background` shell approach REJECTED: shell holds navs, 5 forms, teasers, promo text.
- `<main id="main-content">` = 397-char spinner decoy — never target it.
- /blog grid lives inside `<details>` accordions: 111 anchors (109 /blog/ + trend-reports/stories
  filtered out by the href predicate). Relative hrefs auto-absolutized pre-DOM (core.multi.php:282).
- Byte-offset regex walks LIE on this site (Astro island comments) — always DOM-verify.
- og:image + <title> clean on all 8 → featured image + titles automatic.

### Sim result (exact WPA order: class extract → replace box → strip_tags)
british-manicure 5 imgs / almond-ideas 34 / tan-skin 5 / cowboy-carter 6 / black-white 6 /
pink-christmas 7 / mistletoe-tutorial 3 / august-trends 9 — all start/end in real prose, 0 junk
markers (2 prose false-positives eyeballed: "trending now", "share one thing").

---

## bollywoodbubble.com/bollywood-news — Multi-page FINAL (2026-08-30, 10/10 posts CLEAN)
WordPress (Elementor theme "axil"), no WAF, real archive pagination (/page/2/…9+), category feed alive
(15 items, ~6.7 posts/day). 10 posts deep-audited incl. gallery type (a8/a9).

### Campaign settings
```
Type:              Multiple Pages
URL:               https://www.bollywoodbubble.com/bollywood-news/
Page 2 URL:        leave EMPTY (15 newest links per run + dedupe covers 6.7/day; fill
                   /bollywood-news/page/2/ only for a one-time backfill, then remove)
Link method:       XPath
Link XPath:        //h4[contains(@class,'title')]/a
Link wrap:         outer   Link size: multiple   → exactly the 15 newest posts
                  (verified: href set IDENTICAL to the category feed's 15 items)
Content method:    CSS
Content class:     axil-post-details-content
Content wrap:      inner
Content size:      single   (exactly 1 node on all 10 posts)
Strip HTML tags:   ON, standard allowed list
```

### Content tab — visual xpath removals (all load-bearing)
```
//div[contains(@class,'saboxplugin-wrap')]
//blockquote
//style
//script
```
- saboxplugin-wrap = Simple Author Box div INSIDE the content container (author bio + avatar img).
  1 per post, incl. author photo — must die.
- //blockquote: 16/16 blockquotes across the audit were instagram/twitter embeds
  ("View this post on Instagram / A post shared by…"), 0 legit quotes → kill all.
- //script: a9 (gallery roundup) had 12 script tags INSIDE the body — strip_tags would leak
  their JS text (DWI lesson). //style same (a8 gallery).

### Replace box (# separator) — 2 rules, both load-bearing
```
<h4[^>]*>\s*Also Read:.*?</h4>#
<img[^>]*bb-special-gallery[^>]*>#
```
- Rule 1: inline "Also Read:" h4 cross-links (1 in each of the 10 posts). Verified surgical:
  a2's legit h4 ("Daboo Malik On Amaal…") SURVIVES, its "Also Read:" h4 dies. h4-bounded = s-safe.
- Rule 2: gallery UI icon imgs (share-icon/normal/1977/crema/ludwig/moon/willow.png from
  /plugins/bb-special-gallery/) — otherwise 7 plugin icons download as post images.

### Notes
- Article imgs are absolute (0 relative) — NO src replace rule needed (opposite of mirelle).
- og:image 10/10 absolute + <title> 10/10 clean → featured image + titles automatic.
- News site = text posts: body carries 0-1 inline imgs (a8=1); hero lives outside the body and
  arrives as featured image. That is the site's design, not a bug.
- Ends with the site's own sign-off line ("…stay tuned to Bollywood Bubble") — house style, kept.
- WARNING: starter set already has bollywoodbubble.com/feed/ (site-wide). Running BOTH would
  duplicate posts — pick one (this category campaign replaces the site-wide one) or enable
  WPA's global duplicate skip.

---

## kaldata.com/софтуер — Multi-page FINAL (2026-08-30, 9 unique posts CLEAN, 29/29 imgs absolute)
Bulgarian software-release tracker. WordPress + TagDiv Newspaper theme. ~16.5 posts/day. No WAF.

### WHY NOT FEEDS (root cause of user's one-para truncation)
Their category feed has NO content:encoded at all — all 50 items carry only <description>
(~1.1KB = exactly 1 paragraph + img). Their WP is set to feed "Summary" mode. WPA falls back to
description → the one-para posts. Unfixable on our side → Multi Page scraper is the ONLY route.
(Never enable this feed as a campaign — same trap class as the feed silent-fallback.)

### Campaign settings — FEED-LINKS VARIANT (Cloudflare-proof, use this one)
```
Type:              Multiple Pages
URL:               https://www.kaldata.com/софтуер/feed
Page 2 URL:        (EMPTY — feed carries the 50 newest; 16.5/day)
Link method:       REGEX
Link regex:        <link>(https://www\.kaldata\.com/[^<]+\.html)</link>
                   (class.dom.php wraps as {pattern}is, returns group 1 = absolute URL;
                   no { } in pattern; verified: 50 links, 0 dupes. Log will say
                   "No href found, trying to get links directly by http..." — that line
                   succeeding is EXPECTED for regex-link campaigns, not an error.)
Content method:    CSS
Content class:     td-post-content
Content wrap:      inner
Content size:      single   (TagDiv canonical body; 1 node on every post — AMP too)
Multi S&R box:     (campaign Options → tick the multi "Search and Replace" checkbox, then):
.html|.html?amp=1
                   ← THE CLOUDFLARE BYPASS. Transforms every found link to the AMP version
                   (?amp=1) BEFORE article fetch. AMP pages: same body/class, no CF JS
                   challenge, no scripts, no newsletter box. Verified 8/8 posts.
                   core.multi.php:702-730 = string replace, runs pre-fetch; option
                   OPT_MULTI_SEARCH_REPLACE must be enabled or the box is ignored!
Strip HTML tags:   ON, allowed list (kaldata version — LINKS KEPT + <amp-img> CRITICAL):
<p><a><br><amp-img><h2><h3><h4><h5><strong><em><b><i><u><ul><ol><li><img><blockquote><table><tr><td><th><tbody><figure><figcaption>
                   ← <amp-img> MUST be in the list. Live-run postmortem 2026-08-30 PM: real WPA
                   order is visual-xpaths → extract → STRIP_TAGS → translate → replace-box. With
                   amp-img absent from the list, strip_tags DELETED every image BEFORE the
                   <amp-img→img rename rule could run → posts with empty <figure> shells, 0 imgs.
                   Keeping amp-img alive through strip; the replace box renames it to <img> after.
```
**USER DECISION 2026-08-30: vendor/download links are WANTED.** Replace box = EMPTY (the
two Bulgarian <p> rules were removed — Официална страница / Изтегли rows now import as
clickable links, 3-6 per post, all external, verified). <a>+<br> MUST be in the allowed
list or strip_tags reduces links to dead text.

### ORIGINAL HTML-listing variant (blocked by Cloudflare from user's server — see below)
URL https://www.kaldata.com/софтуер/ (use NON-slash final form) · link XPath
//h2[contains(@class,'entry-title')]/a | //h3[contains(@class,'entry-title')]/a · outer ·
multiple → 27 cards. Same content settings. Failed live: CF returned ~5.8K challenge page.

### CLOUDFLARE BLOCK — live incident 2026-08-30, RESOLVED via AMP
Round 1 (HTML listing from user server): ~5.8K CF challenge → 0 links. Round 2 (feed links,
regex route): FEED PASSES CF (113K chars, 50 links ✓) but ARTICLE pages still challenged
("6287 chars", title "Just a moment..." → WPA built a post OUT of the challenge page!).
RESOLUTION v1: /amp/ → 301 → ?amp=1 + S&R rewrite through allorigins — worked but is a
DICE ROLL: measured live 2026-08-30 PM, allorigins returned 408/520/522 (16-24 bytes) on
3 of 4 article fetches → WPA extracts nothing → intermittent EMPTY title-only kaldata
posts (user-reported: rj-texted-51139, smplayer-47551 — both verified to HAVE full content
when fetched directly). Free proxies have no SLA; never build a production campaign on one.
RESOLUTION v2 (FINAL): same mechanism, ZenRows rendering (deterministic, proven on neowin
2/2 with wait_for). Kaldata Multi S&R box becomes EXACTLY these 2 lines:
```
https://www.kaldata.com/|https://api.zenrows.com/v1/?apikey=YOURKEY&antibot=true&js_render=true&wait_for=.td-post-content&url=https://www.kaldata.com/
.html|.html?amp=1
```

### Title rule + box hygiene (2026-08-30 PM, user live QA)
- NEW title rule in CONTENT replace box: `[ ]*/[ ].*$##titleonly` — cuts kaldata dual-version
  titles at " / " ("Sandboxie 1.18.3 Plus / 5.73.3 Final" → "Sandboxie 1.18.3 Plus"; slash-free
  titles 0-hit untouched; #titleonly = title-only apply — content never touched; backslash-free
  = paste-proof). Old dead `% OFF#|titleonly` rule DELETED from user box (never fired once in
  any log; if it ever matched it would inject literal "|titleonly" into content).
- ZenRows budget: free tier = 5,000 cr/mo (user confirmed), 5 cr/post → 1,000 posts/mo ≈ 33/day
  ceiling; recommend ≤30/day total for retry headroom. Current kaldata 3 + neowin 3 = 6/day
  (900 cr/mo, 18% of budget).
- Both boxes delivered paste-proof in /home/user/config/kaldata-boxes.txt (BOX 1 = multi link S&R,
  pipe lines; BOX 2 = content replace box, hash lines).
(wait_for=.td-post-content exists on the AMP page too — verified. KEEP the amp line: the
campaign's xpath/replace set is AMP-certified. Budget: kaldata 3/day + neowin 3/day ≈
180 posts/mo × 5cr ≈ 900cr — fits the 1000/mo free tier with little headroom; raising
post caps → paid tier. After editing: DELETE CAMPAIGN CACHE (generated feed XML replays
old transformed URLs otherwise) + delete the empty posts so their URLs retry.) REST API dead-end: wp-json serves Cyrillic \uXXXX-escaped (preg_replace can't
unescape without callbacks). If ?amp=1 is EVER challenged too, next rung: swap the S&R line
for a rendering-API wrapper, e.g. ZenRows
`https://www.kaldata.com/|https://api.zenrows.com/v1/?apikey=KEY&antibot=true&url=https://www.kaldata.com/`
(same one-line mechanism; str_replace is non-recursive so prefix line is safe). Apify does
NOT integrate with WPA (separate actor platform) — wrapper APIs are the drop-in.
Note: user's own site being behind CF is IRRELEVANT — CF filters inbound only; outbound
fetches don't pass through it. WP-curl passed from the audit sandbox with WPA's exact
signature → block is server-specific (IP reputation / TLS fingerprint of their PHP-curl).

### Content tab — visual xpath removals (AMP set, all load-bearing; share-block added 2026-08-30 PM)
```
//script
//noscript
//i-amphtml-sizer
//amp-ad
//amp-img/img
//a[contains(@class,'td-social-sharing-button')]
//a[contains(@class,'td-social-handler')]
//ul[contains(@class,'td-pulldown-filter-list')]
//div[contains(@class,'td-a-rec')]
//div[contains(@class,'td-featured-image-rec')]
//div[contains(@class,'td-post-featured-image')]
//div[contains(@class,'tnp')]
```
- SHARE BLOCK (user-caught in first live AMP import): TagDiv puts 9-10 social-share anchors
  (Facebook/X/Viber/Telegram/WhatsApp/LinkedIn/Reddit/Email/Print + "+" expand) INSIDE
  td-post-content top. Two anchor-class xpaths + the empty pulldown ul kill all of them.
- //noscript: AMP puts a fallback <img> of every image inside <noscript> (would duplicate
  each photo after conversion). //script: leaks JS text through strip_tags.
- //i-amphtml-sizer: kills data:image/svg+xml placeholder stubs (broken gray boxes).
- //amp-ad: AMP ad slots (belt; most sit inside td-a-rec anyway).
- //amp-img/img: AMP pre-renders SOME amp-img with a native <img> child → would duplicate
  after the amp-img→img rename. Kills the inner copy. Runs pre-rename (visual stage
  precedes replace stage).
- td-a-rec: AdSense divs. td-featured-image-rec: non-AMP hero dup.
- td-post-featured-image: AMP-only hero dup at top of body (og:image sets featured anyway).
- tnp: newsletter family (non-AMP; no-op on AMP).

### Replace box (# separator) — 3 rules (AMP conversion + placeholder belt)
```
<amp-img\b#<img
</amp-img>#
<img[^>]*src=["\']data:image[^>]*>#
```
- AMP body images are <amp-img> (absolute src + width/height) → rule 1 renames the opening
  tag, rule 2 drops the closing tag, rule 3 belts against stray data: URIs.
- Vendor/download links (Официална страница / Изтегли rows) STAY — user decision 2026-08-30.
- VERIFIED 8/8 live AMP posts: 24 real imgs, 0 broken, 0 dupes, 0 junk, 13-16 links kept.

### Notes
- Cyrillic URL: paste https://www.kaldata.com/софтуер/ — WP/WPA handle the percent-encoded form;
  listing hrefs are already percent-encoded in the HTML.
- Article imgs absolute (0 relative) — NO src replace rule. og:image 9/9 → featured automatic.
- Posts end with license line ("Лиценз: Платен (Shareware)") — genuine content, kept.
- Frequency 16.5/day >> 3/day cap → WPA max setting keeps it fed forever.

---

## neowin.net/software — AUDITED 2026-08-30: NOT SCRAPABLE FREE (CF hard-block)
Cloudflare "Just a moment" on EVERYTHING from every tested vantage: listing+feed direct (403),
Googlebot UA (403), allorigins (challenge/500 — kaldata's bypass does NOT work here), codetabs
(522), rss2json (500), corsproxy (401/key), Wayback (no snapshots of recent posts).

### What DOES work (verified live today): FeedBurner mirrors
- feeds.feedburner.com/neowin-main — 40 items, 17.2/day, LIVE (hours-fresh), links carry
  ?utm_source=rss
- feeds.feedburner.com/neowin-software — 40 items, ALL /software/ links, 9.2/day (software
  releases: Glow 26.12.1, Calibre 9.14.0 etc.) — PERFECT link source
- BUT both are SUMMARY-ONLY (description 424-497b, content:encoded=0) — same truncation class
  as kaldata's feed. Links only, no article body.

### FINAL config — all selectors VERIFIED from user-supplied page source (2026-08-30 PM)
Only missing piece: a rendering-API key for article fetch (free routes exhausted: direct,
googlebot, allorigins, codetabs, corsproxy, rss2json, wayback, jina — ALL challenged).
```
Type:              Multiple Pages
URL:               https://feeds.feedburner.com/neowin-software
Page 2 URL:        (EMPTY)
Link method:       REGEX
Link regex:        <link>(https://www\.neowin\.net/software/[^<]+)</link>
Link wrap:         outer   Link size: multiple   → 40 links (9.2/day, all /software/)
Multi S&R box (3 lines, THIS ORDER; needs OPT_MULTI_SEARCH_REPLACE ticked):
?utm_source=rss|
https://www.neowin.net/|https://api.zenrows.com/v1/?apikey=YOURKEY&antibot=true&js_render=true&wait_for=.article-content&url=https://www.neowin.net/
                   ← FINAL FORM 2026-08-30 PM. ZenRows nondeterminism fully mapped:
                   no-render = random (full OR empty 43K shell w/ title but 0 body — CF
                   serves datacenter IPs a pre-hydration shell); js_render ALONE = WORSE
                   (2/2 stripped in testing!). wait_for=.article-content = render + block
                   until the body div EXISTS = 2/2 full 235K pages. ~5+ credits/post.
                   ⚠ AFTER EDITING THE S&R BOX ALWAYS DELETE CAMPAIGN CACHE: WPA stores
                   the transformed URLs in a generated feed XML (wp-content/uploads/
                   hash_ID.xml) and replays it — the OLD URLs keep running until cache
                   clear (bit the user twice: "edited but log shows old URL").
Content method:    CSS
Content class:     article-content     (itemprop=articleBody; verified single node)
Content wrap:      inner
Content size:      single
Strip HTML tags:   ON, allowed list (LINKS KEPT + changelog lists):
<p><a><br><h2><h3><h4><h5><strong><em><b><i><u><ul><ol><li><img><blockquote><table><tr><td><th><tbody><figure><figcaption>
```
Content tab visual xpath removals:
```
//script
//div[@data-freestar-ad]
//comment()
```
Replace box (# separator) — 8 rules, delivered via WORKSPACE FILE (2026-08-30 PM final).
Paste-corruption saga: run 1 = every backslash DOUBLED; run 2 = every `*` after `[^>]` or
`.` EATEN (log echo `<img[^>]alt=...`, `.?`). Not WPA — the user's copy/paste chain mangles
the text. Fix: exact box content lives in /home/user/config/neowin-replace-box.txt (plain text,
copy from the FILE, never from chat). Also fixed here: rule 1 was .com (author typo —
neowin is .net; user caught it) and added hero-image kill per user request:
```
href="/#href="https://www.neowin.net/
<p[^>]*text-align:center[^>]*><img.*?</p>#
<img[^>]*alt="twitter"[^>]*>#
<em[^>]*>[ ]?Get alerted to(?:(?!</em>).)*?</em>#
<script[^>]*widgets[.]js[^>]*>.*?</script>#
<p[^>]*>[ ]*</p>#
<strong[^>]*>[ ]*</strong>#
[ ]*[-–—][ ]*Neowin[ ]*$#
```
- Rule 2 (hero kill): certified on live Glow AND Calibre posts — kills the centered hero
  <p><img…></p> (incl. BOM variant), SPARES centered-text paras and inline imgs. User wants
  no hero in body. (If they also want no featured THUMBNAIL: untick the campaign's
  featured-image option.)
- Certification on live posts: hero/twitter-img/promo-em/widgets.js/empty-strong 1 hit
  each; download links, changelog ul/strong, text paras KEPT; title "Calibre 9.14.0 –
  Neowin" → "Calibre 9.14.0".
- VERIFY AFTER PASTE: log echo must show `[^>]*` WITH the star. Stars missing = paste
  mangled again → copy from the txt file, not chat.
- KNOWN WPA MANGLE (accept): backslashes vanish in changelog text (System32\config\BFS →
  System32configBFS) inside WPA's pipeline — not reconstructible by replace rules.
- automate_uuid="" attrs on links = WPA's own tracking, invisible front-end, leave.
VERIFIED on real glow-26121 body: hero img (cdn.neowin.com absolute) kept, changelog
3×ul/5×li kept, Download+Links paras kept intact (github release zip / homepage /
screenshot / repo), freestar ad div+script dead, starts at lede ends at Links line.
Anatomy: listing = div.news-list > article.news-item > h3.news-item-title > a (relative
href; not used — listing is CF-blocked, FeedBurner supplies links). article-header
(badge/affiliate/h1/subtitle/meta) sits OUTSIDE article-content — never imported.
WATCH on first live run: content tail beyond the "Links:" para was not in the fragment
(post may continue — tags/share/related unknown). Inspect first post; report junk if any.

---

## CROSS-CAMPAIGN SOFTWARE DEDUP — neowin + kaldata + softexia (2026-08-30, 9/9 matrix passed)
Problem: all 3 sites post the same software releases with different title formats
("Calibre 9.14.0 – Neowin" vs "Calibre 9.14 Final" vs reordered names).

### Layer 1 — WPA native (exact titles): campaign Options tab, tick on ALL software campaigns
"Skip the post if there is there is already a published one with same title in the database"
(OPT_FEED_TITLE_SKIP, metabox_filters.php:421; is_title_duplicate = get_page_by_title across
ALL posts = cross-campaign by design; exact match only; permanent, not 24h).

### Layer 2 — mu-plugin v1.1 (fuzzy, 24h, PRIORITY): /home/user/php/wpa-software-dedup.php
Install: copy to wp-content/mu-plugins/ (make dir; auto-loads, no activation).
- PRIORITY TAKEOVER (user order): kaldata(3) > neowin(2) > softexia(1) > unknown/manual(0).
  Higher-priority version arriving LATER trashes the lower-priority post and takes over.
  Site detected from WPA's original_link post meta (core.php:3338 — written on every post).
- Only fires on titles containing a DOTTED version (9.14.0) → fashion/beauty/news untouched.
- Normalizes: strips site suffixes, " / dual" tail, dotted versions, Build N,
  final/portable/setup/beta/rc/stable/release, punctuation → lowercase.
- Losers → TRASH (reversible) + logged to option 'wsx_dedup_log' (last 20, autoload off).
  Same software >24h later = allowed again.
- PERF: fires once per NEW post (meta-guarded). Non-software posts: 1 meta read+write.
  Software posts: ONE WP_Query — indexed post_date range scan of the 24h window,
  fields=ids, capped 200. No new tables, no schema changes, admin/cron context only
  (never on front-end page views).
- BRUTAL TEST 2026-08-30 (brutal2.php, real feeds pulled live: kaldata 50 + neowin 40 +
  softexia 21 = 111 real titles): 7 NATURAL cross-site collisions found (Sandboxie Plus,
  SMPlayer, Mp3tag, Multi Commander, Calibre, LibreWolf, Vivaldi). All 14 arrival-order
  battles → kaldata survived every time. Full 111-title round-robin interleave: 104
  survived / 7 trashed — zero wrong-name kills, unique survivor names, highest-priority
  site won every contested name. Edges: >24h both live, <24h dedup, fashion immune,
  kaldata beats manual post, neowin>softexia both arrival orders. 23/23 PASS.
- v1.2 (same evening, user QA): (a) LOSING POST'S MEDIA IS PERMANENTLY DELETED — featured
  image + all sideloaded attachments via wp_delete_attachment(force) + _thumbnail_id meta
  cleanup; winner's media untouched. (b) LOG HOOKED INTO WPA CAMPAIGN LOG: WPA's log is
  live echo (nothing stored), and the mu-plugin fires inside the same request → its
  'WSX-dedup: [site] "title" duplicate of [site] ... media file(s) deleted' line appears
  INLINE in the campaign processing log, live. Also stored in wsx_dedup_log (last 20).
  (c) CONFIRMED FLOW: duplicates are fully created first (credits + image downloads spent),
  then killed — hook point is wp_insert_post, no earlier interception without patching WPA
  core. Measured dup rate 7/111 ≈ 6% → ~30 wasted credits/month at current volume. Fine.
- v1.3 (same evening): USER REVERSED PRIORITY — FIRST ARRIVAL ALWAYS WINS, no site
  priority/takeover. Whichever campaign posts first keeps it; ALL later same-software
  posts trashed + media force-deleted (kaldata arriving after neowin now LOSES too).
- v1.3 FULL 111-REAL-TITLE VERIFICATION (2026-08-30, final111.php): (A) all 7 natural
  cross-site collisions × every arrival order = 14/14, survivor = FIRST arriver every
  time (kaldata loses when it arrives later — confirmed). (B) full round-robin interleave
  kaldata→neowin→softexia: 111 inserted, 104 survived, 7 trashed; unique survivor names,
  zero wrong kills, survivor = first arriver in all 7 contested, media accounting exact
  (7 loser files deleted, winners intact). (C) reversed rotation softexia→neowin→kaldata:
  winners mixed by feed position (sx/nw/kd) = pure arrival-order decides, site irrelevant.
  (D) 50 random shuffles of all 111 titles: unique survivors, zero wrong kills, first
  arriver always won, loser media always fully purged — 0 violations across ~350 dedup
  decisions. TOTAL 20/20 PASS. (Harness note: section C initially 'failed' on a wrong
  assertion in the TEST — it expected softexia to win all contested names, but round-robin
  legitimately lets neowin beat kaldata on index position; plugin behavior was correct.)
  Media purge, WPA-log inline echo, wsx_dedup_log storage unchanged. Verified 9/9
  (all arrival orders incl. softexia-first-beats-kaldata, 3-way race, >24h, immunity,
  media purge, log line). Consequence: winner = campaign cron/processing order, not site.
  v1.2 verified 10/10 (media purge, takeover purge, winner intact, echo line, stored log,
  non-dup untouched). NOTE: site has NO fashion posts (3 software campaigns only) —
  dotted-version gate stays as pure safety, zero effect.
  (Note: first harness run showed 5 fake fails — title-string attribution bug in the
  TEST RIG on identical titles, not the plugin; ID-based rerun = clean.)

### Softexia (3rd site, probed 2026-08-30)
softexia.com/feed + feedburner.com/softexia ALIVE (21 items) but summary-only
(content:encoded=0) → same class as neowin: FeedBurner/links fine, bodies need
Multi + ZenRows treatment. Full audit pending user go-ahead.

---

## CPG BRAND MAP — Option A executed (2026-08-31)
Goal (user): auto-append to every CPG post: "Get your favorite dress from [Brand] Website and
more details on their Instagram page." — links to the BRAND's own site/IG, never Sanaulla.
Method: 239 bp-tile brand handles extracted from sanaullastore.com/pages/brands →
phase-1 domain guessing (688 requests, title-token verify) → parking-domain filter (killed
brandbucket/hugedomains redirects) → search verification for ~20 famous/rotation brands
(with sameAs schema + footer IG harvest) → FULL signal check of all mapped sites
(PK-fashion keywords). 13 foreign/parked false positives caught & demoted (incl. a Brazilian
payroll system, cupcake bakery, drone maker). Instagram direct probing impossible (SPA shell
returns identical 200 for valid+invalid) — IGs came from brand sites' own footers/schemas.
DELIVERABLES: config/brand-map.txt (73 brands: handle|Name|Website|Instagram; 63 both,
8 site-only, 2 IG-only incl. Mushq→mushq.com+mushqpk) + docs/brand-links-manual.md
(section 1 VERIFY: zouj/sara-jahan/naaz-couture/daak-co/bin-saeed/fine-tex/farasha/uniluxe/
lakhany + 14 demoted; section 2 PARTIAL missing-one-link; section 3: 152 no-links long tail).
NEXT: CPG v3.4 — brand-map in DB (admin textarea, same pipe format), footer builder with
3 variants (both/site-only/IG-only), Mushq example rendering verified, tests extended.

## CPG v3.4 SHIPPED (2026-08-31) — brand footer, 76/76 tests
php/collection-post-generator.php now: built-in verified 73-brand map embedded (config/
brand-map.txt is the workspace copy), admin Settings rows: "Brand footer" toggle (ON default)
+ "Brand links map" textarea (empty = built-in). Footer appended on CREATE only (updates
never duplicate). Brand resolution: source.brand_handle -> /collections/ slug -> none.
Variants: both ("Get your favorite dress from X Website and more details on their Instagram
page."), site-only ("...from X Website."), IG-only ("Find more of X on their Instagram page.").
SAFETY: map parser rejects any entry containing sanaullastore.com; unmapped brands get no
footer; links carry nofollow noopener + target _blank. Suite: S14 = 13 tests (map load 73,
exact Mushq render end-to-end via store flow, once-only, unmapped none, custom-map parse,
variants, toggle off, sanaulla-reject, no-dup-on-update, built-in IG-only) -> 76/76 PASS.
Install: paste-over as usual; add 'brand_handle' => 'saira-shakira' to the fashionstation
woo source in cpg_default_sources() to cover it (woo URLs have no /collections/ slug).

## CPG v3.4.1 — DEEP SEARCH + MERGE MAP (2026-08-31, evening)
User caught it: the "no links found" long tail had only been domain-guessed, never searched
(afrozeh was instantly findable). Full re-search executed: Brave scripted (rate-limited after
8; parked-rejects overturned: rangrasiya.com.pk, sardinia.pk, scherezade.pk, uniluxeonline,
meerak) + 34 web_search waves over ALL remaining brands + scripted verify pass (PK-fashion
signals, token check, own-page IG harvest; Cloudflare/WAF rescues like saira-rizwan).
MAP v2: 176/239 brands (131 both, 16 site-only, 28 ig-only; zara-shahjahan fixed to
zarashahjahan.com + zarashahjahanofficial; lakhany IG fabric_lsm). 63 unresolved in
docs/brand-links-manual.md v2 (13 verify-first w/ candidates, 8 site-down, 16 IG-gaps,
50 no-links, foreign list). MERGE SEMANTICS (user asked): custom textarea lines are merged
ON TOP of built-in — same handle overrides, new handles add, `handle | Name | - | -`
disables. Tests: 78/78 (S14=17). Search evidence: docs/brand-search-log.md.
IG-probing remains impossible (SPA shell) — own-site schema/footer is the trust chain.

## §13 addendum — DEDUP v1.4 DELETION SHIELD (2026-08-31, night)
User question: "when a WPA post is deleted, WPA recreates it same day (can't use Never-post-
same-link because software posts keep updating) — how does the mu-plugin stop that?"
Answer for v1.3: IT DIDN'T — the 24h scan saw only LIVE posts; a deleted post was invisible,
so its recreation passed clean. GAP CONFIRMED AND FIXED.
v1.4 (php/wpa-software-dedup.php, upload FILE to mu-plugins — never paste, regex mangling):
1. Seen-memory option wsx_dedup_seen (normTitle => first-seen ts, TTL 24h, auto-pruned,
   cap 500). Stamped ONLY when a post survives (= first arrival of the day) or when a
   live-twin kill happens; losers never extend the stamp. If no live twin exists but the
   title was seen inside the TTL (post deleted by user), the recreation is KILLED:
   trashed + media force-deleted + log 'recreation after deletion blocked', live echo
   "was already posted today and deleted — recreation blocked".
2. Attachment sweeper (add_attachment): media WPA sideloads onto an already-killed post
   is force-deleted — no orphans. Standalone uploads + live-post media untouched.
Knob: WSX_DEDUP_SEEN_TTL (hours; 24 = same-day shield, matching dedup window; raise to
8760 if deleted should mean NEVER again). Order of checks: live-twin scan first (real
winner in log), then shield. Non-software titles bypass everything.
Tests /tmp/dd/dedup14-test.php: 19/19 — incl. D3 the exact user scenario (delete → recreate
→ blocked), D2/D11 first-arrival-wins regression, D6 TTL expiry, D7 dual-version norm
collapse, D8 sweeper 3-way, D10 media accounting =2, D9 prune. Harness gotcha fixed:
post_status 'any' string + fixture must MERGE into seen-map not replace it.

## §13 addendum 2 — LOSER-RETRY prevention, Layer 1 verified (2026-08-31)
User scenario: mu-plugin trashes a DUPLICATE LOSER; winner alive; the loser's OWN campaign
re-offers the item (can't use Never-post-same-link) → how is recreation prevented?
- Layer 2 (mu-plugin, installed): CANNOT stop the attempt (hooks after wp_insert_post).
  It kills every recreation AT BIRTH: trash + media force-deleted + live log line, every
  run, automatically, as long as the winner is live (same-day guaranteed; >24h re-offer
  = allowed by the agreed window — say the word to tighten).
- Layer 1 (WPA tick, STILL PENDING ×3): OPT_FEED_TITLE_SKIP = "Skip the post if there is
  already a published one with same title" → VERIFIED IN SOURCE this session:
  is_title_duplicate() → wp_automatic_get_page_by_title() uses post_status 'all', and
  WP core (class-wp-query.php, only 'any' is special-cased; unmatched strings add NO
  status clause) treats 'all' as NO STATUS FILTER → the lookup SEES TRASHED posts →
  the trashed loser blocks the retry BEFORE creation; non-feeds path also link_execlude()s
  the item (kaldata-style campaigns) so that campaign never retries it. Feeds path
  (core.feeds.php:794) skips at feed-parse stage (cheap, before full fetch).
  → TICK IT on all 3 software campaigns. Layer 2 stays because WPA's check is EXACT-title
  (cross-campaign twins differ: – Neowin suffix, dual versions — mu-plugin norm() catches).
Trash nuance: WP auto-empties trash after 30 days → after that WPA's exact-title check
can't see the old loser; irrelevant in practice (feed item long gone). No plugin change;
dedup stays v1.4.

## CPG v3.4.2 — MAP v3, every row source-verified (2026-09-01)
User caught another wrong row (sahar → sahar.pk guess; real = saharonline.pk + IG
sahar.pakistan) → FULL re-verification of all 148 mapped sites: page-source fetch
(token/parking/fashion-signals) + IG read from each site's OWN footer/JSON-LD sameAs
+ DoH forensics on dead-looking domains (Cloudflare + Google resolvers; Verisign
NXDOMAIN = genuinely expired). Result: 119 rows already exact; 15 corrected (site moves:
sairarizwan.pk, lakhanyonline.com, misaalbyas.com, narmin.pk, sahar fix; 7 IGs added from
site source: zahaonline, alsiyaab09, hanim__official, sarajahanonline, ayeshaandusman,
shop_garnet, atiyairfanstudio; 4 expired domains blanked→IG-only: avyana, bareeq,
khuwab-by-kazma, ricamo). Jina reader = CF-block fallback (renders but JS-only IG footers
stay invisible → those 6 rows = site-only). IG direct probing still impossible (login wall).
Map v3 = 176 rows: 138 both / 6 site-only / 32 IG-only / 0 empty, 0 sanaulla links.
Plugin re-embedded, suite 78/78. Lesson recorded: search snippets are STALE (cache) —
a site in a Google snippet can be expired today; NXDOMAIN at registry is the truth.

## CPG v3.4.3 — CF-residue cleared (2026-09-01)
Zellbury IG user-confirmed @zellbury (2M). Remaining blocked sites finished: inara.pk
unmasked as "Inara Technologies" (IT co — wrong) → replaced by shopinara.com + IG
shop_inaraofficial (own schema, PK store; VERIFY vs Sanaulla catalog once). rehan-n-muzammil
REMOVED: apex serves *.myshopify.com cert (CN mismatch), www = empty 404, Google snippet
stale → manual until it resurfaces. shurooq.pk confirmed genuine (luxury pret/lawn) but IG
nowhere in source → phone check. Map v3.1 = 175 rows (137 both, 5 site-only, 32 IG-only,
1 site-only shurooq within those), plugin re-embedded, suite 78/78 (counts updated).

## CPG v3.4.4 — MAP v4: user hand-verified batch (2026-09-01)
User resolved 16 brands personally (highest trust tier): 10 new rows (zouj, abyaan, maherposh,
tana-bana→tanabana.com.pk, nomi-nisar, saphron→saphrononline.com, shahjahan→shahjahanofficial.com,
regalia-textiles, maryam-hussain→maryamhussain.pk, yashfa→yashfastudio.com) + rehan-n-muzammil
re-added IG-only + IG fills (shurooq→shurooqpakistan, dhaga→dhagaofficialstore,
bin-saeed→binsaeedfabrics, elan→elanofficial) + inara/shopinara confirmed. srsltid params
stripped. All 9 new domains curl-verified 200 (4 JS-titles blank = normal). Map v4 = 186 rows
(153 both / 0 site-only / 33 IG-only), 0 sanaulla links. Plugin re-embedded, suite 78/78
(counts 186). Manual list now: tng, unss-apparel, zebtan + ~48 no-links + spot-checks.

## CPG v3.4.5 — adopt-or-create + readable run log (2026-09-01, from live-run questions)
Q1 (user, from live log): "Nirvana by Mushq throttled — if Mushq adds dresses to the SAME
Nirvana collection, will the plugin never post them?" Answer: THROTTLE ONLY GATES NEW-POST
CREATION. A line the plugin has state for ALWAYS updates, even at cap ("updates still run"
per the HOLD line). The THROTTLED Nirvana line means cpg_state had NO post bound for that
line — i.e., it was posted before a state reset (reset warns "existing posts are NOT
touched; lines may be generated again") -> when caps freed, CPG would have created a
DUPLICATE Nirvana post. FIXED: v3.4.5 adopt-or-create — before creating, exact-title
search among live posts; if found, RE-BIND state to it (memorize current ids so nothing
doubles), log "[OK] ... adopted existing post #N (state had been reset — no duplicate
created)". Adoption bypasses caps like any update.
Q2: "log doesn't show what it posted" — CREATED/UPDATED lines exist per line; this run
had zero (cap reached earlier that day). Details upgraded anyway: CREATED = "N designs —
post #N"; UPDATED = "N new designs appended to post #N — <name> · <name> (+more)".
Tests: S15 (8) added — create→reset→adopt (no dup, no throttle), update-at-full-cap,
name-in-log, single-append, one-title. Suite 86/86 (S2 wording assertion updated).

## CPG v3.5 — IMMUTABLE POSTS + SEASON KEYS (2026-09-01, user policy change)
User policy: "once a post is there — no amendment, no updates, no new dresses. The blog
ANNOUNCES collections; it is not a catalog. Annual relaunch under the same name (Nirvana
by Mushq every year) MAY be a new post; the same post never gets new dresses."
CHANGES (php/collection-post-generator.php v3.5):
1. APPEND PATH REMOVED. Existing line + new dresses => [OK] "post #N already announced
   (N designs) — locked, no updates by design". Content never touched after creation.
2. SEASON-AWARE LINE KEYS: key = md5(feed|code|season). Season = "20YY" from 2-digit year
   inside the code (MU26UNR→2026, AA26UAA→2026); year-less codes (LG-RL-0463) fall back
   to newest dress published_at year. Next year => different key => NEW post allowed
   (subject to caps). Year-less titles gain the year: "... (LG-RL-0463) 2027".
3. ADOPTION IS SEASON-MATCHED: adopt-by-title only if candidate's _cpg_season meta is
   empty (legacy → stamp it) or equal. Annual relaunch never falsely adopts last year's
   post. _cpg_season meta stamped on create/adopt.
4. LEGACY STATE MIGRATION: pre-3.5 keys md5(feed|code) are re-keyed in place on first
   sight — no duplicate posts after upgrade.
5. Woo/non-grouped sources (key md5(url)) unchanged, but equally locked.
Log wording: HOLD lines now say "existing posts are final". Tests: S2/S6/S14/S15
rewritten for immutability; S16 added (5): year-code annual relaunch, year-less season
title, legacy-key migration, year-less annual relaunch. Suite 91/91.
NOTE for user: THROTTLED on a line now means "state has no post for it" — after v3.5
install it will either adopt the existing post or create when caps free, then stay final
forever. The [SKIPPED] "line rejected earlier" behavior (draft deleted) unchanged.

## CPG v3.5.1 — REAL-FEED verification + same-collection merge (2026-09-01)
User challenged: (a) does locking one collection lock the brand? (b) was year logic
verified against real previous-year collections? Answered with LIVE feeds (mushq,
lakhany, baroque, saira-shakira products.json pulled fresh; plugin's own parse/group
functions used — audit script /tmp/rt/audit.php pattern preserved below):
- BRAND NOT LOCKED: real counts — mushq 23 collections, lakhany 12, baroque 5,
  saira-shakira 2, all independent lines/keys. Locking is per line only.
- YEAR CODES VERIFIED: 43/43 year-coded lines had 2-digit code == real collection year.
  LIVE ANNUAL-RELAUNCH PROOF: "Nirvana by Mushq" exists TWICE in the feed — MQ24N (2024,
  2 dresses) and MU26UNR (2026, 10 dresses) → two separate posts, exactly the policy.
  Relisted old stock (MQ24xx with 2026 publish dates) proves code-year > date-year (date
  fallback would wrongly merge 2024 Nirvana into 2026) — code year preferred, validated.
- FLAW FOUND & FIXED (v3.5.1): real feed splits one collection across two codes with
  identical names ("The Secret Garden" MU26USG+MU26ULSG; "Lakhany Printed Lawn"
  LSM26UP+LSM26ULP) → would have made near-duplicate posts. NEW: cpg_line_merge_same_
  collection() merges same normalized name + same season; primary code (most dresses) in
  title; line key now md5(feed|normname|season) — stable across store re-tagging; legacy
  per-code keys (pre-3.5 AND 3.5 form) migrate automatically. Exact-name merge only
  (baroque BQ26UCF vs BQ26UFC stay separate — genuinely different Chantelle editions).
Tests: S17 (4) added — split+untagged => 1 post w/ all dresses, primary code in title,
next-year new post. Suite 95/95. Fixture lesson: untagged items only merge when their
title IS the collection name (real untagged items with unique titles remain (Assorted),
usually below min_dresses → skipped).

## CPG v3.5.2 — [TODAY] section in every run log (2026-09-05)
User: "still it does not show which posts it generated — it must show posts generated
today." The run log only covered the current run; daily caps are consumed by EARLY runs,
so the evening log showed created 0 with no trace of the day's output. NEW: cpg_today_
report_lines() — before the "Done in" line the log now lists every CPG post created TODAY
across ALL runs (query: _cpg_post meta + date_query after local midnight, live statuses
only — trash/deleted excluded), each as "  — #ID Title (HH:MM site time)", plus daily-cap
usage ("[TODAY] N CPG post(s) created so far today — daily cap X/Y used"). 30 shown max
("+… more"). Harness: post_date/post_date_gmt defaults added to insert stubs, date_query
support in t_query. Tests S18 (7): section present, id+title listed, non-CPG/yesterday/
trashed excluded, cap shown. Suite 102/102.

## CPG v3.5.3 — [TODAY] now reads counter memory, not a DB query (2026-09-06)
Live-site bug: user's log showed "[TODAY] 0 CPG posts created so far today — daily cap
2/2 used" while two Nureh posts (IDs 160675/160685) HAD been created that morning — the
cap counter was right, the WP meta+date_query lookup returned nothing (host/plugin query
interference). FIX: cpg_counter() gains 'today_posts' memory (id => {time,title}) —
cpg_counter_bump($post_id,$title) records every create AT CREATION TIME in the SAME
option that tracks the caps; [TODAY] renders from it (live-status filter per id; trashed
=> excluded + "N later deleted/trashed"). Log and cap now share one data source — they
cannot disagree. DB query kept ONLY as fallback (cap>0 + memory empty = posts created
pre-3.5.3 earlier same day; prints "list unavailable" note if it finds nothing).
Tests S18 extended (9): cross-run persistence via memory, trash-exclusion + note.
Suite 104/104. Transitional: day of upgrade shows counter-only count for pre-upgrade posts.

## DIT Fashion Posts Generator v3.5.4 — display-gap fix + rename (2026-09-26)
1) [TODAY] display gap fixed: posts created today but later trashed/deleted are STILL
   listed, from counter memory — "  — #ID Title (HH:MM, now in Trash)" (restorable) or
   "(HH:MM, later deleted)" (gone); live posts keep live titles; header keeps the
   "N later deleted/trashed" summary. The log now always answers "what did CPG create
   today", even if those posts no longer exist. Memorized titles come from
   cpg_counter_bump() at creation time; DB fallback only for pre-3.5.3 same-day posts.
2) Renamed to "DIT Fashion Posts Generator" — Plugins list, Settings menu label
   ("DIT Fashion PG"), settings page h1, run + cleanup log headers, cron-interval label.
   DELIBERATELY UNCHANGED: file name collection-post-generator.php, all cpg_* function
   names, option names (cpg_state/cpg_counter/cpg_brands/cpg_meta), post meta keys
   (_cpg_post/_cpg_key/_cpg_season), menu slug cpg-settings, cron schedule key — so
   paste-over is safe: no reactivation, locks/caps/rejections/ledger carry over intact.
Tests: S18 updated — trashed-post assertion flipped to "still listed + tagged", new
hard-delete case added. Suite 105/105.

## DIT Fashion Posts Generator v3.5.6 — fetch hardening + age 5→14 (2026-10-01)
DIAGNOSIS (user report: 0 posts 09-30/10-01, 19 of 21 feeds "no products"): Sanaulla
feeds verified LIVE from sandbox 4 ways (browser UA / WP UA / plugin UA / exact 21-URL
replay in 4.6s — 21/21 HTTP 200; mushq 98, florent 134, aik 95 products). No UA block,
no global rate limit, no store change. The live host's requests were fast-rejected ~90%
(2/21 through: gulaal, annus-abrar) starting after 09-26 19:30 (that run was 100%
healthy — its 5 "no products" brands verified genuinely empty). Culprit: Cloudflare bot
scoring on the host IP (Sanaulla is Shopify behind Cloudflare) or the host's own
outbound filtering — old code logged all of it as "empty or unreachable" with no reason.
v3.5.6 changes:
1) cpg_fetch(): browser-like UA (Chrome 129), min 2s between ANY HTTP requests
   (CPG_FETCH_GAP), ONE retry per failed fetch after 5s (CPG_FETCH_RETRY), and a reason
   string (cpg_fetch_error) surfaced in the log: brand lines split into "feed
   unreachable — HTTP 403 / cURL error 28 / HTTP 200 but response is not JSON" vs
   "collection empty (feed reachable)"; source SKIP lines append the reason too.
2) CPG_TIME_BUDGET 45→150 (pacing needs headroom). Healthy run ≈ 50-60s now.
3) One-time migration: stored age_days 5 → 14 (decision 2026-10-01; marker option
   cpg_v356_age14; any other value untouched). Rescues lines that crossed 5 days during
   the outage. NOTE: Nirvana MU26UNR (newest dress 08-28) stays blocked even at 14.
   Fresh stock waiting as of 10-01: elaf (09-29), charizma (09-28), florent (09-26).
Tests: S12 extended (reason line, retry-count, empty-vs-unreachable split, 403 rescue —
scenarios pinned: brands_per_run=1 / caps 99 + 6 slots), S19 added (migration 5→14,
persists, runs once, non-5 untouched). Suite 112/112.

## DIT Fashion Posts Generator v3.5.7 — ZenRows proxy fallback (2026-10-01)
USER ASK: free proxy service (ZenRows et al.) so CF blocks are gone forever. Verified:
ZenRows free = 5,000 credits/mo recurring, no card (zenrows.com/pricing); standard
request = 1 credit, premium proxy = 10, protected = 25 (docs pricing); only successful
requests billed. ScraperAPI/ScrapingBee free = 1,000/mo (worse fit). Our volume
~2,500 feed fetches/mo (21-22 feeds x 4 runs/day).
DESIGN (fallback-only, not full routing): cpg_fetch order = direct -> 5s -> retry ->
(if still failing AND key configured) ONE ZenRows attempt via
api.zenrows.com/v1/?apikey=K&url=<encoded>. Settings: proxy_provider (Off/ZenRows),
proxy_key (password field), proxy_premium checkbox (adds &premium_proxy=true, 10
credits — lever for hard blocks). OFF until a key is pasted — zero effect if v3.5.6
hardening alone fixes the block. Proxy response JSON-validated downstream: a wrapped/
tampered reply can NEVER build a garbage post (fails safe as "not JSON"). Log: rescued
feeds counted per run, "[NET] N feed(s) rescued via proxy fallback (ZenRows)" line;
proxy failures surface as "feed unreachable — proxy — HTTP 500" etc.
CREDIT MATH: standard (1cr) passes from clean IPs (feed is soft — even curl passes
from sandbox) -> 5,000/mo covers 100% routing (~2,500/mo); if premium needed (10cr)
-> 500/mo -> fallback-only coverage (~16/day), enough when hardening already fixes
most fetches. Run-time budget fine: proxy only on failures.
HONESTY NOTES given to user: "forever" not guaranteed on any free tier (terms can
change; ZenRows changed pricing structure before); prior ZenRows dead-end was
wait_for/js_render for JS pages — irrelevant here (plain JSON); truly self-owned
alternative offered: own Cloudflare Worker relay (free 100k req/day, no third party
reads the feeds) — code offer stands, not built. User action: sign up free, paste key
in Settings -> DIT Fashion PG -> Proxy fallback.
Tests: S20 added (9): off-by-default (no key = no proxy calls, 2 direct attempts),
rescue via proxy (1 call, key+target in URL, no premium param, [NET] line, direct
x2 first), premium param, proxy-failure reason. Counter resets added (S18 pollution).
Suite 121/121.

## DIT Fashion Posts Generator v3.5.8 — 6-provider proxy chain + credit guards (2026-10-01)
User asked for ≥5 free CF-bypass services compared + best plan. Verified free tiers
(2026-10-01, provider sites/docs): ScrapingAnt 10,000 cr/mo recurring no-card (failed
requests cost 0; free=1 concurrent — our fetches are sequential; endpoint
api.scrapingant.com/v2/general?x-api-key=K&url=U); ZenRows 5,000/mo (404s ARE billed —
docs); Crawlbase "up to 5,000" (site) vs 1,000 (older docs — ambiguous, wired anyway);
ScraperAPI 1,000/mo (api.scraperapi.com/?api_key=); ScrapingBee 1,000
(app.scrapingbee.com/api/v1/?api_key=); Scrape.do 1,000/mo (compared, NOT wired —
endpoint unverified); own Cloudflare Worker 100,000 req/DAY free (the forever layer —
config/cf-worker-relay.js ready to deploy, host-allowlisted to sanaullastore.com,
secret path, {URL} template).
v3.5.8 plugin: cpg_proxy_url() registry (scrapingant/zenrows/scraperapi/scrapingbee/
crawlbase/custom), settings primary+backup provider + keys + zenrows premium checkbox +
custom template ({URL} required, custom needs no key). cpg_fetch chain: direct → retry
→ (skip if HTTP 404/410 = dead feed, proxies can't help and ZenRows bills 404s) →
primary → backup, ONE attempt each. Circuit breaker: 3 straight proxy failures per run
→ cpg_proxy_abandoned, stop spending, resumes next run. Log: '[NET] proxy rescues:
provider N [, provider M][ — proxy abandoned after 3 straight failures, resumes next
run]'; failures log 'proxy(provider) — HTTP xxx'. Proxy responses JSON-validated
downstream (tamper-proof). Full comparison + plan: docs/proxy-comparison.md.
Harness: stub now host-parses URLs (proxy URLs embed the encoded target — substring
match misrouted them, that was the S20 failure), TForceCode per-URL forced status,
TProxyFail = list of failing proxy hosts. S20 adapted (403-forced feed, new [NET]/reason
strings), S21 added (19): URL builders ×6, custom template, whitelist, 404-never-
proxied, backup chain, circuit breaker (exactly 3 attempts), custom relay rescue.
Suite 139/139. RECOMMENDED to user: Primary ScrapingAnt + Backup ZenRows + optional own
Worker as Custom (deploy steps in proxy-comparison.md).
