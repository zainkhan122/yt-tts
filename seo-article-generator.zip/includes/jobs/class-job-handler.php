<?php
/**
 * Job Handler
 *
 * @package SEO_Article_Generator
 *
 * @MODIFIED 2026-06-14 — Gutenberg block recovery fix (class-job-handler.php):
 *
 * WHY: wp_insert_post() / wp_update_post() internally call wp_unslash() on all
 * post data before writing to the database (post.php:4888). This strips one layer
 * of backslashes. Our serialize_block_attributes() output contains literal
 * \u0026 / \u003c / \u003e sequences (correct JSON unicode escapes). Without
 * pre-slashing, wp_unslash() strips the leading backslash (e.g. \u0026 → u0026),
 * producing invalid unicode escapes in the DB. Gutenberg's editor then fails to
 * validate these, triggering "Block contains unexpected or invalid content" recovery.
 *
 * WHAT CHANGED:
 * 1. Added wp_slash() on $postarr['post_content'] in finalize_generated_post()
 *    before wp_insert_post()/wp_update_post(). This matches the WordPress data
 *    convention used by the REST API controller (rest-api/endpoints/class-wp-rest-posts-controller.php:776).
 *    After wp_unslash() strips one layer, the \u0026 sequences survive intact.
 *
 * FILES: class-job-handler.php (this file)
 */

namespace SEO_Article_Generator\Jobs;

use SEO_Article_Generator\Utils\Plugin_Time;
use SEO_Article_Generator\AI\AI_Rate_Limit_Exception;
use SEO_Article_Generator\AI\API_Error_Info;
use SEO_Article_Generator\AI\Quota_State_Manager;
use SEO_Article_Generator\AI\AI_Client;
use SEO_Article_Generator\AI\Provider_Registry;
use SEO_Article_Generator\Queue\Backoff_Strategy;
use SEO_Article_Generator\Generator\Article_Generator;
use SEO_Article_Generator\Links\Link_Finder;
use SEO_Article_Generator\Links;
use SEO_Article_Generator\Validation\Validator;
use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Installer;

// Prevent direct access
if ( ! defined( '\ABSPATH' ) ) {
	exit();
}

/**
 * Background job processing with Action Scheduler and Block-Based Finalization
 */
final class Job_Handler {

	public const STATUS_FAILED_VALIDATION  = 'failed_validation';
	public const RECONCILE_TIMEOUT_SECONDS = 900;
	public const STALE_HEARTBEAT_SECONDS   = 2400;
	public const STALE_LEASE_SECONDS       = 3600;
	public const MAX_JOB_RETRIES           = 4;

	/**
	 * Phase 3F (2.34.0): zombie-job liveness thresholds used by
	 * lifecycle_state_is_stale_dead(). An ACTIVE job (processing/reserved) with
	 * no heartbeat/lease activity for longer than this is declared dead rather
	 * than "still live", so newer duplicate completions are adopted instead of
	 * being dropped as orphans. 40 min comfortably exceeds STALE_LEASE_SECONDS
	 * (3600s) so a genuinely slow, heartbeating job is never killed.
	 */
	public const ZOMBIE_ACTIVE_STALE_SECONDS  = 2400; // 40 minutes
	/**
	 * A PASSIVE job (pending/deferred/queued, never started) older than this is
	 * a backlog zombie — mirrors the discovery-side MAX_PASSIVE_WAIT_SECONDS
	 * (12h) starvation backstop so both layers agree that it is dead.
	 */
	public const ZOMBIE_PASSIVE_STALE_SECONDS = 43200; // 12 hours

	/** @var Logger */
	private $logger;

	/** @var int Maximum job retries before final failure */
	private $max_job_retries = self::MAX_JOB_RETRIES;

	public function __construct( $logger = null ) {
		$this->logger = $logger ?: new \SEO_Article_Generator\Logger();

		if ( ! has_action( 'seo_gen_reconcile_job_timeout', array( $this, 'reconcile_job_timeout' ) ) ) {
			\add_action( 'seo_gen_reconcile_job_timeout', array( $this, 'reconcile_job_timeout' ), 10, 1 );
		}
	}

	private function get_job_lock_name( int $job_id ): string {
		return 'job_generation_' . $job_id;
	}

	private function seconds_until_utc( int $at_utc ): int {
		return max( 60, $at_utc - Plugin_Time::now_utc_ts() );
	}

	public function get_generation_preflight(): array {
		return $this->resolve_generation_bootstrap();
	}

	private function is_pipeline_paused(): bool {
		return \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance()->is_discovery_paused();
	}

	/**
	 * Verifies that the associated discovery item still exists.
	 * Prevents orphaned jobs from executing and wasting API tokens.
	 *
	 * ENHANCED: Identity lock — if the discovery row is in 'generating' or 'finalizing'
	 * state with this job_id, the identity is locked and must NOT be treated as replaced.
	 * This prevents premature aborts when discovery identity replacement occurs during
	 * cooldown periods while a job is still actively processing.
	 *
	 * MODIFIED: Throw RuntimeException instead of DeterministicFailureException for infrastructure identity failures.
	 */
	private function verify_linked_discovery_exists( int $job_id ): void {
		global $wpdb;
		$table = Installer::table_discovery();

		$discovery_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, job_id, queue_job_id FROM {$table} WHERE job_id = %d LIMIT 1",
				$job_id
			),
			ARRAY_A
		);

		if ( $discovery_row ) {
			$disc_status = (string) ( $discovery_row['status'] ?? '' );
			if ( in_array( $disc_status, array( 'generating', 'finalizing', 'deferred' ), true ) ) {
				return;
			}
			if ( (int) ( $discovery_row['job_id'] ?? 0 ) === $job_id ) {
				return;
			}
		}

		$queue_job_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT queue_job_id FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				$job_id
			)
		);

		if ( $queue_job_id > 0 ) {
			$discovery_row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, status, queue_job_id FROM {$table} WHERE queue_job_id = %d LIMIT 1",
					$queue_job_id
				),
				ARRAY_A
			);

			if ( $discovery_row ) {
				$disc_status = (string) ( $discovery_row['status'] ?? '' );
				if ( in_array( $disc_status, array( 'generating', 'finalizing', 'deferred' ), true ) ) {
					return;
				}
				if ( (int) ( $discovery_row['queue_job_id'] ?? 0 ) === $queue_job_id ) {
					return;
				}
			}
		}

		// FIX: Allow manual generations (no discovery item) to proceed.
		// Only enforce identity lock if a discovery item WAS linked but is now gone/replaced.
		$had_discovery_link = (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE job_id = %d OR queue_job_id = %d",
				$job_id,
				$queue_job_id
			)
		);

		if ( ! $had_discovery_link ) {
			// Manual generation — no discovery item ever existed. Skip identity check.
			return;
		}

		throw new \RuntimeException(
			'Job aborted pre-flight: discovery identity was replaced or removed before execution.'
		);
	}

	private function resolve_generation_bootstrap(): array {
		$status = AI_Client::get_provider_status();
		if ( $status['enabled_count'] > 0 ) {
			$routable = $status['routable'] ?? array();
			$count    = count( $routable );

			// ── PROVIDER ROTATION ──────────────────────────────────────────
			// Round-robin across routable providers so every generation does
			// NOT start on the same provider.  The index persists in a
			// transient; after each successful generation the caller advances
			// it via advance_provider_rotation().
			$rot_idx  = (int) \get_transient( 'seogen_provider_rotation_idx' );
			$first    = $routable[ $rot_idx % max( 1, $count ) ] ?? $routable[0] ?? array();
			$provider = $first['provider'] ?? 'gemini';
			$model    = (string) ( $first['model'] ?? '' );

			// ── MODEL ROTATION (LKGM) ─────────────────────────────────────
			// If this provider recently succeeded with a specific model,
			// start there instead of the snapshot-chosen default.  This is
			// the LKGP (Last Known Good Provider/Model) strategy from
			// OmniRoute's auto-routing.  The fallback chain still fires if
			// the LKGM is now in cooldown or misconfigured.
			// Only applies to custom providers (built-in Gemini/Perplexity
			// have their own intra-provider fallback chains).
			$registry = \SEO_Article_Generator\AI\Provider_Registry::get_instance();
			if ( $registry->is_custom( $provider ) ) {
				$lkgm = (string) \get_transient( 'seogen_lkgm_' . sanitize_key( $provider ) );
				if ( $lkgm !== '' ) {
					$profile   = $registry->get_custom_profile( $provider );
					$model_ids = array_map( function ( $m ) {
						return (string) ( $m['model_id'] ?? '' );
					}, (array) ( $profile['models'] ?? array() ) );
					$model_ids = array_filter( $model_ids );

					if ( in_array( $lkgm, $model_ids, true ) ) {
						$model = $lkgm;
						if ( $this->logger ) {
							$this->logger->info( "LKGM: starting at last-known-good model", array(
								"provider" => $provider,
								"lkgm"     => $lkgm,
								"default"  => (string) ( $first["model"] ?? "" ),
							) );
						}
					} elseif ( $this->logger ) {
						$this->logger->info( "LKGM: transient model not in provider model list, using default", array(
							"provider"    => $provider,
							"lkgm"        => $lkgm,
							"model_count" => count( $model_ids ),
						) );
					}
				}
			}

			return array(
				'ok'       => true,
				'provider' => $provider,
				'api_key'  => AI_Client::get_api_key_for_provider( $provider ),
				'model'    => $model,
				'_rotation_idx' => $rot_idx,
			);
		}
		return array(
			'ok'          => false,
			'temporary'   => $status['paused'],
			'retry_after' => max(60, (int) ($status['min_retry_after'] ?? 60)),
			'reason'      => $status['paused'] ? 'No routable providers' : 'No active AI providers',
			'snapshot'    => AI_Client::get_generation_snapshot(),
		);
	}

	public function schedule_generation( $input_data, $user_id ) {
		global $wpdb;

		$jobs_table = Installer::table_jobs();
		$now_mysql  = Plugin_Time::utc_mysql_now();

		if ( ! is_array( $input_data ) ) {
			throw new \InvalidArgumentException( 'Generation input payload must be an array.' );
		}

		$is_update = ! empty( $input_data['existing_post_id'] ) || ! empty( $input_data['existingpostid'] );

		$defaults        = \SEO_Article_Generator\Option_Registry::defaults();
		$update_fallback = $defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS ];
		$new_fallback    = $defaults[ \SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS ];

		$raw_sections = array();

		if ( ! empty( $input_data['regen_sections'] ) && is_array( $input_data['regen_sections'] ) ) {
			$raw_sections = $input_data['regen_sections'];
		} elseif ( ! empty( $input_data['sections'] ) && is_array( $input_data['sections'] ) ) {
			$raw_sections = $input_data['sections'];
		} elseif ( ! empty( $input_data['section_selection'] ) && is_array( $input_data['section_selection'] ) ) {
			$raw_sections = $input_data['section_selection'];
		} else {
			$raw_sections = (array) \get_option(
				$is_update ? 'seo_gen_update_sections' : 'seo_gen_discovery_sections',
				$is_update ? $update_fallback : $new_fallback
			);
		}

		// @MODIFIED 2026-05-05: Pass 'toc' as a passthrough value for new-post jobs so that
		// the Table of Contents section selected in Discovery Generation Sections settings
		// survives normalization. 'toc' has no canonical content key (it is a render directive),
		// so normalize_sections() with an empty passthrough silently drops it before it can
		// reach the TOC injection decision in Article_Generator. Update jobs do not support
		// 'toc' in seo_gen_update_sections, so keep an empty passthrough for those.
		$sections_passthrough = $is_update ? array() : array( 'toc' );

		$canonical_sections = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections(
			$raw_sections,
			$sections_passthrough
		);

		if ( empty( $canonical_sections ) ) {
			$canonical_sections = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections(
				$is_update ? $update_fallback : $new_fallback,
				$sections_passthrough
			);
		}

		if ( empty( $canonical_sections ) ) {
			throw new \RuntimeException(
				$is_update
					? 'AI Update Sections resolved to an empty canonical set before job creation.'
					: 'Discovery Generation Sections resolved to an empty canonical set before job creation.'
			);
		}

		$canonical_sections = array_values(
			array_unique(
				array_filter(
					$canonical_sections,
					static function ( $section ) {
						return is_string( $section ) && trim( $section ) !== '';
					}
				)
			)
		);

		$input_data['regen_sections']    = $canonical_sections;
		$input_data['sections']          = $canonical_sections;
		$input_data['section_selection'] = $canonical_sections;

		$bootstrap = $this->resolve_generation_bootstrap();
		if ( empty( $bootstrap['ok'] ) ) {
			throw new \RuntimeException( (string) ( $bootstrap['reason'] ?? 'No active AI providers available' ) );
		}

		$wpdb->query( 'START TRANSACTION' );

		try {
			$inserted = $wpdb->insert(
				$jobs_table,
				array(
					'user_id'      => (int) $user_id,
					'status'       => 'pending',
					'input_data'   => \wp_json_encode( $input_data ),
					'available_at' => $now_mysql,
					'created_at'   => $now_mysql,
				),
				array( '%d', '%s', '%s', '%s', '%s' )
			);

			if ( 1 !== (int) $inserted ) {
				throw new \RuntimeException( 'Failed to create generation job. DB error: ' . $wpdb->last_error );
			}

			$job_id = (int) $wpdb->insert_id;

			$repo = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$q_id = $repo->enqueue(
				\SEO_Article_Generator\Queue\Job_Types::GENERATE_ARTICLE,
				$job_id,
				array( 'user_id' => (int) $user_id ),
				$now_mysql
			);

			if ( $q_id <= 0 ) {
				throw new \RuntimeException( 'Failed to create generation queue ticket.' );
			}

			$updated = $wpdb->update(
				$jobs_table,
				array( 'queue_job_id' => $q_id ),
				array( 'id' => $job_id ),
				array( '%d' ),
				array( '%d' )
			);

			if ( $updated === false ) {
				throw new \RuntimeException( 'Failed to persist generation queue ticket. DB error: ' . $wpdb->last_error );
			}

			$wpdb->query( 'COMMIT' );

			// Force-schedule an immediate queue worker kick. Routed through the
			// unique scheduler so a pending recurring/single tick short-circuits
			// instead of stacking another orphan row that would survive
			// unschedule_all($hook, []) and cause the next=1 OVERDUE feedback loop.
			if ( \SEO_Article_Generator\Queue\AS_Registry::is_ready_public() ) {
				\SEO_Article_Generator\Queue\AS_Registry::schedule_unique_single_action(
					Plugin_Time::now_utc_ts() + 1,
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_QUEUE_WORKER,
					array()
				);
			}

			return array(
				'job_id'       => $job_id,
				'queue_job_id' => $q_id,
			);
		} catch ( \Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			throw $e;
		}
	}

	private function schedule_timeout_reconcile( int $job_id, int $delay = self::RECONCILE_TIMEOUT_SECONDS ): void {
		if ( \function_exists( 'as_schedule_single_action' ) ) {
			\as_schedule_single_action(
				Plugin_Time::now_utc_ts() + max( 60, $delay ),
				'seo_gen_reconcile_job_timeout',
				array( $job_id ),
				'seo-gen',
				false,
				10
			);
		}
	}

	public function process_job( $job_id, $queue_job_id = null, $reservation_token = null ) {
		$job_id = \absint( is_array( $job_id ) ? ( $job_id['job_id'] ?? 0 ) : $job_id );
		if ( ! $job_id ) {
			return;
		}

		if ( \function_exists( '\wp_raise_memory_limit' ) ) {
			\wp_raise_memory_limit( 'admin' );
		}
		if ( \function_exists( 'set_time_limit' ) ) {
			\set_time_limit( 300 );
		}

		$job = $this->load_job_for_execution( $job_id );
		if ( ! $job ) {
			return;
		}

		if ( null === $queue_job_id && ! empty( $job['queue_job_id'] ) ) {
			$queue_job_id = (int) $job['queue_job_id'];
		}

		if ( ! in_array( (string) $job['status'], array( 'pending', 'deferred', 'processing' ), true ) ) {
			return;
		}

		// FIX F2 (2026-09-06): worker-side orphan refusal. The 09-05 loop created
		// 2752 jobs for 20 discoveries; 433 completions matched no row and their
		// AI spend burned for nothing (plus a 2545-deep queue backlog). Before
		// touching the lease or the AI, verify a discovery-linked job is still
		// owned by a live row. Ad-hoc (manual form) jobs carry no discovery_id
		// and are never refused here.
		if ( ! $this->is_job_owned_by_live_discovery( (int) $job_id, is_array( $job ) ? $job : array() ) ) {
			$this->logger->warning( "Job {$job_id} refused: orphaned (discovery released or superseded it). Failing without AI burn." );
			$this->fail_job(
				(int) $job_id,
				'Orphaned: owning discovery no longer references this job (superseded or terminal). Refused before AI burn.',
				array( 'pending', 'deferred', 'processing' ),
				$queue_job_id ? (int) $queue_job_id : null,
				$reservation_token ? (string) $reservation_token : null
			);
			return;
		}

		// FIX (Phase 3F, 2.34.0) — post-level duplicate suppression. The 09-06 log
		// showed ~2,480 ready backlog tickets, hundreds of which were duplicate
		// generation jobs for the SAME post (Wine/post 345 alone had 39). Each
		// duplicate ran a full AI call whose result was then dropped as an orphan
		// ('owns live job' / 'no identity-matched item'). Before touching the
		// lease or the AI, retire this ticket cheaply when a NEWER job already
		// covers the same post (or this job's discovery now points elsewhere).
		// Returns TRUE when this job is the live one and may proceed.
		if ( ! $this->is_job_latest_for_post( (int) $job_id, is_array( $job ) ? $job : array() ) ) {
			$this->logger->warning(
				"Job {$job_id} refused: superseded duplicate for the same post (a newer job covers it). Retired without AI burn."
			);
			$this->retire_superseded_job(
				(int) $job_id,
				'Superseded: a newer generation job already covers this post. Retired before AI burn (Phase 3F duplicate guard).',
				array( 'pending', 'deferred', 'processing' ),
				$queue_job_id ? (int) $queue_job_id : null,
				$reservation_token ? (string) $reservation_token : null
			);
			return;
		}

		// If already 'processing', verify the lease is actually held by this worker.
		// A stale 'processing' state (prior crash with no lock) must be re-claimable.
		if ( (string) $job['status'] === 'processing' ) {
			global $wpdb;
			$stale_lease = ! (bool) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . \SEO_Article_Generator\Installer::table_locks() .
					' WHERE lock_name = %s AND lease_expires_at > %s',
					$this->get_job_lock_name( $job_id ),
					\SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now()
				)
			);
			if ( ! $stale_lease ) {
				// Active lease held by another worker — do not steal.
				return;
			}
			// Stale 'processing' with no active lease: reset to 'pending' so this worker can claim it.
			// DO NOT reset retry_count — a crash-stale job must continue consuming its retry budget,
			// not restart it. Resetting to 0 allows infinite retry cycles for persistent errors.
			$reset = $wpdb->update(
				\SEO_Article_Generator\Installer::table_jobs(),
				array(
					'status'            => 'pending',
					'heartbeat_at'      => null,
					'status_started_at' => null,
				),
				array(
					'id'     => (int) $job_id,
					'status' => 'processing',
				),
				array( '%s', '%s', '%s' ),
				array( '%d', '%s' )
			);
			if ( (int) $reset !== 1 ) {
				return; // Another worker beat us to it.
			}
			$job['status'] = 'pending';
		}

		if ( ! empty( $job['available_at'] ) ) {
			$available_ts = Plugin_Time::utc_ts_from_utc_mysql( (string) $job['available_at'] );
			if ( $available_ts > Plugin_Time::now_utc_ts() ) {
				return;
			}
		}

		if ( $this->is_pipeline_paused() ) {
			$this->mark_job_deferred_or_throw(
				$job_id,
				Plugin_Time::now_utc_ts() + 60,
				'Pipeline paused.',
				array( 'pending', 'deferred' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		$lease_key = $this->get_job_lock_name( $job_id );
		$owner_key = \wp_generate_uuid4();

		if ( ! $this->acquire_lease( $lease_key, $owner_key, self::STALE_LEASE_SECONDS ) ) {
			$this->mark_job_deferred_or_throw(
				$job_id,
				Plugin_Time::now_utc_ts() + 30,
				'System busy',
				array( 'pending', 'deferred' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		$from_states = ( (string) $job['status'] === 'deferred' ) ? array( 'deferred' ) : array( 'pending' );

		$transitioned = false;
		foreach ( $from_states as $from_state ) {
			if ( $this->transition_job_status( $job_id, $from_state, 'processing' ) ) {
				$transitioned = true;
				break;
			}
		}

		if ( ! $transitioned ) {
			$this->release_lease( $lease_key, $owner_key );
			return;
		}

		if ( function_exists( '\update_option' ) ) {
			\update_option(
				'seo_gen_active_job',
				array(
					'job_id'     => $job_id,
					'started_at' => Plugin_Time::now_utc_ts(),
					'owner'      => $owner_key,
				),
				false
			);
		}

		$this->schedule_timeout_reconcile( (int) $job_id, self::RECONCILE_TIMEOUT_SECONDS );

		try {
			$job = $this->load_job_for_execution( $job_id );

			$input_data = \json_decode( $job['input_data'], true );
			if ( ! \is_array( $input_data ) ) {
				throw new \RuntimeException( 'Invalid job payload JSON' );
			}

			if ( $this->is_pipeline_paused() ) {
				$this->mark_job_deferred_or_throw(
					$job_id,
					Plugin_Time::now_utc_ts() + 60,
					'Pipeline paused.',
					array( 'processing' ),
					$queue_job_id,
					$reservation_token
				);
				return;
			}

			$bootstrap = $this->resolve_generation_bootstrap();

			if ( empty( $bootstrap['ok'] ) ) {
				if ( ! empty( $bootstrap['temporary'] ) ) {
					$retry_after = max( 60, (int) ( $bootstrap['retry_after'] ?? 60 ) );
					$this->logger->info(
						"Job {$job_id} deferred due to temporary provider issue: {$bootstrap['reason']}",
						array(
							'job_id'      => $job_id,
							'reason'      => $bootstrap['reason'],
							'retry_after' => $retry_after,
						)
					);
					$this->mark_job_deferred_or_throw(
						$job_id,
						Plugin_Time::now_utc_ts() + $retry_after,
						(string) $bootstrap['reason'],
						array( 'processing' ),
						$queue_job_id,
						$reservation_token
					);
					return;
				}

				throw new \RuntimeException( (string) $bootstrap['reason'] );
			}

				$this->verify_linked_discovery_exists( $job_id );

				// RUNTIME FINGERPRINT: Log job handler file/mtime for identity check authority
				$this->logger->info(
					'Job pre-flight identity check',
					array(
						'job_id'            => (int) $job_id,
						'queue_job_id'      => (int) $queue_job_id,
						'job_handler_file'  => __FILE__,
						'job_handler_mtime' => @filemtime( __FILE__ ),
					)
				);

				// Log before Admission Gate check to capture deferral reasons
			$this->logger->info(
				"Job {$job_id} attempting to claim Admission Gate slot",
				array(
					'job_id'   => $job_id,
					'software' => (string) ( $input_data['software_name'] ?? '' ),
					'version'  => (string) ( $input_data['discovered_version'] ?? '' ),
				)
			);

			// @MODIFIED 2026-04-09: Atomic Admission Gate for Background Workers
			$gate     = \SEO_Article_Generator\Core\Admission_Gate::get_instance();
			$software = (string) ( $input_data['software_name'] ?? '' );
			$version  = (string) ( $input_data['discovered_version'] ?? '' );

			/*
			 * Bootstrap/provider availability was already resolved above.
			 * Do not do a second non-atomic "can_proceed" read here.
			 * Claim the slot directly; that is the only authoritative admission step.
			 */
			if ( ! $gate->claim_slot( $software, $version ) ) {
				$metrics = $gate->get_inflight_metrics_uncached();

				$reason = ( (int) ( $metrics['generations'] ?? 0 ) >= (int) ( $metrics['maxgen'] ?? 0 ) )
					? 'Admission Gate busy: global generation limit reached.'
					: 'Admission Gate busy: equivalent item already in flight.';

				$this->mark_job_deferred_or_throw(
					$job_id,
					Plugin_Time::now_utc_ts() + 60,
					$reason,
					array( 'processing' ),
					$queue_job_id,
					$reservation_token
				);
				return;
			}

		try {
			$provider = (string) $bootstrap['provider'];
			$api_key  = (string) $bootstrap['api_key'];

			// [2.34.12] Inject snapshot-chosen ready model into custom provider
			// profile so Custom_Provider starts there instead of $ids[0] (which
			// may be dead/misconfigured).  Without this, every job pays a
			// guaranteed wasted 404 + hop before reaching a live model.
		$bootstrap_model = (string) ( $bootstrap['model'] ?? '' );
		if ( $bootstrap_model !== '' ) {
			$registry = Provider_Registry::get_instance();
			if ( $registry->is_custom( $provider ) ) {
				// [2.34.20 FIX] Use runtime-only field setter so _fallback_model
				// survives in-memory without being stripped by validate_custom_profile().
				$registry->set_custom_profile_runtime_field( $provider, '_fallback_model', $bootstrap_model );
			}
		}

			$ai_client = new AI_Client( $provider, $api_key, $this->logger );
				// [2.34.4] Pass execution context (job_id) so providers that key
				// conversations by session (OpenCode Zen `x-opencode-session`) get a
				// stable id across workers/retries/model+provider fallback.
				if ( method_exists( $ai_client, 'set_request_context' ) ) {
					$ai_client->set_request_context( array( 'job_id' => (int) $job_id ) );
				}
				$generator = new Article_Generator(
					$ai_client,
					new Link_Finder( $this->logger, new Links\DB_Post_Finder( $this->logger ) ),
					new Validator(),
					$this->logger
				);

				$this->heartbeat_job( $job_id, $lease_key, $owner_key, self::STALE_LEASE_SECONDS, $queue_job_id, $reservation_token );

				$heartbeat = function () use ( $job_id, $lease_key, $owner_key, $queue_job_id, $reservation_token ) {
					$this->assert_job_not_cancelled( (int) $job_id );
					$this->heartbeat_job( $job_id, $lease_key, $owner_key, self::STALE_LEASE_SECONDS, $queue_job_id, $reservation_token );
				};

				$this->logger->info(
					'Runtime fingerprint',
					array(
						'job_id'                 => (int) $job_id,
						'job_handler_file'       => __FILE__,
						'job_handler_mtime'      => @filemtime( __FILE__ ),
						'article_generator_file' => ( new \ReflectionClass( \SEO_Article_Generator\Generator\Article_Generator::class ) )->getFileName(),
						'content_formatter_file' => ( new \ReflectionClass( \SEO_Article_Generator\Generator\Content_Formatter::class ) )->getFileName(),
					)
				);

				$this->assert_job_not_cancelled( (int) $job_id );

				$result = $generator->generate( $input_data, $heartbeat );

				$this->assert_job_not_cancelled( (int) $job_id );

				try {
					$this->heartbeat_job( $job_id, $lease_key, $owner_key, self::STALE_LEASE_SECONDS, $queue_job_id, $reservation_token );
				} catch ( \Throwable $heartbeat_error ) {
					if ( $this->classify_runtime_exception( $heartbeat_error ) === 'ownership_loss' && is_array( $result ) ) {
						$this->persist_post_generation_recovery_snapshot( (int) $job_id, $result, $heartbeat_error );
					}
					throw $heartbeat_error;
				}

				$this->complete_job( $job_id, $result, $job, $queue_job_id, $reservation_token );
			} finally {
				$gate->release_slot( $software, $version );
			}
		} catch ( \Throwable $e ) {
			$this->handle_job_error( $job_id, $job, $e, $queue_job_id, $reservation_token );
		} finally {
			$this->release_lease( $lease_key, $owner_key );
			$this->unschedule_timeout_reconcile( (int) $job_id );
			\delete_option( 'seo_gen_active_job' );
		}
	}

	private function unschedule_timeout_reconcile( int $job_id ): void {
		if ( \function_exists( 'as_unschedule_all_actions' ) ) {
			\as_unschedule_all_actions( 'seo_gen_reconcile_job_timeout', array( $job_id ), 'seo-gen' );
		}
	}

	private function get_current_job_and_queue_state( int $job_id ): array {
		global $wpdb;
		$jobs  = Installer::table_jobs();
		$queue = Installer::table_queue();

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT j.status AS job_status,
                    j.error_message,
                    j.queue_job_id,
                    j.heartbeat_at AS job_heartbeat_at,
                    q.status AS queue_status,
                    q.reservation_token,
                    q.heartbeat_at AS queue_heartbeat_at,
                    q.lease_expires_at
             FROM {$jobs} j
             LEFT JOIN {$queue} q ON q.id = j.queue_job_id
             WHERE j.id = %d
             LIMIT 1",
				$job_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : array();
	}

	private function format_heartbeat_diagnostic_error( $error ): string {
		$error = trim( (string) $error );
		if ( $error === '' ) {
			return '';
		}
		if ( strpos( $error, 'Heartbeat refused:' ) === 0 ) {
			return '[prior heartbeat diagnostic suppressed]';
		}
		return $error;
	}

	private function get_current_lock_state( string $lock_name ): array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT lock_name, owner_key, heartbeat_at, lease_expires_at
             FROM ' . Installer::table_locks() . '
             WHERE lock_name = %s
             LIMIT 1',
				$lock_name
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : array();
	}

	private function heartbeat_job( $job_id, $lock, $owner, $dur = 300, $queue_job_id = null, $reservation_token = null ) {
		global $wpdb;

		$now     = Plugin_Time::utc_mysql_now();
		$expires = Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + (int) $dur );

		$raw_updated = $wpdb->update(
			Installer::table_jobs(),
			array( 'heartbeat_at' => $now ),
			array(
				'id'     => (int) $job_id,
				'status' => 'processing',
			),
			array( '%s' ),
			array( '%d', '%s' )
		);

		if ( $raw_updated === false ) {
			throw new \RuntimeException(
				'Heartbeat DB update failed for job ' . (int) $job_id . ': ' . (string) $wpdb->last_error
			);
		}

		$updated = (int) $raw_updated;

		$state = null;
		if ( 1 !== $updated ) {
			$state = $this->get_current_job_and_queue_state( (int) $job_id );

			if ( ( $state['job_status'] ?? '' ) !== 'processing' ) {
				throw new \RuntimeException(
					sprintf(
						'Heartbeat refused: expected processing, found job=%s queue=%s',
						$state['job_status'] ?? 'missing',
						$state['queue_status'] ?? 'missing'
					)
				);
			}

			$last_heartbeat    = strtotime( (string) ( $state['job_heartbeat_at'] ?? '' ) . ' UTC' );
			$seconds_since_log = $last_heartbeat > 0 ? ( Plugin_Time::now_utc_ts() - $last_heartbeat ) : PHP_INT_MAX;
			if ( $seconds_since_log >= self::STALE_LEASE_SECONDS ) {
				$this->logger->info(
					'Heartbeat no-op accepted for still-processing job.',
					array(
						'job_id'             => (int) $job_id,
						'job_heartbeat_at'   => $state['job_heartbeat_at'] ?? null,
						'queue_heartbeat_at' => $state['queue_heartbeat_at'] ?? null,
						'lease_expires_at'   => $state['lease_expires_at'] ?? null,
					)
				);
			}
		}

		if ( $queue_job_id && $reservation_token ) {
			$repo        = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$queue_alive = $repo->heartbeat( $queue_job_id, $reservation_token, (int) $dur );

			if ( $queue_alive ) {
				$queue_state  = $repo->get_state( (int) $queue_job_id );
				$queue_status = (string) ( $queue_state['status'] ?? '' );
				$queue_token  = (string) ( $queue_state['reservation_token'] ?? '' );
				$lease_until  = (string) ( $queue_state['lease_expires_at'] ?? '' );

				if (
					$queue_status === \SEO_Article_Generator\Queue\Job_Repository::STATUS_RESERVED &&
					$queue_token === (string) $reservation_token &&
					$lease_until !== '' &&
					strtotime( $lease_until . ' UTC' ) > Plugin_Time::now_utc_ts()
				) {
					$repo->heartbeat( (int) $queue_job_id, (string) $reservation_token, (int) $dur );
					$this->logger->info(
						'Queue heartbeat idempotent recovery accepted — lease extended.',
						array(
							'job_id'            => (int) $job_id,
							'queue_job_id'      => (int) $queue_job_id,
							'reservation_token' => (string) $reservation_token,
							'queue_status'      => $queue_status,
							'lease_until'       => $lease_until,
							'runtime_file'      => __FILE__,
							'runtime_mtime'     => @filemtime( __FILE__ ),
						)
					);
				} else {
					$wpdb->update(
						Installer::table_jobs(),
						array(
							'status'            => 'reconcile_failed',
							'error_message'     => 'Queue reservation heartbeat refused during processing.',
							'heartbeat_at'      => null,
							'status_started_at' => null,
							'completed_at'      => Plugin_Time::utc_mysql_now(),
						),
						array(
							'id'     => (int) $job_id,
							'status' => 'processing',
						),
						array( '%s', '%s', '%s', '%s', '%s' ),
						array( '%d', '%s' )
					);

					$this->logger->error(
						'Queue heartbeat refused: reservation lost.',
						array(
							'job_id'            => (int) $job_id,
							'queue_job_id'      => (int) $queue_job_id,
							'reservation_token' => (string) $reservation_token,
							'queue_status'      => $queue_status !== '' ? $queue_status : 'missing',
							'queue_token'       => $queue_token !== '' ? $queue_token : 'missing',
							'lease_until'       => $lease_until !== '' ? $lease_until : 'missing',
							'runtime_file'      => __FILE__,
							'runtime_mtime'     => @filemtime( __FILE__ ),
						)
					);

					throw new \RuntimeException( 'Queue heartbeat refused: reservation lost.' );
				}
			}
		}

		$lock_updated = $wpdb->update(
			Installer::table_locks(),
			array(
				'heartbeat_at'     => $now,
				'lease_expires_at' => $expires,
			),
			array(
				'lock_name' => $this->get_job_lock_name( (int) $job_id ),
				'owner_key' => $owner,
			),
			array( '%s', '%s' ),
			array( '%s', '%s' )
		);

		if ( $lock_updated === false ) {
			throw new \RuntimeException(
				'Lease heartbeat DB update failed for job ' . (int) $job_id . ': ' . (string) $wpdb->last_error
			);
		}

		if ( 1 !== (int) $lock_updated ) {
			$lock_state = $this->get_current_lock_state( $this->get_job_lock_name( (int) $job_id ) );

			if ( ( $lock_state['owner_key'] ?? '' ) === (string) $owner ) {
				if ( $queue_job_id && $reservation_token ) {
					$repo         = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
					$queue_state  = $repo->get_state( (int) $queue_job_id );
					$queue_status = $queue_state['status'] ?? '';
					$queue_token  = $queue_state['reservation_token'] ?? '';
					$lease_until  = $queue_state['lease_expires_at'] ?? '';

					if (
						$queue_status === \SEO_Article_Generator\Queue\Job_Repository::STATUS_RESERVED &&
						$queue_token === (string) $reservation_token &&
						! empty( $lease_until ) &&
						strtotime( $lease_until . ' UTC' ) > Plugin_Time::now_utc_ts()
					) {
						$wpdb->update(
							Installer::table_locks(),
							array(
								'heartbeat_at'     => $now,
								'lease_expires_at' => $expires,
								'updated_at'       => $now,
							),
							array(
								'lock_name' => $this->get_job_lock_name( (int) $job_id ),
							),
							array( '%s', '%s', '%s' ),
							array( '%s' )
						);
						$this->logger->info(
							'Heartbeat idempotent recovery accepted — lease extended.',
							array(
								'job_id'        => (int) $job_id,
								'expected'      => (string) $owner,
								'queue_status'  => $queue_status,
								'lease_until'   => $lease_until,
								'runtime_file'  => __FILE__,
								'runtime_mtime' => @filemtime( __FILE__ ),
							)
						);
						return true;
					}
				} else {
					return true;
				}
			}

			$this->logger->error(
				'Lease heartbeat refused: owner mismatch.',
				array(
					'job_id'         => (int) $job_id,
					'expected_owner' => (string) $owner,
					'found_owner'    => $lock_state['owner_key'] ?? 'missing',
					'lease_until'    => $lock_state['lease_expires_at'] ?? 'missing',
					'runtime_file'   => __FILE__,
					'runtime_mtime'  => @filemtime( __FILE__ ),
				)
			);

			throw new \RuntimeException(
				sprintf(
					'Lease heartbeat refused: expected owner=%s, found owner=%s lease_until=%s',
					(string) $owner,
					$lock_state['owner_key'] ?? 'missing',
					$lock_state['lease_expires_at'] ?? 'missing'
				)
			);
		}

		$this->logger->info(
			'Progressive heartbeat extension applied.',
			array(
				'job_id'         => (int) $job_id,
				'lease_duration' => (int) $dur,
				'new_expiry'     => $expires,
			)
		);
	}

	/**
	 * Deterministic generation failures must not be retried.
	 *
	 * @param \Throwable $e
	 * @return bool
	 */
	private function is_deterministic_generation_exception( \Throwable $e ): bool {
		if ( $e instanceof \SEO_Article_Generator\AI\DeterministicFailureException ) {
			return true;
		}

		$message    = strtolower( trim( (string) $e->getMessage() ) );
		$signatures = array(
			'cannot access offset of type string on string',
			'invalid schema',
			'non-array payload',
			'validator returned invalid results',
			'final sanity check',
			'all partial regeneration sections failed sanity check',
			// @MODIFIED 2026-05-22: Missing required sections (e.g. "download" with zero links)
			// is permanent — retrying the same discovery data will always produce the same gap.
			'missing required populated sections',
			// [PHASE 3D, 2.32.28] Thin-output guard: a full-render self-heal / forced
			// rewrite whose AI response (200 OK) omitted the prose sections, even after
			// the generator's single alternate-model retry, is terminal at job level.
			// The published post must NOT be touched; the discovery row parks in the
			// Failed tab (recovery registry classifies the signature as 'abort').
			'full_render_ai_omitted_sections',
			// HTTP 400 = INVALID_ARGUMENT: bad request body, invalid model ID, unsupported param.
			// Retrying an identical payload will always return 400. Hard-fail immediately.
			'http 400',
			'status code 400',
			'error 400',
			'(http 400)',
			'invalid_argument',
			'invalidargument',
			'bad request',
		);
		foreach ( $signatures as $needle ) {
			if ( $needle !== '' && strpos( $message, $needle ) !== false ) {
				return true;
			}
		}
		return false;
	}

	private function classify_runtime_exception( \Throwable $e ): string {
		$message = strtolower( trim( (string) $e->getMessage() ) );

		foreach ( array(
			'heartbeat refused: expected processing',
			'queue heartbeat refused: reservation lost',
			'lease heartbeat refused: expected owner',
		) as $needle ) {
			if ( strpos( $message, $needle ) !== false ) {
				return 'ownership_loss';
			}
		}

		foreach ( array(
			'heartbeat db update failed',
			'lease heartbeat db update failed',
		) as $needle ) {
			if ( strpos( $message, $needle ) !== false ) {
				return 'infra_failure';
			}
		}

		return 'generic';
	}

	private function transition_job_terminal_strict(
		int $job_id,
		string $target_status,
		string $reason,
		array $from_states,
		$queue_job_id = null,
		$reservation_token = null
	): void {
		global $wpdb;

		$sql_states = "'" . implode( "','", array_map( 'esc_sql', $from_states ) ) . "'";
		$now        = Plugin_Time::utc_mysql_now();

		$updated = (int) $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . Installer::table_jobs() . "
                 SET status = %s,
                     error_message = %s,
                     heartbeat_at = NULL,
                     status_started_at = NULL,
                     completed_at = %s
                 WHERE id = %d
                   AND status IN ({$sql_states})",
				$target_status,
				$reason,
				$now,
				$job_id
			)
		);

		if ( $updated !== 1 ) {
			$state = $this->get_current_job_and_queue_state( $job_id );

			if ( ( $state['job_status'] ?? '' ) !== $target_status ) {
				throw new \RuntimeException(
					sprintf(
						'Terminal transition refused for job %d: wanted=%s found job=%s queue=%s error=%s',
						$job_id,
						$target_status,
						$state['job_status'] ?? 'missing',
						$state['queue_status'] ?? 'missing',
						$this->format_heartbeat_diagnostic_error( $state['error_message'] ?? '' )
					)
				);
			}
		}

		if ( $queue_job_id && $reservation_token ) {
			$repo = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );

			if ( $target_status === 'reconcile_failed' ) {
				$queue_state = $repo->get_state( (int) $queue_job_id );

				if (
					( $queue_state['status'] ?? '' ) === \SEO_Article_Generator\Queue\Job_Repository::STATUS_RESERVED &&
					(string) ( $queue_state['reservation_token'] ?? '' ) === (string) $reservation_token
				) {
					$queue_ok = $repo->mark_terminal_failed(
						(int) $queue_job_id,
						(string) $reservation_token,
						'Ownership loss during generation: ' . $reason
					);

					if ( ! $queue_ok ) {
						throw new \RuntimeException(
							'Queue terminal failure CAS refused while reconciling ownership loss for job ' . $job_id
						);
					}
				}
			} else {
				$queue_ok = $repo->mark_terminal_failed(
					(int) $queue_job_id,
					(string) $reservation_token,
					$reason
				);

				if ( ! $queue_ok ) {
					throw new \RuntimeException(
						'Queue reconciliation failed while setting terminal job state for job ' . $job_id
					);
				}
			}
		}

		if ( function_exists( '\do_action' ) ) {
			$user_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT user_id FROM ' . Installer::table_jobs() . ' WHERE id = %d',
					$job_id
				)
			);

			\do_action( 'seo_gen_job_finished', $job_id, $target_status, $user_id );
		}
	}

	private function retry_job_or_throw( $job_id, $count, $reason, array $from_states = array( 'processing' ), $queue_job_id = null, $reservation_token = null, ?API_Error_Info $error_info = null, string $provider = '', string $model = '' ): void {
		if ( ! $this->retry_job( $job_id, $count, $reason, $from_states, $queue_job_id, $reservation_token, $error_info, $provider, $model ) ) {
			$state = $this->get_current_job_and_queue_state( (int) $job_id );

			throw new \RuntimeException(
				sprintf(
					'Retry transition refused for job %d: found job=%s queue=%s error=%s',
					(int) $job_id,
					$state['job_status'] ?? 'missing',
					$state['queue_status'] ?? 'missing',
					$this->format_heartbeat_diagnostic_error( $state['error_message'] ?? '' )
				)
			);
		}
	}

	private function mark_job_deferred_or_throw( $job_id, $at, $reason, array $from_states = array( 'processing' ), $queue_job_id = null, $reservation_token = null ): void {
		if ( ! $this->mark_job_deferred( $job_id, $at, $reason, $from_states, $queue_job_id, $reservation_token ) ) {
			$state = $this->get_current_job_and_queue_state( (int) $job_id );

			throw new \RuntimeException(
				sprintf(
					'Deferred transition refused for job %d: found job=%s queue=%s error=%s',
					(int) $job_id,
					$state['job_status'] ?? 'missing',
					$state['queue_status'] ?? 'missing',
					$this->format_heartbeat_diagnostic_error( $state['error_message'] ?? '' )
				)
			);
		}
	}

	/**
	 * Persist a compact failure snapshot for debugging without bloating the jobs table.
	 *
	 * @param int        $job_id
	 * @param array|null $job
	 * @param \Throwable $e
	 * @return void
	 */
	private function persist_failure_debug_context( int $job_id, $job, \Throwable $e ): void {
		global $wpdb;

		$existing_debug = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT debug_data FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				$job_id
			)
		);

		$payload = array(
			'failure' => array(
				'class'       => get_class( $e ),
				'message'     => (string) $e->getMessage(),
				'code'        => (int) $e->getCode(),
				'file'        => $e->getFile(),
				'line'        => $e->getLine(),
				'trace_head'  => substr( $e->getTraceAsString(), 0, 4000 ),
				'retry_count' => (int) ( $job['retry_count'] ?? 0 ),
			),
		);

		if ( ! empty( $job['input_data'] ) ) {
			$decoded = json_decode( (string) $job['input_data'], true );
			if ( is_array( $decoded ) ) {
				$payload['input_summary'] = array(
					'software_name'    => (string) ( $decoded['software_name'] ?? '' ),
					'existing_post_id' => (int) ( $decoded['existing_post_id'] ?? 0 ),
					'input_type'       => (string) ( $decoded['input_type'] ?? '' ),
					'regen_sections'   => array_values( (array) ( $decoded['regen_sections'] ?? array() ) ),
				);
			}
		}

		if ( ! empty( $existing_debug ) ) {
			$decoded_existing = json_decode( (string) $existing_debug, true );
			if ( is_array( $decoded_existing ) ) {
				$payload = array_merge( $decoded_existing, $payload );
			}
		}

		$wpdb->update(
			Installer::table_jobs(),
			array( 'debug_data' => wp_json_encode( $payload ) ),
			array( 'id' => $job_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	private function persist_post_generation_recovery_snapshot( int $job_id, array $result, \Throwable $e ): void {
		global $wpdb;

		$article    = isset( $result['article'] ) && is_array( $result['article'] ) ? $result['article'] : array();
		$validation = isset( $result['validation'] ) && is_array( $result['validation'] ) ? $result['validation'] : array(
			'passed'   => false,
			'score'    => 0,
			'errors'   => array( 'Recovery snapshot missing validation payload.' ),
			'warnings' => array(),
		);

		$existing_debug = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT debug_data FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				$job_id
			)
		);

		$debug = array();
		if ( ! empty( $existing_debug ) ) {
			$decoded = json_decode( (string) $existing_debug, true );
			if ( is_array( $decoded ) ) {
				$debug = $decoded;
			}
		}

		$debug['post_generation_recovery'] = array(
			'captured_at' => Plugin_Time::utc_mysql_now(),
			'reason'      => (string) $e->getMessage(),
			'file'        => __FILE__,
			'mtime'       => @filemtime( __FILE__ ),
		);

		$wpdb->update(
			Installer::table_jobs(),
			array(
				'output_data'        => wp_json_encode( $article ),
				'validation_results' => wp_json_encode( $validation ),
				'debug_data'         => wp_json_encode( $debug ),
			),
			array( 'id' => $job_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	private function handle_job_error( $job_id, $job, $e, $queue_job_id = null, $reservation_token = null ) {
		if ( strpos( (string) $e->getMessage(), 'Job cancelled by operator.' ) !== false ) {
			$this->logger->warning( "Job {$job_id} stopped after operator cancellation." );
			return;
		}

		$this->logger->error( "Job {$job_id} error: " . $e->getMessage() );
		$this->persist_failure_debug_context( (int) $job_id, is_array( $job ) ? $job : array(), $e );

		$runtime_class = $this->classify_runtime_exception( $e );

		if ( $runtime_class === 'ownership_loss' ) {
			$this->transition_job_terminal_strict(
				(int) $job_id,
				'reconcile_failed',
				(string) $e->getMessage(),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		if ( $runtime_class === 'infra_failure' ) {
			$this->transition_job_terminal_strict(
				(int) $job_id,
				'failed',
				'Infrastructure failure during heartbeat/lease renewal: ' . (string) $e->getMessage(),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		if ( $e instanceof AI_Rate_Limit_Exception ) {
			$error_info = $e->get_error_info();
			$snapshot   = AI_Client::get_generation_snapshot();
			$bootstrap  = $this->resolve_generation_bootstrap();

			if ( $error_info !== null ) {
				$retry_after = Backoff_Strategy::delay_for_attempt(
					(int) ( $job['retry_count'] ?? 0 ) + 1,
					$error_info,
					$e->get_provider(),
					''
				);
				$reset_at    = $error_info->get_reset_at_ts();
				$reason      = $error_info->is_daily_quota()
					? 'Daily Quota Exhausted'
					: ( $error_info->get_error_type() === API_Error_Info::TYPE_SERVER_OVERLOADED
					? 'Provider Overloaded'
					: 'Rate Limit Strike' );
			} else {
				$retry_after = max(
					60,
					(int) ( $snapshot['min_retry_after'] ?? 300 ),
					(int) ( $bootstrap['retry_after'] ?? 0 )
				);
				$reset_at    = $e->get_reset_at();
				$reason      = (string) ( $bootstrap['reason'] ?? $e->getMessage() ?: 'Rate Limit' );
			}

			if ( strpos( $reason, 'Provider-only mode is enabled' ) !== false ) {
				$retry_after = max( $retry_after, 900 );
			}

			if ( $reset_at > Plugin_Time::now_utc_ts() ) {
				$defer_at = $reset_at + 30;
			} else {
				$defaults       = \SEO_Article_Generator\Option_Registry::defaults();
				$delay_min      = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
				$delay_max      = max( $delay_min, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );
				$random_seconds = rand( $delay_min * 60, $delay_max * 60 );
				$defer_at       = Plugin_Time::now_utc_ts() + $retry_after + $random_seconds;
			}

			$this->mark_job_deferred_or_throw(
				$job_id,
				$defer_at,
				$reason,
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		if ( strpos( (string) $e->getMessage(), 'No active AI providers available' ) !== false ) {
			$bootstrap = $this->resolve_generation_bootstrap();

			if ( ! empty( $bootstrap['temporary'] ) ) {
				$retry_after = max( 60, (int) ( $bootstrap['retry_after'] ?? 300 ) );

				// Fix #5: Use PUBLISH_INTERVAL_MIN/MAX (clumping protection) instead of UPDATE_DELAY
				$defaults        = \SEO_Article_Generator\Option_Registry::defaults();
				$delay_min2      = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
				$delay_max2      = max( $delay_min2, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );
				$random_seconds2 = rand( $delay_min2 * 60, $delay_max2 * 60 );

				$staggered_retry2 = $retry_after + $random_seconds2;

				$this->mark_job_deferred_or_throw(
					$job_id,
					Plugin_Time::now_utc_ts() + $staggered_retry2,
					(string) ( $bootstrap['reason'] ?? $e->getMessage() ),
					array( 'processing', 'generating', 'validating' ),
					$queue_job_id,
					$reservation_token
				);
						return;
			}
		}

		if ( $this->is_deterministic_generation_exception( $e ) ) {
			$this->logger->error(
				'Deterministic generation failure',
				array(
					'job_id' => (int) $job_id,
					'class'  => get_class( $e ),
					'file'   => $e->getFile(),
					'line'   => $e->getLine(),
					'error'  => $e->getMessage(),
				)
			);

			$this->transition_job_terminal_strict(
				(int) $job_id,
				self::STATUS_FAILED_VALIDATION,
				'Deterministic generation failure: ' . (string) $e->getMessage(),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		// MODIFIED: Identity failures don't benefit from multiple retries - fail immediately
		if ( strpos( (string) $e->getMessage(), 'discovery identity was replaced' ) !== false ) {
			$this->transition_job_terminal_strict(
				(int) $job_id,
				'failed',
				'Aborted: ' . (string) $e->getMessage(),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}

		$attempts = (int) ( $job['retry_count'] ?? 0 );
		if ( $attempts < $this->max_job_retries ) {
			$fallback_error_info = ( $e instanceof AI_Rate_Limit_Exception ) ? $e->get_error_info() : null;
			$fallback_provider   = ( $e instanceof AI_Rate_Limit_Exception ) ? $e->get_provider() : '';
			$this->retry_job_or_throw(
				$job_id,
				$attempts + 1,
				(string) $e->getMessage(),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token,
				$fallback_error_info,
				$fallback_provider,
				''
			);
			return;
		}

		$this->transition_job_terminal_strict(
			(int) $job_id,
			'failed',
			(string) $e->getMessage(),
			array( 'processing', 'generating', 'validating' ),
			$queue_job_id,
			$reservation_token
		);
	}

	private function retry_job( $job_id, $count, $reason, array $from_states = array( 'processing' ), $queue_job_id = null, $reservation_token = null, ?API_Error_Info $error_info = null, string $provider = '', string $model = '' ) {
		global $wpdb;

		$backoff    = Backoff_Strategy::delay_for_attempt( $count, $error_info, $provider, $model );
		$retry_at   = Plugin_Time::now_utc_ts() + $backoff;
		$sql_states = "'" . implode( "','", array_map( 'esc_sql', $from_states ) ) . "'";

		$sql = $wpdb->prepare(
			'UPDATE ' . Installer::table_jobs() . "
             SET status = %s,
                 retry_count = %d,
                 available_at = %s,
                 error_message = %s,
                 heartbeat_at = NULL,
                 status_started_at = NULL,
                 completed_at = NULL
             WHERE id = %d
               AND status IN ({$sql_states})",
			'pending',
			(int) $count,
			Plugin_Time::utc_mysql_from_utc_ts( $retry_at ),
			(string) $reason,
			(int) $job_id
		);

		$ok = 1 === (int) $wpdb->query( $sql );

		if ( ! $ok ) {
			return false;
		}

		if ( $queue_job_id && $reservation_token ) {
			$repo     = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$queue_ok = $repo->mark_failed( $queue_job_id, (int) $count, $reservation_token );

			if ( ! $queue_ok ) {
				$wpdb->update(
					Installer::table_jobs(),
					array(
						'status'        => 'reconcile_failed',
						'error_message' => 'Queue retry CAS refused after job retry transition.',
						'completed_at'  => Plugin_Time::utc_mysql_now(),
					),
					array(
						'id'     => (int) $job_id,
						'status' => 'pending',
					),
					array( '%s', '%s', '%s' ),
					array( '%d', '%s' )
				);
				return false;
			}
		}

		return true;
	}

	private function mark_job_deferred( $job_id, $at, $reason, array $from_states = array( 'processing' ), $queue_job_id = null, $reservation_token = null ) {
		global $wpdb;

		$sql_states = "'" . implode( "','", array_map( 'esc_sql', $from_states ) ) . "'";

		$sql = $wpdb->prepare(
			'UPDATE ' . Installer::table_jobs() . "
             SET status = %s,
                 available_at = %s,
                 error_message = NULL,
                 heartbeat_at = NULL,
                 status_started_at = NULL,
                 completed_at = NULL
             WHERE id = %d
               AND status IN ({$sql_states})",
			'deferred',
			Plugin_Time::utc_mysql_from_utc_ts( (int) $at ),
			(int) $job_id
		);

		$ok = 1 === (int) $wpdb->query( $sql );

		if ( ! $ok ) {
			return false;
		}

		if ( $queue_job_id && $reservation_token ) {
			$repo     = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$delay    = $this->seconds_until_utc( (int) $at );
			$queue_ok = $repo->requeue_deferred( $queue_job_id, $reservation_token, $delay );

			if ( ! $queue_ok ) {
				$wpdb->update(
					Installer::table_jobs(),
					array(
						'status'        => 'reconcile_failed',
						'error_message' => 'Queue defer CAS refused after job defer transition.',
						'completed_at'  => Plugin_Time::utc_mysql_now(),
					),
					array(
						'id'     => (int) $job_id,
						'status' => 'deferred',
					),
					array( '%s', '%s', '%s' ),
					array( '%d', '%s' )
				);
				return false;
			}
		}

		$this->logger->info(
			"Job {$job_id} deferred: {$reason} (until {$at})",
			array(
				'job_id'         => $job_id,
				'reason'         => $reason,
				'deferred_until' => $at,
				'from_states'    => $from_states,
			)
		);

		return true;
	}

	public function complete_job( $job_id, $result, $job, $queue_job_id = null, $reservation_token = null ) {
		global $wpdb;

		$validation = $result['validation'] ?? array(
			'passed'   => false,
			'score'    => 0,
			'errors'   => array( 'Missing' ),
			'warnings' => array(),
		);

		$article = $result['article'] ?? array();

		if ( ! is_array( $article ) ) {
			$this->logger->error(
				'Job ' . (int) $job_id . ' returned non-array article payload.',
				array( 'type' => gettype( $article ) )
			);

			$article = array(
				'failed_sections'        => array(),
				'hallucination_warnings' => array( 'issues' => array() ),
				'_payload_error'         => 'Non-array article payload from generator',
				'_raw_article'           => is_scalar( $article ) ? (string) $article : wp_json_encode( $article ),
			);

			$validation['passed'] = false;
			if ( is_array( $validation['errors'] ?? null ) ) {
				$validation['errors'][] = 'Generator returned non-array article payload';
			}
		}

		$hallucination_issues = array();
		if (
			isset( $article['hallucination_warnings'] ) &&
			is_array( $article['hallucination_warnings'] ) &&
			isset( $article['hallucination_warnings']['issues'] ) &&
			is_array( $article['hallucination_warnings']['issues'] )
		) {
			$hallucination_issues = $article['hallucination_warnings']['issues'];
		}

		$failed_sections = isset( $article['failed_sections'] ) && is_array( $article['failed_sections'] )
			? $article['failed_sections']
			: array();

		// @MODIFIED 2026-05-03: Download-related validation errors are hard blocks.
		// Non-download errors remain soft quality gates (logged, non-blocking).
		$validation_passed = ! empty( $validation['passed'] );
		$download_errors   = array();
		if ( ! $validation_passed && ! empty( $validation['errors'] ) ) {
			foreach ( $validation['errors'] as $err ) {
				if ( stripos( $err, 'download' ) !== false ) {
					$download_errors[] = $err;
				}
			}
		}
		if ( ! empty( $download_errors ) ) {
			$this->transition_job_terminal_strict(
				(int) $job_id,
				self::STATUS_FAILED_VALIDATION,
				'Blocked: ' . implode( '; ', $download_errors ),
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id,
				$reservation_token
			);
			return;
		}
		if ( ! $validation_passed ) {
			$this->logger->warning(
				'Job completed below quality threshold — proceeding to finalization with quality flags.',
				array(
					'jobid'  => $job_id,
					'score'  => $validation['score'] ?? 0,
					'errors' => $validation['errors'] ?? array(),
				)
			);
		}
		$final_status = 'completed';
		$now          = Plugin_Time::utc_mysql_now();

		// ── STEP 1: CAS the job table FIRST. Article data is persisted before queue is touched. ──
		$updated = $wpdb->update(
			Installer::table_jobs(),
			array(
				'status'                  => $final_status,
				'output_data'             => \wp_json_encode( $article ),
				'validation_results'      => \wp_json_encode( $validation ),
				'debug_data'              => isset( $result['_debug'] ) ? \wp_json_encode( $result['_debug'] ) : null,
				'error_message'           => null,
				'heartbeat_at'            => null,
				'status_started_at'       => null,
				'completed_at'            => $now,
				'hallucination_count'     => count( $hallucination_issues ),
				'failed_sections_count'   => count( $failed_sections ),
				'validation_errors_count' => count( $validation['errors'] ?? array() ),
			),
			array(
				'id'     => (int) $job_id,
				'status' => 'processing',
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d' ),
			array( '%d', '%s' )
		);

		if ( 1 !== (int) $updated ) {
			$current = (string) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT status FROM ' . Installer::table_jobs() . ' WHERE id = %d',
					(int) $job_id
				)
			);

			if ( $current === $final_status ) {
				// Concurrent completion by another worker — article was already persisted by them.
				// Still need to ensure queue is reconciled below; fall through.
				$this->logger->info( "Job {$job_id} already marked {$final_status} by concurrent process. Success." );
			} elseif ( $this->is_operator_terminal_failure(
				$current,
				(string) $wpdb->get_var(
					$wpdb->prepare( 'SELECT error_message FROM ' . Installer::table_jobs() . ' WHERE id = %d', (int) $job_id )
				)
			) ) {
				$this->logger->warning(
					"Job {$job_id} completion abandoned — operator cancelled."
				);
				return;
			} else {
				// Job status is neither 'completed' nor operator-cancelled (e.g. 'failed' from reconciler).
				// Article data is NOT persisted — this is the actual data-loss scenario.
				throw new \RuntimeException( 'Job completion CAS failed for job ' . (int) $job_id . " (Current status: {$current})" );
			}
		}

		// ── STEP 2: Article is now safely in DB. Mark queue terminal. ──
		if ( $queue_job_id && $reservation_token ) {
			$repo = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );

			if ( $final_status === 'completed' ) {
				$status_ok = $repo->mark_terminal_completed( $queue_job_id, $reservation_token );
			} else {
				$status_ok = $repo->mark_terminal_failed(
					$queue_job_id,
					$reservation_token,
					'Validation failed: ' . \wp_json_encode( $validation['errors'] ?? array() )
				);
			}

			if ( ! $status_ok ) {
				// Job is completed and article is persisted. Queue is inconsistent.
				// normalizelifecyclepayload(job=completed, queue=reserved) → 'reconcilefailed' → shouldfail.
				// recover_from_reconcile_failed_snapshot() will read output_data (which IS written) and finalize.
				$this->transition_job_terminal_strict(
					(int) $job_id,
					'reconcile_failed',
					'Queue terminal CAS refused after job completion — article persisted, recovery via snapshot.',
					array( 'completed' ),
					$queue_job_id,
					$reservation_token
				);
				return;
			}
		}

		$this->logger->info( "Job {$job_id} finished with status {$final_status}" );

		if ( function_exists( '\do_action' ) ) {
			\do_action( 'seo_gen_job_finished', (int) $job_id, $final_status, (int) ( $job['user_id'] ?? 0 ) );
		}
	}

	public function get_job_status( $job_id ) {
		global $wpdb;
		$job = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT status, error_message, user_id, queue_job_id, available_at, heartbeat_at, status_started_at, created_at
             FROM ' . Installer::table_jobs() . '
             WHERE id = %d',
				(int) $job_id
			),
			ARRAY_A
		);

		if ( $job && ! empty( $job['queue_job_id'] ) ) {
			$queue_table         = Installer::table_queue();
			$job['queue_status'] = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT status FROM {$queue_table} WHERE id = %d",
					(int) $job['queue_job_id']
				)
			);
		}

		return $job;
	}

	public const STATUS_MISSING = 'missing';

	private function normalize_lifecycle_payload( array $raw ): array {
		$job_state   = (string) ( $raw['job_status'] ?? '' );
		$queue_state = (string) ( $raw['queue_status'] ?? '' );
		$error       = trim( (string) ( $raw['error_message'] ?? '' ) );
		$user_id     = (int) ( $raw['user_id'] ?? 0 );

		$dto = array(
			'combined_status' => (string) ( $raw['combined_status'] ?? ( $job_state !== '' ? $job_state : ( $queue_state !== '' ? $queue_state : 'unknown' ) ) ),
			'job_status'      => $job_state,
			'queue_status'    => $queue_state,
			'error_message'   => $error,
			'user_id'         => $user_id,
			'should_continue' => false,
			'should_finalize' => false,
			'should_fail'     => false,
			'failure_status'  => 'failed',
			'failure_reason'  => $error !== '' ? $error : 'AI job failed.',
			'deferred_until'  => 0,
		);

		if ( $job_state === 'completed' && $queue_state === 'reserved' ) {
			$dto['combined_status'] = 'reconcile_failed';
			$dto['should_fail']     = true;
			$dto['failure_status']  = 'failed';
			$dto['failure_reason']  = 'Job completed but queue ticket is still reserved.';
			return $dto;
		}

		if ( $job_state === 'completed' ) {
			$dto['combined_status'] = 'completed';
			$dto['should_finalize'] = true;
			return $dto;
		}

		if ( \in_array( $job_state, array( 'timed_out', 'timeout' ), true ) ) {
			$dto['combined_status'] = $job_state;
			$dto['should_fail']     = true;
			$dto['failure_status']  = 'timeout';
			$dto['failure_reason']  = $error !== '' ? $error : 'AI job timed out.';
			return $dto;
		}

		if ( $job_state === self::STATUS_FAILED_VALIDATION ) {
			$dto['combined_status'] = self::STATUS_FAILED_VALIDATION;
			$dto['should_fail']     = true;
			$dto['failure_status']  = 'failed';
			$dto['failure_reason']  = $error !== '' ? $error : 'AI job failed validation.';
			return $dto;
		}

		if ( \in_array( $job_state, array( 'failed', 'error', 'reconcile_failed' ), true ) ) {
			$dto['combined_status'] = $job_state;
			$dto['should_fail']     = true;
			$dto['failure_status']  = 'failed';
			$dto['failure_reason']  = $error !== '' ? $error : 'AI job failed.';
			return $dto;
		}

		if ( $queue_state === 'failed' && $job_state !== 'completed' ) {
				$dto['combined_status'] = 'queue_failed';
				$dto['should_fail']     = true;
				$dto['failure_status']  = 'failed';
				$dto['failure_reason']  = $error !== '' ? $error : 'Queue ticket failed before completion.';
				return $dto;
		}

		// Stale-processing with terminal successful queue: job output is ready but jobs table was not reset
		if ( $job_state === 'processing' && $queue_state === 'completed' ) {
			$dto['combined_status'] = 'completed';
			$dto['job_status']      = 'completed';
			$dto['should_finalize'] = true;
			return $dto;
		}

		// Stale-processing guard: jobs table says 'processing' but the queue ticket is
		// back to 'queued' — the worker crashed and released the queue without resetting
		// the job status. Treat this as 'pending' so the next queue worker re-claims it.
		if ( $job_state === 'processing' && $queue_state === 'queued' ) {
			$dto['combined_status'] = 'pending';
			$dto['job_status']      = 'pending';
			$dto['should_continue'] = true;
			return $dto;
		}
		// Phase 3F (2.34.0): zombie suppression. The 09-06 log held "live" jobs
		// (e.g. job 7260) that were stuck in a non-terminal state for 12+ hours
		// with no heartbeat; the old code treated ANY non-terminal state as
		// should_continue with no age cap, so the orphan guard dropped ~193
		// genuinely-finished duplicate completions ("owns live job") forever.
		// A non-terminal job is only "live" if it shows recent liveness; if it
		// is stale beyond the threshold it is treated as a failed dead job so the
		// newer real completion gets adopted instead of being dropped.
		$stale_dead = $this->lifecycle_state_is_stale_dead( $job_state, $queue_state, $raw );

		if ( ! $stale_dead && (
			\in_array( $job_state, array( 'pending', 'deferred', 'processing', 'generating', 'validating', 'reserved' ), true ) ||
			\in_array( $queue_state, array( 'pending', 'queued', 'reserved', 'processing' ), true )
		) ) {
			$dto['should_continue'] = true;
			if ( $job_state === 'deferred' && ! empty( $raw['available_at'] ) ) {
				$dto['deferred_until'] = (int) Plugin_Time::utc_ts_from_utc_mysql( (string) $raw['available_at'] );
			}
			return $dto;
		}

		if ( $stale_dead ) {
			$dto['combined_status'] = 'stale_dead';
			$dto['should_fail']     = true;
			$dto['failure_status']  = 'timeout';
			$dto['failure_reason']  = $error !== '' ? $error : 'AI job stuck in a non-terminal state without heartbeat past liveness threshold (zombie).';
			return $dto;
		}

		$dto['should_fail']    = true;
		$dto['failure_status'] = 'failed';
		$dto['failure_reason'] = $error !== '' ? $error : 'Lifecycle contract violation: unrecognized job state.';
		return $dto;
	}

	public function get_job_lifecycle_status( $job_id ) {
		$status = $this->get_job_status( $job_id );

		if ( ! $status ) {
			return $this->normalize_lifecycle_payload(
				array(
					'combined_status' => 'missing',
					'job_status'      => '',
					'queue_status'    => '',
					'error_message'   => 'Generation job not found.',
					'user_id'         => 0,
					'available_at'    => null,
				)
			);
		}

		$job_state   = (string) ( $status['status'] ?? '' );
		$queue_state = (string) ( $status['queue_status'] ?? '' );
		$combined    = $job_state !== '' ? $job_state : ( $queue_state !== '' ? $queue_state : 'unknown' );

		if ( $job_state === 'completed' && $queue_state === 'reserved' ) {
			$combined = 'reconcile_failed';
		}

		return $this->normalize_lifecycle_payload(
			array(
				'combined_status'   => $combined,
				'job_status'        => $job_state,
				'queue_status'      => $queue_state,
				'error_message'     => (string) ( $status['error_message'] ?? '' ),
				'user_id'           => (int) ( $status['user_id'] ?? 0 ),
				'available_at'      => $status['available_at'] ?? null,
				'heartbeat_at'      => $status['heartbeat_at'] ?? null,
				'status_started_at' => $status['status_started_at'] ?? null,
				'created_at'        => $status['created_at'] ?? null,
			)
		);
	}

	/**
	 * Phase 3F (2.34.0): decide whether a non-terminal lifecycle state is in fact
	 * a dead "zombie" (stuck with no liveness past the threshold) rather than a
	 * genuinely running/queued job.
	 *
	 * A long slow generation legitimately sits in 'processing' while heartbeats
	 * keep flowing (heartbeat_job refreshes heartbeat_at), so liveness — not mere
	 * wall-clock age — is the signal. Thresholds:
	 *   - ACTIVE work state (job processing/generating/validating/reserved, or
	 *     queue reserved/processing): dead if the NEWEST of heartbeat_at /
	 *     status_started_at / created_at is older than ZOMBIE_ACTIVE_STALE_SECONDS.
	 *   - PASSIVE wait state (job pending/deferred or a queued ticket that never
	 *     started): dead if older than ZOMBIE_PASSIVE_STALE_SECONDS (mirrors the
	 *     discovery-side 12h starvation backstop so the two agree).
	 *
	 * @param string $job_state
	 * @param string $queue_state
	 * @param array  $raw  Raw status row incl. heartbeat/started/created times.
	 * @return bool
	 */
	private function lifecycle_state_is_stale_dead( $job_state, $queue_state, array $raw ): bool {
		$is_active = \in_array( (string) $job_state, array( 'processing', 'generating', 'validating', 'reserved' ), true )
			|| \in_array( (string) $queue_state, array( 'reserved', 'processing' ), true );
		$is_passive = ! $is_active && (
			\in_array( (string) $job_state, array( 'pending', 'deferred' ), true )
			|| \in_array( (string) $queue_state, array( 'queued', 'pending' ), true )
		);

		if ( ! $is_active && ! $is_passive ) {
			return false; // terminal or unknown — other branches own those.
		}

		$threshold = $is_active ? self::ZOMBIE_ACTIVE_STALE_SECONDS : self::ZOMBIE_PASSIVE_STALE_SECONDS;

		$latest_ts = 0;
		foreach ( array( 'heartbeat_at', 'status_started_at', 'created_at' ) as $col ) {
			if ( ! empty( $raw[ $col ] ) ) {
				$ts = (int) Plugin_Time::utc_ts_from_utc_mysql( (string) $raw[ $col ] );
				if ( $ts > $latest_ts ) {
					$latest_ts = $ts;
				}
			}
		}

		// No datable liveness signal: be conservative, do not kill.
		if ( $latest_ts <= 0 ) {
			return false;
		}

		return ( Plugin_Time::now_utc_ts() - $latest_ts ) > $threshold;
	}

public function get_preview( $job_id ) {
		global $wpdb;
		$job = $wpdb->get_row( $wpdb->prepare(
			'SELECT output_data, validation_results, user_id, debug_data FROM ' . Installer::table_jobs() . 
			' WHERE id = %d',
			(int) $job_id
		), ARRAY_A );
		if ( ! $job ) {
			return null;
		}
		$article = json_decode( $job['output_data'], true );
		$debug = null;
		if ( ! empty( $job['debug_data'] ) ) {
			$debug = json_decode( $job['debug_data'], true );
		}
		return array(
			'article'         => $article,
			'validation'      => json_decode( $job['validation_results'], true ),
			'user_id'         => $job['user_id'],
			'html_content'    => $article['html_content'] ?? '',
			'raw_prompt'      => $debug['raw_prompt'] ?? null,
			'raw_response'    => $debug['raw_response'] ?? null,
			'provider'        => $debug['provider'] ?? null,
			'http_trace'      => $debug['http_trace'] ?? null,
		);
	}

	public function get_regen_sections( $job_id ) {
		global $wpdb;
		$job = $wpdb->get_row( $wpdb->prepare( 'SELECT input_data FROM ' . Installer::table_jobs() . ' WHERE id = %d', (int) $job_id ), ARRAY_A );
		if ( ! $job || empty( $job['input_data'] ) ) {
			return array();
		}

		$decoded = json_decode( $job['input_data'], true );

		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$raw_sections = array();

		if ( isset( $decoded['regen_sections'] ) && is_array( $decoded['regen_sections'] ) ) {
			$raw_sections = $decoded['regen_sections'];
		} elseif ( isset( $decoded['sections'] ) && is_array( $decoded['sections'] ) ) {
			$raw_sections = $decoded['sections'];
		} elseif ( isset( $decoded['section_selection'] ) && is_array( $decoded['section_selection'] ) ) {
			$raw_sections = $decoded['section_selection'];
		}

		return \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $raw_sections, array() );
	}

	public function finalize_generated_post( int $post_id, array $postarr ) {
		global $wp_filter;

		$all_hooks = array();
		if ( isset( $wp_filter['save_post'] ) ) {
			foreach ( $wp_filter['save_post']->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $callback => $data ) {
					$all_hooks[] = array(
						'hook'     => 'save_post',
						'callback' => $callback,
						'priority' => $priority,
					);
				}
			}
		}

		$result = null;
		try {
			remove_action( 'save_post', array( 'SEO_Article_Generator\\Admin\\Hero_Meta_Box', 'save_meta_box' ), 10 );
			\kses_remove_filters();

			// [FIX] Grant unfiltered_html capability temporarily to prevent wp_kses_post()
			// inside wp_insert_post() from stripping JSON attributes from Gutenberg block
			// comments (e.g. <!-- wp:rank-math/toc-block {"headings":[...]} -->).
			$unfiltered_cap_cb = static function ( array $allcaps ): array {
				$allcaps['unfiltered_html'] = true;
				return $allcaps;
			};
			add_filter( 'user_has_cap', $unfiltered_cap_cb );

			if ( class_exists( '\SEO_Article_Generator\Integration\Jetpack_Integration' ) && isset( $postarr['preview']['article']['tags'] ) ) {
				\SEO_Article_Generator\Integration\Jetpack_Integration::$pending_tags = (array) $postarr['preview']['article']['tags'];
			}
			if ( class_exists( '\SEO_Article_Generator\Integration\Buffer_Integration' ) && isset( $postarr['preview']['article']['tags'] ) ) {
				\SEO_Article_Generator\Integration\Buffer_Integration::$pending_tags = (array) $postarr['preview']['article']['tags'];
				// [FIX] Persist the AI-generated SEO tags to post meta so the
				// publish_watchdog path (wp_publish_post) can read them at Buffer
				// share time, since $pending_tags is only populated in this finalize
				// flow and not during watchdog-driven publishes.
				\update_post_meta( $post_id, '_seo_gen_ai_tags', (array) $postarr['preview']['article']['tags'] );
			}

			// [FIX] Strip double-escaped HTML entities (renderer-level corruption).
			// Content from renderers may contain \&quot; wrapping attribute values
			// (e.g. class="\&quot;wp-block-heading\&quot;"). Remove the spurious
			// \&quot; so the HTML is valid. Must run BEFORE wp_slash() so the regex
			// matches the literal \&quot; in raw content (before addslashes doubles the backslash).
			$postarr['post_content'] = preg_replace( '/\\\\&quot;/', '', $postarr['post_content'] );

			// [FIX] WordPress data convention: wp_insert_post() / wp_update_post() expect
			// slashed data because they call wp_unslash() internally (post.php:4888) before
			// writing to the database. Without this, literal \u0026 / \u003c / \u003e
			// sequences produced by serialize_block_attributes() lose their leading
			// backslash (wp_unslash strips it), leaving invalid unicode escapes like
			// u0026 in the DB. Gutenberg then fails to validate these on editor load,
			// triggering "Block contains unexpected or invalid content" recovery.
			$postarr['post_content'] = \wp_slash( $postarr['post_content'] );

			$now_utc_ts  = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
			$update_data = \array_merge(
				array(
					'ID'                => $post_id,
					'post_modified'     => \SEO_Article_Generator\Utils\Plugin_Time::site_mysql_from_utc_ts( $now_utc_ts ),
					'post_modified_gmt' => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_from_utc_ts( $now_utc_ts ),
				),
				$postarr
			);

			if ( $post_id > 0 ) {
				$result = \wp_update_post( $update_data, true );
			} else {
				$result = \wp_insert_post( $postarr, true );
			}

			remove_filter( 'user_has_cap', $unfiltered_cap_cb );
			\kses_init_filters();

			if ( \is_wp_error( $result ) ) {
				throw new \RuntimeException( 'Failed to save post: ' . $result->get_error_message() );
			}

			$new_post_id = (int) $result;

			// [MODIFIED] Share updated posts to Buffer.
			// For $post_id > 0 (update), transition_post_status fires with
			// $old_status === $new_status === 'publish'. Buffer's
			// handle_status_transition now returns early for same-status
			// transitions (matching Jetpack), so we trigger share_post()
			// directly here instead.
			if ( $post_id > 0 && class_exists( '\SEO_Article_Generator\Integration\Buffer_Integration' ) ) {
				$_buf = new \SEO_Article_Generator\Integration\Buffer_Integration( $this->logger );
				$_buf->share_post( $new_post_id );
			}

			foreach ( $all_hooks as $item ) {
				if ( \is_callable( $item['callback'] ) ) {
					\call_user_func( $item['callback'], $new_post_id, \get_post( $new_post_id ) );
				}
			}

			return $new_post_id;
		} finally {
			\add_action( 'save_post', array( 'SEO_Article_Generator\\Admin\\Hero_Meta_Box', 'save_meta_box' ), 10, 2 );
		}
	}

	/**
	 * FIX F2 (2026-09-06): true when a discovery-linked job is still owned by a
	 * live (non-terminal) discovery row referencing exactly this job.
	 *
	 * Ownership rules (evaluated in order):
	 *  1. No discovery_id in input_data → ad-hoc job → owned (never refused).
	 *  2. Discovery row missing → orphan.
	 *  3. Row terminal (done/failed/timeout/ignored/skipped_*) → orphan, even if
	 *     job_id still matches (covers rows that kept a live job_id).
	 *  4. Row job_id matches → owned.
	 *  5. Row job_id is 0/NULL on a NON-terminal row → link pending (Step-A
	 *     window: Step C lands milliseconds later) → owned.
	 *  6. Otherwise the row points at a different job → superseded → orphan.
	 */
	private function is_job_owned_by_live_discovery( int $job_id, array $job ): bool {
		$input = array();
		if ( ! empty( $job['input_data'] ) ) {
			$decoded = json_decode( (string) $job['input_data'], true );
			if ( is_array( $decoded ) ) {
				$input = $decoded;
			}
		}

		$discovery_id = (int) ( $input['discovery_id'] ?? 0 );
		if ( $discovery_id <= 0 ) {
			return true;
		}

		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, status, job_id FROM ' . \SEO_Article_Generator\Installer::table_discovery() . ' WHERE id = %d',
				$discovery_id
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return false;
		}

		$status = (string) ( $row['status'] ?? '' );
		if ( \in_array( $status, array( 'done', 'failed', 'timeout', 'ignored', 'skipped_not_newer', 'skippedduplicate' ), true ) ) {
			return false;
		}

		$ref_job_id = (int) ( $row['job_id'] ?? 0 );
		if ( $ref_job_id === (int) $job_id ) {
			return true;
		}

		if ( $ref_job_id <= 0 ) {
			return true;
		}

		return false;
	}

	/**
	 * Phase 3F (2.34.0): post-level duplicate suppression.
	 *
	 * Returns TRUE when $job_id is the live job that should run AI for its
	 * target. Returns FALSE when an OLDER duplicate must be retired without an
	 * AI call because a NEWER equivalent job already covers the same post, or
	 * the discovery now references a different (newer) job.
	 *
	 * Rules:
	 *  - Ad-hoc/manual jobs (no discovery_id AND no existing_post_id) are never
	 *    suppressed here — they have no post-scoped sibling to dedupe against.
	 *  - Discovery jobs: if the owning discovery row's job_id is a DIFFERENT and
	 *    NEWER job, this one is superseded. (The older is_job_owned_by_live_discovery
	 *    already covers terminal/released rows; this covers "live but newer".)
	 *  - Post-scoped jobs (existing_post_id set, incl. legacy/backlog tickets whose
	 *    discovery_id is 0): scan ALL non-terminal generation jobs for the same
	 *    post. If any newer (higher id) job is live (not failed/cancelled) this
	 *    older one is superseded. Jobs created by this very run are not yet
	 *    visible when the worker claims the newest, so newest-wins is stable.
	 *
	 * @param int   $job_id
	 * @param array $job    Loaded job row (includes input_data).
	 * @return bool
	 */
	private function is_job_latest_for_post( int $job_id, array $job ): bool {
		$input = array();
		if ( ! empty( $job['input_data'] ) ) {
			$decoded = json_decode( (string) $job['input_data'], true );
			if ( is_array( $decoded ) ) {
				$input = $decoded;
			}
		}

		$discovery_id    = (int) ( $input['discovery_id'] ?? 0 );
		$existing_post   = (int) ( $input['existing_post_id'] ?? ( $input['existingpostid'] ?? 0 ) );

		// Ad-hoc manual generation: nothing post-scoped to dedupe against.
		if ( $discovery_id <= 0 && $existing_post <= 0 ) {
			return true;
		}

		global $wpdb;
		$jobs_table = \SEO_Article_Generator\Installer::table_jobs();

		// Terminal/retired statuses that never count as a covering "live" job.
		$dead = array( 'completed', 'failed', 'cancelled', 'superseded', 'reconcile_failed' );
		$dead_in = "'" . implode( "','", array_map( 'esc_sql', $dead ) ) . "'";

		// Rule A — discovery-owned: discovery row's current job wins.
		if ( $discovery_id > 0 ) {
			$ref_job_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT job_id FROM ' . \SEO_Article_Generator\Installer::table_discovery() . ' WHERE id = %d',
					$discovery_id
				)
			);
			// A different, newer job is referenced => this older ticket is stale.
			if ( $ref_job_id > 0 && $ref_job_id !== $job_id && $ref_job_id > $job_id ) {
				return false;
			}
		}

		// Rule B — post-scoped: any newer non-terminal job for the same post wins.
		if ( $existing_post > 0 ) {
			// Match against the JSON payload via existing_post_id or legacy
			// existingpostid key. JSON_EXTRACT keeps this index-safe enough for
			// the backlog sweep; candidate set is pre-filtered by status + id.
			$newer_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT MIN(j.id) FROM {$jobs_table} j
					 WHERE j.id > %d
					   AND j.status NOT IN ({$dead_in})
					   AND (
					     JSON_UNQUOTE(JSON_EXTRACT(j.input_data, '$.existing_post_id')) = %s
					     OR JSON_UNQUOTE(JSON_EXTRACT(j.input_data, '$.existingpostid')) = %s
					   )
					 LIMIT 1",
					$job_id,
					(string) $existing_post,
					(string) $existing_post
				)
			);
			if ( $newer_id > 0 ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Retire a superseded/duplicate job WITHOUT an AI call.
	 *
	 * Marks the generation job terminal ('failed' with a non-retryable abort
	 * signature) and retires its queue ticket as completed/superseded so it is
	 * never re-released by reserve(). The error signature resolves to 'abort'
	 * in Discovery_Processor::get_recovery_strategy() (registered alongside
	 * full_render_ai_omitted_sections), so rescan/auto-gen never resurrect it.
	 *
	 * @param int      $job_id
	 * @param string   $reason
	 * @param string[] $from_states
	 * @param int|null $queue_job_id
	 * @param string|null $reservation_token
	 */
	private function retire_superseded_job( int $job_id, string $reason, array $from_states, $queue_job_id = null, $reservation_token = null ): void {
		global $wpdb;

		$now = Plugin_Time::utc_mysql_now();
		$signature = 'superseded_duplicate_no_ai_burn';
		$message   = $signature . ': ' . $reason;

		$sql_states = "'" . implode( "','", array_map( 'esc_sql', $from_states ) ) . "'";

		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . \SEO_Article_Generator\Installer::table_jobs() . "
				 SET status = 'failed',
				     error_message = %s,
				     heartbeat_at = NULL,
				     status_started_at = NULL,
				     completed_at = %s
				 WHERE id = %d
				   AND status IN ({$sql_states})",
				$message,
				$now,
				(int) $job_id
			)
		);

		if ( $queue_job_id ) {
			$repo = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$repo->mark_superseded(
				(int) $queue_job_id,
				$reservation_token ? (string) $reservation_token : '',
				'superseded duplicate for job ' . (int) $job_id
			);
		}
	}

	private function load_job_for_execution( $job_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, user_id, status, queue_job_id, input_data, retry_count, available_at
                 FROM ' . Installer::table_jobs() . '
                 WHERE id = %d',
				(int) $job_id
			),
			ARRAY_A
		);
	}

	private function transition_job_status( $job_id, $from, $to ) {
		global $wpdb;
		$now = Plugin_Time::utc_mysql_now();
		return 1 === (int) $wpdb->update(
			Installer::table_jobs(),
			array(
				'status'            => $to,
				'status_started_at' => $now,
				'heartbeat_at'      => $now,
			),
			array(
				'id'     => (int) $job_id,
				'status' => $from,
			),
			array( '%s', '%s', '%s' ),
			array( '%d', '%s' )
		);
	}

	private function acquire_lease( $lock, $owner, $dur ) {
		global $wpdb;
		$table   = Installer::table_locks();
		$now     = Plugin_Time::utc_mysql_now();
		$expires = Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + $dur );
		$wpdb->query( $wpdb->prepare( "INSERT INTO $table (lock_name, owner_key, lease_expires_at, heartbeat_at, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE owner_key = IF(lease_expires_at < %s, VALUES(owner_key), owner_key), lease_expires_at = IF(lease_expires_at < %s, VALUES(lease_expires_at), lease_expires_at)", $lock, $owner, $expires, $now, $now, $now, $now, $now ) );
		return $wpdb->get_var( $wpdb->prepare( "SELECT owner_key FROM $table WHERE lock_name = %s", $lock ) ) === $owner;
	}

	private function release_lease( $lock, $owner ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . Installer::table_locks() . ' WHERE lock_name = %s AND owner_key = %s', $lock, $owner ) );
	}

	private function fail_job( $job_id, $reason, array $from_states = array( 'processing' ), $queue_job_id = null, $reservation_token = null ) {
		global $wpdb;

		$sql_states = "'" . implode( "','", array_map( 'esc_sql', $from_states ) ) . "'";
		$now        = Plugin_Time::utc_mysql_now();

		$ok = 1 === (int) $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . Installer::table_jobs() . "
                 SET status = 'failed',
                     error_message = %s,
                     heartbeat_at = NULL,
                     status_started_at = NULL,
                     completed_at = %s
                 WHERE id = %d
                   AND status IN ({$sql_states})",
				(string) $reason,
				$now,
				(int) $job_id
			)
		);

		if ( ! $ok ) {
			return false;
		}

		if ( $queue_job_id && $reservation_token ) {
			$repo     = new \SEO_Article_Generator\Queue\Job_Repository( $wpdb );
			$queue_ok = $repo->mark_terminal_failed( $queue_job_id, $reservation_token, $reason );

			if ( ! $queue_ok ) {
				$wpdb->update(
					Installer::table_jobs(),
					array(
						'status'        => 'reconcile_failed',
						'error_message' => 'Queue terminal CAS refused after fail_job transition: ' . (string) $reason,
						'completed_at'  => Plugin_Time::utc_mysql_now(),
					),
					array(
						'id'     => (int) $job_id,
						'status' => 'failed',
					),
					array( '%s', '%s', '%s' ),
					array( '%d', '%s' )
				);
				return false;
			}
		}

		$user_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT user_id FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				(int) $job_id
			)
		);

		\do_action( 'seo_gen_job_finished', (int) $job_id, 'failed', $user_id );

		return true;
	}

	public function force_cancel_job( int $job_id, string $reason ): bool {
		global $wpdb;

		$job = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, status, queue_job_id
                 FROM ' . Installer::table_jobs() . '
                 WHERE id = %d',
				$job_id
			),
			ARRAY_A
		);

		if ( ! $job ) {
			return true;
		}

		$queue_job_id      = ! empty( $job['queue_job_id'] ) ? (int) $job['queue_job_id'] : null;
		$reservation_token = null;

		if ( $queue_job_id ) {
			$reservation_token = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT reservation_token
                     FROM ' . Installer::table_queue() . "
                     WHERE id = %d AND status = 'reserved'",
					$queue_job_id
				)
			);
		}

		return $this->fail_job(
			$job_id,
			$reason,
			array( 'pending', 'deferred', 'processing', 'generating', 'validating' ),
			$queue_job_id ?: null,
			$reservation_token ?: null
		);
	}

	private function is_job_cancelled( int $job_id ): bool {
		global $wpdb;

		$status = (string) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT status FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				$job_id
			)
		);

		return in_array( $status, array( 'failed', 'timed_out', 'timeout', 'reconcile_failed', 'completed', self::STATUS_FAILED_VALIDATION ), true );
	}

	private function assert_job_not_cancelled( int $job_id ): void {
		if ( $this->is_job_cancelled( $job_id ) ) {
			throw new \RuntimeException( 'Job cancelled by operator.' );
		}
	}

	private function is_operator_terminal_failure( string $status, string $error_message ): bool {
		if ( $status !== 'failed' ) {
			return false;
		}

		return (
			strpos( $error_message, 'Job force-reset via dashboard queue cleared.' ) !== false
			|| strpos( $error_message, 'Killed manually from discovery dashboard.' ) !== false
		);
	}

	public function reconcile_job_timeout( $job_id ) {
		global $wpdb;

		$job = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT status, heartbeat_at, status_started_at, available_at, queue_job_id
                 FROM ' . Installer::table_jobs() . '
                 WHERE id = %d',
				(int) $job_id
			),
			ARRAY_A
		);

		if ( $job && \in_array( $job['status'], array( 'processing', 'generating', 'validating' ), true ) ) {
			$last_active = $job['heartbeat_at'] ?: ( $job['status_started_at'] ?: $job['available_at'] );

			if ( $last_active && ( Plugin_Time::now_utc_ts() - Plugin_Time::utc_ts_from_utc_mysql( $last_active ) ) > self::RECONCILE_TIMEOUT_SECONDS ) {
				$has_lease = (bool) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT COUNT(*) FROM ' . Installer::table_locks() . '
                     WHERE lock_name = %s
                       AND lease_expires_at > %s',
						$this->get_job_lock_name( (int) $job_id ),
						Plugin_Time::utc_mysql_now()
					)
				);

				if ( ! $has_lease ) {
					$queue_job_id      = (int) ( $job['queue_job_id'] ?? 0 );
					$reservation_token = null;
					if ( $queue_job_id > 0 ) {
						$reservation_token = $wpdb->get_var(
							$wpdb->prepare(
								'SELECT reservation_token FROM ' . Installer::table_queue() .
								" WHERE id = %d AND status = 'reserved'",
								$queue_job_id
							)
						);
					}
					$this->fail_job(
						$job_id,
						'Timeout (heartbeat aged out, no active lease)',
						array( $job['status'] ),
						$queue_job_id ?: null,
						$reservation_token ?: null
					);
				}
			}
		}
	}

	public function cleanup_stale_jobs() {
		global $wpdb;

		$cutoff = Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() - self::STALE_HEARTBEAT_SECONDS );
		$stale  = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, queue_job_id
                 FROM ' . Installer::table_jobs() . "
                 WHERE status IN ('processing', 'generating', 'validating')
                   AND heartbeat_at < %s",
				$cutoff
			),
			ARRAY_A
		);

		foreach ( $stale as $job ) {
			$has_lease = (bool) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . Installer::table_locks() . '
                 WHERE lock_name = %s
                   AND lease_expires_at > %s',
					$this->get_job_lock_name( (int) $job['id'] ),
					Plugin_Time::utc_mysql_now()
				)
			);

			if ( $has_lease ) {
				continue;
			}

			$queue_job_id      = (int) ( $job['queue_job_id'] ?? 0 );
			$reservation_token = null;
			if ( $queue_job_id > 0 ) {
				$reservation_token = $wpdb->get_var(
					$wpdb->prepare(
						'SELECT reservation_token FROM ' . Installer::table_queue() .
						" WHERE id = %d AND status = 'reserved'",
						$queue_job_id
					)
				);
			}

			$this->fail_job(
				(int) $job['id'],
				'Stale (heartbeat timeout & lease expired)',
				array( 'processing', 'generating', 'validating' ),
				$queue_job_id ?: null,
				$reservation_token ?: null
			);
		}
	}

	/**
	 * Clear expired runtime locks.
	 *
	 * @return int Number of locks cleared.
	 */
	public function clear_stale_locks() {
		global $wpdb;

		$now = Plugin_Time::utc_mysql_now();

		return (int) $wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . Installer::table_locks() . '
                 WHERE lease_expires_at < %s',
				$now
			)
		);
	}

	/**
	 * Delete terminal generation jobs older than N days.
	 *
	 * @param int $days Number of days to keep.
	 * @return int Number of jobs deleted.
	 */
	public function revive_cooldown_jobs(): void {
		global $wpdb;

		$jobs_table      = Installer::table_jobs();
		$queue_table     = Installer::table_queue();
		$discovery_table = Installer::table_discovery();
		$now_utc         = Plugin_Time::utc_mysql_now();

		$bootstrap                     = $this->resolve_generation_bootstrap();
		$providers_temporarily_blocked = empty( $bootstrap['ok'] ) && ! empty( $bootstrap['temporary'] );

		// ── AUTO-REQUEUE: Revive failed discovery items whose errors are transient ──
		// Only runs when providers are NOT temporarily blocked.
		if ( ! $providers_temporarily_blocked ) {
			$auto_requeueable_patterns = array(
				'%quota%',
				'%Rate Limit%',
				'%rate limit%',
				'%cooldown%',
				'%system busy%',
				'%pipeline paused%',
				'%Daily API quota%',
				'%Provider Overloaded%',
				'%Admission Gate busy%',
				'%temporary%',
				'%Quota%',
			);
			$like_clauses              = array();
			foreach ( $auto_requeueable_patterns as $pattern ) {
				$like_clauses[] = $wpdb->prepare( 'error_message LIKE %s', $pattern );
			}
			$like_sql = implode( ' OR ', $like_clauses );

			$failed_items = $wpdb->get_results(
				"SELECT id, error_message FROM {$discovery_table}
				WHERE status IN ('failed', 'timeout')
				AND ({$like_sql})
				ORDER BY completed_at ASC
				LIMIT 50",
				ARRAY_A
			);

			if ( ! empty( $failed_items ) ) {
				$defaults    = \SEO_Article_Generator\Option_Registry::defaults();
				$min_minutes = max(
					1,
					(int) \get_option(
						\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN,
						$defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ]
					)
				);
				$max_minutes = max(
					$min_minutes,
					(int) \get_option(
						\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX,
						$defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ]
					)
				);

				$processor = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance()->get_processor();
				$uid       = (int) ( $wpdb->get_var( "SELECT user_id FROM {$discovery_table} WHERE status IN ('failed','timeout') LIMIT 1" ) ?: 1 );
				$slot      = 0;

				foreach ( $failed_items as $item ) {
					$discovery_id = (int) $item['id'];
					$gap_seconds  = rand( $min_minutes * 60, $max_minutes * 60 );
					$jitter       = rand( 5, 15 );
					$delay        = 1 + ( $slot * ( $gap_seconds + $jitter ) );

					if ( $processor && method_exists( $processor, 'retry_item' ) ) {
						$processor->retry_item( $discovery_id, $uid, $delay );
						++$slot;
					}
				}

				if ( $slot > 0 ) {
					$this->logger->info(
						sprintf(
							'revive_cooldown_jobs: Auto-requeued %d transiently-failed discovery items with staggered timing (%d-%d min apart).',
							$slot,
							$min_minutes,
							$max_minutes
						)
					);
				}
			}
		}

		// Check bootstrap state before reviving to prevent churn against still-blocked provider
		if ( $providers_temporarily_blocked ) {
			$delay           = max( 60, (int) ( $bootstrap['retry_after'] ?? 60 ) );
			$resume_at_mysql = Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + $delay );

			$deferred_jobs = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, queue_job_id FROM {$jobs_table}
                    WHERE status = %s
                    AND (
                        error_message IS NULL
                        OR error_message LIKE %s
                        OR error_message LIKE %s
                        OR error_message LIKE %s
                        OR error_message LIKE %s
                        OR error_message LIKE %s
                    )",
					'deferred',
					'%quota%',
					'%cooldown%',
					'%rate limit%',
					'%system busy%',
					'%pipeline paused%'
				),
				ARRAY_A
			);

			if ( ! empty( $deferred_jobs ) ) {
				$job_ids       = array_column( $deferred_jobs, 'id' );
				$queue_job_ids = array_filter( array_column( $deferred_jobs, 'queue_job_id' ) );

				// Get clumping protection settings from Options
				$defaults    = \SEO_Article_Generator\Option_Registry::defaults();
				$min_minutes = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
				$max_minutes = max( $min_minutes, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );

				// Stagger each job's available_at timestamp even when deferring
				$now_ts    = Plugin_Time::now_utc_ts();
				$resume_ts = Plugin_Time::now_utc_ts() + $delay;
				$job_index = 0;
				foreach ( $deferred_jobs as $job ) {
					// Fix #4: Skip jobs that already have a future available_at (prevent double-staggering)
					$existing_ts = Plugin_Time::utc_ts_from_utc_mysql( $job['available_at'] ?? '' );
					if ( $existing_ts > $now_ts ) {
						++$job_index;
						continue; // already staggered from a prior call — skip
					}

					// Random gap between min/max interval (in seconds)
					$gap_seconds = rand( $min_minutes * 60, $max_minutes * 60 );
					// FINDING 4 FIX: Increase sub-jitter to 5-15s to prevent 60-second window clustering
					$jitter_seconds = rand( 5, 15 );
					// Enforce minimum gap: (min_minutes * 60) + 15 seconds between jobs
					$effective_gap = max( $gap_seconds + $jitter_seconds, ( $min_minutes * 60 ) + 15 );
					// Calculate staggered timestamp from resume time
					$staggered_ts    = $resume_ts + ( $job_index * $effective_gap );
					$staggered_mysql = Plugin_Time::utc_mysql_from_utc_ts( $staggered_ts );

					// Update job with staggered available_at
					$wpdb->update(
						$jobs_table,
						array(
							'status'       => 'deferred',
							'available_at' => $staggered_mysql,
							'retry_count'  => null,
						),
						array( 'id' => $job['id'] ),
						array( '%s', '%s', '%s' ),
						array( '%d' )
					);

					// Update queue ticket if exists
					if ( ! empty( $job['queue_job_id'] ) ) {
								$wpdb->update(
									$queue_table,
									array(
										'status'           => 'deferred',
										'available_at'     => $staggered_mysql,
										'reservation_token' => null,
										'lease_expires_at' => null,
									),
									array( 'id' => $job['queue_job_id'] ),
									array( '%s', '%s', '%s', '%s' ),
									array( '%d' )
								);
					}

					++$job_index;
				}

				$this->logger->info(
					sprintf(
						'revive_cooldown_jobs: Provider still temporarily blocked. Deferred %d jobs with staggered timing until %s (interval: %d-%d min).',
						$job_index,
						$resume_at_mysql,
						$min_minutes,
						$max_minutes
					)
				);
			}
			return;
		}

		$deferred_jobs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, queue_job_id FROM {$jobs_table}
                 WHERE status = %s
                   AND (
                       error_message IS NULL
                       OR error_message LIKE %s
                       OR error_message LIKE %s
                       OR error_message LIKE %s
                       OR error_message LIKE %s
                       OR error_message LIKE %s
                   )",
				'deferred',
				'%quota%',
				'%cooldown%',
				'%rate limit%',
				'%system busy%',
				'%pipeline paused%'
			),
			ARRAY_A
		);

		if ( empty( $deferred_jobs ) ) {
			$this->logger->info( 'revive_cooldown_jobs: No quota-blocked deferred jobs found.' );
			return;
		}

		$job_ids       = array_column( $deferred_jobs, 'id' );
		$queue_job_ids = array_filter( array_column( $deferred_jobs, 'queue_job_id' ) );

		// Get clumping protection settings from Options
		$defaults    = \SEO_Article_Generator\Option_Registry::defaults();
		$min_minutes = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
		$max_minutes = max( $min_minutes, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );

		// Stagger each job's available_at timestamp to prevent API rush
		$now_ts    = Plugin_Time::now_utc_ts();
		$job_index = 0;
		foreach ( $deferred_jobs as $job ) {
			// FINDING 4 GUARD: Skip jobs already staggered with a future available_at
			// to prevent double-staggering on repeated revive calls.
			$existing_avail = $job['available_at'] ?? '';
			if ( ! empty( $existing_avail ) ) {
				$existing_ts = Plugin_Time::utc_ts_from_utc_mysql( $existing_avail );
				if ( $existing_ts > $now_ts + 30 ) {
					// Already has a future slot — leave it, just increment index for spacing.
					++$job_index;
					continue;
				}
			}

			// Random gap between min/max interval (in seconds)
			$gap_seconds = rand( $min_minutes * 60, $max_minutes * 60 );
			// FINDING 4 FIX: Increase sub-jitter to 5-15s to prevent 60-second window clustering
			$jitter_seconds = rand( 5, 15 );
			// Enforce minimum gap: (min_minutes * 60) + 15 seconds between jobs
			$effective_gap = max( $gap_seconds + $jitter_seconds, ( $min_minutes * 60 ) + 15 );
			// Calculate staggered timestamp: start at index 1, not 0, to ensure first job has base delay
			$staggered_ts    = $now_ts + ( ( $job_index + 1 ) * $effective_gap );
			$staggered_mysql = Plugin_Time::utc_mysql_from_utc_ts( $staggered_ts );

			// Update job with staggered available_at
			$wpdb->update(
				$jobs_table,
				array(
					'status'            => 'pending',
					'available_at'      => $staggered_mysql,
					'heartbeat_at'      => null,
					'status_started_at' => null,
					'error_message'     => null,
					'completed_at'      => null,
				),
				array( 'id' => $job['id'] ),
				array( '%s', '%s', '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);

			// Update queue ticket if exists
			if ( ! empty( $job['queue_job_id'] ) ) {
				$wpdb->update(
					$queue_table,
					array(
						'status'            => 'queued',
						'available_at'      => $staggered_mysql,
						'attempts'          => 0,
						'reservation_token' => null,
						'lease_expires_at'  => null,
					),
					array( 'id' => $job['queue_job_id'] ),
					array( '%s', '%s', '%d', '%s', '%s' ),
					array( '%d' )
				);
			}

			++$job_index;
		}

		$this->logger->info(
			sprintf(
				'revive_cooldown_jobs: Revived %d deferred jobs with STAGGERED timing to prevent API rush. Each job scheduled %d-%d min apart. (%d queue tickets reset)',
				$job_index,
				$min_minutes,
				$max_minutes,
				$job_index
			)
		);
	}

	/**
	 * Clean up old completed/failed jobs.
	 *
	 * @param int $days Number of days to keep
	 * @return int Number of jobs cleaned
	 */
/**
	 * Delete a completed job immediately after successful finalization.
	 * The AI output is no longer needed once the post has been written.
	 *
	 * @param int $job_id Job ID to delete.
	 * @return bool True if deleted, false if not found.
	 */
	public function delete_job( $job_id ) {
		global $wpdb;

		return (bool) $wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . Installer::table_jobs() . ' WHERE id = %d',
				(int) $job_id
			)
		);
	}

	public function clean_old_jobs( $days = 30 ) {
		global $wpdb;

		$cutoff = Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() - ( (int) $days * DAY_IN_SECONDS ) );

		return (int) $wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . Installer::table_jobs() . '
                 WHERE status IN (%s, %s, %s, %s)
                   AND completed_at IS NOT NULL
                   AND completed_at < %s',
				'completed',
				'failed',
				self::STATUS_FAILED_VALIDATION,
				'reconcile_failed',
				$cutoff
			)
		);
	}
}
