<?php

/**
 * Google Autocomplete Source
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Integrations\Trends;

use DIT\TrendStudio\Source_Exception;
use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Google Autocomplete Provider (Trends)
 * Used to discover real-time search trends and user intent.
 */
class GoogleTrendsAPI
{
    /**
     * Base URL for the autocomplete service
     */
    const BASE_URL = 'https://suggestqueries.google.com/complete/search';

    /**
     * Get suggestions for a specific term
     *
     * @param string $term The seed term (e.g., "fashion")
     * @param string $context Context for expansion (general, buying, trend, question)
     * @param string $gl Geo-location code (default 'US')
     * @param string $hl Language code (default 'en')
     * @return array List of suggestion strings
     */
    public function get_suggestions(string $term, string $context = 'general', string $gl = 'US', string $hl = 'en'): array
    {
        $variations = $this->get_search_variations($term, $context);
        $all_suggestions = [];

        foreach ($variations as $query) {
            $suggestions = $this->fetch_from_api($query, $gl, $hl);
            $all_suggestions = array_merge($all_suggestions, $suggestions);
        }

        // De-duplicate and filter
        $all_suggestions = array_unique($all_suggestions);

        // Remove the seed term itself if present
        $all_suggestions = array_filter($all_suggestions, function ($s) use ($term) {
            return strtolower($s) !== strtolower($term);
        });

        // Limit to reasonable amount (top 50)
        return array_slice($all_suggestions, 0, 50);
    }

    /**
     * Generate search variations based on context to get deeper results
     *
     * @param string $term
     * @param string $context
     * @return array
     */
    private function get_search_variations(string $term, string $context): array
    {
        $current_year = date('Y');
        $next_year = date('Y', strtotime('+1 year'));

        $variations = [$term]; // Always include exact match

        switch ($context) {
            case 'buying':
                $variations[] = "best $term";
                $variations[] = "$term reviews";
                $variations[] = "$term price";
                $variations[] = "$term vs";
                break;
            case 'trend':
                $variations[] = "$term trends";
                $variations[] = "$term $current_year";
                $variations[] = "$term $next_year"; // Forward looking
                $variations[] = "new $term";
                break;
            case 'question':
                $variations[] = "how to $term";
                $variations[] = "what is $term";
                $variations[] = "$term ideas";
                $variations[] = "why $term";
                break;
            // @MODIFIED 2026-01-16 - Blue Ocean filter for low-competition keywords
            case 'rankable':
                $variations[] = "$term alternatives";
                $variations[] = "problems with $term";
                $variations[] = "is $term worth it";
                $variations[] = "$term for beginners";
                $variations[] = "$term mistakes";
                $variations[] = "cheap $term";
                $variations[] = "$term diy";
                break;
            case 'general':
            default:
                $variations[] = "$term a"; // Force alphabetical expansion
                $variations[] = "$term for";
                break;
        }

        return $variations;
    }

    /**
     * Perform the actual API request
     *
     * @param string $query
     * @param string $gl
     * @param string $hl
     * @return array
     */
    private function fetch_from_api(string $query, string $gl, string $hl): array
    {
        $url = add_query_arg([
            'client' => 'firefox', // Returns JSON structure
            'q' => $query,
            'gl' => $gl,
            'hl' => $hl,
        ], self::BASE_URL);

        $response = wp_remote_get($url, [
            'timeout' => 5,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        ]);

        if (is_wp_error($response)) {
            return []; // Fail silently for individual requests
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // Firefox client returns format: [query, [suggestion1, suggestion2, ...]]
        if (!is_array($data) || empty($data[1])) {
            return [];
        }

        return $data[1];
    }
}
