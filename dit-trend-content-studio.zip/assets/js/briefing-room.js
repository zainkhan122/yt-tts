(function ($) {
  // Tab Handling
  $(".nav-tab-wrapper a").on("click", function (e) {
    e.preventDefault();
    $(".nav-tab").removeClass("nav-tab-active");
    $(this).addClass("nav-tab-active");
    $(".dit-ts-tab-content").hide();
    $($(this).attr("href")).show();
  });

  const frame = wp.media({
    title: DitTsBriefing.selectMediaTitle || "Select Media",
    button: { text: DitTsBriefing.selectButtonText || "Use Selected Media" },
    multiple: true,
  });

  $("#dit-ts-select-media").on("click", function (e) {
    e.preventDefault();
    frame.open();
  });

  frame.on("select", function () {
    const selection = frame.state().get("selection");
    const ids = [];
    const previews = [];
    selection.each(function (attachment) {
      ids.push(attachment.id);
      // @MODIFIED 2025-12-18 - Safe access for thumbnail with fallback
      const thumbUrl =
        (attachment.sizes && attachment.sizes.thumbnail && attachment.sizes.thumbnail.url) ||
        (attachment.sizes && attachment.sizes.full && attachment.sizes.full.url) ||
        attachment.url ||
        "";
      if (thumbUrl) {
        previews.push(
          '<img src="' +
          thumbUrl +
          '" alt="' +
          (attachment.alt || "") +
          '" style="max-width:100px; margin:2px;"/>'
        );
      }
    });
    $("#dit_ts_media_ids").val(ids.join(","));
    $("#dit-ts-selected-media").html(previews.join(""));
  });



  // AJAX form submission
  // AJAX form submission REPLACED with Direct Transfer
  $("#dit-ts-briefing-form").on("submit", function (e) {
    e.preventDefault();
    const $form = $(this);
    const $btn = $form.find('input[type="submit"]');

    $btn.prop("disabled", true).val("Transferring to Generator...");

    // Collect all data
    const formData = {};
    $form.find("input, select, textarea").each(function () {
      const name = $(this).attr("name");
      if (name) {
        // Checkboxes logic
        if ($(this).attr('type') === 'checkbox') {
          if (name.includes('[]')) {
            if ($(this).is(':checked')) {
              if (!formData[name]) formData[name] = [];
              formData[name].push($(this).val());
            }
          } else {
            formData[name] = $(this).is(':checked');
          }
        } else if ($(this).attr('type') === 'radio') {
          if ($(this).is(':checked')) {
            formData[name] = $(this).val();
          }
        } else {
          formData[name] = $(this).val();
        }
      }
    });

    // Save to SessionStorage
    sessionStorage.setItem('dit_ts_brief_draft', JSON.stringify(formData));

    // Redirect to Generator Page (Manual View)
    // admin.php?page=dit-trend-studio
    // We can find this base URL from existing localized vars or construct it
    const jobsUrl = DitTsBriefing.jobsUrl; // usually admin.php?page=dit-ts-jobs
    const generatorUrl = jobsUrl.replace('dit-ts-jobs', 'dit-trend-studio');

    window.location.href = generatorUrl;
  });

  // --- Gap Analysis Logic ---

  $("#dit-ts-analyze-btn").on("click", function (e) {
    e.preventDefault();
    const $btn = $(this);
    const $spinner = $("#dit-ts-analyze-spinner");
    const $result = $("#dit-ts-strategy-result");
    const $content = $("#dit-ts-strategy-content");

    const url = $("#dit_ts_gap_source").val();
    const text = $("#dit_ts_gap_content").val();
    // @MODIFIED 2026-01-14 - Get analysis mode
    const mode = $("input[name='dit_ts_strategy_mode']:checked").val();

    if (!url && !text) {
      alert("Please provide a URL or paste text.");
      return;
    }

    $btn.prop("disabled", true);
    $spinner.addClass("is-active");
    $result.hide();

    $.post(DitTsBriefing.ajaxUrl, {
      action: 'dit_ts_analyze_gap',
      nonce: DitTsBriefing.nonce,
      url: url,
      text: text,
      mode: mode
    }, function (response) {
      if (response.success) {
        const strategy = response.data;
        let html = '<table class="widefat striped">';
        html += '<tr><th>Topic</th><td>' + strategy.topic + '</td></tr>';
        html += '<tr><th>Weaknesses & Strategy</th><td><pre style="white-space:pre-wrap;">' + strategy.notes + '</pre></td></tr>';
        html += '<tr><th>Unique Angle</th><td>' + strategy.unique_angle + '</td></tr>';
        html += '<tr><th>Recommended Angle</th><td>' + strategy.editorial_angle.toUpperCase() + '</td></tr>';
        html += '</table>';

        // Debug Controls
        html += '<div style="margin-top: 15px; display: flex; gap: 10px;">';
        if (strategy.raw_request) {
          html += '<button type="button" class="button dit-ts-copy-debug" data-type="request">Copy Raw Request</button>';
        }
        if (strategy.raw_response) {
          html += '<button type="button" class="button dit-ts-copy-debug" data-type="response">Copy Raw Response</button>';
        }
        html += '</div>';

        // Store strategy data on the button for easy access
        $("#dit-ts-use-strategy-btn").data("strategy", strategy);

        // Store raw debug data on container for the copy buttons
        $content.data("debug", {
          request: strategy.raw_request,
          response: strategy.raw_response
        });

        $content.html(html);
        $result.slideDown();
      } else {
        alert("Analysis Failed: " + response.data);
      }
    }).fail(function () {
      alert("Server Error during analysis.");
    }).always(function () {
      $btn.prop("disabled", false);
      $spinner.removeClass("is-active");
    });
  });

  // Debug Copy Handlers
  $(document).on("click", ".dit-ts-copy-debug", function (e) {
    e.preventDefault();
    const type = $(this).data("type");
    const debugData = $("#dit-ts-strategy-content").data("debug");
    const content = debugData[type];

    if (!content) return;

    // Copy to clipboard
    const $temp = $("<textarea>");
    $("body").append($temp);
    $temp.val(typeof content === 'string' ? content : JSON.stringify(content, null, 2)).select();
    document.execCommand("copy");
    $temp.remove();

    const originalText = $(this).text();
    $(this).text("Copied!");
    setTimeout(() => $(this).text(originalText), 2000);
  });

  // Smart Mapping Logic
  $("#dit-ts-use-strategy-btn").on("click", function (e) {
    e.preventDefault();
    const strategy = $(this).data("strategy");

    if (!strategy) return;

    // Populate Form Fields
    $("#dit_ts_topic").val(strategy.topic);
    $("#dit_ts_unique_angle").val(strategy.unique_angle);
    $("#dit_ts_focus_keyword").val(strategy.focus_keyword);
    $("#dit_ts_notes").val(strategy.notes);

    // Select Dropdowns
    $("#dit_ts_editorial_angle").val(strategy.editorial_angle);
    $("#dit_ts_search_intent").val(strategy.search_intent);
    $("#dit_ts_article_structure").val(strategy.article_structure);

    // Switch Tab
    $(".nav-tab-wrapper a[href='#tab-standard']").click();

    // Scroll to top
    $("html, body").animate({ scrollTop: 0 }, "slow");

    // Flash effect to indicate population
    $("#dit-ts-briefing-form").css("background-color", "#f0f6fc").animate({ backgroundColor: "#fff" }, 1000);
  });

})(jQuery);
