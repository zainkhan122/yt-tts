<?php

/**
 * Main Plugin Class
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator;

use function add_action;
use function add_filter;
use function is_admin;
use function current_user_can;
use function wp_send_json_success;
use function wp_send_json_error;
use function get_current_user_id;
use function check_ajax_referer;
use function wp_remote_post;
use function wp_remote_retrieve_body;
use function wp_remote_retrieve_response_code;
use function wp_json_encode;
use function is_wp_error;
use function update_post_meta;
use function get_post_meta;
use SEO_Article_Generator\Discovery\Post_Type_Classifier;

// Prevent direct access
if (!defined('ABSPATH')) {
	exit;
}

// Bootstrap Phase 1, 2 & 3 content classes
if (defined('SEO_GEN_PLUGIN_DIR')) {
	// Phase 0 — Option Registry (single source of truth for all wp_options keys)
	require_once SEO_GEN_PLUGIN_DIR . 'includes/class-option-registry.php';
	// Error handler + the exception classes it defines (AI_Exception,
	// Validation_Exception, Database_Exception, File_Upload_Exception). These
	// live in class-error-handler.php, a filename the spl_autoloader cannot map
	// to the exception FQCNs (it looks for class-ai-exception.php etc.), so they
	// only existed once Error_Handler itself autoloaded. Hard-load here so they
	// are available in every context (cron/queue/overdue-recovery), matching the
	// other core requires. file_exists-guarded for graceful partial deploys.
	if (file_exists(SEO_GEN_PLUGIN_DIR . 'includes/class-error-handler.php')) {
		require_once SEO_GEN_PLUGIN_DIR . 'includes/class-error-handler.php';
	}
	// Phase 1 — classification hardening and deterministic update building
	require_once SEO_GEN_PLUGIN_DIR . 'includes/discovery/class-post-type-classifier.php';
	require_once SEO_GEN_PLUGIN_DIR . 'includes/discovery/class-deterministic-update-builder.php';
	// Phase 2 — content normalizer and section renderer
	require_once SEO_GEN_PLUGIN_DIR . 'includes/content/class-content-normalizer.php';
	require_once SEO_GEN_PLUGIN_DIR . 'includes/content/class-deterministic-section-renderer.php';
	// Phase 3 — AI fallback and schema validator
	require_once SEO_GEN_PLUGIN_DIR . 'includes/ai/class-ai-task-schema-validator.php';
	require_once SEO_GEN_PLUGIN_DIR . 'includes/ai/class-provider-fallback-manager.php';
	// Phase 4 — Unified Publishing
	require_once SEO_GEN_PLUGIN_DIR . 'includes/publishing/class-publish-payload-builder.php';
	// Version SSOT + title analysis (used by Discovery Engine/Processor and the
	// generator). Hard-loaded here rather than relying solely on the spl_autoloader:
	// production incident 2026-09-06 (Overdue Recovery) fatalled with "Class
	// SEO_Article_Generator\Utils\SeoGen_Version_Resolver not found" because these
	// files were only ever autoloaded. Guarded so a missing file degrades gracefully.
	$resolver_file = SEO_GEN_PLUGIN_DIR . 'includes/utils/class-seo-gen-version-resolver.php';
	if (file_exists($resolver_file)) {
		require_once $resolver_file;
	}
	$title_analyzer_file = SEO_GEN_PLUGIN_DIR . 'includes/discovery/class-title-analyzer.php';
	if (file_exists($title_analyzer_file)) {
		require_once $title_analyzer_file;
	}
}

/**
 * Main plugin controller class
 * Coordinates all plugin components using singleton pattern
 */
class Plugin
{

	/**
	 * Single instance of the class
	 *
	 * @var Plugin
	 */
	private static $instance = null;
 
 	private const HERO_META_KEY        = 'seogenherodata';
 	private const HERO_META_LEGACY_KEY = '_seo_gen_hero_data';
 	private const HERO_SCHEMA_VERSION  = 2;

	/**
	 * Error handler instance
	 *
	 * @var Error_Handler
	 */
	private $error_handler;

	/**
	 * Logger instance
	 *
	 * @var Logger
	 */
	private $logger;

	/**
	 * Admin menu instance
	 *
	 * @var Admin\Admin_Menu
	 */
	private $admin_menu;

	/**
	 * Asset Manager
	 * @var Asset_Manager
	 */
	public $asset_manager;

	/**
	 * Ajax Router
	 * @var Ajax_Router
	 */
	private $ajax_router;

	/**
	 * Discovery Processor
	 * @var Discovery\Discovery_Processor
	 */
	private $discovery_processor;

	/**
	 * Job Handler
	 * @var Jobs\Job_Handler
	 */
	private $job_handler;

	/**
	 * Provider Fallback Manager (Phase 3)
	 * @var AI\Provider_Fallback_Manager
	 */
	private $provider_fallback_manager;

	/**
	 * AI Client instance
	 * @var AI\AI_Client
	 */
	private $ai_client;

	/**
	 * Per-request hero data cache.
	 * Populated by get_hero_data(), invalidated by write_hero_data().
	 * @var array<int, array|null>
	 */
	private $hero_data_cache = [];

	/**
	 * Get singleton instance
	 */
	public static function get_instance()
	{
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get AI Client instance (Default settings)
	 *
	 * [PHASE 5 FIX] Use canonical AI_Client::getProviderStatus() for plugin-wide bootstrap.
	 *
	 * @return AI\AI_Client
	 */
	public function get_ai_client()
	{
		if (null === $this->ai_client) {
		$bootstrap = AI\AI_Client::resolve_bootstrap_provider();
		if (!empty($bootstrap['ok'])) {
			$this->ai_client = new AI\AI_Client($bootstrap['provider'], $bootstrap['api_key'], $this->logger);
		} else {
			throw new \RuntimeException($bootstrap['reason'] ?? 'No AI provider available');
		}
		}
		return $this->ai_client;
	}

	/**
	 * Private constructor to prevent direct instantiation
	 */
	private function __construct()
	{
		// Constructor intentionally left empty
		// Use init() method for initialization
	}

	/**
	 * Get Provider Fallback Manager
	 *
	 * @return AI\Provider_Fallback_Manager|null
	 */
	public function get_provider_fallback_manager()
	{
		return $this->provider_fallback_manager;
	}

	/**
	 * Initialize the plugin
	 *
	 * @return void
	 */
	public function init()
	{
		// Initialize error handler and logger first
		$this->logger = new Logger();

		$this->error_handler = new Error_Handler();
		$this->error_handler->set_logger($this->logger);

		// STRICT SCOPE: only this plugin may write into this plugin's log files.
		if (method_exists($this->error_handler, 'set_scope_roots')) {
			$this->error_handler->set_scope_roots(array(
				wp_normalize_path(SEO_GEN_PLUGIN_DIR),
			));
		}

		// Set error handler
		$this->error_handler->init();

		// Load text domain for translations
		add_action('init', array($this, 'load_textdomain'));

		// Initialize admin components if in admin area
		if (\is_admin()) {
			$this->init_admin();

			// @MODIFIED 2025-12-13 v2.0.2: Show install error notice if tables failed
			\add_action('admin_notices', array($this, 'show_install_error_notice'));
		}

		// @MODIFIED 2025-12-02 - Initialize frontend components
		$this->init_frontend();

		// Initialize Job Handler
		$this->job_handler = new Jobs\Job_Handler($this->logger);

		// Initialize Discovery Processor (if exists)
		if (class_exists('SEO_Article_Generator\Discovery\Discovery_Processor')) {
			$this->discovery_processor = new Discovery\Discovery_Processor($this->job_handler, $this->logger);
		}

		// Initialize Provider Fallback Manager (Phase 3)
		if (class_exists('SEO_Article_Generator\AI\Provider_Fallback_Manager')) {
			$this->provider_fallback_manager = new AI\Provider_Fallback_Manager($this->logger);
		}

		// @MODIFIED 2025-12-16 v2.2.0: E-E-A-T author attribution system
		$this->init_eeat();



		// @MODIFIED 2025-12-04 v1.4.0: Register Hero Block
		Blocks\Hero_Block::init();

		// @MODIFIED 2026-03-22: Register Section Block for surgical patching
		Blocks\Section_Block::init();

		// @FIX 2026-06-06: Invalidate Cloudflare page cache when hero meta changes.
		// update_post_meta() does NOT trigger edit_post, so the Cloudflare Super Page Cache
		// plugin never knows the page content changed. Hook updated_post_meta for both
		// canonical and legacy hero keys to purge the associated post's cache.
		\add_action('updated_post_meta', array($this, 'purge_cache_on_hero_meta_change'), 10, 4);

		// @FIX 2026-06-06: Tell Cloudflare Super Page Cache to bypass for posts
		// where hero data might have been updated via update_post_meta().
		\add_filter('swcfpc_cache_bypass', array($this, 'maybe_bypass_cache_for_hero_posts'));

		// @FIX 2026-06-06: Add home page (and posts page) to Cloudflare's
		// per-post purge list. The default Cloudflare list omits home_url('/')
		// unless the SWCFPC_HOME_PAGE_SHOWS_POSTS constant is defined, leaving
		// the blog index / static front page stale after a post update.
		\add_filter('swcfpc_post_related_url_init', array($this, 'add_home_url_to_cloudflare_purge'), 10, 2);

		// @MODIFIED 2026-01-06 v2.15.0: Initialize Post Views System
		Frontend\Views_System::init();

		// @MODIFIED 2025-12-04 v1.4.0: Add body class for CSS targeting
		\add_filter('body_class', array($this, 'add_seo_gen_body_class'), 10, 1);

		// @MODIFIED 2025-12-13 v2.0.8: Register scheduled cleanup handler
		\add_action(Queue\AS_Registry::HOOK_DAILY_CLEANUP, array($this, 'run_daily_cleanup'));

// @MODIFIED 2026-01-04 v2.13.5: Use Ajax_Router
        // Register AJAX handlers
        // $this->register_ajax_handlers(); // Deprecated
        $this->ajax_router = new Ajax_Router($this);

        // Register REST API endpoints for Universal Plugin Dashboard (on rest_api_init)
        add_action('rest_api_init', [$this, 'register_rest_endpoints']);

        // [ARCHITECTURAL-FIX] Finding 3: Cleanup source post's featured image on deletion
		// Since NEW posts sideloaded their own copy, we must delete the source's attachment
		// to prevent media library bloat when the source draft is deleted.
		\add_action('before_delete_post', array($this, 'cleanup_orphaned_featured_image'));

		// [ISSUE-3 FIX] Refresh Rank Math schema on manual post edits for plugin-owned posts.
		// Ensures schema aggregateRating/applicationCategory stay in sync with live data.
		\add_action('save_post', function ($post_id) {
			if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
				return;
			}
			if (\get_post_type($post_id) !== 'post') {
				return;
			}
			if (class_exists('SEO_Article_Generator\Discovery\Post_Type_Classifier')) {
				$type = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify($post_id);
				if (\SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned($type)) {
					if (class_exists('SEO_Article_Generator\Integration\Rank_Math_Schema_Handler')) {
						\SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::write_software_schema($post_id);
					}
				}
			}
		}, 20, 1);
	}

	public function cleanup_orphaned_featured_image($post_id)
	{
		$post = \get_post($post_id);
		if (! $post || $post->post_type !== 'post') {
			return;
		}

		$thumbnail_id = (int) \get_post_thumbnail_id($post_id);
		if ($thumbnail_id <= 0) {
			return;
		}

		global $wpdb;

		$used_elsewhere = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta}
				 WHERE meta_key = '_thumbnail_id'
				   AND meta_value = %d
				   AND post_id <> %d",
				$thumbnail_id,
				$post_id
			)
		);

		if ($used_elsewhere > 0) {
			return;
		}

		$attachment = \get_post($thumbnail_id);
		if ($attachment && (int) $attachment->post_parent !== 0 && (int) $attachment->post_parent !== (int) $post_id) {
			return;
		}

		\wp_delete_attachment($thumbnail_id, true);
	}

	private function init_admin()
	{
		$this->admin_menu = new Admin\Admin_Menu($this->logger);
		$this->admin_menu->init();

		// @MODIFIED 2025-12-04 v1.4.0: Initialize hero meta box
		Admin\Hero_Meta_Box::init();

		// @MODIFIED 2026-01-04 v2.13.5: Initialize Smoke Tester (Admin Diagnostic)
		Admin\Smoke_Tester::init();

		// @MODIFIED 2026-06-14: Register AJAX endpoint for one-time block encoding fix.
		// Fixes broken \uXXXX sequences in block comments of posts generated before the
		// wp_slash() fix in finalize_generated_post().
		Utils\Block_Encoder_Fix::register_ajax();

		// @MODIFIED 2025-12-05 v1.5.3: Add SEO score & downloads columns to post list
		add_filter('manage_post_posts_columns', array($this, 'add_seo_gen_post_columns'));
		add_action('manage_post_posts_custom_column', array($this, 'render_seo_gen_post_column'), 10, 2);
	}


	/**
	 * Initialize frontend components
	 *
	 * @MODIFIED 2025-12-02 - Added for frontend CSS enqueue
	 * @MODIFIED 2026-01-04 v2.13.5 - Moved to Asset_Manager
	 *
	 * @return void
	 */
	private function init_frontend()
	{
		// Asset Manager handles hooks now
		$this->asset_manager = new Asset_Manager();
	}

	/**
	 * Initialize E-E-A-T system
	 *
	 * @MODIFIED 2025-12-16 v2.2.0: Author attribution for Google E-E-A-T compliance
	 *
	 * @return void
	 */
	private function init_eeat()
	{
		// Register Rank Math enhancers immediately.
		if (class_exists('SEO_Article_Generator\\Integration\\RankMath_EEAT_Enhancer')) {
			$eeat_enhancer = new Integration\RankMath_EEAT_Enhancer();
			$eeat_enhancer->register_hooks();
		}

		// Register Social Integrations
		if (class_exists('SEO_Article_Generator\\Integration\\Jetpack_Integration')) {
			$jetpack_integration = new Integration\Jetpack_Integration($this->logger);
			$jetpack_integration->register_hooks();
		}

		if (class_exists('SEO_Article_Generator\\Integration\\Buffer_Integration')) {
			$buffer_integration = new Integration\Buffer_Integration($this->logger);
			$buffer_integration->register_hooks();
		}

		if (class_exists('SEO_Article_Generator\\Integration\\RankMath_Software_Enhancer')) {
			$software_enhancer = new Integration\RankMath_Software_Enhancer();
			$software_enhancer->register_hooks();
		}

		if (class_exists('SEO_Article_Generator\\Integration\\Rank_Math_Schema_Handler')) {
			Integration\Rank_Math_Schema_Handler::register_hooks();
		}

		// Check Rank Math compatibility
		$compat_checker = new Integration\RankMath_Compatibility_Checker();
		if (is_admin()) {
			add_action('admin_notices', array($compat_checker, 'display_admin_notice'));
		}

		// User profile extensions
		if (class_exists('SEO_Article_Generator\\EEAT\\Author_Profile_Manager')) {
			$author_manager = new EEAT\Author_Profile_Manager();
			$author_manager->register_user_meta();

			add_action('show_user_profile', array($author_manager, 'render_profile_fields'));
			add_action('edit_user_profile', array($author_manager, 'render_profile_fields'));
			add_action('personal_options_update', array($author_manager, 'save_profile_fields'));
			add_action('edit_user_profile_update', array($author_manager, 'save_profile_fields'));
		}

		// Attribution metabox (admin only)
		if (is_admin() && class_exists('SEO_Article_Generator\\EEAT\\Article_Attribution_Metabox')) {
			$attribution = new EEAT\Article_Attribution_Metabox();
			add_action('add_meta_boxes', array($attribution, 'register_metabox'));
			add_action('save_post', array($attribution, 'save_metabox'));
		}

		// Frontend E-E-A-T styles
		// @MODIFIED 2026-01-04 v2.13.5 Handled by Asset_Manager
		// add_action('wp_enqueue_scripts', array($this, 'enqueue_eeat_styles'));

		// @MODIFIED 2025-12-16 v2.3.0: Hook E-E-A-T renderers to content
		add_filter('the_content', array($this, 'render_eeat_content'), 5);
	}

	/**
	 * Enqueue E-E-A-T frontend styles
	 *
	 * @deprecated 2.13.5 Use Asset_Manager::enqueue_eeat_styles()
	 * @return void
	 */
	public function enqueue_eeat_styles()
	{
		if ($this->asset_manager) {
			$this->asset_manager->enqueue_eeat_styles();
		}
	}

	/**
	 * Enqueue frontend styles
	 *
	 * @deprecated 2.13.5 Use Asset_Manager::enqueue_frontend_styles()
	 * @return void
	 */
	public function enqueue_frontend_styles()
	{
		if ($this->asset_manager) {
			$this->asset_manager->enqueue_frontend_styles();
		}
	}

	/**
	 * Register AJAX handlers
	 * 
	 * @deprecated 2.13.5 Handled by Ajax_Router
	 * @return void
	 */
	private function register_ajax_handlers()
	{
		// Handled by Ajax_Router now
	}


	/**
	 * AJAX: Submit article generation
	 *
	 * @return void
	 */
	public function ajax_submit_generation()
	{
		try {
			// Verify nonce
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			// Check capabilities
			if (!\current_user_can('edit_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			// Get and sanitize input
			$input_data = $this->sanitize_input_data($_POST);

			// @MODIFIED 2026-04-05: Defensively strip 'toc' from update runtime input
			// toc is not in SECTION_REGISTRY and should not be an update section
			if (!empty($input_data['existing_post_id']) && !empty($input_data['regen_sections']) && is_array($input_data['regen_sections'])) {
				$input_data['regen_sections'] = array_values(array_filter(
					\SEO_Article_Generator\Generator\Article_Schema::normalize_sections($input_data['regen_sections']),
					static function ($section) {
						return $section !== 'toc';
					}
				));

				if (empty($input_data['regen_sections'])) {
					throw new \RuntimeException('AI Update Sections resolved to an empty canonical set. Save Settings > AI Update Sections before running updates.');
				}
			}

	// Settings-backed fallback mirrors DiscoveryProcessor::process_item_background.
	// Both paths normalize through Schema::normalize_sections so the AI job always
	// receives canonical zone keys regardless of what is stored in the option.
	if (empty($input_data['regen_sections'])) {
		$option_defaults = \SEO_Article_Generator\Option_Registry::defaults();
		if (!empty($input_data['existing_post_id'])) {
			$raw_sections = \get_option('seo_gen_update_sections', false);
			$sec_fallback = $option_defaults[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS];
		} else {
			$raw_sections = \get_option('seo_gen_discovery_sections', false);
			$sec_fallback = $option_defaults[\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS];
		}
		if ($raw_sections === false || !\is_array($raw_sections) || empty($raw_sections)) {
			$raw_sections = $sec_fallback;
		}
				$input_data['regen_sections'] = array_values(
					array_unique(
						array_filter(
							\SEO_Article_Generator\Generator\Article_Schema::normalize_sections($raw_sections, $sec_fallback),
							static fn($v) => \is_string($v) && \trim($v) !== ''
						)
					)
				);
			}

			// Create job handler
			$job_handler = new Jobs\Job_Handler($this->logger);

			// Schedule generation job
			$res = $job_handler->schedule_generation($input_data, \get_current_user_id());
			$job_id = is_array($res) ? $res['job_id'] : $res;

			\wp_send_json_success(
				array(
					'job_id' => $job_id,
					'message' => 'Article generation started',
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Generation submit failed: ' . $e->getMessage());
			// @MODIFIED 2025-12-02 - Enhanced error messaging for debugging
			\error_log('[SEO GEN ERROR] ' . $e->getMessage() . ' | File: ' . $e->getFile() . ' | Line: ' . $e->getLine());
			\wp_send_json_error(
				array(
					'message' => $e->getMessage() . ' (Check server logs)',
					'debug' => \WP_DEBUG ? $e->getTrace() : null,
				)
			);
		}
	}

	/**
	 * AJAX: Check job status
	 *
	 * @return void
	 */
	public function ajax_check_status()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('edit_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;

			if (!$job_id) {
				throw new \Exception('Invalid job ID');
			}

			$job_handler = new Jobs\Job_Handler($this->logger);
			$status = $job_handler->get_job_status($job_id);

			wp_send_json_success($status);
		} catch (\Throwable $e) {
			$this->logger->error('Status check failed: ' . $e->getMessage());

			error_log('[SEO GEN ERROR] Status check failed: ' . $e->getMessage() . ' | File: ' . $e->getFile() . ' | Line: ' . $e->getLine());

			wp_send_json_error(
				array(
					'message' => $e->getMessage() . ' (Check server logs)',
				)
			);
		}
	}

	/**
	 * AJAX: Get article preview
	 *
	 * @return void
	 */
	public function ajax_get_preview()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('edit_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;

			if (!$job_id) {
				throw new \Exception('Invalid job ID');
			}

			$job_handler = new Jobs\Job_Handler($this->logger);
			$preview = $job_handler->get_preview($job_id);

			wp_send_json_success($preview);
		} catch (\Throwable $e) {
			$this->logger->error('Preview failed: ' . $e->getMessage());
			error_log('[SEO GEN ERROR] Preview failed: ' . $e->getMessage() . ' | File: ' . $e->getFile() . ' | Line: ' . $e->getLine());
			wp_send_json_error(
				array(
					'message' => $e->getMessage() . ' (Check server logs)',
				)
			);
		}
	}

	/**
	 * AJAX: Publish article
	 *
	 * @return void
	 */
	public function ajax_publish_article()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('publish_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			$job_id  = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
			$post_id = isset($_POST['existing_post_id']) ? absint($_POST['existing_post_id']) : 0;

			if (! $job_id) {
				throw new \Exception('Missing required Job ID');
			}

			// Audit Fix #Critical-1: Source title/content from Job record, not POST
			$job_handler = new Jobs\Job_Handler($this->logger);
			$preview     = $job_handler->get_preview($job_id);

			if (empty($preview) || empty($preview['article'])) {
				throw new \Exception('Could not load canonical job data for publishing');
			}

		// ARCHITECTURAL FIX: Removed pre-write of regen_sections before PPB::build().
		// PPB reads from post meta. The authoritative value was set at approval time
		// via persist_regen_sections_snapshot(). Writing it again here means UI publish
		// uses ajax-time data while background finalization uses approval-time data.
		// Let PPB read the unmolested approval-time snapshot for consistency.

		try {
				$payload_data = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::build($preview, $post_id);
			} catch (\Throwable $e) {
				throw new \Exception(
					'Publish payload build failed: ' . $e->getMessage(),
					0
				);
			}
			$title      = $payload_data['title'];
			$content    = $payload_data['content'];
			$meta_input = $payload_data['meta_input'] ?? array();
			$preview    = $payload_data['preview'];

			if (empty($title)) {
				throw new \Exception('Job output data is incomplete (missing title)');
			}

			if (empty($content)) {
				throw new \Exception('Job output data is incomplete (missing content). For updates to existing articles, ensure the article is recognized as plugin-controlled.');
			}

			// [TIMEZONE HARDENING] Explicit UTC-anchored timestamps for both paths.
			// Replaces ad-hoc date() calls with Plugin_Time architecture.
			$now_utc_ts    = Utils\Plugin_Time::now_utc_ts();
			$post_date     = Utils\Plugin_Time::site_mysql_from_utc_ts($now_utc_ts);
			$post_date_gmt = Utils\Plugin_Time::utc_mysql_from_utc_ts($now_utc_ts);

        $post_arr = array(
            'post_title' => $title,
            'post_content' => $content,
            'post_date' => $post_date,
            'post_date_gmt' => $post_date_gmt,
            'post_modified' => $post_date,
            'post_modified_gmt' => $post_date_gmt,
            'edit_date' => true,
        );

			// [PATCH 3B] Set Primary Author if provided
			if (!empty($meta_input[\SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR])) {
				$post_arr['post_author'] = (int) $meta_input[\SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR];
			}

			$is_update = ($post_id > 0);

			// [FIXED] Routing through Job_Handler to ensure hook guards (Update_Engine) are active.
			// This prevents recursive save loops and ensures content integrity during manual publishes.
			try {
				if ($is_update) {
					$post_arr['ID'] = $post_id;
					$this->job_handler->finalize_generated_post($post_id, $post_arr);
				} else {
					if (empty($post_arr['post_author'])) {
						$post_arr['post_author'] = \get_current_user_id() ?: 1;
					}
					$post_arr['post_type']   = 'post';
					
					// Determine if this is a manual generation (no discovery item linked)
					$job_handler_check = new Jobs\Job_Handler($this->logger);
					$job_data = $job_handler_check->load_job_for_execution($job_id);
					$is_manual_generation = false;
					if ($job_data && !empty($job_data['input_data'])) {
						$input = json_decode($job_data['input_data'], true);
						// Manual generations have generation_mode=auto but no discovery linkage
						// Check if there's a discovery item linked to this job
						global $wpdb;
						$disc_table = Installer::table_discovery();
						$has_discovery = (bool) $wpdb->get_var(
							$wpdb->prepare(
								"SELECT COUNT(*) FROM {$disc_table} WHERE job_id = %d OR queue_job_id = %d",
								$job_id,
								(int)($job_data['queue_job_id'] ?? 0)
							)
						);
						$is_manual_generation = !$has_discovery;
					}
					
					// For manual generations, default to draft (button says "Save as Draft")
					// For discovery generations, use the discovery_publish_status setting
					if ($is_manual_generation) {
						$post_arr['post_status'] = 'draft';
					} else {
						$discovery_publish_status = (string) \get_option('seo_gen_discovery_publish_status', 'publish');
						if (!\in_array($discovery_publish_status, array('publish', 'draft'), true)) {
							$discovery_publish_status = 'publish';
						}
						$post_arr['post_status'] = ($discovery_publish_status === 'draft') ? 'draft' : 'publish';
					}
					
					$post_id = $this->job_handler->finalize_generated_post(0, $post_arr);
				}
			} catch (\Throwable $e) {
				throw new \Exception("Finalization via Job_Handler failed: " . $e->getMessage());
			}

			// Sync meta data.
			try {
				$this->sync_job_meta_to_post($job_id, $post_id, $preview, $meta_input);
			} catch (\Throwable $e) {
				// Audit Fix: Revert/Trash new post if critical metadata fails to persist
				if (! $is_update && $post_id > 0) {
					$this->logger->warning("Rolling back orphaned manual post #{$post_id} due to meta sync failure.");
					\wp_trash_post($post_id);
				}
				throw new \Exception("Critical Metadata Sync Failure: " . $e->getMessage());
			}


			$this->logger->info("Article published: Post ID {$post_id}");

			// @MODIFIED 2026-03-24: Meta sync is now mandatory and blocking
			$response = array(
				'post_id' => $post_id,
				'edit_url' => get_edit_post_link($post_id, 'raw'),
				'message' => $is_update ? 'Article updated' : 'Article saved as draft',
				'meta_saved' => true,
				'warnings' => array(),
			);

			wp_send_json_success($response);
		} catch (\Throwable $e) {
			$this->logger->error('Publish failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Sync job meta to an existing post (for Copy HTML fallback)
	 *
	 * @return void
	 */
	public function ajax_sync_meta()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('edit_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			$job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
			$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

			if (!$job_id || !$post_id) {
				throw new \Exception('Missing job ID or post ID');
			}

			$job_handler = new Jobs\Job_Handler($this->logger);
			$preview = $job_handler->get_preview($job_id);

			if (empty($preview) || empty($preview['article'])) {
				throw new \Exception('Could not load canonical job data for meta sync');
			}

			// Sync regen_sections to post meta so PayloadBuilder reads the correct
			// zones for plugin-owned posts — same fix as ajax_publish_article().
			$post_type = Post_Type_Classifier::classify($post_id);

			if (
				$post_id > 0
				&& Post_Type_Classifier::is_plugin_owned($post_type)
			) {
				$regen_sections = $job_handler->get_regen_sections($job_id);

	$option_defaults = \SEO_Article_Generator\Option_Registry::defaults();
	$sec_fallback = $option_defaults[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS];
	$effective_sections = !empty($regen_sections)
		? $regen_sections
		: (array) \get_option('seo_gen_update_sections', $sec_fallback);

				if (!\is_array($effective_sections) || empty($effective_sections)) {
					$effective_sections = $sec_fallback;
				}

				$normalized = array_values(
					array_unique(
						array_filter(
							\SEO_Article_Generator\Generator\Article_Schema::normalize_sections($effective_sections, $sec_fallback),
							static fn($v) => \is_string($v) && \trim($v) !== ''
						)
					)
				);

				$regen_json = \wp_json_encode($normalized);

				\update_post_meta($post_id, '_seo_gen_regen_sections', $regen_json);
				\update_post_meta($post_id, 'seogenregensections', $regen_json);
			}

			try {
				$payload_data = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::build($preview, $post_id);
			} catch (\Throwable $e) {
				throw new \Exception(
					'Publish payload build failed: ' . $e->getMessage(),
					0
				);
			}
			$preview    = $payload_data['preview'];
			$meta_input = $payload_data['meta_input'] ?? array();

			$this->sync_job_meta_to_post($job_id, $post_id, $preview, $meta_input);

			wp_send_json_success(
				array(
					'message' => 'Schema and hero data synced',
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Meta sync failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * Internal: Sync job data to post meta
	 *
	 * [PRO PARITY] Centralized metadata write via Discovery_Processor::write_post_meta.
	 * This ensures manual edits/re-syncs get taxonomies, E-E-A-T, and Rank Math
	 * updates identical to the background pipeline.
	 *
	 * @param int $job_id
	 * @param int $post_id
	 * @param array $preview Optional preview array to avoid redundant DB reads
	 * @param array $meta_input Optional meta input from payload builder
	 */
	public function sync_job_meta_to_post($job_id, $post_id, array $preview = array(), array $meta_input = array())
	{
		if (empty($preview)) {
			$job_handler = new Jobs\Job_Handler($this->logger);
			$preview     = $job_handler->get_preview($job_id);
		}

		if (empty($preview)) {
			throw new \Exception('Could not load job data');
		}

		$discovery_proc = $this->discovery_processor;
		if ($discovery_proc) {
			$tech_specs = $preview['article']['tech_specs'] ?? array();
			if (!\is_array($tech_specs)) {
				$tech_specs = array();
			}

			$item = (object) array(
				'existing_post_id'   => $post_id,
				'software_name'      => $tech_specs['software_name'] ?? '',
				'discovered_version' => $tech_specs['version'] ?? '',
				'type'               => 'plugin_generated',
				'source_type'        => 'manual'
			);

			$discovery_proc->write_post_meta($post_id, $item, $job_id, $preview, \get_current_user_id(), $meta_input);

			if (class_exists('SEO_Article_Generator\\Integration\\Rank_Math_Schema_Handler')) {
				\SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::write_software_schema($post_id);
			}
		} else {
			throw new \RuntimeException(
				'sync_job_meta_to_post requires Discovery\\Discovery_Processor; aborting to prevent partial metadata persistence.'
			);
		}
	}

	// @MODIFIED v2.0.9: Deleted extract_and_save_faqs() - Rank Math FAQ block handles schema
	// @MODIFIED v2.0.9: Deleted populate_rankmath_schema() - dead code since v1.7.0

	/**
	 * AJAX: Upload sitemap
	 *
	 * @return void
	 */
	public function ajax_upload_sitemap()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			if (!isset($_FILES['sitemap_file'])) {
				throw new \Exception('No file uploaded');
			}

			$file = $_FILES['sitemap_file'];

			// Validate file
			if ($file['error'] !== UPLOAD_ERR_OK) {
				throw new \Exception('File upload error');
			}

			$check_type = \wp_check_filetype((string)$file['name']) ?: array('ext' => '', 'type' => '');
			if (($check_type['ext'] ?? '') !== 'csv') {
				throw new \Exception('Only CSV files are allowed');
			}

			// Parse and import sitemap
			$parser = new Links\Sitemap_Parser($this->logger);
			$result = $parser->import_csv($file['tmp_name']);

			wp_send_json_success(
				array(
					'imported' => $result['imported'],
					'skipped' => $result['skipped'],
					'message' => sprintf('Imported %d links, skipped %d', $result['imported'], $result['skipped']),
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Sitemap upload failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Track download
	 *
	 * @MODIFIED 2025-12-02 Phase 2A
	 *
	 * @return void
	 */
	public function ajax_track_download()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!isset($_POST['post_id'])) {
				wp_send_json_error(array('message' => 'Missing post ID'));
			}

			// @MODIFIED 2026-01-04 Phase 3: Rate Limiting
			if (class_exists('SEO_Article_Generator\Security\Rate_Limiter')) {
				$check = Security\Rate_Limiter::check('download_track', 20, 3600); // 20 per hour
				if (is_wp_error($check)) {
					wp_send_json_error(array('message' => $check->get_error_message()));
				}
			}

			$post_id = absint($_POST['post_id']);
			$count = get_post_meta($post_id, '_seo_gen_download_count', true);
			$count = $count ? intval($count) + 1 : 1;
			update_post_meta($post_id, '_seo_gen_download_count', $count);

			wp_send_json_success(array('count' => $count));
		} catch (\Throwable $e) {
			wp_send_json_error(array('message' => $e->getMessage()));
		}
	}

	/**
	 * AJAX: Submit user rating for a post.
	 *
	 * @since 2.7.3
	 * @return void
	 */
	public function ajax_submit_rating()
	{
		try {
			// Nonce verification (using the frontend nonce)
			check_ajax_referer('seo_gen_rating', 'nonce');

			$post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
			$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;

			if (!$post_id || !$rating) {
				wp_send_json_error(array('message' => 'Missing required data.'));
				return;
			}

			// Use Rating_System for anti-spam and storage
			$result = Frontend\Rating_System::add_rating($post_id, $rating);

			if (is_wp_error($result)) {
				wp_send_json_error(array('message' => $result->get_error_message()));
				return;
			}

			// Return updated rating data
			$data = Frontend\Rating_System::get_rating_data($post_id);

			wp_send_json_success(
				array(
					'message' => 'Thank you for rating!',
					'average' => $data['average'],
					'count' => $data['count'],
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Rating submission failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => 'An error occurred. Please try again.',
				)
			);
		}
	}

	/**
	 * AJAX: Refresh sitemap cache
	 *
	 * @return void
	 */
	public function ajax_refresh_sitemap()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			global $wpdb;
			$table = \SEO_Article_Generator\Installer::table_links();

			$stats = $wpdb->get_row(
				"SELECT
					COUNT(*)                          AS total_links,
					SUM(CASE WHEN used_count = 0 THEN 1 ELSE 0 END) AS unused_links,
					COALESCE(AVG(used_count), 0)      AS avg_usage
				 FROM {$table}",
				ARRAY_A
			);

			$total_links = (int) ( $stats['total_links'] ?? 0 );
			$unused_links = (int) ( $stats['unused_links'] ?? 0 );
			$avg_usage = round( (float) ( $stats['avg_usage'] ?? 0 ), 1 );

			wp_send_json_success(
				array(
					'totalLinks'   => $total_links,
					'unusedLinks'  => $unused_links,
					'avgUsage'   => $avg_usage,
					'message'    => sprintf(
						'Internal links: %d total, %d unused, %.1f avg uses/link',
						$total_links,
						$unused_links,
						$avg_usage
					),
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Sitemap refresh failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Search posts for update picker
	 * FIX: Prioritizes ID lookup and restricts text search to TITLES only.
	 */
	public function ajax_search_posts()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('edit_posts')) {
				throw new \Exception('Insufficient permissions');
			}

			// CRITICAL FIX: Use $_REQUEST instead of $_POST because Select2 defaults to GET
			$search = isset($_REQUEST['search']) ? sanitize_text_field($_REQUEST['search']) : '';
			$page = isset($_REQUEST['page']) ? absint($_REQUEST['page']) : 1;
			$limit = 20;

			$results = array();

			// --- STRATEGY 1: INSTANT ID LOOKUP ---
			// If input is numeric, fetch THAT POST ONLY.
			if (is_numeric($search)) {
				$post_id = absint($search);
				$post = get_post($post_id);

				if ($post && $post->post_type === 'post') {
					$results[] = array(
						'id' => $post->ID,
						'text' => $post->post_title . ' (ID: ' . $post->ID . ')',
					);
					// Return immediately - no DB scan needed
					wp_send_json_success(
						array(
							'results' => $results,
							'pagination' => array('more' => false),
						)
					);
					return;
				}
			}

			// --- STRATEGY 2: TITLE SEARCH (Fallback) ---
			$args = array(
				'post_type' => 'post',
				'post_status' => array('publish', 'draft', 'pending', 'future'),
				'posts_per_page' => $limit,
				'paged' => $page,
				'fields' => 'ids',
				's' => $search,
			);

			// Filter to search titles only (performance + relevance)
			add_filter('posts_search', array($this, 'limit_search_to_title_only'), 10, 2);
			$query = new \WP_Query($args);
			remove_filter('posts_search', array($this, 'limit_search_to_title_only'), 10);

			if ($query->have_posts()) {
				foreach ($query->posts as $post_id) {
					$results[] = array(
						'id' => $post_id,
						'text' => get_the_title($post_id) . ' (ID: ' . $post_id . ')',
					);
				}
			}

			wp_send_json_success(
				array(
					'results' => $results,
					'pagination' => array('more' => $query->max_num_pages > $page),
				)
			);
		} catch (\Throwable $e) {
			wp_send_json_error(array('message' => $e->getMessage()));
		}
	}

	/**
	 * Helper: Limit search to title only
	 */
	public function limit_search_to_title_only($search, $wp_query)
	{
		global $wpdb;
		if (empty($search)) {
			return $search;
		}
		$q = $wp_query->query_vars;
		$n = !empty($q['exact']) ? '' : '%';
		$search = '';
		$searchand = '';
		foreach ((array) $q['search_terms'] as $term) {
			$term = esc_sql($wpdb->esc_like($term));
			$search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
			$searchand = ' AND ';
		}
		if (!empty($search)) {
			$search = " AND ({$search}) ";
			if (!is_user_logged_in()) {
				$search .= " AND ($wpdb->posts.post_password = '') ";
			}
		}
		return $search;
	}


	/**
	 * AJAX: Test API connection
	 *
	 * @return void
	 */
	public function ajax_test_api()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$provider = isset($_POST['provider']) ? sanitize_text_field(wp_unslash($_POST['provider'])) : 'gemini';
			$posted_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';

			// Key prefix validation - only use posted key if it looks real
			$key_prefixes = array(
				'gemini' => 'AIza',
				'openai' => 'sk-',
				'groq' => 'gsk_',
				'perplexity' => 'pplx-',
				'openrouter' => 'sk-or-',
			);
			$expected_prefix = isset($key_prefixes[$provider]) ? $key_prefixes[$provider] : '';

			// Use posted key only if non-empty AND (starts with expected prefix OR is custom provider)
			$use_saved = true;
			$registry = AI\Provider_Registry::get_instance();
			$is_custom = $registry->is_custom($provider);

			if (!empty($posted_key) && $posted_key !== '••••••••') {
				if ($is_custom || (!empty($expected_prefix) && strpos($posted_key, $expected_prefix) === 0)) {
					$use_saved = false;
					$api_key = $posted_key;
				}
			}

			if ($use_saved) {
				$api_key = AI\AI_Client::get_api_key_for_provider($provider);
			}

			if (!$api_key) {
				throw new \Exception('API key is required');
			}

			$details  = AI\AI_Client::get_provider_details($provider);
			$model    = (string) ($details['model'] ?? AI\AI_Client::get_default_model_for_provider($provider));
			$resolved = AI\AI_Client::resolve_provider_model($provider, $model);

			if (empty($resolved['ok'])) {
				throw new \Exception(strtoupper($provider) . ' model is invalid: ' . ($resolved['model'] ?: '(empty)'));
			}

			$preflight = AI\AI_Client::resolve_bootstrap_provider();

			$ai_client = new AI\AI_Client($provider, $api_key, $this->logger);
			$result = $ai_client->test_connection();

			wp_send_json_success(
				array(
					'message' => 'API connection successful',
					'details' => array_merge($result, array(
						'resolved_provider' => $provider,
						'resolved_model'    => $resolved['model'],
						'provider_state'    => (string) ($details['state'] ?? 'unknown'),
						'provider_available'=> !empty($details['available']),
						'bootstrap_ok'      => !empty($preflight['ok']),
						'bootstrap_reason'  => (string) ($preflight['reason'] ?? ''),
					)),
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('API test failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

 	/**
	 * AJAX: Test custom provider connection
	 *
	 * @return void
	 */
	public function ajax_test_custom_provider()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$api_url = isset($_POST['api_url']) ? esc_url_raw(wp_unslash($_POST['api_url'])) : '';
			$api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
			$model_id = isset($_POST['model_id']) ? sanitize_text_field(wp_unslash($_POST['model_id'])) : '';
			$provider_name = isset($_POST['provider_name']) ? sanitize_text_field(wp_unslash($_POST['provider_name'])) : 'Custom Provider';
			$provider_id = isset($_POST['provider_id']) ? sanitize_key(wp_unslash($_POST['provider_id'])) : '';

			if (empty($api_url)) {
				throw new \Exception('API URL is required');
			}

			// If API Key is empty, try to retrieve it from saved custom providers if ID is provided
			if (empty($api_key) && !empty($provider_id)) {
				$registry = AI\Provider_Registry::get_instance();
				$profile = $registry->get_custom_profile($provider_id);
				if (!empty($profile)) {
					$api_key = $profile['api_key'] ?? '';
				}
			}

			if (empty($api_key)) {
				throw new \Exception('API key is required');
			}
			if (empty($model_id)) {
				throw new \Exception('Model ID is required');
			}

			$profile = array(
				'id' => !empty($provider_id) ? $provider_id : 'custom_test_' . time(),
				'name' => $provider_name,
				'api_url' => $api_url,
				'api_key' => $api_key,
				'models' => array(
					array('model_id' => $model_id, 'display_name' => $model_id),
				),
				'enable_web_search' => false,
				'fallback_enabled' => false,
				'supports_json_schema' => false,
				'web_search_config' => array('type' => 'none'),
				'use_openrouter_native_search' => (strpos($api_url, 'openrouter.ai') !== false || strpos($api_url, 'openrouterapi.ai') !== false),
			);

			$logger = $this->logger;
			$registry = AI\Provider_Registry::get_instance();
			// Register in-memory temporarily for the duration of this request
			$registry->register_temporary_provider($profile);

			$ai_client = new AI\AI_Client($profile['id'], $api_key, $logger);

			$custom_provider = new AI\Providers\Custom_Provider(
				$api_key,
				$logger,
				$ai_client,
				$profile['id'],
				$profile
			);

			$result = $custom_provider->test_connection();

			$this->logger->info("Custom provider test succeeded for {$provider_name}.", [
				'url' => preg_replace('/key=[^&]+/', 'key=***', $api_url),
				'model' => $model_id,
			]);

			wp_send_json_success(array(
				'message' => sprintf(
					\__('Connected successfully to %s via %s', 'seo-article-generator'),
					\esc_html($provider_name),
					\esc_html($model_id)
				),
				'details' => $result,
			));
		} catch (\Throwable $e) {
			$this->logger->error('Custom provider test failed: ' . $e->getMessage());
			wp_send_json_error(array(
				'message' => $e->getMessage(),
			));
		}
	}

	/**
	 * AJAX: Manually sync free OpenRouter models into the OpenRouter custom provider.
	 *
	 * @MODIFIED 2026-07-12 - OpenRouter free model auto-sync
	 * @return void
	 */
	public function ajax_sync_openrouter_models()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (! \current_user_can('manage_options')) {
				\wp_send_json_error(array('message' => \__('Insufficient permissions.', 'seo-article-generator')));
			}

			$result = \SEO_Article_Generator\AI\OpenRouter_Model_Sync::sync();

			if ($result['success']) {
				\wp_send_json_success($result);
			} else {
				\wp_send_json_error(array('message' => $result['message']));
			}
		} catch (\Throwable $e) {
			\wp_send_json_error(array('message' => 'Sync failed: ' . $e->getMessage()));
		}
	}

	/**
	 * AJAX: Manual trigger for OpenCode Zen free model sync.
	 * Sibling of ajax_sync_openrouter_models() — same nonce, capability,
	 * and result-shape contract. Intentionally does NOT gate on the
	 * discovery pause flag, matching the OpenRouter manual path (the cron
	 * path in Discovery_Bootstrap::sync_zen_models() is gated).
	 *
	 * @return void
	 */
	public function ajax_sync_zen_models()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (! \current_user_can('manage_options')) {
				\wp_send_json_error(array('message' => \__('Insufficient permissions.', 'seo-article-generator')));
			}

			$result = \SEO_Article_Generator\AI\OpenCode_Zen_Model_Sync::sync();

			if ($result['success']) {
				\wp_send_json_success($result);
			} else {
				\wp_send_json_error(array('message' => $result['message']));
			}
		} catch (\Throwable $e) {
			\wp_send_json_error(array('message' => 'Sync failed: ' . $e->getMessage()));
		}
	}

	/**
	 * @MODIFIED 2026-01-06 v2.16.0: Comprehensive smoke test for Settings page
	 * @return void
	 */
	public function ajax_run_smoke_test()
	{
		$buffer_level = ob_get_level();
		ob_start();

		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				while (ob_get_level() > $buffer_level) {
					ob_end_clean();
				}
				wp_send_json_error(array('message' => 'Insufficient permissions'), 403);
			}

			$results = \SEO_Article_Generator\Admin\Smoke_Tester::run_smoke_test();

			$unexpected_output = '';
			while (ob_get_level() > $buffer_level) {
				$unexpected_output .= ob_get_clean();
			}

			if ($unexpected_output !== '') {
				if ($this->logger) {
					$this->logger->error('Smoke test emitted unexpected output: ' . trim($unexpected_output));
				} else {
					error_log('SEO GEN smoke test emitted unexpected output: ' . trim($unexpected_output));
				}
			}

			wp_send_json_success(array(
				'message' => 'Smoke test completed',
				'results' => $results,
				'debug_output' => $unexpected_output !== '' ? trim($unexpected_output) : null,
			));
		} catch (\Throwable $e) {
			$unexpected_output = '';
			while (ob_get_level() > $buffer_level) {
				$unexpected_output .= ob_get_clean();
			}

			if ($this->logger) {
				$this->logger->error('Smoke test failed: ' . $e->getMessage());
				if ($unexpected_output !== '') {
					$this->logger->error('Smoke test leaked output before failure: ' . trim($unexpected_output));
				}
			} else {
				error_log('SEO GEN smoke test failed: ' . $e->getMessage());
				if ($unexpected_output !== '') {
					error_log('SEO GEN smoke test leaked output before failure: ' . trim($unexpected_output));
				}
			}

			wp_send_json_error(array(
				'message' => $e->getMessage(),
				'debug_output' => $unexpected_output !== '' ? trim($unexpected_output) : null,
			));
		}
	}

	/**
	 * Sanitize input data
	 *
	 * @param array $data Raw input data
	 * @return array Sanitized data
	 */
	private function sanitize_input_data($data)
	{
		return array(
			// @MODIFIED 2025-12-04 v1.5.1: Auto-Update mode fields (primary)
			'generation_mode' => isset($data['generation_mode']) ? sanitize_text_field($data['generation_mode']) : 'auto',
			'article_context' => isset($data['article_context']) ? wp_kses_post($data['article_context']) : '',
			'auto_category' => isset($data['auto_category']) ? sanitize_text_field($data['auto_category']) : '',
			'regen_sections' => isset($data['regen_sections']) && is_array($data['regen_sections'])
				? array_map('sanitize_text_field', $data['regen_sections'])
				: array(),
			// @MODIFIED 2025-12-12 v1.8.1: Partial regen merge requires existing post ID
			'existing_post_id' => isset($data['existing_post_id']) ? absint($data['existing_post_id']) : 0,

			// Legacy Manual Mode fields (preserved for backward compatibility)
			'software_name' => isset($data['software_name']) ? sanitize_text_field($data['software_name']) : '',
			'version' => isset($data['version']) ? sanitize_text_field($data['version']) : '',
			'file_name' => isset($data['file_name']) ? sanitize_text_field($data['file_name']) : '',
			'file_size' => isset($data['file_size']) ? sanitize_text_field($data['file_size']) : '',
			'changelog' => isset($data['changelog']) ? wp_kses_post($data['changelog']) : '',
			'homepage' => isset($data['homepage']) ? esc_url_raw($data['homepage']) : '',
			'license' => isset($data['license']) ? sanitize_text_field($data['license']) : '',
			'developer' => isset($data['developer']) ? sanitize_text_field($data['developer']) : '',
			'os_support' => isset($data['os_support']) ? sanitize_text_field($data['os_support']) : '',
			'category' => isset($data['category']) ? sanitize_text_field($data['category']) : '',
			// @MODIFIED 2025-12-02 Phase 1 fields
			'screenshot_ids' => isset($data['screenshot_ids']) ? sanitize_text_field($data['screenshot_ids']) : '',
			'download_link' => isset($data['download_link']) ? wp_kses_post($data['download_link']) : '',
			'verified_download' => isset($data['verified_download']) ? (bool) $data['verified_download'] : false,
			'license_details' => isset($data['license_details']) ? sanitize_text_field($data['license_details']) : '',
			// @MODIFIED 2025-12-02 Phase 2A fields
			'editor_rating' => isset($data['editor_rating']) ? floatval($data['editor_rating']) : 0,
			'language_support' => isset($data['language_support']) ? sanitize_text_field($data['language_support']) : '',
			'file_hash' => isset($data['file_hash']) ? sanitize_text_field($data['file_hash']) : '',
			// @MODIFIED 2025-12-02 Phase 3 fields
			'video_url' => isset($data['video_url']) ? esc_url_raw($data['video_url']) : '',
			'platform_win11' => isset($data['platform_win11']) ? 1 : 0,
			'platform_win10' => isset($data['platform_win10']) ? 1 : 0,
			'platform_mac' => isset($data['platform_mac']) ? 1 : 0,
			'platform_linux' => isset($data['platform_linux']) ? 1 : 0,
			'platform_android' => isset($data['platform_android']) ? 1 : 0,
			'platform_ios' => isset($data['platform_ios']) ? 1 : 0,
			// @MODIFIED 2025-12-15 v2.1.0: Software category for moat content
			'software_category' => isset($data['software_category']) ? sanitize_text_field($data['software_category']) : '',
			// @MODIFIED 2025-12-16 v2.3.0: P3 section toggles
			'include_faqs' => isset($data['include_faqs']) ? 1 : 0,
			'include_pros_cons' => isset($data['include_pros_cons']) ? 1 : 0,
			'include_competitors' => isset($data['include_competitors']) ? 1 : 0,
			'include_moat' => isset($data['include_moat']) ? 1 : 0,
			// @MODIFIED 2026-03-03: Flag as manual for Prompt_Builder
			'input_type' => 'manual',
		);
	}

	/**
	 * Load plugin text domain for translations
	 *
	 * @return void
	 */
	public function load_textdomain()
	{
		load_plugin_textdomain('seo-article-generator', false, dirname(SEO_GEN_PLUGIN_BASENAME) . '/languages');
	}

	/**
	 * Normalize any hero payload into the canonical schema.
	 *
	 * [CANONICAL-FIX] Finding 1: Real normalizer for schema version 2.
	 *
	 * @param int   $post_id
	 * @param array $raw
	 * @return array
	 */
	/**
	 * Canonical Hero Data Normalizer
	 *
	 * [CANONICAL-FIX] Finding 1: Strict normalization for schema version 2.
	 *
	 * @param int $post_id
	 * @param array $raw
	 * @return array
	 */
	private function normalize_hero_data($post_id, array $raw)
	{
		$schema_array = array();
		$tech_specs   = array();

		if (class_exists('\\SEO_Article_Generator\\Services\\Schema_Sync_Service')) {
			try {
				if (\SEO_Article_Generator\Services\Schema_Sync_Service::has_schema($post_id)) {
					$schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema($post_id);
					$schema_array = (is_object($schema) && method_exists($schema, 'to_array'))
						? $schema->to_array()
						: array();

					$tech_specs = $schema_array['tech_specs'] ?? ($schema_array['techspecs'] ?? array());
					if (!\is_array($tech_specs)) {
						$tech_specs = array();
					}
				}
			} catch (\Throwable $e) {
				$tech_specs = array();
			}
		}

		$normalized = array(
			'_schema_version'    => self::HERO_SCHEMA_VERSION,
			'software_name'      => '',
			'version'            => '',
			'license'            => '',
			'license_details'    => '',
			'file_size'          => '',
			'rating'             => '',
			'rating_count'       => '',
			'logo_url'           => '',
			'publisher'          => '',
		'category' => '',
		'application_category' => '',
		'last_updated' => '',
			'min_os'             => '',
			'security_badge'     => '',
			'download_links'     => array(),
			'last_verified_date' => '',
		);

		$map = array(
			'software_name'      => array('software_name', 'softwarename'),
			'version'            => array('version'),
			'license'            => array('license'),
			'license_details'    => array('license_details', 'licensedetails'),
			'file_size'          => array('file_size', 'filesize'),
			'rating'             => array('rating'),
			'rating_count'       => array('rating_count', 'ratingcount'),
			'logo_url'           => array('logo_url', 'logourl'),
			'publisher'          => array('publisher', 'developer'),
		'category' => array('category'),
		'application_category' => array('application_category', 'applicationcategory'),
		'last_updated' => array('last_updated', 'lastupdated'),
			'min_os'             => array('min_os', 'minos', 'os_support', 'ossupport'),
			'security_badge'     => array('security_badge', 'security_badge_text', 'securitybadge'),
			'download_links'     => array('download_links', 'downloadlinks'),
			'last_verified_date' => array('last_verified_date', 'last_verified', 'lastverified'),
		);

		foreach ($map as $canonical_key => $aliases) {
			foreach ($aliases as $alias) {
				if (array_key_exists($alias, $raw) && $raw[$alias] !== '' && $raw[$alias] !== null) {
					$normalized[$canonical_key] = $raw[$alias];
					break;
				}
			}
		}

		// Backfill from tech_specs
		if (empty($normalized['software_name'])) {
			$normalized['software_name'] = (string) ($tech_specs['software_name'] ?? \get_the_title($post_id));
		}
		if (empty($normalized['version'])) {
			$normalized['version'] = (string) ($tech_specs['version'] ?? '');
		}
	if (empty($normalized['publisher'])) {
		$normalized['publisher'] = (string) ($tech_specs['developer'] ?? '');
	}

	if (empty($normalized['application_category']) && !empty($normalized['category'])) {
		$normalized['application_category'] = \SEO_Article_Generator\Generator\Hero_Data_Provider::normalize_application_category_value($normalized['category']);
	}
	if (empty($normalized['category']) && !empty($normalized['application_category'])) {
		$enum_to_display = array(
			'GameApplication' => 'Games',
			'UtilitiesApplication' => 'Utilities',
			'BusinessApplication' => 'Business',
			'DesignApplication' => 'Design',
			'SecurityApplication' => 'Security',
			'MultimediaApplication' => 'Multimedia',
			'BrowserApplication' => 'Browser',
			'SocialNetworkingApplication' => 'Communication',
			'DeveloperApplication' => 'Developer Tools',
			'EducationalApplication' => 'Education',
		);
		$ac = $normalized['application_category'];
		$normalized['category'] = isset($enum_to_display[$ac]) ? $enum_to_display[$ac] : str_replace('Application', '', $ac);
	}
	if (empty($normalized['category']) && $post_id > 0) {
		$terms = \get_the_terms($post_id, 'category');
		if (!empty($terms) && !\is_wp_error($terms)) {
			$os_slugs = array('windows', 'macos', 'linux', 'android', 'ios', 'mac', 'featured', 'offline', 'portable');
			$sw_terms = array_filter($terms, static function($t) use ($os_slugs) { return !in_array($t->slug, $os_slugs, true); });
			$use_terms = !empty($sw_terms) ? $sw_terms : $terms;
			$first_term = reset($use_terms);
			if ($first_term) {
				$normalized['category'] = $first_term->name;
				if (empty($normalized['application_category'])) {
					$normalized['application_category'] = \SEO_Article_Generator\Generator\Hero_Data_Provider::normalize_application_category_value($first_term->slug);
				}
			}
		}
	}

	$normalized['download_links'] = $this->normalize_hero_download_links($normalized['download_links']);
	$normalized = array_merge($raw, $normalized); // retain schema aliases and provenance
	$normalized['operating_system'] = implode(', ', \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($normalized['download_links']));
	$normalized['os_support'] = $normalized['operating_system'];
	$normalized['download_url'] = \SEO_Article_Generator\Generator\Download_Link_Helper::find_primary_download_url($normalized['download_links']);
	$normalized['downloadUrl'] = $normalized['download_url'];


		if (!empty($normalized['last_updated'])) {
			$ts = \strtotime((string) $normalized['last_updated']);
			if ($ts) {
				$normalized['last_updated'] = \wp_date('Y-m-d', $ts);
			}
		}
		if (!empty($normalized['last_verified_date'])) {
			$ts = \strtotime((string) $normalized['last_verified_date']);
			if ($ts) {
				$normalized['last_verified_date'] = \wp_date('Y-m-d', $ts);
			}
		}

        return $normalized;
	}

	/**
	 * Canonical Hero Download Link Normalizer
	 *
	 * @param array $raw_links
	 * @return array
	 */
	private function normalize_hero_download_links($raw_links): array
	{
		return \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(is_array($raw_links) ? $raw_links : array(), 'Other');
	}

	public function invalidate_hero_data_cache(int $post_id): void
	{
		unset($this->hero_data_cache[$post_id]);
	}

	/**
	 * Resolve canonical hero data.
	 *
	 * [CANONICAL-FIX] Finding 1: Real normalizer for schema version 2.
	 *
	 * @param int $post_id
	 * @return array|null
	 */
	public function get_hero_data($post_id)
	{
		// Per-request cache: hero data cannot change within a single PHP request
		// unless explicitly written by write_hero_data(). Eliminates 10-14 redundant
		// get_post_meta() calls across 7+ callers on every frontend post page.
		if (isset($this->hero_data_cache[$post_id])) {
			return $this->hero_data_cache[$post_id];
		}

		$hero_data = \get_post_meta($post_id, self::HERO_META_KEY, true);
		if (!empty($hero_data) && \is_array($hero_data)) {
			// @FIX 2026-06-06: Normalize in-memory on admin read path only.
			// Persistence is handled exclusively by the save path (save_meta_box ->
			// Schema_Sync_Service::save_schema -> write_hero_data). Writing here
			// on every page load fires updated_post_meta -> Cloudflare purge API
			// calls, causing multi-second edit-screen latency.
			if (\is_admin()) {
				$this->hero_data_cache[$post_id] = $this->normalize_hero_data($post_id, $hero_data);
				return $this->hero_data_cache[$post_id];
			}
			$this->hero_data_cache[$post_id] = $this->normalize_hero_data($post_id, $hero_data);
			return $this->hero_data_cache[$post_id];
		}

		$legacy_data = \get_post_meta($post_id, self::HERO_META_LEGACY_KEY, true);
		if (!empty($legacy_data) && \is_array($legacy_data)) {
			if (\is_admin()) {
				$this->hero_data_cache[$post_id] = $this->normalize_hero_data($post_id, $legacy_data);
				return $this->hero_data_cache[$post_id];
			}
			$this->hero_data_cache[$post_id] = $this->normalize_hero_data($post_id, $legacy_data);
			return $this->hero_data_cache[$post_id];
		}

		$this->hero_data_cache[$post_id] = null;
		return null;
	}

	/**
	 * Write canonical hero data.
	 * 
	 * [CANONICAL-FIX] Single authority for writing seogenherodata.
	 *
	 * @param int $post_id
	 * @param array $data
	 * @return void
	 */
	public function write_hero_data($post_id, array $data)
	{
		$normalized = $this->normalize_hero_data($post_id, $data);
		\update_post_meta($post_id, self::HERO_META_KEY, \wp_slash($normalized));
		// @MODIFIED 2026-04-28: SSOT sync — write to _seo_gen_hero_data so admin UI
		// and Hero_Meta_Box see the same data. Eliminates split-brain between the two keys.
		\update_post_meta($post_id, self::HERO_META_LEGACY_KEY, \wp_slash($normalized));

		// Invalidate per-request cache so subsequent get_hero_data() calls see fresh data.
		unset($this->hero_data_cache[$post_id]);

		// @FIX 2026-06-06: Set a short-lived transient flag to tell the Cloudflare
		// cache bypass filter that this post's hero data was just changed.
		// Expires in 60 seconds — only the next request from a logged-out
		// visitor will bypass cache; subsequent requests use the fresh cache.
		if (\get_post_status($post_id) === 'publish') {
			\set_transient('seo_gen_hero_dirty_' . $post_id, 1, 60);
		}
	}

	/**
	 * Purge Cloudflare page cache when hero meta is updated.
	 *
	 * update_post_meta() fires updated_post_meta but NOT edit_post.
	 * The Cloudflare Super Page Cache plugin only hooks edit_post,
	 * so hero data changes via get_hero_data() normalization are invisible
	 * to the cache invalidation system.
	 *
	 * @since 2.30.1
	 * @param int    $meta_id    The meta ID.
	 * @param int    $post_id    The post ID.
	 * @param string $meta_key   The meta key.
	 * @param mixed  $meta_value The meta value.
	 * @return void
	 */
	public function purge_cache_on_hero_meta_change($meta_id, $post_id, $meta_key, $meta_value)
	{
		if ($meta_key !== self::HERO_META_KEY && $meta_key !== self::HERO_META_LEGACY_KEY) {
			return;
		}

		$this->invalidate_hero_data_cache((int) $post_id);

		// Bail if the post is not published — no cache to purge.
		if (\get_post_status($post_id) !== 'publish') {
			return;
		}

		// Skip autosaves and revisions — the Cloudflare plugin's own edit_post
		// hook already purges on the real save.
		if (\wp_is_post_autosave($post_id) || \wp_is_post_revision($post_id)) {
			return;
		}

		// Dedup: only purge once per post per PHP request. The save path
		// (write_hero_data) writes to two hero meta keys; the second
		// updated_post_meta would otherwise fire a redundant purge.
		static $purged = [];
		if (isset($purged[$post_id])) {
			return;
		}
		$purged[$post_id] = true;

		// Delegate to the Cloudflare Super Page Cache purge API if available.
		if (\function_exists('\\SPC\\Modules\\Cache_Controller::purge_urls')) {
			$permalink = \get_permalink($post_id);
			if ($permalink) {
				\SPC\Modules\Cache_Controller::purge_urls(array($permalink), true);
			}
		}

		// Also fire the plugin's own action for any other listener.
		\do_action('seo_gen_hero_cache_purged', $post_id);
	}

	/**
	 * Conditionally bypass Cloudflare cache for posts with hero data.
	 *
	 * This is a safety net: when hero data is saved via update_post_meta()
	 * (not wp_update_post), the Cloudflare cache plugin doesn't know to
	 * invalidate. Bypassing cache on the FIRST request after a meta change
	 * ensures the cached version is always fresh.
	 *
	 * @since 2.30.1
	 * @param bool $bypass Current bypass decision.
	 * @return bool
	 */
	public function maybe_bypass_cache_for_hero_posts($bypass)
	{
		if ($bypass) {
			return true;
		}

		if (!\is_singular('post')) {
			return false;
		}

		$post_id = \get_the_ID();
		if (!$post_id) {
			return false;
		}

		// Only bypass if the transient flag is set (hero data was just changed).
		// The transient is set by write_hero_data() and expires in 60 seconds.
		$flag_key = 'seo_gen_hero_dirty_' . $post_id;
		if (\get_transient($flag_key)) {
			\delete_transient($flag_key);
			return true;
		}

		return false;
	}

	/**
	 * Add home page (and posts page) to Cloudflare's per-post purge list.
	 *
	 * The Cloudflare Super Page Cache plugin's get_post_related_links()
	 * only includes home_url('/') when the SWCFPC_HOME_PAGE_SHOWS_POSTS
	 * constant is defined. On a default WordPress install with
	 * show_on_front = 'posts', the home page is the blog index and it
	 * is NOT in the purge list — so updating a post leaves the cached
	 * home page stale and visitors see the old post order.
	 *
	 * @since 2.30.1
	 * @param array $urls    Current list of URLs to purge.
	 * @param int   $post_id The post being updated.
	 * @return array Modified list of URLs.
	 */
	public function add_home_url_to_cloudflare_purge($urls, $post_id)
	{
		if (!\is_array($urls)) {
			$urls = array();
		}

		if (!($post_id > 0)) {
			return $urls;
		}

		// Only purge the home page for published posts — no point purging
		// for drafts or pending posts since they never appear on the home page.
		if (\get_post_status($post_id) !== 'publish') {
			return $urls;
		}

		$home = \home_url('/');
		if ($home && !\in_array($home, $urls, true)) {
			$urls[] = $home;
		}

		// If using a static front page with a separate blog posts page,
		// also include the posts page URL.
		if (\get_option('show_on_front') === 'page') {
			$posts_page_id = (int) \get_option('page_for_posts');
			if ($posts_page_id > 0) {
				$link = \get_permalink($posts_page_id);
				if ($link && !\in_array($link, $urls, true)) {
					$urls[] = $link;
				}
			}
		}

		return $urls;
	}

	/**
	 * Render E-E-A-T byline and verification badge in content
	 *
	 * @MODIFIED 2026-03-27: Uses canonical get_hero_data() and passes it to renderer
	 *
	 * @param string $content Post content
	 * @return string Modified content
	 */
	public function render_eeat_content($content)
	{
		// Bail early on non-singular views before any DB queries.
		// the_content filter fires on archives, search, REST — skip all of them.
		if (!\is_singular('post')) {
			return $content;
		}

		$post_id = \get_the_ID();
		$hero_data = $this->get_hero_data($post_id);

		if (!$hero_data) {
			return $content;
		}

		$prepend = '';
		$append  = '';

		// Footer author box (full)
		if (\class_exists('SEO_Article_Generator\\Frontend\\Author_Byline_Renderer')) {
			$byline_renderer = new Frontend\Author_Byline_Renderer();
			$append .= $byline_renderer->render_byline($post_id, 'footer', $hero_data);
		}

		return $prepend . $content . $append;
	}

	/**
	 * Add body class for SEO Gen posts
	 *
	 * @param array $classes Body classes
	 * @return array Modified classes
	 */
	public function add_seo_gen_body_class($classes)
	{
		if (\is_singular('post') && $this->get_hero_data(\get_the_ID())) {
			$classes[] = 'seo-gen-post';
		}
		return $classes;
	}

	/**
	 * Show admin notice if plugin installation had errors
	 *
	 * @MODIFIED 2025-12-13 v2.0.2: Surface table creation failures to admins
	 *
	 * @return void
	 */
	public function show_install_error_notice()
	{
		$error = get_option('seo_gen_install_error');
		if ($error) {
			echo '<div class="notice notice-error is-dismissible">';
			echo '<p><strong>SEO Article Generator:</strong> ' . esc_html($error) . '</p>';
			echo '<p>Please deactivate and reactivate the plugin, or contact support.</p>';
			echo '</div>';
		}
	}

	/**
	 * Run daily cleanup tasks
	 *
	 * @MODIFIED 2025-12-13 v2.0.8
	 * @MODIFIED 2026-03-10: Expanded to include discovery and retention cleanups + lock clearing.
	 *
	 * @return void
	 */
	public function run_daily_cleanup()
	{
		$job_handler         = new Jobs\Job_Handler($this->logger);
		$discovery_processor = new Discovery\Discovery_Processor($job_handler, $this->logger);
		$retention_days      = (int) \get_option('seo_gen_log_retention', 7);

		// 1. Clean completion/error generation jobs (30 days)
		$failed_stale_jobs_count = $job_handler->cleanup_stale_jobs();
		$job_handler->clean_old_jobs(30);

		// 1b. Clean new Industrial Queue tickets (30 days)
		$job_repository = new Queue\Job_Repository($GLOBALS['wpdb']);
		$job_repository->purge_old_jobs(30);

		// 2. Clear stale runtime locks and reservations
		$stale_reservations_count = $job_repository->cleanup_stale_reservations();
		$stale_locks_count = $job_handler->clear_stale_locks(); 

		// Transient cleanup
		// IMPORTANT:
		// Do NOT blanket-delete all seo_gen transients here.
		// Discovery_Engine::run_ai_update_checks() uses seo_gen_ai_checks_{Y-m-d}
		// as the authoritative daily quota counter, and other seo_gen transients
		// hold live runtime state. Only clear disposable UI/cache transients.
		global $wpdb;
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name = '_transient_seo_gen_as_queue_count'
			    OR option_name = '_transient_timeout_seo_gen_as_queue_count'
			    OR option_name LIKE '_transient_seo_gen_dashboard_snapshot_%'
			    OR option_name LIKE '_transient_timeout_seo_gen_dashboard_snapshot_%'
			    OR option_name LIKE '_transient_seo_gen_log_deferred_%'
			    OR option_name LIKE '_transient_timeout_seo_gen_log_deferred_%'"
		);

		// 3. Purge old discovery records and drafts lazily via Queue architecture
		$queue_manager = new Queue\Queue_Manager($job_repository);
		$queue_manager->enqueue_discovery_cleanup();
		$queue_manager->enqueue_retention_cleanup();

		// 3b. Proactive cleanup for orphaned Auto category posts not tracked in discovery table
		$orphan_cleanup = \SEO_Article_Generator\Discovery\Discovery_Engine::cleanup_orphaned_auto_category_posts();

		// Trigger queue worker to start digesting
		Queue\AS_Registry::schedule_unique_single_action(
			Utils\Plugin_Time::now_utc_ts() + 5,
			Queue\AS_Registry::HOOK_QUEUE_WORKER,
			array()
		);

		// 4. Clear old log files
		$logs_deleted = 0;
		if ($retention_days > 0) {
			$logs_deleted = $this->logger->clear_old_logs($retention_days);
		}

		// 5. Clean social share history older than 30 days
		$social_cleanup = $this->cleanup_social_share_history(30);

		$this->logger->info(
			'Daily cleanup completed',
			array(
				'logs_deleted' => $logs_deleted,
				'jobs_failed'  => $failed_stale_jobs_count,
				'reservations_recovered' => $stale_reservations_count,
				'locks_cleared' => $stale_locks_count,
				'buffer_entries_cleaned' => $social_cleanup['buffer'],
				'jetpack_entries_cleaned' => $social_cleanup['jetpack'],
				'orphan_auto_posts_deleted' => $orphan_cleanup['deleted'],
				'orphan_auto_posts_errors' => $orphan_cleanup['errors'],
				'orphan_auto_posts_skipped' => $orphan_cleanup['skipped'],
			)
		);
	}

	/**
	 * Clean social share history older than N days.
	 *
	 * Buffer: Trims entries from `_seo_gen_buffer_share_history` post meta arrays.
	 * Jetpack: Deletes `_wpas_done_*` post meta rows on posts older than N days.
	 *
	 * @param int $days_to_keep Number of days to retain (default 30).
	 * @return array{buffer: int, jetpack: int} Cleanup counts.
	 */
	private function cleanup_social_share_history($days_to_keep = 30)
	{
		global $wpdb;
		$buffer_cleaned  = 0;
		$jetpack_cleaned = 0;

		$cutoff_date = gmdate('Y-m-d H:i:s', strtotime("-{$days_to_keep} days"));

		// --- Buffer: trim old entries from per-post share history arrays ---
		$buffer_meta_rows = $wpdb->get_results(
			"SELECT post_id, meta_value FROM {$wpdb->postmeta}
			 WHERE meta_key = '_seo_gen_buffer_share_history'
			   AND meta_value IS NOT NULL
			   AND meta_value != ''
			   AND meta_value != 'a:0:{}'",
			ARRAY_A
		);

		foreach ((array) $buffer_meta_rows as $row) {
			// WordPress postmeta stores arrays as PHP serialized strings (a:...), NOT JSON
			// Use maybe_unserialize() to handle both serialized and JSON (defensive)
			$history = maybe_unserialize($row['meta_value']);
			if (!is_array($history)) {
				continue;
			}
			$before = count($history);
			$history = array_filter($history, function ($entry) use ($cutoff_date) {
				$shared_at = isset($entry['shared_at']) ? $entry['shared_at'] : '';
				return !empty($shared_at) && $shared_at > $cutoff_date;
			});
			$history = array_values($history);
			$after = count($history);
			$diff = $before - $after;
			if ($diff > 0) {
				if ($after === 0) {
					delete_post_meta((int) $row['post_id'], '_seo_gen_buffer_share_history');
				} else {
					update_post_meta((int) $row['post_id'], '_seo_gen_buffer_share_history', $history);
				}
				$buffer_cleaned += $diff;
			}
		}

		// --- Jetpack: delete _wpas_done_* meta on posts older than N days ---
		$old_posts = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm.post_id
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key LIKE '_wpas_done_%%'
				   AND p.post_date_gmt <= %s
				 LIMIT 500",
				$cutoff_date
			)
		);

		if (!empty($old_posts)) {
			foreach ($old_posts as $pid) {
				$done_keys = $wpdb->get_col($wpdb->prepare(
					"SELECT meta_key FROM {$wpdb->postmeta}
					 WHERE post_id = %d AND meta_key LIKE '_wpas_done_%%'",
					(int) $pid
				));
				foreach ($done_keys as $key) {
					delete_post_meta((int) $pid, $key);
					$jetpack_cleaned++;
				}
			}
		}

		// --- Also clean Buffer transient cache entries ---
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_seo_gen_buffer_pinterest_boards_%%'
			    OR option_name LIKE '_transient_timeout_seo_gen_buffer_pinterest_boards_%%'"
		);

		return array('buffer' => $buffer_cleaned, 'jetpack' => $jetpack_cleaned);
	}

	/**
	 * Get plugin version
	 *
	 * @return string
	 */
	public function get_version()
	{
		return SEO_GEN_VERSION;
	}

	/**
	 * Add SEO score & downloads columns to post list
	 *
	 * @param array $columns Existing columns
	 * @return array Modified columns
	 */
	public function add_seo_gen_post_columns($columns)
	{
		// @MODIFIED 2025-12-05 v1.5.3: Add SEO score & downloads columns
		$columns['seo_gen_score'] = __('SEO Score', 'seo-article-generator');
		$columns['seo_gen_downloads'] = __('Downloads', 'seo-article-generator');
		return $columns;
	}

	/**
	 * Render SEO score & downloads columns
	 *
	 * @param string $column_name Column name
	 * @param int    $post_id Post ID
	 * @return void
	 */
	public function render_seo_gen_post_column($column_name, $post_id)
	{
		switch ($column_name) {
			case 'seo_gen_score':
				// @MODIFIED 2025-12-05 v1.5.3: Add SEO score column
				// @MODIFIED 2025-12-11 v1.8.1: Add staleness warning
				$score = get_post_meta($post_id, '_seo_gen_validation_score', true);
				if ($score) {
					// Check for staleness: validation older than schema modification
					$validation_ts = get_post_meta($post_id, '_seo_gen_validation_timestamp', true);
					$schema_ts = get_post_meta($post_id, '_seo_gen_schema_modified', true);

					$is_stale = false;
					if ($validation_ts && $schema_ts && (int) $validation_ts < (int) $schema_ts) {
						$is_stale = true;
					}

					if ($is_stale) {
						echo '<span title="' . esc_attr__('Score may be outdated - content changed after validation', 'seo-article-generator') . '" style="color:#b45309;">⚠️ ' . esc_html($score) . '</span>';
					} else {
						echo esc_html($score);
					}
				} else {
					echo __('N/A', 'seo-article-generator');
				}
				break;
			case 'seo_gen_downloads':
				// @MODIFIED 2025-12-05 v1.5.3: Add downloads column
				// @MODIFIED 2026-01-06 v2.16.0: Fixed meta key mismatch (was _seo_gen_downloads, now _seo_gen_download_count)
				$downloads = get_post_meta($post_id, '_seo_gen_download_count', true);
				if ($downloads) {
					echo $downloads;
				} else {
					echo __('N/A', 'seo-article-generator');
				}
				break;
		}
	}

	/**
	 * AJAX: Detect RankMath Software template ID from existing posts
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function ajax_detect_rankmath_template()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			global $wpdb;

			// @MODIFIED 2026-01-01 v2.10.1: Fetch rows and decode JSON in PHP (not GROUP BY JSON blob)
			$rows = $wpdb->get_results(
				"SELECT post_id, meta_value
				 FROM {$wpdb->postmeta}
				 WHERE meta_key = 'rank_math_schema_SoftwareApplication'
				 LIMIT 500",
				ARRAY_A
			);

			if (empty($rows)) {
				wp_send_json_success(
					array(
						'template_id' => null,
						'confidence' => 0,
						'message' => 'No RankMath Software schemas found',
					)
				);
				return;
			}

			// Count by template ID in PHP
			$template_counts = array();
			foreach ($rows as $row) {
				$schema = json_decode($row['meta_value'], true);
				if (!empty($schema['metadata']['template'])) {
					$template_id = $schema['metadata']['template'];
					if (!isset($template_counts[$template_id])) {
						$template_counts[$template_id] = 0;
					}
					$template_counts[$template_id]++;
				}
			}

			if (empty($template_counts)) {
				wp_send_json_success(
					array(
						'template_id' => null,
						'confidence' => 0,
						'message' => 'Found schemas but no template IDs',
					)
				);
				return;
			}

			// Sort by count descending
			arsort($template_counts);

			// Build candidates list
			$candidates = array();
			foreach ($template_counts as $id => $count) {
				$candidates[] = array(
					'id' => $id,
					'count' => $count,
				);
				if (count($candidates) >= 5) {
					break;
				}
			}

			// If single candidate, return it
			if (count($candidates) === 1) {
				wp_send_json_success(
					array(
						'template_id' => $candidates[0]['id'],
						'confidence' => $candidates[0]['count'],
						'candidates' => null,
					)
				);
				return;
			}

			// Multiple candidates - return for user selection
			wp_send_json_success(
				array(
					'template_id' => $candidates[0]['id'], // Most common
					'confidence' => $candidates[0]['count'],
					'candidates' => $candidates,
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Template detection failed: ' . $e->getMessage());
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Start RankMath schema migration
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function ajax_start_migration()
	{
		Integration\RankMath_Migration::ajax_start_migration();
	}

	/**
	 * AJAX: Process migration batch
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function ajax_process_migration_batch()
	{
		Integration\RankMath_Migration::ajax_process_batch();
	}

	/**
	 * AJAX: Delete a log file
	 *
	 * @MODIFIED 2026-03-04: Backend handler for log deletion
	 * 
	 * @return void
	 */
	public function ajax_delete_log()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!\current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$filename = isset($_POST['log_file']) ? \sanitize_text_field($_POST['log_file']) : '';

			if (!$filename) {
				throw new \Exception('Missing log filename');
			}

			if ($this->logger->delete_log_file($filename)) {
				\wp_send_json_success(
					array(
						'message' => \__('Log file deleted successfully.', 'seo-article-generator'),
					)
				);
			} else {
				throw new \Exception(\__('Failed to delete log file.', 'seo-article-generator'));
			}
		} catch (\Throwable $e) {
			$this->logger->error('Log deletion failed: ' . $e->getMessage());
			\wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Delete all log files
	 * 
	 * @MODIFIED 2026-03-06: Bulk deletion for v2.26.0
	 */
	public function ajax_delete_all_logs()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!\current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$count = $this->logger->clear_all_logs();

			\wp_send_json_success(
				array(
					'message' => sprintf(\__('%d log files deleted successfully.', 'seo-article-generator'), $count),
				)
			);
		} catch (\Throwable $e) {
			$this->logger->error('Bulk log deletion failed: ' . $e->getMessage());
			\wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * AJAX: Load external debug log content (paginated)
	 */
	public function ajax_load_debug_log()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!\current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$file_path = isset($_POST['debug_log_path']) ? \sanitize_text_field(\wp_unslash($_POST['debug_log_path'])) : '';

			if ($file_path === '') {
				throw new \Exception(\__('No debug log path configured.', 'seo-article-generator'));
			}

			$info = $this->logger->get_external_log_info($file_path);
			if ($info === null) {
				throw new \Exception(\__('Debug log file not found or not readable. Check the path and file permissions.', 'seo-article-generator'));
			}

			$page = isset($_POST['debug_log_page']) ? max(1, (int) $_POST['debug_log_page']) : 1;
			$per_page = isset($_POST['debug_log_per_page']) ? max(10, min(500, (int) $_POST['debug_log_per_page'])) : 100;

			$result = $this->logger->read_external_log_paginated($file_path, $page, $per_page);

			if (empty($result)) {
				throw new \Exception(\__('Failed to read debug log file.', 'seo-article-generator'));
			}

			\wp_send_json_success(array(
				'content'     => implode("\n", $result['lines']),
				'size'        => $info['size'],
				'mtime'       => $info['mtime'],
				'page'        => $result['page'],
				'total_pages' => $result['total_pages'],
				'total_lines' => $result['total_lines'],
				'per_page'    => $result['per_page'],
			));
		} catch (\Throwable $e) {
			$this->logger->error('Debug log load failed: ' . $e->getMessage());
			\wp_send_json_error(array(
				'message' => $e->getMessage(),
			));
	}
 }

	/**
	 * AJAX: Save debug log path option
	 */
	public function ajax_save_debug_log_path()
	{
		try {
			\check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!\current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$file_path = isset($_POST['debug_log_path']) ? \sanitize_text_field(\wp_unslash($_POST['debug_log_path'])) : '';

			if ($file_path !== '' && strpos($file_path, '..') !== false) {
				throw new \Exception(\__('Path must not contain directory traversal sequences.', 'seo-article-generator'));
			}

			\update_option(\SEO_Article_Generator\Option_Registry::DEBUG_LOG_PATH, $file_path);

			$info = $file_path !== '' ? $this->logger->get_external_log_info($file_path) : null;

			\wp_send_json_success(array(
				'message'   => $file_path === '' ? \__('Debug log path cleared.', 'seo-article-generator') : \__('Debug log path saved.', 'seo-article-generator'),
				'file_info' => $info,
			));
		} catch (\Throwable $e) {
			$this->logger->error('Debug log path save failed: ' . $e->getMessage());
			\wp_send_json_error(array(
				'message' => $e->getMessage(),
			));
		}
	}

	/**
	 * AJAX: Download external debug log file
	 */
	public function ajax_download_debug_log()
	{
		if (!isset($_GET['_wpnonce']) || !\wp_verify_nonce($_GET['_wpnonce'], 'seo_gen_download_debug_log')) {
			\wp_die(\__('Security check failed.', 'seo-article-generator'));
		}

		if (!\current_user_can('manage_options')) {
			\wp_die(\__('Unauthorized', 'seo-article-generator'));
		}

		$file_path = (string) \get_option(\SEO_Article_Generator\Option_Registry::DEBUG_LOG_PATH, '');

		if ($file_path === '' || strpos($file_path, '..') !== false) {
			\wp_die(\__('No valid debug log path configured.', 'seo-article-generator'));
		}

		if (!\file_exists($file_path) || !\is_readable($file_path)) {
			\wp_die(\__('Debug log file does not exist or is not readable.', 'seo-article-generator'));
		}

		if (\ob_get_level()) {
			\ob_end_clean();
		}

		\header('Content-Description: File Transfer');
		\header('Content-Type: text/plain');
		\header('Content-Disposition: attachment; filename="' . \basename($file_path) . '"');
		\header('Expires: 0');
		\header('Cache-Control: must-revalidate');
		\header('Pragma: public');
		\header('Content-Length: ' . \filesize($file_path));

		\readfile($file_path);
		exit();
	}

	/**
	 * Get Discovery Processor
	 *
	 * @return Discovery\Discovery_Processor|null
	 */
	public function get_discovery_processor()
	{
		return $this->discovery_processor;
	}

	/**
	 * Get Job Handler
	 *
	 * @return Jobs\Job_Handler|null
	 */
	public function get_job_handler()
	{
		return $this->job_handler;
	}

/**
     * Get Logger
     *
     * @return Logger
     */
	public function get_logger()
	{
		return $this->logger;
	}

	/**
	 * Register REST API endpoints for Universal Plugin Dashboard
	 *
	 * @return void
	 */
	public function register_rest_endpoints()
	{
		// Only register if REST API is available
		if (!function_exists('register_rest_route')) {
			return;
		}

		// Metrics endpoint
		register_rest_route('wp/v2', '/metrics', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_metrics'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);

		// Status endpoint
		register_rest_route('wp/v2', '/status', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_status'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);
	}

	/**
	 * Verify Dashboard API Key
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public function verify_dashboard_key($request)
	{
		$api_key = $request->get_header('X-Dashboard-Key');
		$expected_key = get_option(Option_Registry::DASHBOARD_API_KEY, '');

		if (empty($expected_key)) {
			return new \WP_Error('unconfigured', 'Dashboard API key not configured', ['status' => 503]);
		}

		if (empty($api_key) || !hash_equals($expected_key, $api_key)) {
			return new \WP_Error('unauthorized', 'Invalid API key', ['status' => 401]);
		}

		return true;
	}

	/**
	 * REST API: Get plugin metrics for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_metrics($request)
	{
		global $wpdb;

		$jobs_table = Installer::table_jobs();
		$discovery_table = Installer::table_discovery();

		// Total posts generated (completed jobs)
		$total_posts = $wpdb->get_var("SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'completed'");

		// Today's posts (completed today in site timezone)
		$today_start = \SEO_Article_Generator\Utils\Plugin_Time::site_mysql_from_utc_ts(strtotime('today midnight'));
		$today_posts = $wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'completed' AND completed_at >= %s",
			$today_start
		));

		// Buffer shares today - use BUFFER_PUB_TRACKER option
		$buffer_shares_today = 0;
		if (class_exists('\\SEO_Article_Generator\\Integration\\Buffer_Integration')) {
			$tracker = get_option(Option_Registry::BUFFER_PUB_TRACKER, array('date' => '', 'ids' => array()));
			$today = gmdate('Y-m-d');
			if (isset($tracker['date']) && $tracker['date'] === $today && isset($tracker['ids']) && is_array($tracker['ids'])) {
				$buffer_shares_today = count($tracker['ids']);
			}
		}

		// Recent errors (last 50 failed jobs)
		$errors = $wpdb->get_results($wpdb->prepare(
			"SELECT error_message, completed_at as timestamp FROM {$jobs_table} 
			 WHERE status = 'failed' AND error_message != '' 
			 ORDER BY completed_at DESC LIMIT 50"
		));

		$error_logs = [];
		foreach ((array) $errors as $error) {
			$error_logs[] = [
				'message'   => $error->error_message,
				'timestamp' => $error->timestamp,
			];
		}

		// Health score based on success rate
		$total_completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobs_table} WHERE status IN ('completed', 'failed')");
		$total_failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'failed'");
		$health_score = $total_completed > 0 ? max(0, 100 - round(($total_failed / $total_completed) * 100)) : 100;

		// AI API metrics
		$ai_metrics = [];
		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client') && method_exists('\\SEO_Article_Generator\\AI\\AI_Client', 'get_dashboard_metrics')) {
			$ai_metrics = \SEO_Article_Generator\AI\AI_Client::get_dashboard_metrics();
		}

		// Quota status
		$quota = [];
		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client') && method_exists('\\SEO_Article_Generator\\AI\\AI_Client', 'get_daily_quota_status')) {
			$quota = \SEO_Article_Generator\AI\AI_Client::get_daily_quota_status();
		}

		// Queue stats
		$queue_stats = [];
		if (class_exists('\\SEO_Article_Generator\\Queue\\Job_Repository')) {
			$repo = new \SEO_Article_Generator\Queue\Job_Repository($wpdb);
			$queue_stats = $repo->get_queue_stats();
		}

		// Jetpack Stats (traffic/visitors)
		$traffic_stats = [];
		if (class_exists('\\SEO_Article_Generator\\Integration\\Jetpack_Integration')) {
			$jetpack = new \SEO_Article_Generator\Integration\Jetpack_Integration($this->logger);
			if ($jetpack::is_stats_available()) {
				$traffic_stats = $jetpack->get_site_stats('day');
			}
		}

		return rest_ensure_response([
			'total_posts_generated' => (int) $total_posts,
			'today_posts'           => (int) $today_posts,
			'buffer_shares_today'   => (int) $buffer_shares_today,
			'error_logs'            => $error_logs,
			'health_score'          => (int) $health_score,
			'last_updated'          => current_time('c'),
			'plugin_version'        => SEO_GEN_VERSION,
			'ai_metrics'            => $ai_metrics,
			'quota'                 => $quota,
			'queue_stats'           => $queue_stats,
			'traffic'               => $traffic_stats,
		]);
	}

	/**
	 * REST API: Get plugin status for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_status($request)
	{
		global $wpdb;

		// Check database connectivity
		$db_status = 'connected';
		try {
			$wpdb->get_var('SELECT 1');
		} catch (\Throwable $e) {
			$db_status = 'error';
		}

		// Check AI provider availability
		$ai_status = 'unknown';
		$ai_details = [];
		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client')) {
			$provider_status = \SEO_Article_Generator\AI\AI_Client::get_provider_status();
			$ai_status = $provider_status['enabled_count'] > 0 ? 'available' : 'unavailable';
			$ai_details = [
				'enabled_count'    => $provider_status['enabled_count'] ?? 0,
				'routable_providers' => $provider_status['routable'] ?? [],
				'paused'           => $provider_status['paused'] ?? false,
				'min_retry_after'  => $provider_status['min_retry_after'] ?? 0,
			];
		}

		// Check scheduled actions
		$scheduler_status = 'unknown';
		if (class_exists('ActionScheduler')) {
			$scheduler_status = 'active';
		}

		// Plugin version
		$version = SEO_GEN_VERSION;

		// Uptime (time since plugin activated)
		$activated_ts = get_option('seo_gen_activated_timestamp', time());
		$uptime = time() - $activated_ts;

		return rest_ensure_response([
			'status'           => 'active',
			'version'          => $version,
			'php_version'      => PHP_VERSION,
			'wp_version'       => get_bloginfo('version'),
			'uptime_seconds'   => $uptime,
			'database'         => $db_status,
			'ai_providers'     => $ai_status,
			'ai_details'       => $ai_details,
			'scheduler'        => $scheduler_status,
			'last_checked'     => current_time('c'),
		]);
	}

	/**
	 * AJAX: Generate Dashboard API Key
	 */
	public function ajax_generate_dashboard_key()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$key = wp_generate_password(32, false);
			update_option(Option_Registry::DASHBOARD_API_KEY, $key, false);

wp_send_json_success([
				'key' => $key,
				'message' => 'Dashboard API key generated successfully',
			]);
		} catch (\Throwable $e) {
			$this->logger->error('Dashboard key generation failed: ' . $e->getMessage());
			wp_send_json_error([
				'message' => $e->getMessage(),
			]);
		}
	}

	/**
	 * AJAX: Dry-run slug migration preview.
	 *
	 * @return void
	 */
	public function ajax_slug_dry_run()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			$limit = isset($_POST['limit']) ? absint($_POST['limit']) : 20;
			$limit = min(max($limit, 1), 100);

			$result = \SEO_Article_Generator\Utils\Canonical_Slug_Service::dry_run_migration($limit);

			wp_send_json_success($result);
		} catch (\Throwable $e) {
			$this->logger->error('Slug dry-run failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Run full slug migration.
	 *
	 * @return void
	 */
	public function ajax_slug_migrate()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			// Prevent PHP timeout during processing
			if (function_exists('set_time_limit')) {
				@set_time_limit(0);
			}

// Process one post per request to avoid gateway timeouts
		$batch_size = 1;

		// Allow override of redirect creation from UI checkbox (takes precedence over stored option)
		$disable_redirects = isset($_POST['disable_redirects']) ? filter_var($_POST['disable_redirects'], FILTER_VALIDATE_BOOLEAN) : false;
		if ($disable_redirects) {
			\SEO_Article_Generator\Utils\Canonical_Slug_Service::set_skip_redirect_creation(true);
		}

		$result = \SEO_Article_Generator\Utils\Canonical_Slug_Service::run_migration($batch_size);

			wp_send_json_success($result);
		} catch (\Throwable $e) {
			$this->logger->error('Slug migration failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

/**
	 * AJAX: Rollback slug migration.
	 *
	 * @return void
	 */
	public function ajax_slug_rollback()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			$result = \SEO_Article_Generator\Utils\Canonical_Slug_Service::rollback_migration();

			wp_send_json_success($result);
		} catch (\Throwable $e) {
			$this->logger->error('Slug rollback failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Clear all Rank Math redirections.
	 *
	 * @return void
	 */
	public function ajax_slug_clear_redirections()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			if (!\SEO_Article_Generator\Utils\Canonical_Slug_Service::is_rankmath_redirections_active()) {
				wp_send_json_error(['message' => 'Rank Math Redirections module not active']);
			}

			global $wpdb;
			$table = $wpdb->prefix . 'rank_math_redirections';

			$deleted = $wpdb->query("DELETE FROM $table WHERE status = 'active' OR status = 'inactive'");

			if ($deleted === false) {
				wp_send_json_error(['message' => 'Failed to delete redirections: ' . $wpdb->last_error]);
			}

			// Also clear transients/cache
			\wp_cache_delete('rank_math_redirections', 'rank_math');

			// Reset migration state so next run starts fresh from offset 0
			delete_option('seo_gen_slug_migration_state');
			delete_option('seo_gen_slug_rollback_data');

			wp_send_json_success(['deleted' => $deleted]);
		} catch (\Throwable $e) {
			$this->logger->error('Clear redirections failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Get current migration state.
	 *
	 * @return void
	 */
	public function ajax_slug_state()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			$state = \SEO_Article_Generator\Utils\Canonical_Slug_Service::get_migration_state();

			wp_send_json_success($state);
		} catch (\Throwable $e) {
			$this->logger->error('Slug state check failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Update internal links for migrated slugs.
	 *
	 * @return void
	 */
	public function ajax_update_internal_links()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			if (function_exists('set_time_limit')) {
				@set_time_limit(0);
			}

			$result = \SEO_Article_Generator\Utils\Canonical_Slug_Service::run_link_update();

			wp_send_json_success($result);
		} catch (\Throwable $e) {
			$this->logger->error('Internal links update failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Rollback internal links updates.
	 *
	 * @return void
	 */
	public function ajax_rollback_internal_links()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			$result = \SEO_Article_Generator\Utils\Canonical_Slug_Service::rollback_link_updates();

			wp_send_json_success($result);
		} catch (\Throwable $e) {
			$this->logger->error('Internal links rollback failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}

	/**
	 * AJAX: Get link update state.
	 *
	 * @return void
	 */
	public function ajax_link_update_state()
	{
		try {
			check_ajax_referer('seo_gen_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				wp_send_json_error(['message' => 'Insufficient permissions'], 403);
			}

			$state = \SEO_Article_Generator\Utils\Canonical_Slug_Service::get_link_update_state();

			wp_send_json_success($state);
		} catch (\Throwable $e) {
			$this->logger->error('Link update state check failed: ' . $e->getMessage());
			wp_send_json_error(['message' => $e->getMessage()]);
		}
	}
}
