<?php

/**
 * AJAX Handler for updating video URL after client-side export
 *
 * Handles:
 * 1. Local server upload (uploads/mcq-video-studio/generated/)
 * 2. R2 upload (Cloudflare R2 - for Buffer/social upload)
 * 3. Buffer push after R2 upload (when delivery_mode = r2_buffer)
 * 4. Updates job and project with video URL
 *
 * @package MCQ_Video_Studio
 * @subpackage Includes
 * @since 1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Video_URL_Handler
{
    public static function init()
    {
        add_action('wp_ajax_mcqvs_update_video_url', array(__CLASS__, 'handle_update_video_url'));
        add_action('wp_ajax_mcqvs_upload_to_r2', array(__CLASS__, 'handle_r2_upload'));
    }

    /**
     * Update video_url in job and/or project
     * Handles local upload, R2 upload, or just URL update
     * Supports $_FILES['video_blob'] for direct blob upload from JS
     */
    public static function handle_update_video_url()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $project_id = isset($_POST['project_id']) ? absint($_POST['project_id']) : 0;
        $video_url = esc_url_raw($_POST['video_url'] ?? '');
        $save_mode = sanitize_text_field($_POST['save_mode'] ?? 'local');

        if (empty($job_id) && empty($project_id)) {
            wp_send_json_error('Job ID or Project ID required');
        }

        $delivery_mode = get_option('mcqvs_delivery_mode', 'local');

        if ($save_mode === 'local' && $delivery_mode === 'local') {
            wp_send_json_success(array(
                'message'   => 'Local mode: no server upload needed',
                'job_id'    => $job_id,
                'project_id' => $project_id,
                'method'    => 'local',
            ));
        }

        $upload_url = '';
        $upload_method = $save_mode;
        $r2_enabled = !empty(get_option('mcqvs_r2_endpoint', '')) &&
            !empty(get_option('mcqvs_r2_access_key', ''));

        $effective_mode = ($save_mode === 'r2' || $save_mode === 'r2_buffer') ? $save_mode : $delivery_mode;

        if (class_exists('VS_Error_Logger') && !empty($job_id)) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'upload.started',
                'started',
                $job_id,
                "Video upload starting for job {$job_id} (mode: {$effective_mode})",
                'info',
                array('job_id' => $job_id, 'save_mode' => $save_mode, 'effective_mode' => $effective_mode)
            );
        }

        if ($effective_mode === 'server' || (($effective_mode === 'r2' || $effective_mode === 'r2_buffer') && !$r2_enabled)) {
            $upload_start = microtime(true);
            $upload_url = self::handle_local_upload($job_id, $project_id);
            $upload_method = 'server';
        } elseif (($effective_mode === 'r2' || $effective_mode === 'r2_buffer') && $r2_enabled) {
            $upload_start = microtime(true);
            $upload_url = self::handle_r2_upload_from_request($job_id, $project_id);
            $upload_method = 'r2';
        } else {
            $upload_start = microtime(true);
            $upload_url = $video_url;
        }

        if (is_wp_error($upload_url)) {
            if (!empty($job_id) && class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'upload.failed',
                    'failed',
                    $job_id,
                    "Video upload failed for job {$job_id}: " . $upload_url->get_error_message(),
                    'error',
                    array('job_id' => $job_id, 'error' => $upload_url->get_error_message(), 'method' => $upload_method)
                );
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            } elseif (!empty($job_id)) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            }
            wp_send_json_error('Video upload failed: ' . $upload_url->get_error_message());
        }

        if (empty($upload_url)) {
            if (!empty($job_id) && class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'upload.failed',
                    'failed',
                    $job_id,
                    "Video upload returned empty URL for job {$job_id}",
                    'error',
                    array('job_id' => $job_id, 'method' => $upload_method)
                );
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            } elseif (!empty($job_id)) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            }
            wp_send_json_error('Video upload returned empty URL');
        }

        $success = true;
        $messages = array();

        if (!empty($job_id)) {
            $job_repo = VS_Job_Repository::init();
            $job = $job_repo->get_job($job_id);

            if (!$job || !VS_Job_Status::can_transition($job['status'], VS_Job_Status::UPLOADING)) {
                $job_repo->release_job_lock($job_id);
                wp_send_json_error('Cannot transition job from ' . ($job['status'] ?? 'missing') . ' to uploading');
            }

            $job_repo->update_status($job_id, VS_Job_Status::UPLOADING);

            $url_updated = $job_repo->update_video_url($job_id, $upload_url);
            if ($url_updated === false) {
                $job_repo->update_status($job_id, VS_Job_Status::FAILED, array(
                    'error_message' => 'Failed to persist video URL after upload'
                ));
                $job_repo->release_job_lock($job_id);
                wp_send_json_error('Failed to update video URL in database');
            }

            $messages[] = 'Job video_url updated';

            if (class_exists('VS_Error_Logger')) {
                $upload_duration_ms = isset($upload_start) ? (int) round((microtime(true) - $upload_start) * 1000) : -1;
                VS_Error_Logger::get_instance()->log_pipeline(
                    'upload.completed',
                    'completed',
                    $job_id,
                    "Video uploaded for job {$job_id} (method: {$upload_method}, duration: {$upload_duration_ms}ms)",
                    'info',
                    array('job_id' => $job_id, 'video_url' => $upload_url, 'method' => $upload_method, 'duration_ms' => $upload_duration_ms)
                );
            }
        }

        if (!empty($project_id)) {
            $project_repo = VS_Project_Repository::init();
            $result = $project_repo->update_video_url($project_id, $upload_url);

            if ($result) {
                $project_repo->update_status($project_id, VS_Project_Status::COMPLETED, array(
                    'video_url' => $upload_url
                ));
                $messages[] = 'Project video_url updated';
            } else {
                $success = false;
            }
        }

        $buffer_result = null;
        if ($effective_mode === 'r2_buffer' && !empty($upload_url)) {
            // @FIX 2026-08-07: Always defer Buffer push to vs_publish_scheduled_cron.
            // The cron runs every 15 min, filters on publish_at <= now_gmt, and passes
            // Buffer the job's publish_at as scheduled_at. Buffer itself enforces the
            // schedule (addToQueue mode respects scheduled_at even when it's slightly
            // in the past; other modes post immediately). The upload callback MUST
            // NOT call push_to_buffer here — doing so either races the cron or, worse,
            // fires Buffer with a future scheduled_at that Buffer ignores and posts
            // immediately, bypassing the user's intended schedule.
            $deferred_publish_at = '';
            if (!empty($job_id) && class_exists('VS_Job_Repository')) {
                $deferred_job = VS_Job_Repository::init()->get_job($job_id);
                if ($deferred_job) {
                    $deferred_publish_at = $deferred_job['publish_at'] ?? '';
                }
            }
            $messages[] = 'Buffer push deferred to publish scheduler (publish_at=' . ($deferred_publish_at !== '' ? $deferred_publish_at : 'n/a') . ')';
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'buffer.push',
                    'deferred',
                    $job_id,
                    "Buffer push deferred to publish scheduler for job {$job_id} (save_mode=r2_buffer, publish_at=" . ($deferred_publish_at !== '' ? $deferred_publish_at : 'n/a') . ')',
                    'info',
                    array('job_id' => $job_id, 'video_url' => $upload_url, 'publish_at' => $deferred_publish_at !== '' ? $deferred_publish_at : null)
                );
            }
        }

        if (!empty($job_id)) {
            $job_repo = VS_Job_Repository::init();
            if (in_array($upload_method, array('r2', 'server', 'local'), true)) {
                $job_repo->update_status($job_id, VS_Job_Status::COMPLETED, array(
                    'video_url' => $upload_url
                ));
                if (class_exists('VS_Error_Logger')) {
                    $log_context = array(
                        'job_id' => $job_id,
                        'video_url' => $upload_url,
                        'method' => $upload_method,
                    );
                    if ($buffer_result !== null && !is_wp_error($buffer_result)) {
                        $log_context['buffer_result'] = $buffer_result;
                    }
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'job.completed',
                        'completed',
                        $job_id,
                        "Job {$job_id} finalized as completed (method: {$upload_method})",
                        'info',
                        $log_context
                    );
                }
            }
            $job_repo->release_job_lock($job_id);
        }

        if ($success) {
            $response_data = array(
                'message'      => implode(', ', $messages),
                'job_id'       => $job_id,
                'project_id'   => $project_id,
                'video_url'    => $upload_url,
                'method'       => $upload_method,
            );
            if ($buffer_result !== null && !is_wp_error($buffer_result)) {
                $response_data['buffer'] = $buffer_result;
            }
            wp_send_json_success($response_data);
        } else {
            wp_send_json_error('Failed to update video URL in database');
        }
    }

    /**
     * @NEW 2026-07-18 (server-side render): Upload an already-rendered local MP4
     *              file for a job, reusing the exact same local/R2 delivery paths
     *              the browser upload uses — but with NO admin-ajax nonce, because
     *              the file is produced server-side by render-node.js.
     *
     * @param string $job_id
     * @param string $local_mp4 absolute path to the rendered MP4
     * @param string $save_mode 'local' | 'r2' | 'r2_buffer' | '' (falls back to delivery_mode)
     * @return string|WP_Error public video URL on success
     */
    public static function upload_local_file_for_job($job_id, $local_mp4, $save_mode = '')
    {
        $job_id    = sanitize_text_field($job_id);
        $delivery  = get_option('mcqvs_delivery_mode', 'local');
        $mode      = in_array($save_mode, array('local', 'r2', 'r2_buffer'), true) ? $save_mode : $delivery;
        $r2_enabled = !empty(get_option('mcqvs_r2_endpoint', '')) && !empty(get_option('mcqvs_r2_access_key', ''));

        if (class_exists('VS_Error_Logger') && $job_id) {
            VS_Error_Logger::get_instance()->log_pipeline('upload.started', 'started', $job_id, "Server render upload for {$job_id} (mode: {$mode})", 'info', array('job_id' => $job_id, 'mode' => $mode));
        }

        if ($mode === 'local') {
            $url = self::handle_local_upload($job_id, 0, $local_mp4);
            return $url;
        }

        if (($mode === 'r2' || $mode === 'r2_buffer') && $r2_enabled) {
            // Stage the rendered file as a PHP-managed temp upload so the existing
            // R2 path (which reads from a temp file path) can consume it unchanged.
            $tmp = tempnam(sys_get_temp_dir(), 'mcqvs_r2_');
            if ($tmp === false || !@copy($local_mp4, $tmp)) {
                return new WP_Error('stage_failed', 'Could not stage rendered file for R2 upload.');
            }
            $url = self::handle_r2_upload_from_path($job_id, 0, $tmp);
            @unlink($tmp);
            return $url;
        }

        // Mode wants R2 but R2 not configured → fall back to local.
        $url = self::handle_local_upload($job_id, 0, $local_mp4);
        return $url;
    }

    /**
     * @NEW 2026-07-18: R2 upload variant that reads from an explicit local path
     *              (instead of $_FILES / base64 POST), so server-rendered files
     *              reuse the same VS_R2_Storage logic as browser uploads.
     */
    private static function handle_r2_upload_from_path($job_id, $project_id, $local_path)
    {
        if (!@is_readable($local_path)) {
            return new WP_Error('no_file', 'Render file not readable: ' . $local_path);
        }
        $key  = 'videos/' . ($job_id ?: 'project_' . $project_id) . '_' . time() . '.mp4';
        $r2   = new VS_R2_Storage();
        $r2_url = $r2->upload_file($local_path, $key, 'video/mp4');
        return $r2_url;
    }

    /**
     * Handle R2 upload from POST data (base64 or blob)
     * Legacy endpoint for direct R2 uploads
     */
    public static function handle_r2_upload()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $project_id = isset($_POST['project_id']) ? absint($_POST['project_id']) : 0;

        $temp_info = self::get_video_temp_file($job_id, $project_id);
        if (is_wp_error($temp_info)) {
            wp_send_json_error($temp_info->get_error_message());
        }

        $temp_file = $temp_info['path'];
        $key = 'videos/' . ($job_id ?: 'project_' . $project_id) . '_' . time() . '.mp4';

        $r2 = new VS_R2_Storage();
        $r2_url = $r2->upload_file($temp_file, $key, 'video/mp4');

        if (!$temp_info['php_managed']) {
            @unlink($temp_file);
        }

        if (is_wp_error($r2_url)) {
            if (!empty($job_id)) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            }
            wp_send_json_error('R2 upload failed: ' . $r2_url->get_error_message());
        }

        if (!empty($job_id)) {
            $job_repo = VS_Job_Repository::init();
            $job_repo->update_video_url($job_id, $r2_url);
            $job_repo->update_status($job_id, VS_Job_Status::UPLOADING);
            $job_repo->update_status($job_id, VS_Job_Status::COMPLETED, array(
                'video_url' => $r2_url
            ));
            $job_repo->release_job_lock($job_id);
        }

        if (!empty($project_id)) {
            $project_repo = VS_Project_Repository::init();
            $project_repo->update_video_url($project_id, $r2_url);
            $project_repo->update_status($project_id, VS_Project_Status::COMPLETED);
        }

        $buffer_result = null;
        if (!empty($job_id) && !empty($r2_url)) {
            $job_repo_buf = VS_Job_Repository::init();
            $job_buf = $job_repo_buf->get_job($job_id);
            $job_save_mode = 'local';
            if ($job_buf && !empty($job_buf['settings'])) {
                $job_settings = json_decode($job_buf['settings'], true);
                $job_save_mode = $job_settings['save_mode'] ?? 'local';
            }
            if ($job_save_mode === 'r2_buffer') {
                // @FIX 2026-08-07: Same deferral as the primary upload path — the
                // vs_publish_scheduled_cron is the sole Buffer entry point.
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'buffer.push',
                        'deferred',
                        $job_id,
                        "Buffer push deferred to publish scheduler (R2 path, job {$job_id}, publish_at=" . ($job_buf['publish_at'] ?? 'n/a') . ')',
                        'info',
                        array('job_id' => $job_id, 'video_url' => $r2_url, 'publish_at' => $job_buf['publish_at'] ?? null)
                    );
                }
            }
        }

        $response_data = array(
            'video_url' => $r2_url,
            'job_id' => $job_id,
            'project_id' => $project_id
        );
        if ($buffer_result !== null && !is_wp_error($buffer_result)) {
            $response_data['buffer'] = $buffer_result;
        }

        wp_send_json_success($response_data);
    }

    /**
     * R2 upload from current request (supports $_FILES blob + base64 fallback)
     */
    private static function handle_r2_upload_from_request($job_id, $project_id)
    {
        $temp_info = self::get_video_temp_file($job_id, $project_id);
        if (is_wp_error($temp_info)) {
            return $temp_info;
        }

        $temp_file = $temp_info['path'];
        $key = 'videos/' . ($job_id ?: 'project_' . $project_id) . '_' . time() . '.mp4';

        $r2 = new VS_R2_Storage();
        $r2_url = $r2->upload_file($temp_file, $key, 'video/mp4');

        if (!$temp_info['php_managed']) {
            @unlink($temp_file);
        }

        return $r2_url;
    }

    /**
     * Extract video data from request as a temp file.
     * Priority: $_FILES['video_blob'] > $_POST['video_data'] (base64)
     *
     * @param string $job_id
     * @param int    $project_id
     * @return array|WP_Error Array with 'path' and 'php_managed' keys, or WP_Error
     */
    private static function get_video_temp_file($job_id, $project_id)
    {
        if (!empty($_FILES['video_blob']) && $_FILES['video_blob']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['video_blob'];
            $mime = mime_content_type($file['tmp_name']);

            if ($mime !== 'video/mp4' && $mime !== 'application/octet-stream') {
                return new WP_Error('invalid_mime', 'Invalid file type: ' . $mime);
            }

            return array('path' => $file['tmp_name'], 'php_managed' => true);
        }

        $video_data = $_POST['video_data'] ?? '';
        if (!empty($video_data)) {
            $decoded = base64_decode($video_data);
            if ($decoded === false) {
                return new WP_Error('decode_error', 'Failed to decode video data');
            }

            $temp_file = tempnam(sys_get_temp_dir(), 'mcqvs_video_');
            $written = file_put_contents($temp_file, $decoded);

            if ($written === false) {
                @unlink($temp_file);
                return new WP_Error('write_error', 'Failed to write temp file');
            }

            return array('path' => $temp_file, 'php_managed' => false);
        }

        return new WP_Error('no_data', 'No video data provided. Send video_blob as file or video_data as base64.');
    }

    /**
     * Handle local server upload (supports $_FILES blob + base64 + explicit path)
     *
     * @param string $job_id
     * @param int    $project_id
     * @param string $explicit_path Optional absolute path to an already-rendered file
     *                              (used by the server-side Node renderer).
     */
    private static function handle_local_upload($job_id, $project_id, $explicit_path = null)
    {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/mcq-video-studio/generated';

        if (!file_exists($base_dir)) {
            wp_mkdir_p($base_dir);
        }

        $filename = 'video_' . ($job_id ?: 'project_' . $project_id) . '_' . time() . '.mp4';
        $target_path = $base_dir . '/' . $filename;

        if (!empty($explicit_path)) {
            if (!@copy($explicit_path, $target_path)) {
                return new WP_Error('copy_failed', 'Failed to copy rendered video to uploads directory.');
            }
            return $upload_dir['baseurl'] . '/mcq-video-studio/generated/' . $filename;
        }

        if (!empty($_FILES['video_blob']) && $_FILES['video_blob']['error'] === UPLOAD_ERR_OK) {
            move_uploaded_file($_FILES['video_blob']['tmp_name'], $target_path);
        } else {
            $video_data = $_POST['video_data'] ?? '';
            if (!empty($video_data)) {
                $decoded = base64_decode($video_data);
                if ($decoded === false) {
                    return new WP_Error('decode_error', 'Invalid video data');
                }
                file_put_contents($target_path, $decoded);
            } else {
                return new WP_Error('no_data', 'No video data provided. Send video_blob as file or video_data as base64.');
            }
        }

        return $upload_dir['baseurl'] . '/mcq-video-studio/generated/' . $filename;
    }

    /**
     * Push video to Buffer for social media posting.
     * Delegates to VS_Buffer_Client::push_job_to_buffer for shared cron + AJAX path.
     *
     * @param string $job_id
     * @param int    $project_id
     * @param string $video_url Public R2 URL of the video
     * @return array|WP_Error
     */
    private static function push_to_buffer($job_id, $project_id, $video_url)
    {
        if (empty($job_id)) {
            return new WP_Error('no_job', 'Job ID required for Buffer push.');
        }

        $buffer_token = get_option('mcqvs_buffer_access_token', '');
        if (empty($buffer_token)) {
            VS_Error_Logger::get_instance()->log('Buffer push skipped: No access token', 'warning');
            return new WP_Error('no_token', 'Buffer access token not configured');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (!$job) {
            return new WP_Error('no_job', 'Job not found.');
        }

        VS_Error_Logger::get_instance()->log_pipeline(
            'buffer.push',
            'started',
            $job_id,
            "Buffer push started for job {$job_id}",
            'info',
            array('job_id' => $job_id, 'video_url' => $video_url)
        );

        $result = VS_Buffer_Client::push_job_to_buffer($job_id, $video_url, $job);

        if (is_wp_error($result)) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'buffer.push',
                'failed',
                $job_id,
                "Buffer push failed for job {$job_id}: " . $result->get_error_message(),
                'error',
                array('job_id' => $job_id, 'video_url' => $video_url, 'error' => $result->get_error_message())
            );
            return $result;
        }

        $post_ids = array();
        if (is_array($result) && !empty($result['results'])) {
            foreach ($result['results'] as $r) {
                if (is_array($r) && isset($r['post']['id'])) {
                    $post_ids[] = $r['post']['id'];
                }
            }
        }

        VS_Error_Logger::get_instance()->log_pipeline(
            'buffer.push',
            'completed',
            $job_id,
            "Buffer push completed for job {$job_id} - " . count($post_ids) . " post(s) created",
            'info',
            array('job_id' => $job_id, 'video_url' => $video_url, 'buffer_post_ids' => $post_ids, 'result' => $result)
        );

        return $result;
    }

    /**
     * Get internal R2 path (for Buffer/social upload, not public)
     */
    public static function get_internal_r2_path($video_url)
    {
        $r2_bucket = get_option('mcqvs_r2_bucket', '');

        if (empty($r2_bucket)) {
            return $video_url;
        }

        if (strpos($video_url, $r2_bucket) !== false) {
            $parts = explode($r2_bucket . '/', $video_url);
            return isset($parts[1]) ? $parts[1] : $video_url;
        }

        return $video_url;
    }
}
