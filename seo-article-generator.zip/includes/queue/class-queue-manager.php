<?php

/**
 * Queue Manager — public API for enqueuing jobs
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * High-level convenience class for enqueuing jobs.
 * Used by the Scheduler and Bootstrap to push work into the queue.
 */
/**
 * Convenience class for enqueuing jobs.
 */
class Queue_Manager
{
    /**
     * @var Job_Repository
     */
    private $repository;

    /**
     * @param Job_Repository $repository Repository instance.
     */
    public function __construct(Job_Repository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Enqueue a draft for processing (idempotent — skips if already open).
     *
     * @param int   $draft_id Draft post ID.
     * @param array $payload Optional extra context.
     * @return int Existing or newly created job ID.
     */
    public function enqueue_draft($draft_id, $payload = array())
    {
        return $this->repository->enqueue_unique(
            Job_Types::PROCESS_DRAFT,
            (int) $draft_id,
            $payload
        );
    }

    /**
     * Enqueue a discovery cleanup job (idempotent).
     *
     * @return int Existing or newly created job ID.
     */
    public function enqueue_discovery_cleanup()
    {
        return $this->repository->enqueue_unique(
            Job_Types::CLEANUP_DISCOVERY,
            0
        );
    }

    /**
     * Enqueue a retention cleanup job (idempotent).
     *
     * @return int Existing or newly created job ID.
     */
    public function enqueue_retention_cleanup()
    {
        return $this->repository->enqueue_unique(
            Job_Types::CLEANUP_RETENTION,
            0
        );
    }
}
