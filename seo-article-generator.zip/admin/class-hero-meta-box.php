<?php

/**
 * Hero Meta Box
 * @MODIFIED 2025-12-04 v1.4.0: Custom meta box for editing hero section data
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Admin;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Registers and handles hero section meta box
 */
class Hero_Meta_Box
{
    /**
     * Initialize meta box
     *
     * @return void
     */
    public static function init()
    {
        \add_action('add_meta_boxes', array(__CLASS__, 'register_meta_box'));
        \add_action('save_post', array(__CLASS__, 'save_meta_box'), 10, 2);
        \add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }

    /**
     * Register meta box
     * @MODIFIED 2025-12-04 v1.4.0: Add hero data meta box to post editor
     *
     * @return void
     */
    public static function register_meta_box()
    {
        \add_meta_box(
            'seo_gen_hero_meta',
            \__('Hero Section Data', 'seo-article-generator'),
            array(__CLASS__, 'render_meta_box'),
            'post',
            'normal', // Full-width for better UX
            'high'
        );
    }

    /**
     * Enqueue meta box assets
     * @MODIFIED 2025-12-04 v1.4.0: Enqueue JS for repeater field
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public static function enqueue_assets($hook)
    {
        if ('post.php' !== $hook && 'post-new.php' !== $hook) {
            return;
        }

        // Enqueue WordPress media uploader (in case we add image later)
        \wp_enqueue_media();

        // Enqueue repeater field JS
        // @MODIFIED 2025-12-28: Cache bust via file modification time
        // @MODIFIED 2026-01-07: Added jquery-ui-sortable dependency
        $meta_js = SEO_GEN_PLUGIN_DIR . 'assets/js/admin-hero-meta-box.js';
        \wp_enqueue_script(
            'seo-gen-hero-meta-box',
            SEO_GEN_PLUGIN_URL . 'assets/js/admin-hero-meta-box.js',
            array('jquery', 'jquery-ui-sortable'),
            \file_exists($meta_js) ? \filemtime($meta_js) : SEO_GEN_VERSION,
            true
        );

        $meta_css = SEO_GEN_PLUGIN_DIR . 'assets/css/admin-hero-meta-box.css';
        \wp_enqueue_style(
            'seo-gen-hero-meta-box',
            SEO_GEN_PLUGIN_URL . 'assets/css/admin-hero-meta-box.css',
            array(),
            \file_exists($meta_css) ? \filemtime($meta_css) : SEO_GEN_VERSION
        );
    }

    /**
     * Render meta box
     * @MODIFIED 2025-12-04 v1.4.0: Form fields for hero data
     *
     * @param \WP_Post $post Current post object
     * @return void
     */
    public static function render_meta_box($post)
    {
        // Nonce field
        \wp_nonce_field('seo_gen_hero_meta', 'seo_gen_hero_meta_nonce');

        // @MODIFIED 2026-01-03: Refactored to read from Source of Truth (Schema + Overrides)
        // This ensures the editor always shows the intended state, even if the derived cache is stale.

        $hero_data = array();
        $schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema($post->ID);

        if ($schema) {
            // Generated Post: Load overrides and re-derive hero data on-the-fly
            $overrides = get_post_meta($post->ID, '_seo_gen_hero_overrides', true);
            if (!is_array($overrides)) {
                $overrides = array();
            }

            // [SSOT-FIX 2026-07-25] Strip SSOT-managed fields from the read path so stale
            // _seo_gen_hero_overrides cannot leak through Hero_Data_Provider::from_schema() and
            // override schema-derived version / last_updated / last_verified_date in the
            // rendered admin form. Hero_Data_Provider::from_schema() honors ALLOWED_OVERRIDES,
            // so any of these three keys present in $overrides would clobber the freshly-computed
            // canonical version (from $schema->tech_specs->version) and today's date (date()).
            // Source-of-truth is enforced centrally in save_schema() (line ~147) on the auto
            // path AND in apply_hero_overrides() (just before persisting) on the admin save path.
            foreach ( array( 'version', 'last_updated', 'last_verified_date' ) as $_ssot_field ) {
                unset( $overrides[ $_ssot_field ] );
            }

            // @MODIFIED 2026-05-23: Merge persisted download_links into overrides so
            // manual edits appear in the rendered form instead of the original schema links.
            $persisted_links = get_post_meta($post->ID, '_seo_gen_hero_download_links', true);
            if (is_array($persisted_links)) {
                $overrides['download_links'] = $persisted_links;
            }

            $hero_data = \SEO_Article_Generator\Generator\Hero_Data_Provider::from_schema($schema, $overrides, $post->ID);
        } else {
            // Manual Post: Load via canonical accessor (reads both keys with fallback)
            $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post->ID);
            if (!is_array($hero_data)) {
                $hero_data = array();
            }
        }

        // Default values
        $software_name = isset($hero_data['software_name']) ? $hero_data['software_name'] : '';
        $version = isset($hero_data['version']) ? $hero_data['version'] : '';
        $license = isset($hero_data['license']) ? $hero_data['license'] : '';
        $license_details = isset($hero_data['license_details']) ? $hero_data['license_details'] : '';
        $file_size = isset($hero_data['file_size']) ? $hero_data['file_size'] : '';
        $rating = isset($hero_data['rating']) ? $hero_data['rating'] : 0;
        // @MODIFIED 2025-12-15 v2.2.0: Neutral default instead of false security claim
        $security_badge = isset($hero_data['security_badge']) ? $hero_data['security_badge'] : 'Download Available';
        $download_links = isset($hero_data['download_links']) && is_array($hero_data['download_links'])
            ? $hero_data['download_links']
            : array();
        // @MODIFIED 2025-12-14 v2.1.0: App Store style fields
        $logo_url = isset($hero_data['logo_url']) ? $hero_data['logo_url'] : '';
        $publisher = isset($hero_data['publisher']) ? $hero_data['publisher'] : '';
        $category = isset($hero_data['application_category']) ? $hero_data['application_category'] : (isset($hero_data['category']) ? $hero_data['category'] : '');
        $author_name = isset($hero_data['author_name']) ? $hero_data['author_name'] : '';
        // @since 2.6.1: Software last updated date for specs grid
        $last_updated = isset($hero_data['last_updated']) ? $hero_data['last_updated'] : '';
        // @MODIFIED 2026-03-07: Fetch last verified date for E-E-A-T field
        // Canonical key is last_verified_date; legacy fallback for old data
        $last_verified = isset($hero_data['last_verified_date']) ? $hero_data['last_verified_date'] : (isset($hero_data['last_verified']) ? $hero_data['last_verified'] : '');
?>
        <div class="seo-gen-hero-meta-box">
            <div class="seo-gen-hero-fields">
                <!-- @MODIFIED 2025-12-14 v2.1.0: App Store Style Logo Picker -->
                <div class="seo-gen-field seo-gen-logo-field">
                    <label><?php \_e('Software Logo', 'seo-article-generator'); ?></label>
                    <div class="seo-gen-logo-picker">
                        <div class="seo-gen-logo-preview" id="hero_logo_preview">
                            <?php if ($logo_url): ?>
                                <img src="<?php echo \esc_url($logo_url); ?>" alt="Logo">
                            <?php else: ?>
                                <span class="seo-gen-logo-placeholder">No Logo</span>
                            <?php endif; ?>
                        </div>
                        <div class="seo-gen-logo-buttons">
                            <button type="button" class="button" id="seo-gen-select-logo">
                                <?php \_e('Select Logo', 'seo-article-generator'); ?>
                            </button>
                            <button type="button" class="button" id="seo-gen-remove-logo" <?php echo $logo_url ? '' : 'style="display:none;"'; ?>>
                                <?php \_e('Remove', 'seo-article-generator'); ?>
                            </button>
                        </div>
                        <!-- @MODIFIED 2025-12-24 v2.6.1: Direct URL input for images not in media library -->
                        <div class="seo-gen-logo-url-input">
                            <label for="hero_logo_url_direct"><?php \_e('Or paste image URL:', 'seo-article-generator'); ?></label>
                            <div class="seo-gen-logo-url-row">
                                <input type="url"
                                    id="hero_logo_url_direct"
                                    value="<?php echo \esc_url($logo_url); ?>"
                                    placeholder="https://example.com/uploads/logo.png"
                                    class="widefat">
                                <button type="button" class="button" id="seo-gen-apply-logo-url">
                                    <?php \_e('Apply', 'seo-article-generator'); ?>
                                </button>
                            </div>
                        </div>
                        <input type="hidden" id="hero_logo_url" name="hero_logo_url" value="<?php echo \esc_url($logo_url); ?>">
                    </div>
                    <p class="description"><?php \_e('80×80px recommended. Select from media library or paste a direct URL for images in uploads folder.', 'seo-article-generator'); ?></p>
                </div>

                <!-- Software Name -->
                <div class="seo-gen-field">
                    <label for="hero_software_name"><?php \_e('Software Name', 'seo-article-generator'); ?></label>
                    <input type="text"
                        id="hero_software_name"
                        name="hero_software_name"
                        value="<?php echo \esc_attr($software_name); ?>"
                        class="widefat">
                </div>

                <!-- Row: Publisher + Category (App Store fields) -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_publisher"><?php \_e('Publisher', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_publisher"
                            name="hero_publisher"
                            value="<?php echo \esc_attr($publisher); ?>"
                            class="widefat"
                            placeholder="e.g., ConeXware, Inc.">
                    </div>
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_category"><?php \_e('Categories (Comma-separated)', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_category"
                            name="hero_category"
                            value="<?php echo \esc_attr($category); ?>"
                            class="widefat"
                            placeholder="e.g., Compression Utility, System Tools">
                        <p class="description"><?php \_e('First category displays in Hero, all categories passed to Schema.', 'seo-article-generator'); ?></p>
                    </div>
                </div>

                <!-- Row: Version + License -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_version"><?php \_e('Version', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_version"
                            name="hero_version"
                            value="<?php echo \esc_attr($version); ?>"
                            class="widefat"
                            placeholder="e.g., 3.0.20">
                    </div>
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_license"><?php \_e('License', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_license"
                            name="hero_license"
                            value="<?php echo \esc_attr($license); ?>"
                            class="widefat"
                            placeholder="e.g., Free, Trial, Premium">
                    </div>
                </div>

                <!-- Row: License Details + File Size -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_license_details"><?php \_e('License Details', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_license_details"
                            name="hero_license_details"
                            value="<?php echo \esc_attr($license_details); ?>"
                            class="widefat"
                            placeholder="e.g., Trial (7 Days)">
                    </div>
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_file_size"><?php \_e('File Size', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_file_size"
                            name="hero_file_size"
                            value="<?php echo \esc_attr($file_size); ?>"
                            class="widefat"
                            placeholder="e.g., 67 MB">
                    </div>
                </div>

                <!-- @since 2.6.1: Last Updated field for specs grid -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_last_updated"><?php \_e('Last Updated', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_last_updated"
                            name="hero_last_updated"
                            value="<?php echo \esc_attr($last_updated); ?>"
                            class="widefat"
                            placeholder="e.g., December 12, 2025">
                        <p class="description"><?php \_e('Shows in hero specs grid as UPDATED', 'seo-article-generator'); ?></p>
                    </div>
                </div>

                <!-- Row: Rating + Security Badge -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_rating"><?php \_e('Rating (0-5)', 'seo-article-generator'); ?></label>
                        <input type="number"
                            id="hero_rating"
                            name="hero_rating"
                            value="<?php echo \esc_attr($rating); ?>"
                            min="0"
                            max="5"
                            step="0.1"
                            class="widefat">
                    </div>
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_security_badge"><?php \_e('Security Badge Text', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_security_badge"
                            name="hero_security_badge"
                            value="<?php echo \esc_attr($security_badge); ?>"
                            class="widefat"
                            placeholder="100% Secure">
                    </div>
                </div>

                <!-- @MODIFIED 2025-12-15 v2.2.0: E-E-A-T Author Attribution Fields -->
                <!-- Row: Author Name + Last Verified -->
                <div class="seo-gen-field-row">
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_author_name"><?php \_e('Reviewer/Author Name', 'seo-article-generator'); ?></label>
                        <input type="text"
                            id="hero_author_name"
                            name="hero_author_name"
                            value="<?php echo \esc_attr($author_name); ?>"
                            class="widefat"
                            placeholder="e.g., John Smith">
                        <p class="description"><?php \_e('E-E-A-T signal: displays byline in article', 'seo-article-generator'); ?></p>
                    </div>
                    <div class="seo-gen-field seo-gen-field-half">
                        <label for="hero_last_verified"><?php \_e('Last Verified Date', 'seo-article-generator'); ?></label>
                        <input type="date"
                            id="hero_last_verified"
                            name="hero_last_verified"
                            value="<?php echo \esc_attr($last_verified); ?>"
                            class="widefat">
                        <p class="description"><?php \_e('Shows human oversight timestamp in hero', 'seo-article-generator'); ?></p>
                    </div>
                </div>

                <!-- Download Links (Repeater) -->
                <div class="seo-gen-field">
                    <label><?php \_e('Download Links', 'seo-article-generator'); ?></label>
                    <div id="seo-gen-hero-links-container">
                        <?php if (! empty($download_links)): ?>
                            <?php foreach ($download_links as $idx => $link): ?>
                                <?php echo self::render_link_row($idx, $link); ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <?php echo self::render_link_row(0); ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="button" id="seo-gen-add-hero-link">
                        <?php \_e('+ Add Download Link', 'seo-article-generator'); ?>
                    </button>
                </div>
            </div>

            <p class="description">
                <?php \_e('This data populates the hero section block at the top of the article. Changes save automatically when you update the post.', 'seo-article-generator'); ?>
            </p>
        </div>

        <!-- Template for new link row (hidden) -->
        <script type="text/html" id="seo-gen-hero-link-template">
            <?php echo self::render_link_row('{{INDEX}}'); ?>
        </script>
    <?php
    }

    /**
     * Render single download link row
     * @MODIFIED 2025-12-04 v1.4.0: Repeater field row template
     * @MODIFIED 2026-01-07: Added drag handle for sortable
     * @MODIFIED 2026-01-07: Fixed to use explicit indices for proper PHP parsing
     *
     * @param int|string $index Row index
     * @param array      $link Link data
     * @return string HTML
     */
    private static function render_link_row($index, $link = array())
    {
        $platform = isset($link['platform']) ? esc_attr($link['platform']) : '';
        $url = isset($link['url']) ? esc_url($link['url']) : '';
        $variant = isset($link['variant']) ? esc_attr($link['variant']) : '';
        $is_primary = isset($link['is_primary']) && $link['is_primary'];
        // @MODIFIED 2026-05-02: GAP 8 — Preserve fields not exposed as visible inputs.
        // Without these hidden inputs, saving the metabox silently wipes text, file_type,
        // version, and channel across ALL download links — destroying user customizations.
        $text = isset($link['text']) ? esc_attr($link['text']) : '';
        $file_type = isset($link['file_type']) ? esc_attr($link['file_type']) : '';
        $version = isset($link['version']) ? esc_attr($link['version']) : '';
        $channel = isset($link['channel']) ? esc_attr($link['channel']) : '';

        ob_start();
        ?>
        <div class="seo-gen-hero-link-row" data-index="<?php echo $index; ?>">
 <div class="seo-gen-hero-link-fields">
                <span class="seo-gen-drag-handle" title="Drag to reorder">
                    <span class="dashicons dashicons-menu"></span>
                </span>

                <input type="text"
                    name="hero_links[<?php echo $index; ?>][platform]"
                    value="<?php echo $platform; ?>"
                    placeholder="Platform (e.g., Windows, macOS)"
                    class="seo-gen-hero-link-platform">

                <input type="text"
                    name="hero_links[<?php echo $index; ?>][variant]"
                    value="<?php echo $variant; ?>"
                    placeholder="Variant (e.g., 64-bit, ARM)"
                    class="seo-gen-hero-link-variant">

                <input type="url"
                    name="hero_links[<?php echo $index; ?>][url]"
                    value="<?php echo $url; ?>"
                    placeholder="Download URL"
                    class="seo-gen-hero-link-url">

                <label class="seo-gen-hero-link-primary-label">
                    <input type="hidden"
                        name="hero_links[<?php echo $index; ?>][is_primary]"
                        value="<?php echo $is_primary ? '1' : '0'; ?>"
                        class="seo-gen-primary-hidden">
                    <input type="checkbox"
                        class="seo-gen-primary-checkbox"
                        value="1"
                        <?php checked($is_primary, true); ?>>
                    Primary
                </label>

                <button type="button" class="button seo-gen-remove-hero-link" title="Remove">×</button>

                <?php // @MODIFIED 2026-05-02: GAP 8 — Hidden fields to carry SSOT data through form save. ?>
                <input type="hidden" name="hero_links[<?php echo $index; ?>][text]" value="<?php echo $text; ?>">
                <input type="hidden" name="hero_links[<?php echo $index; ?>][file_type]" value="<?php echo $file_type; ?>">
                <input type="hidden" name="hero_links[<?php echo $index; ?>][version]" value="<?php echo $version; ?>">
                <input type="hidden" name="hero_links[<?php echo $index; ?>][channel]" value="<?php echo $channel; ?>">
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Save meta box data
     * @MODIFIED 2025-12-04 v1.4.0: Sanitize and save hero data
     * @MODIFIED 2025-12-11 v1.8.0: Presentation overrides only, download links locked to schema
     *
     * @param int      $post_id Post ID
     * @param \WP_Post $post Post object
     * @return void
     */
    public static function save_meta_box($post_id, $post)
    {
        // Security checks
        if (! isset($_POST['seo_gen_hero_meta_nonce'])) {
            return;
        }

        if (! \wp_verify_nonce($_POST['seo_gen_hero_meta_nonce'], 'seo_gen_hero_meta')) {
            return;
        }

        if (\defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (! \current_user_can('edit_post', $post_id)) {
            return;
        }

        // @MODIFIED 2025-12-16 v2.4.1: All hero fields now overridable to correct AI errors
        // Previously only presentation fields; now includes factual fields AND download links
        $overrides = array(
            // Core factual fields (now overridable to correct AI errors)
            'software_name'   => isset($_POST['hero_software_name']) ? \sanitize_text_field($_POST['hero_software_name']) : '',
            'version'         => isset($_POST['hero_version']) ? \sanitize_text_field($_POST['hero_version']) : '',
            'license'         => isset($_POST['hero_license']) ? \sanitize_text_field($_POST['hero_license']) : '',
            'file_size'       => isset($_POST['hero_file_size']) ? \sanitize_text_field($_POST['hero_file_size']) : '',
            // Presentation fields
            'license_details' => isset($_POST['hero_license_details']) ? \sanitize_text_field($_POST['hero_license_details']) : '',
            'rating'          => isset($_POST['hero_rating']) ? \floatval($_POST['hero_rating']) : null,
            'security_badge'  => isset($_POST['hero_security_badge']) ? \sanitize_text_field($_POST['hero_security_badge']) : '',
            // App Store style fields
            'logo_url'        => isset($_POST['hero_logo_url']) ? \esc_url_raw($_POST['hero_logo_url']) : '',
            'publisher'       => isset($_POST['hero_publisher']) ? \sanitize_text_field($_POST['hero_publisher']) : '',
            'category'        => isset($_POST['hero_category']) ? \sanitize_text_field($_POST['hero_category']) : '',
            // E-E-A-T author attribution fields
            'author_name'     => isset($_POST['hero_author_name']) ? \sanitize_text_field($_POST['hero_author_name']) : '',
            'last_verified_date' => isset($_POST['hero_last_verified']) ? \sanitize_text_field($_POST['hero_last_verified']) : '',
            // @since 2.6.1: Software last updated date
            'last_updated'    => isset($_POST['hero_last_updated']) ? \sanitize_text_field($_POST['hero_last_updated']) : '',
        // @MODIFIED 2026-05-23: Download links ARE overridable for manual posts.
        // For AI-generated posts, download_links persist separately to survive schema sync.
        // This allows manual edits while preserving SSOT for AI-generated content.
        );

		// @MODIFIED 2025-12-30 v2.8.5: Pass factual data to overrides for synchronization
        $overrides['software_name'] = isset($_POST['hero_software_name']) ? \sanitize_text_field($_POST['hero_software_name']) : '';
        $overrides['version']       = isset($_POST['hero_version']) ? \sanitize_text_field($_POST['hero_version']) : '';
        $overrides['category']      = isset($_POST['hero_category']) ? \sanitize_text_field($_POST['hero_category']) : '';

        // @MODIFIED 2026-05-23: Capture download links from POST for all posts.
        // Only set when POST data is present to avoid clearing links on meta box reload.
        // These persist in _seo_gen_hero_download_links to survive schema sync
        // while preserving SSOT for AI-generated content.
        if (isset($_POST['hero_links']) && is_array($_POST['hero_links'])) {
            $overrides['download_links'] = array();
            foreach ($_POST['hero_links'] as $link) {
                if (empty($link['platform']) || empty($link['url'])) {
                    continue;
                }
                $overrides['download_links'][] = array(
                    'platform'   => \sanitize_text_field($link['platform']),
                    'url'        => \esc_url_raw($link['url']),
                    'variant'    => \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_variant_name(
                        isset($link['variant']) ? \sanitize_text_field($link['variant']) : ''
                    ),
                    'file_type'  => isset($link['file_type']) ? \sanitize_text_field($link['file_type']) : '',
                    'version'    => isset($link['version']) ? \sanitize_text_field($link['version']) : '',
                    'channel'    => isset($link['channel']) ? \sanitize_text_field($link['channel']) : '',
                    'text'       => isset($link['text']) ? \sanitize_text_field($link['text']) : '',
                    'is_primary' => isset($link['is_primary']) && $link['is_primary'] === '1',
                );
            }
        }

		// @MODIFIED v1.8.0: Use Schema_Sync_Service to regenerate hero from schema + overrides
		$result     = \SEO_Article_Generator\Services\Schema_Sync_Service::apply_hero_overrides($post_id, $overrides);
		$has_schema = get_post_meta($post_id, '_seo_gen_article_snapshot', true);

		// Fallback for non-generated posts: save directly as before
		if (!$result) {
			if ($has_schema) {
				// @MODIFIED 2026-03-20: Data Loss Prevention Guard
				// If a post is AI-generated (has a schema), we must NOT allow the fallback logic
				// to overwrite the complex schema-derived hero data with flat form data.
				wp_die(__('CRITICAL ERROR: Failed to synchronize hero overrides with the underlying Article Schema. Save aborted to prevent data loss.', 'seo-article-generator'), __('Schema Sync Error', 'seo-article-generator'), array('back_link' => true));
			}

			// No schema exists - this is a manual post, save legacy data
			$hero_data = array(
				'software_name' => isset($_POST['hero_software_name']) ? \sanitize_text_field($_POST['hero_software_name']) : '',
				'version' => isset($_POST['hero_version']) ? \sanitize_text_field($_POST['hero_version']) : '',
				'license' => isset($_POST['hero_license']) ? \sanitize_text_field($_POST['hero_license']) : '',
				'license_details' => $overrides['license_details'],
				'file_size' => isset($_POST['hero_file_size']) ? \sanitize_text_field($_POST['hero_file_size']) : '',
				'rating' => $overrides['rating'] ?? 0,
				'security_badge' => $overrides['security_badge'] ?: 'Download Available',
				'download_links' => array(),
				// @MODIFIED 2025-12-14 v2.1.0: App Store style fields
				'logo_url' => $overrides['logo_url'],
				'publisher' => $overrides['publisher'],
				'category' => $overrides['category'],
				// @MODIFIED 2025-12-15 v2.2.0: E-E-A-T fields
				'author_name' => $overrides['author_name'],
				'last_verified_date' => $overrides['last_verified_date'],
				// @since 2.6.1: Software last updated for specs grid
				'last_updated' => $overrides['last_updated'],
			);

			// @MODIFIED 2026-05-03: Legacy fallback for non-generated posts —
			// download_links are still accepted here because there is no canonical source
			// for manually-created posts (no schema, no discovery pipeline).
			if (isset($_POST['hero_links']) && is_array($_POST['hero_links'])) {
				foreach ($_POST['hero_links'] as $link) {
					if (empty($link['platform']) || empty($link['url'])) {
						continue;
					}

					$hero_data['download_links'][] = array(
						'platform' => \sanitize_text_field($link['platform']),
						'url' => \esc_url_raw($link['url']),
						'variant' => \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_variant_name(
							isset($link['variant']) ? \sanitize_text_field($link['variant']) : ''
						),
						'file_type' => isset($link['file_type']) ? \sanitize_text_field($link['file_type']) : '',
						'version' => isset($link['version']) ? \sanitize_text_field($link['version']) : '',
						'channel' => isset($link['channel']) ? \sanitize_text_field($link['channel']) : '',
						'text' => isset($link['text']) ? \sanitize_text_field($link['text']) : '',
						'is_primary' => isset($link['is_primary']) && $link['is_primary'] === '1',
					);
				}
			}

			// Use canonical write_hero_data() for normalization, cache invalidation,
			// and Cloudflare dirty transient. Direct update_post_meta() was causing
			// stale per-request cache and missing cache bypass for first visitor.
			\SEO_Article_Generator\Plugin::get_instance()->write_hero_data($post_id, $hero_data);

			// [PLATFORM PARITY] Sync flat meta keys for legacy/UI compatibility
			\update_post_meta($post_id, '_seo_gen_version', $hero_data['version']);
			\update_post_meta($post_id, '_seo_gen_license', $hero_data['license']);
			\update_post_meta($post_id, '_seo_gen_file_size', $hero_data['file_size']);
			\update_post_meta($post_id, '_seo_gen_developer', $hero_data['publisher']);

			// For download URL, we pick the primary link or the first one if it exists
			$primary_url = '';
			if (!empty($hero_data['download_links'])) {
				foreach ($hero_data['download_links'] as $link) {
					if (!empty($link['is_primary'])) {
						$primary_url = $link['url'];
						break;
					}
				}
				if (empty($primary_url)) {
					$primary_url = $hero_data['download_links'][0]['url'];
				}
			}
			\update_post_meta($post_id, '_seo_gen_download_url', $primary_url);
		}
	}
}
