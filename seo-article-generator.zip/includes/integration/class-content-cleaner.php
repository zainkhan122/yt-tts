<?php

namespace SEO_Article_Generator\Integration;

if (! defined('ABSPATH')) exit;

/**
 * Enterprise HTML Pre-Processor for AI Token Optimization
 * Removes garbage nodes, unmasks affiliate links, and strips structural bloat.
 * * @MODIFIED 2026-03-01 - Restored affiliate link de-obfuscation logic.
 */
class Content_Cleaner
{

    /**
     * Cleans scraped HTML for AI consumption
     *
     * @param string $html The raw scraped HTML
     * @param string $url The source URL (optional)
     * @return string Token-optimized, clean HTML with direct links
     */
    public static function clean($html, $url = '')
    {
        if (empty($html)) return '';

        // 1. Safe DOM Initialization
        $dom = new \DOMDocument();
        libxml_use_internal_errors(true);
        // Force UTF-8 encoding to prevent garbled characters
        $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new \DOMXPath($dom);

        // 2. NODE ANNIHILATION: Remove entirely useless structural tags
        // Removed 'iframe' from the blind deletion array so we can process it safely
        $junk_tags = array('script', 'style', 'nav', 'footer', 'aside', 'header', 'form', 'button', 'svg', 'img');
        foreach ($junk_tags as $tag) {
            $nodes = $dom->getElementsByTagName($tag);
            for ($i = $nodes->length - 1; $i >= 0; $i--) {
                $nodes->item($i)->parentNode->removeChild($nodes->item($i));
            }
        }

        // 2b. SAFE IFRAME HANDLING (Extract YouTube links before deleting the iframe)
        $iframes = $dom->getElementsByTagName('iframe');
        for ($i = $iframes->length - 1; $i >= 0; $i--) {
            $iframe = $iframes->item($i);
            $src = $iframe->getAttribute('src');

            // If it's a YouTube or Vimeo video, create a readable text link for the AI
            if (strpos($src, 'youtube.com') !== false || strpos($src, 'youtu.be') !== false || strpos($src, 'vimeo.com') !== false) {
                $video_link = $dom->createElement('a', 'Video Link: ' . $src);
                $video_link->setAttribute('href', $src);
                $iframe->parentNode->insertBefore($video_link, $iframe);
            }

            // Now safely remove the heavy iframe
            $iframe->parentNode->removeChild($iframe);
        }

        // 3. SEMANTIC PRUNING: Remove "Garbage" Links via XPath (Case-insensitive)
        // @MODIFIED 2026-03-04: Removed 'purchase' and 'buy now' from phrases that get a "Trial" pass.
        // But we MUST keep removing Buy links per user requirement.
        $spam_phrases = array(
            'read more',
            'you may also like',
            'related post',
            'click here',
            'subscribe',
            'advertisement',
            'get premium',
            'buy now',     // KEEP REMOVING
            'purchase',    // KEEP REMOVING
            'pricing'      // KEEP REMOVING
        );

        foreach ($spam_phrases as $phrase) {
            // @MODIFIED 2026-03-04: Ensure we don't nuked links containing "trial" even if they match other spam phrases
            $query = "//a[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{$phrase}')]";
            $query .= "[not(contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'trial'))]";

            $spam_links = $xpath->query($query);
            foreach ($spam_links as $node) {
                $node->parentNode->removeChild($node);
            }
        }

	// 4. AFFILIATE LINK REMOVAL & DE-OBFUSCATION & ATTRIBUTE STRIPPING
	$links = $dom->getElementsByTagName('a');
	for ($i = $links->length - 1; $i >= 0; $i--) {
		$link = $links->item($i);

		// Remove empty links
		if (! $link->hasAttribute('href') || empty($link->getAttribute('href'))) {
			$link->parentNode->removeChild($link);
			continue;
		}

		$href = $link->getAttribute('href');

		// @MODIFIED 2026-04-29: Remove affiliate/tracking redirect URLs entirely.
		// These are opaque network redirect links (prf.hn, awin1.com, etc.) that
		// cannot be de-obfuscated to a real download URL. Stripping them prevents
		// the AI from learning and replicating the affiliate URLs.
		if (class_exists('\\SEO_Article_Generator\\Generator\\Download_Link_Helper')
			&& \SEO_Article_Generator\Generator\Download_Link_Helper::is_affiliate_url($href)) {
			$link->parentNode->removeChild($link);
			continue;
		}

		$text = strtolower($link->nodeValue);

            // @MODIFIED 2026-03-04: Label Trial links for AI grounding
            if (strpos($text, 'trial') !== false) {
                $link->nodeValue = '[TRIAL] ' . $link->nodeValue;
            }

            // De-obfuscate Affiliate Links (e.g., ?redirectto=https://mac.eltima.com/airy.dmg)
            // Catches standard wrapper parameters: redirectto, url, out, target, link, aff, path
            // @MODIFIED 2026-03-01 - Added 'path' to catch ?PATH=https://... wrappers
            if (preg_match('/(?:redirectto|url|out|target|link|aff|path)=([^&]+)/i', $href, $matches)) {
                $decoded_url = urldecode($matches[1]);
                // Only replace if the decoded string is a valid URL
                if (filter_var($decoded_url, FILTER_VALIDATE_URL)) {
                    $href = $decoded_url;
                    $link->setAttribute('href', $href);
                }
            }

            // Strip all attributes except 'href' to save AI tokens
            while ($link->attributes->length > 1) {
                $attr = $link->attributes->item(0);
                if ($attr->nodeName !== 'href') {
                    $link->removeAttributeNode($attr);
                } else {
                    $attr = $link->attributes->item(1);
                    if ($attr) $link->removeAttributeNode($attr);
                }
            }
        }

        // 5. EXTRACT AND STRIP
        $cleaned_html = $dom->saveHTML();

        // Strip structural bloat but KEEP semantic text tags and our cleaned <a> tags
        $allowed_tags = '<a><h1><h2><h3><h4><h5><h6><p><ul><ol><li><strong><b><br>';
        $token_optimized_text = strip_tags($cleaned_html, $allowed_tags);

        // Clean up excessive whitespace
        $token_optimized_text = preg_replace('/\s+/', ' ', $token_optimized_text);
        $token_optimized_text = str_replace('> <', '><', $token_optimized_text);

        return trim($token_optimized_text);
    }

    /**
     * Extract the first supported video URL (YouTube / Vimeo / Dailymotion)
     * from raw post HTML.
     *
     * @MODIFIED 2026-08-24: Added so the source-post video survives the
     * article_context build. Discovery_Processor feeds the AI
     * wp_strip_all_tags($raw_html), which destroys video URLs that only
     * exist inside <iframe src>, <a href> or wp:embed block delimiters —
     * the AI never sees them and video_url comes back empty.
     *
     * Scan priority:
     *   1. Gutenberg embed block delimiters (wp:embed / wp:core-embed-*)
     *   2. [embed] shortcodes
     *   3. <iframe src> attributes
     *   4. <a href> attributes
     *   5. Bare URLs in text (survive wp_strip_all_tags)
     *
     * @param string $html Raw HTML (post_content or scraped source HTML).
     * @return string Supported video URL or '' when none found.
     */
    public static function extract_video_url($html)
    {
        if (empty($html) || ! is_string($html)) {
            return '';
        }

        // 1. Gutenberg core/embed + core-embed-* block delimiter JSON.
        if (preg_match_all('/<!--\s*wp:(?:core-embed-[a-z0-9-]+|embed)\s+(\{[^}]*\})\s*\/?-->/i', $html, $matches)) {
            foreach ($matches[1] as $json) {
                $attrs = json_decode($json, true);
                $url   = is_array($attrs) && ! empty($attrs['url']) ? (string) $attrs['url'] : '';
                if ($url !== '' && self::is_supported_video_url($url)) {
                    return $url;
                }
            }
        }

        // 2. [embed] shortcode.
        if (preg_match('/\[embed\]\s*(https?:\/\/[^\s\[\]]+)\s*\[\/embed\]/i', $html, $matches)) {
            $url = trim($matches[1]);
            if (self::is_supported_video_url($url)) {
                return $url;
            }
        }

        // 3. <iframe src="..."> raw embed code.
        if (preg_match_all('/<iframe[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']/i', $html, $matches)) {
            foreach ($matches[1] as $src) {
                $src = html_entity_decode($src, ENT_QUOTES, 'UTF-8');
                if (self::is_supported_video_url($src)) {
                    return $src;
                }
            }
        }

        // 4. <a href="..."> pointing at a supported video host.
        if (preg_match_all('/<a[^>]*\bhref\s*=\s*["\']([^"\']+)["\']/i', $html, $matches)) {
            foreach ($matches[1] as $href) {
                $href = html_entity_decode($href, ENT_QUOTES, 'UTF-8');
                if (self::is_supported_video_url($href)) {
                    return $href;
                }
            }
        }

        // 5. Bare URL in plain text.
        if (preg_match('/https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?[^\s"\'<>]+|embed\/[A-Za-z0-9_-]{5,}|shorts\/[A-Za-z0-9_-]{5,})|youtu\.be\/[A-Za-z0-9_-]{5,}|vimeo\.com\/\d{5,}|dailymotion\.com\/video\/[A-Za-z0-9_-]+)/i', $html, $matches)) {
            if (self::is_supported_video_url($matches[0])) {
                return $matches[0];
            }
        }

        return '';
    }

    /**
     * Validate a candidate video URL: supported provider host, a real video
     * path (channel/playlist URLs are rejected) and not a known AI
     * placeholder/hallucinated YouTube ID (reuses the existing
     * Download_Link_Helper::is_placeholder_youtube_url() gate).
     *
     * @param string $url Candidate URL.
     * @return bool
     */
    private static function is_supported_video_url($url)
    {
        if (! is_string($url) || trim($url) === '') {
            return false;
        }

        $parsed = parse_url($url);
        $host   = isset($parsed['host']) ? strtolower((string) $parsed['host']) : '';
        if ($host === '') {
            return false;
        }
        $host = preg_replace('/^www\./', '', $host);
        $path = isset($parsed['path']) ? (string) $parsed['path'] : '';

        $valid = false;

        if ($host === 'youtu.be') {
            $valid = (bool) preg_match('#^/[A-Za-z0-9_-]{5,}#', $path);
        } elseif ($host === 'youtube.com' || substr($host, -12) === '.youtube.com') {
            if (preg_match('#^/(embed|shorts|v|live)/[A-Za-z0-9_-]{5,}#i', $path)) {
                $valid = true;
            } elseif (strpos($path, '/watch') === 0) {
                // Require an actual v= parameter — channel/playlist URLs rejected.
                $valid = isset($parsed['query']) && (bool) preg_match('/(?:^|&)v=[A-Za-z0-9_-]{5,}/', (string) $parsed['query']);
            }
        } elseif ($host === 'youtube-nocookie.com') {
            $valid = (bool) preg_match('#^/embed/[A-Za-z0-9_-]{5,}#i', $path);
        } elseif ($host === 'vimeo.com' || substr($host, -10) === '.vimeo.com') {
            $valid = (bool) preg_match('#^/(?:video/)?\d{5,}#i', $path);
        } elseif ($host === 'dailymotion.com' || substr($host, -17) === '.dailymotion.com') {
            $valid = (bool) preg_match('#^/(?:embed/)?video/[A-Za-z0-9_-]+#i', $path);
        }

        if (! $valid) {
            return false;
        }

        if (class_exists('\SEO_Article_Generator\Generator\Download_Link_Helper')) {
            // The existing placeholder gate only recognizes watch?v= / youtu.be
            // shapes, so normalize embed/shorts/v/live forms first.
            $check_url = $url;
            if (preg_match('#^(?:https?://)?(?:www\.)?youtube(?:-nocookie)?\.com/(?:embed|shorts|v|live)/([A-Za-z0-9_-]{5,})#i', $check_url, $m)) {
                $check_url = 'https://www.youtube.com/watch?v=' . $m[1];
            } elseif (preg_match('#^(?:https?://)?youtu\.be/([A-Za-z0-9_-]{5,})#i', $check_url, $m)) {
                $check_url = 'https://www.youtube.com/watch?v=' . $m[1];
            }
            if (\SEO_Article_Generator\Generator\Download_Link_Helper::is_placeholder_youtube_url($check_url)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Extracts structured download links from HTML for AI grounding.
     * Use Link_Resolver to find and classify links.
     *
     * @param string $html The raw HTML to scan
     * @param array  $args Optional metadata (e.g., software_name)
     * @return array List of structured links
     */
    public static function extract_structured_links($html, $args = array())
    {
        if (empty($html)) {
            return array();
        }
 
        if (! class_exists('\\SEO_Article_Generator\\Integration\\Link_Resolver')) {
            return array();
        }
 
        $resolved = \SEO_Article_Generator\Integration\Link_Resolver::resolve_from_html((string) $html, $args);
        return $resolved['links'] ?? array();
    }
}

