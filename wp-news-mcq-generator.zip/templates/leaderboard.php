<?php
/**
 * Leaderboard Template
 * @version 1.1 - Hardened with XSS Prevention
 * * @MODIFIED: Added esc_html() to dynamic output.
 */

if (!defined('ABSPATH')) exit;

get_header();

$is_astra = function_exists('astra_page_layout');
if ($is_astra) :
?>
    <div id="primary" <?php astra_primary_class(); ?>>
        <?php astra_primary_content_top(); ?>
<?php endif; ?>

<div class="nm-leaderboard-wrapper">
    <div class="nm-leaderboard-container">
        <div class="nm-leaderboard-header">
            <h1>🏆 Leaderboard</h1>
            <p>See how you rank against other quiz takers!</p>
        </div>

        <?php if (is_user_logged_in()): ?>
        <?php
            // Pre-fetch user's rank data to avoid AJAX CLS
            $user_id = get_current_user_id();
            $user_points = (int) get_user_meta($user_id, 'nm_total_points', true);
            $user_level = (int) get_user_meta($user_id, 'nm_level', true) ?: 1;
            
            global $wpdb;
            $rank = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) + 1 
                FROM {$wpdb->usermeta} 
                WHERE meta_key = 'nm_total_points' 
                AND CAST(meta_value AS UNSIGNED) > %d",
                $user_points
            ));
        ?>
        <div class="nm-user-rank-card">
            <h3>Your Rank</h3>
            <div class="nm-rank-display">
                <span class="rank-number">#<span id="nm-user-rank"><?php echo (int) $rank; ?></span></span>
                <div class="rank-details">
                    <span class="rank-points"><span id="nm-user-points"><?php echo (int) $user_points; ?></span> points</span>
                    <span class="rank-level">Level <span id="nm-user-level"><?php echo (int) $user_level; ?></span></span>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php echo do_shortcode('[nm_leaderboard type="all_time" limit="50"]'); ?>
    </div>
</div>

<?php 
if ($is_astra) :
?>
        <?php astra_primary_content_bottom(); ?>
    </div><?php if (astra_page_layout() == 'right-sidebar'): ?>
        <?php get_sidebar(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php get_footer(); ?>