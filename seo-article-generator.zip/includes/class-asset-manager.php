<?php

namespace SEO_Article_Generator;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Asset Manager
 * 
 * Handles enqueuing of scripts and styles.
 * @since 2.13.5
 */
class Asset_Manager
{
    public function __construct()
    {
        $this->register_hooks();
    }

    private function register_hooks()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_eeat_styles'));
    }

    /**
     * Enqueue frontend styles (Moved from Plugin class)
     */
    public function enqueue_frontend_styles()
    {
        // Base article styles
        $css_file = SEO_GEN_PLUGIN_DIR . 'assets/css/seo-gen-article-styles.css';
        if (file_exists($css_file)) {
            wp_enqueue_style(
                'seo-gen-article-styles',
                SEO_GEN_PLUGIN_URL . 'assets/css/seo-gen-article-styles.css',
                array(),
                filemtime($css_file)
            );
        }

        // TOC addon styles
        $toc_css_file = SEO_GEN_PLUGIN_DIR . 'assets/css/seo-gen-article-styles-toc-addon.css';
        if (file_exists($toc_css_file)) {
            wp_enqueue_style(
                'seo-gen-article-styles-toc-addon',
                SEO_GEN_PLUGIN_URL . 'assets/css/seo-gen-article-styles-toc-addon.css',
                array('seo-gen-article-styles'),
                filemtime($toc_css_file)
            );
        }

        // Accordion script — only on single post pages with hero data
        $js_file = SEO_GEN_PLUGIN_DIR . 'assets/js/seo-gen-accordion.js';
        if (file_exists($js_file) && is_singular('post') && Plugin::get_instance()->get_hero_data(get_the_ID())) {
            wp_enqueue_script(
                'seo-gen-accordion',
                SEO_GEN_PLUGIN_URL . 'assets/js/seo-gen-accordion.js',
                array('jquery'),
                filemtime($js_file),
                true
            );
        }

        // Rating UI script
        $rating_js = SEO_GEN_PLUGIN_DIR . 'assets/js/rating-ui.js';
	if (file_exists($rating_js) && is_singular('post') && Plugin::get_instance()->get_hero_data(get_the_ID())) {
            wp_enqueue_script(
                'seo-gen-rating-ui',
                SEO_GEN_PLUGIN_URL . 'assets/js/rating-ui.js',
                array(),
                filemtime($rating_js),
                true
            );

            wp_localize_script(
                'seo-gen-rating-ui',
                'seo_gen_Rating',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('seo_gen_rating'),
                )
            );
        }

        // @MODIFIED 2026-01-09 v2.16.7: Download tracker script for click tracking
        $download_js = SEO_GEN_PLUGIN_DIR . 'assets/js/download-tracker.js';
	if (file_exists($download_js) && is_singular('post') && Plugin::get_instance()->get_hero_data(get_the_ID())) {
            wp_enqueue_script(
                'seo-gen-download-tracker',
                SEO_GEN_PLUGIN_URL . 'assets/js/download-tracker.js',
                array(),
                filemtime($download_js),
                true
            );

            wp_localize_script(
                'seo-gen-download-tracker',
                'seo_gen_Download',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('seo_gen_nonce'),
                    'post_id'  => get_the_ID(),
                )
            );
        }
    }

    /**
     * Enqueue E-E-A-T frontend styles (Moved from Plugin class)
     */
    public function enqueue_eeat_styles()
    {
	if (is_singular('post') && Plugin::get_instance()->get_hero_data(get_the_ID())) {
            add_action(
                'wp_head',
                function () {
                    if (class_exists('SEO_Article_Generator\\Frontend\\EEAT_Frontend_Styles')) {
                        echo '<style>';
                        echo Frontend\EEAT_Frontend_Styles::get_inline_css();
                        echo '</style>';
                    }
                },
                100
            );
        }
    }
}
