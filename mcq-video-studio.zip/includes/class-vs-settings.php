<?php

/**
 * Video Studio Settings
 *
 * Handles settings page for Buffer, R2, and Automation configuration.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Settings
 *
 * Settings page for Video Studio.
 *
 * @since 1.0.0
 */
class VS_Settings
{

    /**
     * Option group name.
     */
    const OPTION_GROUP = 'mcqvs_settings';

    /**
     * Return asset version for cache busting — matches VS_Core::get_asset_version().
     * In dev mode (WP_DEBUG), returns epoch seconds so every page load busts cache.
     * In production, returns the plugin version constant.
     *
     * @return string|int
     */
    private static function get_asset_version()
    {
        return defined('MCQVS_DEV_MODE') && MCQVS_DEV_MODE ? time() : MCQVS_VERSION;
    }

    /**
     * Version string for a settings asset based on its modification time.
     *
     * Using filemtime() (not the plugin version) guarantees that any edit to
     * settings.js / settings.css busts the browser cache immediately, which is
     * required while the settings UI evolves quickly.
     *
     * @param string $relative_path Path relative to the plugin directory.
     * @return string
     */
    private static function get_asset_file_version($relative_path)
    {
        $file = MCQVS_PLUGIN_DIR . $relative_path;
        $mtime = @filemtime($file);
        return $mtime ? (string) $mtime : self::get_asset_version();
    }

    /**
     * Singleton instance.
     *
     * @var VS_Settings|null
     */
    private static $instance = null;

    /**
     * Settings page hook suffix.
     *
     * @var string
     */
    private $hook_suffix = '';

    /**
     * Initialize settings.
     *
     * @since 1.0.0
     * @return VS_Settings
     */
    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct()
    {
        add_action('admin_menu', array($this, 'add_settings_page'), 30);
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_settings_assets'));

        // Remove the "Thank you for creating with WordPress" admin footer text on plugin pages.
        add_filter('admin_footer_text', array($this, 'filter_admin_footer_text'), 999);
        add_filter('update_footer', array($this, 'filter_update_footer'), 999);

        // AJAX handlers.
        // @FIX: Renamed from `vs_*` to `mcqvs_*` to match the canonical `mcqvs_` namespace
        //       used by every other AJAX surface in this plugin (registered in class-vs-core.php).
        add_action('wp_ajax_mcqvs_test_buffer', array($this, 'ajax_test_buffer'));
        add_action('wp_ajax_mcqvs_refresh_buffer_channels', array($this, 'ajax_refresh_buffer_channels'));
        add_action('wp_ajax_mcqvs_test_r2', array($this, 'ajax_test_r2'));
        add_action('wp_ajax_mcqvs_run_automation', array($this, 'ajax_run_automation'));
        // @NEW 2026-06-29: Diagnostics logs endpoint
        add_action('wp_ajax_mcqvs_get_diagnostics_logs', array($this, 'ajax_get_diagnostics_logs'));
        // @NEW 2026-06-26: API Provider Connection Tests & Custom Provider CRUD
        add_action('wp_ajax_mcqvs_test_gemini', array($this, 'ajax_test_gemini'));
        add_action('wp_ajax_mcqvs_test_custom_provider', array($this, 'ajax_test_custom_provider'));
        add_action('wp_ajax_mcqvs_save_custom_provider', array($this, 'ajax_save_custom_provider'));
        add_action('wp_ajax_mcqvs_delete_custom_provider', array($this, 'ajax_delete_custom_provider'));
        add_action('wp_ajax_mcqvs_get_custom_providers', array($this, 'ajax_get_custom_providers'));
        add_action('wp_ajax_mcqvs_reset_rotation', array($this, 'ajax_reset_rotation'));
        add_action('wp_ajax_mcqvs_save_builtin_custom_models', array($this, 'ajax_save_builtin_custom_models'));

        // @NEW 2026-07-07: Dashboard "Reset Stuck Pipeline" emergency button. Kills
        //              any wedged headless renderer PIDs and resets their rows back to
        //              `ready_for_render` so the 5-min cron can re-spawn them. Optionally
        //              accepts `scope` (rendering|all) — default is `rendering` and that is
        //              the only safe choice from the dashboard.
        add_action('wp_ajax_mcqvs_reset_stuck_pipeline', array($this, 'ajax_reset_stuck_pipeline'));
        add_action('wp_ajax_mcqvs_get_render_progress', array($this, 'ajax_get_render_progress'));

        // @NEW 2026-07-08: Dashboard "Reset Plugin" master button. Preserves vs_mcq_bank
        //        (your exam questions) and vs_topics (topic rows the bank's topic_id
        //        column references; the Content Planner Saved Questions Bank refresh
        //        joins vs_topics <-> vs_mcq_bank, so both must survive a reset). Clears
        //        all other vs_* tables, options, transients, and cancels/pauses all
        //        Action Scheduler hooks. Designed for "start over from MCQs" without
        //        losing question history.
        add_action('wp_ajax_mcqvs_reset_plugin', array($this, 'ajax_reset_plugin'));
        // @FIX 1.4.9.53 (global STOP): dashboard "Stop Everything" / "Resume" —
        // kills live renders, cancels ALL queues/crons/actions, sets the global
        // stop flag every entry point respects. Data untouched (unlike Reset).
        add_action('wp_ajax_mcqvs_stop_all', array($this, 'ajax_stop_all'));
        add_action('wp_ajax_mcqvs_resume_all', array($this, 'ajax_resume_all'));
        // @FIX 1.4.9.41 (data-loss): one-click restore of the safety backup
        // (Content Planner, batch tracker, batches, retention settings, etc.).
        add_action('wp_ajax_mcqvs_restore_backup', array($this, 'ajax_restore_backup'));

        // @NEW 2026-07-30: Dashboard buttons to clear ready/queued jobs
        add_action('wp_ajax_mcqvs_clear_ready_jobs', array($this, 'ajax_clear_ready_jobs'));
        add_action('wp_ajax_mcqvs_clear_queued_jobs', array($this, 'ajax_clear_queued_jobs'));
        add_action('wp_ajax_mcqvs_clear_queue', array($this, 'ajax_clear_queue'));
        add_action('wp_ajax_mcqvs_clear_questions', array($this, 'ajax_clear_questions'));

        add_action('wp_ajax_mcqvs_manual_buffer_push', array($this, 'ajax_manual_buffer_push'));

        // @NEW 2026-08-01: Multi-account Buffer support.
        add_action('wp_ajax_mcqvs_add_buffer_account', array($this, 'ajax_add_buffer_account'));
        add_action('wp_ajax_mcqvs_save_buffer_account', array($this, 'ajax_save_buffer_account'));
        add_action('wp_ajax_mcqvs_delete_buffer_account', array($this, 'ajax_delete_buffer_account'));
        add_action('wp_ajax_mcqvs_set_default_buffer_account', array($this, 'ajax_set_default_buffer_account'));
        add_action('wp_ajax_mcqvs_refresh_buffer_account_channels', array($this, 'ajax_refresh_buffer_account_channels'));
    }

    public function filter_admin_footer_text($text)
    {
        $screen = get_current_screen();
        if ($screen && strpos($screen->id, 'mcqvs') !== false) {
            return '';
        }
        return $text;
    }

    public function filter_update_footer($text)
    {
        $screen = get_current_screen();
        if ($screen && strpos($screen->id, 'mcqvs') !== false) {
            return '';
        }
        return $text;
    }

    public function ajax_reset_rotation()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (class_exists('VS_Provider_Registry')) {
            VS_Provider_Registry::get_instance()->reset_failures();
        }
        wp_send_json_success(array('message' => 'Rotation failures reset.'));
    }

    /**
     * @NEW 2026-07-07: Emergency dashboard button — force-reset any wedged pipeline.
     *
     * Scans headless-render transients and job rows for "rendering" state that has no
     * live renderer process (or is past its hard timeout), then:
     *   1. Kills the stored PID (best effort; may already be dead).
     *   2. Cancels any scheduled `mcqvs_kill_orphan_render` Action Scheduler action.
     *   3. Clears mcqvs_render_pid_* / mcqvs_render_started_* / mcqvs_job_lock_* transients.
     *   4. Folds the job row back to `ready_for_render` with retry_count incremented.
     *
     * The next 5-min headless cron will re-spawn the render with the current (900s) timeout.
     */
    public function ajax_reset_stuck_pipeline()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $scope = sanitize_key($_POST['scope'] ?? 'rendering');
        if (! in_array($scope, array('rendering', 'all'), true)) {
            $scope = 'rendering';
        }

        if (! class_exists('VS_Headless_Renderer')) {
            wp_send_json_error('Headless renderer class not available.');
        }

        // Local logger so the button leaves an auditable trail (the user needs to
        // SEE what the button did in the diagnostics log).
        $log = function ($msg, $level = 'warning', $ctx = array()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log($msg, $level, array_merge(array('_type' => 'pipeline'), $ctx));
            }
        };

        $log('Reset Stuck Pipeline: invoked by user. scope=' . $scope, 'info');

        global $wpdb;
        $jobs_table = $wpdb->prefix . 'vs_jobs';

        // 1) Find wedged rows.
        //    Default scope ONLY touches rows that the rendering card counts as
        //    "live": `rendering`, `ready_for_render`, `pending`, `uploading`.
        //    We deliberately do NOT touch `completed` / `failed` / `cancelled` —
        //    the rendering card never counts those, so they cannot be "stuck"
        //    from the dashboard's perspective.
        //
        //    Bug history (cross-file audit 2026-07-08): The original
        //    implementation filtered strictly to `status = 'rendering'`. If a
        //    job was sitting at `ready_for_render` (or `pending`) with a
        //    pending `mcqvs_render_claim` Action Scheduler action queued up
        //    (e.g. from a previous tick that died mid-claim), the row showed
        //    in the dashboard's rendering/queued cards but was invisible to
        //    this handler. The dashboard then re-promoted the row back to
        //    `rendering` within seconds of the reload, making the button look
        //    like it did nothing.
        //
        //    Fix: include `ready_for_render` / `pending` / `uploading` in the
        //    candidates, then queue ALL their related AS actions for cancel
        //    before the row is reset. This way the dashboard's pipeline card
        //    actually drops to 0 immediately on reload.
        $wedged_statuses = array(
            VS_Job_Status::RENDERING,
            VS_Job_Status::READY_FOR_RENDER,
            VS_Job_Status::PENDING,
            VS_Job_Status::UPLOADING,
        );
        $placeholders    = implode(',', array_fill(0, count($wedged_statuses), '%s'));
        $candidates      = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT job_id, status, started_at FROM {$jobs_table} WHERE status IN ({$placeholders})",
                $wedged_statuses
            )
        );

        $reset      = 0;
        $skipped    = 0;
        $killed_pids = array();
        $now_gmt   = current_time('mysql', true);

        foreach ((array) $candidates as $row) {
            $job_id = $row->job_id;

            $pid_transient  = 'mcqvs_render_pid_' . $job_id;
            $pid            = (int) get_transient($pid_transient);
            $started_trans  = (int) get_transient('mcqvs_render_started_' . $job_id);

            // Determine if this row is genuinely wedged:
            //  - No stored PID transient at all, OR
            //  - PID stored but process is dead, OR
            //  - PID stored + alive but exceeded hard timeout window (started_at + 900s + 120s buffer).
            $is_wedged = false;
            if (empty($pid)) {
                $is_wedged = true; // Lost our handle; safest to reset.
            } else {
                $alive = VS_Headless_Renderer::is_pid_running($pid);
                if (! $alive) {
                    $is_wedged = true;
                } else {
                    $hard_limit = (int) get_option('mcqvs_render_timeout', 900) + 120;
                    $started_ts = $started_trans ?: strtotime($row->started_at . ' UTC');
                    if ($started_ts && (time() - $started_ts) > $hard_limit) {
                        $is_wedged = true; // Still alive but over the cliff — force kill.
                    }
                }
            }

            if (! $is_wedged) {
                $skipped++;
                $log('Reset Stuck Pipeline: job ' . $job_id . ' still active (status=' . $row->status . ', PID ' . $pid . ' alive, within timeout) — skipped.', 'info');
                continue;
            }

            // Kill the process if we think it is alive (best effort).
            if (! empty($pid)) {
                VS_Headless_Renderer::kill_pid($pid);
                $killed_pids[] = $pid;
                $log('Reset Stuck Pipeline: killed PID ' . $pid . ' for job ' . $job_id, 'warning', array('job_id' => $job_id, 'pid' => $pid));
            } else {
                $log('Reset Stuck Pipeline: job ' . $job_id . ' had no live PID handle — forcing reset.', 'warning', array('job_id' => $job_id));
            }

            // Cancel ALL scheduled Action Scheduler actions tied to this job so the
            // dashboard counts actually drop on reload. The dominant races:
            //   - `mcqvs_kill_orphan_render` — old (pid,job_id) signature
            //   - `mcqvs_kill_orphan_render` — new signature that some AS installs store
            //   - `mcqvs_render_claim` queued by `run_headless_render_queue()` from any
            //     partial tick that died mid-spawn. This is the one that otherwise
            //     immediately re-promotes the row back to `rendering`.
            if (function_exists('as_unschedule_action')) {
                // These MUST match the exact (hook, args, group) used at schedule
                // time (class-vs-headless-renderer.php render_job: kill_orphan uses
                // array(pid, job_id) + 'mcq-video-studio'; automation-engine claims
                // use array(job_id) + 'mcq-video-studio').
                as_unschedule_action('mcqvs_kill_orphan_render', array((int) $pid, $job_id), 'mcq-video-studio');
                as_unschedule_action('mcqvs_render_claim', array($job_id), 'mcq-video-studio');
            }

            // Clear every transient this job_id ever stamped.
            delete_transient('mcqvs_render_pid_' . $job_id);
            delete_transient('mcqvs_render_started_' . $job_id);
            delete_transient('mcqvs_render_auth_' . $job_id);
            delete_transient('mcqvs_render_auth_verified_' . $job_id);
            delete_transient('mcqvs_job_lock_' . $job_id);

            // Pick the correct target state from the source state. We never write
            // a row back to itself, and we never promote `pending` -> `rendering`
            // (that would skip headless queue validation).
            $from_status = $row->status;
            $to_status   = VS_Job_Status::READY_FOR_RENDER;
            if ($from_status === VS_Job_Status::UPLOADING) {
                // Uploading-stage rows are wedged on R2/Buffer. Re-queue to
                // ready_for_render so R2 can pick them back up cleanly.
                $to_status = VS_Job_Status::READY_FOR_RENDER;
            }

            // @FIX (cross-file audit 2026-07-08): Stamp a per-job cooldown so the very
            //              same `READY_FOR_RENDER` row we just reset does NOT get
            //              re-picked by `run_headless_render_queue` on the next 5-min
            //              tick. The headless queue + the render-claim AS action both
            //              check this transient and skip until expiry. 7 minutes covers
            //              one full AS cycle plus 2 minutes of jitter; transient auto-
            //              expires so the user always gets a clean retry next top-of-hour.
            set_transient('mcqvs_reset_cooldown_' . $job_id, time() + 420, 600);

            // @FIX (cross-file audit 2026-07-08): Also pause the recurring
            //              `vs_headless_render_cron` for a couple of cycles so the
            //              scan itself doesn't enumerate rows the user just whacked.
            //              Wraps the recurring action with a per-cycle guard transient.
            $resume_at = (int) get_transient('mcqvs_render_queue_pause_until');
            $desired   = time() + 420;
            if ($resume_at < $desired) {
                set_transient('mcqvs_render_queue_pause_until', $desired, 600);
            }

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$jobs_table} SET status = %s, retry_count = retry_count + 1, started_at = %s WHERE job_id = %s",
                    $to_status,
                    $now_gmt,
                    $job_id
                )
            );

            $reset++;
            $log('Reset Stuck Pipeline: job ' . $job_id . ' reset ' . $from_status . ' -> ' . $to_status . ' (retry_count+1, cooldown=7min).', 'warning', array('job_id' => $job_id, 'from' => $from_status, 'to' => $to_status, 'cooldown_until' => gmdate('c', time() + 420)));
        }

        // After the row reset, also sweep the render queue itself for any orphan
        // claim actions whose job no longer exists in any terminal-then-reset state.
        // This catches claim actions scheduled against jobs that were already
        // nuked by the test/smoke-test harness or a prior failed run.
        $claim_cancelled = 0;
        if (function_exists('as_get_scheduled_actions')) {
            try {
                $pending = as_get_scheduled_actions(array(
                    'hook'   => 'mcqvs_render_claim',
                    'status' => 'pending',
                    'per_page' => 100,
                ), ARRAY_A);
                if (is_array($pending)) {
                    foreach ($pending as $a) {
                        $args = isset($a['args']) ? $a['args'] : array();
                        $jid = '';
                        if (is_array($args)) {
                            $jid = isset($args['job_id']) ? (string) $args['job_id']
                                : (isset($args[0]) ? (string) $args[0] : '');
                        }
                        if ($jid === '') {
                            continue;
                        }
                        $exists = $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT job_id FROM {$jobs_table} WHERE job_id = %s",
                                $jid
                            )
                        );
                        if (! $exists) {
                            as_unschedule_action('mcqvs_render_claim', array('job_id' => $jid), 'mcq-video-studio');
                            as_unschedule_action('mcqvs_render_claim', array($jid), 'mcq-video-studio');
                            $claim_cancelled++;
                        }
                    }
                }
            } catch (\Throwable $e) {
                // Best-effort: never let a conservative sweep crash the user-facing reset.
                $log('Reset Stuck Pipeline: orphan-claim sweep failed: ' . $e->getMessage(), 'warning');
            }
        }

        // Report live post-reset counts so the dashboard truth is unambiguous.
        $after = class_exists('VS_Job_Repository')
            ? VS_Job_Repository::init()->get_status_breakdown()
            : array();

        $log(
            sprintf('Reset Stuck Pipeline: COMPLETE. reset=%d skipped=%d killed_pids=%s orphan_claims_cancelled=%d after(rendering=%d, ready=%d, failed=%d, completed=%d)',
                $reset, $skipped, implode(',', $killed_pids), $claim_cancelled,
                (int) ($after['rendering'] ?? 0),
                (int) ($after['ready_for_render'] ?? 0) + (int) ($after['pending'] ?? 0),
                (int) ($after['failed'] ?? 0),
                (int) ($after['completed'] ?? 0)
            ),
            'warning',
            array('reset' => $reset, 'skipped' => $skipped, 'killed_pids' => $killed_pids, 'orphan_claims_cancelled' => $claim_cancelled, 'after' => $after)
        );

        wp_send_json_success(array(
            'message'        => sprintf('Reset %d stuck job(s), skipped %d still-active render(s), cancelled %d orphan claim(s).', $reset, $skipped, $claim_cancelled),
            'reset'          => $reset,
            'skipped'        => $skipped,
            'killed_pids'    => $killed_pids,
            'orphan_claims'  => $claim_cancelled,
            'after'          => $after,
        ));
    }

    /**
     * @NEW 2026-07-08: Master "Reset Plugin" button — start over from MCQs only.
     *
     * Preserves the vs_mcq_bank table (your exam question bank) and vs_topics
     * (topic rows the bank's topic_id column references; without them the
     * Content Planner Saved Questions Bank LEFT JOIN yields no rows). All other
     * plugin tables, options, transients, Action Scheduler hooks, and renderer
     * PID handles are cleared. The headless render cron and all claim/orphan-kill
     * actions are cancelled. Plugin will self-heal tables and re-spawn hooks on
     * next page load.
     */
    /**
     * @FIX 1.4.9.41 (data-loss): Restore missing user data from the safety backup
     * (Content Planner, batch tracker, batches, Artifact Cleanup retention
     * settings, Buffer accounts, API provider/key). Only refills values that are
     * currently missing — existing data is never overwritten.
     */
    public function ajax_restore_backup()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (! function_exists('mcqvs_restore_safety_backup')) {
            wp_send_json_error('Restore helper not available (plugin files incomplete).');
        }
        $result = mcqvs_restore_safety_backup();
        wp_send_json_success($result);
    }

    /**
     * @FIX 1.4.9.53 (global STOP): Emergency "Stop Everything" — non-destructive.
     * Scope (user-confirmed):
     *   - Kill ALL live render PIDs (render-node.js) and reset their jobs back
     *     to READY_FOR_RENDER so Resume re-renders them from scratch.
     *   - Cancel every scheduled/recurring Action Scheduler action AND WP cron:
     *     render queue, publish scheduler, daily scheduler, AI topic batches
     *     (mcqvs_process_topic_batch / vs_generate_mcq_batch), job transitions
     *     (vs_process_job_event), render claims, orphan-kills, telemetry/artifact
     *     prunes, batch-tracker cleanup.
     *   - Set the persistent `mcqvs_global_stop` flag + far-future render-queue
     *     pause transient so NOTHING restarts until Resume is clicked.
     *   - Buffer: no new posts scheduled/pushed (already-sent posts can't be
     *     recalled — documented).
     *   - Studio browser Auto-Runner halts on its next poll via MCQVS_Config.
     *   - NO tables truncated, NO options deleted, NO data lost.
     */
    public function ajax_stop_all()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $prefix = $wpdb->prefix;
        $now = gmdate('Y-m-d H:i:s');
        $now_ts = time();

        $pids_nuked = 0;
        $jobs_reset = 0;
        $as_cancelled = 0;

        // 1) Kill every live render process (same scan the master reset uses).
        if (class_exists('VS_Headless_Renderer')) {
            $pid_transients = $wpdb->get_col(
                $wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_pid_%')
            );
            if (is_array($pid_transients)) {
                foreach ($pid_transients as $key) {
                    $pid = get_transient(str_replace('_transient_', '', $key));
                    if ($pid) {
                        VS_Headless_Renderer::kill_pid(absint($pid));
                        $pids_nuked++;
                        delete_transient(str_replace('_transient_', '', $key));
                    }
                }
            }
        }

        // 2) Mid-render jobs -> back to READY_FOR_RENDER (re-render on Resume).
        //    Clear partial video_url/path/started_at so Resume renders clean.
        $res = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$prefix}vs_jobs
                 SET status = %s, started_at = NULL, retry_count = 0, error_message = NULL, video_url = NULL, video_path = NULL
                 WHERE status IN (%s, %s)",
                VS_Job_Status::READY_FOR_RENDER,
                VS_Job_Status::RENDERING,
                VS_Job_Status::UPLOADING
            )
        );
        if (false !== $res) {
            $jobs_reset = (int) $res;
        }

        // 3) Cancel every Action Scheduler action (recurring + single).
        $as_hooks = array(
            'vs_process_bulk_schedule',
            'mcqvs_process_topic_batch',
            'vs_generate_mcq_batch',
            'vs_headless_render_cron',
            'vs_publish_scheduled_cron',
            'mcqvs_render_claim',
            'mcqvs_kill_orphan_render',
            'mcqvs_cleanup_batch_tracker',
            'mcqvs_render_liveness',
            'mcqvs_daily_telemetry_prune',
            'mcqvs_daily_artifact_prune',
        );
        if (function_exists('as_unschedule_all_actions')) {
            foreach ($as_hooks as $hook) {
                if (function_exists('as_has_scheduled_action') && as_has_scheduled_action($hook)) {
                    as_unschedule_all_actions($hook);
                    $as_cancelled++;
                }
            }
            // Single-shot job transitions (may exist per pending job).
            as_unschedule_all_actions('vs_process_job_event');
        }

        // 4) Clear every WP cron event (incl. single vs_process_job_event).
        foreach (array(
            'vs_daily_schedule_event',
            'vs_headless_render_cron',
            'vs_publish_scheduled_cron',
            'mcqvs_orphan_kill_cron',
            'mcqvs_daily_telemetry_prune',
            'mcqvs_daily_artifact_prune',
            'vs_process_job_event',
            'mcqvs_render_claim',
            'mcqvs_kill_orphan_render',
            'mcqvs_cleanup_batch_tracker',
        ) as $hook) {
            wp_clear_scheduled_hook($hook);
        }

        // 5) Persistent stop flag + belt-and-braces render-queue pause.
        update_option('mcqvs_global_stop', $now_ts);
        set_transient('mcqvs_render_queue_pause_until', $now_ts + (30 * DAY_IN_SECONDS), 30 * DAY_IN_SECONDS);

        // 6) Clear volatile render transients so a Resume starts clean.
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_started_%'));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_job_lock_%'));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_auth_%'));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_auth_verified_%'));

        if (class_exists('VS_Error_Logger')) {
            // @FIX 1.4.9.55: log site-local time (wp_date respects the WP timezone),
            // matching the display fix — not the raw UTC $now.
            $stop_local = function_exists('wp_date') ? wp_date('Y-m-d H:i:s') : $now;
            VS_Error_Logger::get_instance()->log(
                "GLOBAL STOP executed at {$stop_local}. pids_nuked={$pids_nuked} jobs_reset_to_ready={$jobs_reset} as_cancelled={$as_cancelled}",
                'warning',
                array(
                    '_type' => 'global_stop',
                    'pids_nuked' => $pids_nuked,
                    'jobs_reset' => $jobs_reset,
                    'as_cancelled' => $as_cancelled,
                )
            );
        }

        wp_send_json_success(array(
            'message' => sprintf(
                'Stopped everything. Killed %d render process(es), reset %d job(s) to Ready (they will re-render on Resume), cancelled %d scheduled task(s). No data was deleted.',
                $pids_nuked,
                $jobs_reset,
                $as_cancelled
            ),
            'pids_nuked' => $pids_nuked,
            'jobs_reset' => $jobs_reset,
            'as_cancelled' => $as_cancelled,
            'stopped' => true,
        ));
    }

    /**
     * @FIX 1.4.9.53: Resume after a global STOP — manual only.
     * Clears the stop flag + pause, re-registers all crons (idempotent), and
     * re-schedules the pending->ready_for_render transitions for pending jobs.
     */
    public function ajax_resume_all()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $prefix = $wpdb->prefix;
        $now = gmdate('Y-m-d H:i:s');
        $now_gmt = $now;

        delete_option('mcqvs_global_stop');
        delete_transient('mcqvs_render_queue_pause_until');

        // @FIX 1.4.9.54 (Skip overdue, keep future): while the pipeline was stopped,
        // calendar jobs whose publish date passed must NOT be dumped onto social in
        // a late burst on resume. Mark them CANCELLED with a clear reason — the
        // missed window is skipped, and only future jobs continue. Covers:
        //   - pending / ready_for_render (never rendered, date passed)
        //   - completed-but-unpublished (rendered before the stop, publish passed)
        //   - never touches jobs with no publish_at (buffer-queued, no date concept)
        //     or jobs already published (published_channels set).
        $overdue_skipped = 0;
        $table = $prefix . 'vs_jobs';
        $skip_res = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                 SET status = %s, error_message = %s
                 WHERE status IN (%s, %s, %s)
                   AND publish_at IS NOT NULL
                   AND publish_at != '0000-00-00 00:00:00'
                   AND publish_at < %s
                   AND (published_channels IS NULL OR published_channels = '')",
                VS_Job_Status::CANCELLED,
                'Skipped on resume: publish date passed while pipeline was stopped.',
                VS_Job_Status::PENDING,
                VS_Job_Status::READY_FOR_RENDER,
                VS_Job_Status::COMPLETED,
                $now_gmt
            )
        );
        if (false !== $skip_res) {
            $overdue_skipped = (int) $skip_res;
        }

        // Re-register the recurring crons (idempotent — only adds missing ones).
        if (class_exists('VS_Automation_Engine')) {
            $engine = VS_Automation_Engine::init();
            if ($engine && method_exists($engine, 'register_cron')) {
                $engine->register_cron();
            }
        }

        // Re-schedule pending jobs that were waiting on vs_process_job_event.
        $requeued = 0;
        $table = $prefix . 'vs_jobs';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT job_id, scheduled_at FROM {$table} WHERE status = %s",
                VS_Job_Status::PENDING
            ),
            ARRAY_A
        );
        if (is_array($rows)) {
            foreach ($rows as $r) {
                $job_id = isset($r['job_id']) ? $r['job_id'] : '';
                if (empty($job_id)) continue;
                $sched = isset($r['scheduled_at']) && $r['scheduled_at'] !== '0000-00-00 00:00:00' ? strtotime($r['scheduled_at'] . ' UTC') : 0;
                if ($sched && $sched > time()) {
                    wp_schedule_single_event($sched, 'vs_process_job_event', array($job_id));
                    $requeued++;
                } elseif (function_exists('as_enqueue_async_action')) {
                    as_enqueue_async_action('vs_process_job_event', array($job_id), 'mcq-video-studio');
                    $requeued++;
                }
            }
        }

        if (class_exists('VS_Error_Logger')) {
            // @FIX 1.4.9.55: log site-local time, matching the STOP log + display fix.
            $resume_local = function_exists('wp_date') ? wp_date('Y-m-d H:i:s') : $now;
            VS_Error_Logger::get_instance()->log(
                "GLOBAL RESUME executed at {$resume_local}. overdue_skipped={$overdue_skipped} requeued_pending={$requeued}",
                'info',
                array(
                    '_type'            => 'global_resume',
                    'overdue_skipped'  => $overdue_skipped,
                    'requeued_pending' => $requeued,
                )
            );
        }

        wp_send_json_success(array(
            'message' => sprintf(
                'Resumed. Skipped %d overdue job(s) whose publish date passed while stopped (marked Cancelled — the missed window is skipped, no late flood). %d pending job(s) re-queued, future jobs stay on schedule.',
                $overdue_skipped,
                $requeued
            ),
            'overdue_skipped' => $overdue_skipped,
            'requeued_pending' => $requeued,
            'stopped' => false,
        ));
    }

    public function ajax_reset_plugin()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // The reset is heavy (multiple TRUNCATEs, a full options scan, and
        // Action Scheduler cancellation). On slower hosts the default PHP
        // execution limit can be exceeded mid-run, which kills the request
        // and leaves the browser with a status-0 / aborted XHR. Lift the
        // limits so the reset can finish and return a real JSON response.
        if (function_exists('set_time_limit')) {
            @set_time_limit(0);
        }
        @ini_set('memory_limit', '512M');

        global $wpdb;
        $prefix = $wpdb->prefix;
        $now = gmdate('Y-m-d H:i:s');

        // Kill every known renderer PID before touching tables (best-effort).
        $pids_nuked = 0;
        if (class_exists('VS_Headless_Renderer')) {
            // Scan all transient keys (API-limited: `mcqvs_render_pid_*`)
            $pid_transients = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                    '_transient_mcqvs_render_pid_%'
                )
            );
            if (is_array($pid_transients)) {
                foreach ($pid_transients as $key) {
                    $pid = get_transient(str_replace('_transient_', '', $key));
                    if ($pid) {
                        VS_Headless_Renderer::kill_pid(absint($pid));
                        $pids_nuked++;
                        delete_transient(str_replace('_transient_', '', $key));
                    }
                }
            }
        }

        $preserve = array('vs_mcq_bank', 'vs_topics');

        $all_tables = array('vs_logs','vs_topics','vs_mcq_bank','vs_exam_calendar','vs_jobs','vs_projects','vs_project_questions');

        $truncated = 0;
        foreach ($all_tables as $tbl) {
            if (in_array($tbl, $preserve, true)) {
                continue;
            }
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $prefix . $tbl)) === $prefix . $tbl) {
                $wpdb->query("TRUNCATE TABLE {$prefix}{$tbl}");
                $truncated++;
            }
        }

        // Nuclear strike on every vs_jobs-related transient puddle.
        // This shared table of render-auth-lock snippets is shared by
        // the old planner and the headless engine; wiping all of them
        // guarantees that post-reset no stale signal can re-promote
        // a now-gone row.
        $trans_keys = $wpdb->get_col(
            $wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
                '_transient_mcqvs_render_%', '_transient_mcqvs_job_lock_%', '_transient_mcqvs_auth_%',
                '_transient_mcqvs_reset_cooldown_%', '_transient_mcqvs_render_queue_pause_until')
        );
        $trans_nuked = 0;
        if (is_array($trans_keys)) {
            foreach ($trans_keys as $key) {
                delete_transient(str_replace('_transient_', '', $key));
                $trans_nuked++;
            }
        }

        // Also delete the custom-format telemetry counters, the content-plan
        // global, the batch tracker, and any leftover batch temp-keys.
        $opt_keys = $wpdb->get_col(
            $wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
                'mcqvs_api_count_%', 'mcqvs_videos_created_%', 'mcqvs_batch_%')
        );
        $opts_nuked = 0;
        if (is_array($opt_keys)) {
            foreach ($opt_keys as $key) {
                delete_option($key);
                $opts_nuked++;
            }
        }
        delete_option('mcqvs_batch_tracker');
        delete_option('mcqvs_content_plan');
        delete_option('mcqvs_content_plan_pending_batches');
        $opts_nuked += 3;

        // Cancel all Action Scheduler recurring actions + single per-job claims.
        // Pre-count scheduled actions before cancelling them so the response
        // counter is accurate (as_unschedule_all_actions() returns void).
        $as_cancelled = 0;
        if (function_exists('as_get_scheduled_actions') && function_exists('as_unschedule_all_actions')) {
            try {
                foreach (array(
                    'vs_process_bulk_schedule',
                    'mcqvs_process_topic_batch',
                    'vs_generate_mcq_batch',
                    'vs_headless_render_cron',
                    'vs_publish_scheduled_cron',
                    'mcqvs_render_claim',
                    'mcqvs_kill_orphan_render',
                    // @NEW 2026-08-09: artifact cleanup cron
                    'mcqvs_daily_artifact_prune',
                ) as $hook) {
                    $cnt = count(as_get_scheduled_actions(array(
                        'hook'   => $hook,
                        'per_page' => 500,
                    ), 'ids'));
                    if ($cnt > 0) {
                        as_unschedule_all_actions($hook);
                        $as_cancelled += $cnt;
                    }
                }
            } catch (\Throwable $e) {
                $as_cancelled = -1; // Signal that the sweep was attempted but not counted.
            }
        }

        // Nuke WP cron events too for hosts that don't support AS fully.
        wp_clear_scheduled_hook('vs_daily_schedule_event');
        wp_clear_scheduled_hook('vs_headless_render_cron');
        wp_clear_scheduled_hook('vs_publish_scheduled_cron');
        wp_clear_scheduled_hook('mcqvs_daily_telemetry_prune');
        wp_clear_scheduled_hook('mcqvs_kill_orphan_render');
        wp_clear_scheduled_hook('mcqvs_render_claim');
        // @NEW 2026-08-09: Also clear the artifact cleanup cron.
        wp_clear_scheduled_hook('mcqvs_daily_artifact_prune');

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                "Master Reset Plugin: executed at {$now}. pids_nuked={$pids_nuked} tables_truncated={$truncated} transients_nuked={$trans_nuked} opt_keys_nuked={$opts_nuked} as_cancelled={$as_cancelled} preserve=vs_mcq_bank,vs_topics",
                'warning',
                array(
                    '_type'           => 'master_reset',
                    'pids_nuked'      => $pids_nuked,
                    'tables_truncated' => $truncated,
                    'transients_nuked' => $trans_nuked,
                    'opts_nuked'       => $opts_nuked,
                    'as_cancelled'     => $as_cancelled,
                )
            );
        }

        wp_send_json_success(array(
            'message'     => sprintf(
                'Plugin reset complete: %d table(s) truncated, %d transient(s) cleared, %d option(s) nuked, %d AS action(s) cancelled. vs_mcq_bank & vs_topics preserved. Reloading…',
                $truncated,
                $trans_nuked,
                $opts_nuked,
                $as_cancelled
            ),
            'pids_nuked'       => $pids_nuked,
            'tables_truncated' => $truncated,
            'transients_nuked' => $trans_nuked,
            'opts_nuked'       => $opts_nuked,
            'as_cancelled'     => $as_cancelled,
        ));
    }

    /**
     * AJAX: Delete all ready-for-render jobs from the pipeline.
     */
    public function ajax_clear_ready_jobs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        global $wpdb;
        $table = VS_Job_Repository::get_table_name();
        $deleted = $wpdb->delete($table, array('status' => VS_Job_Status::READY_FOR_RENDER));
        $count = $deleted !== false ? (int) $deleted : 0;
        wp_send_json_success(array(
            'message' => sprintf('Deleted %d ready-for-render job(s).', $count),
            'deleted' => $count,
        ));
    }

    /**
     * AJAX: Delete all queued (pending) jobs from the pipeline.
     */
    public function ajax_clear_queued_jobs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        global $wpdb;
        $table = VS_Job_Repository::get_table_name();
        $deleted = $wpdb->delete($table, array('status' => VS_Job_Status::PENDING));
        $count = $deleted !== false ? (int) $deleted : 0;
        wp_send_json_success(array(
            'message' => sprintf('Deleted %d queued job(s).', $count),
            'deleted' => $count,
        ));
    }

    /**
     * AJAX: Delete all pending + ready_for_render + rendering + uploading jobs (clear the full queue).
     */
    public function ajax_clear_queue()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        global $wpdb;
        $table = VS_Job_Repository::get_table_name();
        $deleted = $wpdb->delete($table, array('status' => VS_Job_Status::PENDING));
        $deleted2 = $wpdb->delete($table, array('status' => VS_Job_Status::READY_FOR_RENDER));
        $deleted3 = $wpdb->delete($table, array('status' => VS_Job_Status::RENDERING));
        $deleted4 = $wpdb->delete($table, array('status' => VS_Job_Status::UPLOADING));
        $count = ($deleted !== false ? (int) $deleted : 0) + ($deleted2 !== false ? (int) $deleted2 : 0) + ($deleted3 !== false ? (int) $deleted3 : 0) + ($deleted4 !== false ? (int) $deleted4 : 0);
        wp_send_json_success(array(
            'message' => sprintf('Cleared %d job(s) from queue.', $count),
            'deleted' => $count,
        ));
    }

    /**
     * AJAX: Delete all questions from the MCQ bank.
     */
    public function ajax_clear_questions()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        global $wpdb;
        $bank_table = $wpdb->prefix . 'vs_mcq_bank';
        $deleted = $wpdb->get_var("SELECT COUNT(*) FROM {$bank_table}");
        $wpdb->query("TRUNCATE TABLE {$bank_table}");
        wp_send_json_success(array(
            'message' => sprintf('Deleted %d question(s) from the bank.', (int) $deleted),
            'deleted' => (int) $deleted,
        ));
    }

    public function ajax_save_builtin_custom_models()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        if ($provider_id !== 'gemini') {
            wp_send_json_error('Invalid provider');
        }
        $models_raw = $_POST['models'] ?? '[]';
        if (is_string($models_raw)) {
            $models = json_decode(stripslashes($models_raw), true);
        } else {
            $models = array();
        }
        if (!is_array($models)) {
            $models = array();
        }

        VS_Provider_Registry::get_instance()->save_builtin_custom_models($provider_id, $models);

        wp_send_json_success(array('message' => 'Custom models saved.'));
    }

    /**
     * AJAX: Return live render progress for a job.
     *
     * Reads the status JSON written by render-node.js to surface the
     * node-side progress percentage (0-100) to the dashboard UI.
     */
    public function ajax_get_render_progress()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $job_id = sanitize_text_field(wp_unslash($_POST['job_id'] ?? ''));
        if (empty($job_id)) {
            wp_send_json_error('Missing job_id');
        }

        $status_file = get_transient('mcqvs_render_status_' . $job_id);
        if (empty($status_file) || !@is_readable($status_file)) {
            wp_send_json_success(array('progress' => -1, 'status' => 'unknown'));
            return;
        }

        $status = json_decode(@file_get_contents($status_file), true);
        if (!is_array($status)) {
            wp_send_json_success(array('progress' => -1, 'status' => 'unknown'));
            return;
        }

        wp_send_json_success(array(
            'progress' => isset($status['progress']) ? (int) $status['progress'] : -1,
            'status'   => $status['status'] ?? 'unknown',
        ));
    }

    public function ajax_get_diagnostics_logs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        $logger = VS_Error_Logger::get_instance();
        $logs = $logger->get_logs();
        wp_send_json_success(array(
            'logs' => $logs,
            'count' => count($logs),
            'server_time' => gmdate('Y-m-d H:i:s'),
        ));
    }

    /**
     * Add settings submenu page.
     *
     * @since 1.0.0
     */
    public function add_settings_page()
    {
        // 1. Settings (General/Buffer/R2)
        // @MODIFIED 2026-02-09: Removed redundant settings submenu. 
        // Settings are now tabs on the main Dashboard page (page=mcqvs-video-studio).
        /*
        add_submenu_page(
            'mcqvs-video-studio', // Parent slug (New Top Level)
            __('Video Studio Settings', 'mcq-video-studio'),
            __('Settings', 'mcq-video-studio'),
            'manage_options',
            'mcqvs-settings',
            array($this, 'render_settings_page')
        );
        */

        // 2. Automation Submenu
        // @MODIFIED 2026-02-09: Removed redundant Automation submenu.
        /*
        add_submenu_page(
            'mcqvs-video-studio',
            __('Video Automation', 'mcq-video-studio'),
            __('Automation', 'mcq-video-studio'),
            'manage_options',
            'mcqvs-automation',
            array($this, 'render_settings_page')
        );
        */
    }

    /**
     * Register settings.
     *
     * @since 1.0.0
     */
    public function register_settings()
    {
        // Buffer settings.
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_access_token', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // R2 settings.
        register_setting(self::OPTION_GROUP, 'mcqvs_r2_endpoint', array(
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_r2_access_key', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_r2_secret_key', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_r2_bucket', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_r2_public_domain', array(
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
        ));

        // Automation settings.
        register_setting(self::OPTION_GROUP, 'mcqvs_automation_enabled', array(
            'type'              => 'boolean',
            'default'           => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_automation_count', array(
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
        ));

        // @NEW 2026-01-10: Gemini Model Setting for AI Quiz Generation
        register_setting(self::OPTION_GROUP, 'mcqvs_gemini_model_id', array(
            'type'              => 'string',
            'default'           => 'gemini-3-flash-preview',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @NEW 2026-02-18: Gemini API Key Setting (Independent Mode)
        register_setting(self::OPTION_GROUP, 'mcqvs_gemini_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @FIX 1.4.9.45 (data-loss): "Delete all plugin data on uninstall" toggle.
        // Default 0 = KEEP all data (Content Planner, batches, generated Qs,
        // retention settings, API keys, uploads) when the plugin is removed/updated.
        register_setting(self::OPTION_GROUP, 'mcqvs_purge_data_on_uninstall', array(
            'type' => 'boolean',
            'default' => false,
            'sanitize_callback' => function ($val) {
                return $val ? 1 : 0;
            },
        ));

        // @NEW 2026-04-22: Delivery Mode (local / r2 / r2_buffer)
        register_setting(self::OPTION_GROUP, 'mcqvs_delivery_mode', array(
            'type' => 'string',
            'default' => 'local',
            'sanitize_callback' => function($val) {
                return in_array($val, array('local', 'r2', 'r2_buffer'), true) ? $val : 'local';
            },
        ));

        // @NEW 2026-04-22: Buffer Channel IDs (JSON array of channel IDs)
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_channels', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @FIX: Register the TTS provider so the canonical key is exposed to the Settings API
        //       and is editable via the Dashboard's API Settings form, alongside the legacy key.
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_provider', array(
            'type' => 'string',
            'default' => 'webspeech',
            'sanitize_callback' => function ($val) {
                $allowed = array('webspeech', 'google', 'azure', 'elevenlabs', 'edge');
                return in_array($val, $allowed, true) ? $val : 'webspeech';
            },
        ));

        // @NEW 2026-07-28: Voice rotation for automated content pipeline — cycles
        //       through a configurable list of Edge TTS English voices/accents so
        //       MCQ videos have natural variety across the publishing schedule.
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_voice_rotation_enabled', array(
            'type'              => 'boolean',
            'default'           => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_voice_rotation_list', array(
            'type'              => 'string',
            'default'           => '[]',
            'sanitize_callback' => function($val) {
                if (is_array($val)) {
                    $cleaned = array();
                    foreach ($val as $v) {
                        $cleaned[] = sanitize_text_field($v);
                    }
                    return wp_json_encode($cleaned);
                }
                if (is_string($val)) {
                    $decoded = json_decode($val, true);
                    if (is_array($decoded)) {
                        return wp_json_encode(array_map('sanitize_text_field', $decoded));
                    }
                    // Comma-separated fallback
                    $parts = array_map('trim', explode(',', $val));
                    return wp_json_encode(array_filter(array_map('sanitize_text_field', $parts)));
                }
                return '[]';
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_voice_rotation_index', array(
            'type'              => 'integer',
            'default'           => 0,
            'sanitize_callback' => 'absint',
        ));

        // @NEW 2026-07-28: Default TTS voice — used globally when rotation is disabled.
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_default_voice', array(
            'type'              => 'string',
            'default'           => 'en-US-AriaNeural',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @NEW 2026-08-11: "Speak the answer options aloud" toggle — reading all 4 options
        //       is the biggest TTS time cost. Disabling it keeps Shorts shorter without
        //       losing the question/answer narration. Consumed by the Content Planner /
        //       headless renderer defaults and seeded into the Studio voiceover defaults.
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_speak_options', array(
            'type'              => 'boolean',
            'default'           => true,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        // @FIX 1.4.9.49 (TTS SSOT): the rest of the TTS knobs are now Settings too.
        // Master TTS on/off (export + preview). Default ON (matches previous behavior).
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_enabled', array(
            'type'              => 'boolean',
            'default'           => true,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));
        // Speech rate (0.6x - 1.5x, default 1.2 — aligns with the server default).
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_rate', array(
            'type'              => 'number',
            'default'           => 1.2,
            'sanitize_callback' => function($val) {
                $v = (float) $val;
                if ($v < 0.5) $v = 0.5;
                if ($v > 2.0) $v = 2.0;
                return $v;
            },
        ));
        // What the TTS reads aloud (all default ON, matching prior behavior).
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_speak_hook', array(
            'type'              => 'boolean',
            'default'           => true,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_speak_answer', array(
            'type'              => 'boolean',
            'default'           => true,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_tts_speak_cta', array(
            'type'              => 'boolean',
            'default'           => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        // @NEW 2026-04-22: Buffer Caption Template
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_caption_template', array(
            'type' => 'string',
            'default' => "{hook}\n\n{topic}\nCan you score {score}/{total}?\n\n{hashtags}",
            'sanitize_callback' => function($val) {
                return sanitize_textarea_field($val);
            },
        ));

        // @NEW 2026-07-05: Buffer Channel Configuration
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_enabled_channels', array(
            'type' => 'string',
            'sanitize_callback' => function($val) {
                if (is_array($val)) {
                    return wp_json_encode(array_map('sanitize_text_field', $val));
                }
                return sanitize_text_field($val);
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_channel_types', array(
            'type' => 'string',
            'sanitize_callback' => function($val) {
                if (is_array($val)) {
                    $clean = array();
                    foreach ($val as $k => $v) {
                        $clean[sanitize_text_field($k)] = sanitize_text_field($v);
                    }
                    return wp_json_encode($clean);
                }
                return sanitize_text_field($val);
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_channel_link_posts', array(
            'type' => 'string',
            'sanitize_callback' => function($val) {
                if (is_array($val)) {
                    $clean = array();
                    foreach ($val as $k => $v) {
                        $clean[sanitize_text_field($k)] = absint($v);
                    }
                    return wp_json_encode($clean);
                }
                return sanitize_text_field($val);
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_scheduling_mode', array(
            'type' => 'string',
            'default' => 'addToQueue',
            'sanitize_callback' => function($val) {
                return in_array($val, array('addToQueue', 'customScheduled', 'shareNow'), true) ? $val : 'addToQueue';
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_daily_limit', array(
            'type' => 'integer',
            'default' => 0,
            'sanitize_callback' => function($val) { return max(0, absint($val)); },
        ));

        // @NEW 2026-08-01: Multi-account Buffer support.
        // @FIX 2026-08-08: mcqvs_buffer_accounts is intentionally NOT registered with
        // the Settings API. It is managed exclusively by AJAX. Registering it whitelists
        // the option so options.php would process (and sanitize/overwrite) it whenever a
        // mcqvs_buffer_accounts field lands in the POST — e.g. from a cached page snapshot
        // taken before an account was added — which wiped the freshly added account on a
        // routine "Save Settings". Unregistered, the Settings form can never touch it.
        // A pre_update_option_mcqvs_buffer_accounts guard (mcq-video-studio.php) provides
        // a second layer against direct update_option() writes of empty values.

        // @NEW 2026-08-10: Per-channel caption / story / YouTube maps for the
        // LEGACY default account. Multi-account installs persist the same data
        // inside the mcqvs_buffer_accounts option instead, so the registry
        // reads from there. These legacy keys exist so the save_settings() path
        // (when no accounts are registered yet) still round-trips per-channel
        // state instead of dropping it on the floor.
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_channel_captions', array(
            'type' => 'string',
            'sanitize_callback' => function ($val) {
                if (is_array($val)) {
                    $clean = array();
                    foreach ($val as $k => $v) {
                        $clean[sanitize_text_field($k)] = sanitize_textarea_field($v);
                    }
                    return wp_json_encode($clean);
                }
                return sanitize_text_field($val);
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_buffer_channel_post_to_story', array(
            'type' => 'string',
            'sanitize_callback' => function ($val) {
                if (is_array($val)) {
                    $clean = array();
                    foreach ($val as $k => $v) {
                        $clean[sanitize_text_field($k)] = !empty($v) ? 1 : 0;
                    }
                    return wp_json_encode($clean);
                }
                return sanitize_text_field($val);
            },
        ));

        // @NEW 2026-04-22: AI Batch Size (topics per API call)
        register_setting(self::OPTION_GROUP, 'mcqvs_ai_batch_size', array(
            'type' => 'integer',
            'default' => 10,
            'sanitize_callback' => function($val) {
                $v = absint($val);
                return ($v >= 3 && $v <= 25) ? $v : 10;
            },
        ));

        // @NEW 2026-04-22: Headless Rendering Settings
        register_setting(self::OPTION_GROUP, 'mcqvs_headless_rendering_enabled', array(
            'type'    => 'boolean',
            'default' => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_node_path', array(
            'type' => 'string',
            'default' => '/usr/bin/node',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_chrome_path', array(
            'type' => 'string',
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @NEW 2026-07-18 (server-side render): FFmpeg binary path for the
        //              browser-free Node renderer (replaces Chromium/Playwright).
        register_setting(self::OPTION_GROUP, 'mcqvs_ffmpeg_path', array(
            'type' => 'string',
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @FIX F7: Register Playwright browsers path option so the Dashboard Headless
        //         tab can persist a custom PLAYWRIGHT_BROWSERS_PATH shared by both the
        //         test-connection and render_job spawns.
        register_setting(self::OPTION_GROUP, 'mcqvs_playwright_path', array(
            'type' => 'string',
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_render_timeout', array(
            'type' => 'integer',
            'default' => 180,
            'sanitize_callback' => function($val) { $v = absint($val); return ($v >= 60 && $v <= 600) ? $v : 180; },
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_render_concurrency', array(
            'type' => 'integer',
            'default' => 1,
            'sanitize_callback' => function($val) { $v = absint($val); return ($v >= 1 && $v <= 4) ? $v : 1; },
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_gemini_custom_models', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));

	// @FIX: Pexels key was only read from parent plugin's option key (`nm_pexels_api_key`),
	//       making the stock feature dependent on the parent MCQ plugin. Provide a
	//       canonical mcqvs_pexels_api_key option that takes priority.
	register_setting(self::OPTION_GROUP, 'mcqvs_pexels_api_key', array(
		'type' => 'string',
		'sanitize_callback' => 'sanitize_text_field',
	));

        // @NEW 2026-04-24: Video Format (shorts | youtube)
        register_setting(self::OPTION_GROUP, 'mcqvs_video_format', array(
            'type' => 'string',
            'default' => 'shorts',
            'sanitize_callback' => function($val) {
                return in_array($val, array('shorts', 'youtube'), true) ? $val : 'shorts';
            },
        ));

        // @NEW 2026-08-11: Show the one-line 💡 explanation after the answer reveal.
        // Default OFF (ultra-minimal Shorts — explanation is not spoken, so videos stay
        // short either way; this only hides the on-screen learning bar).
        register_setting(self::OPTION_GROUP, 'mcqvs_show_explanation', array(
            'type'              => 'boolean',
            'default'           => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        // @NEW 2026-08-11: Strip emoji from ON-SCREEN text (hook) on server renders.
        // node-canvas cannot reliably draw color emoji or flag glyphs (they become
        // monochrome glyphs at best, tofu boxes on minimal VPS fonts). Captions and
        // YouTube titles keep the emoji (they use the original {hook} string), so
        // this only affects the video pixels. Default ON.
        register_setting(self::OPTION_GROUP, 'mcqvs_strip_emoji_on_screen', array(
            'type'              => 'boolean',
            'default'           => true,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        // @NEW 2026-05-07: Default publish time for social media scheduling
        register_setting(self::OPTION_GROUP, 'mcqvs_default_publish_time', array(
            'type' => 'string',
            'default' => '18:00',
            'sanitize_callback' => function($val) {
                $val = sanitize_text_field($val);
                if (preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $val)) {
                    return $val;
                }
                return '18:00';
            },
        ));

        // @NEW 2026-08-07: Publish time window — start..end bracket (HH:MM). The
        // Content Planner slots N-per-day evenly across [start, end]. Used as fallback
        // when a CSV row omits publish_time.
        register_setting(self::OPTION_GROUP, 'mcqvs_publish_time_window_start', array(
            'type' => 'string',
            'default' => '18:00',
            'sanitize_callback' => function($val) {
                $val = sanitize_text_field($val);
                return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $val) ? $val : '18:00';
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_publish_time_window_end', array(
            'type' => 'string',
            'default' => '21:00',
            'sanitize_callback' => function($val) {
                $val = sanitize_text_field($val);
                return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $val) ? $val : '21:00';
            },
        ));

        // Default publish frequency for Content Planner jobs
        register_setting(self::OPTION_GROUP, 'mcqvs_publish_frequency', array(
            'type' => 'string',
            'default' => 'daily',
            'sanitize_callback' => function($val) {
                $allowed = array('daily', 'twice_daily', 'every_3_days', 'weekly', 'asap');
                return in_array($val, $allowed, true) ? $val : 'daily';
            },
        ));

        // @NEW 2026-07-05: Provider failure cooldown (seconds)
        register_setting(self::OPTION_GROUP, 'mcqvs_provider_failure_cooldown', array(
            'type' => 'integer',
            'default' => 600,
            'sanitize_callback' => function($val) {
                $v = absint($val);
                if ($v < 60) $v = 60;
                if ($v > 7200) $v = 7200;
                return $v;
            },
        ));

        // @NEW 2026-05-07: Publish timezone offset (e.g. '+5:30' for IST)
        register_setting(self::OPTION_GROUP, 'mcqvs_publish_timezone', array(
            'type' => 'string',
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @NEW 2026-05-07: Auto-publish toggle (publish to Buffer after render+upload)
        register_setting(self::OPTION_GROUP, 'mcqvs_auto_publish_enabled', array(
            'type' => 'boolean',
            'default' => false,
            'sanitize_callback' => function($val) { return ($val === '1' || $val === 1 || $val === true) ? true : false; },
        ));

        // @NEW 2026-06-26: Custom Provider System
        register_setting(self::OPTION_GROUP, 'mcqvs_custom_providers', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        register_setting(self::OPTION_GROUP, 'mcqvs_api_provider', array(
            'type'    => 'string',
            'default' => 'gemini',
            'sanitize_callback' => function($val) {
                $registry = VS_Provider_Registry::get_instance();
                $allowed = $registry->get_all_ids();
                return in_array($val, $allowed, true) ? $val : 'gemini';
            },
        ));

        // @NEW 2026-07-03: External Assets Location
        register_setting(self::OPTION_GROUP, 'mcqvs_external_assets_url', array(
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_external_assets_path', array(
            'type'              => 'string',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        // @NEW 2026-07-06: Log Storage (retention days + visible count + total cap).
        // Storage moved from WP transient (1 hour) to wp_vs_logs table so configured
        // retention is actually honoured instead of silently expiring after 1 hour.
        register_setting(self::OPTION_GROUP, 'mcqvs_log_retention_days', array(
            'type'              => 'integer',
            'default'           => 7,
            'sanitize_callback' => function ($val) {
                $v = absint($val);
                if ($v < 1)   { $v = 1; }
                if ($v > 30)  { $v = 30; }
                return $v;
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_log_visible_count', array(
            'type'              => 'integer',
            'default'           => 25,
            'sanitize_callback' => function ($val) {
                $v = absint($val);
                $allowed = array(5, 10, 25, 50, 100, 250, 500);
                return in_array($v, $allowed, true) ? $v : 25;
            },
        ));
        register_setting(self::OPTION_GROUP, 'mcqvs_log_max_total', array(
            'type'              => 'integer',
            'default'           => 5000,
            'sanitize_callback' => function ($val) {
                $v = absint($val);
                if ($v < 500)   { $v = 500; }
                if ($v > 50000) { $v = 50000; }
                return $v;
            },
        ));

        // @NEW 2026-08-09: Artifact cleanup retention per category.
        // Sentinel value -1 means "not configured / disabled". 0 also disables.
        // Per user requirement: no defaults — admin must explicitly opt in.
        foreach (array('tts', 'covers', 'generated', 'exports', 'batch', 'render_temp', 'temp') as $cat) {
            register_setting(self::OPTION_GROUP, 'mcqvs_artifact_retention_' . $cat, array(
                'type'              => 'integer',
                'default'           => -1,
                'sanitize_callback' => function ($val) use ($cat) {
                    $v = (int) $val;
                    if ($v < -1) { $v = -1; }
                    if ($v > 365) { $v = 365; }
                    return $v;
                },
            ));
        }
        register_setting(self::OPTION_GROUP, 'mcqvs_artifact_retention_dry_run', array(
            'type'              => 'integer',
            'default'           => 0,
            'sanitize_callback' => function ($val) {
                return $val ? 1 : 0;
            },
        ));
    }

    /**
     * Enqueue settings assets.
     *
     * @since 1.0.0
     * @param string $hook Current admin page hook.
     */
    public function enqueue_settings_assets($hook)
    {
        // Use stored hook suffix instead of hardcoded string for portability.
        // Enqueue assets only on our specific settings pages.
        if (strpos($hook, 'mcqvs-') === false) {
            return;
        }

        wp_enqueue_style(
            'mcqvs-settings',
            MCQVS_PLUGIN_URL . 'assets/css/settings.css',
            array(),
            self::get_asset_file_version('assets/css/settings.css')
        );

        // @NEW 2026-08-10: Media Library for the Assets tab branding logo picker.
        wp_enqueue_media();

        wp_enqueue_script(
            'mcqvs-settings',
            MCQVS_PLUGIN_URL . 'assets/js/settings.js',
            array('jquery'),
            self::get_asset_file_version('assets/js/settings.js'),
            true
        );

        wp_localize_script('mcqvs-settings', 'mcqvsSettings', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('mcqvs_studio_nonce'),
            'i18n'    => array(
                'testing'    => __('Testing...', 'mcq-video-studio'),
                'success'    => __('Connection successful!', 'mcq-video-studio'),
                'failed'     => __('Connection failed: ', 'mcq-video-studio'),
                'running'    => __('Running automation...', 'mcq-video-studio'),
                'jobCreated' => __('Jobs created: ', 'mcq-video-studio'),
                'resetting'  => __('Resetting...', 'mcq-video-studio'),
                'resetPlugin' => __('Resetting Plugin…', 'mcq-video-studio'),
                'resetStuckConfirm' => __('Force-reset any wedged/stuck render jobs back to the queue? The next cron will re-spawn them.', 'mcq-video-studio'),
                'resetPluginConfirm' => __('WARNING: This will TRUNCATE all plugin tables (jobs, topics, projects, logs, exams) EXCEPT the MCQ bank. All settings (buffer, R2, rotation state, etc.) will remain intact. This operation cannot be undone. Continue?', 'mcq-video-studio'),
            ),
        ));
    }

    /**
     * Render dedicated Dashboard page.
     *
     * @since 1.5.0
     */
    public function render_dashboard_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $mcq_repo  = new VS_MCQ_Repository();
        $job_repo  = VS_Job_Repository::init();
        $logger    = VS_Error_Logger::get_instance();

        $stats_mcq = array(
            'total' => $mcq_repo->count_items('approved', 'total'),
            'today' => $mcq_repo->count_items('approved', 'today'),
        );
        $stats_jobs    = $job_repo->get_stats();
        $video_stats   = VS_Error_Logger::get_completed_video_stats();
        $api_usage     = $logger->get_daily_api_usage();
        $api_by_source = $logger->get_daily_api_usage_by_source();
        $recent_errors = $logger->get_recent_errors(5);
        $recent_batches = VS_Bulk_Scheduler::get_recent_batches(5);
        $pipeline      = $job_repo->get_status_breakdown();
        $recent_videos = $job_repo->get_recent_completed_jobs(5);
        $pipeline_jobs = $job_repo->get_recent_pipeline_jobs(15);
        $batch_tracker = get_option('mcqvs_batch_tracker', array());
        $rotation_status = class_exists('VS_Provider_Registry')
            ? VS_Provider_Registry::get_instance()->get_rotation_status()
            : array('providers' => array(), 'last_provider' => '', 'last_model' => '', 'consecutive_failures' => 0, 'current_index' => 0);

        $automation_enabled   = get_option('mcqvs_automation_enabled', false);
        $automation_count     = absint(get_option('mcqvs_automation_count', 3));
        $auto_publish_enabled = get_option('mcqvs_auto_publish_enabled', false);
        $next_daily           = wp_next_scheduled('vs_daily_schedule_event');
        $headless_cron        = function_exists('as_has_scheduled_action') && as_has_scheduled_action('vs_headless_render_cron');
        $publish_cron         = function_exists('as_has_scheduled_action') && as_has_scheduled_action('vs_publish_scheduled_cron');

        $r2_configured  = (bool) get_option('mcqvs_r2_access_key', '');
        $buf_configured = (bool) get_option('mcqvs_buffer_access_token', '');

        // @NEW 2026-08-08: Dashboard Buffer card reads ALL enabled accounts.
        $buffer_accounts = class_exists('VS_Buffer_Account_Registry') ? VS_Buffer_Account_Registry::get_accounts() : array();
        $active_buffer_accounts = array();
        if (is_array($buffer_accounts)) {
            foreach ($buffer_accounts as $aid => $acct) {
                if (!empty($acct['enabled']) && !empty($acct['token'])) {
                    $active_buffer_accounts[$aid] = $acct;
                }
            }
        }
        $buffer_account_count = count($active_buffer_accounts);
        $gemini_key     = (bool) get_option('mcqvs_gemini_api_key', '');
        $headless_url   = (bool) get_option('mcqvs_headless_rendering_enabled', '');

$queue_depth    = $pipeline['pending'] + $pipeline['ready_for_render'];
        $next_render    = null;
        global $wpdb;
        $as_table = $wpdb->prefix . 'actionscheduler_actions';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$as_table}'") === $as_table) {
            $next_render = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT scheduled_date_local FROM {$as_table} WHERE hook = %s AND status = 'pending' AND scheduled_date_local > NOW() ORDER BY scheduled_date_local ASC LIMIT 1",
                    'vs_headless_render_cron'
                )
            );
        }

        // Buffer stats: completed jobs with video_url that haven't been published yet
        $buffer_pending = 0;
        $buffer_scheduled = 0;
        $buffer_published = 0;
        $buffer_manual = 0;
        $buffer_manual_jobs = array();
        if (class_exists('VS_Job_Repository')) {
            $job_repo_buf = VS_Job_Repository::init();
            $completed_jobs = $job_repo_buf->get_jobs_by_status(VS_Job_Status::COMPLETED, 100);
            $now_gmt = gmdate('Y-m-d H:i:s');
            foreach ($completed_jobs as $j) {
                // Only Buffer-intended jobs (r2_buffer) belong in the Buffer pipeline card.
                // Plain r2/local jobs are completed-but-not-for-Buffer and must not be counted
                // as "pending" here — that is what produced the "Pending: 1 vs Not queued"
                // contradiction.
                $j_settings = is_string($j['settings'] ?? '') ? json_decode($j['settings'], true) : ($j['settings'] ?? array());
                $j_save_mode = is_array($j_settings) ? ($j_settings['save_mode'] ?? null) : null;
                if ($j_save_mode === null) {
                    $j_save_mode = get_option('mcqvs_delivery_mode', 'local');
                }
                if ($j_save_mode !== 'r2_buffer') {
                    continue;
                }
                $has_video = !empty($j['video_url']);
                $published = !empty($j['published_channels']);
                $publish_at = $j['publish_at'] ?? '';
                $manual_pending = is_array($j_settings) && !empty($j_settings['buffer_manual_pending']);
                if ($has_video) {
                    if ($published) {
                        $buffer_published++;
                    } elseif ($manual_pending) {
                        $buffer_manual++;
                        $buffer_manual_jobs[] = $j;
                    } elseif (!empty($publish_at) && $publish_at !== '0000-00-00 00:00:00' && $publish_at <= $now_gmt) {
                        $buffer_pending++;
                    } elseif (!empty($publish_at) && $publish_at !== '0000-00-00 00:00:00' && $publish_at > $now_gmt) {
                        $buffer_scheduled++;
                    } else {
                        $buffer_pending++; // completed, has video, no publish_at set = ready to publish
                    }
                }
            }
        }
        ?>
        <style>
            .mcqvs-dash{max-width:1400px;margin:0 auto;padding:20px 0 40px}
            .mcqvs-dash-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
            .mcqvs-dash-header h1{font-size:22px;font-weight:700;color:#1d2327;margin:0}
            .mcqvs-dash-header .mcqvs-dash-subtitle{font-size:13px;color:#787c82;margin-top:2px}
            .mcqvs-dash-kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px}
            .mcqvs-kpi{background:#fff;border:1px solid #e2e4e9;border-radius:8px;padding:20px 22px;position:relative;overflow:hidden;transition:box-shadow .15s}
            .mcqvs-kpi:hover{box-shadow:0 2px 8px rgba(0,0,0,.06)}
            .mcqvs-kpi-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;margin-bottom:12px}
            .mcqvs-kpi-icon.blue{background:#dbeafe;color:#2563eb}
            .mcqvs-kpi-icon.green{background:#dcfce7;color:#16a34a}
            .mcqvs-kpi-icon.amber{background:#fef3c7;color:#d97706}
            .mcqvs-kpi-icon.purple{background:#f3e8ff;color:#9333ea}
            .mcqvs-kpi-label{font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px}
            .mcqvs-kpi-value{font-size:28px;font-weight:700;color:#1e293b;line-height:1}
            .mcqvs-kpi-sub{font-size:12px;color:#94a3b8;margin-top:6px}
            .mcqvs-kpi-sub.up{color:#16a34a}
            .mcqvs-section{margin-bottom:28px}
            .mcqvs-section-title{font-size:14px;font-weight:700;color:#334155;margin-bottom:14px;display:flex;align-items:center;gap:8px}
            .mcqvs-section-title span{font-size:15px}
            .mcqvs-pipeline{display:grid;grid-template-columns:repeat(6,1fr);gap:12px}
            .mcqvs-pipe-item{background:#fff;border:1px solid #e2e4e9;border-radius:8px;padding:16px;text-align:center;position:relative}
            .mcqvs-pipe-dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-bottom:8px}
            .mcqvs-pipe-dot.pending{background:#facc15}
            .mcqvs-pipe-dot.ready{background:#3b82f6}
            .mcqvs-pipe-dot.rendering{background:#8b5cf6;animation:pulse 1.5s infinite}
            .mcqvs-pipe-dot.uploading{background:#f97316;animation:pulse 1.5s infinite}
            .mcqvs-pipe-dot.completed{background:#22c55e}
            .mcqvs-pipe-dot.failed{background:#ef4444}
            .mcqvs-pipe-dot.buffer{background:#06b6d4}
            .mcqvs-pipe-label{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
            .mcqvs-pipe-count{font-size:22px;font-weight:700;color:#1e293b}
            @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
            .mcqvs-dash-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
            .mcqvs-card{background:#fff;border:1px solid #e2e4e9;border-radius:8px;padding:20px 22px}
            .mcqvs-card-title{font-size:13px;font-weight:700;color:#334155;margin-bottom:14px;display:flex;align-items:center;gap:6px}
            .mcqvs-info-row{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid #f1f5f9;font-size:13px}
            .mcqvs-info-row:last-child{border-bottom:none}
            .mcqvs-info-label{color:#64748b}
            .mcqvs-info-value{font-weight:600;color:#1e293b}
            .mcqvs-badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:11px;font-weight:600}
            .mcqvs-badge.on{background:#dcfce7;color:#16a34a}
            .mcqvs-badge.off{background:#fee2e2;color:#dc2626}
            .mcqvs-badge.ok{background:#dbeafe;color:#2563eb}
            .mcqvs-error-list{max-height:260px;overflow-y:auto}
            .mcqvs-error-item{padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:12px}
            .mcqvs-error-item:last-child{border-bottom:none}
            .mcqvs-error-time{color:#94a3b8;font-size:11px;display:block;margin-bottom:3px}
            .mcqvs-error-msg{color:#dc2626;font-weight:500}
            .mcqvs-empty{text-align:center;padding:24px;color:#94a3b8;font-style:italic;font-size:13px}
            .mcqvs-timeline{list-style:none;padding:0;margin:0}
            .mcqvs-timeline li{position:relative;padding:10px 0 10px 22px;border-left:2px solid #e2e4e9;margin-bottom:8px}
            .mcqvs-timeline li::before{content:'';position:absolute;left:-5px;top:14px;width:8px;height:8px;border-radius:50%;background:#cbd5e1}
            .mcqvs-timeline li.done{border-left-color:#22c55e}.mcqvs-timeline li.done::before{background:#22c55e}
            .mcqvs-timeline li.running{border-left-color:#3b82f6}.mcqvs-timeline li.running::before{background:#3b82f6}
            .mcqvs-timeline li.err{border-left-color:#ef4444}.mcqvs-timeline li.err::before{background:#ef4444}
            .mcqvs-batch-topic{font-weight:600;color:#1e293b;font-size:13px}
            .mcqvs-batch-meta{font-size:11px;color:#94a3b8;margin-top:2px}
            .mcqvs-table{width:100%;border-collapse:collapse;font-size:13px}
            .mcqvs-table th{text-align:left;padding:8px 10px;border-bottom:2px solid #e2e4e9;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.5px}
            .mcqvs-table td{padding:8px 10px;border-bottom:1px solid #f1f5f9}
            .mcqvs-table tr:last-child td{border-bottom:none}
            .mcqvs-delivery-badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600}
            .mcqvs-delivery-badge.r2{background:#dbeafe;color:#2563eb}
            .mcqvs-delivery-badge.local{background:#dcfce7;color:#16a34a}
            .mcqvs-delivery-badge.none{background:#f1f5f9;color:#94a3b8}
            .mcqvs-api-split{margin-top:12px;display:flex;flex-direction:column;gap:5px}
            .mcqvs-api-none{font-size:12px;color:#94a3b8;font-style:italic}
            .mcqvs-api-chip{display:flex;align-items:center;gap:6px;font-size:11px;line-height:1}
            .mcqvs-api-chip-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
            .mcqvs-api-chip-name{width:auto;min-width:0;flex-shrink:0;font-weight:600;color:#475569;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:110px}
            .mcqvs-api-chip-bar{flex:1;height:4px;background:#eef2f7;border-radius:2px;overflow:hidden;min-width:30px}
            .mcqvs-api-chip-bar span{display:block;height:100%;background:linear-gradient(90deg,#6366f1,#8b5cf6);border-radius:2px}
            .mcqvs-api-chip-count{width:28px;text-align:right;font-weight:700;color:#1e293b;font-variant-numeric:tabular-nums}
        </style>

        <div class="mcqvs-dash">
            <div class="mcqvs-dash-header">
                <div>
                    <h1><?php esc_html_e('Video Studio Dashboard', 'mcq-video-studio'); ?></h1>
                    <div class="mcqvs-dash-subtitle"><?php esc_html_e('Real-time overview of your video pipeline', 'mcq-video-studio'); ?></div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:nowrap;">
                    <?php
                    // @FIX 1.4.9.58: one compact row — Stop/Resume (single toggle), Restore,
                    // Reset. Settings + Open Studio buttons removed (they're one click away
                    // in the left admin menu and were wrapping the header onto 2 rows).
                    $mcqvs_stopped = function_exists('mcqvs_is_global_stopped') ? mcqvs_is_global_stopped() : false;
                    $mcqvs_stop_time = function_exists('mcqvs_global_stop_time') ? mcqvs_global_stop_time() : 0;
                    ?>
                    <?php if ($mcqvs_stopped) : ?>
                        <button type="button" id="mcqvs-resume-all" class="button button-primary" style="background:#16a34a;border-color:#16a34a;color:#fff;white-space:nowrap;" title="Resume the pipeline. Overdue jobs are skipped; future jobs stay on schedule.">▶ Resume</button>
                        <span id="mcqvs-global-stop-status" class="button" style="background:#dc2626;color:#fff;border-color:#dc2626;cursor:default;white-space:nowrap;">
                            <?php
                            echo '⏹ STOPPED';
                            if ($mcqvs_stop_time) {
                                echo ' ' . esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $mcqvs_stop_time));
                            }
                            ?>
                        </span>
                    <?php else : ?>
                        <button type="button" id="mcqvs-stop-all" class="button" style="background:#dc2626;border-color:#dc2626;color:#fff;white-space:nowrap;" title="Kills live renders, cancels all queues/crons/AI batches and blocks new Buffer posts. No data is deleted.">⏹ Stop Everything</button>
                    <?php endif; ?>
                    <button type="button" id="mcqvs-restore-backup" class="button button-secondary" title="Refills missing Content Planner / batch tracker / retention settings from the last auto-backup (never overwrites existing data)."><?php esc_html_e('Restore Safety Backup', 'mcq-video-studio'); ?></button>
                    <button type="button" id="mcqvs-reset-plugin" class="button button-secondary" style="color:#dc2626;border-color:#dc2626;white-space:nowrap;"><?php esc_html_e('Reset Plugin', 'mcq-video-studio'); ?></button>
                </div>
            </div>

            <!-- KPI Cards -->
            <div class="mcqvs-dash-kpi">
                <div class="mcqvs-kpi">
                    <div class="mcqvs-kpi-icon blue">&#9998;</div>
                    <div class="mcqvs-kpi-label"><?php esc_html_e('Questions Generated', 'mcq-video-studio'); ?></div>
                    <div class="mcqvs-kpi-value"><?php echo esc_html($stats_mcq['total']); ?></div>
                    <div class="mcqvs-kpi-sub <?php echo $stats_mcq['today'] > 0 ? 'up' : ''; ?>">+<?php echo esc_html($stats_mcq['today']); ?> <?php esc_html_e('today', 'mcq-video-studio'); ?></div>
                    <?php if ($stats_mcq['total'] > 0) : ?>
                    <button type="button" id="mcqvs-clear-questions" class="button button-small" style="font-size:10px;padding:2px 8px;color:#dc2626;border-color:#dc2626;width:100%;margin-top:6px;"><?php esc_html_e('Clear Questions', 'mcq-video-studio'); ?></button>
                    <?php endif; ?>
                </div>
                <div class="mcqvs-kpi">
                    <div class="mcqvs-kpi-icon green">&#9654;</div>
                    <div class="mcqvs-kpi-label"><?php esc_html_e('Videos Created', 'mcq-video-studio'); ?></div>
                    <div class="mcqvs-kpi-value"><?php echo esc_html($video_stats['total']); ?></div>
                    <div class="mcqvs-kpi-sub <?php echo $video_stats['today'] > 0 ? 'up' : ''; ?>">+<?php echo esc_html($video_stats['today']); ?> <?php esc_html_e('today', 'mcq-video-studio'); ?></div>
                </div>
                <div class="mcqvs-kpi">
                    <div class="mcqvs-kpi-icon amber">&#9881;</div>
                    <div class="mcqvs-kpi-label"><?php esc_html_e('Jobs in Queue', 'mcq-video-studio'); ?></div>
                    <div class="mcqvs-kpi-value"><?php echo esc_html($stats_jobs['pending']); ?></div>
                    <div class="mcqvs-kpi-sub" style="margin-bottom:6px;"><?php esc_html_e('Awaiting processing', 'mcq-video-studio'); ?></div>
                    <?php if ($stats_jobs['pending'] > 0) : ?>
                    <button type="button" id="mcqvs-clear-queue" class="button button-small" style="font-size:10px;padding:2px 8px;color:#dc2626;border-color:#dc2626;width:100%;"><?php esc_html_e('Clear Queue', 'mcq-video-studio'); ?></button>
                    <?php endif; ?>
                </div>
                <div class="mcqvs-kpi">
                    <div class="mcqvs-kpi-icon purple">&#128200;</div>
                    <div class="mcqvs-kpi-label"><?php esc_html_e('API Calls Today', 'mcq-video-studio'); ?></div>
                    <div class="mcqvs-kpi-value"><?php echo esc_html($api_usage); ?></div>
                    <?php
                    $api_source_labels = array('buffer' => __('Buffer', 'mcq-video-studio'), 'other' => __('Other', 'mcq-video-studio'));
                    if (class_exists('VS_Provider_Registry')) {
                        $reg = VS_Provider_Registry::get_instance();
                        foreach ($reg->get_builtin_providers() as $pid => $pcfg) {
                            $api_source_labels[$pid] = $pcfg['name'] ?? ucfirst($pid);
                        }
                        foreach ($reg->get_custom_providers() as $profile) {
                            if (! empty($profile['id'])) {
                                $api_source_labels[$profile['id']] = ! empty($profile['name']) ? $profile['name'] : $profile['id'];
                            }
                        }
                    }
                    $api_sorted = $api_by_source;
                    arsort($api_sorted);
                    ?>
                    <div class="mcqvs-api-split">
                        <?php if (empty($api_sorted)) : ?>
                            <div class="mcqvs-api-none"><?php esc_html_e('No calls yet', 'mcq-video-studio'); ?></div>
                        <?php else : ?>
                            <?php foreach ($api_sorted as $src => $cnt) : ?>
                                <div class="mcqvs-api-chip">
                                    <span class="mcqvs-api-chip-dot" style="background:<?php echo esc_attr($src === 'buffer' ? '#06b6d4' : ($src === 'other' ? '#94a3b8' : '#6366f1')); ?>"></span>
                                    <span class="mcqvs-api-chip-name"><?php echo esc_html($api_source_labels[$src] ?? ucfirst($src)); ?></span>
                                    <span class="mcqvs-api-chip-bar"><span style="width:<?php echo esc_attr($api_usage > 0 ? min(100, round($cnt / $api_usage * 100)) : 0); ?>%"></span></span>
                                    <span class="mcqvs-api-chip-count"><?php echo esc_html($cnt); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Pipeline Status -->
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#9673;</span> <?php esc_html_e('Pipeline Status', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-pipeline">
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot pending"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Pending', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($pipeline['pending']); ?></div>
                        <?php if ($pipeline['pending'] > 0) : ?>
                        <button type="button" id="mcqvs-clear-queued" class="button button-small" style="margin-top:8px;font-size:10px;padding:2px 8px;color:#dc2626;border-color:#dc2626;"><?php esc_html_e('Clear', 'mcq-video-studio'); ?></button>
                        <?php endif; ?>
                    </div>
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot ready"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Ready', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($pipeline['ready_for_render']); ?></div>
                        <?php if ($pipeline['ready_for_render'] > 0) : ?>
                        <button type="button" id="mcqvs-clear-ready" class="button button-small" style="margin-top:8px;font-size:10px;padding:2px 8px;color:#dc2626;border-color:#dc2626;"><?php esc_html_e('Clear', 'mcq-video-studio'); ?></button>
                        <?php endif; ?>
                    </div>
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot rendering"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Rendering', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($pipeline['rendering']); ?></div>
                        <?php if ($pipeline['rendering'] > 0) :
                            // @FIX 2026-08-07: Show ALL active rendering jobs (not just the
                            // first) in the Rendering card, each with its own progress bar
                            // color so concurrent renders are individually trackable.
                            $render_colors = array(
                                array('#8b5cf6', '#a78bfa'),
                                array('#f59e0b', '#fbbf24'),
                                array('#10b981', '#34d399'),
                                array('#ef4444', '#f87171'),
                                array('#06b6d4', '#22d3ee'),
                                array('#ec4899', '#f472b6'),
                            );
                            $rendering_jobs = $job_repo->get_jobs_by_status(VS_Job_Status::RENDERING, 50);
                            $render_idx = 0;
                            foreach ((array) $rendering_jobs as $rj) :
                                $rj_settings = is_string($rj['settings'] ?? '') ? json_decode($rj['settings'], true) : (is_array($rj['settings'] ?? null) ? $rj['settings'] : array());
                                $rj_topic = is_array($rj_settings) ? ($rj_settings['topic_name'] ?? '') : '';
                                if ($rj_topic === '') {
                                    $rj_topic = $rj['job_id'] ?? '';
                                }
                                $rc = $render_colors[$render_idx % count($render_colors)];
                                $render_idx++;
                        ?>
                            <div style="font-size:9px;color:#64748b;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:150px;" title="<?php echo esc_attr($rj_topic); ?>"><?php echo esc_html($rj_topic); ?></div>
                            <div class="mcqvs-render-progress" data-job-id="<?php echo esc_attr($rj['job_id'] ?? ''); ?>" style="margin-top:3px;">
                                <div style="display:flex;align-items:center;gap:6px;">
                                    <div style="flex:1;height:5px;background:#e2e8f0;border-radius:3px;overflow:hidden;">
                                        <div class="mcqvs-render-progress-bar" style="width:0%;height:100%;background:linear-gradient(90deg,<?php echo esc_attr($rc[0]); ?>,<?php echo esc_attr($rc[1]); ?>);border-radius:3px;transition:width 0.5s ease;"></div>
                                    </div>
                                    <span class="mcqvs-render-progress-pct" style="font-size:11px;font-weight:600;color:<?php echo esc_attr($rc[0]); ?>;min-width:32px;text-align:right;">0%</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot uploading"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Uploading', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($pipeline['uploading']); ?></div>
                    </div>
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot completed"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Completed', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($pipeline['completed']); ?></div>
                    </div>
                    <!-- Buffer Card (6th) -->
                    <div class="mcqvs-pipe-item">
                        <div class="mcqvs-pipe-dot buffer"></div>
                        <div class="mcqvs-pipe-label"><?php esc_html_e('Buffer', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-pipe-count"><?php echo esc_html($buffer_pending + $buffer_scheduled); ?></div>
                        <div style="font-size:9px;color:#94a3b8;margin-top:2px;">
                            <?php esc_html_e('Pending', 'mcq-video-studio'); ?>: <?php echo esc_html($buffer_pending); ?> |
                            <?php esc_html_e('Scheduled', 'mcq-video-studio'); ?>: <?php echo esc_html($buffer_scheduled); ?> |
                            <?php esc_html_e('Done', 'mcq-video-studio'); ?>: <?php echo esc_html($buffer_published); ?>
                        </div>
                        <?php if (!empty($active_buffer_accounts)) : ?>
                        <div style="margin-top:8px;padding-top:6px;border-top:1px solid #f1f5f9;font-size:9px;color:#64748b;text-align:left;max-height:80px;overflow-y:auto;">
                            <div style="font-weight:700;margin-bottom:3px;color:#475569;">
                                <?php echo esc_html($buffer_account_count); ?> <?php esc_html_e('account(s)', 'mcq-video-studio'); ?>
                            </div>
                            <?php foreach ($active_buffer_accounts as $aid => $acct) :
                                $acct_label = $acct['label'] ?? $aid;
                                $acct_channels = (int) count($acct['channels'] ?? array());
                            ?>
                            <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                <?php echo esc_html($acct_label); ?>
                                <span style="color:#94a3b8;">&middot; <?php echo esc_html($acct_channels); ?> ch</span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <?php if ($buffer_manual > 0) : ?>
                        <div style="margin-top:10px;padding-top:8px;border-top:1px solid #fef2f2;">
                            <div style="font-size:10px;color:#dc2626;font-weight:700;margin-bottom:6px;">
                                &#9888; <?php echo esc_html($buffer_manual); ?> <?php esc_html_e('need manual push', 'mcq-video-studio'); ?>
                            </div>
                            <?php $first_manual_job = reset($buffer_manual_jobs); if ($first_manual_job) : ?>
                            <div style="font-size:9px;color:#64748b;margin-bottom:6px;word-break:break-all;">
                                <?php echo esc_html($first_manual_job['job_id']); ?>
                                <?php
                                $jset = is_string($first_manual_job['settings'] ?? '') ? json_decode($first_manual_job['settings'], true) : array();
                                if (is_array($jset) && !empty($jset['buffer_last_error'])) {
                                    echo '<br><span style="color:#dc2626;">' . esc_html(substr($jset['buffer_last_error'], 0, 80)) . '</span>';
                                }
                                ?>
                            </div>
                            <button type="button" class="button button-small button-secondary mcqvs-manual-buffer-push"
                                data-job-id="<?php echo esc_attr($first_manual_job['job_id']); ?>"
                                style="font-size:10px;padding:2px 8px;">
                                &#9654; <?php esc_html_e('Push Now', 'mcq-video-studio'); ?>
                            </button>
                            <span class="mcqvs-manual-buffer-status" style="margin-left:4px;font-size:10px;"></span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <script>
                jQuery(function($) {
                    $('.mcqvs-manual-buffer-push').on('click', function() {
                        var btn = $(this);
                        var statusEl = btn.siblings('.mcqvs-manual-buffer-status');
                        var jobId = btn.data('job-id');
                        btn.prop('disabled', true);
                        statusEl.text('Pushing...');
                        $.post(mcqvsSettings.ajaxUrl, {
                            action: 'mcqvs_manual_buffer_push',
                            nonce: mcqvsSettings.nonce,
                            job_id: jobId
                        }, function(res) {
                            if (res.success) {
                                statusEl.text('Done!');
                                setTimeout(function() { location.reload(); }, 1500);
                            } else {
                                statusEl.text(res.data);
                                btn.prop('disabled', false);
                            }
                        }).fail(function() {
                            statusEl.text('Request failed');
                            btn.prop('disabled', false);
                        });
                    });
                });
                </script>
            </div>

            <!-- Schedule + Services -->
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#9881;</span> <?php esc_html_e('Automation & Services', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-dash-grid">
                    <div class="mcqvs-card">
                        <div class="mcqvs-card-title">&#9200; <?php esc_html_e('Schedule Overview', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Automation', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $automation_enabled ? 'on' : 'off'; ?>"><?php echo $automation_enabled ? __('Enabled', 'mcq-video-studio') : __('Disabled', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Daily Job Limit', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value"><?php echo esc_html($automation_count); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Next Daily Run', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value"><?php echo $next_daily ? wp_date(get_option('time_format') . ' — ' . get_option('date_format'), $next_daily) : __('Not scheduled', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Render Cron', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $headless_cron ? 'on' : 'off'; ?>"><?php echo $headless_cron ? __('Active', 'mcq-video-studio') : __('Inactive', 'mcq-video-studio'); ?></span>
                        </div>
                        <?php if ($headless_cron) : ?>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Next Render Run', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value"><?php echo $next_render ? get_date_from_gmt($next_render, get_option('time_format') . ' — ' . get_option('date_format')) : __('Within 5 min', 'mcq-video-studio'); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($queue_depth > 0) : ?>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Jobs in Queue', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value" style="color:#d97706;font-weight:700"><?php echo esc_html($queue_depth); ?> <?php esc_html_e('awaiting processing', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Est. Queue Clear', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value"><?php
                                $concurrency = max(1, absint(get_option('mcqvs_render_concurrency', 1)));
                                $render_timeout = absint(get_option('mcqvs_render_timeout', 180));
                                // Match the effective floor so the dashboard estimate is accurate.
                                if ($render_timeout < 600) { $render_timeout = 900; }
                                $batches = ceil($queue_depth / $concurrency);
                                $est_seconds = $batches * ($render_timeout + 30);
                                echo esc_html(human_time_diff(time(), time() + $est_seconds));
                            ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Publish Cron', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $publish_cron ? 'on' : 'off'; ?>"><?php echo $publish_cron ? __('Active', 'mcq-video-studio') : __('Inactive', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Auto-Publish', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $auto_publish_enabled ? 'on' : 'off'; ?>"><?php echo $auto_publish_enabled ? __('Enabled', 'mcq-video-studio') : __('Disabled', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row" style="margin-top:10px">
                            <button type="button" id="mcqvs-reset-stuck" class="button button-secondary">
                                &#9888; <?php esc_html_e('Reset Stuck Pipeline', 'mcq-video-studio'); ?>
                            </button>
                            <span id="mcqvs-reset-stuck-status" class="mcqvs-status" style="margin-left:8px"></span>
                        </div>
                    </div>
                    <div class="mcqvs-card">
                        <div class="mcqvs-card-title">&#128737; <?php esc_html_e('Service Health', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Gemini API', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $gemini_key ? 'ok' : 'off'; ?>"><?php echo $gemini_key ? __('Configured', 'mcq-video-studio') : __('Not Set', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Buffer', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $buf_configured ? 'ok' : 'off'; ?>"><?php echo $buf_configured ? __('Connected', 'mcq-video-studio') : __('Not Set', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Cloudflare R2', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $r2_configured ? 'ok' : 'off'; ?>"><?php echo $r2_configured ? __('Configured', 'mcq-video-studio') : __('Not Set', 'mcq-video-studio'); ?></span>
                        </div>
                        <?php
                        // Surface the silent R2 misconfiguration: public domain pointing at the
                        // WordPress site instead of the R2 CDN -> "R2 ↗" links 404 and Buffer
                        // receives an unplayable URL. This is exactly what produced the
                        // https://test.dailyinfotainment.com/videos/... 404 reported by the user.
                        $r2_public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
                        $r2_domain_bad   = false;
                        $r2_bad_reason   = '';
                        if ($r2_configured && $r2_public_domain === '') {
                            $r2_domain_bad = true;
                            $r2_bad_reason = 'not set — stored URLs are unplayable';
                        } elseif ($r2_configured && $r2_public_domain !== '') {
                            $pd_host   = wp_parse_url($r2_public_domain, PHP_URL_HOST);
                            $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
                            if ($pd_host && $site_host && strtolower((string) $pd_host) === strtolower((string) $site_host)) {
                                $r2_domain_bad = true;
                                $r2_bad_reason = 'points at this WordPress site — R2 links 404';
                            }
                        }
                        ?>
                        <?php if ($r2_domain_bad) : ?>
                        <div class="mcqvs-info-row" style="background:#fef2f2;">
                            <span class="mcqvs-info-label">R2 Public Domain</span>
                            <span class="mcqvs-badge off">&#9888; <?php echo esc_html($r2_bad_reason); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Headless Renderer', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-badge <?php echo $headless_url ? 'ok' : 'off'; ?>"><?php echo $headless_url ? __('Configured', 'mcq-video-studio') : __('Not Set', 'mcq-video-studio'); ?></span>
                        </div>
                        <div class="mcqvs-info-row">
                            <span class="mcqvs-info-label"><?php esc_html_e('Failed Jobs', 'mcq-video-studio'); ?></span>
                            <span class="mcqvs-info-value" style="color:<?php echo $pipeline['failed'] > 0 ? '#dc2626' : '#16a34a'; ?>"><?php echo esc_html($pipeline['failed']); ?></span>
                        </div>
                    </div>
                </div>
            </div>

<!-- Recent Videos -->
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#9654;</span> <?php esc_html_e('Recent Videos', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-card">
                    <?php if (empty($recent_videos)) : ?>
                        <div class="mcqvs-empty"><?php esc_html_e('No completed videos yet.', 'mcq-video-studio'); ?></div>
                    <?php else : ?>
                        <table class="mcqvs-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Topic', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Completed', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Video', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Buffer', 'mcq-video-studio'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_videos as $vid) :
                                    $has_r2 = !empty($vid['video_url']);
                                    $has_local = !empty($vid['video_path']);
                                    $video_url = $has_r2 ? $vid['video_url'] : ($has_local ? $vid['video_path'] : '');
                                    $completed_ts = $vid['completed_at'] ? strtotime($vid['completed_at'] . ' UTC') : 0;

                                    // Buffer status
                                    $published_channels = !empty($vid['published_channels']) ? json_decode($vid['published_channels'], true) : [];
                                    $buffer_post_ids = !empty($vid['buffer_post_ids']) ? json_decode($vid['buffer_post_ids'], true) : [];
                                    $publish_at_ts = !empty($vid['publish_at']) && $vid['publish_at'] !== '0000-00-00 00:00:00' ? strtotime($vid['publish_at'] . ' UTC') : 0;
                                    $vid_settings = is_string($vid['settings'] ?? '') ? json_decode($vid['settings'], true) : ($vid['settings'] ?? array());
                                    $vid_save_mode = is_array($vid_settings) ? ($vid_settings['save_mode'] ?? null) : null;
                                    if ($vid_save_mode === null) {
                                        $vid_save_mode = get_option('mcqvs_delivery_mode', 'local');
                                    }
                                    $is_buffer_intended = ($vid_save_mode === 'r2_buffer');

                                    // Resolve channel names from IDs
                                    $buffer_channel_names = array();
                                    if (!empty($published_channels) && is_array($published_channels)) {
                                        $saved_channels = json_decode(get_option('mcqvs_buffer_channels', '[]'), true);
                                        $channel_map = array();
                                        if (is_array($saved_channels)) {
                                            foreach ($saved_channels as $ch) {
                                                if (isset($ch['id'], $ch['name'])) {
                                                    $channel_map[$ch['id']] = $ch['name'];
                                                }
                                            }
                                        }
                                        foreach ($published_channels as $cid) {
                                            $buffer_channel_names[] = $channel_map[$cid] ?? $cid;
                                        }
                                    }

                                    $buffer_html = '';
                                    if (!empty($published_channels) && is_array($published_channels)) {
                                        $buffer_html = '<span class="mcqvs-badge on" style="font-size:10px;">' . esc_html__('Published', 'mcq-video-studio') . ' (' . count($published_channels) . ' ch)</span>';
                                        if (!empty($buffer_channel_names) && is_array($buffer_channel_names)) {
                                            $buffer_html .= '<br><small style="color:#64748b;">' . esc_html(implode(', ', array_slice($buffer_channel_names, 0, 3))) . (count($buffer_channel_names) > 3 ? '...' : '') . '</small>';
                                        }
                                    } elseif ($publish_at_ts > 0) {
                                        $buffer_html = '<span class="mcqvs-badge" style="background:#fef3c7;color:#d97706;font-size:10px;">' . esc_html__('Scheduled', 'mcq-video-studio') . '</span>';
                                        $buffer_html .= '<br><small style="color:#64748b;">' . wp_date(get_option('time_format') . ' \u2014 ' . get_option('date_format'), $publish_at_ts) . '</small>';
                                    } elseif ($is_buffer_intended && $has_r2) {
                                        // Completed r2_buffer job, not yet pushed: it IS pending Buffer.
                                        $buffer_html = '<span class="mcqvs-badge" style="background:#dbeafe;color:#2563eb;font-size:10px;">' . esc_html__('Ready to publish', 'mcq-video-studio') . '</span>';
                                    } else {
                                        $buffer_html = '<span class="mcqvs-badge off" style="font-size:10px;">' . esc_html__('Not queued', 'mcq-video-studio') . '</span>';
                                    }
                                ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($vid['topic_name']); ?></strong></td>
                                        <td><?php echo $completed_ts ? wp_date(get_option('time_format') . ' &#8212; ' . get_option('date_format'), $completed_ts) : '&#8212;'; ?></td>
<td>
                                            <?php if ($video_url) : ?>
                                                <a href="<?php echo esc_url($video_url); ?>" target="_blank" rel="noopener" class="mcqvs-delivery-badge <?php echo esc_attr($has_r2 ? 'r2' : 'local'); ?>" style="text-decoration:none;display:inline-block;">
                                                    <?php echo esc_html($has_r2 ? 'R2 ↗' : 'Local ↗'); ?>
                                                </a>
                                            <?php else : ?>
                                                <span class="mcqvs-delivery-badge none">&#8212;</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $buffer_html; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            </div>

            <!-- Provider Rotation Status -->
            <?php if (!empty($rotation_status['providers'])) : ?>
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#128260;</span> <?php esc_html_e('AI Provider Rotation', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-card">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                        <div>
                            <strong><?php esc_html_e('Last used:', 'mcq-video-studio'); ?></strong>
                            <code><?php echo esc_html($rotation_status['last_provider'] ?: '—'); ?> / <?php echo esc_html($rotation_status['last_model'] ?: '—'); ?></code>
                        </div>
                        <div>
                            <?php if ((int) $rotation_status['consecutive_failures'] > 0) : ?>
                                <span class="mcqvs-badge off"><?php printf(esc_html__('%d consecutive failures', 'mcq-video-studio'), (int) $rotation_status['consecutive_failures']); ?></span>
                            <?php else : ?>
                                <span class="mcqvs-badge on">OK</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <table class="mcqvs-table">
                        <thead><tr><th><?php esc_html_e('Provider', 'mcq-video-studio'); ?></th><th><?php esc_html_e('Models', 'mcq-video-studio'); ?></th><th><?php esc_html_e('Failures', 'mcq-video-studio'); ?></th><th><?php esc_html_e('Cooldown Until', 'mcq-video-studio'); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ($rotation_status['providers'] as $prov) :
                            $cd = (int) $prov['cooldown_until'];
                            $cd_in_future = $cd > time();
                            $cd_label = $cd_in_future ? esc_html(wp_date(get_option('time_format') . ' — ' . get_option('date_format'), $cd)) : '—';
                            $fail = (int) $prov['failures'];
                            $fail_color = $fail > 3 ? '#dc2626' : ($fail > 0 ? '#f59e0b' : '#16a34a');
                            // @FIX 1.5.1: models is now an array of {model,label,...}; extract labels.
                            $model_labels = array();
                            if (is_array($prov['models'])) {
                                foreach ($prov['models'] as $_m) {
                                    $model_labels[] = is_array($_m) ? ($_m['label'] ?? $_m['model'] ?? '') : (string) $_m;
                                }
                            }
                            $models_short = implode(', ', array_slice($model_labels, 0, 3)) . (count($model_labels) > 3 ? '…' : '');
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($prov['label'] ?: $prov['provider']); ?></strong><br><small style="color:#94a3b8;"><?php echo esc_html($prov['provider']); ?></small></td>
                                <td><small><?php echo esc_html($models_short); ?></small></td>
                                <td><span style="color:<?php echo esc_attr($fail_color); ?>;font-weight:600;"><?php echo esc_html($fail); ?></span></td>
                                <td><?php echo $cd_in_future ? '<span style="color:#f59e0b;font-weight:600;">' . $cd_label . '</span>' : $cd_label; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- Pipeline Jobs (active + recent) -->
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#128221;</span> <?php esc_html_e('Pipeline Jobs (Active & Recent)', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-card">
                    <?php if (empty($pipeline_jobs)) : ?>
                        <div class="mcqvs-empty"><?php esc_html_e('No active pipeline jobs.', 'mcq-video-studio'); ?></div>
                    <?php else : ?>
                        <table class="mcqvs-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Topic', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Status', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Progress', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Qs', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Created', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Publish At', 'mcq-video-studio'); ?></th>
                                    <th><?php esc_html_e('Buffer Status', 'mcq-video-studio'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                // @FIX 2026-08-07: Per-job progress bar colors in the pipeline
                                // table so concurrent renders are individually trackable.
                                $render_palette = array(
                                    array('#8b5cf6', '#a78bfa'),
                                    array('#f59e0b', '#fbbf24'),
                                    array('#10b981', '#34d399'),
                                    array('#ef4444', '#f87171'),
                                    array('#06b6d4', '#22d3ee'),
                                    array('#ec4899', '#f472b6'),
                                );

                                // @NEW 2026-08-08: Build one channel-id => name map from the
                                // legacy option AND every account's per-account channel cache,
                                // so the "Buffer Status" column resolves names for posts that
                                // were pushed through any of the enabled accounts.
                                $all_channel_map = array();
                                $legacy_channels_raw = json_decode(get_option('mcqvs_buffer_channels', '[]'), true);
                                if (is_array($legacy_channels_raw)) {
                                    foreach ($legacy_channels_raw as $ch) {
                                        if (isset($ch['id'], $ch['name'])) {
                                            $all_channel_map[$ch['id']] = $ch['name'];
                                        }
                                    }
                                }
                                if (class_exists('VS_Buffer_Account_Registry')) {
                                    foreach (VS_Buffer_Account_Registry::get_accounts() as $acct_aid => $acct_data) {
                                        $acct_cache_raw = get_option('mcqvs_buffer_account_' . $acct_aid . '_channels_data', '[]');
                                        $acct_cache = is_array($acct_cache_raw) ? $acct_cache_raw : json_decode((string) $acct_cache_raw, true);
                                        if (is_array($acct_cache)) {
                                            foreach ($acct_cache as $ch) {
                                                if (isset($ch['id'], $ch['name'])) {
                                                    $all_channel_map[$ch['id']] = $ch['name'];
                                                }
                                            }
                                        }
                                    }
                                }
                            foreach ($pipeline_jobs as $pj) :
                                $pj_settings = is_string($pj['settings'] ?? '') ? json_decode($pj['settings'], true) : (is_array($pj['settings'] ?? null) ? $pj['settings'] : array());
                                $pj_topic = $pj_settings['topic_name'] ?? $pj['topic_name'] ?? ('Job ' . sanitize_text_field($pj['job_id']));
                                $pj_status = $pj['status'] ?? 'pending';
                                $pj_status_labels = array(
                                    'pending'         => 'Queued',
                                    'ready_for_render'=> 'Ready',
                                    'rendering'       => 'Rendering',
                                    'uploading'       => 'Uploading',
                                    'completed'       => 'Completed',
                                    'failed'          => 'Failed',
                                );
                                $pj_status_colors = array(
                                    'pending'         => '#facc15',
                                    'ready_for_render'=> '#3b82f6',
                                    'rendering'       => '#8b5cf6',
                                    'uploading'       => '#f97316',
                                    'completed'       => '#22c55e',
                                    'failed'          => '#ef4444',
                                );
                                $pj_label = $pj_status_labels[$pj_status] ?? $pj_status;
                                $pj_color = $pj_status_colors[$pj_status] ?? '#94a3b8';
                                $pj_created = !empty($pj['created_at']) ? strtotime($pj['created_at'] . ' UTC') : 0;
                                $pj_publish = !empty($pj['publish_at']) ? strtotime($pj['publish_at'] . ' UTC') : 0;
                                $pj_is_rendering = ($pj_status === 'rendering');

                                // Buffer status
                                $pj_has_video = !empty($pj['video_url']);
                                $pj_published = !empty($pj['published_channels']);
                                $pj_published_channels = !empty($pj['published_channels']) ? json_decode($pj['published_channels'], true) : [];
                                $pj_buffer_post_ids = !empty($pj['buffer_post_ids']) ? json_decode($pj['buffer_post_ids'], true) : [];
                                $pj_settings_buf = is_string($pj['settings'] ?? '') ? json_decode($pj['settings'], true) : (is_array($pj['settings'] ?? null) ? $pj['settings'] : array());
                                $pj_save_mode = is_array($pj_settings_buf) ? ($pj_settings_buf['save_mode'] ?? null) : null;
                                if ($pj_save_mode === null) {
                                    $pj_save_mode = get_option('mcqvs_delivery_mode', 'local');
                                }
                                $pj_is_buffer = ($pj_save_mode === 'r2_buffer');
                                $now_gmt = current_time('mysql', true);

                                // Resolve channel names from IDs (same logic as Recent Videos)
                                // @FIX 2026-08-08: Uses the merged all-account channel map.
                                $pj_channel_names = array();
                                if (!empty($pj_published_channels) && is_array($pj_published_channels)) {
                                    foreach ($pj_published_channels as $cid) {
                                        $pj_channel_names[] = $all_channel_map[$cid] ?? $cid;
                                    }
                                }

                                if ($pj_published && is_array($pj_published_channels) && !empty($pj_published_channels)) {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#dcfce7;color:#16a34a;font-size:10px;">' . esc_html__('Published', 'mcq-video-studio') . ' (' . count($pj_published_channels) . ' ch)</span>';
                                    if (!empty($pj_channel_names)) {
                                        $buffer_status .= '<br><small style="color:#94a3b8;">' . esc_html(implode(', ', array_slice($pj_channel_names, 0, 2))) . (count($pj_channel_names) > 2 ? '...' : '') . '</small>';
                                    }
                                } elseif ($pj_publish > 0 && $pj_publish <= strtotime($now_gmt . ' UTC')) {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#fef3c7;color:#d97706;font-size:10px;">' . esc_html__('Due Now', 'mcq-video-studio') . '</span>';
                                } elseif ($pj_publish > 0) {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#dbeafe;color:#2563eb;font-size:10px;">' . esc_html__('Scheduled', 'mcq-video-studio') . '</span>';
                                    $buffer_status .= '<br><small style="color:#94a3b8;">' . wp_date(get_option('date_format') . ' ' . get_option('time_format'), $pj_publish) . '</small>';
                                } elseif ($pj_is_buffer && $pj_has_video) {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#dbeafe;color:#2563eb;font-size:10px;">' . esc_html__('Ready', 'mcq-video-studio') . '</span>';
                                } elseif ($pj_has_video) {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#f1f5f9;color:#64748b;font-size:10px;">' . esc_html__('Local', 'mcq-video-studio') . '</span>';
                                } else {
                                    $buffer_status = '<span class="mcqvs-delivery-badge" style="background:#f1f5f9;color:#94a3b8;font-size:10px;">' . esc_html__('—', 'mcq-video-studio') . '</span>';
                                }
                            ?>
                                <tr>
                                    <td><strong><?php echo esc_html($pj_topic); ?></strong><br><small style="color:#94a3b8;"><?php echo esc_html($pj['job_id']); ?></small></td>
                                    <td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:<?php echo esc_attr($pj_color); ?>;margin-right:6px;"></span><?php echo esc_html($pj_label); ?></td>
                                    <td>
                                        <?php if ($pj_is_rendering) :
                                            $rc = $render_palette[abs(crc32((string) $pj['job_id'])) % count($render_palette)];
                                        ?>
                                            <div class="mcqvs-render-progress" data-job-id="<?php echo esc_attr($pj['job_id']); ?>" style="min-width:120px;">
                                                <div style="display:flex;align-items:center;gap:8px;">
                                                    <div style="flex:1;height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden;">
                                                        <div class="mcqvs-render-progress-bar" style="width:0%;height:100%;background:linear-gradient(90deg,<?php echo esc_attr($rc[0]); ?>,<?php echo esc_attr($rc[1]); ?>);border-radius:3px;transition:width 0.5s ease;"></div>
                                                    </div>
                                                    <span class="mcqvs-render-progress-pct" style="font-size:11px;font-weight:600;color:<?php echo esc_attr($rc[0]); ?>;min-width:32px;text-align:right;">0%</span>
                                                </div>
                                            </div>
                                        <?php elseif ($pj_status === 'completed') : ?>
                                            <span style="color:#22c55e;font-size:11px;font-weight:600;">100%</span>
                                        <?php else : ?>
                                            <span style="color:#94a3b8;font-size:11px;">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($pj['question_count'] ?? '-'); ?></td>
                                    <td><?php echo $pj_created ? esc_html(human_time_diff($pj_created, time()) . ' ago') : '—'; ?></td>
                                    <td><?php echo $pj_publish ? esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $pj_publish)) : '—'; ?></td>
                                    <td><?php echo $buffer_status; ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- AI Generation Progress (Batch Tracker) -->
            <?php if (!empty($batch_tracker)) :
                $bt_total = count($batch_tracker);
                $bt_completed = count(array_filter($batch_tracker, fn($b) => ($b['status'] ?? '') === 'completed'));
                $bt_failed = count(array_filter($batch_tracker, fn($b) => ($b['status'] ?? '') === 'failed'));
                $bt_rate_limited = count(array_filter($batch_tracker, fn($b) => ($b['status'] ?? '') === 'rate_limited'));
                $bt_pending = count(array_filter($batch_tracker, fn($b) => ($b['status'] ?? '') === 'pending'));
            ?>
            <div class="mcqvs-section">
                <div class="mcqvs-section-title"><span>&#129302;</span> <?php esc_html_e('AI Generation Progress', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-card">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                        <strong><?php printf(esc_html__('%d / %d batches done', 'mcq-video-studio'), $bt_completed, $bt_total); ?></strong>
                        <span class="mcqvs-info-value" style="color:#dc2626;"><?php echo $bt_failed; ?> failed</span>
                    </div>
                    <div style="height:10px;background:#eee;border-radius:5px;overflow:hidden;margin-bottom:10px;">
                        <div style="width:<?php echo $bt_total ? esc_attr(($bt_completed / $bt_total) * 100) : 0; ?>%;height:100%;background:linear-gradient(90deg,#22c55e,#16a34a);transition:width 0.3s;"></div>
                    </div>
                    <?php if ($bt_rate_limited > 0) : ?>
                        <div style="font-size:11px;color:#ffa000;margin-bottom:8px;">&#9888; <?php printf(esc_html__('%d batch(es) waiting for AI quota - auto-retry scheduled', 'mcq-video-studio'), $bt_rate_limited); ?></div>
                    <?php endif; ?>
                    <details style="font-size:12px;">
                        <summary style="cursor:pointer;font-weight:600;"><?php esc_html_e('View Batch Details', 'mcq-video-studio'); ?></summary>
                        <table class="mcqvs-table" style="margin-top:8px;">
                            <thead><tr><th>#</th><th>Topics</th><th>Status</th><th>Time</th></tr></thead>
                            <tbody>
                            <?php foreach ($batch_tracker as $bt_idx => $bt_row) :
                                $bt_status_label = $bt_row['status'] ?? 'unknown';
                                $bt_status_color = array(
                                    'completed' => '#22c55e', 'failed' => '#ef4444', 'rate_limited' => '#ffa000', 'pending' => '#94a3b8',
                                )[$bt_status_label] ?? '#94a3b8';
                            ?>
                                <tr>
                                    <td><?php echo esc_html($bt_idx); ?></td>
                                    <td><?php echo esc_html($bt_row['topics'] ?? '-'); ?></td>
                                    <td><span style="color:<?php echo esc_attr($bt_status_color); ?>;font-weight:600;"><?php echo esc_html($bt_status_label); ?></span><?php if (!empty($bt_row['error'])): ?><br><small style="color:#94a3b8;"><?php echo esc_html(substr($bt_row['error'], 0, 60)); ?></small><?php endif; ?></td>
                                    <td><?php echo !empty($bt_row['time']) ? esc_html(human_time_diff(strtotime($bt_row['time'] . ' UTC'), time()) . ' ago') : '—'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </details>
                </div>
            </div>
            <?php endif; ?>

            <!-- Batches + Errors -->
            <div class="mcqvs-section">
                <div class="mcqvs-dash-grid">
                    <div class="mcqvs-card">
                        <div class="mcqvs-card-title">&#128196; <?php esc_html_e('Recent Batches', 'mcq-video-studio'); ?></div>
                        <?php if (empty($recent_batches)) : ?>
                            <div class="mcqvs-empty"><?php esc_html_e('No recent batches found.', 'mcq-video-studio'); ?></div>
                        <?php else : ?>
                            <ul class="mcqvs-timeline">
                                <?php foreach ($recent_batches as $batch) :
                                    $cls = $batch['status'] === 'completed' ? 'done' : ($batch['status'] === 'failed' ? 'err' : 'running');
                                ?>
                                    <li class="<?php echo esc_attr($cls); ?>">
                                        <div class="mcqvs-batch-topic"><?php echo esc_html($batch['topic']); ?></div>
                                        <div class="mcqvs-batch-meta">
                                            <?php printf(
                                                esc_html__('%s Qs &bull; %s videos &bull; %s', 'mcq-video-studio'),
                                                $batch['total_questions'],
                                                isset($batch['job_ids']) ? count($batch['job_ids']) : 0,
                                                human_time_diff(strtotime($batch['created_at'] . ' UTC'), time()) . ' ago'
                                            ); ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="mcqvs-card">
                        <div class="mcqvs-card-title" style="color:#dc2626">&#9888; <?php esc_html_e('Recent Errors', 'mcq-video-studio'); ?></div>
                        <div class="mcqvs-error-list">
                            <?php if (empty($recent_errors)) : ?>
                                <div class="mcqvs-empty"><?php esc_html_e('No recent errors.', 'mcq-video-studio'); ?></div>
                            <?php else : ?>
                                <?php foreach ($recent_errors as $err) : ?>
                                    <div class="mcqvs-error-item">
                                        <span class="mcqvs-error-time"><?php echo esc_html($err['ts']); ?></span>
                                        <div class="mcqvs-error-msg"><?php echo esc_html($err['message']); ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render settings page (configuration tabs only).
     *
     * @since 1.0.0
     */
    public function render_settings_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        // Determine active tab — default to 'api' (first config tab)
        $active_tab = 'api';

        if (isset($_GET['tab'])) {
            $active_tab = sanitize_text_field(wp_unslash($_GET['tab']));
        }
?>
        <div class="wrap mcqvs-settings-wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <nav class="nav-tab-wrapper">
                <a href="?page=mcqvs-settings&tab=api" class="nav-tab <?php echo 'api' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('API Settings', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=schedule" class="nav-tab <?php echo 'schedule' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Schedule', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=buffer" class="nav-tab <?php echo 'buffer' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Buffer', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=r2" class="nav-tab <?php echo 'r2' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Cloudflare R2', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=migration" class="nav-tab <?php echo 'migration' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Data Migration', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=health" class="nav-tab <?php echo 'health' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('System Health', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=headless" class="nav-tab <?php echo 'headless' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Headless Rendering', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=assets" class="nav-tab <?php echo 'assets' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Assets', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=logs" class="nav-tab <?php echo 'logs' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Logs', 'mcq-video-studio'); ?>
                </a>
                <a href="?page=mcqvs-settings&tab=data" class="nav-tab <?php echo 'data' === $active_tab ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Data', 'mcq-video-studio'); ?>
                </a>
            </nav>

            <!-- @FIX F-DATA-LOSS: Surgical global hidden emitter so OPTIONS.php never wipes
                 fields belonging to inactive tabs. Each render_*_tab() must call this with the
                 array of keys IT natively renders; everything else is re-emitted here as a
                 hidden scalar so WP Settings API does not silently write defaults. -->
            <form method="post" action="options.php">
                <?php settings_fields(self::OPTION_GROUP); ?>
                <?php $this->render_global_hidden_settings_except($this->keys_native_to_tab($active_tab)); ?>

                <?php if ('buffer' === $active_tab) : ?>
                    <?php $this->render_buffer_tab(); ?>
                <?php elseif ('r2' === $active_tab) : ?>
                    <?php $this->render_r2_tab(); ?>
                <?php elseif ('schedule' === $active_tab || 'automation' === $active_tab) : ?>
                    <?php $this->render_automation_tab(); ?>
                <?php elseif ('api' === $active_tab) : ?>
                    <?php $this->render_api_tab(); ?>
                <?php elseif ('migration' === $active_tab) : ?>
                    <?php $this->render_migration_tab(); ?>
                <?php elseif ('health' === $active_tab) : ?>
                    <?php
                    if (class_exists('VS_Core')) {
                        VS_Core::init()->render_system_health_page(true);
                    }
                    ?>
                <?php elseif ('headless' === $active_tab) : ?>
                    <?php $this->render_headless_tab(); ?>
                <?php elseif ('assets' === $active_tab) : ?>
                    <?php $this->render_assets_tab(); ?>
                <?php elseif ('logs' === $active_tab) : ?>
                    <?php $this->render_logs_tab(); ?>
                <?php elseif ('data' === $active_tab) : ?>
                    <?php $this->render_data_tab(); ?>
                <?php endif; ?>

                <?php submit_button(); ?>
            </form>
        </div>
    <?php
    }

    /**
     * Render Buffer tab.
     *
     * @since 1.0.0
     */
    private function render_buffer_tab()
    {
        $auto_publish = get_option('mcqvs_auto_publish_enabled', false);
        $default_publish_time = get_option('mcqvs_default_publish_time', '09:00');
        $publish_frequency = get_option('mcqvs_publish_frequency', 'daily');
        $publish_timezone = get_option('mcqvs_publish_timezone', '');

        // @NEW 2026-08-07: Per-account card layout. Each Buffer account owns its
        // own token, channels, scheduling mode, daily limit, and caption template.
        // Ensure a legacy single-account install shows as a "default" card.
        VS_Buffer_Account_Registry::ensure_legacy_migrated();
        $buffer_accounts = VS_Buffer_Account_Registry::get_accounts();
        if (!is_array($buffer_accounts)) {
            $buffer_accounts = array();
        }
        $valid_types = VS_Buffer_Client::get_valid_post_types();
        ?>
        <style>
            .mcqvs-buffer-account-card{background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px 20px;margin:0 0 20px;box-shadow:0 1px 2px rgba(0,0,0,.05);overflow:hidden;box-sizing:border-box;}
            .mcqvs-account-card-head{display:flex;flex-wrap:wrap;align-items:center;gap:10px;border-bottom:1px solid #eee;padding-bottom:12px;margin-bottom:14px;}
            .mcqvs-account-card-head .mcqvs-account-label{flex:1;min-width:180px;}
            .mcqvs-default-badge{background:#2271b1;color:#fff;border-radius:3px;padding:2px 8px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;}
            .mcqvs-enabled-label{display:inline-flex;align-items:center;gap:4px;}
            .mcqvs-default-radio{display:inline-flex;align-items:center;gap:4px;color:#666;}
            .mcqvs-buffer-account-card .form-table{width:100%;border-collapse:collapse;}
            .mcqvs-buffer-account-card .form-table th,.mcqvs-buffer-account-card .form-table td{padding:10px 10px 10px 0;vertical-align:top;}
            .mcqvs-buffer-account-card .form-table th{width:160px;font-weight:600;}
            .mcqvs-buffer-account-card .form-table td{width:100%;}
            .mcqvs-account-channels td,.mcqvs-account-channels th{vertical-align:middle;}
            .mcqvs-service-badge{background:#3b82f6;color:#fff;padding:2px 8px;border-radius:3px;font-size:11px;display:inline-block;}
            .mcqvs-add-account-card{border-style:dashed;background:#f8f9fb;}
            .mcqvs-account-channels-wrap{width:100%;max-width:100%;overflow-x:auto;}
            .mcqvs-account-channels{width:100%;max-width:100%;table-layout:fixed;}
            .mcqvs-account-channels th,
            .mcqvs-account-channels td{word-wrap:break-word;overflow-wrap:break-word;box-sizing:border-box;}
            .mcqvs-ch-story-label{display:inline-flex;align-items:center;gap:4px;cursor:pointer;}
            .mcqvs-ch-story-label input[type=checkbox]{margin:0;}
            .mcqvs-ch-caption-toggle{font-size:14px;line-height:1;padding:2px 7px;}
            .mcqvs-ch-caption-toggle.mcqvs-ch-caption-active{background:#dbeafe;border-color:#2563eb;color:#1e3a8a;}
            .mcqvs-ch-detail-grid{display:grid;grid-template-columns:1fr;gap:14px;}
            .mcqvs-channel-detail-row > td{padding:0 !important;}
            .mcqvs-channel-detail-row .mcqvs-ch-detail-grid{padding:14px 18px;background:#fafbfc;}
            .mcqvs-ch-caption{width:100%;max-width:100%;box-sizing:border-box;font-family:inherit;}
            .mcqvs-ch-caption-label{display:block;font-weight:600;color:#1e293b;margin-bottom:4px;font-size:12px;}
            .mcqvs-account-channels td:nth-child(2) .mcqvs-ch-name{max-width:220px;display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle;}
            .mcqvs-account-channels td:nth-child(2) small{display:block;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
            .mcqvs-buffer-account-card .large-text{width:100%;max-width:100%;box-sizing:border-box;}
        </style>

        <div class="mcqvs-buffer-layout">
            <h2><?php esc_html_e('Buffer Accounts', 'mcq-video-studio'); ?></h2>
            <p class="description" style="margin-top:0;">
                <?php esc_html_e('Each account below is self-contained: its own access token, connection test, channels, scheduling mode, daily limit, and caption template. Changes inside a card are saved with its "Save Account" button. The "Default" account is used when no specific account is chosen.', 'mcq-video-studio'); ?>
            </p>

            <div id="mcqvs-buffer-accounts-wrap">
                <?php foreach ($buffer_accounts as $acct_id => $acct) : ?>
                    <?php $this->render_buffer_account_card($acct_id, $acct, $valid_types); ?>
                <?php endforeach; ?>

                <div class="mcqvs-buffer-account-card mcqvs-add-account-card" id="mcqvs-buffer-add-account-form">
                    <div class="mcqvs-account-card-head">
                        <h4 style="margin:0;"><?php esc_html_e('Add New Buffer Account', 'mcq-video-studio'); ?></h4>
                        <button type="button" id="mcqvs-toggle-add-account" class="button button-secondary"><?php esc_html_e('Show Form', 'mcq-video-studio'); ?></button>
                    </div>
                    <div class="mcqvs-add-account-body" style="display:none;">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="mcqvs-new-account-label"><?php esc_html_e('Label', 'mcq-video-studio'); ?></label></th>
                            <td><input type="text" id="mcqvs-new-account-label" name="label" class="regular-text" placeholder="<?php esc_attr_e('e.g. Brand A — Facebook + IG', 'mcq-video-studio'); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="mcqvs-new-account-token"><?php esc_html_e('Access Token', 'mcq-video-studio'); ?></label></th>
                            <td><input type="password" id="mcqvs-new-account-token" name="token" class="regular-text" placeholder="<?php esc_attr_e('Paste Buffer API token here', 'mcq-video-studio'); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Enabled', 'mcq-video-studio'); ?></th>
                            <td><label><input type="checkbox" id="mcqvs-new-account-enabled" name="enabled" value="1" checked="checked" /> <?php esc_html_e('Active', 'mcq-video-studio'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Daily Limit', 'mcq-video-studio'); ?></th>
                            <td><input type="number" id="mcqvs-new-account-daily-limit" name="daily_limit" class="small-text" value="0" min="0" max="100" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Scheduling Mode', 'mcq-video-studio'); ?></th>
                            <td>
                                <select id="mcqvs-new-account-scheduling-mode" name="scheduling_mode">
                                    <option value="addToQueue"><?php esc_html_e('Add to Queue', 'mcq-video-studio'); ?></option>
                                    <option value="customScheduled"><?php esc_html_e('Custom Scheduled', 'mcq-video-studio'); ?></option>
                                    <option value="shareNow"><?php esc_html_e('Share Now', 'mcq-video-studio'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Caption Template', 'mcq-video-studio'); ?></th>
                            <td><textarea id="mcqvs-new-account-caption-template" name="caption_template" class="large-text" rows="3" placeholder="<?php esc_attr_e('Optional — uses global default if empty', 'mcq-video-studio'); ?>"></textarea></td>
                        </tr>
                        <tr>
                            <th scope="row"></th>
                            <td><button type="button" id="mcqvs-add-buffer-account" class="button button-primary"><?php esc_html_e('Add Account', 'mcq-video-studio'); ?></button></td>
                        </tr>
                    </table>
                    </div>
                </div>
            </div>
            <div id="mcqvs-buffer-accounts-loading" style="display:none;color:#666;padding:10px 0;">
                <?php esc_html_e('Saving account...', 'mcq-video-studio'); ?>
            </div>
            <div id="mcqvs-buffer-channels-loading" style="display:none;color:#666;padding:10px 0;">
                <?php esc_html_e('Loading channels from Buffer...', 'mcq-video-studio'); ?>
            </div>

            <hr style="margin:28px 0 20px;" />

            <h2><?php esc_html_e('Defaults & Scheduling', 'mcq-video-studio'); ?></h2>
            <p class="description" style="margin-top:0;">
                <?php esc_html_e('These defaults apply to all accounts unless overridden inside an account card, and to Content Planner scheduling.', 'mcq-video-studio'); ?>
            </p>
            <table class="form-table">
        <tr>
            <th scope="row"><?php esc_html_e('Auto-Publish After Upload', 'mcq-video-studio'); ?></th>
            <td>
                <label>
                    <input type="checkbox" name="mcqvs_auto_publish_enabled" value="1" <?php checked($auto_publish === true || $auto_publish === 1 || $auto_publish === '1'); ?> />
                    <?php esc_html_e('Automatically publish videos to Buffer after R2 upload completes', 'mcq-video-studio'); ?>
                </label>
                <p class="description">
                    <?php esc_html_e('When enabled (and delivery mode = R2 + Buffer), completed videos are automatically pushed to Buffer. A cron job checks every 15 minutes.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_default_publish_time"><?php esc_html_e('Default Publish Time', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="time" name="mcqvs_default_publish_time" id="mcqvs_default_publish_time"
                    value="<?php echo esc_attr($default_publish_time); ?>" class="small-text"
                    style="width:150px;min-width:150px;font-size:14px;padding:4px 8px;" />
                <p class="description">
                    <?php esc_html_e('Default time of day to publish videos (used by Content Planner when no specific time is set).', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label><?php esc_html_e('Publish Time Window', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <?php
                $window_start = get_option('mcqvs_publish_time_window_start', '18:00');
                $window_end   = get_option('mcqvs_publish_time_window_end', '21:00');
                ?>
                <input type="time" name="mcqvs_publish_time_window_start" id="mcqvs_publish_time_window_start"
                    value="<?php echo esc_attr($window_start); ?>" class="small-text"
                    style="width:150px;min-width:150px;font-size:14px;padding:4px 8px;" />
                <span style="margin:0 6px;color:#64748b;">&rarr;</span>
                <input type="time" name="mcqvs_publish_time_window_end" id="mcqvs_publish_time_window_end"
                    value="<?php echo esc_attr($window_end); ?>" class="small-text"
                    style="width:150px;min-width:150px;font-size:14px;padding:4px 8px;" />
                <p class="description">
                    <?php esc_html_e('When a CSV row omits publish_time, the plugin slots that video at a random time inside this start..end window. N-per-day (from Publish Frequency) evenly fills the bracket.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_publish_timezone"><?php esc_html_e('Publish Timezone', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <select name="mcqvs_publish_timezone" id="mcqvs_publish_timezone">
                    <?php
                    $tz_options = array('UTC', 'US/Eastern', 'US/Central', 'US/Pacific', 'Europe/London', 'Europe/Berlin', 'Asia/Kolkata', 'Asia/Karachi', 'Asia/Dubai', 'Asia/Tokyo', 'Australia/Sydney');
                    foreach ($tz_options as $tz) :
                    ?>
                    <option value="<?php echo esc_attr($tz); ?>" <?php selected($publish_timezone, $tz); ?>><?php echo esc_html($tz); ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="description">
                    <?php esc_html_e('Timezone used for Buffer publish scheduling. Select the timezone where your audience is located. Publish times are converted to UTC for the Buffer API.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_publish_frequency"><?php esc_html_e('Default Publish Frequency', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <select name="mcqvs_publish_frequency" id="mcqvs_publish_frequency">
                    <option value="daily" <?php selected($publish_frequency, 'daily'); ?>><?php esc_html_e('1 video per day', 'mcq-video-studio'); ?></option>
                    <option value="twice_daily" <?php selected($publish_frequency, 'twice_daily'); ?>><?php esc_html_e('2 videos per day', 'mcq-video-studio'); ?></option>
                    <option value="every_3_days" <?php selected($publish_frequency, 'every_3_days'); ?>><?php esc_html_e('1 video every 3 days', 'mcq-video-studio'); ?></option>
                    <option value="weekly" <?php selected($publish_frequency, 'weekly'); ?>><?php esc_html_e('1 video per week', 'mcq-video-studio'); ?></option>
                    <option value="asap" <?php selected($publish_frequency, 'asap'); ?>><?php esc_html_e('All ASAP (no spacing)', 'mcq-video-studio'); ?></option>
                </select>
                <p class="description">
                    <?php esc_html_e('Default publish cadence for Content Planner videos. Used when no per-plan frequency is set.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Show Answer Explanations', 'mcq-video-studio'); ?></th>
            <td>
                <label for="mcqvs_show_explanation">
                    <input type="hidden" name="mcqvs_show_explanation" value="0" />
                    <input type="checkbox" name="mcqvs_show_explanation" id="mcqvs_show_explanation" value="1" <?php checked(get_option('mcqvs_show_explanation', false)); ?> />
                    <?php esc_html_e('Show the one-line 💡 explanation bar after each answer reveals', 'mcq-video-studio'); ?>
                </label>
                <p class="description">
                    <?php esc_html_e('Default OFF for ultra-minimal Shorts. When ON, videos show a short learning bar ("💡 ...") in the reveal phase using the AI/CSV explanation field. It is visual only — never spoken — so video length is unaffected either way.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Strip Emoji from On-Screen Text', 'mcq-video-studio'); ?></th>
            <td>
                <label for="mcqvs_strip_emoji_on_screen">
                    <input type="hidden" name="mcqvs_strip_emoji_on_screen" value="0" />
                    <input type="checkbox" name="mcqvs_strip_emoji_on_screen" id="mcqvs_strip_emoji_on_screen" value="1" <?php checked(get_option('mcqvs_strip_emoji_on_screen', true)); ?> />
                    <?php esc_html_e('Remove emoji from the hook text rendered inside the video (server-rendered)', 'mcq-video-studio'); ?>
                </label>
                <p class="description">
                    <?php esc_html_e('Recommended ON. The server-side canvas cannot reliably draw color emoji or flags (they appear as monochrome glyphs or empty boxes on minimal servers). Captions and YouTube titles keep the emoji — only the pixels inside the video are cleaned. If you install a color emoji font (e.g. fonts-noto-color-emoji) on your render VPS, you can turn this off.', 'mcq-video-studio'); ?>
                </p>
            </td>
        </tr>
            </table>
        </div>
        <?php
    }

    /**
     * Render a single Buffer account as a self-contained card.
     *
     * @param string $acct_id Account key.
     * @param array  $acct    Account data.
     * @param array  $valid_types Per-service valid post types.
     */
    private function render_buffer_account_card($acct_id, $acct, $valid_types)
    {
        $is_default = !empty($acct['is_default']);
        $enabled = !empty($acct['enabled']);
        $label = $acct['label'] ?? $acct_id;
        $token = $acct['token'] ?? '';
        $daily_lim = isset($acct['daily_limit']) ? (int) $acct['daily_limit'] : 0;
        $sched_mode = $acct['scheduling_mode'] ?? 'addToQueue';
        $cap_tpl = isset($acct['caption_template']) ? $acct['caption_template'] : '';
        $yt_title = isset($acct['youtube_title']) ? $acct['youtube_title'] : '';
        $yt_category = isset($acct['youtube_category']) ? $acct['youtube_category'] : '27';

        $acct_channels = VS_Buffer_Account_Registry::get_channels($acct_id);
        $acct_types    = VS_Buffer_Account_Registry::get_channel_types($acct_id);
        $acct_links    = VS_Buffer_Account_Registry::get_link_posts($acct_id);
        // @NEW 2026-08-10: Per-channel state maps. Same getters the registry
        // exposes to the push pipeline so the UI is rendered from the same
        // source of truth the Buffer push will read at runtime.
        $acct_channel_captions = VS_Buffer_Account_Registry::get_channel_captions($acct_id);
        $acct_channel_story    = VS_Buffer_Account_Registry::get_channel_post_to_story($acct_id);
        if (!is_array($acct_channels)) { $acct_channels = array(); }
        if (!is_array($acct_types)) { $acct_types = array(); }
        if (!is_array($acct_links)) { $acct_links = array(); }
        if (!is_array($acct_channel_captions)) { $acct_channel_captions = array(); }
        if (!is_array($acct_channel_story))    { $acct_channel_story = array(); }

        // Cached channel list for this account; default account falls back to the
        // legacy global cache so a pre-migration install still renders channels.
        $channels_raw = get_option('mcqvs_buffer_account_' . $acct_id . '_channels_data', '[]');
        $channels = is_array($channels_raw) ? $channels_raw : json_decode((string) $channels_raw, true);
        if ((!is_array($channels) || empty($channels)) && $is_default) {
            $channels_raw = get_option('mcqvs_buffer_channels_data', '[]');
            $channels = is_array($channels_raw) ? $channels_raw : json_decode((string) $channels_raw, true);
        }
        if (!is_array($channels)) { $channels = array(); }

        // @NEW 2026-08-10: Detect whether this account owns at least one channel
        // that requires a per-channel UI. We only render the per-channel
        // controls (caption editor, story tick, YouTube overrides) on rows
        // that actually exist; absent services hide their controls entirely.
        //
        // @FIX 2026-08-10: Stories on Buffer are Facebook + Instagram only.
        // Threads does NOT support stories — removed from the story list so
        // the per-channel "Story" tick doesn't appear on Threads channels
        // (and so has_story_channel doesn't get falsely flagged).
        $has_youtube_channel = false;
        $has_story_channel   = false; // facebook + instagram
        foreach ($channels as $ch_probe) {
            $svc = isset($ch_probe['service']) ? (string) $ch_probe['service'] : '';
            if ($svc === 'youtube') {
                $has_youtube_channel = true;
            }
            if (in_array($svc, array('facebook', 'instagram'), true)) {
                $has_story_channel = true;
            }
        }
        ?>
        <div class="mcqvs-buffer-account-card" data-account-id="<?php echo esc_attr($acct_id); ?>">
            <div class="mcqvs-account-card-head">
                <input type="text" class="mcqvs-account-label regular-text" value="<?php echo esc_attr($label); ?>" placeholder="<?php esc_attr_e('Account label', 'mcq-video-studio'); ?>" />
                <?php if ($is_default) : ?>
                    <span class="mcqvs-default-badge"><?php esc_html_e('Default', 'mcq-video-studio'); ?></span>
                <?php else : ?>
                    <label class="mcqvs-default-radio" title="<?php esc_attr_e('Set as default account', 'mcq-video-studio'); ?>">
                        <input type="radio" name="mcqvs_set_default_radio" class="mcqvs-set-default-account" value="<?php echo esc_attr($acct_id); ?>" />
                        <?php esc_html_e('Set as default', 'mcq-video-studio'); ?>
                    </label>
                <?php endif; ?>
                <label class="mcqvs-enabled-label">
                    <input type="checkbox" class="mcqvs-account-toggle" value="1" <?php checked($enabled); ?> />
                    <?php esc_html_e('Enabled', 'mcq-video-studio'); ?>
                </label>
                <?php if (!$is_default) : ?>
                    <button type="button" class="button button-small mcqvs-delete-account" data-account-id="<?php echo esc_attr($acct_id); ?>" style="color:#dc3232;">
                        <?php esc_html_e('Delete', 'mcq-video-studio'); ?>
                    </button>
                <?php endif; ?>
                <button type="button" class="button button-primary mcqvs-save-account" data-account-id="<?php echo esc_attr($acct_id); ?>">
                    <?php esc_html_e('Save Account', 'mcq-video-studio'); ?>
                </button>
            </div>
            <table class="form-table">
                <tr>
                    <th scope="row"><label><?php esc_html_e('Access Token', 'mcq-video-studio'); ?></label></th>
                    <td>
                        <input type="password" class="mcqvs-account-token regular-text" value="" autocomplete="new-password" placeholder="<?php esc_attr_e('Leave blank to keep the stored token', 'mcq-video-studio'); ?>" />
                        <?php if ($token !== '') : ?>
                            <p class="description"><?php esc_html_e('A token is stored for this account. Only enter a new one to replace it.', 'mcq-video-studio'); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Connection', 'mcq-video-studio'); ?></th>
                    <td>
                        <button type="button" class="button button-secondary mcqvs-test-buffer" data-account-id="<?php echo esc_attr($acct_id); ?>">
                            <?php esc_html_e('Test Connection', 'mcq-video-studio'); ?>
                        </button>
                        <button type="button" class="button button-secondary mcqvs-refresh-buffer-channels" data-account-id="<?php echo esc_attr($acct_id); ?>" style="margin-left:8px;">
                            <?php esc_html_e('Refresh Channels', 'mcq-video-studio'); ?>
                        </button>
                        <span class="mcqvs-status mcqvs-buffer-account-status"></span>
                    </td>
                </tr>
                <tr class="mcqvs-channels-row">
                    <td colspan="2">
                        <label style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e('Channels', 'mcq-video-studio'); ?></label>
                        <div class="mcqvs-account-channels-wrap">
                            <?php if (empty($channels)) : ?>
                                <p class="mcqvs-no-channels-msg" style="color:#999;">
                                    <?php esc_html_e('No channels loaded. Click "Refresh Channels" to fetch this account\'s connected social channels.', 'mcq-video-studio'); ?>
                                </p>
                            <?php else : ?>
                                <table class="widefat fixed striped mcqvs-account-channels">
                                    <thead>
                                        <tr>
                                            <th style="width:50px;"><?php esc_html_e('Enable', 'mcq-video-studio'); ?></th>
                                            <th><?php esc_html_e('Channel', 'mcq-video-studio'); ?></th>
                                            <th style="width:110px;"><?php esc_html_e('Service', 'mcq-video-studio'); ?></th>
                                            <th style="width:130px;"><?php esc_html_e('Post Type', 'mcq-video-studio'); ?></th>
                                            <th style="width:90px;"><?php esc_html_e('Story', 'mcq-video-studio'); ?></th>
                                            <th style="width:100px;"><?php esc_html_e('Link Post', 'mcq-video-studio'); ?></th>
                                            <th style="width:60px;"><?php esc_html_e('Caption', 'mcq-video-studio'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="mcqvs-account-channels-body">
                                    <?php foreach ($channels as $ch) :
                                        $ch_id = esc_attr($ch['id']);
                                        $ch_id_raw = $ch['id'];
                                        $checked = in_array($ch['id'], $acct_channels, true);
                                        $service = $ch['service'] ?? 'unknown';
                                        $types = $valid_types[$service] ?? array('post');
                                        $current_type = $acct_types[$ch['id']] ?? 'post';
                                        $is_link = !empty($acct_links[$ch['id']]);
                                        $show_link = in_array($service, array('facebook', 'linkedin'), true);
                                        // @NEW 2026-08-10: Per-channel state for this row.
                                        //
                                        // @FIX 2026-08-10: Threads does NOT support stories
                                        // on Buffer — only Facebook + Instagram show the
                                        // "Story" tick. Other services show `—`.
                                        $ch_story_on   = !empty($acct_channel_story[$ch_id_raw]);
                                        $show_story    = in_array($service, array('facebook', 'instagram'), true);
                                        $ch_caption    = isset($acct_channel_captions[$ch_id_raw]) ? (string) $acct_channel_captions[$ch_id_raw] : '';
                                        $has_caption   = ($ch_caption !== '');
                                        // Service char limit hint for the caption editor.
                                        $svc_limit = VS_Buffer_Client::get_service_char_limit($service);
                                    ?>
                                        <tr class="mcqvs-channel-row" data-channel-id="<?php echo $ch_id; ?>" data-service="<?php echo esc_attr($service); ?>" data-char-limit="<?php echo esc_attr((string) $svc_limit); ?>">
                                            <td><input type="checkbox" class="mcqvs-ch-enable" value="<?php echo $ch_id; ?>" <?php checked($checked); ?> /></td>
                                            <td>
                                                <strong class="mcqvs-ch-name" title="<?php echo esc_attr($ch['displayName'] ?? $ch['name'] ?? $ch['id']); ?>"><?php echo esc_html($ch['displayName'] ?? $ch['name'] ?? $ch['id']); ?></strong>
                                                <small style="color:#888;" title="<?php echo esc_attr($ch['id']); ?>"><?php echo esc_html($ch['id']); ?></small>
                                            </td>
                                            <td><span class="mcqvs-service-badge"><?php echo esc_html(ucfirst($service)); ?></span></td>
                                            <td>
                                                <select class="mcqvs-ch-type">
                                                <?php foreach ($types as $t) : ?>
                                                    <option value="<?php echo esc_attr($t); ?>" <?php selected($current_type, $t); ?>><?php echo esc_html(ucfirst($t)); ?></option>
                                                <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td>
                                                <?php if ($show_story) : ?>
                                                    <label class="mcqvs-ch-story-label" title="<?php esc_attr_e('Force post_type=story for this channel', 'mcq-video-studio'); ?>">
                                                        <input type="checkbox" class="mcqvs-ch-story" value="1" <?php checked($ch_story_on); ?> />
                                                        <span class="mcqvs-ch-story-text"><?php esc_html_e('Story', 'mcq-video-studio'); ?></span>
                                                    </label>
                                                <?php else : ?>
                                                    <span style="color:#aaa;">&mdash;</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($show_link) : ?>
                                                    <input type="checkbox" class="mcqvs-ch-link" value="1" <?php checked($is_link); ?> />
                                                <?php else : ?>
                                                    <span style="color:#aaa;">&mdash;</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button type="button" class="button button-small mcqvs-ch-caption-toggle<?php echo $has_caption ? ' mcqvs-ch-caption-active' : ''; ?>"
                                                        data-channel-id="<?php echo $ch_id; ?>"
                                                        title="<?php esc_attr_e('Edit per-channel caption template', 'mcq-video-studio'); ?>"
                                                        aria-label="<?php esc_attr_e('Edit caption', 'mcq-video-studio'); ?>">
                                                    &#9998;
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="mcqvs-channel-detail-row" data-channel-id="<?php echo $ch_id; ?>" style="display:<?php echo $has_caption ? 'table-row' : 'none'; ?>;">
                                            <td colspan="7">
                                                <div class="mcqvs-ch-detail-grid">
                                                    <div>
                                                        <label class="mcqvs-ch-caption-label">
                                                            <?php esc_html_e('Caption template (this channel)', 'mcq-video-studio'); ?>
                                                            <?php if ($svc_limit > 0) : ?>
                                                                <span class="mcqvs-ch-caption-limit" style="color:#64748b;font-weight:400;font-size:11px;">
                                                                    <?php
                                                                    /* translators: %d = Buffer service character limit. */
                                                                    echo esc_html(sprintf(__('— truncated to %d chars at push time', 'mcq-video-studio'), $svc_limit));
                                                                    ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </label>
                                                        <textarea class="mcqvs-ch-caption large-text" rows="3"
                                                                  data-channel-id="<?php echo $ch_id; ?>"
                                                                  placeholder="<?php echo esc_attr($cap_tpl !== '' ? $cap_tpl : "{hook}\n\n{topic}\nCan you score {score}/{total}?\n\n{hashtags}"); ?>"><?php echo esc_textarea($ch_caption); ?></textarea>
                                                        <p class="description">
                                                            <?php esc_html_e('Placeholders: {topic}, {score}, {total}, {hook}, {hashtags}, {firstquestion}, {link}, {part}, {part_total}. Empty = use this account\'s global caption template.', 'mcq-video-studio'); ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Scheduling Mode', 'mcq-video-studio'); ?></th>
                    <td>
                        <select class="mcqvs-account-scheduling-mode">
                            <option value="addToQueue" <?php selected($sched_mode, 'addToQueue'); ?>><?php esc_html_e('Add to Queue', 'mcq-video-studio'); ?></option>
                            <option value="customScheduled" <?php selected($sched_mode, 'customScheduled'); ?>><?php esc_html_e('Custom Scheduled', 'mcq-video-studio'); ?></option>
                            <option value="shareNow" <?php selected($sched_mode, 'shareNow'); ?>><?php esc_html_e('Share Now', 'mcq-video-studio'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><?php esc_html_e('Daily Limit', 'mcq-video-studio'); ?></label></th>
                    <td>
                        <input type="number" class="mcqvs-account-daily-limit small-text" value="<?php echo esc_attr($daily_lim); ?>" min="0" max="100" />
                        <span class="description"><?php esc_html_e('Maximum posts per day (0 = unlimited).', 'mcq-video-studio'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><?php esc_html_e('Caption Template', 'mcq-video-studio'); ?></label></th>
                    <td>
                        <textarea class="mcqvs-account-caption-template large-text" rows="3"><?php echo esc_textarea($cap_tpl); ?></textarea>
                        <p class="description">
                            <?php esc_html_e('Placeholders: {topic}, {score}, {total}, {hook}, {hashtags}, {firstquestion}, {link}, {part}, {part_total}. Empty = use the global default.', 'mcq-video-studio'); ?>
                        </p>
                    </td>
                </tr>
                <?php if ($has_youtube_channel) : ?>
                <tr>
                    <th scope="row"><label><?php esc_html_e('YouTube Title', 'mcq-video-studio'); ?></label></th>
                    <td>
                        <input type="text" class="mcqvs-account-youtube-title regular-text" value="<?php echo esc_attr($yt_title); ?>" placeholder="<?php esc_attr_e('{topic} - Quiz', 'mcq-video-studio'); ?>" />
                        <p class="description">
                            <?php esc_html_e('Used as the YouTube video title. Placeholders: {topic}, {score}, {total}, {hook}, {hashtags}, {part}, {part_total}. Empty = "{topic} - Quiz".', 'mcq-video-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><?php esc_html_e('YouTube Category', 'mcq-video-studio'); ?></label></th>
                    <td>
                        <select class="mcqvs-account-youtube-category">
                            <?php
                            $yt_categories = array(
                                '1'  => 'Film & Animation',
                                '2'  => 'Autos & Vehicles',
                                '10' => 'Music',
                                '15' => 'Pets & Animals',
                                '17' => 'Sports',
                                '19' => 'Travel & Events',
                                '20' => 'Gaming',
                                '22' => 'People & Blogs',
                                '23' => 'Comedy',
                                '24' => 'Entertainment',
                                '25' => 'News & Politics',
                                '26' => 'Howto & Style',
                                '27' => 'Education',
                                '28' => 'Science & Technology',
                                '29' => 'Nonprofits & Activism',
                            );
                            foreach ($yt_categories as $yt_cid => $yt_cname) :
                            ?>
                                <option value="<?php echo esc_attr($yt_cid); ?>" <?php selected($yt_category, $yt_cid); ?>><?php echo esc_html($yt_cname); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="description"><?php esc_html_e('YouTube requires a category when publishing videos.', 'mcq-video-studio'); ?></span>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        <?php
    }

    /**
     * Render R2 tab.
     *
     * @since 1.0.0
     */
    private function render_r2_tab()
    {
    ?>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mcqvs_r2_endpoint"><?php esc_html_e('R2 Endpoint', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="url" name="mcqvs_r2_endpoint" id="mcqvs_r2_endpoint"
                        value="<?php echo esc_attr(get_option('mcqvs_r2_endpoint', '')); ?>" class="regular-text"
                        placeholder="https://ACCOUNT_ID.r2.cloudflarestorage.com" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_r2_access_key"><?php esc_html_e('Access Key ID', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="text" name="mcqvs_r2_access_key" id="mcqvs_r2_access_key"
                        value="<?php echo esc_attr(get_option('mcqvs_r2_access_key', '')); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_r2_secret_key"><?php esc_html_e('Secret Access Key', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="password" name="mcqvs_r2_secret_key" id="mcqvs_r2_secret_key"
                        value="<?php echo esc_attr(get_option('mcqvs_r2_secret_key', '')); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_r2_bucket"><?php esc_html_e('Bucket Name', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="text" name="mcqvs_r2_bucket" id="mcqvs_r2_bucket"
                        value="<?php echo esc_attr(get_option('mcqvs_r2_bucket', '')); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_r2_public_domain"><?php esc_html_e('Public Domain', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="url" name="mcqvs_r2_public_domain" id="mcqvs_r2_public_domain"
                        value="<?php echo esc_attr(get_option('mcqvs_r2_public_domain', '')); ?>" class="regular-text"
                        placeholder="https://videos.yourdomain.com" />
                    <p class="description">
                        <?php esc_html_e('Public URL where videos will be accessible. This MUST be a Cloudflare-served URL that points to the R2 bucket.', 'mcq-video-studio'); ?><br>
                        <strong><?php esc_html_e('Do NOT use your WordPress site URL', 'mcq-video-studio'); ?></strong> &mdash; <?php esc_html_e('R2 files are not stored on your web server.', 'mcq-video-studio'); ?><br>
                        <?php esc_html_e('Use either:', 'mcq-video-studio'); ?><br>
                        &bull; <a href="https://developers.cloudflare.com/r2/buckets/public-buckets/" target="_blank"><?php esc_html_e('R2 Public Bucket URL', 'mcq-video-studio'); ?></a> (e.g. <code>https://pub-XXXXXXXXXXXXXXXX.r2.dev</code>)<br>
                        &bull; <a href="https://developers.cloudflare.com/r2/buckets/public-buckets/#custom-domains" target="_blank"><?php esc_html_e('Custom Domain', 'mcq-video-studio'); ?></a> (e.g. <code>https://cdn.yourdomain.com</code>)
                    </p>
                </td>
            </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Test Connection', 'mcq-video-studio'); ?></th>
            <td>
                <button type="button" id="mcqvs-test-r2" class="button button-secondary">
                    <?php esc_html_e('Test R2 Connection', 'mcq-video-studio'); ?>
                </button>
                <span id="mcqvs-r2-status" class="mcqvs-status"></span>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_delivery_mode"><?php esc_html_e('Delivery Mode', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <select name="mcqvs_delivery_mode" id="mcqvs_delivery_mode">
                    <?php
                    $delivery_mode = get_option('mcqvs_delivery_mode', 'local');
                    $modes = array(
                        'local'     => 'Browser Download Only',
                        'r2'        => 'Upload to Cloudflare R2',
                        'r2_buffer' => 'R2 Upload + Auto-Post via Buffer',
                    );
                    foreach ($modes as $value => $label) : ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($delivery_mode, $value); ?>>
                            <?php echo esc_html($label); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <p class="description">
                    <strong>Browser Download:</strong> Videos save locally via browser (default).<br>
                    <strong>R2:</strong> Videos upload to Cloudflare R2 automatically after rendering.<br>
                    <strong>R2 + Buffer:</strong> Upload to R2, then auto-post to social media via Buffer.
                </p>
            </td>
        </tr>
    </table>
    <?php
        // Show a prominent warning if the public domain matches the WordPress site host.
        $r2_public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
        if ($r2_public_domain !== '') {
            $pd_host   = wp_parse_url($r2_public_domain, PHP_URL_HOST);
            $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
            if ($pd_host && $site_host && strtolower($pd_host) === strtolower($site_host)) {
                echo '<div class="notice notice-error" style="margin:12px 0 0;"><p>';
                echo '<strong>' . esc_html__('R2 Public Domain Misconfiguration:', 'mcq-video-studio') . '</strong> ';
                echo esc_html__('The public domain points at this WordPress site.', 'mcq-video-studio');
                echo ' <code>' . esc_html($pd_host) . '</code> &rarr; ';
                echo esc_html__('Videos stored in R2 are NOT accessible here. R2 links will return 404 and Buffer publishing will fail.', 'mcq-video-studio');
                echo '</p><p>';
                echo esc_html__('Set the public domain to one of:', 'mcq-video-studio') . '<br>';
                echo '&bull; ' . esc_html__('An R2 Public Bucket URL', 'mcq-video-studio') . ' <code>https://pub-XXXXXXXXXXXXXXXX.r2.dev</code><br>';
                echo '&bull; ' . esc_html__('A Cloudflare Workers custom domain connected to this R2 bucket', 'mcq-video-studio') . '<br><br>';
                echo esc_html__('Go to ', 'mcq-video-studio') . '<a href="https://dash.cloudflare.com/" target="_blank">Cloudflare Dashboard</a> &rarr; R2 &rarr; your bucket &rarr; Settings &rarr; Public Access.';
                echo '</p></div>';
            }
        }
    }

    /**
     * Render API Settings tab.
     * @NEW 2026-02-18
     */
    private function render_api_tab()
    {
        $api_key = get_option('mcqvs_gemini_api_key', '');
        $model   = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
        $parent_key = get_option('nm_gemini_api_key', '');
        $active_provider = get_option('mcqvs_api_provider', 'gemini');
        $registry = VS_Provider_Registry::get_instance();
        $all_ids = $registry->get_all_ids();
        $custom_providers = $registry->get_custom_providers();
        $custom_json = get_option('mcqvs_custom_providers', '[]');
    ?>
        <style>
            .mcqvs-provider-cards { margin-top: 15px; }
            .mcqvs-provider-card {
                background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;
                padding: 15px; margin-bottom: 12px; position: relative;
            }
            .mcqvs-provider-card.active { border-color: #2271b1; border-left: 4px solid #2271b1; }
            .mcqvs-provider-card-header {
                display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;
            }
            .mcqvs-provider-card-header h4 { margin: 0; font-size: 14px; }
            .mcqvs-provider-card-body { font-size: 12px; }
            .mcqvs-provider-card-body .form-field { margin-bottom: 8px; }
            .mcqvs-provider-card-body label { font-weight: 600; display: inline-block; width: 100px; }
            .mcqvs-provider-card-body input,
            .mcqvs-provider-card-body select { max-width: 400px; }
            .mcqvs-status.success { color: #00a32a; font-weight: 600; margin-left: 8px; }
            .mcqvs-status.error { color: #d63638; font-weight: 600; margin-left: 8px; }
            .mcqvs-status.loading { color: #2271b1; margin-left: 8px; }
            .mcqvs-add-provider-btn { margin-top: 10px; }
            .mcqvs-model-row { display: flex; gap: 6px; align-items: center; margin-bottom: 4px; }
            .mcqvs-model-row input { width: 180px; }
        </style>

        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mcqvs_api_provider"><?php esc_html_e('AI Provider', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <select name="mcqvs_api_provider" id="mcqvs_api_provider">
                        <?php
                        $builtin = $registry->get_builtin_providers();
                        foreach ($builtin as $id => $cfg) : ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php selected($active_provider, $id); ?>>
                            <?php echo esc_html($cfg['name']); ?>
                        </option>
                        <?php endforeach; ?>
                        <?php if (!empty($custom_providers)) : ?>
                        <optgroup label="Custom Providers">
                        <?php foreach ($custom_providers as $cp) : ?>
                            <option value="<?php echo esc_attr($cp['id']); ?>" <?php selected($active_provider, $cp['id']); ?>>
                                <?php echo esc_html($cp['name'] ?? 'Unnamed'); ?>
                            </option>
                        <?php endforeach; ?>
                        </optgroup>
                        <?php endif; ?>
                    </select>
                    <p class="description">
                        <?php esc_html_e('Select the AI provider for quiz generation, hooks, and SEO.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
        </table>

        <h3><?php esc_html_e('Built-in Providers', 'mcq-video-studio'); ?></h3>

        <div class="mcqvs-provider-cards">
            <div class="mcqvs-provider-card <?php echo ($active_provider === 'gemini') ? 'active' : ''; ?>" data-provider="gemini">
                <div class="mcqvs-provider-card-header">
                    <h4><?php esc_html_e('Google Gemini', 'mcq-video-studio'); ?><?php if ($active_provider === 'gemini') : ?> <span class="dashicons dashicons-yes-alt" style="color:#00a32a;"></span><?php endif; ?></h4>
                </div>
                <div class="mcqvs-provider-card-body">
                    <div class="form-field">
                        <label for="mcqvs_gemini_api_key"><?php esc_html_e('API Key', 'mcq-video-studio'); ?></label>
                        <input type="password" name="mcqvs_gemini_api_key" id="mcqvs_gemini_api_key"
                            value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
                            <p class="description" style="margin-left: 108px;">
                                <?php esc_html_e('Your own key, used only by this plugin. Required for AI generation.', 'mcq-video-studio'); ?>
                            </p>
                    </div>
                    <div class="form-field">
                        <label for="mcqvs_gemini_model_id"><?php esc_html_e('Model', 'mcq-video-studio'); ?></label>
                        <select name="mcqvs_gemini_model_id" id="mcqvs_gemini_model_id">
                            <?php $gemini_models = $registry->get_supported_models('gemini'); ?>
                            <?php foreach ($gemini_models as $val => $label) : ?>
                            <option value="<?php echo esc_attr($val); ?>" <?php selected($model, $val); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('Custom Models', 'mcq-video-studio'); ?></label>
                        <div class="mcqvs-custom-models-list" data-provider="gemini">
                            <?php $gemini_custom = $registry->get_builtin_custom_models('gemini'); ?>
                            <?php foreach ($gemini_custom as $cm) : ?>
                            <div class="mcqvs-model-row">
                                <input type="text" class="builtin-model-id" value="<?php echo esc_attr($cm['model_id'] ?? ''); ?>" placeholder="model-id" />
                                <input type="text" class="builtin-model-name" value="<?php echo esc_attr($cm['display_name'] ?? ''); ?>" placeholder="Display Name" />
                                <button type="button" class="button button-small mcqvs-remove-builtin-model" title="Remove">&times;</button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="button button-small mcqvs-add-builtin-model" data-provider="gemini"><?php esc_html_e('+ Add Custom Model', 'mcq-video-studio'); ?></button>
                        <input type="hidden" name="mcqvs_gemini_custom_models" id="mcqvs_gemini_custom_models_json" value="<?php echo esc_attr(get_option('mcqvs_gemini_custom_models', '')); ?>" />
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('Test', 'mcq-video-studio'); ?></label>
                        <button type="button" class="button button-secondary mcqvs-test-api-btn" data-provider="gemini">
                            <?php esc_html_e('Test Gemini Connection', 'mcq-video-studio'); ?>
                        </button>
                        <span class="mcqvs-status mcqvs-test-status" data-provider="gemini"></span>
                    </div>
                </div>
            </div>

        </div>

        <h3><?php esc_html_e('Custom Providers', 'mcq-video-studio'); ?></h3>
        <p class="description" style="margin-bottom:15px;">
            <?php esc_html_e('Add custom endpoints (vLLM, Ollama, DeepSeek, OpenRouter, Groq, Mistral, etc). These providers use the /v1/chat/completions route.', 'mcq-video-studio'); ?>
        </p>

        <div id="mcqvs-custom-providers-container" class="mcqvs-provider-cards">
            <?php foreach ($custom_providers as $cp) :
                $cp_id = esc_attr($cp['id'] ?? '');
                $is_active = ($active_provider === $cp_id);
            ?>
            <div class="mcqvs-provider-card <?php echo $is_active ? 'active' : ''; ?>" data-provider="<?php echo $cp_id; ?>" data-custom="1" data-profile-id="<?php echo $cp_id; ?>">
                <div class="mcqvs-provider-card-header">
                    <h4><?php echo esc_html($cp['name'] ?? 'Unnamed'); ?><?php if ($is_active) : ?> <span class="dashicons dashicons-yes-alt" style="color:#00a32a;"></span> (Active)<?php endif; ?></h4>
                    <div>
                        <button type="button" class="button button-small mcqvs-delete-custom-provider" data-provider-id="<?php echo $cp_id; ?>" style="color:#d63638;"><?php esc_html_e('Delete', 'mcq-video-studio'); ?></button>
                    </div>
                </div>
                <div class="mcqvs-provider-card-body">
                    <div class="form-field">
                        <label><?php esc_html_e('Name', 'mcq-video-studio'); ?></label>
                        <input type="text" class="cp-field" data-field="name" value="<?php echo esc_attr($cp['name'] ?? ''); ?>" />
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('API URL', 'mcq-video-studio'); ?></label>
                        <input type="url" class="cp-field regular-text" data-field="api_url" value="<?php echo esc_attr($cp['api_url'] ?? ''); ?>" placeholder="https://api.your-provider.com/v1" />
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('API Key', 'mcq-video-studio'); ?></label>
                        <input type="password" class="cp-field" data-field="api_key" value="<?php echo esc_attr($cp['api_key'] ?? ''); ?>" />
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('Models', 'mcq-video-studio'); ?></label>
                        <div class="mcqvs-models-list" data-profile-id="<?php echo $cp_id; ?>">
                        <?php foreach ((array)($cp['models'] ?? array()) as $mi => $m) : ?>
                            <div class="mcqvs-model-row">
                                <input type="text" class="cp-model-id" value="<?php echo esc_attr($m['model_id'] ?? ''); ?>" placeholder="model-id" />
                                <input type="text" class="cp-model-name" value="<?php echo esc_attr($m['display_name'] ?? ''); ?>" placeholder="Display Name" />
                                <button type="button" class="button button-small mcqvs-remove-model" title="Remove model">&times;</button>
                            </div>
                        <?php endforeach; ?>
                        </div>
                        <button type="button" class="button button-small mcqvs-add-model" data-profile-id="<?php echo $cp_id; ?>"><?php esc_html_e('+ Add Model', 'mcq-video-studio'); ?></button>
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('Options', 'mcq-video-studio'); ?></label>
                        <label style="width:auto; font-weight:normal; margin-right:15px;">
                            <input type="checkbox" class="cp-field" data-field="supports_json_schema" <?php checked(!empty($cp['supports_json_schema'])); ?> value="1" />
                            <?php esc_html_e('JSON Schema Support', 'mcq-video-studio'); ?>
                        </label>
                        <label style="width:auto; font-weight:normal; margin-right:15px;">
                            <input type="checkbox" class="cp-field" data-field="enable_web_search" <?php checked(!empty($cp['enable_web_search'])); ?> value="1" />
                            <?php esc_html_e('Web Search', 'mcq-video-studio'); ?>
                        </label>
                        <label style="width:auto; font-weight:normal;">
                            <input type="checkbox" class="cp-field" data-field="fallback_enabled" <?php checked(!empty($cp['fallback_enabled'])); ?> value="1" />
                            <?php esc_html_e('Model Fallback', 'mcq-video-studio'); ?>
                        </label>
                    </div>
                    <div class="form-field">
                        <label><?php esc_html_e('Test', 'mcq-video-studio'); ?></label>
                        <button type="button" class="button button-secondary mcqvs-test-api-btn" data-provider="<?php echo $cp_id; ?>">
                            <?php esc_html_e('Test Connection', 'mcq-video-studio'); ?>
                        </button>
                        <button type="button" class="button button-primary mcqvs-save-custom-provider" data-provider-id="<?php echo $cp_id; ?>" style="margin-left:8px;">
                            <?php esc_html_e('Save Provider', 'mcq-video-studio'); ?>
                        </button>
                        <span class="mcqvs-status mcqvs-test-status" data-provider="<?php echo $cp_id; ?>"></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <button type="button" id="mcqvs-add-custom-provider" class="button button-secondary mcqvs-add-provider-btn">
            <?php esc_html_e('+ Add Custom Provider', 'mcq-video-studio'); ?>
        </button>

        <h3><?php esc_html_e('Model Rotation', 'mcq-video-studio'); ?></h3>
        <p class="description" style="margin-bottom:15px;">
            <?php esc_html_e('The system cycles through all enabled providers/models in order. On 429 (rate limit) or 503 (server error), it automatically switches to the next model. Models with 3+ consecutive failures are temporarily skipped.', 'mcq-video-studio'); ?>
        </p>

        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('Rotation Queue', 'mcq-video-studio'); ?></th>
                <td>
                    <?php
                    $rotation_queue = $registry->get_rotation_queue();
                    $rotation_state = $registry->get_rotation_state();
                    $failures = isset($rotation_state['failures']) && is_array($rotation_state['failures']) ? $rotation_state['failures'] : array();
                    if (empty($rotation_queue)) : ?>
                        <p class="description"><?php esc_html_e('No providers configured. Add at least one provider with API key.', 'mcq-video-studio'); ?></p>
                    <?php else : ?>
                    <ol class="mcqvs-rotation-queue" style="margin:0; padding-left:20px;">
                        <?php foreach ($rotation_queue as $idx => $slot) :
                            $key = $slot['provider'] . '::' . $slot['model'];
                            $fail_count = isset($failures[$key]) ? (int)$failures[$key] : 0;
                            $is_current = ($idx === ($rotation_state['current_index'] ?? 0));
                        ?>
                        <li style="margin-bottom:4px; <?php echo $is_current ? 'font-weight:600; color:#2271b1;' : ''; ?>">
                            <?php echo esc_html($slot['label']); ?>
                            <?php if ($is_current) : ?> <span class="dashicons dashicons-arrow-right-alt" style="color:#2271b1;"></span> <em>(next)</em><?php endif; ?>
                            <?php if ($fail_count > 0) : ?>
                                <span style="color:#d63638; margin-left:8px;">⚠ <?php printf(esc_html__('%d failure(s)', 'mcq-video-studio'), $fail_count); ?></span>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; ?>
                    </ol>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Reset Failures', 'mcq-video-studio'); ?></th>
                <td>
                    <button type="button" class="button button-secondary" id="mcqvs-reset-rotation-failures">
                        <?php esc_html_e('Reset All Failure Counters', 'mcq-video-studio'); ?>
                    </button>
                    <span class="mcqvs-status" id="mcqvs-rotation-reset-status"></span>
                    <p class="description"><?php esc_html_e('Clears failure counters and resets rotation to the first model.', 'mcq-video-studio'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_provider_failure_cooldown"><?php esc_html_e('Model Failure Cooldown', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="number" name="mcqvs_provider_failure_cooldown" id="mcqvs_provider_failure_cooldown"
                        value="<?php echo esc_attr(get_option('mcqvs_provider_failure_cooldown', 600)); ?>"
                        min="60" max="7200" step="60" class="small-text" /> <?php esc_html_e('seconds', 'mcq-video-studio'); ?>
                    <p class="description">
                        <?php esc_html_e('When a MODEL returns 429 (quota exhausted) or 503, the plugin cools down ONLY that model for this many seconds, then tries the next model in the same provider (and across all configured providers) before failing a job. Defaults to 600s (10 min). Lower this for faster failover; raise it to avoid hammering a throttled model.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
        </table>

        <input type="hidden" id="mcqvs_custom_providers_json" name="mcqvs_custom_providers" value="<?php echo esc_attr($custom_json); ?>" />

        <h3><?php esc_html_e('Text-to-Speech Voice Settings', 'mcq-video-studio'); ?></h3>
        <p class="description" style="margin-bottom:15px;">
            <?php esc_html_e('Choose a default TTS voice for all videos, or enable rotation to cycle through different English accents (US, UK, AU, IN, CA, IE). Only applies to Edge TTS (server-side, free).', 'mcq-video-studio'); ?>
        </p>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mcqvs_tts_default_voice"><?php esc_html_e('Default TTS Voice', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <select name="mcqvs_tts_default_voice" id="mcqvs_tts_default_voice" style="width:350px;">
                        <?php
                        $default_voice = get_option('mcqvs_tts_default_voice', 'en-US-AriaNeural');
                        $all_voices = self::get_edge_english_voices();
                        foreach ($all_voices as $voice_id => $voice_name) :
                        ?>
                        <option value="<?php echo esc_attr($voice_id); ?>" <?php selected($default_voice, $voice_id); ?>>
                            <?php echo esc_html($voice_name); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" class="button button-secondary" id="mcqvs-test-tts-voice" style="margin-left:8px;">
                        <?php esc_html_e('Test Voice', 'mcq-video-studio'); ?>
                    </button>
                    <span id="mcqvs-tts-test-status" class="mcqvs-status" style="margin-left:8px;"></span>
                    <p class="description">
                        <?php esc_html_e('This voice is used across the entire plugin when voice rotation is disabled below.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Voice Rotation', 'mcq-video-studio'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="mcqvs_tts_voice_rotation_enabled" id="mcqvs_tts_voice_rotation_enabled" value="1" <?php checked(get_option('mcqvs_tts_voice_rotation_enabled', false)); ?> />
                        <?php esc_html_e('Enable voice rotation — cycle through multiple voices/accents per video', 'mcq-video-studio'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('When enabled, each new video job picks the next voice from the list below instead of the default voice above.', 'mcq-video-studio'); ?>
                    </p>
                    <div id="mcqvs-voice-rotation-list-wrap" style="margin-top:10px; <?php echo get_option('mcqvs_tts_voice_rotation_enabled', false) ? '' : 'display:none;'; ?>">
                        <input type="hidden" name="mcqvs_tts_voice_rotation_list" value="" />
                        <select name="mcqvs_tts_voice_rotation_list[]" id="mcqvs_tts_voice_rotation_list" multiple style="min-height:150px; width:350px;">
                            <?php
                            $saved = get_option('mcqvs_tts_voice_rotation_list', '[]');
                            $selected_voices = is_string($saved) ? json_decode($saved, true) : (is_array($saved) ? $saved : array());
                            if (!is_array($selected_voices)) $selected_voices = array();
                            foreach ($all_voices as $voice_id => $voice_name) :
                                $is_sel = in_array($voice_id, $selected_voices, true);
                            ?>
                            <option value="<?php echo esc_attr($voice_id); ?>" <?php selected($is_sel); ?>>
                                <?php echo esc_html($voice_name); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">
                            <?php esc_html_e('Hold Ctrl/Cmd to select multiple voices. Leave all unselected to keep using the default voice above.', 'mcq-video-studio'); ?>
                        </p>
                    </div>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Speak Options Aloud', 'mcq-video-studio'); ?></th>
                <td>
                    <label for="mcqvs_tts_speak_options">
                        <input type="hidden" name="mcqvs_tts_speak_options" value="0" />
                        <input type="checkbox" name="mcqvs_tts_speak_options" id="mcqvs_tts_speak_options" value="1" <?php checked(get_option('mcqvs_tts_speak_options', true)); ?> />
                        <?php esc_html_e('Read the 4 answer options aloud in every question', 'mcq-video-studio'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Reading all options is the largest TTS time cost. Turn this OFF to keep Shorts in the 25–40 second range (question + answer are still spoken; only the option list is skipped). Applies to new videos created by the Content Planner and to the Studio editor defaults.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <!-- @FIX 1.4.9.49 (TTS SSOT): these are the single source of truth for what
                 TTS reads, the rate, and whether TTS is on — Studio + Content Planner +
                 headless all read them. -->
            <tr>
                <th scope="row"><?php esc_html_e('Enable Voiceover (TTS)', 'mcq-video-studio'); ?></th>
                <td>
                    <label for="mcqvs_tts_enabled">
                        <input type="hidden" name="mcqvs_tts_enabled" value="0" />
                        <input type="checkbox" name="mcqvs_tts_enabled" id="mcqvs_tts_enabled" value="1" <?php checked(get_option('mcqvs_tts_enabled', true)); ?> />
                        <?php esc_html_e('Generate voiceover narration in exported videos (Edge TTS)', 'mcq-video-studio'); ?>
                    </label>
                    <p class="description"><?php esc_html_e('Master switch for the whole plugin. Studio preview may still use browser speech; exports follow this setting.', 'mcq-video-studio'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Speech Rate', 'mcq-video-studio'); ?></th>
                <td>
                    <input type="number" name="mcqvs_tts_rate" id="mcqvs_tts_rate" value="<?php echo esc_attr(get_option('mcqvs_tts_rate', 1.2)); ?>" min="0.5" max="2.0" step="0.1" style="width:120px;" />
                    <span style="margin-left:8px;color:#666;">×</span>
                    <p class="description"><?php esc_html_e('0.5x – 2.0x. Default 1.2 (keeps a 5-question Short ~30-40s).', 'mcq-video-studio'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Read Hook Aloud', 'mcq-video-studio'); ?></th>
                <td>
                    <label for="mcqvs_tts_speak_hook">
                        <input type="hidden" name="mcqvs_tts_speak_hook" value="0" />
                        <input type="checkbox" name="mcqvs_tts_speak_hook" id="mcqvs_tts_speak_hook" value="1" <?php checked(get_option('mcqvs_tts_speak_hook', true)); ?> />
                        <?php esc_html_e('Narrate the hook line', 'mcq-video-studio'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Read Answer Aloud', 'mcq-video-studio'); ?></th>
                <td>
                    <label for="mcqvs_tts_speak_answer">
                        <input type="hidden" name="mcqvs_tts_speak_answer" value="0" />
                        <input type="checkbox" name="mcqvs_tts_speak_answer" id="mcqvs_tts_speak_answer" value="1" <?php checked(get_option('mcqvs_tts_speak_answer', true)); ?> />
                        <?php esc_html_e('Narrate the correct answer on reveal', 'mcq-video-studio'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Read CTA Aloud', 'mcq-video-studio'); ?></th>
                <td>
                    <label for="mcqvs_tts_speak_cta">
                        <input type="hidden" name="mcqvs_tts_speak_cta" value="0" />
                        <input type="checkbox" name="mcqvs_tts_speak_cta" id="mcqvs_tts_speak_cta" value="1" <?php checked(get_option('mcqvs_tts_speak_cta', false)); ?> />
                        <?php esc_html_e('Narrate the "Comment your score" CTA in the outro', 'mcq-video-studio'); ?>
                    </label>
                </td>
            </tr>
        </table>

        <script type="text/javascript">
        jQuery(function($) {
            // Toggle rotation list visibility
            var $cb = $('#mcqvs_tts_voice_rotation_enabled');
            var $wrap = $('#mcqvs-voice-rotation-list-wrap');
            $cb.on('change', function() {
                $wrap.toggle($(this).is(':checked'));
            });

            // Test Voice button
            $('#mcqvs-test-tts-voice').on('click', function() {
                var $btn = $(this);
                var $status = $('#mcqvs-tts-test-status');
                var voice = $('#mcqvs_tts_default_voice').val();
                if (!voice) { $status.text('No voice selected.'); return; }

                // Debounce: prevent rapid-fire clicks that could trigger rate limiting
                if ($btn.data('debounce')) {
                    return;
                }
                $btn.data('debounce', true);
                setTimeout(function() { $btn.data('debounce', false); }, 500);

                $btn.prop('disabled', true);
                $status.removeClass('success error').addClass('loading').text('Generating...');

                $.post(mcqvsSettings.ajaxUrl, {
                    action: 'mcqvs_generate_tts',
                    nonce: mcqvsSettings.nonce,
                    text: 'Hello, this is a sample of my voice. Can you score five out of five?',
                    provider: 'edge',
                    voice: voice,
                    rate: 1.0,
                    pitch: 0.0
                }, function(response) {
                    $btn.prop('disabled', false);
                    $status.removeClass('loading');
                    if (response.success && response.data && response.data.audio_url) {
                        $status.addClass('success').text('Playing...');
                        var audio = new Audio(response.data.audio_url);
                        audio.onended = function() { $status.removeClass('success').text(''); };
                        audio.play().catch(function() { $status.addClass('error').text('Playback failed'); });
                    } else {
                        $status.addClass('error').text('Failed: ' + (response.data || 'unknown error'));
                    }
                }).fail(function() {
                    $btn.prop('disabled', false);
                    $status.removeClass('loading').addClass('error').text('Network error');
                    // Reset debounce on network error too
                    $btn.data('debounce', false);
                });
            });
        });
        </script>
    <?php
    }

    /**
     * @NEW 2026-07-28: Comprehensive list of Edge TTS English neural voices
     * across 6 English-speaking regions. Used by the voice rotation system
     * and by the Studio UI voice selector. Kept in one place so both PHP
     * and JS sides reference the same canonical set.
     *
     * @return array voice_id => display_name
     */
    public static function get_edge_english_voices()
    {
        return array(
            // US English (en-US)
            'en-US-AriaNeural'    => 'Aria (Female, US)',
            'en-US-GuyNeural'     => 'Guy (Male, US)',
            'en-US-JennyNeural'   => 'Jenny (Female, US)',
            'en-US-TonyNeural'    => 'Tony (Male, US)',
            'en-US-MichelleNeural' => 'Michelle (Female, US)',
            'en-US-AnaNeural'     => 'Ana (Female, US, Child)',
            // UK English (en-GB) — tested working
            'en-GB-SoniaNeural'   => 'Sonia (Female, UK)',
            'en-GB-RyanNeural'    => 'Ryan (Male, UK)',
            'en-GB-LibbyNeural'   => 'Libby (Female, UK)',
            'en-GB-MaisieNeural'  => 'Maisie (Female, UK)',
            'en-GB-ThomasNeural'  => 'Thomas (Male, UK)',
            // Australian English (en-AU) — tested working
            'en-AU-NatashaNeural' => 'Natasha (Female, AU)',
            'en-AU-WilliamNeural' => 'William (Male, AU)',
            // Indian English (en-IN) — tested working
            'en-IN-NeerjaNeural'  => 'Neerja (Female, IN)',
            'en-IN-PrabhatNeural' => 'Prabhat (Male, IN)',
            // Canadian English (en-CA)
            'en-CA-ClaraNeural'   => 'Clara (Female, CA)',
            'en-CA-LiamNeural'    => 'Liam (Male, CA)',
            // Irish English (en-IE)
            'en-IE-ConnorNeural'  => 'Connor (Male, IE)',
            'en-IE-EmilyNeural'   => 'Emily (Female, IE)',
        );
    }

    /**
     * @NEW 2026-07-28: Get the next voice in the rotation cycle and advance
     * the persistent index. Used by the content planner and headless renderer
     * so every new job gets a different voice/ accent.
     *
     * Returns the default voice when rotation is disabled or no voices selected.
     *
     * @return string Edge TTS voice ID (e.g. 'en-US-AriaNeural')
     */
    public static function get_next_rotation_voice()
    {
        $default_voice = get_option('mcqvs_tts_default_voice', 'en-US-AriaNeural');
        if (empty($default_voice)) {
            $default_voice = 'en-US-AriaNeural';
        }

        $enabled = get_option('mcqvs_tts_voice_rotation_enabled', false);
        if (!$enabled) {
            return $default_voice;
        }

        $saved = get_option('mcqvs_tts_voice_rotation_list', '[]');
        $voice_list = is_string($saved) ? json_decode($saved, true) : (is_array($saved) ? $saved : array());
        if (!is_array($voice_list) || empty($voice_list)) {
            return $default_voice;
        }

        $allowed = self::get_edge_english_voices();
        $voice_list = array_values(array_intersect($voice_list, array_keys($allowed)));

        if (empty($voice_list)) {
            return $default_voice;
        }

        $index = (int) get_option('mcqvs_tts_voice_rotation_index', 0);
        $voice = $voice_list[$index % count($voice_list)];
        $index = ($index + 1) % count($voice_list);
        update_option('mcqvs_tts_voice_rotation_index', $index);
        return $voice;
    }

    /**
     * Render Automation/Schedule tab.
     *
     * @since 1.0.0
     */
    private function render_automation_tab()
    {
        $enabled = get_option('mcqvs_automation_enabled', false);
        $count = get_option('mcqvs_automation_count', 3);
        $ai_batch_size = get_option('mcqvs_ai_batch_size', 10);
        ?>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('Enable Daily Schedule', 'mcq-video-studio'); ?></th>
                <td>
                    <label>
                    <input type="checkbox" name="mcqvs_automation_enabled" value="1" <?php checked($enabled === true || $enabled === 1 || $enabled === '1'); ?> />
                    <?php esc_html_e('Automatically generate videos daily at midnight', 'mcq-video-studio'); ?>
                </label>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_automation_count"><?php esc_html_e('Videos Per Day', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="number" name="mcqvs_automation_count" id="mcqvs_automation_count"
                        value="<?php echo esc_attr($count); ?>" min="1" max="10" class="small-text" />
                    <p class="description">
                        <?php esc_html_e('Number of videos to generate per day (1-10).', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_ai_batch_size"><?php esc_html_e('Topics Per API Call', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="number" name="mcqvs_ai_batch_size" id="mcqvs_ai_batch_size"
                    value="<?php echo esc_attr($ai_batch_size); ?>" min="3" max="25" class="small-text" />
                <p class="description">
                    Number of topics sent to Gemini in a single API call (3-25). Higher = fewer API calls = lower cost. Default: 10. Gemini Flash handles up to 15 comfortably.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Manual Trigger', 'mcq-video-studio'); ?></th>
                <td>
                    <button type="button" id="mcqvs-run-automation" class="button button-primary">
                        <?php esc_html_e('Run Schedule Now', 'mcq-video-studio'); ?>
                    </button>
                    <span id="mcqvs-automation-status" class="mcqvs-status"></span>
                    <p class="description">
                        <?php esc_html_e('Manually trigger the daily scheduler immediately.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <!-- @TODO: Add Advanced Content Calendar UI here -->
        </table>
    <?php
    }

    /**
     * Render Dashboard Tab.
     * @NEW 2026-02-09
     */
    private function render_dashboard_tab()
    {
        // 1. Fetch Data
        $mcq_repo = new VS_MCQ_Repository();
        $job_repo = VS_Job_Repository::init();
        $logger   = VS_Error_Logger::get_instance();

        $stats_mcq = array(
            'total' => $mcq_repo->count_items('approved', 'total'),
            'today' => $mcq_repo->count_items('approved', 'today'),
        );

        $stats_jobs = $job_repo->get_stats();

        // @MODIFIED 2026-02-23: Videos Created is derived from completed jobs so it
        //              always matches the "Completed" pipeline card (server/headless
        //              completions never incremented the old append-only option).
        $video_stats = VS_Error_Logger::get_completed_video_stats();

        $api_usage = $logger->get_daily_api_usage();
        $api_by_source = $logger->get_daily_api_usage_by_source();
        $api_quota = 1000; // Hardcoded for now

        $recent_batches = VS_Bulk_Scheduler::get_recent_batches(5);
        $recent_errors  = $logger->get_recent_errors(5);

        // 2. Render UI
    ?>
        <style>
            .vs-dashboard-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 20px;
                margin-top: 20px;
                margin-bottom: 40px;
            }

            .vs-card {
                background: #fff;
                padding: 20px;
                border: 1px solid #ccd0d4;
                border-radius: 4px;
                box-shadow: 0 1px 1px rgba(0, 0, 0, .04);
            }

            .vs-card h3 {
                margin: 0 0 10px;
                font-size: 13px;
                color: #50575e;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            .vs-stat-value {
                font-size: 28px;
                font-weight: 600;
                color: #1d2327;
                line-height: 1.2;
            }

            .vs-stat-sub {
                font-size: 12px;
                color: #787c82;
                margin-top: 5px;
            }

            .vs-stat-sub.positive {
                color: #46b450;
            }

            .vs-dashboard-split {
                display: grid;
                grid-template-columns: 2fr 1fr;
                gap: 20px;
            }

            .vs-section-header {
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                display: block;
            }

            /* Timeline */
            .vs-timeline {
                padding: 0;
                margin: 0;
                list-style: none;
            }

            .vs-timeline li {
                position: relative;
                padding-left: 20px;
                margin-bottom: 15px;
                border-left: 2px solid #ddd;
                padding-bottom: 5px;
            }

            .vs-timeline li::before {
                content: '';
                position: absolute;
                left: -6px;
                top: 0;
                width: 10px;
                height: 10px;
                border-radius: 50%;
                background: #ddd;
            }

            .vs-timeline li.completed {
                border-left-color: #46b450;
            }

            .vs-timeline li.completed::before {
                background: #46b450;
            }

            .vs-timeline li.processing {
                border-left-color: #2271b1;
            }

            .vs-timeline li.processing::before {
                background: #2271b1;
            }

            .vs-timeline li.failed {
                border-left-color: #d63638;
            }

            .vs-timeline li.failed::before {
                background: #d63638;
            }

            .vs-batch-header {
                font-weight: 600;
                color: #2c3338;
                font-size: 14px;
            }

            .vs-batch-meta {
                font-size: 12px;
                color: #646970;
            }

            /* Error List */
            .vs-error-list {
                background: #fff;
                border: 1px solid #d63638;
                border-radius: 4px;
            }

            .vs-error-item {
                padding: 10px;
                border-bottom: 1px solid #f0f0f1;
                font-size: 12px;
            }

            .vs-error-item:last-child {
                border-bottom: none;
            }

            .vs-error-time {
                color: #a0a5aa;
                margin-bottom: 4px;
                display: block;
                font-size: 11px;
            }

            .vs-error-msg {
                color: #d63638;
                font-weight: 500;
            }

            .vs-empty-state {
                padding: 20px;
                text-align: center;
                color: #a7aaad;
                font-style: italic;
            }
        </style>

        <!-- KPIS -->
        <div class="vs-dashboard-grid">
            <div class="vs-card">
                <h3><?php esc_html_e('Questions Generated', 'mcq-video-studio'); ?></h3>
                <div class="vs-stat-value"><?php echo esc_html($stats_mcq['total']); ?></div>
                <div class="vs-stat-sub <?php echo $stats_mcq['today'] > 0 ? 'positive' : ''; ?>">
                    <?php printf(esc_html__('+%d today', 'mcq-video-studio'), $stats_mcq['today']); ?>
                </div>
            </div>

            <div class="vs-card">
                <h3><?php esc_html_e('Videos Created', 'mcq-video-studio'); ?></h3>
                <div class="vs-stat-value"><?php echo esc_html($video_stats['total']); ?></div>
                <div class="vs-stat-sub <?php echo $video_stats['today'] > 0 ? 'positive' : ''; ?>">
                    <?php printf(esc_html__('+%d today', 'mcq-video-studio'), $video_stats['today']); ?>
                </div>
            </div>

            <div class="vs-card">
                <h3><?php esc_html_e('Jobs in Queue', 'mcq-video-studio'); ?></h3>
                <div class="vs-stat-value"><?php echo esc_html($stats_jobs['pending']); ?></div>
                <div class="vs-stat-sub">
                    <?php esc_html_e('Pending processing', 'mcq-video-studio'); ?>
                </div>
            </div>

            <div class="vs-card">
                <h3><?php esc_html_e('API Calls Today', 'mcq-video-studio'); ?></h3>
                <div class="vs-stat-value">
                    <?php echo esc_html($api_usage); ?>
                </div>
                <?php
                $legacy_api_labels = array('buffer' => __('Buffer', 'mcq-video-studio'), 'other' => __('Other', 'mcq-video-studio'));
                if (class_exists('VS_Provider_Registry')) {
                    $legacy_reg = VS_Provider_Registry::get_instance();
                    foreach ($legacy_reg->get_builtin_providers() as $pid => $pcfg) {
                        $legacy_api_labels[$pid] = $pcfg['name'] ?? ucfirst($pid);
                    }
                    foreach ($legacy_reg->get_custom_providers() as $profile) {
                        if (! empty($profile['id'])) {
                            $legacy_api_labels[$profile['id']] = ! empty($profile['name']) ? $profile['name'] : $profile['id'];
                        }
                    }
                }
                $legacy_api_sorted = $api_by_source;
                arsort($legacy_api_sorted);
                ?>
                <div class="vs-api-legacy-split">
                    <?php if (empty($legacy_api_sorted)) : ?>
                        <div class="vs-api-legacy-none"><?php esc_html_e('No calls yet', 'mcq-video-studio'); ?></div>
                    <?php else : ?>
                        <?php foreach ($legacy_api_sorted as $lsrc => $lcnt) : ?>
                            <div class="vs-api-legacy-row">
                                <span class="vs-api-legacy-dot" style="background:<?php echo esc_attr($lsrc === 'buffer' ? '#06b6d4' : ($lsrc === 'other' ? '#94a3b8' : '#6366f1')); ?>"></span>
                                <span class="vs-api-legacy-name"><?php echo esc_html($legacy_api_labels[$lsrc] ?? ucfirst($lsrc)); ?></span>
                                <span class="vs-api-legacy-bar"><span style="width:<?php echo esc_attr($api_usage > 0 ? min(100, round($lcnt / $api_usage * 100)) : 0); ?>%"></span></span>
                                <span class="vs-api-legacy-count"><?php echo esc_html($lcnt); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="vs-dashboard-split">
            <!-- Timeline -->
            <div>
                <span class="vs-section-header"><?php esc_html_e('Recent Batches', 'mcq-video-studio'); ?></span>
                <?php if (empty($recent_batches)) : ?>
                    <div class="vs-card vs-empty-state"><?php esc_html_e('No recent batches found.', 'mcq-video-studio'); ?></div>
                <?php else : ?>
                    <ul class="vs-timeline">
                        <?php foreach ($recent_batches as $batch) : ?>
                            <?php
                            $status_class = $batch['status'] === 'completed' ? 'completed' : ($batch['status'] === 'failed' ? 'failed' : 'processing');
                            $icon = $batch['status'] === 'completed' ? '✅' : ($batch['status'] === 'failed' ? '⚠️' : '⏳');
                            ?>
                            <li class="<?php echo esc_attr($status_class); ?>">
                                <div class="vs-batch-header">
                                    <?php echo esc_html($icon . ' ' . $batch['topic']); ?>
                                </div>
                                <div class="vs-batch-meta">
                                    <?php printf(
                                        esc_html__('%s Qs • %s videos • %s', 'mcq-video-studio'),
                                        $batch['total_questions'],
                                        isset($batch['job_ids']) ? count($batch['job_ids']) : 0,
                                        human_time_diff(strtotime($batch['created_at'] . ' UTC'), time()) . ' ago'
                                    ); ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Errors -->
            <div>
                <span class="vs-section-header"><?php esc_html_e('Error Summary', 'mcq-video-studio'); ?></span>
                <div class="vs-error-list">
                    <?php if (empty($recent_errors)) : ?>
                        <div class="vs-empty-state"><?php esc_html_e('No recent errors.', 'mcq-video-studio'); ?></div>
                    <?php else : ?>
                        <?php foreach ($recent_errors as $err) : ?>
                            <div class="vs-error-item">
                                <span class="vs-error-time"><?php echo esc_html($err['ts']); ?></span>
                                <div class="vs-error-msg"><?php echo esc_html($err['message']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php
    }

    /**
     * Render Migration tab.
     *
     * @since 1.1.0
     */
    private function render_migration_tab()
    {
    ?>
        <div class="mcqvs-migration-wrap" style="max-width: 800px; margin-top: 20px;">
            <div class="notice notice-info inline">
                <p>
                    <strong><?php esc_html_e('Migration Tool', 'mcq-video-studio'); ?></strong><br>
                    <?php esc_html_e('Move your existing "MCQ" posts and "Topics" to the new optimized Custom Tables.', 'mcq-video-studio'); ?>
                </p>
            </div>

            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Migration Status', 'mcq-video-studio'); ?></th>
                    <td>
                        <button type="button" id="mcqvs-check-migration" class="button button-secondary">
                            <?php esc_html_e('Check Status', 'mcq-video-studio'); ?>
                        </button>
                        <span id="mcqvs-migration-check-status" class="mcqvs-status" style="margin-left: 10px;"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Run Migration', 'mcq-video-studio'); ?></th>
                    <td>
                        <button type="button" id="mcqvs-run-migration" class="button button-primary">
                            <?php esc_html_e('Start Migration', 'mcq-video-studio'); ?>
                        </button>
                        <p class="description">
                            <?php esc_html_e('Process will run in batches. Do not close this tab.', 'mcq-video-studio'); ?>
                        </p>

                        <div id="mcqvs-migration-progress" style="margin-top: 15px; display: none;">
                            <div style="background: #fff; border: 1px solid #ccc; height: 20px; width: 100%; border-radius: 3px; overflow: hidden;">
                                <div id="mcqvs-migration-bar" style="background: #2271b1; height: 100%; width: 0%; transition: width 0.3s;"></div>
                            </div>
                            <p id="mcqvs-migration-log" style="font-family: monospace; font-size: 12px; margin-top: 5px; color: #666;"></p>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
<?php
    }




    /**
     * AJAX: Test Buffer connection.
     *
     * @since 1.0.0
     */
    public function ajax_test_buffer()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // @NEW 2026-08-07: Per-account support — if account_id is posted, use the
        // token from the registry. Otherwise fall back to the legacy single-account
        // option for backward compatibility.
        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if ($account_id !== '') {
            $accounts = VS_Buffer_Account_Registry::get_accounts();
            $token    = $accounts[$account_id]['token'] ?? '';
            if (empty($token)) {
                wp_send_json_error('No token configured for this account.');
            }
        } else {
            $token = get_option('mcqvs_buffer_access_token', '');
            if (empty($token)) {
                wp_send_json_error('No token configured');
            }
        }

        // @FIX 2026-08-08: Pass account_id to the client so it resolves + caches the
        // organization id under the per-account key (mcqvs_buffer_account_{id}_org_id).
        // Without it, the client falls back to the legacy GLOBAL org id, which can be
        // stale from a previous token/org and yields an empty channel list.
        $client   = new VS_Buffer_Client($token, $account_id);
        $profiles = $client->get_profiles();

        if (is_wp_error($profiles)) {
            wp_send_json_error($profiles->get_error_message());
        }

        if (! is_array($profiles)) {
            wp_send_json_error('Buffer API returned an unexpected response.');
        }

        wp_send_json_success(array(
            'profiles' => count($profiles),
            'message'  => sprintf('Found %d connected channels', count($profiles)),
        ));
    }

    /**
     * AJAX: Refresh Buffer channels from API.
     *
     * @since 1.0.0
     */
    public function ajax_refresh_buffer_channels()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // @NEW 2026-08-07: Per-account support — if account_id is posted, use that
        // account's token and store channels under the per-account cache keys that
        // VS_Buffer_Client::channels_data_option_key() / channel_ids_option_key()
        // read at publish time. Otherwise fall back to legacy single-account keys.
        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if ($account_id !== '') {
            $accounts = VS_Buffer_Account_Registry::get_accounts();
            if (!isset($accounts[$account_id])) {
                wp_send_json_error('Account not found.');
            }
            $token = $accounts[$account_id]['token'] ?? '';
            if (empty($token)) {
                wp_send_json_error('No token configured for this account.');
            }
            $store_key = 'mcqvs_buffer_account_' . $account_id . '_channels_data';
            $list_key  = 'mcqvs_buffer_account_' . $account_id . '_channel_ids';
        } else {
            $token     = get_option('mcqvs_buffer_access_token', '');
            if (empty($token)) {
                wp_send_json_error('No token configured');
            }
            $store_key = 'mcqvs_buffer_channels_data';
            $list_key  = 'mcqvs_buffer_channels';
        }

        VS_Buffer_Client::clear_channels_cache($account_id);

        // @FIX 2026-08-08: Pass account_id to the client (see note above) so the
        // org id is resolved + cached per account instead of using the legacy
        // global org cache that may point at a stale/other organization.
        $client   = new VS_Buffer_Client($token, $account_id);
        $channels = $client->get_channels();

        if (is_wp_error($channels)) {
            wp_send_json_error($channels->get_error_message());
        }

        if (! is_array($channels)) {
            wp_send_json_error('Buffer API returned an unexpected response.');
        }

        $channel_ids = array();
        foreach ($channels as $ch) {
            if (!empty($ch['id'])) {
                $channel_ids[] = $ch['id'];
            }
        }
        update_option($list_key, wp_json_encode($channel_ids), false);
        update_option($store_key, wp_json_encode($channels), false);

        wp_send_json_success(array(
            'channels'   => $channels,
            'account_id' => $account_id,
            'message'    => sprintf('Found %d channels', count($channels)),
        ));
    }

    /**
     * @NEW 2026-07-19: Manually push a job to Buffer (for jobs that failed 3 auto-attempts).
     */
    public function ajax_manual_buffer_push()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Job ID required');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (!$job) {
            wp_send_json_error('Job not found');
        }

        // @FIX 2026-08-07: Clear the BLOCK flags so the push is fresh, but KEEP the
        // audit state (last_error + last_error_time) so admins can see what failed
        // before the manual retry. Also stamp manual_reset_at for the timeline.
        $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        if (!is_array($settings)) {
            $settings = array();
        }
        unset($settings['buffer_manual_pending']);
        unset($settings['buffer_attempts']);
        $settings['manual_reset_at'] = gmdate('Y-m-d H:i:s');
        $job_repo->update_job_fields($job_id, array('settings' => wp_json_encode($settings)));

        // Clear any retry throttle.
        delete_transient('mcqvs_buffer_retry_' . $job_id);

        $video_url = $job['video_url'];
        if (empty($video_url)) {
            wp_send_json_error('Job has no video URL');
        }

        $result = VS_Buffer_Client::push_job_to_buffer($job_id, $video_url, $job);

        if (is_wp_error($result)) {
            wp_send_json_error('Manual Buffer push failed: ' . $result->get_error_message());
        }

        wp_send_json_success(array(
            'message' => 'Manual Buffer push completed successfully',
            'result'  => $result,
        ));
    }

    /**
     * AJAX: Add a new Buffer account.
     *
     * @since 1.4.9.14
     */
    public function ajax_add_buffer_account()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $data = array(
            'label'              => sanitize_text_field($_POST['label'] ?? ''),
            'token'              => sanitize_text_field($_POST['token'] ?? ''),
            'enabled'            => !empty($_POST['enabled']),
            'daily_limit'        => max(0, (int) ($_POST['daily_limit'] ?? 0)),
            'scheduling_mode'    => in_array($_POST['scheduling_mode'] ?? '', array('addToQueue', 'customScheduled', 'shareNow'), true) ? $_POST['scheduling_mode'] : 'addToQueue',
            'caption_template'   => sanitize_textarea_field($_POST['caption_template'] ?? ''),
            'youtube_title'      => sanitize_text_field($_POST['youtube_title'] ?? ''),
            'youtube_category'   => sanitize_text_field($_POST['youtube_category'] ?? '27'),
        );

        $result = VS_Buffer_Account_Registry::add_account($data);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        $accounts = VS_Buffer_Account_Registry::get_accounts();
        $new_account = $accounts[$result] ?? null;

        wp_send_json_success(array(
            'account_id' => $result,
            'account'    => $new_account,
            'message'    => 'Buffer account added successfully.',
        ));
    }

    /**
     * AJAX: Save changes to an existing Buffer account.
     *
     * @since 1.4.9.14
     */
    public function ajax_save_buffer_account()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if (empty($account_id)) {
            wp_send_json_error('Account ID required');
        }

        $data = array(
            'label'              => sanitize_text_field($_POST['label'] ?? ''),
            'enabled'            => !empty($_POST['enabled']),
            'daily_limit'        => max(0, (int) ($_POST['daily_limit'] ?? 0)),
            'scheduling_mode'    => in_array($_POST['scheduling_mode'] ?? '', array('addToQueue', 'customScheduled', 'shareNow'), true) ? $_POST['scheduling_mode'] : 'addToQueue',
            'caption_template'   => sanitize_textarea_field($_POST['caption_template'] ?? ''),
            'channels'           => isset($_POST['channels']) && is_array($_POST['channels']) ? array_map('sanitize_text_field', $_POST['channels']) : array(),
            'channel_types'      => isset($_POST['channel_types']) && is_array($_POST['channel_types']) ? $_POST['channel_types'] : array(),
            'channel_link_posts' => isset($_POST['channel_link_posts']) && is_array($_POST['channel_link_posts']) ? $_POST['channel_link_posts'] : array(),
            'youtube_title'      => sanitize_text_field($_POST['youtube_title'] ?? ''),
            'youtube_category'   => sanitize_text_field($_POST['youtube_category'] ?? '27'),
            // @NEW 2026-08-10: Per-channel UI state. The registry sanitizes these
            // maps; we forward whatever the JS sent so a partial save (e.g. just
            // toggling the story tick) doesn't clobber the other maps.
            'channel_captions'      => isset($_POST['channel_captions']) ? wp_unslash($_POST['channel_captions']) : null,
            'channel_post_to_story' => isset($_POST['channel_post_to_story']) ? wp_unslash($_POST['channel_post_to_story']) : null,
        );

        // Token is optional on save (only update if provided).
        if (!empty($_POST['token'])) {
            $data['token'] = sanitize_text_field($_POST['token']);
        }

        $result = VS_Buffer_Account_Registry::update_account($account_id, $data);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success(array(
            'account_id' => $account_id,
            'message'    => 'Buffer account saved successfully.',
        ));
    }

    /**
     * AJAX: Delete a Buffer account.
     *
     * @since 1.4.9.14
     */
    public function ajax_delete_buffer_account()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if (empty($account_id)) {
            wp_send_json_error('Account ID required');
        }

        $result = VS_Buffer_Account_Registry::delete_account($account_id);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success(array(
            'account_id' => $account_id,
            'message'    => 'Buffer account deleted successfully.',
        ));
    }

    /**
     * AJAX: Set an account as the default.
     *
     * @since 1.4.9.14
     */
    public function ajax_set_default_buffer_account()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if (empty($account_id)) {
            wp_send_json_error('Account ID required');
        }

        $accounts = VS_Buffer_Account_Registry::get_accounts();
        if (!isset($accounts[$account_id])) {
            wp_send_json_error('Account not found');
        }

        // Clear existing default.
        foreach ($accounts as $aid => $acct) {
            if (!empty($acct['is_default'])) {
                $accounts[$aid]['is_default'] = false;
            }
        }
        $accounts[$account_id]['is_default'] = true;

        update_option(VS_Buffer_Account_Registry::OPTION_ACCOUNTS, wp_json_encode($accounts), false);

        wp_send_json_success(array(
            'default_account_id' => $account_id,
            'message'            => 'Default Buffer account updated.',
        ));
    }

    /**
     * AJAX: Refresh channels for a specific Buffer account.
     *
     * @since 1.4.9.14
     */
    public function ajax_refresh_buffer_account_channels()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $account_id = sanitize_key($_POST['account_id'] ?? '');
        if (empty($account_id)) {
            wp_send_json_error('Account ID required');
        }

        $token = VS_Buffer_Account_Registry::get_token($account_id);
        if (empty($token)) {
            wp_send_json_error('No token configured for this account');
        }

        VS_Buffer_Client::clear_channels_cache($account_id);

        $client   = new VS_Buffer_Client($token, $account_id);
        $channels = $client->get_channels();

        if (is_wp_error($channels)) {
            wp_send_json_error($channels->get_error_message());
        }

        if (! is_array($channels)) {
            wp_send_json_error('Buffer API returned an unexpected response.');
        }

        $channel_ids = array();
        foreach ($channels as $ch) {
            if (!empty($ch['id'])) {
                $channel_ids[] = $ch['id'];
            }
        }
        // Update per-account channel IDs cache.
        update_option('mcqvs_buffer_account_' . $account_id . '_channel_ids', wp_json_encode($channel_ids), false);

        wp_send_json_success(array(
            'account_id' => $account_id,
            'channels'   => $channels,
            'message'    => sprintf('Found %d channels for account %s', count($channels), $account_id),
        ));
    }

    /**
     * AJAX: Test R2 connection.
     *
     * @since 1.0.0
     */
    public function ajax_test_r2()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $r2_storage = new VS_R2_Storage();
        $test_result = $r2_storage->test_connection();

        if (is_wp_error($test_result)) {
            wp_send_json_error($test_result->get_error_message());
        }

        wp_send_json_success('R2 endpoint is reachable, credentials valid, public domain correctly configured');
    }

    /**
     * AJAX: Run automation manually.
     *
     * @since 1.0.0
     */
    public function ajax_run_automation()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // Call the scheduler directly.
        $engine = VS_Automation_Engine::init();
        $engine->run_daily_scheduler();

        // Count pending + ready_for_render jobs (both are awaiting processing).
        $repo = VS_Job_Repository::init();
        $jobs = $repo->get_pending_jobs(10);
        $ready = $repo->get_jobs_by_status(VS_Job_Status::READY_FOR_RENDER, 50);
        $total = count($jobs) + count($ready);

        wp_send_json_success(array(
            'jobs_created' => $total,
            'jobs_pending' => count($jobs),
            'jobs_ready'   => count($ready),
            'message'      => sprintf('Queue now has %d jobs awaiting processing (%d pending, %d ready)', $total, count($jobs), count($ready)),
        ));
    }

    public function ajax_test_gemini()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        $registry = VS_Provider_Registry::get_instance();
        $result = $registry->test_connection('gemini');
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        wp_send_json_success($result);
    }

    public function ajax_test_custom_provider()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        if (empty($provider_id)) {
            wp_send_json_error('Provider ID is required');
        }
        $temp_name = sanitize_text_field($_POST['temp_name'] ?? '');
        $temp_url = esc_url_raw($_POST['temp_url'] ?? '');
        $temp_key = sanitize_text_field($_POST['temp_key'] ?? '');
        $temp_models_raw = $_POST['temp_models'] ?? '[]';
        if (is_string($temp_models_raw)) {
            $temp_models = json_decode(stripslashes($temp_models_raw), true);
        } else {
            $temp_models = array();
        }
        if (!is_array($temp_models)) {
            $temp_models = array();
        }

        $registry = VS_Provider_Registry::get_instance();

        if (!empty($temp_url) && !empty($temp_key)) {
            $temp_profile = array(
                'id'       => $provider_id,
                'name'     => $temp_name ?: 'Test',
                'api_url'  => $temp_url,
                'api_key'  => $temp_key,
                'models'   => $temp_models,
            );

            $existing = $registry->get_custom_providers();
            $found = false;
            foreach ($existing as $i => $p) {
                if (($p['id'] ?? '') === $provider_id) {
                    $existing[$i] = array_merge($p, $temp_profile);
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $existing[] = $registry->validate_custom_profile($temp_profile);
            }
            update_option('mcqvs_custom_providers', wp_json_encode($existing));
            $registry = VS_Provider_Registry::get_instance();
        }

        $result = $registry->test_connection($provider_id);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        wp_send_json_success($result);
    }

    public function ajax_save_custom_provider()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $profile_raw = $_POST['profile'] ?? '{}';
        if (is_string($profile_raw)) {
            $profile = json_decode(stripslashes($profile_raw), true);
        } else {
            $profile = array();
        }
        if (!is_array($profile)) {
            wp_send_json_error('Invalid profile data');
        }

        $registry = VS_Provider_Registry::get_instance();
        $existing = $registry->get_custom_providers();

        $sanitized = $registry->validate_custom_profile($profile);
        if (empty($sanitized['id'])) {
            wp_send_json_error('Provider ID is required');
        }

        $found = false;
        foreach ($existing as $i => $p) {
            if (($p['id'] ?? '') === $sanitized['id']) {
                $existing[$i] = $sanitized;
                $found = true;
                break;
            }
        }
        if (!$found) {
            $existing[] = $sanitized;
        }

        $registry->save_custom_providers($existing);

        wp_send_json_success(array(
            'id'   => $sanitized['id'],
            'name' => $sanitized['name'],
            'message' => sprintf('Provider "%s" saved.', $sanitized['name']),
        ));
    }

    public function ajax_delete_custom_provider()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        if (empty($provider_id)) {
            wp_send_json_error('Provider ID is required');
        }

        $registry = VS_Provider_Registry::get_instance();
        $existing = $registry->get_custom_providers();
        $filtered = array();
        foreach ($existing as $p) {
            if (($p['id'] ?? '') !== $provider_id) {
                $filtered[] = $p;
            }
        }
        $registry->save_custom_providers($filtered);

        if (get_option('mcqvs_api_provider', '') === $provider_id) {
            update_option('mcqvs_api_provider', 'gemini');
        }

        wp_send_json_success(array('message' => 'Provider deleted.'));
    }

    public function ajax_get_custom_providers()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        $registry = VS_Provider_Registry::get_instance();
        wp_send_json_success(array(
            'providers' => $registry->get_custom_providers(),
            'all_ids'   => $registry->get_all_ids(),
        ));
    }

    /**
     * Render Logs tab.
     *
     * Storage moved from transient (1 hour) to wp_vs_logs table.
     * @FIX 1.4.9.45 (data-loss): Data & Privacy tab — control whether plugin data
     * survives uninstall/update, and restore the auto safety backup.
     *
     * @return void
     */
    private function render_data_tab()
    {
        $purge = (bool) get_option('mcqvs_purge_data_on_uninstall', false);
        $backup_raw = get_option('mcqvs_safety_backup', '');
        $backup_info = '';
        if (!empty($backup_raw)) {
            $b = json_decode((string) $backup_raw, true);
            if (is_array($b)) {
                $backup_info = sprintf(
                    __('Backup taken %s (from plugin version %s).', 'mcq-video-studio'),
                    esc_html((string) ($b['time'] ?? 'unknown')),
                    esc_html((string) ($b['version'] ?? 'unknown'))
                );
            }
        }
        ?>
        <h2><?php esc_html_e('Data & Privacy', 'mcq-video-studio'); ?></h2>

        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mcqvs_purge_data_on_uninstall"><?php esc_html_e('Delete all plugin data on uninstall', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <label>
                        <input type="checkbox" name="mcqvs_purge_data_on_uninstall" id="mcqvs_purge_data_on_uninstall" value="1" <?php checked($purge, true); ?> />
                        <?php esc_html_e('Delete everything when the plugin is removed (uninstalled).', 'mcq-video-studio'); ?>
                    </label>
                    <p class="description">
                        <strong><?php esc_html_e('Default: KEEP (recommended).', 'mcq-video-studio'); ?></strong>
                        <?php esc_html_e('When unchecked, deactivating or updating the plugin keeps all data: Content Planner topics, batch tracker, generated questions (MCQ bank), jobs, Artifact Cleanup retention settings, API keys, Buffer accounts, and render uploads.', 'mcq-video-studio'); ?>
                        <?php esc_html_e('When checked, a permanent uninstall deletes all plugin tables, options and uploads.', 'mcq-video-studio'); ?>
                    </p>
                    <p class="description">
                        <?php esc_html_e('Note: the ZIP-update flow (deactivate → delete folder → upload) runs the uninstall routine, so keeping this off is exactly what protects your data across updates.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Safety Backup', 'mcq-video-studio'); ?></th>
                <td>
                    <button type="button" id="mcqvs-restore-backup-data" class="button button-secondary">
                        <?php esc_html_e('Restore Safety Backup', 'mcq-video-studio'); ?>
                    </button>
                    <?php if (!empty($backup_info)) : ?>
                        <p class="description"><?php echo $backup_info; ?></p>
                    <?php else : ?>
                        <p class="description"><?php esc_html_e('No backup yet — one is taken automatically on every plugin activation/update.', 'mcq-video-studio'); ?></p>
                    <?php endif; ?>
                    <p class="description">
                        <?php esc_html_e('Refills missing values (Content Planner, batch tracker, batches, retention settings, API keys) from the last auto-backup. Never overwrites existing data.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * This tab lets the admin choose how long to keep logs, how many
     * rows are visible by default on the dedicated Logs page, and
     * the absolute cap on stored rows.
     *
     * @return void
     */
    private function render_logs_tab()
    {
        $retention    = (int) get_option('mcqvs_log_retention_days', 7);
        $visible      = (int) get_option('mcqvs_log_visible_count', 25);
        $max_total    = (int) get_option('mcqvs_log_max_total', 5000);
        $logger       = VS_Error_Logger::get_instance();
        $stats        = $logger->get_stats();
        $has_table    = $logger->table_exists();
        $count_string = $has_table
            ? sprintf('%s total / %s within retention window', number_format_i18n($stats['total']), number_format_i18n($stats['within_retention']))
            : __('Storage table not created yet.', 'mcq-video-studio');
        ?>
        <table class="form-table" role="presentation">
            <tr>
                <th scope="row">
                    <label for="mcqvs_log_retention_days"><?php esc_html_e('Log Retention (days)', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="number" min="1" max="30" step="1"
                           name="mcqvs_log_retention_days" id="mcqvs_log_retention_days"
                           value="<?php echo esc_attr($retention); ?>" class="small-text" />
                    <p class="description">
                        <?php esc_html_e('Number of days to keep error, warning, info and API logs. Allowed range: 1-30 days. Old logs are pruned automatically by a daily WP-Cron job.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_log_visible_count"><?php esc_html_e('Default visible logs', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <select name="mcqvs_log_visible_count" id="mcqvs_log_visible_count">
                        <?php foreach (array(5, 10, 25, 50, 100, 250, 500) as $opt) : ?>
                            <option value="<?php echo esc_attr($opt); ?>" <?php selected($visible, $opt); ?>><?php echo esc_html($opt); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">
                        <?php esc_html_e('How many entries the dedicated Logs page shows by default. The page also exposes a "Show all within retention" toggle and per-row details.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_log_max_total"><?php esc_html_e('Maximum stored logs', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="number" min="500" max="50000" step="100"
                           name="mcqvs_log_max_total" id="mcqvs_log_max_total"
                           value="<?php echo esc_attr($max_total); ?>" class="small-text" />
                    <p class="description">
                        <?php esc_html_e('Hard cap on total log rows. The DB pruner trims the oldest rows to keep the table lean (500 - 50,000).', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Storage', 'mcq-video-studio'); ?></th>
                <td>
                    <code>wp_vs_logs</code>
                    <span class="description"> &mdash; <?php esc_html_e('persistent DB table; replaced the old 1 hour transient.', 'mcq-video-studio'); ?></span>
                    <p class="description" style="margin-top:6px;">
                        <?php echo esc_html($count_string); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Open Logs page', 'mcq-video-studio'); ?></th>
                <td>
                    <a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=mcqvs-logs')); ?>">
                        <?php esc_html_e('Open Logs page', 'mcq-video-studio'); ?>
                    </a>
                </td>
            </tr>
        </table>
        <?php
    }

    private function render_headless_tab()
    {
        $enabled = get_option('mcqvs_headless_rendering_enabled', false);
        $node_path = get_option('mcqvs_node_path', '/usr/bin/node');
        $ffmpeg_path = get_option('mcqvs_ffmpeg_path', '');
        $timeout = get_option('mcqvs_render_timeout', 180);
        $concurrency = get_option('mcqvs_render_concurrency', 1);
        // @FIX F1: Wrap the Headless tab in a real Settings-API form that targets
        //         options.php so the values (including the master enable checkbox)
        //         actually persist instead of disappearing on reload.
        ?>
        <table class="form-table">
        <tr>
                <th scope="row"><?php esc_html_e('Enable Headless Rendering', 'mcq-video-studio'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="mcqvs_headless_rendering_enabled" value="1" <?php checked($enabled === true || $enabled === 1 || $enabled === '1'); ?> />
                    <?php esc_html_e('Enable autonomous server-side video rendering via Node.js (browser-free)', 'mcq-video-studio'); ?>
                </label>
                    <p class="description">
                    <strong>How it works:</strong> A WP-Cron / Action Scheduler tick (<code>vs_headless_render_cron</code>, every 5 min) picks up <code>ready_for_render</code> jobs and PHP spawns a background <code>node render-service/render-node.js --payload=&lt;json&gt;</code> process. The renderer reuses the plugin's Canvas2D drawing modules under a DOM shim, draws frames with <strong>node-canvas</strong> (no Chrome, Chromium, Puppeteer or Playwright) and pipes raw RGBA into <strong>FFmpeg</strong> (libx264) to produce the MP4. Background music + SFX are mixed by FFmpeg; voiceover (if enabled) is generated by <strong>Microsoft Edge TTS</strong> over an outbound WebSocket (<code>wss://speech.platform.bing.com</code>, no API key). The whole pipeline runs on the same web host / VPS — there is no separate render node and no browser tab is required.
                </p>
                <p class="description" style="margin-top:8px;">
                    <strong>If rendering fails / jobs get stuck:</strong>
                    &nbsp;1) click <em>Test Headless Setup</em> below to see which dependency is missing;
                    &nbsp;2) if <code>node-canvas</code> is missing, run <code>cd render-service &amp;&amp; npm install --omit=dev</code>;
                    &nbsp;3) if FFmpeg is missing or lacks libx264, install it or set <em>FFmpeg Path</em>;
                    &nbsp;4) if voiceover fails, your host is likely blocking the Edge TTS WebSocket (firewall/outbound);
                    &nbsp;5) if jobs wedge in <code>rendering</code>, use the Dashboard &rarr; <em>Reset Stuck Pipeline</em> button to kill orphaned PIDs and re-queue them.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_node_path"><?php esc_html_e('Node.js Path', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="text" name="mcqvs_node_path" id="mcqvs_node_path"
                    value="<?php echo esc_attr($node_path); ?>" class="regular-text" placeholder="/usr/bin/node" />
                <p class="description">Full path to Node.js binary. Verify with <code>which node</code> on your VPS.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_ffmpeg_path"><?php esc_html_e('FFmpeg Path (optional)', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="text" name="mcqvs_ffmpeg_path" id="mcqvs_ffmpeg_path"
                    value="<?php echo esc_attr($ffmpeg_path); ?>" class="regular-text" placeholder="Auto-detect (leave blank)" />
                <p class="description">Full path to the FFmpeg binary used to encode the MP4. Leave blank to auto-detect (<code>/usr/bin/ffmpeg</code>, <code>which ffmpeg</code>). Requires <code>libx264</code>.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_render_timeout"><?php esc_html_e('Render Timeout (seconds)', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="number" name="mcqvs_render_timeout" id="mcqvs_render_timeout"
                    value="<?php echo esc_attr($timeout); ?>" min="60" max="600" class="small-text" />
                <p class="description">Maximum time to wait for a single video render (60-600s). Default: 180.</p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="mcqvs_render_concurrency"><?php esc_html_e('Concurrent Renders', 'mcq-video-studio'); ?></label>
            </th>
            <td>
                <input type="number" name="mcqvs_render_concurrency" id="mcqvs_render_concurrency"
                    value="<?php echo esc_attr($concurrency); ?>" min="1" max="4" class="small-text" />
                <p class="description">Number of videos to render simultaneously (1-4). Each uses ~500MB RAM. Default: 1.</p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Setup Status', 'mcq-video-studio'); ?></th>
            <td>
                <button type="button" id="mcqvs-test-headless" class="button button-secondary">
                    <?php esc_html_e('Test Headless Setup', 'mcq-video-studio'); ?>
                </button>
                <span id="mcqvs-headless-status" class="mcqvs-status"></span>
                <p class="description">
                    Checks Node.js, FFmpeg (libx264), node-canvas, and template fonts on your VPS. Edge TTS is reported as optional — only required when voiceover is enabled and the host can reach <code>wss://speech.platform.bing.com</code>.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Setup Server Environment', 'mcq-video-studio'); ?></th>
            <td>
                <button type="button" id="mcqvs-setup-env" class="button button-primary"><?php esc_html_e('One-Click Setup (no SSH needed)', 'mcq-video-studio'); ?></button>
                <span id="mcqvs-setup-env-status" class="mcqvs-status"></span>
                <p class="description">
                    <strong>Self-sufficient:</strong> this provisions everything the headless renderer needs,
                    straight from this page — <strong>Node.js</strong> (portable download if missing/too old),
                    <strong>canvas 3.x</strong> (prebuilt binary via npm) and a <strong>bundled static FFmpeg</strong>
                    (ffmpeg-static via npm). No SSH, no <code>setup-vps.sh</code>, no system packages, no compiling.
                    Re-runs automatically after every plugin update. When done, click "Test Headless Setup" above.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Artifact Cleanup Retention (days)', 'mcq-video-studio'); ?></th>
            <td>
                <?php
                $categories = array(
                    'tts'         => __('TTS MP3 cache', 'mcq-video-studio'),
                    'covers'      => __('Cover PNG cache', 'mcq-video-studio'),
                    'generated'   => __('Generated videos (local)', 'mcq-video-studio'),
                    'exports'     => __('Exported videos (batch)', 'mcq-video-studio'),
                    'batch'       => __('Batch frames (per-job)', 'mcq-video-studio'),
                    'render_temp' => __('PHP render temps (payload, status, log)', 'mcq-video-studio'),
                    'temp'        => __('Node render temps (mp4, wav, bgframes)', 'mcq-video-studio'),
                );
                ?>
                <fieldset>
                    <?php foreach ($categories as $key => $label) :
                        $val = (int) get_option('mcqvs_artifact_retention_' . $key, -1);
                        $display = $val < 0 ? '' : (string) $val;
                    ?>
                        <label style="display:inline-block;min-width:320px;margin-right:12px;margin-bottom:6px;">
                            <span style="display:inline-block;width:220px;"><?php echo esc_html($label); ?></span>
                            <input type="number" min="-1" max="365" step="1"
                                   name="mcqvs_artifact_retention_<?php echo esc_attr($key); ?>"
                                   id="mcqvs_artifact_retention_<?php echo esc_attr($key); ?>"
                                   value="<?php echo esc_attr($display); ?>"
                                   placeholder="<?php esc_attr_e('off', 'mcq-video-studio'); ?>"
                                   class="small-text" />
                            <span class="description"><?php esc_html_e('days (-1 = off)', 'mcq-video-studio'); ?></span>
                        </label>
                    <?php endforeach; ?>
                </fieldset>
                <p class="description">
                    <?php esc_html_e('Days to keep each category of generated/temporary file. Empty or -1 disables pruning for that category (default). Old files are removed by the daily "mcqvs_daily_artifact_prune" cron.', 'mcq-video-studio'); ?>
                </p>
                <p>
                    <label>
                        <input type="checkbox" name="mcqvs_artifact_retention_dry_run" value="1" <?php checked((int) get_option('mcqvs_artifact_retention_dry_run', 0), 1); ?> />
                        <?php esc_html_e('Dry run (count matches, log stats, do not delete)', 'mcq-video-studio'); ?>
                    </label>
                </p>
                <p>
                    <button type="button" class="button" id="mcqvs-run-artifact-cleanup">
                        <?php esc_html_e('Run cleanup now', 'mcq-video-studio'); ?>
                    </button>
                    <span id="mcqvs-artifact-cleanup-result" class="description" style="margin-left:8px;"></span>
                </p>
            </td>
        </tr>
        </table>
        <?php
    }

    /**
     * Render External Assets tab.
     * @NEW 2026-07-03: Allow hosting heavy assets (audio, fonts, bg videos) externally.
     */
    private function render_assets_tab()
    {
        $assets_url = get_option('mcqvs_external_assets_url', '');
        $assets_path = get_option('mcqvs_external_assets_path', '');
        $current_url = mcqvs_assets_url();
        $current_dir = mcqvs_assets_dir();
        $branding = get_option('MCQVS_studio_branding', array());
        $logo_url = isset($branding['logo_url']) ? esc_url($branding['logo_url']) : '';
        $logo_pos = isset($branding['logo_pos']) ? sanitize_text_field($branding['logo_pos']) : 'all';
        $logo_pos_norm = in_array($logo_pos, array('corner', 'outro', 'all'), true) ? $logo_pos : 'all';
        ?>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mcqvs_external_assets_url"><?php esc_html_e('External Assets URL', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="url" name="mcqvs_external_assets_url" id="mcqvs_external_assets_url"
                        value="<?php echo esc_attr($assets_url); ?>" class="regular-text" placeholder="https://yourdomain.com/wp-content/Assests-for-MCQ-Video-Plugin/" />
                    <p class="description">
                        <?php esc_html_e('Full URL to a folder containing audio/, fonts/, and bg-videos/ subfolders. Leave empty to use the built-in plugin assets.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mcqvs_external_assets_path"><?php esc_html_e('External Assets Path', 'mcq-video-studio'); ?></label>
                </th>
                <td>
                    <input type="text" name="mcqvs_external_assets_path" id="mcqvs_external_assets_path"
                        value="<?php echo esc_attr($assets_path); ?>" class="regular-text code" placeholder="/path/to/wp-content/Assests for MCQ Video Plugin/" />
                    <p class="description">
                        <?php esc_html_e('Server filesystem path to the same folder (needed for PHP directory scans). Example: /var/www/html/wp-content/Assests for MCQ Video Plugin/', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Current Resolution', 'mcq-video-studio'); ?></th>
                <td>
                    <p><strong><?php esc_html_e('Assets URL:', 'mcq-video-studio'); ?></strong> <code><?php echo esc_html($current_url); ?></code></p>
                    <p><strong><?php esc_html_e('Assets Path:', 'mcq-video-studio'); ?></strong> <code><?php echo esc_html($current_dir); ?></code></p>
                    <p class="description">
                        <?php esc_html_e('If external URL/path is set above, these show the resolved values. Otherwise default plugin paths are used.', 'mcq-video-studio'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <?php esc_html_e('Branding Logo', 'mcq-video-studio'); ?>
                </th>
                <td>
                    <div class="mcqvs-logo-uploader">
                        <div class="mcqvs-logo-preview-wrap">
                            <img id="mcqvs-logo-preview" src="<?php echo $logo_url; ?>" alt=""
                                style="<?php echo $logo_url ? 'display:block;' : 'display:none;'; ?>max-width:220px;max-height:90px;object-fit:contain;border:1px solid #dcdcde;border-radius:4px;padding:8px;background-color:#fff;background-image:linear-gradient(45deg,#e0e0e0 25%,transparent 25%,transparent 75%,#e0e0e0 75%,#e0e0e0),linear-gradient(45deg,#e0e0e0 25%,transparent 25%,transparent 75%,#e0e0e0 75%,#e0e0e0);background-size:10px 10px;background-position:0 0,5px 5px;box-shadow:0 1px 2px rgba(0,0,0,.05);" />
                            <p class="description" id="mcqvs-logo-preview-empty" style="<?php echo $logo_url ? 'display:none;' : ''; ?>">
                                <?php esc_html_e('No logo uploaded. Select an image from the Media Library.', 'mcq-video-studio'); ?>
                            </p>
                        </div>
                        <p>
                            <button type="button" class="button" id="mcqvs-logo-select"><?php esc_html_e('Select Logo', 'mcq-video-studio'); ?></button>
                            <button type="button" class="button" id="mcqvs-logo-remove" style="<?php echo $logo_url ? '' : 'display:none;'; ?>"><?php esc_html_e('Remove Logo', 'mcq-video-studio'); ?></button>
                            <span class="spinner" id="mcqvs-logo-spinner" style="float:none;margin:0 0 0 8px;"></span>
                            <span class="mcqvs-logo-status" id="mcqvs-logo-status"></span>
                        </p>
                        <p>
                            <label for="mcqvs-logo-position"><strong><?php esc_html_e('Logo Position', 'mcq-video-studio'); ?></strong></label>
                            <select id="mcqvs-logo-position">
                                <option value="all" <?php selected($logo_pos_norm, 'all'); ?>><?php esc_html_e('All scenes (corner + outro)', 'mcq-video-studio'); ?></option>
                                <option value="corner" <?php selected($logo_pos_norm, 'corner'); ?>><?php esc_html_e('Corner only', 'mcq-video-studio'); ?></option>
                                <option value="outro" <?php selected($logo_pos_norm, 'outro'); ?>><?php esc_html_e('Outro only', 'mcq-video-studio'); ?></option>
                            </select>
                            <span class="spinner" id="mcqvs-logo-pos-spinner" style="float:none;margin:0 0 0 8px;"></span>
                            <span class="mcqvs-logo-pos-status" id="mcqvs-logo-pos-status"></span>
                        </p>
                        <p class="description">
                            <?php esc_html_e('The logo is copied into the plugin assets folder (assets/images/brand-logo.png) so headless rendering reads it from local disk instead of downloading it for every render. It is shared with the Studio editor and Content Planner automatically.', 'mcq-video-studio'); ?>
                        </p>
                    </div>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Emit every mcqvs_* Settings API option as a hidden input EXCEPT the keys natively
     * rendered by the current tab. Prevents cross-tab data loss on the global Settings form.
     *
     * @param string[] $skip Keys to skip because the active tab renders them as visible controls.
     */
    private function render_global_hidden_settings_except(array $skip = array())
    {
        // Canonical list mirrors every register_setting() call above. Keep in sync.
        // @FIX 2026-08-08: mcqvs_buffer_accounts is intentionally OMITTED below. It is
        // managed exclusively by AJAX (add/save/delete/set-default). Emitting it as a
        // hidden input would snapshot the value at page load and let a later "Save
        // Changes" on this form silently overwrite (revert/wipe) any account edited
        // after page load. Absent from the POST, the Settings API leaves it untouched.
        $all_keys = array(
            // Buffer
            'mcqvs_buffer_access_token',
            'mcqvs_buffer_channels',
            'mcqvs_buffer_enabled_channels',
            'mcqvs_buffer_channel_types',
            'mcqvs_buffer_channel_link_posts',
            'mcqvs_buffer_scheduling_mode',
            'mcqvs_buffer_daily_limit',
            'mcqvs_buffer_caption_template',
            // @NEW 2026-08-10: Per-channel legacy defaults. Multi-account installs
            // persist these in mcqvs_buffer_accounts instead, but the legacy
            // default-account path still reads them here, so whitelist them.
            'mcqvs_buffer_channel_captions',
            'mcqvs_buffer_channel_post_to_story',
            // R2
            'mcqvs_r2_endpoint',
            'mcqvs_r2_access_key',
            'mcqvs_r2_secret_key',
            'mcqvs_r2_bucket',
            'mcqvs_r2_public_domain',
            'mcqvs_delivery_mode',
            // Automation / Schedule
            'mcqvs_automation_enabled',
            'mcqvs_automation_count',
            'mcqvs_ai_batch_size',
            'mcqvs_auto_publish_enabled',
            'mcqvs_default_publish_time',
            'mcqvs_publish_time_window_start',
            'mcqvs_publish_time_window_end',
            'mcqvs_publish_timezone',
            'mcqvs_publish_frequency',
            'mcqvs_video_format',
            // API
            'mcqvs_gemini_api_key',
            'mcqvs_gemini_model_id',
            'mcqvs_gemini_custom_models',
            'mcqvs_api_provider',
            'mcqvs_custom_providers',
            'mcqvs_tts_provider',
            'mcqvs_tts_default_voice',
            'mcqvs_tts_voice_rotation_enabled',
            'mcqvs_tts_voice_rotation_list',
            'mcqvs_tts_voice_rotation_index',
            'mcqvs_tts_speak_options',
            'mcqvs_tts_enabled',
            'mcqvs_tts_rate',
            'mcqvs_tts_speak_hook',
            'mcqvs_tts_speak_answer',
            'mcqvs_tts_speak_cta',
            'mcqvs_show_explanation',
            'mcqvs_strip_emoji_on_screen',
            'mcqvs_pexels_api_key',
            'mcqvs_provider_failure_cooldown',
            // Headless
            'mcqvs_headless_rendering_enabled',
            'mcqvs_node_path',
            'mcqvs_ffmpeg_path',
            'mcqvs_render_timeout',
            'mcqvs_render_concurrency',
            // Assets
            'mcqvs_external_assets_url',
            'mcqvs_external_assets_path',
            // Data & Privacy
            'mcqvs_purge_data_on_uninstall',
        );

        $skip_map = array_flip($skip);
        foreach ($all_keys as $key) {
            if (isset($skip_map[$key])) {
                continue;
            }

            // Boolean checkboxes: re-emit current stored scalar so the value persists
            // when the checkbox lives on a different tab.
            $checkbox_keys = array(
                'mcqvs_automation_enabled',
                'mcqvs_headless_rendering_enabled',
                'mcqvs_auto_publish_enabled',
                'mcqvs_tts_voice_rotation_enabled',
            );
            if (in_array($key, $checkbox_keys, true)) {
                $cur = get_option($key, false);
                echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($cur ? '1' : '0') . '" />';
                continue;
            }

            $val = get_option($key, '');
            if (is_array($val) || is_object($val)) {
                $val = wp_json_encode($val);
            }
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr((string) $val) . '" />';
        }
    }

    /**
     * Return the list of mcqvs_* keys natively rendered by the given active tab.
     * Tabs MUST list every key they render so the global hidden emitter doesn't double-up.
     *
     * @param string $active_tab One of: api, schedule, buffer, r2, migration, health, headless, assets.
     * @return string[]
     */
    private function keys_native_to_tab($active_tab)
    {
        switch ($active_tab) {
            case 'api':
                return array(
                    'mcqvs_gemini_api_key',
                    'mcqvs_gemini_model_id',
                    'mcqvs_gemini_custom_models',
                    'mcqvs_api_provider',
                    'mcqvs_custom_providers',
                    'mcqvs_provider_failure_cooldown',
                    'mcqvs_tts_provider',
                    'mcqvs_tts_default_voice',
                    'mcqvs_tts_voice_rotation_enabled',
                    'mcqvs_tts_voice_rotation_list',
                    'mcqvs_tts_voice_rotation_index',
                    'mcqvs_tts_speak_options',
                    'mcqvs_tts_enabled',
                    'mcqvs_tts_rate',
                    'mcqvs_tts_speak_hook',
                    'mcqvs_tts_speak_answer',
                    'mcqvs_tts_speak_cta',
                );
            case 'schedule':
            case 'automation':
                return array(
                    'mcqvs_automation_enabled',
                    'mcqvs_automation_count',
                    'mcqvs_ai_batch_size',
                );
            case 'buffer':
                return array(
                    'mcqvs_auto_publish_enabled',
                    'mcqvs_default_publish_time',
                    'mcqvs_publish_time_window_start',
                    'mcqvs_publish_time_window_end',
                    'mcqvs_publish_timezone',
                    'mcqvs_publish_frequency',
                    'mcqvs_show_explanation',
                    'mcqvs_strip_emoji_on_screen',
                );
            case 'r2':
                return array(
                    'mcqvs_r2_endpoint',
                    'mcqvs_r2_access_key',
                    'mcqvs_r2_secret_key',
                    'mcqvs_r2_bucket',
                    'mcqvs_r2_public_domain',
                    'mcqvs_delivery_mode',
                );
            case 'headless':
                return array(
                    'mcqvs_headless_rendering_enabled',
                    'mcqvs_node_path',
                    'mcqvs_ffmpeg_path',
                    'mcqvs_render_timeout',
                    'mcqvs_render_concurrency',
                );
            case 'assets':
                return array(
                    'mcqvs_external_assets_url',
                    'mcqvs_external_assets_path',
                );
            case 'logs':
                return array(
                    'mcqvs_log_retention_days',
                    'mcqvs_log_visible_count',
                    'mcqvs_log_max_total',
                );
            case 'data':
                return array(
                    'mcqvs_purge_data_on_uninstall',
                );
            default:
                // Migration / health render no Settings-API keys.
                return array();
        }
    }
}
