<?php
namespace SEO_Article_Generator\Publishing;

use SEO_Article_Generator\Discovery\Post_Type_Classifier;
use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Services\Schema_Sync_Service;
use SEO_Article_Generator\Generator\Surgical_Patcher;
use SEO_Article_Generator\Discovery\Title_Analyzer;
use SEO_Article_Generator\Validation\Post_Content_Integrity_Guard;

if (!defined('ABSPATH')) {
    exit;
}

final class Publish_Payload_Builder
{
    public static function build(array $preview, int $post_id = 0): array
    {
        if (empty($preview['article']) || !is_array($preview['article'])) {
            throw new \RuntimeException('Publish_Payload_Builder requires preview.article array.');
        }

        $article            = self::canonicalize_article_contract($preview['article']);
        $preview['article'] = $article;

    $title = isset($article['title']) ? (string) $article['title'] : '';
    $content = isset($article['html_content']) ? (string) $article['html_content'] : '';

    $post_type = ($post_id > 0) ? Post_Type_Classifier::classify($post_id) : Post_Type_Classifier::TYPE_NEW;

    $is_update_contract = (
        $post_id > 0 && (
            $post_type === Post_Type_Classifier::TYPE_PLUGIN ||
            $post_type === Post_Type_Classifier::TYPE_PLUGIN_LEGACY ||
            $post_type === Post_Type_Classifier::TYPE_LEGACY
        )
    );

if (! $is_update_contract) {
	$_focus_keyword = trim((string) ($article['focus_keyword'] ?? $article['focuskeyword'] ?? ''));
	$_meta_description = trim((string) ($article['meta_description'] ?? $article['metadescription'] ?? ''));

	if ($_focus_keyword === '' && $post_id > 0) {
		$_existing_fk = trim((string) \get_post_meta($post_id, 'rank_math_focus_keyword', true));
		if ($_existing_fk !== '') {
			$_focus_keyword = $_existing_fk;
			$article['focus_keyword'] = $_existing_fk;
		}
	}

	// Fallback for new posts: derive focus_keyword from software_name or title
	if ($_focus_keyword === '' && $post_id === 0) {
		$_software_name = trim((string) ($article['tech_specs']['software_name'] ?? $article['software_name'] ?? $article['title'] ?? ''));
		if ($_software_name !== '') {
			$_focus_keyword = $_software_name;
			$article['focus_keyword'] = $_software_name;
		}
	}

	if ($_meta_description === '' && $post_id > 0) {
		$_existing_md = trim((string) \get_post_meta($post_id, 'rank_math_description', true));
		if ($_existing_md !== '') {
			$_meta_description = $_existing_md;
			$article['meta_description'] = $_existing_md;
		}
	}

	if ($_meta_description === '' && !empty($article['introduction'])) {
		$_intro_parts = is_array($article['introduction']) ? $article['introduction'] : array($article['introduction']);
		$_intro_text = trim(implode(' ', array_filter(array_map('wp_strip_all_tags', $_intro_parts))));
		if ($_intro_text !== '') {
			$_derived = mb_substr($_intro_text, 0, 158);
			$_last_space = mb_strrpos($_derived, ' ');
			if ($_last_space !== false && $_last_space > 80) {
				$_derived = mb_substr($_derived, 0, $_last_space);
			}
			$_meta_description = class_exists('\\SEO_Article_Generator\\Generator\\Response_Normalizer')
				? \SEO_Article_Generator\Generator\Response_Normalizer::strip_markdown(trim($_derived))
				: trim($_derived);
			$article['meta_description'] = $_meta_description;
			$preview['article']['meta_description'] = $_meta_description;
		}
	}
	// Fallback 2: title + software_name + version (for new posts when AI omits meta_description and introduction)
	if ($_meta_description === '' && (! empty($article['title']) || ! empty($article['tech_specs']['software_name']))) {
		$sw  = $article['tech_specs']['software_name'] ?? $article['software_name'] ?? '';
		$ver = $article['tech_specs']['version'] ?? $article['version'] ?? '';
		$_meta_description = sprintf('Download %s %s', $sw, $ver);
		$article['meta_description'] = $_meta_description;
		$preview['article']['meta_description'] = $_meta_description;
	}

	$_missing = array();

	if (trim($title) === '') {
		$_missing[] = 'title';
	}
	if ($_focus_keyword === '') {
		$_missing[] = 'focus_keyword';
	}
	if ($_meta_description === '') {
		$_missing[] = 'meta_description';
	}

	if (!empty($_missing)) {
		throw new \RuntimeException(
			'new_post_seo_contract_incomplete: Missing required SEO fields for new post: '
			. implode(', ', $_missing)
			. '. Job will retry.'
		);
	}
}

    $heading_map = isset($article['_seo_gen_heading_map']) && is_array($article['_seo_gen_heading_map'])
        ? $article['_seo_gen_heading_map']
        : (isset($article['seogenheadingmap']) && is_array($article['seogenheadingmap'])
            ? $article['seogenheadingmap']
            : array());

    if (! $is_update_contract) {
        $preview['article']['title'] = $title;
        $preview['article']['html_content'] = $content;

        $payload = [
            'title' => $title,
            'content' => $content,
            'preview' => $preview,
        ];

        $payload['meta_input'] = self::buildHeroMetaInput($article, $post_id);

        if (class_exists('\\SEO_Article_Generator\\EEAT\\Article_Attribution_Metabox')) {
            $eeat_meta = \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::buildGeneratedMetaInput($article, $post_id);
            if (isset($eeat_meta['seogenherodata'], $payload['meta_input']['seogenherodata'])) {
                $payload['meta_input']['seogenherodata'] = array_merge(
                    $payload['meta_input']['seogenherodata'],
                    $eeat_meta['seogenherodata']
                );
                unset($eeat_meta['seogenherodata']);
            }
            $payload['meta_input'] = array_merge($payload['meta_input'], $eeat_meta);
        }

        return $payload;
    }

    // Both TYPE_PLUGIN and TYPE_PLUGIN_LEGACY reach here.
        $existing_post = get_post($post_id);
        if (!$existing_post) {
            throw new \RuntimeException('Existing post not found for plugin update publish.');
        }

$snapshot_json = get_post_meta($post_id, '_seo_gen_regen_sections', true);
if ($snapshot_json === '' || $snapshot_json === null) {
    $snapshot_json = get_post_meta($post_id, 'seogenregensections', true);
}

$registry_defaults = \SEO_Article_Generator\Option_Registry::defaults();
$default_regen_sections = Article_Schema::normalize_sections(
    (array) \get_option(
        \SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS,
        $registry_defaults[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS]
    ),
    $registry_defaults[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS]
);

        if (is_array($snapshot_json)) {
            $regen_sections = $snapshot_json;
        } elseif (is_string($snapshot_json) && $snapshot_json !== '') {
            $decoded = json_decode($snapshot_json, true);
            $regen_sections = is_array($decoded) ? $decoded : $default_regen_sections;
        } else {
            $regen_sections = $default_regen_sections;
        }

        $regen_sections = Article_Schema::normalize_sections($regen_sections, $default_regen_sections);

        if (empty($regen_sections)) {
            $regen_sections = $default_regen_sections;
        }

        // SIMPLE_UTILITY exclusion: mirror Article_Generator behavior.
        // The generator correctly skips faqs/moat for SIMPLE_UTILITY at
        // class-article-generator.php:1764, but PPB must also skip them
        // during publish-time validation to prevent
        // ai_schema_missing_requested_sections on every retry.
        if (!empty($article['software_type']) && $article['software_type'] === 'SIMPLE_UTILITY') {
            $regen_sections = array_values(array_diff($regen_sections, array('faqs', 'moat')));
        }

        $ai_schema = Article_Schema::from_array($article);

        // @MODIFIED 2026-07-28: Partial-success gate. Only `download` is
        // mandatory here — hero is handled separately via Hero_Data_Provider
        // (meta write, not HTML), so it is NOT validated at the HTML-publish
        // layer. All other requested sections are SOFT: if AI omitted them,
        // proceed and let merged_clone() (line 279) handle preservation
        // via the 'preserve_non_empty' merge strategy. The base schema's
        // existing content for soft-failed keys is preserved.
        $mandatory_ppb_sections = array('download');
        $missing_mandatory_ppb  = array();
        $missing_soft_ppb      = array();

        foreach ($regen_sections as $section) {
            $section = Article_Schema::get_canonical_key((string) $section) ?: (string) $section;
            $payload = $ai_schema->get_section_payload($section);
            $is_present = !empty($payload);

            if ($section === 'download') {
                $is_present = false;
                $download = is_array($payload) ? $payload : array();
                $links = (isset($download['links']) && is_array($download['links'])) ? $download['links'] : array();

                foreach ($links as $link) {
                    if (!is_array($link)) {
                        continue;
                    }

                    $url = isset($link['url']) ? (string) $link['url'] : '';
                    if ($url !== '' && !\SEO_Article_Generator\Generator\Download_Link_Helper::is_placeholder_url($url)) {
                        $is_present = true;
                        break;
                    }
                }
            } elseif ($section === 'introduction') {
                $intro = is_array($payload) ? $payload : array($payload);
                $is_present = strlen(trim(implode(' ', array_filter($intro)))) > 20;
            } elseif ($section === 'features') {
                $is_present = is_array($payload) && count($payload) >= 2;
            } elseif ($section === 'faqs') {
                $is_present = is_array($payload) && count($payload) >= 2;
            } elseif ($section === 'troubleshooting') {
                $is_present = is_array($payload) && !empty($payload);
            } elseif ($section === 'moat') {
                $is_present = false;

                if (is_string($payload)) {
                    $is_present = strlen(trim(wp_strip_all_tags($payload))) > 40;
                } else {
                    $moat = is_array($payload) ? $payload : array();

                    if (!empty($moat['body']) && is_string($moat['body'])) {
                        $is_present = strlen(trim(wp_strip_all_tags($moat['body']))) > 40;
                    }

                    if (!$is_present) {
                        $content = array();

                        if (isset($moat['content']) && is_array($moat['content'])) {
                            $content = $moat['content'];
                        } elseif (isset($moat[0])) {
                            $content = $moat;
                        }

                        foreach ($content as $entry) {
                            if (is_string($entry)) {
                                if (strlen(trim(wp_strip_all_tags($entry))) > 40) {
                                    $is_present = true;
                                    break;
}

continue;
                            }

                            if (!is_array($entry)) {
                                continue;
                            }

                            $heading = trim((string) ($entry['heading'] ?? ''));
                            $body    = trim((string) ($entry['body'] ?? ''));
                            $recipe  = trim((string) ($entry['recipe'] ?? ''));
                            $why     = trim((string) ($entry['why'] ?? ''));

                            $substantive = $body !== '' ? $body : trim($recipe . ' ' . $why);

                            if ($heading !== '' && strlen(wp_strip_all_tags($substantive)) > 20) {
                                $is_present = true;
                                break;
                            }

                            if ($heading === '' && strlen(wp_strip_all_tags($substantive)) > 40) {
                                $is_present = true;
                                break;
                            }
                        }
                    }
                }
            }

            if (!$is_present) {
                // @MODIFIED 2026-07-28: Partition into mandatory vs soft-fail
                // to match generator gate (class-article-generator.php L1829).
                // Only `download` is mandatory here — hero is meta-written.
                // Soft-fail sections are preserved by merged_clone() via
                // 'preserve_non_empty' merge strategy (line 279).
                if (in_array($section, $mandatory_ppb_sections, true)) {
                    $missing_mandatory_ppb[] = $section;
                } else {
                    $missing_soft_ppb[] = $section;
                }
            }
        }

        $missing_mandatory_ppb = array_values(array_unique($missing_mandatory_ppb));
        $missing_soft_ppb     = array_values(array_unique($missing_soft_ppb));

        if (!empty($missing_mandatory_ppb)) {
            throw new \RuntimeException(
                'ai_schema_missing_requested_sections: ' . implode(', ', $missing_mandatory_ppb)
            );
        }

        $effective_schema = $ai_schema;

        if (Schema_Sync_Service::has_schema($post_id)) {
            $existing_schema  = Schema_Sync_Service::load_schema($post_id);
            $effective_schema = Article_Schema::merged_clone($existing_schema, $ai_schema, $regen_sections);
        }

        $effective_article = self::canonicalize_article_contract($effective_schema->to_array());

        // @MODIFIED 2026-07-19: Re-enforce version SSOT on the MERGED effective article.
        // Article_Schema::merged_clone() (line 279) preserves non-regen sections
        // (meta_description, hero_section, introduction, whats_new) from the OLD stored
        // schema. The generate-time SSOT (class-article-generator.php:1255) only corrected
        // the AI-fresh values, which merged_clone then discards — so the persisted hero
        // meta and meta_description kept the previous version (e.g. VSO Downloader hero
        // 6.3.0.154 / meta 6.2.0.151 while the title was already canonical 6.4.0.157).
        // Re-apply the canonical version here, sourced from the AI schema's tech_specs
        // (already forced canonical by the generate-time SSOT), so every surface written
        // downstream (buildHeroMetaInput, write_post_meta, save_schema) is consistent.
        // [SSOT-EXTRACT] Re-enforce version SSOT on the MERGED effective article
        // via the shared static helper (also consumed by the sentinel-absent
        // self-heal path in class-discovery-processor.php) so both finalization
        // routes keep tech_specs.version, hero_section.version, tech_specs.last_updated,
        // hero_section.last_updated, hero_section.last_verified_date, meta_description,
        // introduction[], whats_new[] and download_section.heading aligned to the
        // canonical input version and today's date. See class-publish-payload-builder.php
        // enforce_version_ssot() for the single source of truth of this behaviour.
        $ppb_canonical = '';
        if ( isset( $ai_schema ) && method_exists( $ai_schema, 'to_array' ) ) {
            $ai_arr = $ai_schema->to_array();
            if ( ! empty( $ai_arr['tech_specs']['version'] ) ) {
                $ppb_canonical = (string) $ai_arr['tech_specs']['version'];
            }
        }
        self::enforce_version_ssot( $effective_article, $ppb_canonical );

    $existing_content = (string) $existing_post->post_content;

    // Hero block comment normalization — one-shot migration for posts whose hero comment
    // was stored in a corrupted form.
    //
    // Two known corruption patterns:
    //   (A) Gutenberg JS auto-save adds a space: <!-- wp:seo-gen/hero / -->
    //       PHP parse_blocks() requires /--&gt; (no trailing space), so it falls back to
    //       freeform and the hero zone is permanently invisible to the parser.
    //   (B) Legacy wpautop or Classic-editor fallback wraps the comment in <p> tags:
    //       <p><!-- wp:seo-gen/hero / --></p>  or  <p><!-- wp:seo-gen/hero /--></p>
    //
    // Hero is in Surgical_Patcher::SELF_CLOSING_ZONES — it is never re-patched on update.
    // Without this normalization the corrupted form would persist forever.
    // The replacement runs only when the pattern is present, making this a no-op for clean posts.
    if ( strpos( $existing_content, '<!-- wp:seo-gen/hero' ) !== false ) {
        // Strip <p> wrapper (any whitespace variation), normalize closing slash.
        $existing_content = preg_replace(
            '~<p>\s*<!--\s+wp:seo-gen/hero\s*/?\s*-->\s*</p>~i',
            '<!-- wp:seo-gen/hero /-->',
            $existing_content
        );
        // Normalize bare space-slash variant: <!-- wp:seo-gen/hero / --> → <!-- wp:seo-gen/hero /-->
        $existing_content = preg_replace(
            '~<!--\s+wp:seo-gen/hero\s*/?\s*-->~i',
            '<!-- wp:seo-gen/hero /-->',
            $existing_content
        );
    }

    // TYPE_LEGACY full rewrite: posts have no sentinel structure to migrate/patch.
    // Use the fresh AI-generated HTML (which already has block sentinels) directly,
    // preserving the existing post's URL, ID, author, and publish date.
    if ( $post_type === Post_Type_Classifier::TYPE_LEGACY ) {
        $content = (string) ( $article['html_content'] ?? '' );
        if ( trim( $content ) === '' ) {
            throw new \RuntimeException(
                'TYPE_LEGACY_full_rewrite_empty_html: Post ' . $post_id
                . ' has no sentinel structure and html_content is empty. Cannot perform full rewrite.'
            );
        }
        $content = Article_Schema::canonicalize_hero_block_comment( $content );

        $integrity = Post_Content_Integrity_Guard::validate_for_publish( $content, [
            'mode' => 'update',
        ] );
        if ( empty( $integrity['ok'] ) ) {
            throw new \RuntimeException(
                'post_content_integrity_guard_failed: Post ' . $post_id
                . ' TYPE_LEGACY full rewrite failed validation. fatal_reasons='
                . implode( ',', (array) ( $integrity['fatal_reasons'] ?? [] ) )
                . '. Job will retry.'
            );
        }

        $title = self::resolve_plugin_update_title(
            (string) $existing_post->post_title,
            isset($effective_article['tech_specs']) && is_array($effective_article['tech_specs']) ? $effective_article['tech_specs'] : array(),
            isset($ai_schema->to_array()['title']) ? (string) $ai_schema->to_array()['title'] : ''
        );
        $effective_article['title'] = $title;
        $effective_article['html_content'] = $content;
        if (!empty($heading_map)) {
            $effective_article['_seo_gen_heading_map'] = $heading_map;
        }
        $preview['article'] = $effective_article;

        $payload = array(
            'title'   => $title,
            'content' => $content,
            'preview' => $preview,
        );
        $payload['meta_input'] = self::buildHeroMetaInput($effective_article, $post_id);
        if (class_exists('\\SEO_Article_Generator\\EEAT\\Article_Attribution_Metabox')) {
            $eeat_meta = \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::buildGeneratedMetaInput($effective_article, $post_id);
            if (isset($eeat_meta['seogenherodata'], $payload['meta_input']['seogenherodata'])) {
                $payload['meta_input']['seogenherodata'] = array_merge(
                    $payload['meta_input']['seogenherodata'],
                    $eeat_meta['seogenherodata']
                );
                unset($eeat_meta['seogenherodata']);
            }
            $payload['meta_input'] = array_merge($payload['meta_input'], $eeat_meta);
        }

        return $payload;
    }

    if ( $post_type === Post_Type_Classifier::TYPE_PLUGIN_LEGACY ) {

        if ( ! class_exists( '\\SEO_Article_Generator\\Tools\\Sentinel_Fallback_Utility' ) ) {
            throw new \RuntimeException(
                'legacy_update_post ' . $post_id
                . ' requires Sentinel_Fallback_Utility for migration but class not found.'
            );
        }

            // BUG-A FIX: Pass explicit context so the intent is clear and not dependent on default.
            // is_update = false: preserve any legacy cross_post_links markup already present in content.
            // Injection for new posts is now handled downstream by Discovery_Processor::injectInternalLinksIfEnabled()
            // after post creation. PPB operates on raw AI HTML only (see Finding 2 critical fix).
            $repair = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::repair_and_audit(
                $existing_content,
                [],
                [ 'is_update' => false ]
            );

            if ( ! empty( $repair['migration_attempted'] ) ) {
                // Upgrade was attempted (post had no block delimiters when repair_and_audit ran).
                if ( $repair['changed'] && empty( $repair['audit']['fatal_reasons'] ) ) {
                    // Migration succeeded. Validate in-memory only - do NOT persist early.
                    // Persistence is deferred to final publish flow.
                    $existing_content = (string) $repair['content'];

                    $repaired_format = \SEO_Article_Generator\Tools\Sentinel_Injector::detect_format( $existing_content );

                if ( $repaired_format !== 'block' || strpos( $existing_content, '<!-- wp:seo-gen/section ' ) === false ) {
                    throw new \RuntimeException(
                        'migration_failed_missing_block_delimiters: legacy update post ' . $post_id . ' sentinel migration did not produce canonical zone blocks.'
                    );
                }
                } else {
                    // Migration attempted but failed (no block delimiters produced, or fatal audit issues).
                    // Throw so the job retries. Discovery_Processor escalates to full rewrite on next attempt.
                    throw new \RuntimeException(
                        'migration_failed_missing_block_delimiters: legacy update post ' . $post_id
                        . '. Audit: ' . \json_encode( $repair['audit']['fatal_reasons'] ?? [] )
                        . '. Job should retry as full regeneration.'
                    );
                }
			} else {
				// BUG-B FIX: migration_attempted = false means the content already had block delimiters
				// when repair_and_audit() ran — another request (Sentinel_Injector or Discovery_Processor)
				// migrated the post between classify() and get_post() in this request.
				// $existing_content is already the migrated content (read from get_post() above).

				// FIXED: Verify content has actual block structure AND zone completeness before writing contract.
				$current_format = \SEO_Article_Generator\Tools\Sentinel_Injector::detect_format( $existing_content );

				if ( $current_format === 'block' && strpos( $existing_content, '<!-- wp:seo-gen/section ' ) !== false ) {
				// FIXED: Zone completeness check - verify the zones REQUESTED for
				// this update exist. Scope to $regen_sections (what the admin
				// actually enabled), NOT the entire SECTION_REGISTRY. A zone the
				// admin just enabled is legitimately absent and is ADDITIVELY
				// INSERTED by SurgicalPatcher below — it must NOT be treated as a
				// corrupt block-v1 contract that forces a destructive full rewrite.
				$check_zones  = ! empty( $regen_sections ) ? (array) $regen_sections : \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
				$zones_present = array_values( array_filter( $check_zones, static function ( $z ) use ( $existing_content ) {
					return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $existing_content, $z ) !== false;
				} ) );
				$missing_zones = array_values( array_diff( $check_zones, $zones_present ) );

				if ( ! empty( $missing_zones ) ) {
					// Not fatal: SurgicalPatcher injects these additively below.
					// Genuinely broken posts are still caught by the
					// needs_full_regen / not_found_detection_failed paths.
				}
				} else {
				}
				// No throw, no failure. Fall through to Surgical_Patcher with existing migrated content.
			}
		}

        $patched = Surgical_Patcher::patch(
            $existing_content,
            $effective_article,
            $regen_sections,
            $heading_map,
            $post_id
        );

        // FINDING-4 FIX: If SurgicalPatcher signals needs_full_regen, throw immediately.
        if (!empty($patched['needs_full_regen'])) {
            throw new \RuntimeException(
                'migration_failed_missing_block_delimiters: Post ' . $post_id
                . ' has no patchable sentinel structure. '
                . 'Content contract must be cleared for full regeneration on next retry.'
            );
        }

        if (!empty($patched['not_found_detection_failed'])) {
            // FIX: Always trigger full-regen for not_found_detection_failed cases.
            // These posts have zone detection failures that cannot be surgically patched,
            // regardless of whether they have some section sentinels or none.
            throw new \RuntimeException(
                'migration_failed_missing_block_delimiters: Post ' . $post_id
                . ' has zone detection failures that cannot be surgically patched. '
                . 'Content contract must be cleared for full regeneration on next retry.'
            );
        }

        if (!empty($patched['not_found_in_content'])) {
            throw new \RuntimeException(
                'surgical_patch_requested_zones_missing: Post ' . $post_id
                . ' is missing requested zones: '
                . implode(', ', $patched['not_found_in_content'])
                . '. Refusing partial publish to avoid unintended section drift.'
            );
        }

        if (!empty($patched['skipped'])) {
            throw new \RuntimeException(
                'surgical_patch_render_skipped: Post ' . $post_id
                . ' could not render requested zones: '
                . implode(', ', $patched['skipped'])
                . '. Refusing partial publish so unselected sections remain untouched.'
            );
        }

        $content = !empty($patched['content'])
            ? (string) $patched['content']
            : $existing_content;

        // Publish-boundary canonicalization: re-apply the hero block comment normalizer
        // one more time on whatever the surgical patcher produced. This is defense-in-depth
        // so any future content producer (admin tool, Jetpack update, manual rewrite, etc.)
        // that routes through this builder also writes the parser-safe hero form, even if
        // the producer forgot to call the helper itself.
        $content = Article_Schema::canonicalize_hero_block_comment( $content );

        // Pre-publish integrity gate: fail-fast if the content is structurally unsafe
        // (duplicate sentinels, duplicate IDs, cross-post link leaks on update). The
        // Post_Content_Integrity_Guard has been defined as the pre-publish validator since
        // v2.33.0 but was never wired in; this is the call site. A failure here causes
        // finalize_generated_post() to throw and the job to retry on the next tick.
        $integrity = Post_Content_Integrity_Guard::validate_for_publish( $content, [
            'mode' => $is_update_contract ? 'update' : 'new',
        ] );
        if ( empty( $integrity['ok'] ) ) {
            throw new \RuntimeException(
                'post_content_integrity_guard_failed: Post ' . $post_id
                . ' content failed pre-publish validation. fatal_reasons='
                . implode( ',', (array) ( $integrity['fatal_reasons'] ?? [] ) )
                . '. audit=' . \wp_json_encode( $integrity['audit'] ?? [] )
                . '. Job will retry.'
            );
        }

        $title = self::resolve_plugin_update_title(
            (string) $existing_post->post_title,
            isset($effective_article['tech_specs']) && is_array($effective_article['tech_specs']) ? $effective_article['tech_specs'] : array(),
            isset($ai_schema->to_array()['title']) ? (string) $ai_schema->to_array()['title'] : ''
        );

        $effective_article['title'] = $title;
        $effective_article['html_content'] = $content;

        if (!empty($heading_map)) {
            $effective_article['_seo_gen_heading_map'] = $heading_map;
        }

        $preview['article'] = $effective_article;

        $payload = array(
            'title'   => $title,
            'content' => $content,
            'preview' => $preview,
        );

        // 4) Use effective article for ALL metadata in update branch
        $payload['meta_input'] = self::buildHeroMetaInput($effective_article, $post_id);

        if (class_exists('\\SEO_Article_Generator\\EEAT\\Article_Attribution_Metabox')) {
            $eeat_meta = \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::buildGeneratedMetaInput($effective_article, $post_id);
            if (isset($eeat_meta['seogenherodata'], $payload['meta_input']['seogenherodata'])) {
                $payload['meta_input']['seogenherodata'] = array_merge(
                    $payload['meta_input']['seogenherodata'],
                    $eeat_meta['seogenherodata']
                );
                unset($eeat_meta['seogenherodata']);
            }
            $payload['meta_input'] = array_merge($payload['meta_input'], $eeat_meta);
        }

        return $payload;
    }

    /**
     * [SSOT-EXTRACT] Re-enforce the canonical version + today's date across every
     * version-bearing surface of an article contract.
     *
     * This is the single source of truth for the version SSOT behaviour previously
     * inlined in build() (lines 284-363). It is consumed by:
     *   - build()                        after merged_clone() (normal update path).
     *   - Discovery_Processor           sentinel-absent self-heal catch block
     *                                   (class-discovery-processor.php ~3192),
     *                                   BEFORE Content_Formatter::to_html() and
     *                                   buildHeroMetaInput() consume the article.
     *
     * The self-heal path historically bypassed build(), so its hero_section.version,
     * tech_specs.last_updated, hero_section.last_updated and meta_description
     * substring rewrites never ran — producing published posts whose Hero meta
     * version badge and "Last Updated" date lagged the canonical title/tech_specs.
     *
     * @param array  $article          Article contract (passed by reference; mutated).
     * @param string $forced_canonical Optional canonical version. When empty, the
     *                                 helper falls back to $article['tech_specs']['version'].
     *                                 Caller in build() sources it from the AI schema
     *                                 (already corrected by the generate-time SSOT).
     */
    public static function enforce_version_ssot( array &$article, string $forced_canonical = '' ): void
    {
        Version_SSOT::enforce($article, $forced_canonical);
    }

    /**
     * Build Hero Meta Input (seogenherodata)
     */
    public static function buildHeroMetaInput(array $article, int $post_id = 0): array
    {
        $article  = self::canonicalize_article_contract($article);
        $existing = array();

        if ($post_id > 0) {
            $existing = get_post_meta($post_id, 'seogenherodata', true);
            if (!is_array($existing)) {
                $existing = array();
            }
        }

        $hero      = is_array($article['hero_section'] ?? null) ? $article['hero_section'] : array();
        $techspecs = is_array($article['tech_specs'] ?? null) ? $article['tech_specs'] : array();
        $download  = is_array($article['download_section'] ?? null) ? $article['download_section'] : array();

	$links_in = is_array($download['links'] ?? null) ? $download['links'] : array();

	$hero_homepage = trim((string) ($techspecs['homepage'] ?? ''));

	$hero_non_download_patterns = array(
		'/what-is-dotnet/', '/whats-new/', '/overview',
		'/learn.microsoft.com', '/docs.microsoft.com',
		'/release-notes', '/blob/main/release-notes',
		'/en-us/apps/', '/en-us/learn/',
	);

	// DIAGNOSTIC: Log hero meta input links
	if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
		error_log( sprintf(
			'[PublishPayload] buildHeroMetaInput: links_in=%d | homepage=%s | post_id=%d',
			count( $links_in ), $hero_homepage, $post_id
		) );
	}

	$links = array();
	$dropped_non_download = 0;
	$dropped_normalize = 0;
	foreach ($links_in as $raw_link) {
		$link = self::normalize_download_link($raw_link, $hero_homepage);
		if ($link === null) {
			$dropped_normalize++;
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				$_url = is_array( $raw_link ) ? ( $raw_link['url'] ?? '' ) : (string) $raw_link;
				error_log( sprintf(
					'[PublishPayload]   DROPPED by normalize_download_link: url=%s | homepage=%s',
					$_url, $hero_homepage
				) );
			}
			continue;
		}
		$hero_link_url_lower = strtolower(trim((string) ($link['url'] ?? '')));
            $is_non_download = false;
            foreach ($hero_non_download_patterns as $pattern) {
                if (strpos($hero_link_url_lower, $pattern) !== false) {
                    $is_non_download = true;
                    break;
                }
            }
            if ($is_non_download && count($links) > 0) {
                $dropped_non_download++;
                if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
                    error_log( sprintf(
                        '[PublishPayload]   DROPPED non-download pattern: url=%s | pattern matched',
                        $link['url'] ?? ''
                    ) );
                }
                continue;
            }

		$links[] = array(
			'platform' => $link['platform'],
			'url' => $link['url'],
			'variant' => $link['variant'],
			'file_type' => $link['file_type'] ?? '',
			'version' => $link['version'] ?? '',
			'channel' => $link['channel'] ?? '',
			'text' => $link['text'] ?? '',
			'is_primary' => !empty($link['is_primary']) ? 1 : 0,
		);
        }

        $normalizedExistingHeroLinks = self::normalize_existing_hero_links($existing['download_links'] ?? array());
        // @MODIFIED 2026-05-02: GAP 6 — Pass smart_windows_default=true to prefer Windows x64
        // as primary when no is_primary flag is set, matching the Response_Normalizer's behavior.
        $normalizedArticleLinks = !empty($links) ? self::enforce_single_primary($links, true) : array();

        // DIAGNOSTIC: Log hero meta normalization summary
        if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
            error_log( sprintf(
                '[PublishPayload] buildHeroMetaInput RESULT: links_in=%d | normalized=%d | dropped_normalize=%d | dropped_non_download=%d | existing_hero=%d',
                count( $links_in ), count( $links ), $dropped_normalize, $dropped_non_download, count( $normalizedExistingHeroLinks )
            ) );
        }

        $canonicalArticleLinks = array();
        if (!empty($article['_canonical_download_links']) && is_array($article['_canonical_download_links'])) {
	if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[PublishPayload] buildHeroMetaInput: _canonical_download_links count=' . count($article['_canonical_download_links']) . ' | homepage=' . $hero_homepage);
		}
	foreach ($article['_canonical_download_links'] as $raw_link) {
			// Ensure canonical links have bypass flag to skip homepage collision guard.
			// Links from _canonical_download_links are the single source of truth and
			// should not be rejected by the homepage guard that filters AI hallucinations.
			if (is_array($raw_link) && !isset($raw_link['_bypass_homepage_guard'])) {
				$raw_link['_bypass_homepage_guard'] = true;
			}
			$normalized = self::normalize_download_link($raw_link, $hero_homepage);
			if ($normalized === null) {
                    if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						$_url = is_array($raw_link) ? ($raw_link['url'] ?? '') : (string)$raw_link;
						error_log( '[PublishPayload] buildHeroMetaInput: canonical DROPPED url=' . $_url . ' | homepage=' . $hero_homepage);
					}
                    continue;
                }
                $canonicalArticleLinks[] = $normalized;
            }
            // @MODIFIED 2026-05-02: GAP 6 — Consistent smart_windows_default=true.
            $canonicalArticleLinks = self::enforce_single_primary($canonicalArticleLinks, true);
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[PublishPayload] buildHeroMetaInput: canonicalArticleLinks after enforce_single_primary count=' . count($canonicalArticleLinks));
				foreach ($canonicalArticleLinks as $_i => $_cl) {
					error_log( '[PublishPayload] buildHeroMetaInput:   CANONICAL[' . $_i . '] url=' . ($_cl['url'] ?? '') . ' | platform=' . ($_cl['platform'] ?? '') . ' | variant=' . ($_cl['variant'] ?? ''));
				}
			}
        } else {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[PublishPayload] buildHeroMetaInput: _canonical_download_links EMPTY or not array');
			}
		}

        // @FIXED 2026-07-22: Canonical links are the SSOT for Hero Meta. Previously used
        // normalizedArticleLinks (from AI-generated download_section) as fallback, causing
        // Hero Meta to show different links than the Download Zone during partial regen.
        // Hero Meta MUST only use canonicalArticleLinks or existing hero links, never AI links.
        $heroDownloadLinks = array();
        if (!empty($canonicalArticleLinks)) {
            $heroDownloadLinks = $canonicalArticleLinks;
        } else {
            $heroDownloadLinks = $normalizedExistingHeroLinks;
        }

        // @MODIFIED 2026-05-02: GAP 1 — Text carry-over from existing hero data into SSOT.
        // When new AI/canonical links win the priority cascade, their `text` field is typically
        // empty (AI rarely provides it). This loop finds the matching existing link and carries
        // its preserved text forward, making seogenherodata the true single source of truth.
        // GAP 3 — Version-refresh uses the OLD link's version field directly instead of a
        // blind leftmost-match regex, preventing OS version numbers (e.g. "Windows 8.1")
        // from being corrupted. GAP 4 — preg_quote handles integer-only versions natively.
        if (!empty($heroDownloadLinks) && !empty($normalizedExistingHeroLinks)
            && $heroDownloadLinks !== $normalizedExistingHeroLinks) {
            foreach ($heroDownloadLinks as $i => $new_link) {
                $new_url_lower = strtolower(trim((string) ($new_link['url'] ?? '')));
                $matched_old = null;
                // 1. Exact URL match
                foreach ($normalizedExistingHeroLinks as $old_link) {
                    $old_url_lower = strtolower(trim((string) ($old_link['url'] ?? '')));
                    if ($old_url_lower !== '' && $old_url_lower === $new_url_lower) {
                        $matched_old = $old_link;
                        break;
                    }
                }
        // 2. Fallback: platform+variant+file_type match (URL changed on version update)
        if ($matched_old === null) {
            $n_platform = strtolower(trim((string) ($new_link['platform'] ?? '')));
            $n_variant = strtolower(trim((string) ($new_link['variant'] ?? 'standard')));
            $n_ftype = strtolower(trim((string) ($new_link['file_type'] ?? '')));
            foreach ($normalizedExistingHeroLinks as $old_link) {
                $o_platform = strtolower(trim((string) ($old_link['platform'] ?? '')));
                $o_variant = strtolower(trim((string) ($old_link['variant'] ?? 'standard')));
                $o_ftype = strtolower(trim((string) ($old_link['file_type'] ?? '')));
                $slot_match = ($o_platform === $n_platform && $o_variant === $n_variant);
                if (!$slot_match && $o_platform === $n_platform && $o_ftype !== '' && $o_ftype === $n_ftype) {
                    // @MODIFIED 2026-05-02: When file_type matches but variant differs due to
                    // architecture composition (e.g. old="portable", new="x64 portable"),
                    // check architecture prefix overlap to avoid matching x64 to x86 link.
                    $n_arch = '';
                    $o_arch = '';
                    if (preg_match('/^(x64|x86|arm64|arm)\s+/i', $n_variant, $nm)) { $n_arch = strtolower($nm[1]); }
                    if (preg_match('/^(x64|x86|arm64|arm)\s+/i', $o_variant, $om)) { $o_arch = strtolower($om[1]); }
                    if ($n_arch !== '' && $o_arch !== '' && $n_arch !== $o_arch) {
                        continue;
                    }
                    $slot_match = true;
                }
                if ($slot_match) {
                    $matched_old = $old_link;
                    break;
                }
            }
        }
        // Carry over text from matched existing link
                if ($matched_old !== null && !empty($matched_old['text']) && empty($new_link['text'])) {
                    $carried_text = trim((string) $matched_old['text']);
                    // Version-refresh: replace OLD version number with NEW using exact match
                    $new_version = trim((string) ($new_link['version'] ?? ''));
                    $old_version = trim((string) ($matched_old['version'] ?? ''));
                    if ($new_version !== '' && $old_version !== '' && $old_version !== $new_version) {
                        $carried_text = preg_replace(
                            '/\b' . preg_quote($old_version, '/') . '\b/',
                            $new_version,
                            $carried_text,
                            1
                        );
                    }
                    $heroDownloadLinks[$i]['text'] = $carried_text;
                }
		}
		}

		// @MODIFIED 2026-08-06: Stale manual edit detection for download links.
		// Scraped links (_canonical_download_links) are the ground truth for URLs.
		// Manual edits from the hero meta box (_seo_gen_hero_download_links) are
		// only preserved when they match a fresh scraped link — preventing stale
		// additions (e.g. a "Beta" link) from persisting indefinitely when the
		// source page no longer offers that variant.
		//
		// Matching rules:
		//   1. URL matches a canonical link → KEEP (scraped link, possibly with text edit)
		//   2. platform+variant+file_type matches a canonical link → KEEP (version-updated URL)
		//   3. Neither matches → DROP (stale addition no longer in source)
		$persisted_links = \get_post_meta($post_id, '_seo_gen_hero_download_links', true);
		if (is_array($persisted_links) && !empty($persisted_links)) {
			// Build canonical link lookups from the fresh scrape
			$canonical_urls = array();
			$canonical_slot_map = array();
			foreach ($canonicalArticleLinks as $_cl) {
				$_url = rtrim(strtolower(trim((string)($_cl['url'] ?? ''))), '/');
				if ($_url !== '') { $canonical_urls[$_url] = $_cl; }
				$_p = strtolower(trim((string)($_cl['platform'] ?? '')));
				$_v = strtolower(trim((string)($_cl['variant'] ?? 'standard')));
				$_ft = strtolower(trim((string)($_cl['file_type'] ?? '')));
				$_slot_key = $_p . '|' . $_v . '|' . $_ft;
				if (!isset($canonical_slot_map[$_slot_key])) {
					$canonical_slot_map[$_slot_key] = $_cl;
				}
				// Also register without file_type for architecture-composed variants
				$_slot_key_nft = $_p . '|' . $_v;
				if (!isset($canonical_slot_map[$_slot_key_nft])) {
					$canonical_slot_map[$_slot_key_nft] = $_cl;
				}
			}

			$appended = 0;
			$dropped_stale = 0;
			foreach ($persisted_links as $pl) {
				if (!is_array($pl)) { continue; }
				$normalized_pl = self::normalize_download_link($pl, $hero_homepage);
				if ($normalized_pl === null) { continue; }
				$_pl_url = rtrim(strtolower(trim((string)($normalized_pl['url'] ?? ''))), '/');
				if ($_pl_url === '') { continue; }

				// Already in heroDownloadLinks? Skip.
				$_already = false;
				foreach ($heroDownloadLinks as $_hl) {
					if (rtrim(strtolower(trim((string)($_hl['url'] ?? ''))), '/') === $_pl_url) {
						$_already = true;
						break;
					}
				}
				if ($_already) { continue; }

				// Match #1: URL matches a canonical (scraped) link → KEEP
				if (isset($canonical_urls[$_pl_url])) {
					$heroDownloadLinks[] = $normalized_pl;
					$appended++;
					continue;
				}

				// Match #2: platform+variant+file_type matches a canonical link → KEEP
				$_p = strtolower(trim((string)($normalized_pl['platform'] ?? '')));
				$_v = strtolower(trim((string)($normalized_pl['variant'] ?? 'standard')));
				$_ft = strtolower(trim((string)($normalized_pl['file_type'] ?? '')));
				$_slot_key = $_p . '|' . $_v . '|' . $_ft;
				$_slot_key_nft = $_p . '|' . $_v;
				if (isset($canonical_slot_map[$_slot_key]) || isset($canonical_slot_map[$_slot_key_nft])) {
					$heroDownloadLinks[] = $normalized_pl;
					$appended++;
					continue;
				}

				// No match → STALE manual addition, drop it
				$dropped_stale++;
			}
			// [SSOT-FIX Finding 3] ALWAYS re-run enforce_single_primary after the stale-link
			// filter, not only when $appended > 0. The persisted-links loop above may add,
			// drop, or keep links without their is_primary flag, leaving hero meta without
			// any primary-marked link when the canonical scrape also lacked one. Running
			// enforce_single_primary unconditionally guarantees exactly one link is marked
			// primary for the Hero Meta Box UI.
			$heroDownloadLinks = self::enforce_single_primary($heroDownloadLinks, true);
			if (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) {
				error_log(sprintf(
					'[PublishPayload] buildHeroMetaInput: _seo_gen_hero_download_links count=%d | kept=%d | dropped_stale=%d | heroDownloadLinks final count=%d',
					count($persisted_links), $appended, $dropped_stale, count($heroDownloadLinks)
				));
			}
		}

		$heroCategory = '';
        $categorySources = [
            $hero['category']     ?? '',
            $article['category']  ?? '',
            $existing['category'] ?? '',
        ];
        foreach ($categorySources as $rawCat) {
            if (empty($rawCat)) continue;
            $candidates = is_array($rawCat)
                ? $rawCat
                : array_filter(array_map('trim', explode(',', (string)$rawCat)));
            foreach ($candidates as $c) {
                $c = trim((string)$c);
                if ($c !== '') {
                    $heroCategory = $c;
                    break 2;
                }
            }
        }
        if (!$heroCategory) {
            if ($post_id > 0) {
                $terms = get_the_terms($post_id, 'category');
                if (!empty($terms) && !is_wp_error($terms)) {
                    $os_slugs = array('windows', 'macos', 'linux', 'android', 'ios');
                    $sw_terms = array_filter($terms, static function($t) use ($os_slugs) { return !in_array($t->slug, $os_slugs, true); });
                    $use_terms = !empty($sw_terms) ? $sw_terms : $terms;
                    $heroCategory = implode(', ', wp_list_pluck(array_values($use_terms), 'name'));
                }
            }
        }
        if (!$heroCategory) {
            $heroCategory = '';
        }

        $normalized = array(
            '_schema_version'    => 2,
            'software_name'      => (string)($hero['software_name'] ?? $techspecs['software_name'] ?? $techspecs['softwarename'] ?? $article['title'] ?? ''),
            'version'            => (string)($techspecs['version'] ?? $hero['version'] ?? ''),
            'license'            => (string)($hero['license'] ?? $techspecs['license'] ?? ''),
            'license_details'    => (string)($hero['license_details'] ?? $hero['licensedetails'] ?? ''),
            'file_size'          => (string)($hero['file_size'] ?? $hero['filesize'] ?? $techspecs['file_size'] ?? $techspecs['filesize'] ?? ''),
            'rating'             => isset($hero['rating']) ? (string)$hero['rating'] : (string)($existing['rating'] ?? ''),
            'rating_count'       => isset($hero['rating_count']) ? (string)$hero['rating_count'] : (string)($existing['rating_count'] ?? ''),
            'logo_url'           => (string)($hero['logo_url'] ?? $hero['logourl'] ?? ''),
            'publisher'          => (string)($hero['publisher'] ?? $techspecs['developer'] ?? ''),
		'category' => $heroCategory,
		'application_category' => \SEO_Article_Generator\Generator\Hero_Data_Provider::normalize_application_category_value($heroCategory),
		'last_updated' => (string)($hero['last_updated'] ?? $hero['lastupdated'] ?? $techspecs['lastupdated'] ?? ''),
            'min_os'             => (string)($hero['min_os'] ?? $hero['minos'] ?? $techspecs['os_support'] ?? $techspecs['ossupport'] ?? ''),
            'security_badge'     => (string)($hero['security_badge'] ?? $hero['security_badge_text'] ?? $hero['securitybadge'] ?? $existing['security_badge'] ?? ''),
	'download_links' => (static function(array $links): array {
			$clean = array();
			foreach ($links as $l) {
				if (is_array($l)) { unset($l['_portal_fallback']); }
				$clean[] = $l;
			}
			return $clean;
		})($heroDownloadLinks),
            'last_verified_date' => (string)($hero['last_verified_date'] ?? $hero['last_verified'] ?? $hero['lastverified'] ?? $existing['last_verified_date'] ?? $existing['last_verified'] ?? ''),
        );

        // [SSOT-FIX Finding 6] wp_date() for last_updated (WP timezone display), gmdate()
        // for last_verified_date (UTC ISO). Same source as Hero_Data_Provider::from_schema().
        $normalized['last_updated'] = function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : \date( 'F j, Y' );
        $normalized['last_verified_date'] = gmdate('Y-m-d');

        if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[PublishPayload] buildHeroMetaInput: FINAL download_links count=' . count($heroDownloadLinks));
			foreach ($heroDownloadLinks as $_i => $_dl) {
				error_log( '[PublishPayload] buildHeroMetaInput:   FINAL[' . $_i . '] url=' . ($_dl['url'] ?? '') . ' | platform=' . ($_dl['platform'] ?? '') . ' | variant=' . ($_dl['variant'] ?? ''));
			}
		}

        return array(
            'seogenherodata' => $normalized,
        );
    }

    private static function canonicalize_article_contract(array $article): array
    {
        $raw_heading_map = array();

        if (isset($article['_seo_gen_heading_map']) && is_array($article['_seo_gen_heading_map'])) {
            $raw_heading_map = $article['_seo_gen_heading_map'];
        } elseif (isset($article['seogenheadingmap']) && is_array($article['seogenheadingmap'])) {
            $raw_heading_map = $article['seogenheadingmap'];
        }

        foreach (
            array(
                'download_section',
                'tech_specs',
                'hero_section',
                'features',
                'faqs',
                'pros_cons',
                'related_software',
                'whats_new',
                'installation_guide',
                'safety',
                'competitors',
                'moat_data',
            ) as $_pre
        ) {
            if (!isset($article[$_pre]) || !is_array($article[$_pre])) {
                $article[$_pre] = array();
            }
        }

        $schema  = Article_Schema::from_array($article);
        $article = $schema->to_array();

        $normalized_heading_map = array();
        foreach ($raw_heading_map as $map_key => $map_value) {
            if (!is_string($map_key) || !is_string($map_value)) {
                continue;
            }

            $map_key   = trim($map_key);
            $map_value = trim($map_value);

            if ($map_key === '' || $map_value === '') {
                continue;
            }

            $canonical_key = Article_Schema::get_canonical_key($map_key);
            if (!$canonical_key) {
                continue;
            }

            $normalized_heading_map[$canonical_key] = $map_value;
        }

        if (!empty($normalized_heading_map)) {
            $article['_seo_gen_heading_map'] = $normalized_heading_map;
            $article['seogenheadingmap']     = $normalized_heading_map;
        }

        if (!isset($article['download_section']['links']) || !is_array($article['download_section']['links'])) {
            $article['download_section']['links'] = array();
        }

        if (!isset($article['installation_guide']['steps']) || !is_array($article['installation_guide']['steps'])) {
            $article['installation_guide']['steps'] = array();
        }

        if (!isset($article['installation_guide']['common_issues']) || !is_array($article['installation_guide']['common_issues'])) {
            $article['installation_guide']['common_issues'] = array();
        }

        if (!isset($article['pros_cons']['pros']) || !is_array($article['pros_cons']['pros'])) {
            $article['pros_cons']['pros'] = array();
        }

        if (!isset($article['pros_cons']['cons']) || !is_array($article['pros_cons']['cons'])) {
            $article['pros_cons']['cons'] = array();
        }

	$raw_links = isset($article['download_section']['links']) && is_array($article['download_section']['links'])
		? $article['download_section']['links']
		: array();

	$homepage = trim((string) ($article['tech_specs']['homepage'] ?? $article['techspecs']['homepage'] ?? ''));

	$non_download_patterns = array(
		'/what-is-dotnet/', '/whats-new/', '/overview',
		'/learn.microsoft.com', '/docs.microsoft.com',
		'/release-notes', '/blob/main/release-notes',
		'/en-us/apps/', '/en-us/learn/',
	);

	// DIAGNOSTIC: Log canonicalize input
	if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
		error_log( sprintf(
			'[PublishPayload] canonicalize_article_contract: raw_links=%d | homepage=%s',
			count( $raw_links ), $homepage
		) );
	}

	$links = array();
	$canonical_dropped = 0;
	foreach ($raw_links as $raw_link) {
		$normalized = self::normalize_download_link($raw_link, $homepage);
		if ($normalized === null) {
			$canonical_dropped++;
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				$_url = is_array( $raw_link ) ? ( $raw_link['url'] ?? '' ) : (string) $raw_link;
				error_log( sprintf(
					'[PublishPayload]   canonicalize DROPPED: url=%s | homepage=%s',
					$_url, $homepage
				) );
			}
			continue;
		}
		$is_non_download = false;
		$link_url_lower = strtolower(trim((string) ($normalized['url'] ?? '')));
            foreach ($non_download_patterns as $pattern) {
                if (strpos($link_url_lower, $pattern) !== false) {
                    $is_non_download = true;
                    break;
                }
            }
            if ($is_non_download && count($links) > 0) {
                $canonical_dropped++;
                if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
                    error_log( sprintf(
                        '[PublishPayload]   canonicalize DROPPED non-download: url=%s',
                        $normalized['url'] ?? ''
                    ) );
                }
                continue;
            }
            $links[] = $normalized;
        }

	// DIAGNOSTIC: Log canonicalize output
	if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
		error_log( sprintf(
			'[PublishPayload] canonicalize_article_contract RESULT: input=%d | output=%d | dropped=%d',
			count( $raw_links ), count( $links ), $canonical_dropped
		) );
	}

            // @MODIFIED 2026-05-02: GAP 6 — Consistent smart_windows_default=true.
            $article['download_section']['links'] = self::enforce_single_primary($links, true);

        return $article;
    }

	public static function enforce_single_primary(array $links, bool $smart_windows_default = false): array
	{
		$has_primary = false;
		$normalized_links = array();

		foreach ($links as $link) {
			if (is_string($link)) {
				$link = array('url' => trim($link));
			}
			if (!is_array($link) || empty($link['url'])) {
				continue;
			}

			// Ensure basic keys are present to avoid undefined index notices/warnings
			$item = array_merge(
				array(
					'platform'   => 'Windows',
					'url'        => '',
					'variant'    => 'Standard',
					'file_type'  => '',
					'version'    => '',
					'channel'    => '',
					'text'       => '',
					'is_primary' => 0,
				),
				$link
			);

			// Enforce type safety
			$item['platform']   = (string)$item['platform'];
			$item['url']        = (string)$item['url'];
			$item['variant']    = (string)$item['variant'];
			$item['file_type']  = (string)$item['file_type'];
			$item['version']    = (string)$item['version'];
			$item['channel']    = (string)$item['channel'];
			$item['text']       = (string)$item['text'];
			$item['is_primary'] = !empty($item['is_primary']) || !empty($item['isprimary']) ? 1 : 0;

			$normalized_links[] = $item;
		}

		foreach ($normalized_links as $i => $link) {
			$is_primary = !empty($link['is_primary']);
			if ($is_primary && !$has_primary) {
				$has_primary = true;
				$normalized_links[$i]['is_primary'] = 1;
			} else {
				$normalized_links[$i]['is_primary'] = 0;
			}
		}

		// When smart_windows_default is enabled, prioritize Windows links as primary
		// even if a non-Windows link was pre-marked as primary by discovery.
		if ($smart_windows_default) {
			$windows_primary_index = -1;
			$current_primary_index = -1;

			foreach ($normalized_links as $i => $link) {
				$p = strtolower($link['platform'] ?? '');
				$v = strtolower($link['variant'] ?? '');
				$u = strtolower($link['url'] ?? '');

				// Track current primary
				if (!empty($link['is_primary'])) {
					$current_primary_index = $i;
				}

				// Find first Windows x64 link (preferred primary)
				if ($windows_primary_index === -1 && $p === 'windows' && (preg_match('/^x64\b/i', $v) || strpos($u, '64') !== false)) {
					$windows_primary_index = $i;
				}
			}

			// If we found a Windows link and current primary is not Windows, switch primary
			if ($windows_primary_index !== -1 && $current_primary_index !== $windows_primary_index) {
				// Remove primary from current
				if ($current_primary_index !== -1) {
					$normalized_links[$current_primary_index]['is_primary'] = 0;
				}
				// Set Windows as primary
				$normalized_links[$windows_primary_index]['is_primary'] = 1;
				$has_primary = true;
			}
		}

		if (!$has_primary && !empty($normalized_links)) {
			$best = 0;
			if ($smart_windows_default) {
				foreach ($normalized_links as $i => $link) {
					$p = strtolower($link['platform'] ?? '');
					$v = strtolower($link['variant'] ?? '');
					$u = strtolower($link['url'] ?? '');
					// @MODIFIED 2026-05-02: Handle composed variants (e.g. "x64 Portable")
					// by checking if variant starts with x64, not just equals x64.
					if ($p === 'windows' && (preg_match('/^x64\b/i', $v) || strpos($u, '64') !== false)) {
						$best = $i;
						break;
					}
				}
			}
			$normalized_links[$best]['is_primary'] = 1;
		}

		// @ADDED 2026-05-28: Enforce OS priority sorting so both Hero and Body download links match exactly
		usort($normalized_links, static function(array $a, array $b): int {
			$priority = array(
				'windows' => 1,
				'macos'   => 2,
				'linux'   => 3,
				'android' => 4,
				'ios'     => 5,
				'iphone'  => 5,
			);

			$pa = $priority[strtolower($a['platform'])] ?? 99;
			$pb = $priority[strtolower($b['platform'])] ?? 99;

			if ($pa !== $pb) {
				return $pa <=> $pb;
			}

			$primary_a = !empty($a['is_primary']) ? 1 : 0;
			$primary_b = !empty($b['is_primary']) ? 1 : 0;
			if ($primary_a !== $primary_b) {
				return $primary_b <=> $primary_a;
			}

			return strcmp($a['url'], $b['url']);
		});

		return $normalized_links;
	}

    private static function normalize_existing_hero_links($raw): array
    {
        if (!is_array($raw)) {
            return array();
        }

        $links = array();
        foreach ($raw as $raw_link) {
            if (!is_array($raw_link) || empty($raw_link['url'])) {
                continue;
            }

        $links[] = array(
            'platform' => sanitize_text_field((string)($raw_link['platform'] ?? '')),
            'url' => esc_url_raw((string)$raw_link['url']),
            // @MODIFIED 2026-05-02: Delegate variant normalization so composed variants
            // (e.g. "x64 Portable") are produced consistently from old stored data.
            'variant' => \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_variant_name(sanitize_text_field((string)($raw_link['variant'] ?? ''))),
            'file_type' => sanitize_text_field((string)($raw_link['file_type'] ?? '')),
			'version' => sanitize_text_field((string)($raw_link['version'] ?? '')),
			'channel' => sanitize_text_field((string)($raw_link['channel'] ?? '')),
			'is_primary' => !empty($raw_link['is_primary']) || !empty($raw_link['isprimary']) ? 1 : 0,
			'text' => sanitize_text_field((string)($raw_link['text'] ?? '')),
		);
        }

        // @MODIFIED 2026-05-02: GAP 6 — Consistent smart_windows_default=true.
        return self::enforce_single_primary($links, true);}

	public static function normalize_download_link($raw_link, $homepage = ''): ?array
	{
		$input_url = is_array($raw_link) ? ($raw_link['url'] ?? '') : (string)$raw_link;
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[PublishPayload] normalize_download_link: CHECKING url=' . $input_url . ' | homepage=' . $homepage);
		}
		if (is_string($raw_link)) {
			$raw_link = array('url' => trim($raw_link));
		}
		if (!is_array($raw_link)) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[PublishPayload] normalize_download_link: REJECTED not-an-array url=' . $input_url);
			}
			return null;
		}

		$normalized = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_link($raw_link, 'Windows', $homepage);
        if (!$normalized) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[PublishPayload] normalize_download_link: REJECTED by normalize_link url=' . $input_url . ' | homepage=' . $homepage);
			}
            return null;
        }
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[PublishPayload] normalize_download_link: ACCEPTED url=' . $normalized['url'] . ' | platform=' . ($normalized['platform'] ?? '') . ' | variant=' . ($normalized['variant'] ?? ''));
		}

	return array(
		'platform' => $normalized['platform'],
		'url' => $normalized['url'],
		'variant' => $normalized['variant'],
		'file_type' => $normalized['file_type'],
		'version' => $normalized['version'],
		'channel' => $normalized['channel'],
		'is_primary' => $normalized['is_primary'],
		'text' => $normalized['text'],
		'_portal_fallback' => ! empty($normalized['_portal_fallback']),
	);
    }


    private static function resolve_plugin_update_title(string $existing_title, array $tech_specs, string $fallback_title): string
    {
        // FIXED 2026-04-03: For partial-regen updates, existing_title is always the ground truth.
        // Only attempt version substitution — never replace the entire title.
        if ($existing_title === '') {
            // No existing title at all — sanitize fallback before using it
            return !empty($fallback_title) ? \sanitize_text_field($fallback_title) : '';
        }

        $new_version = trim((string) ($tech_specs['version'] ?? ''));
        $build = trim((string) ($tech_specs['build'] ?? ''));

        // No new version info → preserve existing title unchanged
        if ($new_version === '') {
            return $existing_title;
        }

        $replacement = $new_version;
        if ($build !== '') {
            $replacement .= stripos($build, 'build') !== false ? ' ' . $build : ' Build ' . $build;
        }

        if (class_exists(Title_Analyzer::class)) {
            $analyzer = new Title_Analyzer();
            $extracted = $analyzer->extract($existing_title);

            if (!empty($extracted['version'])) {
			$title_vr_pattern = '/\b' . preg_quote((string) $extracted['version'], '/') . '\b/i';
			return preg_replace($title_vr_pattern, $replacement, $existing_title);
            }
        }

        return $existing_title;
    }
}

        // TYPE_PLUGIN: native block contract — surgical patch directly (no migration needed).
        if ( $post_type === Post_Type_Classifier::TYPE_PLUGIN ) {
            if ( $this->logger ) {
                $this->logger->info(
                    'PATH D: Plugin-owned native block post. Surgical patch via Surgical_Patcher.',
                    [ 'post_id' => $post_id ]
                );
            }

            $patched = Surgical_Patcher::patch(
                $existing_content,
                $effective_article,
                $regen_sections,
                $heading_map,
                $post_id
            );

            // FINDING-4 FIX: If SurgicalPatcher signals needs_full_regen, throw immediately.
            if ( ! empty( $patched['needs_full_regen'] ) ) {
                throw new \RuntimeException(
                    'migration_failed_missing_block_delimiters: Post ' . $post_id
                    . ' has no patchable sentinel structure. '
                    . 'Content contract must be cleared for full regeneration on next retry.'
                );
            }

            if ( ! empty( $patched['not_found_detection_failed'] ) ) {
                // FIX: Always trigger full-regen for not_found_detection_failed cases.
                // These posts have zone detection failures that cannot be surgically patched,
                // regardless of whether they have some section sentinels or none.
                throw new \RuntimeException(
                    'migration_failed_missing_block_delimiters: Post ' . $post_id
                    . ' has zone detection failures that cannot be surgically patched. '
                    . 'Content contract must be cleared for full regeneration on next retry.'
                );
            }

            if ( ! empty( $patched['not_found_in_content'] ) ) {
                throw new \RuntimeException(
                    'surgical_patch_requested_zones_missing: Post ' . $post_id
                    . ' is missing requested zones: '
                    . implode( ', ', $patched['not_found_in_content'] )
                    . '. Refusing partial publish to avoid unintended section drift.'
                );
            }

            if ( ! empty( $patched['skipped'] ) ) {
                throw new \RuntimeException(
                    'surgical_patch_render_skipped: Post ' . $post_id
                    . ' could not render requested zones: '
                    . implode( ', ', $patched['skipped'] )
                    . '. Refusing partial publish so unselected sections remain untouched.'
                );
            }

            $content = ! empty( $patched['content'] )
                ? (string) $patched['content']
                : $existing_content;

            // Publish-boundary canonicalization: re-apply the hero block comment normalizer
            // one more time on whatever the surgical patcher produced. This is defense-in-depth
            // so any future content producer (admin tool, Jetpack update, manual rewrite, etc.)
            // that routes through this builder also writes the parser-safe hero form, even if
            // the producer forgot to call the helper itself.
            $content = Article_Schema::canonicalize_hero_block_comment( $content );

            // Pre-publish integrity gate: fail-fast if the content is structurally unsafe
            // (duplicate sentinels, duplicate IDs, cross-post link leaks on update). The
            // Post_Content_Integrity_Guard has been defined as the pre-publish validator since
            // v2.33.0 but was never wired in; this is the call site. A failure here causes
            // finalize_generated_post() to throw and the job to retry on the next tick.
            $integrity = Post_Content_Integrity_Guard::validate_for_publish( $content, [
                'mode' => $is_update_contract ? 'update' : 'new',
            ] );
            if ( empty( $integrity['ok'] ) ) {
                throw new \RuntimeException(
                    'post_content_integrity_guard_failed: Post ' . $post_id
                    . ' content failed pre-publish validation. fatal_reasons='
                    . implode( ',', (array) ( $integrity['fatal_reasons'] ?? [] ) )
                    . '. audit=' . \wp_json_encode( $integrity['audit'] ?? [] )
                    . '. Job will retry.'
                );
            }

            $title = self::resolve_plugin_update_title(
                (string) $existing_post->post_title,
                isset( $effective_article['tech_specs'] ) && is_array( $effective_article['tech_specs'] ) ? $effective_article['tech_specs'] : array(),
                isset( $ai_schema->to_array()['title'] ) ? (string) $ai_schema->to_array()['title'] : ''
            );

            $effective_article['title'] = $title;
            $effective_article['html_content'] = $content;

            if ( ! empty( $heading_map ) ) {
                $effective_article['_seo_gen_heading_map'] = $heading_map;
            }

            $preview['article'] = $effective_article;

            $payload = array(
                'title'   => $title,
                'content' => $content,
                'preview' => $preview,
            );

            // 4) Use effective article for ALL metadata in update branch
            $payload['meta_input'] = self::buildHeroMetaInput( $effective_article, $post_id );

            if ( class_exists( '\\SEO_Article_Generator\\EEAT\\Article_Attribution_Metabox' ) ) {
                $eeat_meta = \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::buildGeneratedMetaInput( $effective_article, $post_id );
                if ( isset( $eeat_meta['seogenherodata'], $payload['meta_input']['seogenherodata'] ) ) {
                    $payload['meta_input']['seogenherodata'] = array_merge(
                        $payload['meta_input']['seogenherodata'],
                        $eeat_meta['seogenherodata']
                    );
                    unset( $eeat_meta['seogenherodata'] );
                }
                $payload['meta_input'] = array_merge( $payload['meta_input'], $eeat_meta );
            }

            return $payload;
        }

    /**
 * Version Single Source of Truth Enforcement.
 *
 * Centralizes version canonicalization across all publish paths:
 * - Publish_Payload_Builder::build()
 * - Discovery_Processor self-heal path
 * - Hero_Data_Provider::from_schema()
 *
 * @since 2.38.0
 */
final class Version_SSOT
{
    /**
     * Enforce canonical version across all article surfaces.
     *
     * @param array  $article          Article contract (passed by reference; mutated).
     * @param string $forced_canonical Optional canonical version. When empty, falls back
     *                                 to $article['tech_specs']['version'].
     * @return void
     */
    public static function enforce(array &$article, string $forced_canonical = ''): void
    {
        $ppb_canonical = $forced_canonical;
        if ($ppb_canonical === '' && !empty($article['tech_specs']['version'])) {
            $ppb_canonical = (string) $article['tech_specs']['version'];
        }

        if ($ppb_canonical !== '' && preg_match('/^\d+\.\d+(\.\d+)?/', $ppb_canonical)) {
            $article['tech_specs']['version'] = $ppb_canonical;
            // [SSOT-FIX Finding 6] Use wp_date() (WP-timezone) for tech_specs/hero_section
            // last_updated so all date writes converge to the same timezone Hero_Data_Provider
            // and renderers consume. Server-local \date() drifted by 1 day when WP timezone
            // != server timezone.
            $article['tech_specs']['last_updated'] = function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : \date( 'F j, Y' );
            if (isset($article['version'])) {
                $article['version'] = $ppb_canonical;
            }
            if (is_array($article['hero_section'] ?? null)) {
                $article['hero_section']['version'] = $ppb_canonical;
                $article['hero_section']['last_updated']       = function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : \date( 'F j, Y' );
                $article['hero_section']['last_verified_date'] = \gmdate('Y-m-d');
            }

            // 3+ dotted segments (or "Build N" suffix); avoids clobbering two-segment
            // numbers such as file sizes (e.g. 46.6). Strips leaked markdown first.
            $ppb_vt = '/\b\d+\.\d+\.\d+(?:\.\d+)?(?:\s*Build\s*\d+)?\b/i';

            // [META-NO-VERSION] Meta description must NEVER contain software version.
            // Matches 2+ dotted segments so 2-segment versions like "v26.1", "26.1", "15.2"
            // are caught (previously missed by the 3+ segment regex used elsewhere).
            // [META-NO-SIZE] Meta description must NEVER contain file size either.
            $ppb_md_vt = '/\b\d+\.\d+(?:\.\d+)?(?:\.\d+)?(?:\s*Build\s*\d+)?\b/i';
            $ppb_md_size = '/\b\d+(?:\.\d+)?\s*(?:MB|GB|KB|kB|TB|bytes?)\b/i';

            if (is_string($article['meta_description'] ?? null)) {
                $md = \SEO_Article_Generator\Generator\Response_Normalizer::strip_markdown($article['meta_description']);
                // [META-NO-VERSION] Remove version from meta_description entirely (SERP churn / build-tag noise).
                $md = preg_replace($ppb_md_vt, '', $md);
                // Also strip prefixed versions like "v1.2", "v1.2.3", "version 1.2.3", "ver 1.2.3"
                $md = preg_replace('/\b(?:v|version|ver)\s*\d+\.\d+(?:\.\d+)?(?:\.\d+)?\b/i', '', $md);
                // Strip versions with dashes/suffixes (e.g. "1.2.3-beta", "1.2.3-rc1", "1.2.3-alpha")
                $md = preg_replace('/\b\d+\.\d+(?:\.\d+)?(?:-[a-z0-9]+)?\b/i', '', $md);
                // Strip prefixed versions with dashes (e.g. "v1.2.3-beta", "version 1.2.3-rc1")
                $md = preg_replace('/\b(?:v|version|ver)\s*\d+\.\d+(?:\.\d+)?(?:-[a-z0-9]+)?\b/i', '', $md);
                // [META-NO-SIZE] Remove file size from meta_description entirely (SERP churn / noise).
                $md = preg_replace($ppb_md_size, '', $md);
                // Also strip sizes without space (e.g. "90MB", "1.5GB")
                $md = preg_replace('/\b\d+(?:\.\d+)?(?:MB|GB|KB|kB|TB)\b/i', '', $md);
                $md = preg_replace('/\s+/', ' ', $md);
                $md = trim($md, ' ,.;:');
                $article['meta_description'] = $md;
            }
            if (is_array($article['introduction'] ?? null)) {
                foreach ($article['introduction'] as $ppb_i => $ppb_t) {
                    if (is_string($ppb_t)) {
                        $article['introduction'][$ppb_i] = preg_replace($ppb_vt, $ppb_canonical, $ppb_t);
                    }
                }
            }
            if (is_array($article['whats_new'] ?? null)) {
                foreach ($article['whats_new'] as $ppb_j => $ppb_w) {
                    if (is_string($ppb_w)) {
                        $article['whats_new'][$ppb_j] = preg_replace($ppb_vt, $ppb_canonical, $ppb_w);
                    }
                }
            }
            if (!empty($article['download_section']['heading'])) {
                $article['download_section']['heading'] = preg_replace(
                    $ppb_vt,
                    $ppb_canonical,
                    (string) $article['download_section']['heading']
                );
            }
        }

        // @FIXED 2026-07-22: ALWAYS set dates to today, regardless of version format.
        // [SSOT-FIX Finding 6] wp_date() for last_updated (display), gmdate() for
        // last_verified_date (ISO/sortable). Same timezone source as Hero_Data_Provider.
        if (is_array($article['tech_specs'] ?? null)) {
            $article['tech_specs']['last_updated'] = function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : \date( 'F j, Y' );
        }
        if (is_array($article['hero_section'] ?? null)) {
            $article['hero_section']['last_updated']       = function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : \date( 'F j, Y' );
            $article['hero_section']['last_verified_date'] = \gmdate('Y-m-d');
        }
    }
}
