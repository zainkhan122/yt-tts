<?php
/**
 * Google-Trends Shorts Service (v1.9.0, owner-approved 2026-10-04).
 *
 * Pipeline: daily cron fetches Google Trends "Trending Now" RSS (verified
 * working 2026-09, free, no key) for configured geos -> dedupe vs last 7 days
 * -> score (traffic + niche-fit + questionability + freshness - exclusions)
 * -> qualified trends generate ONE evergreen-safe MCQ each via the existing
 * AI quiz handler with the approved 'trend' context (P-T1) -> jobs enter the
 * EXISTING planner-style job path (shorts loop format, series "Trend Jack",
 * experiment "trend") -> render/Buffer/playlist reuse existing services.
 *
 * YouTube mostPopular (1 quota unit) is intentionally NOT polled in v1:
 * RSS traffic + niche scoring already gate quality; adding YT calls doubles
 * failure surface for marginal gain. Re-evaluate after 2 weeks of score vs
 * performance logs (calibration window documented in
 * docs/google-trends-shorts-plan.md).
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Trends_Service
{
    public const CRON_HOOK = 'mcqvs_trends_fetch_cron';

    /** @NEW 1.9.0 */
    public static function init()
    {
        add_action(self::CRON_HOOK, array(__CLASS__, 'cron_run'));
        add_action('admin_init', array(__CLASS__, 'ensure_schedule'));
        add_action('wp_ajax_mcqvs_trends_fetch_now', array(__CLASS__, 'ajax_fetch_now'));
        add_action('wp_ajax_mcqvs_trends_queue_now', array(__CLASS__, 'ajax_queue_now'));
        self::migrate_legacy_floor();
    }

    /**
     * @FIX 1.9.4 (live evidence: site kept showing "min 45" after upgrade):
     * mcqvs_trends_min_score was REPURPOSED in v1.9.3 from "quality bar"
     * (defaults 60/55/45) to "sanity floor" (default 20) — but a value SAVED by
     * an earlier form submit lives in wp_options and always beats a new code
     * default, so upgraded sites kept the old bar and queued nothing. Migrate
     * stored values that exactly match any legacy default; custom choices are
     * respected. Flag-guarded, runs once.
     */
    public static function migrate_legacy_floor()
    {
        if (get_option('mcqvs_trends_floor_migrated', 0)) {
            return;
        }
        $stored = get_option('mcqvs_trends_min_score', null);
        if ($stored !== null && in_array((int) $stored, array(60, 55, 45), true)) {
            update_option('mcqvs_trends_min_score', 20);
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('MCQVS trends.floor_migrated from=' . (int) $stored . ' to=20', 'info', array('_type' => 'trends', 'event' => 'floor_migrated'));
            }
        }
        update_option('mcqvs_trends_floor_migrated', 1);
    }

    /** Self-healing daily schedule (same pattern as VS_Artifact_Cleanup). */
    public static function ensure_schedule()
    {
        if ((int) get_option('mcqvs_trends_enabled', 0) !== 1) {
            return;
        }
        if (! wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 3600, 'daily', self::CRON_HOOK);
        }
    }

    public static function cron_run()
    {
        if ((int) get_option('mcqvs_trends_enabled', 0) !== 1) {
            return array('skipped' => 'disabled');
        }
        $fetch = self::fetch_trends();
        if (is_wp_error($fetch)) {
            return array('error' => $fetch->get_error_message());
        }
        return self::generate_and_queue();
    }

    // ------------------------------------------------------------------
    //  FETCH + PARSE
    // ------------------------------------------------------------------

    /**
     * Fetch + store today's trends for all configured geos.
     *
     * @return array|WP_Error {fetched:int, new:int}
     */
    public static function fetch_trends()
    {
        $geos = array_filter(array_map('trim', explode(',', (string) get_option('mcqvs_trends_geos', 'US,PK'))));
        if (empty($geos)) {
            $geos = array('US');
        }
        $items = array();
        $errors = 0;
        foreach ($geos as $geo) {
            $geo = strtoupper(preg_replace('/[^A-Za-z]/', '', $geo));
            if ($geo === '') {
                continue;
            }
            $res = wp_remote_get('https://trends.google.com/trending/rss?geo=' . $geo, array('timeout' => 20, 'user-agent' => 'Mozilla/5.0 (compatible; MCQVS/1.9)'));
            if (is_wp_error($res)) {
                $errors++;
                self::log('trends.fetch_failed', array('geo' => $geo, 'error' => $res->get_error_message()));
                continue;
            }
            $code = (int) wp_remote_retrieve_response_code($res);
            if ($code !== 200) {
                $errors++;
                self::log('trends.fetch_http', array('geo' => $geo, 'code' => $code));
                continue;
            }
            $parsed = self::parse_rss((string) wp_remote_retrieve_body($res), $geo);
            foreach ($parsed as $p) {
                $items[] = $p;
            }
        }
        if (empty($items) && $errors > 0) {
            return new WP_Error('trends_all_failed', 'All trend feeds failed today');
        }

        // Dedupe vs last 7 days.
        $seen = get_option('mcqvs_trends_seen', array());
        if (! is_array($seen)) {
            $seen = array();
        }
        $today = gmdate('Y-m-d');
        $seen = array_filter($seen, function ($v) use ($today) { return is_array($v) && ($v['date'] ?? '') >= gmdate('Y-m-d', strtotime('-7 days')); });
        $new = 0;
        $fresh = array();
        foreach ($items as $it) {
            if (isset($seen[$it['hash']])) {
                continue;
            }
            $seen[$it['hash']] = array('date' => $today, 'title' => $it['title']);
            $fresh[] = $it;
            $new++;
        }
        update_option('mcqvs_trends_seen', $seen, false);
        update_option('mcqvs_trends_today', array('date' => $today, 'fetched_at' => gmdate('Y-m-d H:i:s'), 'items' => $fresh), false);
        self::log('trends.fetched', array('fetched' => count($items), 'new' => $new, 'geos' => implode('+', $geos)));
        return array('fetched' => count($items), 'new' => $new);
    }

    /**
     * Parse Google Trends RSS (ht:approx_traffic namespace).
     *
     * @NEW 1.9.0 public for tests.
     * @return array list of {title, traffic, geo, hash}
     */
    public static function parse_rss($xml, $geo = 'US')
    {
        $out = array();
        if (trim((string) $xml) === '') {
            return $out;
        }
        $prev = libxml_use_internal_errors(true);
        $sx = simplexml_load_string($xml);
        libxml_use_internal_errors($prev);
        if (! $sx || ! isset($sx->channel->item)) {
            return $out;
        }
        $today = gmdate('Y-m-d');
        foreach ($sx->channel->item as $item) {
            $title = trim((string) $item->title);
            if ($title === '') {
                continue;
            }
            $traffic = 0;
            // @NEW 1.9.5: RSS carries ht:news_item headlines per trend — keep them:
            // they feed the P-T1 prompt context AND the Qualified display.
            $headlines = array();
            foreach ($item->children('ht', true) as $tag => $node) {
                if ($tag === 'approx_traffic') {
                    $traffic = self::parse_traffic((string) $node);
                }
                if ($tag === 'news_item') {
                    $ht = '';
                    foreach ($node->children('ht', true) as $tag2 => $node2) {
                        if ($tag2 === 'news_item_title') {
                            $ht = trim((string) $node2);
                        }
                    }
                    if ($ht !== '') {
                        $headlines[] = $ht;
                    }
                }
            }
            $out[] = array(
                'title'     => $title,
                'traffic'   => $traffic,
                'geo'       => $geo,
                'headlines' => array_slice($headlines, 0, 3),
                'hash'      => md5($today . '|' . strtolower($title) . '|' . $geo),
            );
        }
        return $out;
    }

    /** "200K+" / "1,000,000+" -> int. */
    public static function parse_traffic($s)
    {
        $s = trim(str_replace(array('+', ','), '', (string) $s));
        if ($s === '') {
            return 0;
        }
        $mult = 1;
        $last = strtoupper(substr($s, -1));
        if ($last === 'K') { $mult = 1000; $s = substr($s, 0, -1); }
        if ($last === 'M') { $mult = 1000000; $s = substr($s, 0, -1); }
        return (int) ((float) $s * $mult);
    }

    // ------------------------------------------------------------------
    //  SCORING
    // ------------------------------------------------------------------

    /**
     * Scoring v3 (2026-10-04, rebuilt against LIVE feed truth).
     *
     * WHY v1/v2 failed (live evidence, three fetches): a composite THRESHOLD is
     * uncalibratable — real RSS traffic is 500-20K on thin geos and the shapes
     * vary wildly, so any fixed bar either blocks everything or admits junk.
     * v3 therefore separates CONCERNS:
     *   - HARD GATES (safety exclusions + a tiny traffic floor) decide ELIGIBILITY,
     *   - the SCORE only RANKS eligible trends (niche fit dominant, format next,
     *     traffic as tie-break, freshness last),
     *   - selection takes top-N by rank with a very low sanity floor.
     * Components: traffic 0-40 · format 0-30 · niche 0-40 · freshness 10.
     *
     * @NEW 1.9.0 public for tests.
     */
    public static function score_trend($item)
    {
        $title = (string) ($item['title'] ?? '');
        $low = ' ' . strtolower($title) . ' ';
        $reasons = array();

        // GATE 1 (hard): safety exclusions — encoded as score -100 so every
        // existing consumer (UI, logs, tests) keeps one vocabulary.
        $built_in = array('death', 'died', 'killed', 'kill', 'attack', 'war', 'crime', 'arrest', 'hospital', 'funeral', 'tragedy', 'victim', 'rape', 'suicide');
        $custom = array_filter(array_map('trim', explode(',', (string) get_option('mcqvs_trends_exclusions', ''))));
        foreach (array_merge($built_in, $custom) as $word) {
            if ($word !== '' && strpos($low, ' ' . strtolower($word) . ' ') !== false) {
                return array('score' => -100, 'reasons' => array('excluded:' . $word), 'gated' => 'safety');
            }
        }

        $t = (int) ($item['traffic'] ?? 0);
        // GATE 2 (hard): traffic floor — below this the trend is RSS noise.
        $floor = (int) get_option('mcqvs_trends_min_traffic', 200);
        if ($t < $floor) {
            return array('score' => 0, 'reasons' => array('traffic-floor:' . $t . '<' . $floor), 'gated' => 'traffic');
        }

        // RANK components.
        $score = 0;
        if ($t >= 500000) { $score += 40; $reasons[] = 'traffic:500K+'; }
        elseif ($t >= 200000) { $score += 34; $reasons[] = 'traffic:200K+'; }
        elseif ($t >= 50000) { $score += 26; $reasons[] = 'traffic:50K+'; }
        elseif ($t >= 10000) { $score += 18; $reasons[] = 'traffic:10K+'; }
        elseif ($t >= 1000) { $score += 10; $reasons[] = 'traffic:1K+'; }
        else { $score += 8; $reasons[] = 'traffic:floor'; }

        $fmt = 0;
        $is_matchup = (strpos($low, ' vs ') !== false || strpos($low, ' versus ') !== false);
        if ($is_matchup) { $fmt += 18; $reasons[] = 'format:matchup'; }
        if (preg_match('/\b(cup|trophy|final|semi-?final|election|day|festival|award|match|series|game|open|championship|derby|olympics|honors|awards)\b/', $low)) { $fmt += 8; $reasons[] = 'format:event'; }
        if (preg_match('/\b(weather|map|city|country|state|capital|river|mountain|island|region|center|centre)\b/', $low)) { $fmt += 6; $reasons[] = 'format:place'; }
        if (! $is_matchup && preg_match('/^(\w+ ){1,2}\w+$/', trim($title)) && ! preg_match('/\b(news|live|update|today|tonight|video|full episode|highlights)\b/', $low)) { $fmt += 5; $reasons[] = 'format:person'; }
        $fmt = min(30, $fmt);
        $score += $fmt;

        // Niche fit DOMINATES (0-40): pillar keywords 20 each; matchups inherit
        // sports-pillar affinity because a contest is always sports-quiz-able.
        $pillars = (string) get_option('mcqvs_trends_pillars', 'united states, usa, america, pakistan, india, state, city, geography, country, english, grammar, spelling, history, president, science, ocean, animal, wildlife, sport, football, cricket, movie, actor, music, space, weather');
        $fit = 0;
        foreach (array_filter(array_map('trim', explode(',', $pillars))) as $kw) {
            if ($kw !== '' && strpos($low, ' ' . strtolower($kw) . ' ') !== false) {
                $fit += 20;
            }
        }
        if ($is_matchup && preg_match('/\b(sport|cricket|football|baseball|basketball|tennis|hockey)\b/', $pillars)) {
            $fit += 20;
            $reasons[] = 'niche:matchup-sport';
        }
        $fit = min(40, $fit);
        $score += $fit;
        if ($fit) { $reasons[] = 'niche:' . $fit; }

        $score += 10;
        $reasons[] = 'fresh:10';

        return array('score' => $score, 'reasons' => $reasons, 'gated' => null);
    }

    /**
     * Selection v3: eligibility gates first (safety, traffic floor), then rank
     * desc, sanity floor (mcqvs_trends_min_score, default 20), cap per_day.
     *
     * @return array list of {item, score, reasons}
     */
    public static function qualified_trends()
    {
        $store = get_option('mcqvs_trends_today', array());
        if (! is_array($store) || ($store['date'] ?? '') !== gmdate('Y-m-d') || empty($store['items'])) {
            return array();
        }
        $floor_score = (int) get_option('mcqvs_trends_min_score', 20);
        $cap = max(1, min(3, (int) get_option('mcqvs_trends_per_day', 2)));
        $queued = get_option('mcqvs_trends_queued', array());
        if (! is_array($queued)) { $queued = array(); }
        $rows = array();
        foreach ($store['items'] as $it) {
            if (isset($queued[$it['hash']])) {
                continue;
            }
            $s = self::score_trend($it);
            if (! empty($s['gated'])) {
                continue; // safety or traffic floor
            }
            if ($s['score'] < $floor_score) {
                continue; // sanity floor (thin-day noise)
            }
            $rows[] = array('item' => $it, 'score' => $s['score'], 'reasons' => $s['reasons']);
        }
        usort($rows, function ($a, $b) {
            if ($b['score'] !== $a['score']) { return $b['score'] <=> $a['score']; }
            return strcmp((string) $a['item']['title'], (string) $b['item']['title']);
        });
        return array_slice($rows, 0, $cap);
    }

    // ------------------------------------------------------------------
    //  GENERATE + QUEUE (reuses existing job pipeline)
    // ------------------------------------------------------------------

    /**
     * For each qualified trend: 1 evergreen-safe MCQ via the approved 'trend'
     * context, then a shorts job through the existing job repository.
     *
     * @return array {queued:int, titles:array, errors:array}
     */
    public static function generate_and_queue()
    {
        $rows = self::qualified_trends();
        $out = array('queued' => 0, 'titles' => array(), 'errors' => array());
        if (empty($rows)) {
            self::log('trends.none_qualified', array());
            return $out;
        }
        if (! class_exists('VS_AJAX_AI_Quiz_Handler') || ! class_exists('VS_Job_Repository')) {
            $out['errors'][] = 'missing dependencies';
            return $out;
        }
        $handler = VS_AJAX_AI_Quiz_Handler::get_instance();
        $queued = get_option('mcqvs_trends_queued', array());
        if (! is_array($queued)) { $queued = array(); }

        foreach ($rows as $row) {
            $trend = $row['item']['title'];
            $qs = $handler->generate_topic_quiz_data($trend, 1, 'trend', (array) ($row['item']['headlines'] ?? array()));
            if (is_wp_error($qs) || empty($qs[0]['question'])) {
                $out['errors'][] = $trend . ': ' . (is_wp_error($qs) ? $qs->get_error_message() : 'empty');
                self::log('trends.generate_failed', array('trend' => $trend));
                continue;
            }
            $q = $qs[0];
            $question = sanitize_text_field((string) $q['question']);
            $settings = array(
                'topic_name'    => 'Trend: ' . $trend,
                'quizName'      => $trend,
                'template'      => class_exists('VS_Content_Planner') ? VS_Content_Planner::guess_template_for_topic($trend, '') : 'trivia',
                'currentTemplate' => '',
                'save_mode'     => get_option('mcqvs_delivery_mode', 'local'),
                'save_mode_video_format' => 'shorts',
                'videoFormat'   => 'shorts',
                'series'        => 'Trend Jack',
                'experiment'    => 'trend',
                'title_override' => $question, // question-first formula
                'hookText'      => mb_substr($trend, 0, 60),
                'hookVisible'   => true,
                'ctaText'       => class_exists('VS_Content_Planner') ? VS_Content_Planner::resolve_cta(array(), 'trend|' . $question) : 'Comment your score 👇',
                'speakCta'      => true,
                'hashtags'      => '#trending #quiz #shorts',
                'showExplanation' => false,
                'seo'           => array('title' => $question, 'description' => 'Trending today: ' . $trend . '. One question, ten seconds, zero mercy.', 'hashtags' => array('#trending', '#quiz', '#shorts'), 'tags' => array($trend, 'quiz', 'trivia'), 'source' => 'trend'),
            );
            $settings['currentTemplate'] = $settings['template'];
            $quiz = array(array(
                'question'    => $question,
                'options'     => array_values((array) $q['options']),
                'correct'     => (int) $q['correct'],
                'explanation' => sanitize_text_field((string) ($q['explanation'] ?? '')),
                'difficulty'  => sanitize_text_field((string) ($q['difficulty'] ?? 'medium')),
            ));
            $job_id = VS_Job_Repository::init()->create_job(array(
                'topic_id'       => 0,
                'question_count' => 1,
                'platform'       => 'all',
                'status'         => VS_Job_Status::READY_FOR_RENDER,
                'quiz_data'      => wp_json_encode($quiz),
                'settings'       => wp_json_encode($settings),
                'scheduled_at'   => gmdate('Y-m-d H:i:s'),
            ));
            if (is_wp_error($job_id)) {
                $out['errors'][] = $trend . ': ' . $job_id->get_error_message();
                continue;
            }
            $queued[$row['item']['hash']] = array('date' => gmdate('Y-m-d'), 'job' => $job_id);
            $out['queued']++;
            $out['titles'][] = $question;
            self::log('trends.queued', array('trend' => $trend, 'score' => $row['score'], 'job' => $job_id));
        }
        update_option('mcqvs_trends_queued', $queued, false);
        return $out;
    }

    // ------------------------------------------------------------------
    //  AJAX + UI helpers
    // ------------------------------------------------------------------

    public static function ajax_fetch_now()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) { wp_send_json_error('Access denied'); }
        $r = self::fetch_trends();
        if (is_wp_error($r)) { wp_send_json_error($r->get_error_message()); }
        // @FIX 1.9.1: transparency — return the TOP-SCORED trends regardless of
        // the threshold, with scores + reasons, so "qualified 0" is explainable
        // from the UI instead of opaque.
        $store = get_option('mcqvs_trends_today', array());
        $min = (int) get_option('mcqvs_trends_min_score', 20);
        $rows = array();
        foreach ((is_array($store) && ! empty($store['items']) ? $store['items'] : array()) as $it) {
            $s = self::score_trend($it);
            $rows[] = array(
                'title'     => $it['title'],
                'geo'       => $it['geo'] ?? '',
                'traffic'   => $it['traffic'],
                'headlines' => $it['headlines'] ?? array(),
                'score'     => $s['score'],
                'reasons'   => implode(',', $s['reasons']),
                'gated'     => $s['gated'],
                'qualified' => ($s['gated'] === null && $s['score'] >= $min),
            );
        }
        usort($rows, function ($a, $b) { return $b['score'] <=> $a['score']; });
        wp_send_json_success(array_merge($r, array(
            'qualified' => count(array_filter($rows, function ($x) use ($min) { return $x['score'] >= $min; })),
            'min_score' => $min,
            'min_traffic' => (int) get_option('mcqvs_trends_min_traffic', 200),
            'top'       => array_slice($rows, 0, 8),
        )));
    }

    public static function ajax_queue_now()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) { wp_send_json_error('Access denied'); }
        wp_send_json_success(self::generate_and_queue());
    }

    private static function log($event, array $data)
    {
        if (class_exists('VS_Error_Logger')) {
            $parts = array();
            foreach ($data as $k => $v) { if (is_scalar($v)) { $parts[] = $k . '=' . $v; } }
            VS_Error_Logger::get_instance()->log('MCQVS ' . $event . ($parts ? ' ' . implode(' ', $parts) : ''), 'info', array('_type' => 'trends', 'event' => $event, 'data' => $data));
        }
    }
}
