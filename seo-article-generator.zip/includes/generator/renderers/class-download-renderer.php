<?php
/**
 * DOWNLOAD PORTAL RENDERER
 *
 * @MODIFIED 2026-06-14 — Gutenberg block recovery fix (class-download-renderer.php):
 *
 * WHY: The stored innerHTML for the core/group wrapper had wrong class order and
 * wrong CSS property order compared to what Gutenberg's JS save() function
 * produces via useBlockProps.save(). Gutenberg validates blocks by re-running
 * the JS save() and comparing the output with the stored innerHTML. Any
 * difference triggers "Block contains unexpected or invalid content" recovery.
 *
 * WHAT CHANGED:
 * 1. Removed duplicated dead code block (orphaned safety/return code outside any
 *    method) that would have caused a PHP fatal error.
 * 2. Removed 'metadata' attribute from core/group block attrs — it is not defined
 *    in core/group block.json and the JS save() ignores it; including unknown attrs
 *    can cause validation mismatches.
 * 3. Replaced hardcoded innerHTML wrapper string with compute_group_wrapper() which
 *    dynamically computes the <div> opening tag using the PHP style engine. This
 *    ensures the class order (color classes before border classes) and CSS property
 *    order (border-color, border-radius, border-width) exactly match the JS output.
 *
 * FILES: class-download-renderer.php (this file)
 */

namespace SEO_Article_Generator\Generator\Renderers;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Handles rendering of Download Portal section
 *
 * @MODIFIED 2026-03-08: Added last-mile normalization via Download_Link_Helper,
 *   removed href="#" fallback, added is_meaningful_text, improved collect_valid_links.
 */
class Download_Renderer
{
	use \SEO_Article_Generator\Traits\Markdown_Processor;

	/**
	 * Format download section.
	 *
	 * @param array  $download_section Download section data.
	 * @param string $os_support       OS support string.
	 * @param array  $safety           Safety data.
	 * @param array  $tech_specs       Tech specs.
	 * @param string $anchor           Download section anchor. Defaults to schema value.
	 * @param int    $post_id          Post ID for reading existing hero download link text.
	 * @param array  $regen_sections   Sections being regenerated. If 'download' is in this list,
	 *   link continuity is disabled to ensure fresh canonical links are used.
	 * @return string Serialized block HTML.
	 */
	public function render($download_section, $os_support = '', $safety = array(), $tech_specs = array(), $anchor = '', $post_id = 0, $regen_sections = array())
	{
		// [AUDIT FIX] Derive anchor from Article_Schema so render() and render_blocks() 
		// are always consistent. Caller may pass an explicit override; if not, use the
		// schema's registered anchor for 'download' as the single source of truth.
		if ($anchor === '') {
			$anchor = class_exists(\SEO_Article_Generator\Generator\Article_Schema::class)
				? \SEO_Article_Generator\Generator\Article_Schema::get_anchor('download')
				: 'download-portal';
		}

		return serialize_blocks($this->render_blocks($download_section, $os_support, $safety, $tech_specs, $anchor, $post_id, $regen_sections));
	}

/**
	 * Render download section as block array.
	 *
	 * @MODIFIED 2026-04-24: Added $post_id for SSOT text preservation from seogenherodata.
	 * @MODIFIED 2026-08-12: Added $regen_sections to disable link continuity when download
	 *   section is explicitly regenerated (partial regen).
	 *
	 * @param array $download_section Download section data.
	 * @param string $os_support OS support string.
	 * @param array $safety Safety data.
	 * @param array $tech_specs Tech specs.
	 * @param string $anchor Download section anchor. Empty = derive from schema.
	 * @param int $post_id Post ID for reading existing hero link text.
	 * @param array $regen_sections Sections being regenerated. If 'download' is in this list,
	 *   link continuity is disabled to ensure fresh canonical links are used.
	 * @return array Block array.
	 */
	public function render_blocks($download_section, $os_support = '', $safety = array(), $tech_specs = array(), $anchor = '', $post_id = 0, $regen_sections = array())
	{
		// [AUDIT FIX] Single source of truth for the download anchor — same logic as render().
		// Ensures direct callers of render_blocks() are never stuck on a stale hardcoded string.
		if ($anchor === '') {
			$anchor = class_exists(\SEO_Article_Generator\Generator\Article_Schema::class)
				? \SEO_Article_Generator\Generator\Article_Schema::get_anchor('download')
				: 'download-portal';
		}

		if (empty($download_section) || ! is_array($download_section)) {
			return array();
		}

		$software_name = $this->normalize_software_name(
			isset($tech_specs['software_name']) ? $tech_specs['software_name'] : (
				isset($download_section['software_name']) ? $download_section['software_name'] : ''
			)
		);

		$file_size = $this->normalize_file_size($tech_specs);
		$links     = $this->collect_valid_links($download_section, $software_name);

		if (empty($links)) {
			return array();
		}

		$heading = 'Download' . ($software_name !== '' ? ' ' . $software_name : '');
		$inner_blocks = array();

		// Heading with anchor for TOC detection
		$heading_block = \SEO_Article_Generator\Generator\Content_Formatter::heading_block($heading, 2, $anchor);
		$inner_blocks[] = $heading_block;

		// File size
		if ($file_size !== '') {
			$inner_blocks[] = array(
				'blockName'    => 'core/paragraph',
				'attrs'        => array(),
				'innerBlocks'  => array(),
				'innerHTML'    => '<p><strong>File size:</strong> ' . esc_html($file_size) . '</p>',
				'innerContent' => array('<p><strong>File size:</strong> ' . esc_html($file_size) . '</p>'),
			);
		}

		// OS support
		if (! empty($os_support) && $this->is_meaningful_text($os_support)) {
			$inner_blocks[] = array(
				'blockName'    => 'core/paragraph',
				'attrs'        => array(),
				'innerBlocks'  => array(),
				'innerHTML'    => '<p><strong>OS support:</strong> ' . esc_html(trim((string) $os_support)) . '</p>',
				'innerContent' => array('<p><strong>OS support:</strong> ' . esc_html(trim((string) $os_support)) . '</p>'),
			);
		}

	// Download links
	$link_blocks = $this->render_links_blocks($links, $software_name, $post_id, $regen_sections);
	$inner_blocks = array_merge($inner_blocks, $link_blocks);

		// Safety verdict
		$safety_line = $this->extract_safety_line($safety);
		if ($safety_line !== '') {
			$inner_blocks[] = array(
				'blockName'    => 'core/paragraph',
				'attrs'        => array(),
				'innerBlocks'  => array(),
				'innerHTML'    => '<p><strong>Safety:</strong> ' . esc_html($safety_line) . '</p>',
				'innerContent' => array('<p><strong>Safety:</strong> ' . esc_html($safety_line) . '</p>'),
			);
		}

		$inner_html = serialize_blocks($inner_blocks);

		// Build block attrs WITHOUT 'metadata' — it's not in core/group block.json
		// and the JS save() ignores it. Including unknown attrs may cause validation issues.
		$group_attrs = array(
			'className'       => 'seo-gen-download-portal',
			'style'           => array(
				'border' => array(
					'width'  => '2px',
					'color'  => 'var(--nv-c-2)',
					'radius' => array(
						'topLeft'     => '10px',
						'topRight'    => '10px',
						'bottomLeft'  => '10px',
						'bottomRight' => '10px',
					),
				),
			),
			'backgroundColor' => 'nv-light-bg',
			'layout'          => array('type' => 'constrained'),
		);

		// Compute wrapper HTML dynamically to match JS save() output exactly.
		// The JS save() calls useBlockProps.save() which computes class and style
		// from block attrs via the block supports system. We replicate that here.
		$wrapper = self::compute_group_wrapper($group_attrs);

		return array(
			array(
				'blockName'    => 'core/group',
				'attrs'        => $group_attrs,
				'innerBlocks'  => $inner_blocks,
				'innerHTML'    => $wrapper . "\n" . $inner_html . "\n" . '</div>',
				'innerContent' => array($wrapper . "\n" . $inner_html . "\n" . '</div>'),
			),
		);
	}

	/**
	 * Compute the opening <div> wrapper for a core/group block,
	 * matching the exact output of the JS save() function.
	 *
	 * The JS save() calls useBlockProps.save() → getBlockWrapperAttributes()
	 * which processes block supports in registration order:
	 *   1. color support → backgroundColor classes
	 *   2. border support → border classes
	 *   3. All supports → style attribute via style engine
	 *
	 * @param array $attrs Block attributes.
	 * @return string The opening <div> tag with computed class and style.
	 */
	private static function compute_group_wrapper($attrs) {
		// --- Compute classes (matching JS block supports order) ---
		// Gutenberg's useBlockProps.save() processes block supports in this order:
		//   1. wp-block-group (base)
		//   2. className (custom)
		//   3. border support → has-border-color
		//   4. color support → has-{slug}-background-color has-background
		$classes = array('wp-block-group');

		// className attribute
		if (!empty($attrs['className'])) {
			$classes[] = $attrs['className'];
		}

		// Border support — border.color generates has-border-color
		// (Gutenberg processes border BEFORE color in useBlockProps.save())
		if (!empty($attrs['style']['border']['color'])) {
			$classes[] = 'has-border-color';
		}

		// Color support — backgroundColor generates has-{slug}-background-color has-background
		if (!empty($attrs['backgroundColor'])) {
			$classes[] = 'has-' . $attrs['backgroundColor'] . '-background-color';
			$classes[] = 'has-background';
		}

		// --- Compute style (matching JS style engine property order) ---
		// Gutenberg's JS style engine outputs border properties in this order:
		//   border-color, border-width, border-radius (TL, TR, BL, BR)
		// PHP's wp_style_engine_get_styles() may reorder - build CSS manually
		// to guarantee exact match with Gutenberg's JS save() output.
		$style_str = '';
		$border = isset($attrs['style']['border']) ? $attrs['style']['border'] : array();
		if (!empty($border)) {
			$parts = array();
			if (!empty($border['color'])) {
				$parts[] = 'border-color:' . $border['color'];
			}
			if (!empty($border['width'])) {
				$parts[] = 'border-width:' . $border['width'];
			}
			if (!empty($border['radius'])) {
				$r = $border['radius'];
				if (!empty($r['topLeft']))     $parts[] = 'border-top-left-radius:' . $r['topLeft'];
				if (!empty($r['topRight']))    $parts[] = 'border-top-right-radius:' . $r['topRight'];
				if (!empty($r['bottomLeft']))  $parts[] = 'border-bottom-left-radius:' . $r['bottomLeft'];
				if (!empty($r['bottomRight'])) $parts[] = 'border-bottom-right-radius:' . $r['bottomRight'];
			}
			$style_str = implode(';', $parts);
		}

		// --- Build opening tag ---
		$tag = '<div class="' . \esc_attr(implode(' ', $classes)) . '"';
		if ($style_str !== '') {
			$tag .= ' style="' . \esc_attr($style_str) . '"';
		}
		$tag .= '>';

		return $tag;
	}

/**
	 * Render grouped download links as blocks.
	 *
	 * @MODIFIED 2026-04-24: Added $post_id for SSOT text preservation.
	 * On updates, reads existing seogenherodata.download_links[].text and passes
	 * it to format_download_text() so user-customized anchor text survives version updates.
	 * @MODIFIED 2026-08-12: Added $regen_sections to disable link continuity when download
	 *   section is explicitly regenerated (partial regen).
	 *
	 * @param array  $links           Validated links array.
	 * @param string $software_name   Software name.
	 * @param int    $post_id         Post ID for reading existing hero link text.
	 * @param array  $regen_sections  Sections being regenerated. If 'download' is in this list,
	 *   link continuity is disabled to ensure fresh canonical links are used.
	 * @return array Block array.
	 */
private function render_links_blocks($links, $software_name, $post_id = 0, $regen_sections = array())
    {
        // Canonical link text already includes accepted manual edits. No separate read authority.
        $blocks = array();
        $grouped = \SEO_Article_Generator\Generator\Download_Link_Helper::group_links_by_platform($links);

        foreach ($grouped as $platform => $platform_links) {
            if (empty($platform_links)) {
                continue;
            }

            // @MODIFIED 2026-08-12: Track (url|variant) keys instead of text to prevent
            // false duplicate detection when stale text is carried over from old versions.
            $seen_link_keys = array();

            // Filter out links with empty URLs before rendering heading,
            // preventing bare platform headings (e.g. "Android") with no clickable links.
            $platform_links = array_values(array_filter($platform_links, function ($pl) {
                return ! empty($pl['url']);
            }));
            if (empty($platform_links)) {
                continue;
            }

            // Platform heading
            $blocks[] = array(
                'blockName' => 'core/heading',
                'attrs' => array('level' => 3),
                'innerBlocks' => array(),
                'innerHTML' => '<h3 class="wp-block-heading">' . esc_html($platform) . '</h3>',
                'innerContent' => array('<h3 class="wp-block-heading">' . esc_html($platform) . '</h3>'),
            );

            // Download links for this platform
            foreach ($platform_links as $link) {
                // @MODIFIED 2026-03-08: Skip links with empty/invalid URLs instead of rendering href="#"
                $url = isset($link['url']) ? esc_url($link['url']) : '';
                if ($url === '') {
                    continue;
                }

                $text = \SEO_Article_Generator\Generator\Download_Link_Helper::format_download_text($link, $software_name);

                // Diagnostic Logging
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log(sprintf(
                        'SEO Article Generator Link Classification: {url: "%s", detected_platform: "%s", detected_variant: "%s", final_text: "%s", source_text: "%s"}',
                        $link['url'] ?? '',
                        $link['platform'] ?? '',
                        $link['variant'] ?? '',
                        $text,
                        $link['text'] ?? ''
                    ));
                }

                // Uniqueness Guard - Drop duplicate links
                // @MODIFIED 2026-08-12: Use (url + variant) as uniqueness key instead of text.
                // This prevents false collisions when stale text is carried over from old versions
                // (e.g. multiple links getting "Alpha 1 nightly" text). Each distinct URL+variant
                // combination should render as a separate link regardless of display text.
                $variant = isset($link['variant']) ? strtolower(trim((string) $link['variant'])) : 'standard';
                $uniqueness_key = trim((string) ($link['url'] ?? '')) . '|' . $variant;
                if (in_array($uniqueness_key, $seen_link_keys, true)) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log(sprintf('SEO Article Generator Warning: Duplicate link (url+variant) detected in platform %s for software %s: %s (URL: %s). Dropping duplicate link.', $platform, $software_name, $text, $url));
                    }
                    continue;
                }
                $seen_link_keys[] = $uniqueness_key;

                $html = '<p><a href="' . $url . '" target="_blank" rel="nofollow noopener">' . \wp_kses_post(self::process_markdown($text)) . '</a></p>';

                $blocks[] = array(
                    'blockName' => 'core/paragraph',
					'attrs' => array(),
					'innerBlocks' => array(),
					'innerHTML' => $html,
					'innerContent' => array($html),
				);
			}
		}

	return $blocks;
	}

	/**
	* Collect valid links from download section data.
	 *
	 * @MODIFIED 2026-03-08: Uses helper normalize_links for last-mile validation
	 *
	 * @param array  $download_section Download section data.
	 * @param string $software_name    Software name.
	 * @return array Validated links.
	 */
	private function collect_valid_links($download_section, $software_name = '')
	{
		$raw_links = array();

		if (! empty($download_section['links']) && is_array($download_section['links'])) {
			$raw_links = $download_section['links'];
		} else {
			if (! empty($download_section['primary_link']) && is_array($download_section['primary_link'])) {
				$raw_links[] = $download_section['primary_link'];
			}

			if (! empty($download_section['alternate_links']) && is_array($download_section['alternate_links'])) {
				foreach ($download_section['alternate_links'] as $link) {
					if (is_array($link)) {
						$raw_links[] = $link;
					}
				}
			}
		}

		if (empty($raw_links)) {
			return array();
		}

		// @MODIFIED 2026-03-08: Last-mile normalization via shared helper contract
		return \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($raw_links);
	}

	/**
	 * Normalize software name for display.
	 *
	 * @param string $name Raw software name.
	 * @return string Cleaned name.
	 */
	private function normalize_software_name($name)
	{
		$name = trim(wp_strip_all_tags((string) $name));
		return $name;
	}

	/**
	 * Normalize file size from tech specs.
	 *
	 * @param array $tech_specs Tech specs array.
	 * @return string File size string or empty.
	 */
	private function normalize_file_size($tech_specs)
	{
		$value = '';

		if (isset($tech_specs['file_size'])) {
			$value = $tech_specs['file_size'];
		} elseif (isset($tech_specs['filesize'])) {
			$value = $tech_specs['filesize'];
		}

		$value = trim(wp_strip_all_tags((string) $value));

		if (! $this->is_meaningful_text($value)) {
			return '';
		}

		return $value;
	}

	/**
	 * Extract safety verdict line from safety data.
	 *
	 * @param array $safety Safety data array.
	 * @return string Safety line or empty.
	 */
	private function extract_safety_line($safety)
	{
		if (! is_array($safety) || empty($safety)) {
			return '';
		}

		$candidates = array(
			isset($safety['status']) ? $safety['status'] : '',
			isset($safety['verdict']) ? $safety['verdict'] : '',
			isset($safety['summary']) ? $safety['summary'] : '',
		);

		foreach ($candidates as $candidate) {
			$candidate = trim(wp_strip_all_tags((string) $candidate));
			if ($this->is_meaningful_text($candidate)) {
				return $candidate;
			}
		}

		return '';
	}

	/**
	 * Check if a text value is meaningful (not null/n/a/unknown/etc).
	 *
	 * @MODIFIED 2026-03-08: Added for placeholder text filtering
	 *
	 * @param string $value Text value to check.
	 * @return bool True if meaningful.
	 */
	private function is_meaningful_text($value)
	{
		$value = trim(wp_strip_all_tags((string) $value));

		if ($value === '') {
			return false;
		}

		$normalized = strtolower($value);

		return ! in_array($normalized, array(
			'null',
			'n/a',
			'na',
			'none',
			'unknown',
			'tbd',
			'-',
			'—',
			'varies',
			'not specified',
			'see website',
		), true);
	}

	/**
	 * Legacy CTA text sanitizer — preserved to avoid breaking internal calls.
	 *
	 * @param string $raw_text     Raw text.
	 * @param string $software_name Software name.
	 * @param string $platform     Platform.
	 * @param string $variant      Variant.
	 * @param string $license      License.
	 * @return string Sanitized text.
	 */
	private function sanitize_cta_text($raw_text, $software_name = '', $platform = '', $variant = '', $license = '')
	{
		return $raw_text;
	}
}
