<?php

/**
 * DeepSeek AI Client
 *
 * OpenAI-compatible DeepSeek API integration.
 *
 * @package DIT_TrendStudio
 * @since 2.15.12
 * @MODIFIED 2026-02-25 - Added DeepSeek provider (deepseek-chat / deepseek-reasoner) with JSON Output mode.
 * @deprecated 2.30.0 - Use Custom_Client with a 'deepseek' provider profile instead.
 *             DeepSeek\Client is superseded by the extensible custom provider system.
 *             AI_Provider_Factory routes 'deepseek' strategy to Custom_Client automatically.
 *             This class is kept for backward compatibility only.
 */

namespace DIT\TrendStudio\Integrations\DeepSeek;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * DeepSeek API client (OpenAI-compatible /chat/completions)
 *
 * @deprecated 2.30.0 Use Custom_Client with a 'deepseek' provider profile instead.
 * @see https://api-docs.deepseek.com/
 */
class Client implements AIProviderInterface
{
    use AI_Network_Trait;

    /**
     * DeepSeek API base URL.
     */
    private const BASE_URL = 'https://api.deepseek.com';

    /**
     * Chat completion endpoint.
     */
    private const CHAT_ENDPOINT = '/chat/completions';

    /**
     * API key.
     *
     * @var string
     */
    private string $api_key;

    /**
     * Logger.
     *
     * @var Logger
     */
    protected Logger $logger;

    /**
     * Shared prompt/schema builder.
     *
     * @var PromptSchemaBuilder
     */
    private PromptSchemaBuilder $promptSchema;

    /**
     * Visual manifest service.
     *
     * @var VisualManifestService
     */
    private VisualManifestService $visuals;

    /**
     * @param string $api_key DeepSeek API key
     * @param Logger $logger Logger
     */
    public function __construct(string $api_key, Logger $logger)
    {
        $this->provider_slug = 'deepseek';
        $this->api_key = \trim($api_key);
        $this->logger = $logger;
        $this->promptSchema = new PromptSchemaBuilder($logger);
        $this->visuals = new VisualManifestService();
    }

    /**
     * Increment DeepSeek API call count.
     */
    private static function increment_call_count(): void
    {
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('deepseek');
    }

    /**
     * Get API key from settings.
     *
     * @return string
     */
    public static function get_api_key(): string
    {
        return (string) \get_option('dit_ts_deepseek_api_key', '');
    }

    /**
     * Get selected DeepSeek model.
     *
     * @return string
     */
    public static function get_model_id(): string
    {
        $custom = (string) \get_option('dit_ts_deepseek_model_custom', '');
        if ($custom !== '') {
            return $custom;
        }
        return (string) \get_option('dit_ts_deepseek_model', 'deepseek-chat');
    }

    /**
     * @inheritDoc
     */
    public function get_model(): string
    {
        return self::get_model_id();
    }

    /**
     * Test API connection via balance endpoint.
     *
     * @return array
     * @throws AI_Exception
     */
    public function test_connection(): array
    {
        $response = \wp_remote_get(self::BASE_URL . '/user/balance', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
            ],
            'timeout' => 15
        ]);

        if (\is_wp_error($response)) {
            throw new AI_Exception('Connection failed: ' . $response->get_error_message());
        }

        $code = (int) \wp_remote_retrieve_response_code($response);

        if ($code !== 200) {
            throw new AI_Exception('API returned error code: ' . $code);
        }

        return [
            'status'   => 'connected',
            'provider' => 'deepseek',
        ];
    }

    /**
     * Probe quota availability.
     *
     * @return bool
     */
    public function probe_quota(): bool
    {
        try {
            $res = $this->chat_completion(array(
                array('role' => 'system', 'content' => 'Return OK.'),
                array('role' => 'user', 'content' => 'Ping'),
            ), false);
            return !empty($res);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Get user balance via GET /user/balance.
     *
     * @return array
     * @throws AI_Exception
     */
    public function get_balance(): array
    {
        if ($this->api_key === '') {
            throw new AI_Exception('DeepSeek API key missing.');
        }

        $url = self::BASE_URL . '/user/balance';

        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept'        => 'application/json',
            ),
            'timeout' => 30,
        );

        $response = \wp_remote_get($url, $args);
        if (\is_wp_error($response)) {
            throw new AI_Exception('DeepSeek balance request failed: ' . $response->get_error_message());
        }

        $code = (int) \wp_remote_retrieve_response_code($response);
        $raw  = (string) \wp_remote_retrieve_body($response);

        if ($code !== 200) {
            throw new AI_Exception('DeepSeek balance endpoint returned ' . $code . ': ' . \substr($raw, 0, 500));
        }

        $data = \json_decode($raw, true);
        return \is_array($data) ? $data : array();
    }

    /**
     * @inheritDoc
     */
    public function generate(array $prompt_data): array
    {
        $visual_manifest = $prompt_data['source_visual_map'] ?? [];
        $output_schema   = '';

        $bundle = $this->promptSchema->build_perplexity_writing_bundle(
            $prompt_data,
            [], // No research for this path
            $visual_manifest,
            $output_schema,
            $this->visuals,
            10
        );

        $this->logger->info('Calling DeepSeek API for writing');

        $messages = [
            [
                'role'    => 'system',
                'content' => $bundle['system_prompt']
            ],
            [
                'role'    => 'user',
                'content' => $bundle['user_prompt']
            ]
        ];

        return $this->chat_completion($messages, true, $bundle['output_schema'], $visual_manifest);
    }

    /**
     * @inheritDoc
     */
    public function generateFromResearch(array $promptData, array $researchData): array
    {
        $visual_manifest = [];
        $output_schema   = '';

        $bundle = $this->promptSchema->build_perplexity_writing_bundle(
            $promptData,
            $researchData,
            $visual_manifest,
            $output_schema,
            $this->visuals,
            10
        );

        $this->logger->info('Calling DeepSeek API for writing from research');

        $messages = [
            [
                'role'    => 'system',
                'content' => $bundle['system_prompt']
            ],
            [
                'role'    => 'user',
                'content' => $bundle['user_prompt']
            ]
        ];

        return $this->chat_completion($messages, true, $bundle['output_schema'], $visual_manifest);
    }

    /**
     * @inheritDoc
     */
    public function generateCustomJson(string $prompt): array
    {
        self::increment_call_count();

        $messages = array(
            array('role' => 'system', 'content' => 'Return VALID JSON ONLY.'),
            array('role' => 'user', 'content' => $prompt),
        );

        $article = $this->chat_completion($messages, true);
        return $article;
    }

    /**
     * Internal Chat Completion Wrapper
     */
    private function chat_completion(array $messages, bool $json_mode = true, string $output_schema = '', array $visual_manifest = []): array
    {
        self::increment_call_count();

        $body = [
            'model'    => self::get_model_id(),
            'messages' => $messages,
            'stream'   => false,
            'temperature' => 0.7,
            'max_tokens'  => (int) \get_option('dit_ts_ai_max_output_tokens', 32768),
        ];

        if ($json_mode) {
            $body['response_format'] = ['type' => 'json_object'];
        }

        $url = self::BASE_URL . self::CHAT_ENDPOINT;

        $response = $this->call_api_with_retry($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => \wp_json_encode($body),
            'timeout' => 120,
        ]);

        if (\is_wp_error($response)) {
            throw new AI_Exception('DeepSeek API request failed: ' . $response->get_error_message());
        }

$code = (int) \wp_remote_retrieve_response_code($response);
            $raw_body = \wp_remote_retrieve_body($response);

            // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
            if ($code === 429 || $code === 403) {
                $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                    $headers = \wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse('deepseek', $code, $raw_body, (array) $headers);
                    Quota_State_Manager::calibrate_from_error('deepseek', $error_info);
                }
                $reason = class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry';
                throw new AI_Exception("DeepSeek rate limit ({$error_info['error_type']}).", array(
                    'reason' => $reason,
                    'provider' => 'deepseek',
                    'error_class' => $error_info['error_type'],
                    'quota_bucket' => $error_info['quota_bucket'],
                    'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                    'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                    'http_code' => $code,
                    'error_body' => \substr($raw_body, 0, 500),
                ));
            }

            if ($code !== 200) {
                $this->logger->error('DeepSeek API error', ['code' => $code, 'body' => $raw_body]);
                throw new AI_Exception("DeepSeek API returned {$code}: " . \substr($raw_body, 0, 500));
            }

            // @MODIFIED 2026-04-23 - Three-Layer Intelligence: record success
            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success('deepseek', $this->model_id ?? 'deepseek-chat');
            }

        $data = \json_decode($raw_body, true);
        $content = $data['choices'][0]['message']['content'] ?? '';

        if (empty($content)) {
            throw new AI_Exception('Empty response from DeepSeek API');
        }

        $clean  = Sanitizer::clean((string) $content);
        $parsed = Sanitizer::parse($clean);

        if (!\is_array($parsed)) {
            throw new AI_Exception(
                'Failed to parse DeepSeek JSON response',
                array(
                    'sanitizer_error' => Sanitizer::get_last_error(),
                    'content_preview' => \substr((string) $content, 0, 1200),
                )
            );
        }

        return $this->apply_visual_manifest($parsed, $visual_manifest);
    }

    /**
     * Apply visual manifest to generated article.
     */
    private function apply_visual_manifest(array $article, array $visual_manifest): array
    {
        if (empty($visual_manifest)) {
            return $article;
        }
        return $article;
    }
}
