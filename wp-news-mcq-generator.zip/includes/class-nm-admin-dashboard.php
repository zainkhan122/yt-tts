<?php

/**
 * Admin Dashboard Class
 * Renders the main MCQ Generator dashboard in WP Admin.
 * Version: 2.2 - Fixed CSS alignment
 *
 * @MODIFIED: Added 'display: block' and 'height' to .nm-stat-icon
 * and .nm-stat-value to prevent theme CSS conflicts and overlapping.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Admin_Dashboard {


	public static function init() {
		// Submenu registration moved to NM_Admin_Menu::init() (priority 6).
		// Enqueue assets (Chart.js) only on our dashboard.
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
	}

	/**
	 * Register the dashboard submenu page.
	 */
	public static function register_submenu() {
		add_submenu_page(
			'nm_mcq_generator', // Parent Slug
			'Dashboard',       // Page title
			'📊 Dashboard',    // Menu title
			'manage_options',  // Capability
			'nm_dashboard',    // Menu slug (unique)
			array( self::class, 'render' ) // Callback
		);
	}

	/**
	 * Enqueue assets (Chart.js) only on our dashboard
	 */
	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, 'page_nm_dashboard' ) === false && $hook !== 'toplevel_page_nm_mcq_generator' ) {
			return;
		}

		wp_enqueue_script(
			'nm-chartjs',
			'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js',
			array(),
			'3.9.1',
			true
		);
	}

	/**
	 * RENDER DASHBOARD PAGE
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}
		?>
		<div class="wrap nm-dashboard">
			<h1 class="nm-dashboard-title">
				📊 MCQ Generator Dashboard
				<button id="nm-refresh-dashboard" class="button button-secondary" style="margin-left: 20px;">
					🔄 Refresh Data
				</button>
			</h1>

			<div id="nm-stats-cards" class="nm-stats-grid">
				<div class="nm-stat-card nm-card-loading">
					<div class="nm-spinner"></div>
				</div>
			</div>

			<div class="nm-charts-row">
				<div class="nm-chart-container">
					<h2>🔍 Duplicate Detection (Last 7 Days)</h2>
					<canvas id="nm-duplicate-chart"></canvas>
					<div id="nm-duplicate-stats" class="nm-chart-legend"></div>
				</div>

				<div class="nm-chart-container">
					<h2>📈 Generation Activity (Today)</h2>
					<canvas id="nm-activity-chart"></canvas>
					<div id="nm-activity-stats" class="nm-chart-legend"></div>
				</div>
			</div>

			<div class="nm-bottom-row">
				<div class="nm-activity-log">
					<h2>📋 Recent Activity</h2>
					<div class="nm-filter-controls">
						<select id="nm-log-filter">
							<option value="all">All Activities</option>
							<option value="success">Successes Only</option>
							<option value="duplicate">Duplicates Only</option>
							<option value="error">Errors Only</option>
						</select>
						<button id="nm-clear-log" class="button button-small">Clear Log</button>
					</div>
					<div id="nm-activity-log-content" class="nm-log-content">
						<div class="nm-spinner"></div>
					</div>
				</div>

				<div class="nm-system-health">
					<h2>💚 System Health</h2>
					<div id="nm-health-content">
						<div class="nm-spinner"></div>
					</div>
				</div>
			</div>

			<div class="nm-bottom-row">
				<div class="nm-top-topics">
					<h2>🏆 Top Topics</h2>
					<div id="nm-top-topics-content">
						<div class="nm-spinner"></div>
					</div>
				</div>

				<div class="nm-reported-mcqs">
					<h2>🚨 Reported MCQs</h2>
					<div id="nm-reported-content">
						<div class="nm-spinner"></div>
					</div>
				</div>
			</div>
		</div>

		<style>
			.nm-dashboard {
				margin: 20px 20px 40px 0;
			}

			.nm-dashboard-title {
				font-size: 28px;
				margin-bottom: 30px;
				display: flex;
				align-items: center;
			}

			.nm-stats-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
				gap: 20px;
				margin-bottom: 30px;
			}

			.nm-stat-card {
				background: #fff;
				border: 1px solid #ddd;
				border-radius: 8px;
				padding: 20px;
				text-align: center;
				box-shadow: 0 2px 4px rgba(0, 0, 0, .05);
				transition: transform .2s, box-shadow .2s;
			}

			.nm-stat-card:hover {
				transform: translateY(-2px);
				box-shadow: 0 4px 8px rgba(0, 0, 0, .1);
			}

			.nm-stat-icon {
				display: block;
				font-size: 40px;
				opacity: .8;
				height: 45px;
				/* Fixed height to prevent collapse */
				line-height: 45px;
				/* Center emoji vertically */
				overflow: hidden;
				/* Hide theme's background-image text */
				text-overflow: ellipsis;
				white-space: nowrap;
			}

			.nm-stat-value {
				display: block;
				/* Force number to a new line */
				font-size: 36px;
				font-weight: 700;
				color: #0073aa;
				margin: 10px 0;
			}

			.nm-stat-label {
				display: block;
				/* Ensure label is also on its own line */
				font-size: 14px;
				color: #666;
				text-transform: uppercase;
				letter-spacing: .5px;
			}

			.nm-stat-mix-card {
				text-align: left;
			}

			.nm-stat-mix-body {
				margin-top: 10px;
				font-size: 12px;
				line-height: 1.4;
			}

			.nm-stat-mix-section+.nm-stat-mix-section {
				margin-top: 10px;
			}

			.nm-stat-mix-title {
				font-weight: 600;
				color: #444;
				margin-bottom: 4px;
				text-transform: uppercase;
				letter-spacing: .3px;
				font-size: 11px;
			}

			.nm-stat-mix-line {
				margin: 1px 0;
			}

			.nm-charts-row {
				display: grid;
				grid-template-columns: 1fr 1fr;
				gap: 20px;
				margin-bottom: 30px;
			}

			.nm-chart-container {
				background: #fff;
				border: 1px solid #ddd;
				border-radius: 8px;
				padding: 20px;
				box-shadow: 0 2px 4px rgba(0, 0, 0, .05);
			}

			.nm-chart-container h2 {
				margin: 0 0 20px 0;
				font-size: 18px;
				color: #23282d;
			}

			.nm-chart-container canvas {
				max-height: 300px;
			}

			.nm-chart-legend {
				margin-top: 15px;
				padding-top: 15px;
				border-top: 1px solid #eee;
				font-size: 13px;
			}

			.nm-bottom-row {
				display: grid;
				grid-template-columns: 2fr 1fr;
				gap: 20px;
				margin-bottom: 30px;
			}

			.nm-activity-log,
			.nm-system-health,
			.nm-top-topics,
			.nm-reported-mcqs {
				background: #fff;
				border: 1px solid #ddd;
				border-radius: 8px;
				padding: 20px;
				box-shadow: 0 2px 4px rgba(0, 0, 0, .05);
			}

			.nm-activity-log h2,
			.nm-system-health h2,
			.nm-top-topics h2,
			.nm-reported-mcqs h2 {
				margin: 0 0 15px 0;
				font-size: 18px;
				color: #23282d;
			}

			.nm-filter-controls {
				margin-bottom: 15px;
				display: flex;
				gap: 10px;
			}

			.nm-filter-controls select {
				flex: 1;
				padding: 5px 10px;
			}

			.nm-log-content {
				max-height: 400px;
				overflow-y: auto;
				border: 1px solid #eee;
				border-radius: 4px;
				padding: 10px;
				background: #fafafa;
			}

			.nm-log-entry {
				padding: 10px;
				margin-bottom: 8px;
				border-left: 4px solid #ccc;
				background: #fff;
				border-radius: 4px;
				font-size: 13px;
			}

			.nm-log-entry.success {
				border-left-color: #46b450;
			}

			.nm-log-entry.duplicate {
				border-left-color: #ffb900;
			}

			.nm-log-entry.error {
				border-left-color: #dc3232;
			}

			.nm-log-time {
				font-size: 11px;
				color: #999;
				margin-bottom: 4px;
			}

			.nm-log-message-reason {
				font-weight: 600;
				color: #333;
			}

			.nm-log-message-question {
				font-size: 12px;
				color: #666;
				padding-left: 10px;
				border-left: 2px solid #eee;
				margin-top: 5px;
			}

			.nm-health-item {
				display: flex;
				justify-content: space-between;
				padding: 12px 0;
				border-bottom: 1px solid #eee;
			}

			.nm-health-item:last-child {
				border-bottom: none;
			}

			.nm-health-label {
				font-weight: 600;
				color: #555;
			}

			.nm-health-value {
				color: #0073aa;
				font-weight: 500;
			}

			.nm-health-value a {
				text-decoration: none;
				color: #0073aa;
				border: 1px solid #0073aa;
				padding: 2px 6px;
				border-radius: 3px;
				font-size: 11px;
				font-weight: 600;
			}

			.nm-health-value a:hover {
				background: #0073aa;
				color: #fff;
			}

			.nm-health-value .fixing {
				color: #ffb900;
				font-weight: 600;
			}

			.nm-health-status {
				display: inline-block;
				width: 10px;
				height: 10px;
				border-radius: 50%;
				margin-right: 5px;
			}

			.nm-health-status.good {
				background: #46b450;
			}

			.nm-health-status.warning {
				background: #ffb900;
			}

			.nm-health-status.error {
				background: #dc3232;
			}

			.nm-spinner {
				border: 3px solid #f3f3f3;
				border-top: 3px solid #0073aa;
				border-radius: 50%;
				width: 40px;
				height: 40px;
				animation: nm-spin 1s linear infinite;
				margin: 20px auto;
			}

			@keyframes nm-spin {
				0% {
					transform: rotate(0)
				}

				100% {
					transform: rotate(360deg)
				}
			}

			.nm-card-loading {
				min-height: 120px;
				display: flex;
				align-items: center;
				justify-content: center;
			}

			@media (max-width:1200px) {

				.nm-charts-row,
				.nm-bottom-row {
					grid-template-columns: 1fr;
				}
			}
		</style>
		<script>
			jQuery(function($) {
				'use strict';
				const nonce = '<?php echo wp_create_nonce( 'nm_ajax_dashboard' ); ?>';
				let chartInstances = {};

				// ✅ MODIFIED: Load all data on init (without flushing cache)
				setTimeout(function() {
					loadAll(false);
				}, 50);

				$('#nm-refresh-dashboard').on('click', function() {
					const $btn = $(this).prop('disabled', true).text('🔄 Refreshing...');
					// ✅ MODIFIED: Call loadAll with flush_cache = true
					loadAll(true);
					setTimeout(() => {
						$btn.prop('disabled', false).text('🔄 Refresh Data');
					}, 1500);
				});

				// ✅ MODIFIED: Accept a 'flush' parameter
				function loadAll(flush_cache = false) {
					const flush_data = flush_cache ? {
						flush_cache: 1
					} : {};

					loadStatsCards(flush_data);
					loadDuplicateChart(flush_data);
					loadActivityChart(flush_data);
					loadActivityLog(flush_data);
					loadSystemHealth(flush_data);
					loadTopTopics(flush_data);
					loadReportedMCQs(flush_data);
				loadBlueprintStats(flush_data); // ✅ NEW
			}
				// ✅ MODIFIED: Pass flush_data to all AJAX calls
				function loadStatsCards(flush_data = {}) {
					$('#nm-stats-cards').html(
						'<div class="nm-stat-card nm-card-loading"><div class="nm-spinner"></div></div>'
					);

					$.post(
						ajaxurl,
						$.extend({
							action: 'nm_get_dashboard_stats',
							_ajax_nonce: nonce
						}, flush_data),
						function(res) {
							if (res && res.success) {
								renderStatsCards(res.data);
							} else {
								console && console.warn && console.warn('Dashboard stats error:', res);
								$('#nm-stats-cards').html(
									'<div class="nm-stat-card">Error loading stats. Check debug.log.</div>'
								);
							}
						}
					);
				}

				function renderStatsCards(s) {
					const diff = s.difficulty_breakdown || {};
					const cog = s.cognitive_breakdown || {};

					const easy = diff.easy ?? 0;
					const medium = diff.medium ?? 0;
					const hard = diff.hard ?? 0;
					const dUnknown = diff.unknown ?? 0;

					const remember = cog.remember ?? 0;
					const understand = cog.understand ?? 0;
					const apply = cog.apply ?? 0;
					const analyze = cog.analyze ?? 0;
					const evaluate = cog.evaluate ?? 0;
					const cUnknown = cog.unknown ?? 0;

					$('#nm-stats-cards').html(`
		<div class="nm-stat-card">
			<div class="nm-stat-icon">📝</div>
			<div class="nm-stat-value">${s.total_mcqs}</div>
			<div class="nm-stat-label">Total MCQs</div>
		</div>
		<div class="nm-stat-card">
			<div class="nm-stat-icon">✅</div>
			<div class="nm-stat-value">${s.published_mcqs}</div>
			<div class="nm-stat-label">Published</div>
		</div>
		<div class="nm-stat-card">
			<div class="nm-stat-icon">📋</div>
			<div class="nm-stat-value">${s.draft_mcqs}</div>
			<div class="nm-stat-label">Drafts</div>
		</div>
		<div class="nm-stat-card">
			<div class="nm-stat-icon">🚨</div>
			<div class="nm-stat-value">${s.reported_mcqs}</div>
			<div class="nm-stat-label">Reported</div>
		</div>
		<div class="nm-stat-card">
			<div class="nm-stat-icon">🔄</div>
			<div class="nm-stat-value">${s.duplicates_24h}</div>
			<div class="nm-stat-label">Duplicates (24h)</div>
		</div>
		<div class="nm-stat-card">
			<div class="nm-stat-icon">📊</div>
			<div class="nm-stat-value">${s.embedding_coverage}%</div>
			<div class="nm-stat-label">Embedding Coverage</div>
		</div>

<!-- Duplicate scans summary -->
<div class="nm-stat-card">
	<div class="nm-stat-icon">🧭</div>
	<div class="nm-stat-value" style="font-size:22px; line-height:1.3;">
		${(s.duplicate_last_full && s.duplicate_last_full.length) ? s.duplicate_last_full.split(' ')[0] : 'Never'}
		<div style="font-size:14px; margin-top:4px;">
			${(s.duplicate_last_full && s.duplicate_last_full.length) ? s.duplicate_last_full.split(' ')[1] : ''}
		</div>
	</div>
	<div class="nm-stat-label">Last Full Duplicate Scan</div>
	<div style="margin-top:10px; font-size:12px; color:#666;">
		Cursor: <strong>${(s.duplicate_last_cursor && s.duplicate_last_cursor > 0) ? s.duplicate_last_cursor.toLocaleString() : 'N/A'}</strong><br>
		Threshold: <strong>${Math.round(((s.duplicate_threshold ?? 0.7) * 100))}%</strong>
	</div>
</div>

		<!-- Current Affairs config -->
		<div class="nm-stat-card">
			<div class="nm-stat-icon">📰</div>
			<div class="nm-stat-value">Config</div>
			<div class="nm-stat-label">Current Affairs</div>
			<div style="margin-top:10px; font-size:12px; color:#666;">
				Worker Batch: <strong>${(s.ca_worker_batch ?? 1)}</strong><br>
				Max Queue: <strong>${(s.ca_max_queue ?? 50)}</strong>
			</div>
		</div>

		<div class="nm-stat-card nm-stat-mix-card">
			<div class="nm-stat-icon">🎯</div>
			<div class="nm-stat-value">Mix</div>
			<div class="nm-stat-label">Difficulty &amp; Bloom</div>
			<div class="nm-stat-mix-body">
				<div class="nm-stat-mix-section">
					<div class="nm-stat-mix-title">Difficulty split</div>
					<div class="nm-stat-mix-line">Easy: <strong>${easy}</strong></div>
					<div class="nm-stat-mix-line">Medium: <strong>${medium}</strong></div>
					<div class="nm-stat-mix-line">Hard: <strong>${hard}</strong></div>
					<div class="nm-stat-mix-line">Unknown: <strong>${dUnknown}</strong></div>
				</div>
				<div class="nm-stat-mix-section">
					<div class="nm-stat-mix-title">Bloom levels</div>
					<div class="nm-stat-mix-line">Remember: <strong>${remember}</strong></div>
					<div class="nm-stat-mix-line">Understand: <strong>${understand}</strong></div>
					<div class="nm-stat-mix-line">Apply: <strong>${apply}</strong></div>
					<div class="nm-stat-mix-line">Analyze: <strong>${analyze}</strong></div>
					<div class="nm-stat-mix-line">Evaluate: <strong>${evaluate}</strong></div>
					<div class="nm-stat-mix-line">Unknown: <strong>${cUnknown}</strong></div>
				</div>
			</div>
		</div>

		<!-- Buffer API Shares -->
		<div class="nm-stat-card nm-stat-mix-card">
			<div class="nm-stat-icon">🔵</div>
			<div class="nm-stat-value">${s.buffer ? s.buffer.today_total : 0}</div>
			<div class="nm-stat-label">Buffer Shares Today</div>
			<div class="nm-stat-mix-body" style="margin-top:8px;">
				${s.buffer && s.buffer.enabled && s.buffer.has_token ? (function() {
					var html = '';
					var ch = s.buffer.today_channels || {};
					var keys = Object.keys(ch);
					if (keys.length > 0) {
						html += '<div style="border-top:1px solid #eee;padding-top:6px;">';
						keys.forEach(function(svc) {
							var bg = '#666;';
							if (svc === 'facebook') bg = '#1877f2;';
							else if (svc === 'instagram') bg = 'linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);';
							else if (svc === 'twitter') bg = '#000;';
							else if (svc === 'linkedin') bg = '#0a66c2;';
							else if (svc === 'pinterest') bg = '#e60023;';
							else if (svc === 'youtube') bg = '#ff0000;';
							html += '<div style="display:flex;justify-content:space-between;margin:2px 0;font-size:12px;"><span style="display:inline-block;padding:0 6px;border-radius:3px;font-size:10px;font-weight:600;text-transform:uppercase;color:#fff;background:' + bg + '">' + svc + '</span><strong>' + ch[svc] + '</strong></div>';
						});
						html += '</div>';
					} else {
						html = '<p style="font-size:11px;color:#888;margin:6px 0 0 0;">No shares today.</p>';
					}
					var lastTime = s.buffer.today_last ? s.buffer.today_last.split(' ')[1] || s.buffer.today_last : 'N/A';
					var limitReached = s.buffer.today_total >= s.buffer.daily_limit ? ' <span style="color:#dc3232;font-weight:700;">(at limit)</span>' : '';
					html += '<div style="font-size:11px;color:#888;margin-top:6px;padding-top:6px;border-top:1px solid #eee;">Lifetime: <strong>' + s.buffer.lifetime_total + '</strong> &middot; Limit: ' + s.buffer.daily_limit + limitReached + ' &middot; Last: ' + lastTime + '</div>';
					return html;
				})() : '<p style="font-size:11px;color:#888;margin:6px 0 0 0;">Not configured.</p>'}
			</div>
		</div>

		<!-- Daily Roundup Articles -->
		<div class="nm-stat-card nm-stat-mix-card">
			<div class="nm-stat-icon">📰</div>
			<div class="nm-stat-value">${(s.daily_roundups ? s.daily_roundups.total : 0)}</div>
			<div class="nm-stat-label">Daily Roundup Articles</div>
			<div class="nm-stat-mix-body" style="margin-top:8px;">
				<div class="nm-stat-mix-line">Total Articles: <strong>${(s.daily_roundups ? s.daily_roundups.total : 0)}</strong></div>
				<div class="nm-stat-mix-line">Published Today: <strong>${(s.daily_roundups ? s.daily_roundups.published_today : 0)}</strong></div>
				<div class="nm-stat-mix-line">Drafts: <strong>${(s.daily_roundups ? s.daily_roundups.drafts : 0)}</strong></div>
			</div>
		</div>
	`);
				}

				function loadDuplicateChart(flush_data = {}) {
					$.post(ajaxurl, $.extend({
						action: 'nm_get_duplicate_stats',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderDuplicateChart(res.data);
						}
					});
				}

				function renderDuplicateChart(d) {
					const canvas = document.getElementById('nm-duplicate-chart');
					if (!canvas) {
						console.warn('nm-duplicate-chart not found');
						return;
					}
					const ctx = canvas.getContext('2d');
					if (!window.Chart) {
						console.warn('Chart.js not loaded yet');
						return;
					}

					if (chartInstances.duplicateChart) {
						chartInstances.duplicateChart.destroy();
					}

					// ✅ START FIX: Removed 'Fuzzy Match'
					chartInstances.duplicateChart = new Chart(ctx, {
						type: 'doughnut',
						data: {
							labels: ['Exact Match', 'Semantic Match'],
							datasets: [{
								data: [d.exact, d.semantic],
								backgroundColor: ['#0073aa', '#46b450']
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: true,
							plugins: {
								legend: {
									position: 'bottom'
								}
							}
						}
					});
					// ✅ END FIX

					$('#nm-duplicate-stats').html(`<strong>Total Duplicates Prevented:</strong> ${d.total}<br><strong>Most Common:</strong> ${d.most_common}`);
				}

				function loadActivityChart(flush_data = {}) {
					$.post(ajaxurl, $.extend({
						action: 'nm_get_activity_stats',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderActivityChart(res.data);
						}
					});
				}

				function renderActivityChart(d) {
					const canvas = document.getElementById('nm-activity-chart');
					if (!canvas) {
						console.warn('nm-activity-chart not found');
						return;
					}
					const ctx = canvas.getContext('2d');

					if (chartInstances.activityChart) {
						chartInstances.activityChart.destroy();
					}
					chartInstances.activityChart = new Chart(ctx, {
						type: 'line',
						data: {
							labels: d.hours,
							datasets: [{
								label: 'MCQs Created',
								data: d.counts,
								borderColor: '#0073aa',
								backgroundColor: 'rgba(0,115,170,.1)',
								tension: .4,
								fill: true
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: true,
							scales: {
								y: {
									beginAtZero: true,
									ticks: {
										stepSize: 1
									}
								}
							},
							plugins: {
								legend: {
									display: false
								}
							}
						}
					});
					$('#nm-activity-stats').html(`<strong>Total Created Today:</strong> ${d.total}<br><strong>Success Rate:</strong> ${d.success_rate}%`);
				}

				function loadActivityLog(flush_data = {}) {
					$('#nm-activity-log-content').html('<div class="nm-spinner"></div>');
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: $.extend({
							action: 'nm_get_activity_log',
							_wpnonce: nonce
						}, flush_data),
						success: function(res) {
							if (res?.success) {
								renderActivityLog(res.data);
							} else {
								$('#nm-activity-log-content').html('<p style="text-align:center; padding: 20px; color:red;">Error loading log.</p>');
							}
						},
						error: function() {
							$('#nm-activity-log-content').html('<p style="text-align:center; padding: 20px; color:red;">Error loading log.</p>');
						}
					});
				}

				function renderActivityLog(entries) {
					if (!entries || !entries.length) {
						$('#nm-activity-log-content').html('<p style="text-align:center; padding: 20px;">No recent activity.</p>');
						return;
					}
					let html = '';
					entries.forEach(e => {
						html += `<div class="nm-log-entry ${e.type}">
								<div class="nm-log-time">${e.time}</div>
								<div class="nm-log-message-reason">${e.message}</div>`;
						if (e.question && e.question.trim() !== '') {
							html += `<div class="nm-log-message-question">${e.question}</div>`;
						}
						html += `</div>`;
					});
					$('#nm-activity-log-content').html(html);
					filterLog();
				}

				function loadSystemHealth(flush_data = {}) {
					$('#nm-health-content').html('<div class="nm-spinner"></div>');
					$.post(ajaxurl, $.extend({
						action: 'nm_get_system_health',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderSystemHealth(res.data);
						}
					});
				}

				function renderSystemHealth(h) {
					let html = '';
					Object.entries(h).forEach(([k, v]) => {
						let value = v.value;
						if (v.fixable) {
							value += ` <a href="#" data-cron-key="${k}" class="nm-fix-cron-link" style="font-size:11px;">(Try to fix)</a>`;
						}
						html += `<div class="nm-health-item">
								<span class="nm-health-label"><span class="nm-health-status ${v.status}"></span>${v.label}</span>
								<span class="nm-health-value">${value}</span>
							</div>`;
					});
					$('#nm-health-content').html(html);
				}

				function loadTopTopics(flush_data = {}) {
					$('#nm-top-topics-content').html('<div class="nm-spinner"></div>');
					$.post(ajaxurl, $.extend({
						action: 'nm_get_top_topics',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderTopTopics(res.data);
						}
					});
				}

				function renderTopTopics(t) {
					if (!t || t.length === 0) {
						$('#nm-top-topics-content').html('<p style="text-align:center;">No topics yet.</p>');
						return;
					}
					let html = '<table style="width:100%;font-size:13px;"><tr><th style="text-align:left;">Topic</th><th>Count</th></tr>';
					t.forEach(x => {
						html += `<tr><td>${x.name}</td><td style="text-align:center;"><strong>${x.count}</strong></td></tr>`;
					});
					html += '</table>';
					$('#nm-top-topics-content').html(html);
				}

				function loadReportedMCQs(flush_data = {}) {
					$('#nm-reported-content').html('<div class="nm-spinner"></div>');
					$.post(ajaxurl, $.extend({
						action: 'nm_get_reported_mcqs',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderReportedMCQs(res.data);
						}
					});
				}

				function renderReportedMCQs(m) {
					if (!m.length) {
						$('#nm-reported-content').html('<p style="text-align:center; padding: 20px;">No reported MCQs. ✅</p>');
						return;
					}
					let html = '<ul style="list-style:none;padding:0;margin:0;">';
					m.forEach(x => {
						html += `<li style="padding:10px 0;border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
								<div><strong>${x.title}</strong><br><small style="color:#dc3232;">Reported: ${x.count} time(s)</small></div>
								<a href="${x.edit_link}" class="button button-small">Edit</a>
							</li>`;
					});
					html += '</ul>';
					$('#nm-reported-content').html(html);
				}

				// ✅ NEW: Blueprint Stats
				function loadBlueprintStats(flush_data = {}) {
					$('#nm-blueprint-stats').html('<div class="nm-spinner"></div>');
					$.post(ajaxurl, $.extend({
						action: 'nm_get_blueprint_stats',
						_wpnonce: nonce
					}, flush_data), res => {
						if (res?.success) {
							renderBlueprintStats(res.data);
						} else {
							$('#nm-blueprint-stats').html('<p>Error loading blueprint stats.</p>');
						}
					});
				}

				function renderBlueprintStats(data) {
					if (!data || !data.length) {
						$('#nm-blueprint-stats').html('<p>No blueprint data available yet.</p>');
						return;
					}

					let html = '';
					data.forEach(exam => {
						// Calculate drift color
						const driftColor = exam.drift > 10 ? '#dc3232' : (exam.drift > 5 ? '#ffb900' : '#46b450');

						html += `
					<div style="flex:1; min-width:250px; background:#f9f9f9; padding:15px; border-radius:8px; border:1px solid #eee;">
						<h3 style="margin:0 0 10px 0; font-size:15px; border-bottom:1px solid #ddd; padding-bottom:5px;">
							${exam.name}
						</h3>
						
						<div style="display:flex; justify-content:space-between; margin-bottom:5px; font-size:12px; color:#666;">
							<span>Target Hard: <strong>${exam.target_hard}%</strong></span>
							<span>Actual: <strong>${exam.actual_hard}%</strong></span>
						</div>
						
						<div style="background:#ddd; height:6px; border-radius:3px; overflow:hidden; margin-bottom:10px;">
							<div style="width:${exam.actual_hard}%; background:${driftColor}; height:100%;"></div>
						</div>

						<div style="font-size:11px; color:#888;">
							Total Generated: <strong>${exam.total_count}</strong><br>
							Drift: <strong style="color:${driftColor}">${exam.drift}%</strong>
						</div>
					</div>`;
					});
					$('#nm-blueprint-stats').html(html);
				}

				function filterLog() {
					const f = $('#nm-log-filter').val();
					$('.nm-log-entry').show();
					if (f !== 'all') {
						$('.nm-log-entry').not('.' + f).hide();
					}
				}
				$('#nm-log-filter').on('change', filterLog);

				$('#nm-clear-log').on('click', function() {
					if (confirm('Clear activity log?')) {
						$.post(ajaxurl, {
							action: 'nm_clear_activity_log',
							_wpnonce: nonce
						}, function() {
							loadActivityLog();
						});
					}
				});

				$(document).on('click', '.nm-fix-cron-link', function(e) {
					e.preventDefault();
					const cronKey = $(this).data('cron-key');
					const $val = $(this).closest('.nm-health-value');
					$val.html('<span style="color:#ffb900;">Fixing...</span>');
					$.post(ajaxurl, {
						action: 'nm_ajax_reset_stuck_crons',
						_wpnonce: nonce,
						cron_key: cronKey
					}, function(res) {
						if (res.success) {
							$val.html('<span style="color:#46b450;">Fixed! Reloading...</span>');
							setTimeout(loadSystemHealth, 1500);
						} else {
							$val.html('<span style="color:#dc3232;">Failed</span>');
						}
					});
				});

			});
		</script>
		<?php
	}
}
?>
