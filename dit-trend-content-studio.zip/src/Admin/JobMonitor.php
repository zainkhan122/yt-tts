<?php

/**
 * Briefing Room Admin Page
 *
 * Provides UI for users to create a brief: topic, notes, and media uploads.
 * Uses the built‑in WordPress media library to select existing media.
 *
 * @package DIT_TrendStudio\Admin
 * @MODIFIED 2025-12-18 - Added Briefing Room UI with WP media selector.
 */

namespace DIT\TrendStudio\Admin;

if (!defined('ABSPATH')) {
    exit;
}

use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\Scheduler;

class JobMonitor
{
    /** @var Logger */
    private $logger;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        // @DEPRECATED 2026-01-14 - Moved to unified interface in Admin_Menu
        // add_action('admin_menu', [$this, 'register_menu']);
        // add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        // add_action('wp_ajax_dit_ts_create_brief', [$this, 'ajax_create_brief']);
        // add_action('wp_ajax_dit_ts_analyze_gap', [$this, 'ajax_analyze_gap']);
    }

    public function register_menu()
    {
        add_menu_page(
            __('Briefing Room', 'dit-trend-content-studio'),
            __('Briefing Room', 'dit-trend-content-studio'),
            'edit_posts',
            'dit_ts_briefing_room',
            [$this, 'render_page'],
            'dashicons-edit',
            30
        );
    }

    public function enqueue_assets($hook)
    {
        if ($hook !== 'toplevel_page_dit_ts_briefing_room') {
            return;
        }
        wp_enqueue_media();

        $plugin = \DIT\TrendStudio\Core\Plugin::get_instance();

    wp_enqueue_script(
        'dit-ts-briefing-room',
        plugins_url('assets/js/briefing-room.js', DIT_TS_PLUGIN_FILE),
        ['jquery'],
        $plugin->get_asset_version('assets/js/briefing-room.js'),
        true
    );
        wp_localize_script('dit-ts-briefing-room', 'DitTsBriefing', [
            'nonce' => wp_create_nonce('dit_ts_briefing_nonce'),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'jobsUrl' => admin_url('admin.php?page=dit-ts-jobs'),
        ]);
    }

    public function render_page()
    {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'dit-trend-content-studio'));
        }
?>
        <div class="wrap">
            <h1><?php esc_html_e('Briefing Room', 'dit-trend-content-studio'); ?></h1>

            <h2 class="nav-tab-wrapper">
                <a href="#tab-standard" class="nav-tab nav-tab-active"><?php esc_html_e('Standard Brief', 'dit-trend-content-studio'); ?></a>
                <a href="#tab-strategy" class="nav-tab"><?php esc_html_e('Win Strategy (Gap Analysis)', 'dit-trend-content-studio'); ?></a>
            </h2>

            <div id="tab-standard" class="dit-ts-tab-content" style="margin-top: 20px;">
                <form id="dit-ts-briefing-form" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
                    <?php wp_nonce_field('dit_ts_briefing_nonce', 'dit_ts_briefing_nonce_field'); ?>
                    <input type="hidden" name="action" value="dit_ts_create_brief">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="dit_ts_topic"><?php esc_html_e('Topic / Angle', 'dit-trend-content-studio'); ?></label></th>
                            <td><input name="topic" type="text" id="dit_ts_topic" class="regular-text" required></td>
                        </tr>
                        <!-- @MODIFIED 2025-12-18 - Added Unique Angle field (required for authenticity) -->
                        <tr>
                            <th scope="row">
                                <label for="dit_ts_unique_angle"><?php esc_html_e('Unique Angle *', 'dit-trend-content-studio'); ?></label>
                            </th>
                            <td>
                                <textarea name="unique_angle" id="dit_ts_unique_angle" rows="3" class="large-text" required placeholder="<?php esc_attr_e('What makes YOUR take on this topic different? What unique insight, data, or perspective do you bring?', 'dit-trend-content-studio'); ?>"></textarea>
                                <p class="description"><?php esc_html_e('Required. This forces differentiation from generic AI content.', 'dit-trend-content-studio'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dit_ts_focus_keyword"><?php esc_html_e('Focus Keyword', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <input name="focus_keyword" type="text" id="dit_ts_focus_keyword" class="regular-text" placeholder="<?php esc_attr_e('Primary SEO keyword', 'dit-trend-content-studio'); ?>">
                            </td>
                        </tr>
                        <!-- @MODIFIED 2026-01-12 - Added Editorial Angle dropdown for intent-based architecture -->
                        <tr>
                            <th scope="row"><label for="dit_ts_editorial_angle"><?php esc_html_e('Editorial Angle', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <select name="editorial_angle" id="dit_ts_editorial_angle">
                                    <option value="neutral"><?php esc_html_e('Neutral (Balanced)', 'dit-trend-content-studio'); ?></option>
                                    <option value="skeptical"><?php esc_html_e('Skeptical (Critical)', 'dit-trend-content-studio'); ?></option>
                                    <option value="enthusiastic"><?php esc_html_e('Enthusiastic (Positive)', 'dit-trend-content-studio'); ?></option>
                                    <option value="contrarian"><?php esc_html_e('Contrarian (Against popular opinion)', 'dit-trend-content-studio'); ?></option>
                                    <option value="data_driven"><?php esc_html_e('Data-Driven (Facts focused)', 'dit-trend-content-studio'); ?></option>
                                </select>
                                <p class="description"><?php esc_html_e('Sets the writer\'s perspective and tone.', 'dit-trend-content-studio'); ?></p>
                            </td>
                        </tr>
                        <!-- @MODIFIED 2026-01-12 - Added Article Structure dropdown -->
                        <tr>
                            <th scope="row"><label for="dit_ts_article_structure"><?php esc_html_e('Article Structure', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <select name="article_structure" id="dit_ts_article_structure">
                                    <option value="deep_dive"><?php esc_html_e('Deep Dive (Comprehensive)', 'dit-trend-content-studio'); ?></option>
                                    <option value="listicle"><?php esc_html_e('Listicle (Numbered items)', 'dit-trend-content-studio'); ?></option>
                                    <option value="news_brief"><?php esc_html_e('News Brief (Inverted pyramid)', 'dit-trend-content-studio'); ?></option>
                                    <option value="comparison"><?php esc_html_e('Comparison (Side-by-side review)', 'dit-trend-content-studio'); ?></option>
                                </select>
                                <p class="description"><?php esc_html_e('Determines the article format and section layout.', 'dit-trend-content-studio'); ?></p>
                            </td>
                        </tr>
                        <!-- @MODIFIED 2026-01-12 - Added Search Intent dropdown -->
                        <tr>
                            <th scope="row"><label for="dit_ts_search_intent"><?php esc_html_e('Search Intent', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <select name="search_intent" id="dit_ts_search_intent">
                                    <option value="mixed"><?php esc_html_e('Mixed (General)', 'dit-trend-content-studio'); ?></option>
                                    <option value="informational"><?php esc_html_e('Informational (How-to, explainer)', 'dit-trend-content-studio'); ?></option>
                                    <option value="commercial"><?php esc_html_e('Commercial (Reviews, comparisons)', 'dit-trend-content-studio'); ?></option>
                                    <option value="news"><?php esc_html_e('News (Breaking, timely)', 'dit-trend-content-studio'); ?></option>
                                </select>
                                <p class="description"><?php esc_html_e('Matches content to user search intent for better SEO.', 'dit-trend-content-studio'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dit_ts_notes"><?php esc_html_e('Editor Notes', 'dit-trend-content-studio'); ?></label></th>
                            <td><textarea name="notes" id="dit_ts_notes" rows="5" class="large-text"></textarea></td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php esc_html_e('Media Uploads', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <button type="button" class="button" id="dit-ts-select-media"><?php esc_html_e('Select Media', 'dit-trend-content-studio'); ?></button>
            </div>
            <div id="dit-ts-selected-media" style="margin-top:10px;"></div>
            <input type="hidden" name="media_ids" id="dit_ts_media_ids" value="">
            <p class="description"><?php esc_html_e('Attach local media from the WordPress library.', 'dit-trend-content-studio'); ?></p>
            </td>
            </tr>
            </table>
            <?php submit_button(__('Create Brief', 'dit-trend-content-studio')); ?>
            </form>
        </div>

        <!-- Win Strategy Tab -->
        <div id="tab-strategy" class="dit-ts-tab-content" style="display:none; margin-top: 20px;">
            <div class="card" style="max-width: 800px; padding: 20px;">
                <h3><?php esc_html_e('Gap Analysis & Win Strategy', 'dit-trend-content-studio'); ?></h3>
                <p><?php esc_html_e('Paste a competitor\'s article URL or text. We will analyze it to find weaknesses and generate a "Win Strategy" for you.', 'dit-trend-content-studio'); ?></p>

                <form id="dit-ts-gap-analysis-form">
                    <table class="form-table">
                        <!-- @MODIFIED 2026-01-14 - Added Analysis Mode Switcher -->
                        <tr>
                            <th scope="row"><?php esc_html_e('Analysis Mode', 'dit-trend-content-studio'); ?></th>
                            <td>
                                <fieldset>
                                    <label style="margin-right: 20px;">
                                        <input type="radio" name="dit_ts_strategy_mode" value="competitor" checked>
                                        <strong>⚔️ <?php esc_html_e('Competitor Audit', 'dit-trend-content-studio'); ?></strong>
                                        <br><span class="description"><?php esc_html_e('Find gaps to beat this content (Skyscraper Technique).', 'dit-trend-content-studio'); ?></span>
                                    </label>
                                    <br><br>
                                    <label>
                                        <input type="radio" name="dit_ts_strategy_mode" value="brand">
                                        <strong>✨ <?php esc_html_e('Brand Enhancement', 'dit-trend-content-studio'); ?></strong>
                                        <br><span class="description"><?php esc_html_e('Keep specific details, but elevate tone and add industry context.', 'dit-trend-content-studio'); ?></span>
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dit_ts_gap_source"><?php esc_html_e('Source URL', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <input type="url" id="dit_ts_gap_source" class="large-text" placeholder="https://competitor.com/article...">
                                <p class="description"><?php esc_html_e('We will fetch and analyze this page server-side.', 'dit-trend-content-studio'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center; font-weight: bold;"><?php esc_html_e('--- OR ---', 'dit-trend-content-studio'); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dit_ts_gap_content"><?php esc_html_e('Paste Text', 'dit-trend-content-studio'); ?></label></th>
                            <td>
                                <textarea id="dit_ts_gap_content" rows="6" class="large-text" placeholder="<?php esc_attr_e('Paste article text here if URL fetch fails...', 'dit-trend-content-studio'); ?>"></textarea>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="button" id="dit-ts-analyze-btn" class="button button-primary button-large"><?php esc_html_e('Analyze & Generate Strategy', 'dit-trend-content-studio'); ?></button>
                        <span class="spinner" id="dit-ts-analyze-spinner" style="float:none;"></span>
                    </p>
                </form>

                <!-- Analysis Result Container -->
                <div id="dit-ts-strategy-result" style="display:none; margin-top: 20px; background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-left: 4px solid #2271b1;">
                    <h4 style="margin-top:0;"><?php esc_html_e('Strategy Report', 'dit-trend-content-studio'); ?></h4>
                    <div id="dit-ts-strategy-content"></div>
                    <p class="submit" style="margin-bottom:0;">
                        <button type="button" id="dit-ts-use-strategy-btn" class="button button-primary"><?php esc_html_e('Use This Strategy', 'dit-trend-content-studio'); ?></button>
                    </p>
                </div>
            </div>
        </div>

        </div>
<?php
    }
    /**
     * Handle AJAX request to create a brief.
     */
    public function ajax_create_brief()
    {
        check_ajax_referer('dit_ts_briefing_nonce', 'dit_ts_briefing_nonce_field');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Insufficient permissions');
        }

        $topic = sanitize_text_field($_POST['topic'] ?? '');
        $notes = sanitize_textarea_field($_POST['notes'] ?? '');
        $media_ids = sanitize_text_field($_POST['media_ids'] ?? '');
        // @MODIFIED 2025-12-18 - Added unique_angle and focus_keyword for authenticity
        $unique_angle = sanitize_textarea_field($_POST['unique_angle'] ?? '');
        $focus_keyword = sanitize_text_field($_POST['focus_keyword'] ?? '');
        // @MODIFIED 2026-01-12 - Added intent-based architecture fields
        $editorial_angle = sanitize_text_field($_POST['editorial_angle'] ?? 'neutral');
        $article_structure = sanitize_text_field($_POST['article_structure'] ?? 'deep_dive');
        $search_intent = sanitize_text_field($_POST['search_intent'] ?? 'mixed');

        if (empty($topic)) {
            wp_send_json_error('Topic is required');
        }

        // @MODIFIED 2025-12-18 - Unique Angle is required
        if (empty($unique_angle)) {
            wp_send_json_error('Unique Angle is required for content authenticity');
        }

        $media_ids_array = array_filter(array_map('intval', explode(',', $media_ids)));

        try {
            // Get Job Handler instance
            $job_handler = \DIT\TrendStudio\Core\Plugin::get_instance()->get_job_handler();

            $input_data = [
                'topic'             => $topic,
                'user_notes'        => $notes,
                'media_ids'         => $media_ids_array,
                'unique_angle'      => $unique_angle,
                'focus_keyword'     => $focus_keyword,
                // @MODIFIED 2026-01-12 - Intent-based architecture fields
                'editorial_angle'   => $editorial_angle,
                'article_structure' => $article_structure,
                'search_intent'     => $search_intent,
            ];

            $job_id = $job_handler->schedule_generation($input_data, get_current_user_id());

            // Set initial state to briefing (using newly public method)
            $job_handler->update_job_status($job_id, Scheduler::STATE_BRIEFING);

            wp_send_json_success(['job_id' => $job_id, 'message' => 'Brief created successfully']);
        } catch (\Exception $e) {
            $this->logger->error('Failed to create brief: ' . $e->getMessage());
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Handle AJAX request for Gap Analysis
     * @since 1.8.0
     */
    public function ajax_analyze_gap()
    {
        check_ajax_referer('dit_ts_briefing_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Insufficient permissions');
        }

        $url = sanitize_url($_POST['url'] ?? '');
        $text = sanitize_textarea_field($_POST['text'] ?? '');
        // @MODIFIED 2026-01-14 - Capture analysis mode
        $mode = sanitize_text_field($_POST['mode'] ?? 'competitor');

        if (empty($url) && empty($text)) {
            wp_send_json_error('Please provide a URL or paste content to analyze.');
        }

try {
        // @FIXED 2026-04-24 - Respect AI strategy setting (was hardcoded to Gemini)
        $strategy = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_effective_strategy();
        $ai_client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create($strategy, $this->logger);
        $analyzer = new \DIT\TrendStudio\Core\Gap_Analyzer($ai_client, $this->logger);

            // Prioritize URL if valid
            if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                $strategy = $analyzer->analyze($url, 'url', $mode);
            } else {
                $strategy = $analyzer->analyze($text, 'text', $mode);
            }

            wp_send_json_success($strategy);
        } catch (\Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
}

?>