<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProviderCooldown {

	const COOLDOWN_KEY_PREFIX      = 'ai_collage_cooldown_';
	const MISCONFIGURED_KEY_PREFIX  = 'ai_collage_misconfig_';
	const MISCONFIGURED_TTL        = 1800;
	const MAX_COOLDOWN_TTL         = 300;
	const DAILY_QUOTA_KEY_PREFIX   = 'ai_collage_daily_quota_';
	const AUTH_FAILURE_COUNT_KEY   = 'ai_collage_auth_fail_count_';
	const AUTH_FAILURE_THRESHOLD   = 3;

	public static function set_cooldown( string $provider, int $seconds, string $error_type = '' ): void {
		$key = self::COOLDOWN_KEY_PREFIX . $provider;

		if ( in_array( $error_type, [ 'transient', 'server_overloaded' ], true ) ) {
			$ttl = min( max( 30, $seconds ), 180 );
		} elseif ( in_array( $error_type, [ 'quota_rpm', 'quota_tpm' ], true ) ) {
			$ttl = min( max( 45, $seconds ), 120 );
		} elseif ( $error_type === 'quota_unknown' ) {
			$ttl = min( max( 60, $seconds ), self::MAX_COOLDOWN_TTL );
		} elseif ( $error_type === 'quota_rpd' ) {
			$ttl = min( max( 120, $seconds ), self::MAX_COOLDOWN_TTL );
		} else {
			$ttl = min( max( 60, $seconds ), self::MAX_COOLDOWN_TTL );
		}

		set_transient( $key, time(), $ttl );
		update_option( $key . '_ttl', $ttl, false );
		Logger::info( 'provider_cooldown_set', null, [
			'provider'    => $provider,
			'seconds'     => $seconds,
			'applied_ttl' => $ttl,
			'error_type'  => $error_type,
			'until'       => time() + $ttl,
		] );
	}

	public static function is_in_cooldown( string $provider ): bool {
		$key = self::COOLDOWN_KEY_PREFIX . $provider;
		$start = get_transient( $key );
		if ( ! $start ) {
			return false;
		}
		$elapsed = time() - (int) $start;
		$ttl = (int) get_option( $key . '_ttl', 300 );
		if ( $elapsed >= $ttl ) {
			delete_transient( $key );
			return false;
		}
		return true;
	}

	public static function get_cooldown_remaining( string $provider ): int {
		$key = self::COOLDOWN_KEY_PREFIX . $provider;
		$start = get_transient( $key );
		if ( ! $start ) {
			return 0;
		}
		$ttl = (int) get_option( $key . '_ttl', 300 );
		$remaining = $ttl - ( time() - (int) $start );
		return max( 0, $remaining );
	}

	public static function mark_misconfigured( string $provider ): void {
		$key = self::MISCONFIGURED_KEY_PREFIX . $provider;
		set_transient( $key, time(), self::MISCONFIGURED_TTL );
		Logger::warning( 'provider_marked_misconfigured', null, [
			'provider' => $provider,
			'ttl'      => self::MISCONFIGURED_TTL,
		] );
	}

	public static function is_misconfigured( string $provider ): bool {
		$key = self::MISCONFIGURED_KEY_PREFIX . $provider;
		$start = get_transient( $key );
		if ( ! $start ) {
			return false;
		}
		$elapsed = time() - (int) $start;
		if ( $elapsed >= self::MISCONFIGURED_TTL ) {
			delete_transient( $key );
			return false;
		}
		return true;
	}

	public static function set_daily_quota( string $provider, int $reset_at_ts ): void {
		$key = self::DAILY_QUOTA_KEY_PREFIX . $provider;
		$ttl = max( 60, $reset_at_ts - time() );
		set_transient( $key, $reset_at_ts, $ttl );
		Logger::info( 'provider_daily_quota_set', null, [
			'provider'  => $provider,
			'reset_at'  => $reset_at_ts,
			'ttl'       => $ttl,
		] );
	}

	public static function is_daily_quota_blocked( string $provider ): bool {
		$key = self::DAILY_QUOTA_KEY_PREFIX . $provider;
		$reset_at = get_transient( $key );
		if ( ! $reset_at ) {
			return false;
		}
		if ( time() >= (int) $reset_at ) {
			delete_transient( $key );
			return false;
		}
		return true;
	}

	public static function get_daily_quota_remaining( string $provider ): int {
		$key = self::DAILY_QUOTA_KEY_PREFIX . $provider;
		$reset_at = get_transient( $key );
		if ( ! $reset_at ) {
			return 0;
		}
		return max( 0, (int) $reset_at - time() );
	}

	public static function reset_provider( string $provider ): void {
		delete_transient( self::COOLDOWN_KEY_PREFIX . $provider );
		delete_transient( self::MISCONFIGURED_KEY_PREFIX . $provider );
		delete_transient( self::DAILY_QUOTA_KEY_PREFIX . $provider );
		Logger::info( 'provider_cooldown_reset', null, [ 'provider' => $provider ] );
	}

	public static function reset_all(): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_' . self::COOLDOWN_KEY_PREFIX ) . '%',
			$wpdb->esc_like( '_transient_' . self::MISCONFIGURED_KEY_PREFIX ) . '%',
			$wpdb->esc_like( '_transient_' . self::DAILY_QUOTA_KEY_PREFIX ) . '%'
		) );
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_timeout_' . self::COOLDOWN_KEY_PREFIX ) . '%',
			$wpdb->esc_like( '_transient_timeout_' . self::MISCONFIGURED_KEY_PREFIX ) . '%',
			$wpdb->esc_like( '_transient_timeout_' . self::DAILY_QUOTA_KEY_PREFIX ) . '%'
		) );
		if ( function_exists( 'is_object_cache_active' ) && is_object_cache_active() ) {
			wp_cache_flush();
		}
		Logger::info( 'provider_cooldown_reset_all', null, [] );
	}

	/**
	 * Record an auth failure and auto-mark provider as misconfigured after threshold.
	 * Returns true if provider was marked misconfigured.
	 */
	public static function record_auth_failure( string $provider ): bool {
		$key = self::AUTH_FAILURE_COUNT_KEY . $provider;
		$count = (int) get_option( $key, 0 ) + 1;
		update_option( $key, $count, false );

		if ( $count >= self::AUTH_FAILURE_THRESHOLD ) {
			self::mark_misconfigured( $provider );
			delete_option( $key );
			Logger::warning( 'provider_auto_misconfigured', null, [
				'provider' => $provider,
				'failure_count' => $count,
				'threshold' => self::AUTH_FAILURE_THRESHOLD,
			] );
			return true;
		}

		return false;
	}

	/**
	 * Reset auth failure counter (e.g., when provider starts working again).
	 */
	public static function reset_auth_failure_count( string $provider ): void {
		delete_option( self::AUTH_FAILURE_COUNT_KEY . $provider );
	}
}
