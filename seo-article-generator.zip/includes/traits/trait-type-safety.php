<?php

/**
 * Type Safety Trait
 *
 * Provides robust methods for handling AI-generated data that might be 
 * unpredictably typed (e.g., getting an array when a string is expected).
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Traits;

trait Type_Safety
{

    /**
     * Safely convert a potentially multi-typed value to a string.
     * 
     * If an array is passed, it extracts the first element and recursively
     * converts it to a string. This handles AI responses that return 
     * ["value"] instead of "value".
     *
     * @param mixed $value The value to convert.
     * @return string
     */
    protected static function as_string($value)
    {
        if (is_string($value)) {
            return trim($value);
        }

        if (is_array($value)) {
            if (empty($value)) {
                return '';
            }
            // Use first element of array
            return self::as_string(reset($value));
        }

        if (is_scalar($value)) {
            return (string)$value;
        }

        return '';
    }

    /**
     * Safely convert a value to an array.
     * 
     * If a scalar is passed, it wraps it in an array.
     *
     * @param mixed $value
     * @return array
     */
    protected static function as_array($value)
    {
        if (is_array($value)) {
            return $value;
        }

        if (empty($value)) {
            return [];
        }

        return [$value];
    }
}
