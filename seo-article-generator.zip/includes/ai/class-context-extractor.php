<?php

/**
 * Context Extractor Helper
 *
 * @MODIFIED 2025-12-04 v1.3.1: Fixed web search + JSON mode conflict
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI_Exception;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Helper class for extracting context from article text
 *
 * @MODIFIED 2025-12-04 v1.3.1: Simplified to use AI_Client for web search support
 */
class Context_Extractor
{

	/**
	 * AI client instance
	 *
	 * @var AI_Client
	 */
	private $ai_client;

	/**
	 * Constructor
	 *
	 * @param AI_Client $ai_client AI client instance
	 */
	public function __construct($ai_client)
	{
		$this->ai_client = $ai_client;
	}

	/**
	 * Extract software context from existing article text or software name
	 *
	 * @MODIFIED 2025-12-04 v1.3.1: Now inherits web search capability from AI_Client
	 *
	 * @param string $article_text Full article or software name
	 * @return array Extracted data (software_name, category, features, etc.)
	 * @throws AI_Exception If extraction fails
	 */
	public function extract($article_text)
	{
		$extraction_prompt = <<<'PROMPT'
You are analyzing text about a software. Extract structured data.

INPUT TEXT:
{ARTICLE_TEXT}

Return ONLY valid JSON with this structure (no markdown, no extra text):
{
  "software_name": "Exact software name (REQUIRED)",
  "version": "Current version if mentioned, else empty string",  
  "category": "Detailed software category list (e.g., File Recovery, Data Security, Utility)",
  "existing_features": ["feature1", "feature2"],
  "is_existing_article": true or false,
  "homepage": "Official homepage URL if mentioned, else empty"
}

Rules:
- If INPUT TEXT is just 1-3 words (e.g., "VLC Media Player"), it's a new article request.
  Set is_existing_article: false and extract only software_name.
  Infer category from your knowledge or use web search if enabled.
- If INPUT TEXT is a full article (paragraph or HTML), extract as much context as possible.
  Set is_existing_article: true.
- Category: Infer from features/description (Media Player, Browser, Utility, etc.)
- If web search is enabled, you may search for latest info about the software
- Do NOT invent data not present in the text
PROMPT;

		$prompt_with_text = str_replace('{ARTICLE_TEXT}', mb_substr($article_text, 0, 10000), $extraction_prompt);

		try {
			// Use AI client's low-level API call method
			// This inherits web search + JSON mode conflict handling
			$extracted_data = $this->call_ai_for_extraction($prompt_with_text);

			// Ensure required fields exist
			if (empty($extracted_data['software_name'])) {
				throw new AI_Exception('Could not extract software name from provided text');
			}

			// Normalize structure
			$result = array(
				'software_name'       => $extracted_data['software_name'],
				'version'             => isset($extracted_data['version']) ? $extracted_data['version'] : '',
				'category'            => isset($extracted_data['category']) ? $extracted_data['category'] : 'Software',
				'existing_features'   => isset($extracted_data['existing_features']) && is_array($extracted_data['existing_features']) ? $extracted_data['existing_features'] : array(),
				'is_existing_article' => isset($extracted_data['is_existing_article']) ? (bool) $extracted_data['is_existing_article'] : false,
				'homepage'            => isset($extracted_data['homepage']) ? $extracted_data['homepage'] : '',
			);

			return $result;
		} catch (\Exception $e) {
			// Re-throw with context
			throw new AI_Exception('Context extraction failed: ' . $e->getMessage());
		}
	}

	/**
	 * Call AI for extraction (inherits web search logic from settings)
	 *
	 * @param string $prompt Extraction prompt
	 * @return array Parsed JSON response
	 * @throws AI_Exception If API call fails
	 */
	private function call_ai_for_extraction($prompt)
	{
		// @since 2.7.0: Check provider setting
		$provider = get_option('seo_gen_api_provider', 'gemini');

		// Use Perplexity if selected
		if ('perplexity' === $provider) {
			return $this->call_perplexity_for_extraction($prompt);
		}

		// Default: Use Gemini
		$model    = AI_Client::get_gemini_model();
		$endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent";
		$api_key  = AI_Client::get_gemini_key();

		if (empty($api_key)) {
			throw new AI_Exception('Gemini API key not configured');
		}

		$enable_web_search = get_option('seo_gen_enable_web_search', true);

		$request_body = array(
			'contents'         => array(
				array(
					'parts' => array(
						array('text' => $prompt),
					),
				),
			),
			'generationConfig' => array(
				'temperature'     => 0.3,
				'maxOutputTokens' => 2048,
			),
		);

		if (! $enable_web_search) {
			$request_body['generationConfig']['responseMimeType'] = 'application/json';
		}

		if ($enable_web_search) {
			$request_body['tools'] = array(
				array('google_search' => new \stdClass()),
			);
		}

		// USE THE GATEWAY
		$response = $this->ai_client->execute_safe_request(
			"{$endpoint}?key={$api_key}",
			array(
				'timeout' => 60,
				'headers' => array('Content-Type' => 'application/json'),
				'body'    => wp_json_encode($request_body),
			),
			'gemini'
		);

		if (is_wp_error($response)) {
			throw new AI_Exception('Context extraction gateway error: ' . $response->get_error_message());
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);


		if (! is_array($data) || empty($data['candidates']) || empty($data['candidates'][0])) {
			throw new AI_Exception('Invalid context extraction response structure');
		}

		// Extract text from first candidate
		$text = '';
		if (
			isset($data['candidates'][0]['content']['parts'])
			&& is_array($data['candidates'][0]['content']['parts'])
		) {
			foreach ($data['candidates'][0]['content']['parts'] as $part) {
				if (isset($part['text']) && $part['text'] !== '') {
					$text .= $part['text'];
				}
			}
		}

		// @DEBUG: Log raw API response to diagnose empty extraction issue
		if ($text === '' && defined('WP_DEBUG') && WP_DEBUG) {
			error_log('[SEO Generator DEBUG] Context extraction - Raw API response: ' . wp_json_encode($data));
			error_log('[SEO Generator DEBUG] Context extraction - Parts structure: ' . wp_json_encode($data['candidates'][0]['content']['parts'] ?? 'NO_PARTS'));
		}

		if ($text === '') {
			throw new AI_Exception('Empty context extraction response');
		}

		// When web search is enabled, manually extract JSON from text response
		if ($enable_web_search) {
			// Strip markdown code fences if present
			if (preg_match('/```(?:json)?\s*(.*?)\s*```/si', $text, $m)) {
				$text = $m[1];
			}

			// Extract JSON object if not starting with {
			$trimmed = trim($text);
			if (! preg_match('/^[\{\[]/', $trimmed)) {
				$start = strpos($trimmed, '{');
				if ($start !== false) {
					$end = strrpos($trimmed, '}');
					if ($end !== false) {
						$text = substr($trimmed, $start, $end - $start + 1);
					}
				}
			} else {
				$text = $trimmed;
			}
		}

		// @MODIFIED 2026-01-07: Sanitize JSON before decoding to handle control characters
		$text = $this->clean_json_string($text);

		$extracted_data = json_decode($text, true);

		if (json_last_error() !== JSON_ERROR_NONE) {
			// @MODIFIED 2026-01-07: Log the failed JSON for debugging
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[SEO Generator] JSON Decode Error: ' . json_last_error_msg());
				error_log('[SEO Generator] Bad JSON Snippet: ' . substr($text, 0, 500));
			}
			throw new AI_Exception('Failed to parse context extraction JSON: ' . json_last_error_msg());
		}

		return $extracted_data;
	}

	/**
	 * Call Perplexity API for context extraction
	 *
	 * @since 2.7.0
	 * @param string $prompt Extraction prompt
	 * @return array Parsed JSON response
	 * @throws AI_Exception If API call fails
	 */
	private function call_perplexity_for_extraction($prompt)
	{
		$endpoint = 'https://api.perplexity.ai/chat/completions';
		$api_key  = AI_Client::get_perplexity_key();
		$model    = AI_Client::get_perplexity_model();

		if (empty($api_key)) {
			throw new AI_Exception('Perplexity API key not configured');
		}

		$request_body = array(
			'model'              => $model,
			'messages'           => array(
				array(
					'role'    => 'system',
					'content' => 'You are a software context extractor. Use web search to find accurate info. Return ONLY valid JSON with no markdown, no code fences.',
				),
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
			'temperature'        => 0.2,
			'max_tokens'         => 2048,
			// @since 2.7.0: Enable web search for context extraction
			'web_search_options' => array(
				'search_context_size' => 'medium', // Balanced for context extraction
			),
		);

		// USE THE GATEWAY
		$response = $this->ai_client->execute_safe_request(
			$endpoint,
			array(
				'timeout' => 180,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode($request_body),
			),
			'perplexity'
		);

		if (is_wp_error($response)) {
			throw new AI_Exception('Perplexity context extraction gateway error: ' . $response->get_error_message());
		}

		$status_code = wp_remote_retrieve_response_code($response);
		if (200 !== $status_code) {
			throw new AI_Exception('Perplexity context extraction failed with status ' . $status_code);
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);


		if (! is_array($data) || empty($data['choices'][0]['message']['content'])) {
			throw new AI_Exception('Invalid Perplexity context extraction response structure');
		}

		$text = $data['choices'][0]['message']['content'];

		// @MODIFIED 2026-01-07: Ensure text is string before regex to prevent fatal error
		if (! is_string($text)) {
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[SEO Generator] Perplexity returned non-string content: ' . print_r($text, true));
			}
			$text = is_array($text) ? wp_json_encode($text) : (string) $text;
		}

		// Strip markdown code fences if present
		if (preg_match('/```(?:json)?\s*(.*?)\s*```/si', $text, $m)) {
			$text = $m[1];
		}

		// Extract JSON if not starting with {
		$trimmed = trim($text);
		if (! preg_match('/^[\{\[]/', $trimmed)) {
			$start = strpos($trimmed, '{');
			if ($start !== false) {
				$end = strrpos($trimmed, '}');
				if ($end !== false) {
					$text = substr($trimmed, $start, $end - $start + 1);
				}
			}
		} else {
			$text = $trimmed;
		}

		// @MODIFIED 2026-01-07: Sanitize JSON before decoding
		$text = $this->clean_json_string($text);

		$extracted_data = json_decode($text, true);

		if (json_last_error() !== JSON_ERROR_NONE) {
			// @MODIFIED 2026-01-07: Log the failed JSON for debugging
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[SEO Generator] Perplexity JSON Decode Error: ' . json_last_error_msg());
				error_log('[SEO Generator] Perplexity Bad JSON: ' . substr($text, 0, 500));
			}
			throw new AI_Exception('Failed to parse Perplexity context extraction JSON: ' . json_last_error_msg());
		}

		return $extracted_data;
	}

	/**
	 * Clean JSON string by removing invalid control characters
	 *
	 * @since 2.7.1
	 * @param string $json_str Raw JSON string
	 * @return string Sanitized string
	 */
	private function clean_json_string($json_str)
	{
		if (! is_string($json_str)) {
			return '';
		}

		// Remove control characters (0-31) except for:
		// 9 (Tab), 10 (Line Feed), 13 (Carriage Return)
		// Also remove 127 (Delete)
		$clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $json_str);

		return $clean;
	}
}
