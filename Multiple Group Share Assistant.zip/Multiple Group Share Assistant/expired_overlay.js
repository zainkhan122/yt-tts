// expired_overlay.js - Overlay for expired license users
(function() {
  'use strict';

  /**
   * Shows a small native-style popup to collect name + email before redirecting
   */
  function showSignupForm() {
    const existing = document.getElementById('su-signup-form-overlay');
    if (existing) existing.remove();

    // Restored on close/cancel/submit so keyboard/screen-reader users land back
    // where they started instead of at the top of the page.
    const previouslyFocused = document.activeElement;

    chrome.storage.local.get(['userEmail', 'userName'], (stored) => {
      ensureNativeStyles();
      const fbDark = isFbDarkMode();

      const overlay = document.createElement('div');
      overlay.id = 'su-signup-form-overlay';
      overlay.className = 'su-modal-backdrop';

      const card = document.createElement('div');
      card.className = 'su-native su-modal-card' + (fbDark ? ' su-dark' : '');
      card.setAttribute('role', 'dialog');
      card.setAttribute('aria-modal', 'true');
      card.setAttribute('aria-labelledby', 'su-modal-heading');

      const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

      card.innerHTML = `
        <button type="button" id="su-modal-close" class="su-modal-close-btn" aria-label="Close">${suIconSvg('x', 16)}</button>
        <h2 id="su-modal-heading" class="su-modal-heading">Remove our watermark</h2>
        <p class="su-modal-desc">Posts look cleaner and more professional without it. Enter your details to see upgrade options.</p>
        <form id="su-signup-form" novalidate>
          <div class="su-modal-field-group">
            <label for="su-name-input" class="su-modal-label">First name</label>
            <input id="su-name-input" name="firstName" type="text" class="su-modal-input" placeholder="Your first name"
              autocomplete="given-name" value="${esc(stored.userName || '')}">
            <p id="su-name-error" class="su-modal-field-error"></p>
          </div>
          <div class="su-modal-field-group">
            <label for="su-email-input" class="su-modal-label">Email</label>
            <input id="su-email-input" name="email" type="email" class="su-modal-input" placeholder="name@example.com"
              autocomplete="email" value="${esc(stored.userEmail || '')}">
            <p id="su-email-error" class="su-modal-field-error"></p>
          </div>
          <div class="su-modal-actions">
            <button type="button" id="su-cancel" class="su-modal-btn-ghost">Cancel</button>
            <button type="submit" id="su-submit" class="su-modal-btn-primary" disabled>See pricing</button>
          </div>
        </form>
      `;

      overlay.appendChild(card);
      document.body.appendChild(overlay);
      // Class toggle after insertion so the opacity transition actually animates.
      requestAnimationFrame(() => overlay.classList.add('su-modal-visible'));

      const form       = card.querySelector('#su-signup-form');
      const nameInput  = card.querySelector('#su-name-input');
      const emailInput = card.querySelector('#su-email-input');
      const nameError  = card.querySelector('#su-name-error');
      const emailError = card.querySelector('#su-email-error');
      const cancelBtn  = card.querySelector('#su-cancel');
      const submitBtn  = card.querySelector('#su-submit');
      const closeBtn   = card.querySelector('#su-modal-close');

      const isValidEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

      function updateSubmitState() {
        submitBtn.disabled = !(nameInput.value.trim() && isValidEmail(emailInput.value.trim()));
      }
      updateSubmitState();

      // Errors must only surface after the user has actually typed into a field —
      // autofocus can trigger an immediate, un-intended blur (e.g. Facebook's own
      // focus handling on the page underneath), which must not read as "invalid".
      let nameTouched = false;
      let emailTouched = false;

      nameInput.addEventListener('input', () => {
        nameTouched = true;
        if (nameInput.value.trim()) nameError.textContent = '';
        updateSubmitState();
      });
      nameInput.addEventListener('blur', () => {
        if (!nameTouched) return;
        nameError.textContent = nameInput.value.trim() ? '' : 'Please enter your first name.';
      });

      emailInput.addEventListener('input', () => {
        emailTouched = true;
        if (isValidEmail(emailInput.value.trim())) emailError.textContent = '';
        updateSubmitState();
      });
      emailInput.addEventListener('blur', () => {
        if (!emailTouched) return;
        emailError.textContent = isValidEmail(emailInput.value.trim()) ? '' : 'Please enter a valid email.';
      });

      function close() {
        document.removeEventListener('keydown', onKeydown, true);
        overlay.remove();
        if (previouslyFocused && document.body.contains(previouslyFocused) && typeof previouslyFocused.focus === 'function') {
          previouslyFocused.focus();
        }
      }

      cancelBtn.addEventListener('click', close);
      closeBtn.addEventListener('click', close);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

      // Esc closes; Tab/Shift+Tab wraps focus inside the modal instead of
      // escaping onto the Facebook page underneath.
      function onKeydown(e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          close();
          return;
        }
        if (e.key === 'Tab') {
          const focusable = Array.from(card.querySelectorAll('button, input'));
          if (!focusable.length) return;
          const first = focusable[0];
          const last = focusable[focusable.length - 1];
          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      }
      document.addEventListener('keydown', onKeydown, true);

      form.addEventListener('submit', (e) => {
        e.preventDefault();

        const name  = nameInput.value.trim();
        const email = emailInput.value.trim();

        if (!name) { nameError.textContent = 'Please enter your first name.'; nameInput.focus(); return; }
        if (!isValidEmail(email)) { emailError.textContent = 'Please enter a valid email.'; emailInput.focus(); return; }

        chrome.storage.local.set({ userEmail: email, userName: name, signupInitiated: true }, () => {
          chrome.runtime.sendMessage({ type: 'get_installation_id' }, (response) => {
            const installId = response && response.installationId ? response.installationId : '';
            const url = `about:blank`; // External URLs disabled - no license checks
            document.removeEventListener('keydown', onKeydown, true);
            overlay.remove();
            // Persistent 72h background watch (survives this tab closing) PLUS the
            // in-tab fast poll for the common "pays within a few minutes" case.
            armLicenseWatch();
            chrome.storage.local.set({ hasClickedSignup: true }, () => startLicensePolling());
            window.open(url, '_blank');
          });
        });
      });

      // Autofocus First Name on open.
      nameInput.focus();
    });
  }

  /**
   * Creates an unclickable overlay for expired users in the popup
   */
  function createPopupExpiredOverlay() {
    // Check if already exists
    if (document.getElementById('expired-license-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'expired-license-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99999;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: all;
      backdrop-filter: blur(10px);
    `;
    
    document.body.appendChild(overlay);
    
    // Make sure the validation view is on top of the overlay with relative positioning
    const validationView = document.getElementById('validation-view');
    const authSection = document.getElementById('auth-section');
    const settingsContainer = document.getElementById('settings-container');
    const wrapper = document.querySelector('.wrapper');
    
    if (validationView) {
      validationView.style.zIndex = '100000';
      validationView.style.position = 'relative';
    }
    if (authSection) {
      authSection.style.zIndex = '100000';
      authSection.style.position = 'relative';
    }
    if (settingsContainer) {
      settingsContainer.style.zIndex = '100000';
      settingsContainer.style.position = 'relative';
    }
    if (wrapper) {
      wrapper.style.position = 'relative';
    }
    
    // Ensure share container is behind and unclickable
    const shareContainer = document.getElementById('share-container');
    if (shareContainer) {
      shareContainer.style.pointerEvents = 'none';
      shareContainer.style.filter = 'blur(5px)';
      shareContainer.style.opacity = '0.3';
      shareContainer.style.zIndex = '1';
    }
  }

  /**
   * Removes the expired overlay from popup
   */
  function removePopupExpiredOverlay() {
    const overlay = document.getElementById('expired-license-overlay');
    if (overlay) overlay.remove();
    
    // Restore normal functionality
    const shareContainer = document.getElementById('share-container');
    if (shareContainer) {
      shareContainer.style.pointerEvents = 'auto';
      shareContainer.style.filter = 'none';
      shareContainer.style.opacity = '1';
    }
    
    // Reset z-indexes
    const validationView = document.getElementById('validation-view');
    const authSection = document.getElementById('auth-section');
    const settingsContainer = document.getElementById('settings-container');
    
    if (validationView) validationView.style.zIndex = '';
    if (authSection) authSection.style.zIndex = '';
    if (settingsContainer) settingsContainer.style.zIndex = '';
  }

  /**
   * Creates the expired user button on Facebook (replaces the action buttons)
   */
  /**
   * Detects Facebook's active theme. FB toggles the __fb-dark-mode class on <html>;
   * the computed-background luminance check is a fallback for markup changes.
   */
  function isFbDarkMode() {
    const html = document.documentElement;
    if (html.classList.contains('__fb-dark-mode')) return true;
    if (html.classList.contains('__fb-light-mode')) return false;
    try {
      const bg = getComputedStyle(document.body).backgroundColor;
      const m = bg && bg.match(/\d+/g);
      if (m && m.length >= 3) {
        return (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) < 100;
      }
    } catch (e) {}
    return false;
  }

  /**
   * Injects the shared namespaced stylesheet for our in-dialog UI (toolbar + upsell
   * banner). One component, two themes: everything reads CSS variables from the
   * .su-native root class; .su-dark swaps the variable values to FB's dark surfaces.
   * !important throughout so Facebook's own button/input resets can't bleed in.
   * Idempotent — safe to call from every file that renders themed UI.
   */
  function ensureNativeStyles() {
    if (document.getElementById('su-native-styles')) return;
    const style = document.createElement('style');
    style.id = 'su-native-styles';
    style.textContent = `
      .su-native {
        --su-surface: #ffffff;
        --su-surface-2: #f0f2f5;
        --su-hover: #ebedf0;
        --su-text: #050505;
        --su-text-2: #65676b;
        --su-border: #ced0d4;
        --su-accent: #0866FF;
        --su-accent-hover: #0757ce;
        --su-badge-bg: #e4e6eb;
        --su-modal-input-bg: #ffffff;
        --su-modal-border: #ced0d4;
        font-family: "Segoe UI", Helvetica, Arial, sans-serif !important;
        color: var(--su-text);
      }
      .su-native.su-dark {
        --su-surface: #242526;
        --su-surface-2: #3a3b3c;
        --su-hover: #3a3b3c;
        --su-text: #E4E6EB;
        --su-text-2: #B0B3B8;
        --su-border: #3E4042;
        --su-badge-bg: #3a3b3c;
        --su-modal-input-bg: #3A3B3C;
        --su-modal-border: #4E4F50;
      }
      .su-native .su-ghost-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
        /* Basis AUTO, not 0: the buttons' labels differ a lot in width
           ("Sync Latest Groups 47" vs "Presets 3"). With basis 0 every button got
           an equal third of the row and the longest label overflowed its own box
           (clipped icon + text). Auto sizes each button to its content first, then
           shares any leftover space via grow — so text always fits, and the row
           still spans the full width. */
        flex: 1 1 auto !important;
        min-width: 0 !important;
        min-height: 40px !important;
        background: transparent !important;
        border: 1px solid var(--su-border) !important;
        color: var(--su-text) !important;
        border-radius: 8px !important;
        padding: 10px 14px !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        font-family: inherit !important;
        cursor: pointer !important;
        white-space: nowrap !important;
        /* NO overflow:hidden here. The guidance ring (.su-attn::after) is drawn at
           inset:-4px — OUTSIDE this button's box — so clipping the overflow makes
           the ring vanish entirely on every toolbar button. Text fitting is handled
           by flex-basis:auto above plus the toolbar's flex-wrap, not by clipping. */
        line-height: 1.4 !important;
        transition: background 0.15s ease !important;
      }
      .su-native .su-ghost-btn:hover { background: var(--su-hover) !important; }
      .su-native .su-ghost-btn:disabled { cursor: default !important; }
      .su-native .su-badge {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: var(--su-badge-bg) !important;
        color: var(--su-text-2) !important;
        border-radius: 10px !important;
        padding: 2px 7px !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        line-height: 1.5 !important;
        flex-shrink: 0 !important;
      }
      .su-native .su-primary-btn {
        display: inline-flex !important;
        align-items: center !important;
        background: var(--su-accent) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 6px !important;
        height: 24px !important;
        padding: 0 12px !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        font-family: inherit !important;
        cursor: pointer !important;
        flex-shrink: 0 !important;
        white-space: nowrap !important;
        transition: background 0.15s ease !important;
      }
      .su-native .su-primary-btn:hover { background: var(--su-accent-hover) !important; }
      .su-native .su-primary-btn:disabled { opacity: 0.75 !important; cursor: default !important; }
      /* "Remove Watermark" attention pulse (v18.2) — see startRemoveWatermarkFlash().
         .su-wm-flash-host only supplies the easing (added for the pulse, removed
         after) so the button is byte-for-byte its normal self the rest of the time.
         The 380ms ramp is deliberately ~half the 780ms hold either side: a slow
         breathe reads as "this is what we mean", a fast one reads as an alarm.
         Retune it and WM_FLASH_ON_MS/OFF_MS together, or the colour will still be
         travelling when the next beat starts.
         The :hover twin is required: the pointer is often parked over the banner. */
      .su-native .su-primary-btn.su-wm-flash-host {
        transition: background 380ms ease-in-out, transform 380ms ease-in-out, box-shadow 380ms ease-in-out !important;
      }
      .su-native .su-primary-btn.su-wm-flash,
      .su-native .su-primary-btn.su-wm-flash:hover {
        background: #F57C00 !important;
        transform: scale(1.16) !important;
        box-shadow: 0 0 0 4px rgba(245, 124, 0, 0.32) !important;
      }
      /* The colour carries the message; the grow is decoration. Drop only the grow. */
      @media (prefers-reduced-motion: reduce) {
        .su-native .su-primary-btn.su-wm-flash,
        .su-native .su-primary-btn.su-wm-flash:hover { transform: none !important; }
      }
      .su-native .su-icon-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 24px !important;
        height: 24px !important;
        border: none !important;
        border-radius: 50% !important;
        background: transparent !important;
        color: var(--su-text-2) !important;
        cursor: pointer !important;
        padding: 0 !important;
        flex-shrink: 0 !important;
        transition: background 0.15s ease !important;
      }
      .su-native .su-icon-btn:hover { background: var(--su-hover) !important; }
      .su-native .su-cb {
        -webkit-appearance: none !important;
        appearance: none !important;
        width: 18px !important;
        height: 18px !important;
        box-sizing: border-box !important;
        border: 2px solid var(--su-text-2) !important;
        border-radius: 4px !important;
        background: transparent !important;
        margin: 0 !important;
        cursor: pointer !important;
        display: inline-block !important;
        position: relative !important;
        flex-shrink: 0 !important;
        transition: background 0.1s ease, border-color 0.1s ease !important;
      }
      .su-native .su-cb:checked { background: #0866FF !important; border-color: #0866FF !important; }
      .su-native .su-cb:checked::after {
        content: '';
        position: absolute;
        inset: 0;
        background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='3.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 6 9 17l-5-5'/%3E%3C/svg%3E") no-repeat center / 12px 12px;
      }

      /* --- Signup/lead-capture modal --- */
      .su-modal-backdrop {
        position: fixed !important;
        inset: 0 !important;
        background: rgba(0, 0, 0, 0.6) !important;
        z-index: 2147483647 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        opacity: 0 !important;
        transition: opacity 150ms ease !important;
      }
      .su-modal-backdrop.su-modal-visible { opacity: 1 !important; }
      .su-native.su-modal-card {
        background: var(--su-surface) !important;
        color: var(--su-text) !important;
        border-radius: 8px !important;
        padding: 24px !important;
        width: 100% !important;
        max-width: 440px !important;
        box-sizing: border-box !important;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.24) !important;
        position: relative !important;
        margin: 16px !important;
      }
      .su-native .su-modal-close-btn {
        position: absolute !important;
        top: 4px !important;
        right: 4px !important;
        width: 32px !important;
        height: 32px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        border: none !important;
        border-radius: 50% !important;
        background: transparent !important;
        color: var(--su-text-2) !important;
        cursor: pointer !important;
        padding: 0 !important;
        transition: background 0.15s ease !important;
      }
      .su-native .su-modal-close-btn:hover { background: var(--su-hover) !important; }
      .su-native .su-modal-heading {
        margin: 0 32px 4px 0 !important;
        font-size: 17px !important;
        font-weight: 700 !important;
        color: var(--su-text) !important;
      }
      .su-native .su-modal-desc {
        margin: 0 0 16px 0 !important;
        font-size: 13px !important;
        color: var(--su-text-2) !important;
      }
      .su-native .su-modal-field-group { margin-bottom: 16px !important; }
      .su-native .su-modal-label {
        display: block !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        color: var(--su-text) !important;
        margin-bottom: 4px !important;
      }
      .su-native .su-modal-input {
        width: 100% !important;
        box-sizing: border-box !important;
        padding: 9px 10px !important;
        border: 1.5px solid var(--su-modal-border) !important;
        border-radius: 8px !important;
        font-size: 14px !important;
        font-family: inherit !important;
        color: var(--su-text) !important;
        background: var(--su-modal-input-bg) !important;
        outline: none !important;
        transition: border-color 0.15s ease, box-shadow 0.15s ease !important;
      }
      .su-native .su-modal-input::placeholder { color: var(--su-text-2) !important; }
      .su-native .su-modal-input:focus {
        border-color: var(--su-accent) !important;
        box-shadow: 0 0 0 2px var(--su-accent) !important;
      }
      .su-native .su-modal-hint {
        margin: 4px 0 0 0 !important;
        font-size: 12px !important;
        color: var(--su-text-2) !important;
      }
      .su-native .su-modal-field-error {
        margin: 4px 0 0 0 !important;
        font-size: 12px !important;
        color: #f02849 !important;
        min-height: 0 !important;
      }
      .su-native .su-modal-actions {
        display: flex !important;
        justify-content: flex-end !important;
        gap: 8px !important;
        margin-top: 24px !important;
      }
      .su-native .su-modal-btn-ghost {
        padding: 9px 16px !important;
        border: 1.5px solid var(--su-modal-border) !important;
        border-radius: 8px !important;
        background: transparent !important;
        color: var(--su-text) !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        font-family: inherit !important;
        cursor: pointer !important;
        transition: background 0.15s ease !important;
      }
      .su-native .su-modal-btn-ghost:hover { background: var(--su-hover) !important; }
      .su-native .su-modal-btn-primary {
        -webkit-appearance: none !important;
        appearance: none !important;
        padding: 9px 16px !important;
        border: none !important;
        border-radius: 8px !important;
        background: var(--su-accent) !important;
        color: #ffffff !important;
        opacity: 1 !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        font-family: inherit !important;
        cursor: pointer !important;
        transition: background 0.15s ease, opacity 0.15s ease !important;
      }
      .su-native .su-modal-btn-primary:hover:not(:disabled) { background: var(--su-accent-hover) !important; }
      .su-native .su-modal-btn-primary:disabled {
        background: var(--su-accent) !important;
        color: #ffffff !important;
        opacity: 0.4 !important;
        cursor: not-allowed !important;
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * 16px Lucide-style inline SVGs for the banner (stroke: currentColor so they
   * inherit the themed text/accent color).
   */
  function suIconSvg(name, size = 16) {
    const paths = {
      gem: '<path d="M6 3h12l4 6-10 13L2 9Z"/><path d="M11 3 8 9l4 13 4-13-3-6"/><path d="M2 9h20"/>',
      sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
      x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>'
    };
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">${paths[name] || ''}</svg>`;
  }

  // Only a VISIBLE banner counts as "already there" — FB keeps previous share
  // screens mounted as hidden dialogs, and a stale banner inside one of those
  // must not veto inserting the real banner (it gets cleaned up instead).
  function hasLiveExpiredCta() {
    let live = false;
    document.querySelectorAll('[id="share-unlimited-expired-cta"]').forEach(el => {
      if (el.getClientRects().length) live = true;
      else el.remove();
    });
    return live;
  }

  function createFacebookExpiredButton(container) {
    // Check if expired button already exists
    if (hasLiveExpiredCta()) return;
    // User dismissed the banner this session — respect it until the tab closes
    if (sessionStorage.getItem('su_upsellBannerDismissed') === '1') return;

    // Check if user has an expiry date (new user vs expired user)
    chrome.storage.local.get(['authExpiry'], (result) => {
      // Re-check inside the async callback: rapid observer-driven calls can all pass
      // the sync guard above before any of them has inserted the banner.
      if (hasLiveExpiredCta()) return;

      const { authExpiry } = result;
      const hasNeverStartedTrial = !authExpiry; // No expiry date means never started
      const hasExpiredTrial = authExpiry && new Date(authExpiry) <= new Date();
      
      if (hasNeverStartedTrial) {
        // === NEW USER (NON-BLOCKING BANNER, v15.8) ===
        // Sharing works free-forever with a watermark — NEVER remove the sharing UI.
        // This banner upsells paid watermark removal (email + name signup, then checkout).
        console.log('User status: Never started trial (no authExpiry) — free mode with watermark');

        ensureNativeStyles();
        const expiredContainer = document.createElement('div');
        expiredContainer.id = 'share-unlimited-expired-cta';
        expiredContainer.className = 'su-native' + (isFbDarkMode() ? ' su-dark' : '');
        // Slim single-row banner on the themed surface — no shadow, no hover lift.
        expiredContainer.style.cssText = `
            height: 32px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0 6px 0 12px;
            background: var(--su-surface);
            border: 1px solid var(--su-border);
            border-radius: 8px;
            margin-bottom: 8px;
            z-index: 10;
            position: relative;
        `;

        expiredContainer.innerHTML = `
            <span style="display: inline-flex; color: var(--su-accent); flex-shrink: 0;">${suIconSvg('gem', 16)}</span>
            <span style="flex: 1; min-width: 0; color: var(--su-text); font-size: 13px; font-weight: 400; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Free Plan • Posts include watermark</span>
            <button id="su-upsell-action" class="su-primary-btn">Remove Watermark</button>
            <button id="su-upsell-dismiss" class="su-icon-btn" aria-label="Dismiss">${suIconSvg('x', 14)}</button>
        `;

        // Checks the server BEFORE selling — a user with no local authExpiry may
        // already have paid (fresh install, cleared storage, new machine).
        wireRemoveWatermarkButton(expiredContainer.querySelector('#su-upsell-action'), expiredContainer);

        expiredContainer.querySelector('#su-upsell-dismiss').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            sessionStorage.setItem('su_upsellBannerDismissed', '1');
            expiredContainer.remove();
        });

        // Insert into the dialog
        if (container && container.parentElement) {
            container.parentElement.insertBefore(expiredContainer, container);
        }

      } else if (hasExpiredTrial) {
        // === EXPIRED USER (BANNER MODE) ===
        // Do NOT remove existing buttons.
        
        ensureNativeStyles();
        const expiredContainer = document.createElement('div');
        expiredContainer.id = 'share-unlimited-expired-cta';
        expiredContainer.className = 'su-native' + (isFbDarkMode() ? ' su-dark' : '');
        // Slim single-row banner on the themed surface — one accent color, no shadow.
        expiredContainer.style.cssText = `
            height: 32px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0 6px 0 12px;
            background: var(--su-surface);
            border: 1px solid var(--su-border);
            border-radius: 8px;
            margin-bottom: 8px;
            z-index: 10;
            position: relative;
        `;

        expiredContainer.innerHTML = `
            <span style="display: inline-flex; color: var(--su-accent); flex-shrink: 0;">${suIconSvg('gem', 16)}</span>
            <span style="flex: 1; min-width: 0; color: var(--su-text); font-size: 13px; font-weight: 400; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Free Plan • Posts include watermark</span>
            <button id="su-upsell-action" class="su-primary-btn">Remove Watermark</button>
            <button id="su-upsell-dismiss" class="su-icon-btn" aria-label="Dismiss">${suIconSvg('x', 14)}</button>
        `;

        const actionBtn = expiredContainer.querySelector('#su-upsell-action');

        expiredContainer.querySelector('#su-upsell-dismiss').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            sessionStorage.setItem('su_upsellBannerDismissed', '1');
            expiredContainer.remove();
        });

        // Same check-then-sell handler as the never-signed-up branch — one code path,
        // so the two states can never drift apart again.
        wireRemoveWatermarkButton(actionBtn, expiredContainer);


        // Insert into the dialog (before container)
        if (container && container.parentElement) {
            container.parentElement.insertBefore(expiredContainer, container);
        }
      }
    });
  }

  /**
   * Checks if the user's license is expired
   */
  function checkLicenseExpiry(callback) {
    chrome.storage.local.get(['authExpiry'], (result) => {
      const { authExpiry } = result;
      const isExpired = !authExpiry || new Date(authExpiry) <= new Date();
      callback(isExpired);
    });
  }

  /**
   * THE watermark predicate (v16.8). `shareToSelectedGroups` stamps a watermark when
   * this is true, and EVERY "Remove Watermark" affordance is shown when this is true.
   *
   * They must be the same function. Previously the button's visibility was derived
   * separately from the watermark decision, so a user could be watermarked with no
   * control on screen to fix it. The rule now: the button disappears only when the
   * user would genuinely share clean — never before.
   *
   * This file loads FIRST (see manifest content_scripts order), so every downstream
   * script can rely on `window.ExpiredOverlay.isWatermarkActive`.
   */
  function isWatermarkActive() {
    return Promise.resolve(false);
  }

  // A slow breathe, not a strobe: the pulse runs for the whole window between the
  // ghost ANNOUNCING the watermark and it actually being typed, which is several
  // seconds (composer wait + the caption typing out character by character). At
  // burst speed that reads as an error state; held long and slow it reads as
  // "this is the thing we're talking about". Must stay in step with the CSS
  // transition in ensureNativeStyles — the ramp is ~half the hold.
  const WM_FLASH_ON_MS = 780;
  const WM_FLASH_OFF_MS = 780;
  // Hard ceiling. The stop is driven by the share loop, so a group that fails
  // between the two triggers would otherwise leave the button pulsing forever.
  const WM_FLASH_MAX_MS = 90000;

  let wmFlashState = null;   // { timer, on, endsAt } while a pulse is running

  // Document-wide by [id=], and visible-only: duplicate IDs are real here (hidden
  // previous share screens stay mounted). Same rule as hasLiveExpiredCta — but
  // this one must NOT remove the hidden copies, since it runs mid-share while the
  // picker is legitimately parked behind the composer. Re-queried every tick so a
  // banner re-inserted mid-pulse joins in and a removed one just drops out.
  function wmFlashTargets() {
    return Array.from(document.querySelectorAll('[id="su-upsell-action"]'))
      .filter(btn => btn.getClientRects().length);
  }

  function wmFlashPaint(on) {
    wmFlashTargets().forEach(btn => {
      btn.classList.add('su-wm-flash-host');
      btn.classList.toggle('su-wm-flash', on);
    });
  }

  function wmFlashClearAll() {
    document.querySelectorAll('[id="su-upsell-action"]').forEach(btn =>
      btn.classList.remove('su-wm-flash', 'su-wm-flash-host'));
  }

  /**
   * Starts pulsing every VISIBLE "Remove Watermark" button orange, with a slow
   * grow. Driven by the share loop: started when the ghost cursor ANNOUNCES the
   * watermark ("…then our watermark on the line below") and stopped when the
   * watermark actually lands in the composer (v18.2).
   *
   * The point is purely associative: for as long as we are talking about the
   * watermark, the one control that removes it is lit. It sells nothing and clicks
   * nothing.
   *
   * **Toggled from JS rather than a CSS `@keyframes` animation, on purpose.** The
   * base `.su-primary-btn` rule sets `background` with `!important` (it has to —
   * Facebook's stylesheet is aggressive on bare `button`), and `!important` inside
   * a keyframe block is ignored per spec, so an animated background would simply
   * never paint. A higher-specificity `!important` class DOES win the cascade, so
   * the colour is switched by class and only the easing is left to CSS.
   *
   * Cosmetic and best-effort: never awaits, never throws, and no-ops when no
   * banner is on screen.
   */
  function startRemoveWatermarkFlash() {
    try {
      stopRemoveWatermarkFlash();

      const all = Array.from(document.querySelectorAll('[id="su-upsell-action"]'));
      if (!all.some(btn => btn.getClientRects().length)) {
        // Says WHY nothing flashed, which is otherwise indistinguishable from the
        // feature being broken: 0 of 0 means the banner was never inserted (paid
        // user, or dismissed this session); 0 of N means it exists but Facebook has
        // it parked in a hidden dialog behind the composer.
        console.log(`💧 Watermark flash: no visible Remove Watermark button (0 of ${all.length} mounted)`);
        return;
      }

      ensureNativeStyles();
      wmFlashState = { timer: null, on: true, endsAt: Date.now() + WM_FLASH_MAX_MS };
      wmFlashPaint(true);

      const tick = () => {
        if (!wmFlashState) return;
        if (Date.now() >= wmFlashState.endsAt) {
          console.warn('💧 Watermark flash hit its safety cap — stopping.');
          stopRemoveWatermarkFlash();
          return;
        }
        wmFlashState.on = !wmFlashState.on;
        wmFlashPaint(wmFlashState.on);
        wmFlashState.timer = setTimeout(tick, wmFlashState.on ? WM_FLASH_ON_MS : WM_FLASH_OFF_MS);
      };
      wmFlashState.timer = setTimeout(tick, WM_FLASH_ON_MS);
    } catch (e) { /* cosmetic — must never reach the share loop */ }
  }

  /**
   * Ends the pulse. Safe to call when nothing is running (the share loop calls it
   * defensively when a group fails), and safe to call twice.
   *
   * If the button is mid-orange it is held for the rest of that beat before going
   * back to blue, so the pulse never snaps off half-lit — the CSS transition then
   * carries it home.
   */
  function stopRemoveWatermarkFlash() {
    try {
      if (!wmFlashState) { wmFlashClearAll(); return; }
      const wasOn = wmFlashState.on;
      clearTimeout(wmFlashState.timer);
      wmFlashState = null;
      if (wasOn) {
        wmFlashPaint(false);
        // Let the transition finish before the easing class is pulled, or the
        // scale/glow would drop instantly instead of easing out.
        setTimeout(wmFlashClearAll, WM_FLASH_OFF_MS);
      } else {
        wmFlashClearAll();
      }
    } catch (e) { /* cosmetic — must never reach the share loop */ }
  }

  /**
   * Opens the checkout/renewal page for a user we've just CONFIRMED is unlicensed.
   * Collects name+email first if we don't have them yet.
   */
  function openUpgradeDestination() {
    chrome.storage.local.get(['userEmail', 'userName', 'uniqueInstallationId'], (result) => {
      const { userEmail, userName, uniqueInstallationId } = result;

      if (!userEmail) {
        // No details on file — the form collects them and arms the watch on submit.
        showSignupForm();
        return;
      }

      armLicenseWatch();
      startLicensePolling();

      const nameParam = userName ? `&name=${encodeURIComponent(userName)}` : '';
      const open = (id) =>
        window.open(
          `about:blank`, // External URLs disabled - no license checks
          '_blank'
        );

      if (uniqueInstallationId) {
        open(uniqueInstallationId);
      } else {
        chrome.runtime.sendMessage({ type: 'get_installation_id' }, (response) => {
          if (response && response.installationId) open(response.installationId);
        });
      }
    });
  }

  /**
   * Wires a "Remove Watermark" button so it CHECKS BEFORE IT SELLS — for every user
   * state, not just expired ones.
   *
   * This is the user's one self-service repair path: if their watermark is caused by
   * stale/missing local license state rather than by not having paid, clicking here
   * re-reads the server and clears it. Before v16.8 only the expired branch checked;
   * the never-signed-up branch went straight to the signup form, so a paying user
   * whose `authExpiry` never landed locally could never fix themselves — the button
   * only ever tried to sell them something they already owned.
   */
  function wireRemoveWatermarkButton(actionBtn, bannerContainer) {
    actionBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();

      const originalText = actionBtn.textContent;
      actionBtn.disabled = true;
      actionBtn.textContent = 'Checking…';

      const hasLicense = await checkAndActivateLicense();

      if (hasLicense) {
        // Their license was fine all along — local state was stale. Repaired.
        bannerContainer.innerHTML =
          '<span style="margin: 0 auto; color: #ffffff; font-size: 13px; font-weight: 600;">✓ License found — watermark removed</span>';
        bannerContainer.style.background = '#42b72a';
        bannerContainer.style.borderColor = '#42b72a';
        chrome.storage.local.set({ hasClickedContinueSharing: false }, () => {
          setTimeout(() => {
            bannerContainer.style.opacity = '0';
            setTimeout(() => bannerContainer.remove(), 500);
          }, 1500);
        });
        return;
      }

      // Genuinely unlicensed — now, and only now, sell.
      actionBtn.disabled = false;
      actionBtn.textContent = originalText;
      openUpgradeDestination();
    });
  }

  /**
   * Checks for license and activates if found
   * Returns true if valid license found, false otherwise
   */
  async function checkAndActivateLicense() {
    return new Promise((resolve) => {
      // background/license.js owns the storage write — a network failure or an
      // unrecognised install ID resolves 'unknown' and leaves local state alone
      // rather than downgrading the user to expired.
      chrome.runtime.sendMessage({ type: 'refresh_license' }, (response) => {
        if (chrome.runtime.lastError || !response) {
          resolve(false);
          return;
        }
        if (response.status === 'active') {
          console.log('✓ License activated! Expiry:', response.expiry);
          resolve(true);
          return;
        }
        resolve(false);
      });
    });
  }

  /**
   * Arms the persistent background upgrade watch. Every "Remove Watermark" /
   * renewal CTA must call this BEFORE opening the checkout tab.
   */
  function armLicenseWatch() {
    try {
      chrome.runtime.sendMessage({ type: 'arm_license_watch' }, () => {
        // Swallow lastError — the watch is best-effort and must never block the
        // checkout tab from opening.
        void chrome.runtime.lastError;
      });
    } catch (e) {
      console.warn('Could not arm license watch:', e);
    }
  }

  /**
   * Polls for license activation every 5 seconds
   * Stops after 10 minutes or when license is found
   */
  function startLicensePolling() {
    let pollCount = 0;
    const maxPolls = 120; // 10 minutes (120 * 5 seconds)
    
    const pollInterval = setInterval(async () => {
      pollCount++;
      console.log(`License polling attempt ${pollCount}/${maxPolls}...`);
      
      const hasLicense = await checkAndActivateLicense();
      
      if (hasLicense) {
        console.log('✓ License detected! Switching to regular overlay...');
        clearInterval(pollInterval);
        
        // Find the container and switch overlay
        const expiredContainer = document.getElementById('share-unlimited-expired-cta');
        if (expiredContainer && expiredContainer.parentElement) {
          const container = expiredContainer.nextElementSibling;
          switchToRegularOverlay(container);
        }
      } else if (pollCount >= maxPolls) {
        // Stop the in-tab poll only. The flag is NOT cleared here anymore — the
        // 72h background alarm owns the pending-upgrade state now, and clearing
        // it after 10 minutes is precisely what stranded users who paid later.
        console.log('In-tab license polling stopped after 10 minutes — background watch continues');
        clearInterval(pollInterval);
      }
    }, 5000); // Check every 5 seconds
    
    // Store interval ID so it can be cleared if needed
    window.licensePollingInterval = pollInterval;
  }

  /**
   * Switches from expired overlay to regular overlay with the full UI
   */
  function switchToRegularOverlay(container) {
    // Remove the expired button
    const expiredContainer = document.getElementById('share-unlimited-expired-cta');
    if (expiredContainer) {
      expiredContainer.remove();
    }
    
    // Stop any ongoing polling
    if (window.licensePollingInterval) {
      clearInterval(window.licensePollingInterval);
      window.licensePollingInterval = null;
    }
    
    // Clear both flags
    chrome.storage.local.set({ 
      hasClickedSignup: false,
      hasClickedContinueSharing: false
    });
    
    // Now add the regular Select All checkbox and buttons
    // This requires the UI module to be available
    if (window.ShareUnlimited && window.ShareUnlimited.UI && window.ShareUnlimited.UI.addSelectAllCheckbox) {
      // Resolve the share dialog across both FB markup variants (aria-labelledby vs
      // aria-label="Share to a group"); fall back to the legacy selector if Core isn't ready.
      const dialog = (window.ShareUnlimited.Core && window.ShareUnlimited.Core.findShareDialog)
        ? window.ShareUnlimited.Core.findShareDialog()
        : document.querySelector('div[role="dialog"][aria-labelledby]');
      if (dialog) {
        console.log('✓ Adding regular UI elements...');
        window.ShareUnlimited.UI.addSelectAllCheckbox(dialog);
        
        // Also add checkboxes to groups if they're not there
        if (window.ShareUnlimited.UI.addCheckboxesToGroups) {
          window.ShareUnlimited.UI.addCheckboxesToGroups();
        }
      }
    }
    
    console.log('✓ Successfully switched to regular overlay!');
  }

  /**
   * Initializes license polling if user has previously clicked signup (new user only)
   * For expired users, just maintains the button visibility
   */
  function initializeLicensePollingIfNeeded() {
    chrome.storage.local.get(['hasClickedSignup', 'hasClickedContinueSharing', 'authExpiry'], (result) => {
      const { hasClickedSignup, hasClickedContinueSharing, authExpiry } = result;
      const isStillExpired = !authExpiry || new Date(authExpiry) <= new Date();

      // Resume polling for ANY unlicensed user with a pending upgrade. The old
      // `!authExpiry` test excluded expired users entirely — the exact group most
      // likely to be mid-renewal.
      if (hasClickedSignup && isStillExpired) {
        console.log('Resuming license polling from previous session...');
        startLicensePolling();
      } else if (hasClickedSignup && !isStillExpired) {
        // Has valid license now, clear the flag
        chrome.storage.local.set({ hasClickedSignup: false });
      }
      
      // For expired users who clicked continue sharing, just maintain state
      // The button will show based on the flag when the UI is recreated
      if (hasClickedContinueSharing && !isStillExpired) {
        // License is now valid, clear the flag
        chrome.storage.local.set({ hasClickedContinueSharing: false });
      }
    });
  }

  // Start polling on load if needed
  initializeLicensePollingIfNeeded();

  // Remove the upsell banner the moment a license/trial becomes active. Covers
  // popup-side activation, where no FB-side polling is running — without this the
  // stale "Remove Watermark" banner would sit there until a page reload.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.authExpiry) return;
    const newExpiry = changes.authExpiry.newValue;
    if (newExpiry && new Date(newExpiry) > new Date()) {
      const banner = document.getElementById('share-unlimited-expired-cta');
      if (banner) banner.remove();
    }
  });

  // Export functions to global namespace
  window.ExpiredOverlay = {
    createPopupExpiredOverlay,
    removePopupExpiredOverlay,
    createFacebookExpiredButton,
    checkLicenseExpiry,
    checkAndActivateLicense,
    // The single watermark predicate — watermark application AND every "Remove
    // Watermark" affordance must both read this. Never re-derive it locally.
    isWatermarkActive,
    // The ONE click handler for every upgrade CTA, wherever it renders (in-dialog
    // banner, post-share success modal, anything added later). It checks the server
    // before it sells, so a user whose licence merely failed to land locally is
    // repaired instead of re-sold. New CTAs wire through this — never their own.
    wireRemoveWatermarkButton,
    // Cosmetic attention pulse on that CTA. The share loop brackets it around the
    // window where the watermark is being announced and then typed; stop() is safe
    // to call unpaired. No-ops when no banner is on screen.
    startRemoveWatermarkFlash,
    stopRemoveWatermarkFlash,
    startLicensePolling,
    switchToRegularOverlay,
    // Shared theme system for in-dialog UI (used by content_ui_elements.js too —
    // this file loads first, so the helpers are always available downstream)
    ensureNativeStyles,
    isFbDarkMode
  };

})();
