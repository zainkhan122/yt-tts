<?php

/**
 * Plugin Autoloader
 *
 * Handles on-demand loading of all plugin classes.
 *
 * @package WP_News_MCQ_Generator
 * @version 1.2 - Added exception for widget classes
 */

if (! defined('ABSPATH')) {
	exit;
}

spl_autoload_register('nm_mcq_autoloader');

/**
 * Autoloader function.
 *
 * Loads a class file based on its name.
 * e.g., 'NM_Database_Manager' -> 'class-nm-database-manager.php'
 *
 * @param string $class_name The name of the class to load.
 */
function nm_mcq_autoloader($class_name)
{

	// ✅ v9.0.0: Video Studio is now VS_Core in separate mcq-video-studio module
	if (
		$class_name === 'NM_MCQ_Topic_Widget' ||
		$class_name === 'NM_Featured_Topics_Widget'
	) {
		return;
	}

	// We only care about our plugin's classes (prefixed with NM_)
	if (strpos($class_name, 'NM_') !== 0) {
		return;
	}

	// Convert class name to file name
	// 1. Remove the "NM_" prefix
	$class_base = substr($class_name, 3); // "Database_Manager" or "Dashboard_Helpers"

	// 2. Convert underscores to hyphens
	$class_base_hyphenated = str_replace('_', '-', $class_base); // "Database-Manager" or "Dashboard-Helpers"

	// 3. Convert to lowercase
	$class_base_lower = strtolower($class_base_hyphenated); // "database-manager" or "dashboard-helpers"

	// 4. Add the prefix
	$file_name = 'class-nm-' . $class_base_lower . '.php'; // "class-nm-database-manager.php" or "class-nm-dashboard-helpers.php"

	// Build the full file path
	$file_path = NM_PLUGIN_PATH . 'includes/' . $file_name;

	// Check if the file exists and load it
	if (file_exists($file_path)) {
		require_once $file_path;
	} else {
		// Log if a file is missing
	}
}
