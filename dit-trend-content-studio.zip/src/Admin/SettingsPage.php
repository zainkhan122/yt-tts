<?php

/**
 * Admin Menu
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New admin menu for TrendStudio
 */

namespace DIT\TrendStudio\Admin;

use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\Quota_Pause_Manager;
use DIT\TrendStudio\Sources\Idea_Importer;
use DIT\TrendStudio\Core\Plugin;
use DIT\TrendStudio\Integrations\Gemini\Client; // Added for API usage count
use DIT\TrendStudio\Services\Smoke_Test_Service; // @MODIFIED 2026-02-25 - Smoke test

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Menu Handler
 */
class SettingsPage
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Idea importer instance
     *
     * @var Idea_Importer
     */
    private Idea_Importer $idea_importer;

    /**
     * Collage Admin instance
     * @var Collage_Admin|null
     */
    private $collage_admin;

    /**
     * Constructor
     *
     * @param Logger        $logger        Logger instance
     * @param Idea_Importer $idea_importer Idea importer instance
     */
    public function __construct(Logger $logger, Idea_Importer $idea_importer)
    {
        $this->logger = $logger;
        $this->idea_importer = $idea_importer;
    }

    public function set_collage_admin($admin)
    {
        $this->collage_admin = $admin;
    }

    /**
     * Initialize admin menu
     *
     * @return void
     */
    public function init()
    {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
	add_action('admin_init', array($this, 'register_settings'));
	add_action('admin_init', array($this, 'handle_settings_save'));
	add_action('admin_init', array($this, 'handle_debug_log_path_save'));
        // @MODIFIED 2026-01-14 - Batch status polling for jobs page
        add_action('wp_ajax_dit_ts_batch_status', array($this, 'ajax_batch_status'));
        // @MODIFIED 2026-02-24 - Removed duplicate AJAX hook. Core\Plugin owns dit_ts_force_run_job.
        // @MODIFIED 2026-01-14 - Unified Gap Analysis
        add_action('wp_ajax_dit_ts_analyze_gap', array($this, 'ajax_analyze_gap'));
        // @MODIFIED 2026-01-30 - Clear logs
        add_action('wp_ajax_dit_ts_clear_logs', array($this, 'ajax_clear_logs'));
        // @MODIFIED 2026-01-30 - Process Action Scheduler queue manually
		add_action('wp_ajax_dit_ts_process_queue', array($this, 'ajax_process_queue'));
		add_action('wp_ajax_dit_ts_custom_test_connection', array($this, 'ajax_custom_test_connection'));
        // @MODIFIED 2026-02-12 - Reset System Status
        add_action('wp_ajax_dit_ts_reset_system', array($this, 'ajax_reset_system'));
        // @MODIFIED 2026-04-22 - Deactivate Quota Pause for a specific provider
        add_action('wp_ajax_dit_ts_deactivate_quota_pause', array($this, 'ajax_deactivate_quota_pause'));
 	// @MODIFIED 2026-02-24 - Download daily log
	add_action('wp_ajax_dit_ts_download_log', array($this, 'ajax_download_log'));
	// @ADDED 2026-05-31 - Fetch available log files for sidebar
	add_action('wp_ajax_dit_ts_get_log_files', array($this, 'ajax_get_log_files'));
	// @ADDED 2026-05-31 - Fetch paginated log entries for a specific file
	add_action('wp_ajax_dit_ts_get_log_page', array($this, 'ajax_get_log_page'));
	// @ADDED 2026-05-31 - Download a specific log file
	add_action('wp_ajax_dit_ts_download_log_file', array($this, 'ajax_download_log_file'));
	// @ADDED 2026-05-31 - Clear all archived log files (keep current day)
	add_action('wp_ajax_dit_ts_clear_archived_logs', array($this, 'ajax_clear_archived_logs'));
	// @ADDED 2026-04-24 - Download site debug.log
	add_action('wp_ajax_dit_ts_download_debug_log', array($this, 'ajax_download_debug_log'));
	// @ADDED 2026-04-24 - Paginated debug.log fetch
	add_action('wp_ajax_dit_ts_fetch_debug_log_page', array($this, 'ajax_fetch_debug_log_page'));

        // @MODIFIED 2026-02-25 - Smoke test diagnostics
        add_action('wp_ajax_dit_ts_run_smoke_test', array($this, 'ajax_run_smoke_test'));

        // Dashboard Integration
        add_action('wp_ajax_dit_ts_generate_dashboard_key', array($this, 'ajax_generate_dashboard_key'));

        // @MODIFIED 2026-03-07 - Social Queue actions
        add_action('wp_ajax_dit_ts_approve_social_post', array($this, 'ajax_approve_social_post'));
        add_action('wp_ajax_dit_ts_save_custom_providers', array($this, 'ajax_save_custom_providers'));
        add_action('wp_ajax_dit_ts_test_custom_provider', array($this, 'ajax_test_custom_provider'));
        add_action('wp_ajax_dit_ts_delete_custom_provider', array($this, 'ajax_delete_custom_provider'));
        // @ADDED 2026-07-12 - OpenRouter free-model manual sync button (provider card)
        add_action('wp_ajax_dit_ts_sync_openrouter_models', array($this, 'ajax_sync_openrouter_models'));
        // @ADDED 2026-07-17 - OpenCode Zen free-model manual sync button (provider card)
        add_action('wp_ajax_dit_ts_sync_opencode_models', array($this, 'ajax_sync_opencode_models'));

        // @MODIFIED 2026-05-15 - Buffer AJAX handlers
        add_action('wp_ajax_dit_ts_buffer_refresh_channels', array($this, 'ajax_buffer_refresh_channels'));
        add_action('wp_ajax_dit_ts_buffer_test_connection', array($this, 'ajax_buffer_test_connection'));
    }

    /**
     * AJAX: Run Smoke Test suite
     *
     * @MODIFIED 2026-02-25 - Adds robust, non-destructive diagnostics in Settings > Diagnostics.
     *
     * @return void
     */
    public function ajax_run_smoke_test()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(array('message' => 'Insufficient permissions'));
            }

            $svc = new Smoke_Test_Service($this->logger);
            $results = $svc->run();
            wp_send_json_success($results);
        } catch (\Throwable $e) {
            $this->logger->error('Smoke test AJAX failed: ' . $e->getMessage());
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    /**
     * AJAX: Generate Dashboard API Key
     *
     * @return void
     */
    public function ajax_generate_dashboard_key()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $key = wp_generate_password(32, false);
            update_option('dit_ts_dashboard_api_key', $key, false);

            wp_send_json_success([
                'key' => $key,
                'message' => 'Dashboard API key generated successfully',
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('Dashboard key generation failed: ' . $e->getMessage());
            wp_send_json_error([
                'message' => $e->getMessage(),
            ]);
        }
    }

    /**
     * AJAX: Approve Social Post from Dashboard
     * 
     * @MODIFIED 2026-03-07 - Handles manual approval of Urdu text/images and queues the 4:5 collage job.
     */
    public function ajax_approve_social_post()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                wp_send_json_error(array('message' => 'Insufficient permissions'));
            }

            $id = absint($_POST['id'] ?? 0);
            $action = sanitize_text_field($_POST['post_action'] ?? 'sync');

            if (!$id) {
                wp_send_json_error(array('message' => 'Invalid ID'));
            }

            global $wpdb;
            $table = $wpdb->prefix . 'dit_ts_social_meta';

            if ($action === 'delete') {
                $wpdb->delete($table, array('id' => $id), array('%d'));
                wp_send_json_success(array('message' => 'Item removed from queue.'));
                return;
            }

            $urdu_heading = \wp_strip_all_tags(\wp_unslash($_POST['heading'] ?? ''));
            $combined_desc = \wp_unslash($_POST['description'] ?? '');

            // @MODIFIED 2026-03-09 - Split hashtags from description if merged
            // Matches multiple hashtags at the end of the text, preceded by optional whitespace/newlines
            $urdu_description = $combined_desc;
            $hashtags = '';

            if (preg_match('/^(.*?)((?:\s*(?:#[\w\x{0600}-\x{06FF}]+)\s*)+)$/us', $combined_desc, $matches)) {
                $urdu_description = trim($matches[1]);
                $hashtags = trim($matches[2]);
            }

            $urdu_description = \wp_strip_all_tags($urdu_description);
            $hashtags = \sanitize_text_field($hashtags);

            // Mark as completed (was 'generating')
            $wpdb->update(
                $table,
                array(
                    'urdu_heading' => $urdu_heading,
                    'urdu_description' => $urdu_description,
                    'hashtags' => $hashtags,
                    'status' => 'completed'
                ),
                array('id' => $id),
                array('%s', '%s', '%s', '%s'),
                array('%d')
            );

            // @MODIFIED 2026-03-08 - Synchronize to Jetpack Social immediately on approval
            if (get_option('dit_ts_jetpack_enabled')) {
                $post_id = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $table WHERE id = %d", $id));
                if ($post_id) {
                    // Update social meta directly before sync so Jetpack gets the manual edits
                    update_post_meta($post_id, '_dit_ts_urdu_heading', $urdu_heading);
                    update_post_meta($post_id, '_dit_ts_urdu_description', $urdu_description);
                    if (!empty($hashtags)) {
                        update_post_meta($post_id, '_dit_ts_hashtags', $hashtags);
                    }

                    $social = Plugin::get_instance()->get_service('social');
                    if ($social) {
                        $social->sync_to_jetpack($post_id);
                    }
                }
            }

            wp_send_json_success(array('message' => 'Metadata synced and item closed.'));
        } catch (\Throwable $e) {
            $this->logger->error('Social Queue action failed: ' . $e->getMessage());
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    /**
     * Register admin menu
     *
     * @return void
     */
    public function register_menu()
    {
        // Main menu
        add_menu_page(
            __('Trend Studio', 'dit-trend-content-studio'),
            __('Trend Studio', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-trend-studio',
            array($this, 'render_dashboard_page'),
            'dashicons-analytics',
            30
        );

        // Submenu: Dashboard
        add_submenu_page(
            'dit-trend-studio',
            __('Dashboard', 'dit-trend-content-studio'),
            __('Dashboard', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-trend-studio',
            array($this, 'render_dashboard_page')
        );

        // Submenu: Generate Article
        add_submenu_page(
            'dit-trend-studio',
            __('Generate Article', 'dit-trend-content-studio'),
            __('Generate Article', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-trend-studio-generator',
            array($this, 'render_main_page')
        );

        // Submenu: Idea Inbox
        add_submenu_page(
            'dit-trend-studio',
            __('Idea Inbox', 'dit-trend-content-studio'),
            __('Idea Inbox', 'dit-trend-content-studio'),
            'edit_posts',
            'edit.php?post_type=dit_idea',
            null
        );

        // Submenu: Social Queue
        add_submenu_page(
            'dit-trend-studio',
            __('Social Queue', 'dit-trend-content-studio'),
            __('Social Queue', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-ts-social-queue',
            array($this, 'render_social_queue_page')
        );

        // Submenu: Jobs
        add_submenu_page(
            'dit-trend-studio',
            __('Jobs', 'dit-trend-content-studio'),
            __('Jobs', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-ts-jobs',
            array($this, 'render_jobs_page')
        );

        // Submenu: Settings
        add_submenu_page(
            'dit-trend-studio',
            __('Settings', 'dit-trend-content-studio'),
            __('Settings', 'dit-trend-content-studio'),
            'manage_options',
            'dit-ts-settings',
            array($this, 'render_settings_page')
        );

        // Submenu: API Usage
        add_submenu_page(
            'dit-trend-studio',
            __('API Usage', 'dit-trend-content-studio'),
            __('API Usage', 'dit-trend-content-studio'),
            'manage_options',
            'dit-ts-api-usage',
            array($this, 'render_api_usage_page')
        );

        // Submenu: Collage Maker
        add_submenu_page(
            'dit-trend-studio',
            __('Collage Maker', 'dit-trend-content-studio'),
            __('Collage Maker', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-ts-collage-maker',
            array($this, 'render_collage_page')
        );

        // Submenu: Error Logs
        add_submenu_page(
            'dit-trend-studio',
            __('Error Logs', 'dit-trend-content-studio'),
            __('Error Logs', 'dit-trend-content-studio'),
            'manage_options',
            'dit-ts-logs',
            array($this, 'render_logs_page')
        );
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current page hook
     * @return void
     */
    public function enqueue_assets($hook)
    {
        // Only on our pages
        if (strpos($hook, 'dit-trend-studio') === false && strpos($hook, 'dit-ts') === false) {
            return;
        }

        $plugin = Plugin::get_instance();

        // @MODIFIED 2026-05-05 - Required for wp.media (logo uploader) on settings page
        wp_enqueue_media();

        wp_enqueue_style(
            'dit-ts-admin',
            DIT_TS_PLUGIN_URL . 'assets/css/admin.css',
            array('wp-color-picker'),
            $plugin->get_asset_version('assets/css/admin.css')
        );

        // Dashboard CSS
        if ($hook === 'toplevel_page_dit-trend-studio') {
            wp_enqueue_style(
                'dit-ts-dashboard',
                DIT_TS_PLUGIN_URL . 'assets/css/dashboard.css',
                array(),
                $plugin->get_asset_version('assets/css/dashboard.css')
            );
        }

    wp_enqueue_script(
        'dit-ts-admin',
        DIT_TS_PLUGIN_URL . 'assets/js/admin.js',
        array('jquery', 'wp-color-picker', 'jquery-ui-sortable'),
        $plugin->get_asset_version('assets/js/admin.js'),
        true
    );

        wp_localize_script('dit-ts-admin', 'ditTsAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dit_ts_nonce'),
            // @MODIFIED 2026-03-01 - Load authors for campaigns
            'authors' => array_map(function ($usr) {
                return array(
                    'id' => $usr->ID,
                    'name' => $usr->display_name,
                );
            }, get_users(array('capability' => 'publish_posts'))),
            'categories' => array_map(function ($cat) {
                return array(
                    'id' => $cat->term_id,
                    'name' => $cat->name,
                    'slug' => $cat->slug,
                );
            }, get_categories(array('hide_empty' => false))),
        'strings' => array(
            'generating' => __('Generating...', 'dit-trend-content-studio'),
            'preview_ready' => __('Preview ready!', 'dit-trend-content-studio'),
            'error' => __('An error occurred', 'dit-trend-content-studio'),
            // @MODIFIED 2026-04-20 - Password toggle strings
            'showApiKey' => __('Show API key', 'dit-trend-content-studio'),
            'hideApiKey' => __('Hide API key', 'dit-trend-content-studio'),
        ),
        'customProviders' => $this->get_custom_providers_for_js(),
        // @ADDED 2026-07-12 - OpenRouter sync: last timestamp + nonce + action (button rendering & click handler)
        'openrouterLastSync' => (int) \DIT\TrendStudio\Services\OpenRouterModelSync::get_last_sync_time(),
        // @ADDED 2026-07-17 - OpenCode Zen sync: last timestamp (button rendering & click handler)
        'opencodeLastSync' => (int) \DIT\TrendStudio\Services\OpenCodeZenModelSync::get_last_sync_time(),
    ));
    }

    /**
     * Render main generation page
     *
     * @return void
     */
    /**
     * Render dashboard page
     *
     * @return void
     */
    public function render_dashboard_page()
    {
        global $wpdb;
        $jobs_table = $wpdb->prefix . 'dit_ts_jobs';

        // Stats
        // @MODIFIED 2026-08-14 - Lifetime counter now counts plugin-generated posts, not
        // dit_ts_jobs rows (job rows are pruned after 3 days by clean_old_jobs(), so COUNT
        // of 'completed' rows was a rolling window, not a lifetime figure).
        // Markers: '_dit_ts_scheduled' = '1' (auto-publish path, Scheduler::auto_publish_job)
        // or '_dit_ts_job_id' (manual publish path, Plugin::ajax manual publish). Neither is
        // written on idea/source posts, so they are excluded.
        $total_posts = $wpdb->get_var(
            "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'post'
             AND p.post_status NOT IN ('trash', 'auto-draft', 'inherit')
             AND ((pm.meta_key = '_dit_ts_scheduled' AND pm.meta_value = '1') OR pm.meta_key = '_dit_ts_job_id')"
        );

        $today_start = current_time('Y-m-d 00:00:00');
        $posts_generated_today = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $jobs_table WHERE status = 'completed' AND completed_at >= %s", $today_start));

        $all_api_stats = \DIT\TrendStudio\Infrastructure\Usage_Tracker::get_all_stats();

        // Sum for aggregate display if needed, but we'll use the full array in the view
        $total_api_calls = 0;
        $total_api_calls_today = 0;
        foreach ($all_api_stats as $stats) {
            $total_api_calls += $stats['total'];
            $total_api_calls_today += $stats['today'];
        }

        // Errors (count failed jobs today as a proxy for visual health)
        $errors_today = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $jobs_table WHERE status = 'failed' AND completed_at >= %s", $today_start));

        // Recent Jobs
        $recent_jobs = $wpdb->get_results("SELECT * FROM $jobs_table ORDER BY created_at DESC LIMIT 5", ARRAY_A);

        // Recent Errors - Get failed job messages to match $errors_today count
        $recent_errors = array();
        if ($errors_today > 0) {
            $recent_errors = $wpdb->get_results($wpdb->prepare("SELECT error_message FROM $jobs_table WHERE status = 'failed' AND completed_at >= %s ORDER BY completed_at DESC LIMIT 5", $today_start), ARRAY_A);
            $recent_errors = array_column($recent_errors, 'error_message');
        }

        // Social Shares Data (Jetpack & Buffer)
        // Dynamically build platform list from actual connected services
        $social_shares_data = [];

        // 1. Discover connected Buffer channels (all accounts)
        $buffer_channels = [];
        $buffer_accounts = \DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_enabled_accounts();
        foreach ($buffer_accounts as $acc_id => $account) {
            if (!empty($account['api_key'])) {
                try {
                    $buffer_client = new \DIT\TrendStudio\Integrations\Buffer\Client($account['api_key'], null, $acc_id);
                    $acc_channels = $buffer_client->get_channels();
                    foreach ($acc_channels as $ch_id => $ch_data) {
                        $buffer_channels[$ch_id] = $ch_data;
                    }
                } catch (\Throwable $e) {
                    // Buffer unavailable — skip this account
                }
            }
        }
        foreach ($buffer_channels as $ch_id => $ch_data) {
            $svc = strtolower($ch_data['service'] ?? '');
            if ($svc === 'x') $svc = 'twitter';
            if (!isset($social_shares_data[$svc])) {
                $social_shares_data[$svc] = ['jetpack' => 0, 'buffer' => 0];
            }
        }

        // 2. Discover connected Jetpack connections
        // @FIXED 2026-06-08 - Use get_all_connections() (XML-RPC/transient cache) as primary.
        // Connections::get_all_for_user() calls WPCOM REST API which silently returns empty
        // on many Jetpack sites. get_all_connections() reads from the transient populated
        // by XML-RPC which is reliable.
        $publicize = null;
        $jetpack_connections = [];
        if (class_exists('\Jetpack\Publicize')) {
            try {
                $publicize = new \Jetpack\Publicize();
                $raw = $publicize->get_all_connections();
                if (!empty($raw) && is_array($raw)) {
                    foreach ($raw as $svc_name => $svc_conns) {
                        if (is_array($svc_conns)) {
                            foreach ($svc_conns as $c) {
                                $jetpack_connections[] = [
                                    'connection_id' => $c['connection_data']['id'] ?? '',
                                    'id'            => $c['connection_data']['token_id'] ?? '',
                                    'service_name'  => $svc_name,
                                ];
                            }
                        }
                    }
                }
                if (empty($jetpack_connections) && class_exists('\Automattic\Jetpack\Publicize\Connections')) {
                    $jetpack_connections = \Automattic\Jetpack\Publicize\Connections::get_all_for_user();
                }
            } catch (\Throwable $e) {
                // Jetpack unavailable — skip
            }
        }
        foreach ($jetpack_connections as $conn) {
            $svc = strtolower($conn['service_name'] ?? '');
            if ($svc === 'x') $svc = 'twitter';
            if (!isset($social_shares_data[$svc])) {
                $social_shares_data[$svc] = ['jetpack' => 0, 'buffer' => 0];
            }
        }

        // 3. Count Buffer Shares from post meta history (monthly window)
        // @MODIFIED 2026-06-07 - Filter Buffer shares by current month to match monthly reset cycle.
        if (!empty($buffer_channels)) {
            $month_start = date('Y-m-01 00:00:00');
            $buffer_history_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT pm.meta_value FROM {$wpdb->postmeta} pm
                    INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                    WHERE pm.meta_key = '_nm_buffer_share_history'
                    AND p.post_date >= %s",
                    $month_start
                ),
                ARRAY_A
            );
            foreach ($buffer_history_rows as $row) {
                $history = maybe_unserialize($row['meta_value']);
                if (is_array($history)) {
                    foreach ($history as $share) {
                        $svc = strtolower($share['service'] ?? '');
                        if ($svc === 'x') $svc = 'twitter';
                        if (isset($social_shares_data[$svc])) {
                            $social_shares_data[$svc]['buffer']++;
                        }
                    }
                }
            }
        }

        // 4. Count Jetpack Shares from post meta (monthly window)
        // @FIXED 2026-06-08 - Use $jetpack_connections (normalized) instead of broken get_connections('post',...).
        // Remove _wpas_done_all check: it's a local optimistic flag set by Jetpack's save_publicized()
        // before WPCOM actually shares. Only _wpas_done_{unique_id} (set by WPCOM) confirms real shares.
        if (!empty($jetpack_connections)) {
            $month_start = date('Y-m-01 00:00:00');
            $jetpack_shared_posts = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm
                    INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                    WHERE pm.meta_key LIKE '_wpas_done_%%'
                    AND pm.meta_key != '_wpas_done_all'
                    AND p.post_date >= %s",
                    $month_start
                )
            );
            foreach ($jetpack_shared_posts as $post_id) {
                $done_keys = $wpdb->get_col($wpdb->prepare("SELECT meta_key FROM $wpdb->postmeta WHERE post_id = %d AND meta_key LIKE '_wpas_done_%%'", (int)$post_id));
                if (empty($done_keys)) continue;

                foreach ($jetpack_connections as $conn) {
                    // _wpas_done_ uses unique_id (token_id) = 'id' in normalized format
                    $unique_id = $conn['id'] ?? '';
                    $svc = strtolower($conn['service_name'] ?? '');
                    if ($svc === 'x') $svc = 'twitter';

                    if (isset($social_shares_data[$svc]) && !empty($unique_id)) {
                        foreach ($done_keys as $dk) {
                            if ($dk === "_wpas_done_{$unique_id}") {
                                $social_shares_data[$svc]['jetpack']++;
                                break;
                            }
                        }
                    }
                }
            }
        }

        // @MODIFIED 2026-06-07 - Do NOT filter out platforms with zero shares.
        // Platform list is already built from actual connected Buffer channels and Jetpack
        // connections. All platforms in the array are connected — show them even with 0 shares
        // so the user sees all connected accounts at a glance.

        // @MODIFIED 2026-01-30 - Get next scheduled import time
        $next_run = false;
        if (class_exists('ActionScheduler') && function_exists('as_get_scheduled_actions')) {
            $actions = as_get_scheduled_actions(array(
                'hook' => 'dit_ts_scheduled_import',
                'status' => 'pending',
                'per_page' => 1,
                'orderby' => 'date',
                'order' => 'ASC',
            ));
            if (!empty($actions)) {
                $action = reset($actions);
                $next_run = $action->get_schedule()->get_date()->getTimestamp();
            }
        }

        // Fallback to WP Cron if AS didn't return anything (and check if it's mistakenly using WP Cron)
        if (!$next_run) {
            $next_run = wp_next_scheduled('dit_ts_scheduled_import');
        }

        // @MODIFIED 2026-02-09 - Telemetry: Get table size and AS health
        $table_size_mb = $wpdb->get_var("SELECT ROUND(((data_length + index_length) / 1024 / 1024), 2) FROM information_schema.TABLES WHERE table_schema = '" . DB_NAME . "' AND table_name = '$jobs_table'");

        // @MODIFIED 2026-04-18 - Smart scheduler health detection for server-cron mode
        $as_health = 'Healthy';
        $as_health_details = '';
        $wp_cron_disabled = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
        $server_cron_interval = 15 * MINUTE_IN_SECONDS; // User's server cron runs every 15 mins

        if (class_exists('ActionScheduler') && function_exists('as_get_scheduled_actions')) {
            // 1. Check for actions stuck in "running" state (> 30 mins)
            $stuck_running = as_get_scheduled_actions(array(
                'status' => 'running',
                'modified' => gmdate('Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS),
                'per_page' => 1,
            ));

            // 2. Check for recent completions (last 2 hours - accounts for server cron gaps)
            $recently_completed = as_get_scheduled_actions(array(
                'status' => 'complete',
                'date' => gmdate('Y-m-d H:i:s', time() - 2 * HOUR_IN_SECONDS),
                'per_page' => 1,
                'orderby' => 'modified',
                'order' => 'DESC',
            ));

            // 3. Check for severely overdue actions (> 2 hours past schedule)
            // Threshold increased to account for: 15-min cron interval + 20-min job cooldown + processing time
            $severely_overdue = as_get_scheduled_actions(array(
                'status' => 'pending',
                'date' => gmdate('Y-m-d H:i:s', time() - 2 * HOUR_IN_SECONDS),
                'per_page' => 1,
            ));

            // 4. Check if Action Scheduler queue runner is scheduled
            $next_queue_run = wp_next_scheduled('action_scheduler_run_queue');

            $has_stuck_running = !empty($stuck_running);
            $has_recent_activity = !empty($recently_completed);
            $has_severe_overdue = !empty($severely_overdue);
            $queue_scheduled = $next_queue_run !== false;

            if ($has_stuck_running) {
                $as_health = 'Stalled';
                $as_health_details = __('Action stuck in running state', 'dit-trend-content-studio');
            } elseif ($wp_cron_disabled) {
                // Server cron mode - different logic
                if (!$queue_scheduled && $has_severe_overdue && !$has_recent_activity) {
                    $as_health = 'Stalled';
                    $as_health_details = __('Queue runner not scheduled', 'dit-trend-content-studio');
                } elseif ($has_severe_overdue && !$has_recent_activity) {
                    // Severely overdue but might be waiting for next server cron run
                    $as_health = 'Warning';
                    $as_health_details = __('Waiting for server cron', 'dit-trend-content-studio');
                } else {
                    $as_health = 'Healthy';
                    $as_health_details = __('Server Cron Mode (15-min)', 'dit-trend-content-studio');
                }
            } else {
                // Standard WP-Cron mode
                if ($has_severe_overdue && !$has_recent_activity) {
                    $as_health = 'Stalled';
                    $as_health_details = __('Queue not processing', 'dit-trend-content-studio');
                }
            }
        }

        // @MODIFIED 2026-04-22 - Gather quota pause status for dashboard alert
        $quota_pauses = [];
        // Safety check: ensure class exists before using
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
        $quota_pause_providers = ['gemini', 'custom'];
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\AI_Provider_Factory')) {
            $custom_provs = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
            foreach (array_keys($custom_provs) as $cp_slug) {
                if (!in_array($cp_slug, $quota_pause_providers, true)) {
                    $quota_pause_providers[] = $cp_slug;
                }
            }
        }
        foreach ($quota_pause_providers as $provider) {
                if (\DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider)) {
                    $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
                    $reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
                    $quota_pauses[$provider] = [
                        'reason' => $reason,
                        'until' => $until,
                        'label' => ucfirst($provider),
                        'remaining' => ($until > 0) ? human_time_diff(time(), $until) : __('Unknown', 'dit-trend-content-studio'),
                    ];
                }
            }
        }

    include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/dashboard.php';
    }

    /**
     * Render main generation page
     *
     * @return void
     */
    public function render_main_page()
    {
        // Get pending ideas for dropdown
        $ideas = $this->idea_importer->get_pending_ideas(50);

        // Get categories
        $categories = get_categories(array('hide_empty' => false));

        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/main.php';
    }

    /**
     * Render jobs page
     *
     * @return void
     */
    public function render_jobs_page()
    {
        $job_handler = \DIT\TrendStudio\Core\Plugin::get_instance()->get_job_handler();
        $jobs = $job_handler->get_user_jobs(get_current_user_id(), 50);

        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/jobs.php';
    }

    /**
     * Render settings page
     *
     * @return void
     */
    public function render_settings_page()
    {
        $providers = $this->idea_importer->get_providers();

        // @MODIFIED 2026-02-10 - Handle current tab for tabbed settings interface
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'apis';

        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/settings.php';
    }

    /**
     * Render collage page
     */
    public function render_collage_page()
    {
        if ($this->collage_admin) {
            $this->collage_admin->render_page();
        } else {
            echo '<div class="wrap"><h1>Collage Maker</h1><p>Error: Helper not initialized.</p></div>';
        }
    }

    /**
     * Render social queue page
     */
    public function render_social_queue_page()
    {
        try {
            global $wpdb;
            $table = $wpdb->prefix . 'dit_ts_social_meta';

            // @FIXED 2026-05-13: Only show 'pending' items from the last 24 hours.
            // Completed items are retained in the database for 14 days (cleanup setting)
            // but removed from the UI after approval to keep the queue manageable.
            $cutoff = gmdate('Y-m-d H:i:s', time() - (1 * DAY_IN_SECONDS));
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table} 
                WHERE status = 'pending'
                AND created_at >= %s
                ORDER BY created_at DESC 
                LIMIT 50",
                $cutoff
            ), ARRAY_A);
            $pending_posts = is_array($results) ? $results : [];
        } catch (\Throwable $e) {
            if (isset($this->logger) && $this->logger) {
                $this->logger->error('Social Queue page render failed: ' . $e->getMessage());
            }
            $pending_posts = [];
        }

        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/social-queue.php';
    }

    /**
     * Register plugin settings with sanitization callbacks
     * @MODIFIED 2026-04-20 - Social Collage Aesthetics settings with strict validation
     * @return void
     */
    public function register_settings()
    {
        register_setting('dit_ts_settings_group', 'dit_ts_enable_social_collage', [
        'type' => 'boolean',
        'default' => false,
    ]);

    register_setting('dit_ts_settings_group', 'dit_ts_social_font', [
            'type' => 'string',
            'sanitize_callback' => function($input) {
                $clean_filename = sanitize_file_name($input);
                $expected_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . $clean_filename;
                if (!file_exists($expected_path)) {
                    return 'NotoNastaliqUrdu-Regular.ttf';
                }
                return $clean_filename;
            },
            'default' => 'NotoNastaliqUrdu-Regular.ttf',
        ]);

        $color_fields = [
            'dit_ts_social_heading_bg' => '#0f1c34',
            'dit_ts_social_heading_color' => '#ffffff',
            'dit_ts_social_desc_bg' => '#500f19',
            'dit_ts_social_desc_color' => '#ffffff',
        ];
        foreach ($color_fields as $field => $default) {
            register_setting('dit_ts_settings_group', $field, [
                'type' => 'string',
                'sanitize_callback' => 'sanitize_hex_color',
                'default' => $default,
            ]);
        }

        // @MODIFIED 2026-04-21 - Register social collage font size and radius settings
        // @MODIFIED 2026-04-22 - Added area proportion settings for dynamic section sizing
        // @MODIFIED 2026-05-06 - Tuned defaults for short Urdu heading (4-7 words) + medium description (20-35 words)
        $int_fields = [
            'dit_ts_social_h_size' => 42,
            'dit_ts_social_d_size' => 28,
            'dit_ts_social_radius' => 0,
            'dit_ts_social_image_pct' => 55,
            'dit_ts_social_heading_pct' => 10,
            'dit_ts_social_desc_pct' => 25,
            'dit_ts_social_bar_pct' => 10,
        ];
        foreach ($int_fields as $field => $default) {
            register_setting('dit_ts_settings_group', $field, [
                'type' => 'integer',
                'sanitize_callback' => function($input) use ($default) {
                    $val = absint($input);
                    return $val > 0 ? $val : $default;
                },
                'default' => $default,
            ]);
        }

        // @ADDED 2026-05-25 - Visual Sourcing APIs
        register_setting('dit_ts_settings_group', 'dit_ts_image_api_provider', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'serpapi',
        ]);
        register_setting('dit_ts_settings_group', 'dit_ts_serpapi_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('dit_ts_settings_group', 'dit_ts_google_search_api_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('dit_ts_settings_group', 'dit_ts_google_search_cx', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);

        // @MODIFIED 2026-09-10 - Link Whisper integration settings.
        register_setting('dit_ts_settings_group', 'dit_ts_lw_integration_enabled', [
            'type' => 'boolean',
            'sanitize_callback' => function ($input) {
                return !empty($input) ? 1 : 0;
            },
            'default' => 0,
        ]);
        register_setting('dit_ts_settings_group', 'dit_ts_lw_max_links_per_post', [
            'type' => 'integer',
            'sanitize_callback' => function ($input) {
                $val = (int) $input;
                if ($val < 1) {
                    return 2;
                }
                if ($val > 10) {
                    return 10;
                }
                return $val;
            },
            'default' => 2,
        ]);
        register_setting('dit_ts_settings_group', 'dit_ts_lw_skip_callouts', [
            'type' => 'boolean',
            'sanitize_callback' => function ($input) {
                return !empty($input) ? 1 : 0;
            },
            'default' => 1,
        ]);
    }

    /**
     * Handle settings save
     *
     * @return void
     */
    public function handle_settings_save()
    {
        if (!isset($_POST['dit_ts_save_settings'])) {
            return;
        }

        check_admin_referer('dit_ts_settings');

        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['dit_ts_enable_social_collage'])) {
        update_option('dit_ts_enable_social_collage', !empty($_POST['dit_ts_enable_social_collage']));
    } else {
        update_option('dit_ts_enable_social_collage', false);
    }

    // Save API key
        if (isset($_POST['dit_ts_gemini_api_key'])) {
            update_option('dit_ts_gemini_api_key', sanitize_text_field($_POST['dit_ts_gemini_api_key']));
        }

        // @ADDED 2026-05-25 - Visual Sourcing APIs
        if (isset($_POST['dit_ts_image_api_provider'])) {
            update_option('dit_ts_image_api_provider', sanitize_text_field($_POST['dit_ts_image_api_provider']));
        }
        if (isset($_POST['dit_ts_serpapi_key'])) {
            update_option('dit_ts_serpapi_key', sanitize_text_field($_POST['dit_ts_serpapi_key']));
        }
        if (isset($_POST['dit_ts_google_search_api_key'])) {
            update_option('dit_ts_google_search_api_key', sanitize_text_field($_POST['dit_ts_google_search_api_key']));
        }
        if (isset($_POST['dit_ts_google_search_cx'])) {
            update_option('dit_ts_google_search_cx', sanitize_text_field($_POST['dit_ts_google_search_cx']));
        }

        // @MODIFIED 2026-02-10 - Save selected Gemini model, custom override, and API version
        if (isset($_POST['dit_ts_gemini_model'])) {
            update_option('dit_ts_gemini_model', sanitize_text_field($_POST['dit_ts_gemini_model']));
        }
        if (isset($_POST['dit_ts_gemini_model_custom'])) {
            update_option('dit_ts_gemini_model_custom', sanitize_text_field($_POST['dit_ts_gemini_model_custom']));
        }
        if (isset($_POST['dit_ts_gemini_api_version'])) {
            $api_version = sanitize_text_field($_POST['dit_ts_gemini_api_version']);
            // Validate version
            if (in_array($api_version, ['v1', 'v1beta'])) {
                update_option('dit_ts_gemini_api_version', $api_version);
            }
        }

        if (isset($_POST['dit_ts_media_visual_limit'])) {
            update_option('dit_ts_media_visual_limit', absint($_POST['dit_ts_media_visual_limit']));
        }

        if (isset($_POST['dit_ts_media_selection_mode'])) {
            $mode = sanitize_text_field($_POST['dit_ts_media_selection_mode']);
            if (in_array($mode, ['smart', 'legacy'], true)) {
                update_option('dit_ts_media_selection_mode', $mode);
            }
        }

        // @MODIFIED 2026-02-25 - Rewrite media localization settings
        if (isset($_POST['dit_ts_media_localize_external'])) {
            update_option('dit_ts_media_localize_external', !empty($_POST['dit_ts_media_localize_external']));
        } else {
            // Checkbox absent => unchecked
            update_option('dit_ts_media_localize_external', false);
        }

        if (isset($_POST['dit_ts_media_local_image_mode'])) {
            $lm = sanitize_text_field($_POST['dit_ts_media_local_image_mode']);
            if (in_array($lm, array('clone', 'transfer_exclusive', 'transfer_force', 'keep'), true)) {
                update_option('dit_ts_media_local_image_mode', $lm);
            }
        }

        // @MODIFIED 2026-02-16 - Phase 3: Media placement mode (token vs structured blocks)
        if (isset($_POST['dit_ts_media_placement_mode'])) {
            $pmode = sanitize_text_field($_POST['dit_ts_media_placement_mode']);
            if (in_array($pmode, ['token_matcher', 'structured_blocks'], true)) {
                update_option('dit_ts_media_placement_mode', $pmode);
            }
        }

        // @MODIFIED 2026-02-17 - Phase 4.1.2: Safe settings persistence (do not overwrite when field absent)
        if (isset($_POST['dit_ts_ai_enforce_structured_output'])) {
            update_option('dit_ts_ai_enforce_structured_output', !empty($_POST['dit_ts_ai_enforce_structured_output']));
        }

        if (isset($_POST['dit_ts_ai_compact_schema_in_prompt'])) {
            update_option('dit_ts_ai_compact_schema_in_prompt', !empty($_POST['dit_ts_ai_compact_schema_in_prompt']));
        }

        if (isset($_POST['dit_ts_ai_json_repair_attempts'])) {
            update_option(
                'dit_ts_ai_json_repair_attempts',
                max(0, min(3, absint($_POST['dit_ts_ai_json_repair_attempts'])))
            );
        }

        if (isset($_POST['dit_ts_gemini_enable_grounding'])) {
            update_option('dit_ts_gemini_enable_grounding', !empty($_POST['dit_ts_gemini_enable_grounding']));
        }

        if (isset($_POST['dit_ts_gemini_schema_tools_fallback'])) {
            $fb = sanitize_text_field($_POST['dit_ts_gemini_schema_tools_fallback']);
            if (in_array($fb, ['drop_schema', 'drop_tools'], true)) {
                update_option('dit_ts_gemini_schema_tools_fallback', $fb);
            }
        }

        if (isset($_POST['dit_ts_custom_providers_json'])) {
            $providers_json = wp_unslash($_POST['dit_ts_custom_providers_json']);
            $decoded = json_decode($providers_json, true);
            if (is_array($decoded)) {
                $validated = $this->validate_custom_providers($decoded);
                update_option('dit_ts_custom_providers', $validated);
                \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::clear_custom_providers_cache();
            }
        }
        if (isset($_POST['dit_ts_custom_default_provider'])) {
            update_option('dit_ts_custom_default_provider', sanitize_key($_POST['dit_ts_custom_default_provider']));
        }
        if (isset($_POST['dit_ts_custom_fallback_config_json'])) {
            $fb_json = wp_unslash($_POST['dit_ts_custom_fallback_config_json']);
            $fb_decoded = json_decode($fb_json, true);
            if (is_array($fb_decoded)) {
                // @MODIFIED 2026-06-01 - Normalize the saved fallback config so the
                // cross_provider_order from the drag-and-drop UI is preserved & sanitized
                // even if the browser sent extra/unknown keys.
                $cross_order = isset($fb_decoded['cross_provider_order']) && is_array($fb_decoded['cross_provider_order'])
                    ? array_values(array_filter(array_map('sanitize_key', $fb_decoded['cross_provider_order'])))
                    : [];

                $sanitized_fb = [
                    'enable_model_fallback'        => !empty($fb_decoded['enable_model_fallback']),
                    'enable_cross_provider_fallback' => !empty($fb_decoded['enable_cross_provider_fallback']),
                    'enable_universal_fallback'    => !empty($fb_decoded['enable_universal_fallback']),
                    'cross_provider_order'         => $cross_order,
                ];
                update_option('dit_ts_custom_fallback_config', $sanitized_fb);
            }
        }

		// Save RSS feeds
        if (isset($_POST['dit_ts_rss_feeds'])) {
            update_option('dit_ts_rss_feeds', sanitize_textarea_field($_POST['dit_ts_rss_feeds']));
        }

        // @since 1.5.0 - Save NewsAPI key
        if (isset($_POST['dit_ts_newsapi_key'])) {
            update_option('dit_ts_newsapi_key', sanitize_text_field($_POST['dit_ts_newsapi_key']));
        }

        // @since 1.5.0 - Save Social Searcher API key
        if (isset($_POST['dit_ts_social_searcher_key'])) {
            update_option('dit_ts_social_searcher_key', sanitize_text_field($_POST['dit_ts_social_searcher_key']));
        }

        // @MODIFIED 2026-06-01 - Removed OpenRouter + Groq save handlers (use Custom Providers instead)

        // @MODIFIED 2026-03-08 - Save Jetpack Integration Settings
        update_option('dit_ts_jetpack_enabled', isset($_POST['dit_ts_jetpack_enabled']));
        if (isset($_POST['dit_ts_jetpack_template'])) {
            update_option('dit_ts_jetpack_template', sanitize_textarea_field(wp_unslash($_POST['dit_ts_jetpack_template'])));
        }

        // @MODIFIED 2026-09-10 - Link Whisper integration settings.
        update_option('dit_ts_lw_integration_enabled', !empty($_POST['dit_ts_lw_integration_enabled']) ? 1 : 0);
        if (isset($_POST['dit_ts_lw_max_links_per_post'])) {
            $lw_max = (int) $_POST['dit_ts_lw_max_links_per_post'];
            if ($lw_max < 1) { $lw_max = 2; }
            if ($lw_max > 10) { $lw_max = 10; }
            update_option('dit_ts_lw_max_links_per_post', $lw_max);
        }
        update_option('dit_ts_lw_skip_callouts', !empty($_POST['dit_ts_lw_skip_callouts']) ? 1 : 0);

        // @ADDED 2026-05-19 - Save per-network Jetpack Integration Settings
        $jetpack_networks = [
            'facebook',
            'instagram',
            'threads',
            'linkedin',
            'tumblr',
            'mastodon',
            'nextdoor',
            'bluesky',
        ];

        $posted_networks = $_POST['dit_ts_jetpack_networks'] ?? [];
        $network_enabled = [];
        foreach ($jetpack_networks as $svc) {
            $network_enabled[$svc] = !empty($posted_networks[$svc]);
        }
        update_option('dit_ts_jetpack_networks', $network_enabled);

        $posted_templates = $_POST['dit_ts_jetpack_network_templates'] ?? [];
        $global_template = get_option('dit_ts_jetpack_template', '');
        $templates = [];
        foreach ($jetpack_networks as $svc) {
            $raw = sanitize_textarea_field(wp_unslash($posted_templates[$svc] ?? ''));
            // Only save if non-empty AND different from global template
            // If it matches global or is empty, store empty string so global fallback is used
            if (!empty($raw) && $raw !== $global_template) {
                $templates[$svc] = $raw;
            } else {
                $templates[$svc] = '';
            }
        }
        update_option('dit_ts_jetpack_network_templates', $templates);
        

        // @MODIFIED 2026-07-03 - Save Buffer Integration Settings (multi-account)
        if (isset($_POST['dit_ts_buffer_accounts_json'])) {
            $accounts_json = wp_unslash($_POST['dit_ts_buffer_accounts_json']);
            $decoded = json_decode($accounts_json, true);
            if (is_array($decoded)) {
                \DIT\TrendStudio\Integrations\Buffer\Account_Manager::save_accounts($decoded);
            }
        }

        // @MODIFIED 2026-04-20 - Save Social Collage Aesthetics
        if (isset($_POST['dit_ts_social_font'])) {
            $font_filename = sanitize_file_name($_POST['dit_ts_social_font']);
            $font_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . $font_filename;
            update_option('dit_ts_social_font', file_exists($font_path) ? $font_filename : 'NotoNastaliqUrdu-Regular.ttf');
        }
        $social_colors = [
            'dit_ts_social_heading_bg' => '#0f1c34',
            'dit_ts_social_heading_color' => '#ffffff',
            'dit_ts_social_desc_bg' => '#500f19',
            'dit_ts_social_desc_color' => '#ffffff',
        ];
        foreach ($social_colors as $field => $default) {
            if (isset($_POST[$field])) {
                $val = sanitize_hex_color($_POST[$field]);
                update_option($field, !empty($val) ? $val : $default);
            }
        }

        // @MODIFIED 2026-04-21 - Save Social Collage font sizes and radius
        // @MODIFIED 2026-04-22 - Save area proportion settings
        if (isset($_POST['dit_ts_social_h_size'])) {
            update_option('dit_ts_social_h_size', max(14, min(72, absint($_POST['dit_ts_social_h_size']))));
        }
        if (isset($_POST['dit_ts_social_d_size'])) {
            update_option('dit_ts_social_d_size', max(14, min(72, absint($_POST['dit_ts_social_d_size']))));
        }
        if (isset($_POST['dit_ts_social_radius'])) {
            update_option('dit_ts_social_radius', max(0, min(60, absint($_POST['dit_ts_social_radius']))));
        }
        if (isset($_POST['dit_ts_social_image_pct'])) {
            update_option('dit_ts_social_image_pct', max(10, min(80, absint($_POST['dit_ts_social_image_pct']))));
        }
        if (isset($_POST['dit_ts_social_heading_pct'])) {
            update_option('dit_ts_social_heading_pct', max(5, min(50, absint($_POST['dit_ts_social_heading_pct']))));
        }
        if (isset($_POST['dit_ts_social_desc_pct'])) {
            update_option('dit_ts_social_desc_pct', max(5, min(50, absint($_POST['dit_ts_social_desc_pct']))));
        }
        if (isset($_POST['dit_ts_social_bar_pct'])) {
            update_option('dit_ts_social_bar_pct', max(5, min(30, absint($_POST['dit_ts_social_bar_pct']))));
        }

        // @MODIFIED 2026-05-05 - Save Brand Bar Configuration
        if (isset($_POST['dit_ts_brand_bar_text'])) {
            update_option('dit_ts_brand_bar_text', sanitize_text_field(wp_unslash($_POST['dit_ts_brand_bar_text'])));
        }
        if (isset($_POST['dit_ts_brand_bar_color'])) {
            $val = sanitize_hex_color($_POST['dit_ts_brand_bar_color']);
            update_option('dit_ts_brand_bar_color', !empty($val) ? $val : '#1a1a2e');
        }
        if (isset($_POST['dit_ts_brand_bar_text_color'])) {
            $val = sanitize_hex_color($_POST['dit_ts_brand_bar_text_color']);
            update_option('dit_ts_brand_bar_text_color', !empty($val) ? $val : '#ffffff');
        }
        if (isset($_POST['dit_ts_brand_logo_id'])) {
            update_option('dit_ts_brand_logo_id', absint($_POST['dit_ts_brand_logo_id']));
        }
        if (isset($_POST['dit_ts_brand_bar_font_size'])) {
            update_option('dit_ts_brand_bar_font_size', max(12, min(48, absint($_POST['dit_ts_brand_bar_font_size']))));
        }
        if (isset($_POST['dit_ts_brand_bar_letter_spacing'])) {
            update_option('dit_ts_brand_bar_letter_spacing', max(0, min(30, absint($_POST['dit_ts_brand_bar_letter_spacing']))));
        }
        update_option('dit_ts_brand_bar_accent_line', !empty($_POST['dit_ts_brand_bar_accent_line']));

		// Save import schedule
        $schedule_changed = false;
        if (isset($_POST['dit_ts_import_schedule'])) {
            $old_schedule = get_option('dit_ts_import_schedule', 'daily');
            $new_schedule = sanitize_text_field($_POST['dit_ts_import_schedule']);
            update_option('dit_ts_import_schedule', $new_schedule);
            $schedule_changed = ($old_schedule !== $new_schedule);
        }

        // Save import time
        if (isset($_POST['dit_ts_import_time'])) {
            update_option('dit_ts_import_time', sanitize_text_field($_POST['dit_ts_import_time']));
        }

        // @MODIFIED 2026-01-30 - Force reschedule when schedule settings change
        if ($schedule_changed) {
            // Clear the transient lock to allow immediate reschedule
            delete_transient('dit_ts_schedule_last_check');

            $plugin = \DIT\TrendStudio\Core\Plugin::get_instance();
            $plugin->reschedule_imports(true);
        }

        // Save import category
        if (isset($_POST['dit_ts_import_draft_category'])) {
            update_option('dit_ts_import_draft_category', sanitize_text_field($_POST['dit_ts_import_draft_category']));
        }

        // Save worker limit
        if (isset($_POST['dit_ts_worker_limit'])) {
            update_option('dit_ts_worker_limit', max(1, min(10, (int)$_POST['dit_ts_worker_limit'])));
        }

        // Save content vertical
        if (isset($_POST['dit_ts_content_vertical'])) {
            update_option('dit_ts_content_vertical', sanitize_text_field($_POST['dit_ts_content_vertical']));
        }

        // @MODIFIED 2026-02-12 - Save AI Strategy (Fixes settings not saving)
        // @MODIFIED 2026-06-01 - OpenRouter/Groq removed as standalone providers
        if (isset($_POST['dit_ts_ai_strategy'])) {
            $strategy = sanitize_text_field($_POST['dit_ts_ai_strategy']);
            $valid_strategies = [
                'gemini',
                'custom',
            ];
            if (in_array($strategy, $valid_strategies, true)) {
                update_option('dit_ts_ai_strategy', $strategy);
            }
        }

        // @since 1.6.0 - Save editorial tone
        if (isset($_POST['dit_ts_editorial_tone'])) {
            update_option('dit_ts_editorial_tone', sanitize_textarea_field($_POST['dit_ts_editorial_tone']));
        }

        // @since 1.7.0 - Save AI images toggle
        update_option('dit_ts_enable_ai_images', isset($_POST['dit_ts_enable_ai_images']));

        // @since 1.8.0 - Save strict inline citations toggle
        update_option('dit_ts_strict_inline_citations', isset($_POST['dit_ts_strict_inline_citations']));

        // @MODIFIED 2026-02-14 - Save Social Media Blacklist
        if (isset($_POST['dit_ts_smn_blacklist'])) {
            update_option('dit_ts_smn_blacklist', sanitize_textarea_field($_POST['dit_ts_smn_blacklist']));
        }

        // @MODIFIED 2026-01-13 - Save Rank Math Bridge toggle
        update_option('dit_ts_enable_schema_bridge', isset($_POST['dit_ts_enable_schema_bridge']));

        // @MODIFIED 2025-12-14 - Save image suggestion API keys
        if (isset($_POST['dit_ts_unsplash_api_key'])) {
            update_option('dit_ts_unsplash_api_key', sanitize_text_field($_POST['dit_ts_unsplash_api_key']));
        }
        if (isset($_POST['dit_ts_pexels_api_key'])) {
            update_option('dit_ts_pexels_api_key', sanitize_text_field($_POST['dit_ts_pexels_api_key']));
        }

        // @MODIFIED 2026-02-15 - Save Automated Draft Cleanup Settings
        update_option('dit_ts_enable_draft_cleanup', isset($_POST['dit_ts_enable_draft_cleanup']));

        if (isset($_POST['dit_ts_draft_cleanup_age_days'])) {
            update_option('dit_ts_draft_cleanup_age_days', max(1, min(30, (int)$_POST['dit_ts_draft_cleanup_age_days'])));
        }

        update_option('dit_ts_draft_cleanup_delete_media', isset($_POST['dit_ts_draft_cleanup_delete_media']));

        // @MODIFIED 2026-02-14 - Save Collage Settings
        if (isset($_POST['dit_ts_collage_bottom_text'])) {
            update_option('dit_ts_collage_bottom_text', sanitize_text_field($_POST['dit_ts_collage_bottom_text']));
        }
        update_option('dit_ts_collage_retina', isset($_POST['dit_ts_collage_retina']));

        // @MODIFIED 2026-02-08 - Save Campaigns & Manage Schedules
        if (isset($_POST['dit_ts_campaigns'])) {
            // Validate JSON
            $campaigns_json = wp_unslash($_POST['dit_ts_campaigns']);
            $decoded = json_decode($campaigns_json, true);

            if (is_array($decoded)) {
                // @MODIFIED 2026-02-08 - Fix campaign ID persistence bug
                // Ensure IDs and track changes for Action Scheduler cleanup
                $id_mappings = []; // old_id => new_id
                foreach ($decoded as &$c) {
                    $old_id = isset($c['id']) ? $c['id'] : '';
                    // Replace empty IDs or temporary 'new_' prefixed IDs with proper unique IDs
                    if (empty($c['id']) || strpos($c['id'], 'new_') === 0) {
                        $c['id'] = uniqid('cmp_');
                        if (!empty($old_id)) {
                            $id_mappings[$old_id] = $c['id'];
                        }
                    }
                }
                unset($c); // break ref

                // Cleanup orphaned Action Scheduler jobs with old temporary IDs
                if (function_exists('as_unschedule_action') && !empty($id_mappings)) {
                    foreach ($id_mappings as $old_id => $new_id) {
                        as_unschedule_action('dit_ts_run_campaign', ['campaign_id' => $old_id], 'dit_ts_campaigns');
                        $this->logger->info("Campaign ID updated: $old_id → $new_id (cleaned up old scheduled actions)");
                    }
                }

                update_option('dit_ts_campaigns', json_encode($decoded));

                // Updated Schedules via Action Scheduler
                if (function_exists('as_schedule_recurring_action')) {
                    $plugin = \DIT\TrendStudio\Core\Plugin::get_instance();

                    // 1. Get existing actions
                    $existing_actions = []; // We can't easily query by partial args, so we'll just upsert

                    // @MODIFIED 2026-02-11 - Respect Master Switch during Save
                    $is_automation_enabled = (int) get_option('dit_ts_enable_ai_automation', '1');

                    foreach ($decoded as $campaign) {
                        $hook = 'dit_ts_run_campaign';
                        $args = array('campaign_id' => $campaign['id']);
                        $group = 'dit_ts_campaigns';

                        // Check if active or if automation is disabled
                        if (empty($campaign['active']) || empty($campaign['schedule']) || $campaign['schedule'] === 'manual' || !$is_automation_enabled) {
                            as_unschedule_action($hook, $args, $group);
                            continue;
                        }

                        // Determine interval
                        $interval = 0;
                        switch ($campaign['schedule']) {
                            case 'every_15_mins':
                                $interval = 900;
                                break;
                            case 'every_30_mins':
                                $interval = 1800;
                                break;
                            case 'hourly':
                                $interval = 3600;
                                break;
                            case '2hours':
                                $interval = 7200;
                                break;
                            case '3hours':
                                $interval = 10800;
                                break;
                            case '4hours':
                                $interval = 14400;
                                break;
                            case '5hours':
                                $interval = 18000;
                                break;
                            case '6hours':
                                $interval = 21600;
                                break;
                            case '7hours':
                                $interval = 25200;
                                break;
                            case '8hours':
                                $interval = 28800;
                                break;
                            case '9hours':
                                $interval = 32400;
                                break;
                            case '10hours':
                                $interval = 36000;
                                break;
                            case '11hours':
                                $interval = 39600;
                                break;
                            case '12hours':
                                $interval = 43200;
                                break;
                            case 'daily':
                                $interval = 86400;
                                break;
                            case 'twice_daily':
                                $interval = 43200;
                                break;
                            case '48hours':
                                $interval = 172800;
                                break;
                            default:
                                $interval = 3600;
                                break;
                        }

                        // Check if already scheduled with CORRECT interval
                        // AS doesn't let us easily check interval of next occurrence without fetch
                        // Easier strategy: Unschedule specific args, then Schedule fresh
                        // (Only if schedule changed? Hard to track state. Upsert approach: )

                        // Smart Upsert:
                        // Find next action for this campaign
                        $next = as_next_scheduled_action($hook, $args, $group);

                        if ($next) {
                            // If exists, checks if we need to reschedule?
                            // For simplicity and robustness: Unschedule and Reschedule ensuring correct interval
                            // Optimization: In a real high-traffic plugin we'd check schedules.
                            as_unschedule_action($hook, $args, $group);
                        }

                        // Schedule new
                        as_schedule_recurring_action(time() + 60, $interval, $hook, $args, $group);
                    }
                }
            }
        }

        // Save logging
        update_option('dit_ts_enable_logging', isset($_POST['dit_ts_enable_logging']));

        // @MODIFIED 2026-02-22 - Save Automated Draft Cleanup settings
        update_option('dit_ts_enable_draft_cleanup', isset($_POST['dit_ts_enable_draft_cleanup']));
        update_option('dit_ts_draft_cleanup_delete_media', isset($_POST['dit_ts_draft_cleanup_delete_media']));

        if (isset($_POST['dit_ts_draft_cleanup_age_days'])) {
            update_option('dit_ts_draft_cleanup_age_days', max(1, min(30, (int)$_POST['dit_ts_draft_cleanup_age_days'])));
        }

        // @MODIFIED 2026-02-10 - Save Publishing Schedule settings
        update_option('dit_ts_enable_scheduling', isset($_POST['dit_ts_enable_scheduling']));

        if (isset($_POST['dit_ts_posts_per_day'])) {
            update_option('dit_ts_posts_per_day', max(1, min(50, (int)$_POST['dit_ts_posts_per_day'])));
        }

        if (isset($_POST['dit_ts_publish_start'])) {
            update_option('dit_ts_publish_start', sanitize_text_field($_POST['dit_ts_publish_start']));
        }

        if (isset($_POST['dit_ts_publish_end'])) {
            update_option('dit_ts_publish_end', sanitize_text_field($_POST['dit_ts_publish_end']));
        }

        if (isset($_POST['dit_ts_min_interval']) && isset($_POST['dit_ts_max_interval'])) {
            $min_interval = max(1, min(1440, (int) $_POST['dit_ts_min_interval']));
            $max_interval = max(1, min(1440, (int) $_POST['dit_ts_max_interval']));
            if ($min_interval > $max_interval) {
                list($min_interval, $max_interval) = array($max_interval, $min_interval);
            }
            update_option('dit_ts_min_interval', $min_interval);
            update_option('dit_ts_max_interval', $max_interval);
        }

        if (isset($_POST['dit_ts_active_days']) && is_array($_POST['dit_ts_active_days'])) {
            $allowed_days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
            $filtered_days = array_intersect($allowed_days, array_map('sanitize_text_field', $_POST['dit_ts_active_days']));
            update_option('dit_ts_active_days', $filtered_days);
        } else {
            // If none checked, default to all days or empty? Usually better to default to empty if explicitly cleared.
            update_option('dit_ts_active_days', []);
        }

        add_settings_error('dit_ts_settings', 'saved', __('Settings saved.', 'dit-trend-content-studio'), 'updated');

        // @MODIFIED 2026-02-14 - Redirect to preserve tab
        // Get current tab from the hidden input if present, otherwise fallback to referrer logic
        $target_tab = 'apis';
        if (isset($_POST['tab'])) {
            $target_tab = sanitize_text_field($_POST['tab']);
        } elseif (isset($_GET['tab'])) {
            $target_tab = sanitize_text_field($_GET['tab']);
        } elseif (isset($_POST['_wp_http_referer'])) {
            $query = parse_url($_POST['_wp_http_referer'], PHP_URL_QUERY);
            if ($query) {
                parse_str($query, $params);
                if (isset($params['tab'])) {
                    $target_tab = sanitize_text_field($params['tab']);
                }
            }
        }

        $redirect_url = add_query_arg([
            'page' => 'dit-ts-settings',
            'tab'  => $target_tab,
            'settings-updated' => 'true'
        ], admin_url('admin.php'));

        // Ensure successful redirect
        if (!empty($redirect_url)) {
            wp_safe_redirect($redirect_url);
            exit;
        }
    }

    /**
     * Handle batch status checks for Jobs page polling
     * @since 1.8.0
     */
    public function ajax_batch_status()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Insufficient permissions');
        }

        $job_ids = isset($_POST['job_ids']) ? array_map('intval', $_POST['job_ids']) : [];

        if (empty($job_ids)) {
            wp_send_json_error('No job IDs provided');
        }

        $job_handler = \DIT\TrendStudio\Core\Plugin::get_instance()->get_job_handler();
        $updates = [];

        foreach ($job_ids as $id) {
            $status_data = $job_handler->get_job_status($id);
            if (is_array($status_data)) {
                // @MODIFIED 2026-02-24 - Return extended status payload (message, timestamps, post_id, error).
                $updates[$id] = $status_data;
            }
        }

        wp_send_json_success($updates);
    }

    /**
     * Manually trigger a specific job (Bypassing Action Scheduler)
     * Useful for debugging or Stuck Jobs in local environments.
     */
    public function ajax_force_run_job()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Insufficient permissions');
        }

        $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;

        if (!$job_id) {
            wp_send_json_error('Invalid Job ID');
        }

        $job_handler = \DIT\TrendStudio\Core\Plugin::get_instance()->get_job_handler();

        // Disable time limit for this request as generation takes time
        if (function_exists('set_time_limit')) {
            set_time_limit(300); // 5 minutes
        }

        try {
            $job_handler->process_job($job_id);
            wp_send_json_success('Job processed successfully');
        } catch (\Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Handle Gap Analysis (Unified)
     * @since 1.9.0
     */
    public function ajax_analyze_gap()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Insufficient permissions');
        }

        // @MODIFIED 2026-01-24 - Allow raw HTML for asset preservation (images/iframes)
        $source_url = isset($_POST['source_url']) ? wp_unslash($_POST['source_url']) : '';
        $mode       = isset($_POST['mode']) ? sanitize_text_field($_POST['mode']) : 'competitor';

        if (empty($source_url)) {
            wp_send_json_error('Source URL/Content is required');
        }

try {
        // @FIXED 2026-04-24 - Respect AI strategy setting (was hardcoded to Gemini)
        $logger = new Logger();
        $strategy = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_effective_strategy();
        $ai_client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create($strategy, $logger);

        $analyzer = new \DIT\TrendStudio\Core\Gap_Analyzer($ai_client, $logger);

            // Analyze
            $is_url = filter_var($source_url, FILTER_VALIDATE_URL) !== false;
            $result = $analyzer->analyze($source_url, $is_url ? 'url' : 'text', $mode);

            // Return the structure expected by the frontend
            wp_send_json_success($result);
        } catch (\Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Display API call statistics.
     */
    public function render_api_usage_page()
    {
        // Only show to admins
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'dit-trend-content-studio'));
        }

        $all_stats = \DIT\TrendStudio\Infrastructure\Usage_Tracker::get_all_stats();
?>
        <div class="wrap">
            <h1><?php esc_html_e('API Usage', 'dit-trend-content-studio'); ?></h1>
            <p><?php esc_html_e('Monitor your AI API consumption across all active providers.', 'dit-trend-content-studio'); ?></p>

            <div class="dit-ts-usage-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; margin-top: 20px;">
                <?php foreach ($all_stats as $slug => $stats) : ?>
                    <?php
                    // @MODIFIED 2026-02-26 - Surface provider pause + Gemini reset timing.
                    $paused = false;
                    $pause_until = 0;
                    $pause_reason = '';
                    $reset_at = 0;

                    if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                        $paused = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($slug);
                        $pause_until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($slug);
                        $pause_reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($slug);
                        $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reset_at($slug);
                    }

                    // @MODIFIED 2026-02-27 - Show Gemini reset/retry in PT + local to avoid confusion.
                    $pause_until_str_wp = '';
                    $pause_until_str_pt = '';
                    $reset_at_str_wp = '';
                    $reset_at_str_pt = '';

                    if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
                        if ($pause_until > 0) {
                            $pause_until_str_wp = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz((int) $pause_until);
                            if ($slug === 'gemini') {
                                $pause_until_str_pt = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_tz((int) $pause_until, 'America/Los_Angeles');
                            }
                        }
                        if ($reset_at > 0) {
                            $reset_at_str_wp = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz((int) $reset_at);
                            if ($slug === 'gemini') {
                                $reset_at_str_pt = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_tz((int) $reset_at, 'America/Los_Angeles');
                            }
                        }
                    }
                    ?>
                    <div class="card" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                        <h2 style="margin-top: 0; color: #1d2327;"><?php echo esc_html($stats['label']); ?></h2>

                        <div class="usage-stat" style="margin-bottom: 14px;">
                            <span style="font-weight: 700;">
                                <?php echo $paused ? esc_html__('PAUSED', 'dit-trend-content-studio') : esc_html__('ACTIVE', 'dit-trend-content-studio'); ?>
                            </span>
                            <?php if ($paused) : ?>
                                <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                    <?php echo esc_html__('Reason:', 'dit-trend-content-studio'); ?>
                                    <code><?php echo esc_html($pause_reason !== '' ? $pause_reason : 'quota'); ?></code>
                                </div>
                                <?php if ($slug === 'gemini' && $pause_until_str_wp !== '' && $pause_until_str_pt !== '') : ?>
                                    <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                        <?php echo esc_html__('Next retry after (local):', 'dit-trend-content-studio'); ?>
                                        <code><?php echo esc_html($pause_until_str_wp); ?></code>
                                    </div>
                                    <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                        <?php echo esc_html__('Next retry after (PT):', 'dit-trend-content-studio'); ?>
                                        <code><?php echo esc_html($pause_until_str_pt); ?></code>
                                    </div>
                                <?php elseif ($pause_until_str_wp !== '') : ?>
                                    <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                        <?php echo esc_html__('Next retry after:', 'dit-trend-content-studio'); ?>
                                        <code><?php echo esc_html($pause_until_str_wp); ?></code>
                                    </div>
                                <?php endif; ?>
                                <?php if ($slug === 'gemini' && $reset_at_str_pt !== '') : ?>
                                    <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                        <?php echo esc_html__('Gemini RPD reset (00:00 PT):', 'dit-trend-content-studio'); ?>
                                        <code><?php echo esc_html($reset_at_str_pt); ?></code>
                                    </div>
                                    <?php if ($reset_at_str_wp !== '') : ?>
                                        <div style="font-size: 0.85em; color: #646970; margin-top: 4px;">
                                            <?php echo esc_html__('Local time:', 'dit-trend-content-studio'); ?>
                                            <code><?php echo esc_html($reset_at_str_wp); ?></code>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="usage-stat" style="margin-bottom: 10px;">
                            <span style="font-weight: 600; font-size: 1.2em; color: #2271b1;"><?php echo number_format($stats['today']); ?></span>
                            <div style="font-size: 0.85em; color: #646970;"><?php esc_html_e('Calls Made Today', 'dit-trend-content-studio'); ?></div>
                        </div>
                        <div class="usage-stat">
                            <span style="font-weight: 600;"><?php echo number_format($stats['total']); ?></span>
                            <div style="font-size: 0.85em; color: #646970;"><?php esc_html_e('Total Lifetime Calls', 'dit-trend-content-studio'); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if (empty($all_stats)) : ?>
                <div class="notice notice-info inline">
                    <p><?php esc_html_e('No AI providers registered for usage tracking.', 'dit-trend-content-studio'); ?></p>
                </div>
            <?php endif; ?>
        </div>
<?php
    }

    /**
     * Render Error Logs page
     */
    public function render_logs_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'dit-trend-content-studio'));
        }
        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/logs.php';
    }

    /**
     * AJAX: Clear all logs
     * @MODIFIED 2026-05-31 - Fixed: deletes log files instead of truncating non-existent DB table
     */
    public function ajax_clear_logs()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $deleted = $this->logger->clear_all_log_files();

        wp_send_json_success(array(
            'message' => sprintf(__('Deleted %d log file(s)', 'dit-trend-content-studio'), $deleted),
            'deleted' => $deleted,
        ));
    }

    /**
     * AJAX: Get available log files for sidebar
     * @ADDED 2026-05-31
     */
    public function ajax_get_log_files()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $files = $this->logger->get_available_log_files();

        foreach ($files as &$f) {
            $f['size_formatted'] = size_format($f['size']);
        }
        unset($f);

        wp_send_json_success($files);
    }

    /**
     * AJAX: Fetch paginated, filtered log entries from a specific file
     * @ADDED 2026-05-31
     * @MODIFIED 2026-05-31 - Use read_all_nonempty_lines for accurate counts + fix filtered pagination
     */
    public function ajax_get_log_page()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $file     = isset($_GET['file']) ? sanitize_file_name(wp_unslash($_GET['file'])) : '';
        $page     = isset($_GET['page_num']) ? absint($_GET['page_num']) : 1;
        $per_page = isset($_GET['per_page']) ? absint($_GET['per_page']) : 200;
        $level    = isset($_GET['level']) ? sanitize_text_field(wp_unslash($_GET['level'])) : '';
        $search   = isset($_GET['search']) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';

        $per_page = max(1, min(500, $per_page));
        $page     = max(1, $page);

        if (empty($file)) {
            wp_send_json_error('No log file specified');
        }

        $upload_dir = wp_upload_dir();
        $log_dir    = $upload_dir['basedir'] . '/dit-ts-logs';
        $real_path  = realpath($log_dir . '/' . $file);

        $real_log_dir = realpath($log_dir);
        if (!$real_path || !$real_log_dir || strpos($real_path, $real_log_dir) !== 0 || !is_file($real_path) || !is_readable($real_path)) {
            wp_send_json_error('Log file not found or not readable');
        }

        $level_filter = ($level && $level !== 'ALL') ? $level : null;
        $filtered     = ($level_filter !== null);

        $all_lines = Logger::read_all_nonempty_lines($real_path);

        if ($level_filter !== null) {
            $all_lines = array_filter($all_lines, function ($item) use ($level_filter) {
                return strpos($item['raw'], "[{$level_filter}]") !== false;
            });
            $all_lines = array_values($all_lines);
        }

        if ($search !== '') {
            $search_lower = strtolower($search);
            $all_lines = array_filter($all_lines, function ($item) use ($search_lower) {
                return stripos($item['raw'], $search_lower) !== false;
            });
            $all_lines = array_values($all_lines);
            $filtered = true;
        }

        $total_entries = count($all_lines);
        $total_pages   = $total_entries > 0 ? (int) ceil($total_entries / $per_page) : 1;
        $page          = max(1, min($page, $total_pages));

        // Reverse so newest entries appear first (file is chronological, page 1 = latest)
        $all_lines = array_reverse($all_lines);
        $slice     = array_slice($all_lines, ($page - 1) * $per_page, $per_page);

        $entries = array();
        foreach ($slice as $item) {
            $entries[] = $this->parse_log_line($item['raw'], $item['line_num']);
        }

        wp_send_json_success(array(
            'entries'     => $entries,
            'total_lines' => $total_entries,
            'total_pages' => $total_pages,
            'page'        => $page,
            'filtered'    => $filtered,
        ));
    }

    /**
     * Parse a raw log line into structured data
     *
     * @param string $raw      Raw log line.
     * @param int    $line_num Line number.
     * @return array
     */
    private function parse_log_line($raw, $line_num = 0)
    {
        if (preg_match('/^\[(.*?)\] \[(.*?)\] (.+?)(?: (\{.*\}))?$/', $raw, $m)) {
            return array(
                'line_num' => $line_num,
                'time'     => $m[1],
                'level'    => $m[2],
                'message'  => $m[3],
                'context'  => isset($m[4]) ? json_decode($m[4], true) : null,
                'raw'      => $raw,
            );
        }

        return array(
            'line_num' => $line_num,
            'time'     => '-',
            'level'    => 'UNKNOWN',
            'message'  => $raw,
            'context'  => null,
            'raw'      => $raw,
        );
    }

    /**
     * AJAX: Download a specific log file
     * @ADDED 2026-05-31
     */
    public function ajax_download_log_file()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $file      = isset($_GET['file']) ? sanitize_file_name(wp_unslash($_GET['file'])) : '';
        $upload_dir = wp_upload_dir();
        $log_dir   = $upload_dir['basedir'] . '/dit-ts-logs';
        $real_path = realpath($log_dir . '/' . $file);

        if (!$real_path || strpos($real_path, realpath($log_dir)) !== 0 || !is_file($real_path) || !is_readable($real_path)) {
            wp_die('Log file not found.');
        }

        if (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($real_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($real_path));

        readfile($real_path);
        exit;
    }

    /**
     * AJAX: Clear all archived log files (keep today's log)
     * @ADDED 2026-05-31
     */
    public function ajax_clear_archived_logs()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $upload_dir = wp_upload_dir();
        $log_dir    = $upload_dir['basedir'] . '/dit-ts-logs';

        if (!file_exists($log_dir)) {
            wp_send_json_success(array('message' => 'No logs directory found', 'deleted' => 0));
        }

        $today     = date('Y-m-d');
        $today_file = $log_dir . '/dit-ts-' . $today . '.log';
        $deleted   = 0;

        $files = glob($log_dir . '/dit-ts-*.log');
        foreach ($files as $file) {
            if (realpath($file) !== realpath($today_file)) {
                if (unlink($file)) {
                    $deleted++;
                }
            }
        }

        wp_send_json_success(array(
            'message' => sprintf(__('Deleted %d archived log file(s)', 'dit-trend-content-studio'), $deleted),
            'deleted' => $deleted,
        ));
    }

	/**
      * AJAX: Process Action Scheduler queue manually
      * @MODIFIED 2026-01-30 - Added manual queue processing for debugging stuck cron
      * @MODIFIED 2026-04-18 - Enhanced: Unstuck running actions, clear locks, run queue
      */
    public function ajax_process_queue()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception(__('Insufficient permissions', 'dit-trend-content-studio'));
            }

            $results = [];
            $results['wp_cron_disabled'] = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;

            // 1. Unstick actions stuck in "running" state (> 30 mins)
            $results['unstuck_count'] = 0;
            if (class_exists('ActionScheduler') && function_exists('as_get_scheduled_actions')) {
                $stuck_running = as_get_scheduled_actions([
                    'status' => 'running',
                    'modified' => gmdate('Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS),
                    'per_page' => 10,
                ]);

                foreach ($stuck_running as $action_id => $action) {
                    try {
                        \ActionScheduler::store()->mark_failure($action_id, 'Unstuck by manual repair');
                        $results['unstuck_count']++;
                    } catch (\Exception $e) {
                        // Continue if single action fails
                    }
                }
            }

            // 2. Clear plugin-level locks to unblock queue
            delete_transient('dit_ts_job_lock');
            delete_transient('dit_ts_pending_drain_active');
            delete_option('dit_ts_job_start_mutex');
            $results['locks_cleared'] = true;

            // 3. Process Action Scheduler queue
            if (class_exists('ActionScheduler_QueueRunner')) {
                $runner = \ActionScheduler_QueueRunner::instance();
                $processed = $runner->run();
                $results['queue_processed'] = $processed > 0;
                $results['actions_run'] = $processed;
            } else {
                $results['queue_processed'] = false;
            }

            // 4. Check pending actions after processing
            if (function_exists('as_get_scheduled_actions')) {
                $pending = as_get_scheduled_actions([
                    'hook' => 'dit_ts_scheduled_import',
                    'status' => 'pending',
                    'per_page' => 1
                ]);

                if (!empty($pending)) {
                    $action = reset($pending);
                    $results['next_run'] = $action->get_schedule()->get_date()->format('Y-m-d H:i:s');
                } else {
                    $results['next_run'] = null;
                }
            }

            $message = __('Queue repair completed', 'dit-trend-content-studio');
            if ($results['unstuck_count'] > 0) {
                $message .= sprintf(' (%d stuck actions cleared)', $results['unstuck_count']);
            }

            wp_send_json_success([
                'message' => $message,
                'data' => $results
            ]);
        } catch (\Exception $e) {
            wp_send_json_error([
                'message' => $e->getMessage()
            ]);
        }
    }

    private function get_custom_providers_for_js(): array
    {
        $providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
        $result = [];
        foreach ($providers as $id => $profile) {
            $result[] = [
                'id' => $id,
                'name' => $profile['name'] ?? $id,
                'api_url' => $profile['api_url'] ?? '',
                'api_key' => !empty($profile['api_key']),
                'enable_web_search' => !empty($profile['enable_web_search']),
                'web_search_config' => $profile['web_search_config'] ?? ['type' => 'none'],
                'models' => $profile['models'] ?? [],
                'fallback_enabled' => !empty($profile['fallback_enabled']),
            ];
        }
        return $result;
    }

    private function validate_custom_providers(array $decoded): array
    {
        $builtin_slugs = ['gemini', 'custom'];
        $validated = [];
        $existing_providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();

        foreach ($decoded as $profile) {
            $id = isset($profile['id']) ? sanitize_key($profile['id']) : '';
            if ($id === '' || in_array($id, $builtin_slugs, true)) {
                continue;
            }
            $name = sanitize_text_field($profile['name'] ?? $id);
            $api_url = esc_url_raw($profile['api_url'] ?? '');
            $api_key = sanitize_text_field($profile['api_key'] ?? '');
            if ($api_key === '' && isset($existing_providers[$id]['api_key'])) {
                $api_key = $existing_providers[$id]['api_key'];
            }
            $enable_web_search = !empty($profile['enable_web_search']);
            $web_search_type = sanitize_text_field($profile['web_search_config']['type'] ?? 'none');
            if (!in_array($web_search_type, ['none', 'zhipuai', 'kimi', 'minimax'], true)) {
                $web_search_type = 'none';
            }
            $search_engine = sanitize_text_field($profile['web_search_config']['search_engine'] ?? 'search_pro');
            if (!in_array($search_engine, ['search_pro', 'search_pro_lite'], true)) {
                $search_engine = 'search_pro';
            }
            $search_count = max(1, min(20, absint($profile['web_search_config']['search_count'] ?? 10)));
            $models = [];
            if (isset($profile['models']) && is_array($profile['models'])) {
                foreach ($profile['models'] as $m) {
                    $mid = sanitize_text_field($m['model_id'] ?? '');
                    $mname = sanitize_text_field($m['display_name'] ?? $mid);
                    if ($mid !== '') {
                        $models[] = ['display_name' => $mname, 'model_id' => $mid];
                    }
                }
            }
            $fallback_enabled = !empty($profile['fallback_enabled']);

            $validated[] = [
                'id' => $id,
                'name' => $name,
                'api_url' => $api_url,
                'api_key' => $api_key,
                'enable_web_search' => $enable_web_search,
                'web_search_config' => [
                    'type' => $web_search_type,
                    'search_engine' => $search_engine,
                    'search_count' => $search_count,
                ],
                'models' => $models,
                'fallback_enabled' => $fallback_enabled,
            ];
        }

        return $validated;
    }

    public function ajax_save_custom_providers()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        $providers_json = isset($_POST['providers']) ? wp_unslash($_POST['providers']) : '';
        $decoded = json_decode($providers_json, true);

        if (!is_array($decoded)) {
            wp_send_json_error(array('message' => 'Invalid provider data format'));
        }

        $validated = $this->validate_custom_providers($decoded);

        update_option('dit_ts_custom_providers', $validated);
        \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::clear_custom_providers_cache();

        $default_provider = sanitize_key($_POST['default_provider'] ?? '');
        update_option('dit_ts_custom_default_provider', $default_provider);

        $fallback_json = isset($_POST['fallback_config']) ? wp_unslash($_POST['fallback_config']) : '';
        $fallback_decoded = json_decode($fallback_json, true);
        if (is_array($fallback_decoded)) {
            update_option('dit_ts_custom_fallback_config', [
                'enable_model_fallback' => !empty($fallback_decoded['enable_model_fallback']),
                'enable_cross_provider_fallback' => !empty($fallback_decoded['enable_cross_provider_fallback']),
                'enable_universal_fallback' => !empty($fallback_decoded['enable_universal_fallback']),
                'cross_provider_order' => array_map('sanitize_key', $fallback_decoded['cross_provider_order'] ?? []),
            ]);
        }

        wp_send_json_success(array(
            'message' => __('Custom providers saved successfully', 'dit-trend-content-studio'),
            'count' => count($validated),
        ));
    }

    public function ajax_test_custom_provider()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $api_url = esc_url_raw($_POST['api_url'] ?? '');
        $profile = [];

        if ($provider_id !== '') {
            $providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
            if (isset($providers[$provider_id])) {
                $profile = $providers[$provider_id];
                if ($api_key === '') {
                    $api_key = $providers[$provider_id]['api_key'] ?? '';
                }
                if ($api_url === '') {
                    $api_url = $providers[$provider_id]['api_url'] ?? '';
                }
            }
        }

        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'API Key is required'));
        }
        if (empty($api_url)) {
            wp_send_json_error(array('message' => 'API URL is required'));
        }

        try {
            $slug = $provider_id !== '' ? $provider_id : 'custom';
            $client = new \DIT\TrendStudio\Content\Custom_Client($api_key, $this->logger, $api_url, $slug, $profile);
            $result = $client->test_connection();
            wp_send_json_success('Connected to Custom Provider: ' . ($result['model'] ?? 'Ready'));
        } catch (\Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    public function ajax_delete_custom_provider()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        if ($provider_id === '') {
            wp_send_json_error(array('message' => 'Provider ID is required'));
        }

        $providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
        if (!isset($providers[$provider_id])) {
            wp_send_json_error(array('message' => 'Provider not found'));
        }

        unset($providers[$provider_id]);
        $indexed = array_values($providers);
        update_option('dit_ts_custom_providers', $indexed);
        \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::clear_custom_providers_cache();

        $default_id = get_option('dit_ts_custom_default_provider', '');
        if ($default_id === $provider_id) {
            update_option('dit_ts_custom_default_provider', '');
        }

        $fallback_config = get_option('dit_ts_custom_fallback_config', []);
        if (is_array($fallback_config) && isset($fallback_config['cross_provider_order'])) {
            $fallback_config['cross_provider_order'] = array_values(array_filter(
                $fallback_config['cross_provider_order'],
                function ($id) use ($provider_id) { return $id !== $provider_id; }
            ));
            update_option('dit_ts_custom_fallback_config', $fallback_config);
        }

        wp_send_json_success(array(
            'message' => sprintf(__('Provider "%s" deleted', 'dit-trend-content-studio'), $provider_id),
        ));
    }

    /**
     * AJAX: Manual OpenRouter free-model sync (button on each OpenRouter provider card).
     *
     * Unlike the scheduled cron task, this handler bypasses the AI automation
     * master-switch gate — the user explicitly clicked the button.
     *
     * @ADDED 2026-07-12 — OpenRouter free-model sync (universal plan §4c).
     * @return void
     */
    public function ajax_sync_openrouter_models()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        try {
            $result = \DIT\TrendStudio\Services\OpenRouterModelSync::sync();
            if (!empty($result['success'])) {
                wp_send_json_success($result);
                return;
            }
            wp_send_json_error(array(
                'message' => $result['message'] ?? 'Unknown sync error',
                'data'    => $result,
            ));
        } catch (\Throwable $t) {
            wp_send_json_error(array(
                'message' => 'OpenRouter sync failed: ' . $t->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Manual OpenCode Zen free-model sync.
     *
     * Bypasses the AI automation master-switch gate — the user explicitly
     * clicked the button.
     *
     * @ADDED 2026-07-17 — OpenCode Zen free-model sync (parallel to OpenRouter).
     * @return void
     */
    public function ajax_sync_opencode_models()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        try {
            $result = \DIT\TrendStudio\Services\OpenCodeZenModelSync::sync();
            if (!empty($result['success'])) {
                wp_send_json_success($result);
                return;
            }
            wp_send_json_error(array(
                'message' => $result['message'] ?? 'Unknown sync error',
                'data'    => $result,
            ));
        } catch (\Throwable $t) {
            wp_send_json_error(array(
                'message' => 'OpenCode Zen sync failed: ' . $t->getMessage(),
            ));
        }
    }

    public function ajax_custom_test_connection()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $api_url = isset($_POST['api_url']) ? esc_url_raw($_POST['api_url']) : '';
        $provider_id = sanitize_key($_POST['provider_id'] ?? '');
        $profile = [];

        if (empty($api_key) && $provider_id !== '') {
            $providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
            if (isset($providers[$provider_id])) {
                $profile = $providers[$provider_id];
                $api_key = $providers[$provider_id]['api_key'] ?? '';
                if (empty($api_url)) {
                    $api_url = $providers[$provider_id]['api_url'] ?? '';
                }
            }
        }

        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'API Key is required'));
        }
        if (empty($api_url)) {
            wp_send_json_error(array('message' => 'API URL is required'));
        }

        try {
            $slug = $provider_id !== '' ? $provider_id : 'custom';
            $client = new \DIT\TrendStudio\Content\Custom_Client($api_key, $this->logger, $api_url, $slug, $profile);
            $result = $client->test_connection();
            wp_send_json_success('Connected to Custom Provider: ' . ($result['model'] ?? 'Ready'));
        } catch (\Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    /**
     * AJAX: Reset System Status (Clear Transients & Locks)
     * 
     * @since 2.4.0
     */
    public function ajax_reset_system()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        try {
            $job_handler = \DIT\TrendStudio\Core\Plugin::get_instance()->get_job_handler();
            $results = $job_handler->reset_system_state();

            wp_send_json_success(array(
                'message' => __('System status reset successfully', 'dit-trend-content-studio'),
                'data'    => $results
            ));
        } catch (\Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

    /**
     * AJAX: Deactivate Quota Pause for a specific provider
     *
     * @since 2026-04-22
     */
    public function ajax_deactivate_quota_pause()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'dit-trend-content-studio')));
        }

        $provider = sanitize_key($_POST['provider'] ?? '');
        $builtin = ['gemini', 'custom'];
        $custom_providers = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers();
        $allowed = array_merge($builtin, array_keys($custom_providers));

        if (!in_array($provider, $allowed, true)) {
            wp_send_json_error(array('message' => __('Invalid provider', 'dit-trend-content-studio')));
        }

        if (!class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            wp_send_json_error(array('message' => __('Quota_Pause_Manager not available', 'dit-trend-content-studio')));
        }

        \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::clear($provider);

        wp_send_json_success(array(
            'message' => sprintf(__('Quota pause for %s has been deactivated', 'dit-trend-content-studio'), ucfirst($provider)),
            'provider' => $provider,
        ));
    }

    /**
     * AJAX: Download current day log file
     * 
     * @since 2.15.2
     */
    public function ajax_download_log()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $log_file = $this->logger->get_log_file();

        if (!file_exists($log_file)) {
            wp_die('Log file not found.');
        }

        // Clean output buffer to ensure clean file content
        if (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($log_file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($log_file));

		readfile($log_file);
		exit;
	}

	/**
	 * Handle saving the debug.log path from the logs page form
	 * @ADDED 2026-04-24
	 */
	public function handle_debug_log_path_save()
	{
		if (!isset($_POST['dit_ts_save_debug_log_path_btn'])) {
			return;
		}

		if (!current_user_can('manage_options')) {
			return;
		}

		if (!isset($_POST['dit_ts_debug_log_path_nonce']) || !wp_verify_nonce($_POST['dit_ts_debug_log_path_nonce'], 'dit_ts_save_debug_log_path')) {
			wp_die(__('Invalid nonce.', 'dit-trend-content-studio'));
		}

		$path = isset($_POST['dit_ts_debug_log_path']) ? wp_unslash($_POST['dit_ts_debug_log_path']) : '';
$path = preg_replace('#[<>\{\|\`\0]#', '', $path);
		update_option('dit_ts_debug_log_path', $path);

		wp_safe_redirect(admin_url('admin.php?page=dit-ts-logs&debug_log_saved=1'));
		exit;
	}

	/**
	 * AJAX: Download site debug.log file
	 * @ADDED 2026-04-24
	 */
	public function ajax_download_debug_log()
	{
		check_ajax_referer('dit_ts_nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_die('Insufficient permissions');
		}

		$debug_log_path = get_option('dit_ts_debug_log_path', '');

		if (empty($debug_log_path)) {
			wp_die('No debug.log path configured.');
		}

		$real = realpath($debug_log_path);

		if (!$real || !is_file($real) || !is_readable($real)) {
			wp_die('debug.log file not found or not readable.');
		}

		if (ob_get_level()) {
			ob_end_clean();
		}

		header('Content-Description: File Transfer');
		header('Content-Type: text/plain');
		header('Content-Disposition: attachment; filename="debug.log"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($real));

		readfile($real);
		exit;
	}

	/**
	 * AJAX: Fetch a single page of debug.log lines (paginated)
	 * @ADDED 2026-04-24
	 */
	public function ajax_fetch_debug_log_page()
	{
		check_ajax_referer('dit_ts_nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error('Insufficient permissions');
		}

		$debug_log_path = get_option('dit_ts_debug_log_path', '');

		if (empty($debug_log_path)) {
			wp_send_json_error('No debug.log path configured.');
		}

		$page     = isset($_GET['page_num']) ? absint($_GET['page_num']) : 1;
		$per_page = 100;

		$result = Logger::read_file_page($debug_log_path, $page, $per_page);

		wp_send_json_success($result);
	}

    /**
     * AJAX: Refresh Buffer channels for a specific account
     *
     * @since 2026-07-03
     */
    public function ajax_buffer_refresh_channels()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'dit-trend-content-studio')));
        }

        $account_id = isset($_POST['account_id']) ? sanitize_key($_POST['account_id']) : '';
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';

        // Fallback to stored token if not provided (legacy support)
        if (empty($token)) {
            $account = \DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_account($account_id);
            $token = $account['api_key'] ?? get_option('nm_buffer_access_token', '');
        }

        if (empty($token)) {
            wp_send_json_error(array('message' => __('Buffer API token is not configured', 'dit-trend-content-studio')));
        }

        $client = new \DIT\TrendStudio\Integrations\Buffer\Client($token, $this->logger, $account_id);
        $client->clear_all_caches($account_id);
        $channels = $client->get_channels();

        if (empty($channels)) {
            wp_send_json_error(array('message' => __('No channels found. Check API token and Buffer account', 'dit-trend-content-studio')));
        }

        // Fetch Pinterest boards for Pinterest channels
        $pinterest_boards = [];
        foreach ($channels as $channel_id => $channel_data) {
            if ($channel_data['service'] === 'pinterest') {
                $pinterest_boards[$channel_id] = $client->get_pinterest_boards($channel_id);
            }
        }

        // Merge Pinterest boards into channel data for UI
        foreach ($pinterest_boards as $ch_id => $boards) {
            $channels[$ch_id]['pinterest_boards'] = $boards;
        }

        // Return existing channel configs for this account if any
        $account = \DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_account($account_id);
        $channel_configs = $account['channels'] ?? [];

        wp_send_json_success(array(
            'channels' => $channels,
            'pinterest_boards' => $pinterest_boards,
            'channel_configs' => $channel_configs,
        ));
    }

    /**
     * AJAX: Test Buffer API connection
     *
     * @since 2026-05-15
     */
    public function ajax_buffer_test_connection()
    {
        check_ajax_referer('dit_ts_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'dit-trend-content-studio')));
        }

        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        $account_id = isset($_POST['account_id']) ? sanitize_key($_POST['account_id']) : '';
        if (empty($token)) {
            wp_send_json_error(array('message' => __('API token is required', 'dit-trend-content-studio')));
        }

        $client = new \DIT\TrendStudio\Integrations\Buffer\Client($token, $this->logger, $account_id);
        $org_id = $client->get_organization_id();

        if (!$org_id) {
            wp_send_json_error(array('message' => __('Failed to connect. Check API token and ensure Buffer account has organizations', 'dit-trend-content-studio')));
        }

        $channels = $client->get_channels();
        $channel_count = count($channels);

        wp_send_json_success(array(
            'message' => sprintf(__('Connected! Found %d channel(s)', 'dit-trend-content-studio'), $channel_count),
            'channels' => $channel_count,
        ));
    }
}
