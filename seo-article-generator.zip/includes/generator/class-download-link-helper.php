<?php

namespace SEO_Article_Generator\Generator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared helper for download link logic.
 * Central download-link contract: normalization, validation, grouping, and display.
 *
 * @since 2.14.0
 * @MODIFIED 2026-03-08: Added is_placeholder_url, infer_platform_from_url, normalize_variant_name,
 *   normalize_link, normalize_links, get_primary_link. Fixed normalize_platform_name, sort_links_by_variant.
 * @MODIFIED 2026-03-11: Enhanced placeholder detection with LLM hallucination patterns.
 */
class Download_Link_Helper {


	/**
	 * Placeholder patterns for junk URL detection.
	 *
	 * @since 2.27.0
	 */
	private const PLACEHOLDER_PATTERNS = array(
		'placeholder',
		'example.com/download',
		'example.com',
		'dummy.com',
		'localhost',
		'127.0.0.1',
		'download-link-here',
		'your-download-link',
		'test.com',
		'idXXXXXXXXX',
		'id000000000',
		'id123456789',
		'com.example',
		'com.yourcompany',
		'officialsite.com',
		'yourdomain.com',
		'11011111011', // AI Youtube hallucination
		'00000000000',
		'11111111111',
		'12345678901',
		'abcdefghijk',
		'xxxxxxxxxxx',
		'dQw4w9WgXcQ',
	);

	/**
	 * Canonical platform mapping.
	 *
	 * @since 2.27.0
	 */
	private const CANONICAL_PLATFORM_MAP = array(
		'windows'     => 'Windows',
		'win'         => 'Windows',
		'pc'          => 'Windows',
		'mac'         => 'macOS', // Standardized to macOS
		'macos'       => 'macOS',
		'osx'         => 'macOS',
		'mac os'      => 'macOS',
		'linux'       => 'Linux',
		'ubuntu'      => 'Linux',
		'debian'      => 'Linux',
		'fedora'      => 'Linux',
		'android'     => 'Android',
		'ios'         => 'iOS',
		'iphone'      => 'iOS',
		'ipad'        => 'iOS',
		'app store'   => 'iOS',
		'play store'  => 'Android',
		'google play' => 'Android',
	);

	/**
	 * Non-download file extensions that represent media, documents, fonts, stylesheets, or scripts.
	 *
	 * @since 2.31.0
	 */
	private const NON_DOWNLOAD_EXTENSIONS = array(
		'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'tiff', 'tif', 'heic', 'avif', // Images
		'mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a', 'wma',                                      // Audio
		'mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mpeg', 'mpg', 'm4v', '3gp',          // Video
		'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'rtf', 'odt', 'ods', 'odp',          // Documents
		'csv', 'xml', 'json', 'txt',                                                           // Data/text docs
		'woff', 'woff2', 'ttf', 'otf', 'eot',                                                  // Fonts
		'css', 'js', 'map', 'scss', 'less',                                                    // Web assets
	);

	/**
	 * Check if a URL is a placeholder, fake, or invalid download URL.
	 * This is the single source of truth for URL rejection across the pipeline.
	 *
	 * @MODIFIED 2026-03-09: Upgraded with robust pattern matching and host checks
	 * @MODIFIED 2026-03-11: Added standard AI hallucination patterns
	 *
	 * @param string $url URL to check
	 * @return bool True if URL should be rejected
	 */
	public static function is_placeholder_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' || $url === '#' || strtolower( $url ) === 'n/a' ) {
			return true;
		}

		// Decode HTML entities before pattern matching
		$decoded    = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
		$normalized = strtolower( trim( $decoded ) );

		$host       = parse_url( $decoded, PHP_URL_HOST );
		$host_lower = is_string( $host ) ? strtolower( preg_replace( '/^www\./i', '', $host ) ) : '';

		// Exempt explicitly trusted official domains from aggressive heuristic filtering.
		// Example: Google Chrome installers contain "/tag/" and "{GUIDs}" which trigger heuristic blocks.
		if ( $host_lower === 'dl.google.com' || $host_lower === 'google.com' || self::is_allowlisted_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				$exempt_reason = '';
				if ( $host_lower === 'dl.google.com' ) { $exempt_reason = 'dl.google.com'; }
				elseif ( $host_lower === 'google.com' ) { $exempt_reason = 'google.com'; }
				else { $exempt_reason = 'allowlist'; }
				error_log( '[DownloadLinkHelper] is_placeholder_url: EXEMPTED reason=' . $exempt_reason . ' host=' . $host_lower . ' url=' . $url );
			}
			return false;
		}

		if ( strpos( $normalized, 'javascript:' ) === 0 || strpos( $normalized, 'about:blank' ) === 0 || strpos( $normalized, 'data:' ) === 0 ) {
			return true;
		}

		if ( self::is_placeholder_youtube_url( $url ) ) {
			return true;
		}

		// Check against known placeholder patterns
		foreach ( self::PLACEHOLDER_PATTERNS as $needle ) {
			if ( strpos( $normalized, $needle ) !== false ) {
				return true;
			}
		}

		// Complex invalid patterns
		$invalid_patterns = array(
			'/your[-_\s]?link/i',
			'/your[-_\s]?download/i',
			'/your[-_\s]?url/i',
			'/fake/i',
			'/sample/i',
			'/changeme/i',
			'/not[\s\-_]*found/i',
			'/\{.+\}/',
			'/\[.+\]/',
			'/id[X0]{5,}/i', // Catch idXXXXX or id00000 with 5+ chars
			'/com\.(example|yourcompany|yourdomain)\./i',
		);

		foreach ( $invalid_patterns as $pattern ) {
			if ( preg_match( $pattern, $url ) ) {
				return true;
			}
		}

		// Host-based rejection (Trash/Social/Hallucination hubs)
		if ( is_string( $host ) ) {
			$host          = strtolower( preg_replace( '/^www\./i', '', $host ) );
			$blocked_hosts = array(
				'example.com',
				'dummy.com',
				'localhost',
				'127.0.0.1',
				'0.0.0.0',
				'facebook.com',
				'twitter.com',
				'linkedin.com',
				'pinterest.com',
				't.co',
				'instagram.com',
				'reddit.com',
				'youtube.com',
				'youtu.be',
				'vimeo.com',
			);

			if ( in_array( $host, $blocked_hosts, true ) ) {
				return true;
			}

			// Reject known "Trash" domains identified by user
			if ( stripos( $host, 'softexia.com' ) !== false && ( stripos( $url, '/tag/' ) !== false || stripos( $url, '/category/' ) !== false ) ) {
				return true;
			}
		}

		// Path-based rejection for generic "Hub" patterns
		$path = parse_url( $decoded, PHP_URL_PATH );
		if ( is_string( $path ) ) {
			$path_lower    = strtolower( $path );
			$blocked_paths = array( '/tag/', '/category/', '/author/', '/search/', '/drivers/' );
			foreach ( $blocked_paths as $p ) {
				if ( strpos( $path_lower, $p ) !== false ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( '[DownloadLinkHelper] is_placeholder_url: REJECTED - blocked path="' . $p . '" url=' . $url );
					}
					return true;
				}
			}
		}

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_placeholder_url: PASSED url=' . $url );
		}
		return false;
	}

	/**
	 * Combined check for URL validity and placeholder status.
	 * Useful for external validation (e.g. Validator).
	 *
	 * @since 2.27.0
	 *
	 * @param string $url URL to check
	 * @return bool True if URL is a real, valid HTTP(S) download link
	 */
	public static function is_valid_download_url( $url ) {
		$url = trim( (string) $url );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_valid_download_url: CHECKING url=' . $url );
		}
		if ( self::is_placeholder_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - is_placeholder_url=true url=' . $url );
			}
			return false;
		}

		if ( self::is_affiliate_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - affiliate_url=true url=' . $url );
			}
			return false;
		}

		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - invalid_url=true url=' . $url );
			}
			return false;
		}

		$path = (string) parse_url( $url, PHP_URL_PATH );
		if ( $path !== '' ) {
			$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
			if ( in_array( $ext, self::NON_DOWNLOAD_EXTENSIONS, true ) ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - non-download extension="' . $ext . '" url=' . $url );
				}
				return false;
			}
		}

		$scheme = strtolower( (string) parse_url( $url, PHP_URL_SCHEME ) );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_valid_download_url: ACCEPTED scheme=' . $scheme . ' url=' . $url );
		}
		return in_array( $scheme, array( 'http', 'https' ), true );
	}

	/**
	 * Positive binary-link check — mirrors Link_Resolver::resolve_from_html()
	 * so the discovery and generator paths agree on what counts as a download.
	 *
	 * @since 2.40.0
	 * @param string $url  URL to check.
	 * @param string $text Optional anchor/context text (secondary signal).
	 * @return bool True if URL is a binary file or release-asset target.
	 */
	public static function is_binary_link_url( $url, $text = '' ) {
		$url  = trim( (string) $url );
		$text = (string) $text;
		if ( $url === '' ) {
			return false;
		}
		if ( self::is_allowlisted_url( $url ) ) {
			return true;
		}
		if ( preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|deb|rpm|apk|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $url ) ) {
			return true;
		}
		if ( preg_match( '~/(releases/(?:download|expanded_assets|latest)(?:[/?#]|$)|releases/tag/|-/releases(?:[/?#]|$)|raw/|archive/refs/)~i', $url ) ) {
			return true;
		}
		if ( preg_match( '#/projects/.+/files/.+/(download)?#i', $url ) ) {
			return true;
		}
		if ( $text !== '' && preg_match( '/\b(?:download|get\s+for|installer|offline\s+installer|direct\s+link|portable|trial)\b/i', $text ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Check if a URL is an affiliate/tracking redirect that should be rejected.
	 *
	 * Detects two classes of affiliate URLs:
	 * 1. Domain denylist — known affiliate network short domains (prf.hn, awin1.com, etc.)
	 * 2. Structural heuristic — opaque redirect paths with no file extension on non-vendor domains
	 *
	 * @MODIFIED 2026-04-29: Added for affiliate link firewall.
	 *
	 * @param string $url URL to check.
	 * @return bool True if the URL is an affiliate/tracking redirect.
	 */
	public static function is_affiliate_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return false;
		}

		$host = strtolower( (string) parse_url( $url, PHP_URL_HOST ) );
		if ( $host === '' ) {
			return false;
		}

		// Hardcoded standard affiliate redirect domains denylist (Impact, Awin, ShareASale, CJ, etc.)
		static $hardcoded_affiliate_hosts = array(
			'evyy.net'                => true,
			'sjv.io'                  => true,
			'pxf.io'                  => true,
			'prf.hn'                  => true,
			'awin1.com'               => true,
			'shareasale.com'          => true,
			'cj.com'                  => true,
			'jdoqocy.com'             => true,
			'tkqlhce.com'             => true,
			'anrdoezrs.net'           => true,
			'dpbolvw.net'             => true,
			'kqzyfj.com'              => true,
			'qksrv.net'               => true,
			'click.linksynergy.com'   => true,
			'linksynergy.com'         => true,
			'rakuten.com'             => true,
			'impact.com'              => true,
			'impactradius.com'        => true,
			'flexlinkspro.com'        => true,
			'tracking.flexlinks.com'  => true,
			'referralrock.com'        => true,
			'partnerstack.com'        => true,
			'getrewardful.com'        => true,
			'tapfiliate.com'          => true,
			'leaddyno.com'            => true,
			'refersion.com'           => true,
			'ambassador.com'          => true,
			'emjcd.com'               => true,
			'avangate.com'            => true,
			'shareit.com'             => true,
			'regnow.com'              => true,
			'digistore24.com'         => true,
			'clickbank.net'           => true,
			'clickbank.com'           => true,
			'admitad.com'             => true,
			'tradedoubler.com'        => true,
			'webgains.com'            => true,
			'postaffiliatepro.com'    => true,
			'gomasters.co'            => true,
			'referralcandy.com'       => true,
			'doubleclick.net'         => true,
			'googleadservices.com'    => true,
		);

		if ( isset( $hardcoded_affiliate_hosts[ $host ] ) ) {
			return true;
		}
		foreach ( $hardcoded_affiliate_hosts as $denied => $true ) {
			if ( substr( $host, -( strlen( '.' . $denied ) ) ) === '.' . $denied ) {
				return true;
			}
		}

		// 1. Domain denylist check (admin-configurable)
		static $denylist = null;
		if ( $denylist === null ) {
			$raw      = trim(
				(string) \get_option(
					\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST,
					\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST ]
				)
			);
			$denylist = array();
			if ( $raw !== '' ) {
				foreach ( preg_split( '/\r?\n/', $raw ) as $line ) {
					$line = strtolower( trim( $line ) );
					if ( $line !== '' ) {
						$denylist[ $line ] = true;
					}
				}
			}
		}

		if ( ! empty( $denylist ) ) {
			// Exact match
			if ( isset( $denylist[ $host ] ) ) {
				return true;
			}
			// Subdomain match (e.g., tracking.prf.hn)
			foreach ( $denylist as $denied => $true ) {
				if ( $denied !== '' && substr( $host, -( strlen( '.' . $denied ) ) ) === '.' . $denied ) {
					return true;
				}
			}
		}

		// 2. Structural heuristic: affiliate-style paths on non-vendor, non-store domains
		// Pattern: no file extension + path contains /click/ /track/ /redirect/ /aff/ /go/ /visit/
		// AND host is NOT a trusted store or in the allowlist
		$path         = (string) parse_url( $url, PHP_URL_PATH );
		$has_file_ext = (bool) preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|apk|ipa|deb|rpm|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $path );
		if ( ! $has_file_ext && preg_match( '#/(click|track|redirect|aff|go|visit|ref|out|jump|hop|offer|cmp|campaign|deep|link)/#i', $path ) ) {
			// Exempt trusted stores and vendor domains (via allowlist)
			$trusted_stores = array( 'play.google.com', 'apps.apple.com', 'itunes.apple.com', 'apps.microsoft.com' );
			if ( ! in_array( $host, $trusted_stores, true ) ) {
				// Check if host is in download allowlist — those are explicitly trusted
				$url_clean = rtrim( strtolower( trim( $url ) ), '/' );
				if ( ! self::is_allowlisted_url( $url_clean ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Check if a URL is in the admin-configured download allowlist.
	 *
	 * Supports two entry types:
	 * - Full URL (contains "://"): exact match against the normalized URL.
	 * - Bare domain (no "://"): matches against any URL on that host.
	 *
	 * The allowlist bypasses the homepage collision guard for software whose
	 * download URL legitimately equals the homepage (web apps, browser extensions).
	 *
	 * @MODIFIED 2026-04-22: Added for homepage collision guard bypass.
	 * @MODIFIED 2026-05-06: Added bare-domain host matching.
	 *
	 * @param string $url URL to check (already lowercase, trailing-slash-stripped).
	 * @return bool True if the URL or its host is in the allowlist.
	 */
	private static function is_allowlisted_url( $url ) {
		static $allowlist       = null;
		static $allowlist_hosts = null;
		if ( $allowlist === null ) {
			$raw             = trim(
				(string) \get_option(
					\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST,
					\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST ]
				)
			);
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: get_option raw=' . var_export($raw, true) . ' | option_key=' . \SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST );
			}
			$allowlist       = array();
			$allowlist_hosts = array();
			if ( $raw !== '' ) {
				foreach ( preg_split( '/\r?\n/', $raw ) as $line ) {
					$line = rtrim( strtolower( trim( $line ) ), '/' );
					if ( $line === '' ) {
						continue;
					}
					if ( strpos( $line, '://' ) === false ) {
						// Bare host (with optional path/query) — strip everything past the
						// first "/" so "vendor.com/track/foo" stores as the bare host
						// "vendor.com" and matches every URL on that host. This mirrors
						// the lookup at lines below which only reads PHP_URL_HOST.
						$host_only = strtolower( trim( (string) explode( '/', $line, 2 )[0] ) );
						if ( $host_only !== '' ) {
							$allowlist_hosts[ $host_only ] = true;
						}
					} else {
						$allowlist[ $line ] = true;
					}
				}
			}
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: LOADED allowlist_hosts=' . implode(', ', array_keys($allowlist_hosts)) . ' | allowlist_urls=' . implode(', ', array_keys($allowlist)) );
			}
		}

		// 1. Exact URL match (legacy behavior)
		if ( isset( $allowlist[ $url ] ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED exact_url=' . $url );
			}
			return true;
		}

		// 2. Host match against bare-domain entries
		if ( ! empty( $allowlist_hosts ) ) {
			$host = strtolower( parse_url( $url, PHP_URL_HOST ) );
			if ( $host !== false && $host !== null && $host !== '' ) {
				if ( isset( $allowlist_hosts[ $host ] ) ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED host=' . $host . ' for url=' . $url );
					}
					return true;
				}
				// Subdomain match: e.g. "dl.google.com" matches any subdomain
				foreach ( $allowlist_hosts as $allowed_host => $true ) {
					if ( substr( $host, -( strlen( '.' . $allowed_host ) ) ) === '.' . $allowed_host ) {
						if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
							error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED subdomain host=' . $host . ' matches allowed_host=' . $allowed_host . ' for url=' . $url );
						}
						return true;
					}
				}
			}
		}

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_allowlisted_url: NOT allowlisted url=' . $url . ' | allowlist_hosts=' . implode(', ', array_keys($allowlist_hosts)) . ' | allowlist_urls=' . implode(', ', array_keys($allowlist)) );
		}
		return false;
	}

	/**
	 * Public entry point for allowlist checks from outside this class.
	 *
	 * Accepts a raw URL (with or without scheme) and returns true if the URL
	 * or its host appears in the admin-configured download allowlist.
	 *
	 * @param string $url The URL to check.
	 * @return bool True if allowlisted (exact URL or matching host).
	 */
	public static function is_url_in_allowlist( $url ) {
		if ( ! is_string( $url ) || trim( $url ) === '' ) {
			return false;
		}
		$url_clean = rtrim( strtolower( trim( $url ) ), '/' );
		return self::is_allowlisted_url( $url_clean );
	}

	/**
	 * Infer platform from URL domain or file extension.
	 *
	 * @MODIFIED 2026-03-09: Standardized on macOS and expanded detection
	 *
	 * @param string $url Download URL
	 * @return string Platform name or empty string
	 */
	public static function infer_platform_from_url( $url ) {
		if ( ! is_string( $url ) || trim( $url ) === '' ) {
			return '';
		}

		$normalized_url = strtolower( $url );
		$host           = (string) parse_url( $normalized_url, PHP_URL_HOST );
		$path           = (string) parse_url( $normalized_url, PHP_URL_PATH );

		// Extension-based detection (Tier 1: Most reliable for direct links)
		if ( preg_match( '/\.(exe|msi|msix|msp|appx)(?:$|\?)/i', $path ) ) {
			return 'Windows';
		}
		if ( preg_match( '/\.(dmg|pkg)(?:$|\?)/i', $path ) ) {
			return 'macOS';
		}

		if ( preg_match( '/\.(apk)(?:$|\?)/i', $path ) ) {
			return 'Android';
		}

		if ( preg_match( '/\.(appimage|deb|rpm|snap|flatpak|pak|tar\.gz|tgz|tar\.xz|tar\.bz2)(?:$|\?)/i', $path ) ) {
			return 'Linux';
		}

		// Tier 1.2: Path/Query keyword detection (resolves ambiguity for ZIP/pages)
		$query = (string) parse_url( $normalized_url, PHP_URL_QUERY );
		if ( $query !== '' ) {
			if ( preg_match( '/\bplatform=(win|windows|pc)\b/i', $query ) ) {
				return 'Windows';
			}
			if ( preg_match( '/\bplatform=(mac|macos|osx|osx-api|ios-mac)\b/i', $query ) ) {
				return 'macOS';
			}
			if ( preg_match( '/\bplatform=(linux|ubuntu|debian)\b/i', $query ) ) {
				return 'Linux';
			}
			if ( preg_match( '/\bplatform=android\b/i', $query ) ) {
				return 'Android';
			}
			if ( preg_match( '/\bplatform=ios\b/i', $query ) ) {
				return 'iOS';
			}
		}

		// Also check path keywords
		if ( preg_match( '/[-_\/]linux(?:64|32)?[-_\.\/]/i', $path ) || preg_match( '/[-_]linux$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Linux';
		}
		if ( preg_match( '/[-_\/](?:mac|macos|osx|apple)[-_\.\/]/i', $path ) || preg_match( '/[-_](?:mac|macos|osx)$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'macOS';
		}
		if ( preg_match( '/[-_\/]windows[-_\.\/]/i', $path ) || preg_match( '/[-_]windows$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Windows';
		}
		if ( preg_match( '/[-_\/]android[-_\.\/]/i', $path ) || preg_match( '/[-_]android$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Android';
		}
		if ( preg_match( '/[-_\/]ios[-_\.\/]/i', $path ) || preg_match( '/[-_]ios$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'iOS';
		}

		// Tier 1.3: Ambiguous archives (ZIP/7z/RAR) fallback
		if ( preg_match( '/\.(zip|7z|rar)(?:$|\?)/i', $path ) ) {
			// ZIP is ambiguous, but on software sites it's usually Windows if no other clue exists
			return 'Windows';
		}

		// Domain-based detection (Tier 2: Source portals)
		if ( strpos( $host, 'apps.apple.com' ) !== false || strpos( $host, 'itunes.apple.com' ) !== false ) {
			return 'iOS';
		}

		if ( strpos( $host, 'play.google.com' ) !== false ) {
			return 'Android';
		}

		if ( strpos( $host, 'apps.microsoft.com' ) !== false || strpos( $host, 'microsoft.com' ) !== false ) {
			return 'Windows';
		}

		if ( strpos( $host, 'commerce.adobe.com' ) !== false ) {
			return 'Windows';
		}

		if ( strpos( $host, 'snapcraft.io' ) !== false || strpos( $host, 'flathub.org' ) !== false ) {
			return 'Linux';
		}

		return '';
	}

	/**
	 * Normalize variant name to canonical form.
	 *
	 * @MODIFIED 2026-03-09: Using improved mapping from proposed patch
	 *
	 * @param string $variant Raw variant
	 * @return string Normalized variant name
	 */
	public static function normalize_variant_name( $variant ) {
		$variant = trim( (string) $variant );
		if ( $variant === '' ) {
			return 'Standard';
		}

		$map = array(
			'64-bit'           => 'x64',
			'64 bit'           => 'x64',
			'64bit'            => 'x64',
			'64_bit'           => 'x64',
			'x64'              => 'x64',
			'amd64'            => 'x64',
			'win64'            => 'x64',
			'32-bit'           => 'x32',
			'32 bit'           => 'x32',
			'32bit'            => 'x32',
			'32_bit'           => 'x32',
			'x86'              => 'x32',
			'win32'            => 'x32',
			'i686'             => 'x32',
			'i386'             => 'x32',
			'arm64'            => 'ARM64',
			'aarch64'          => 'ARM64',
			'arm'              => 'ARM',
			'mac'              => 'Intel', // @MODIFIED 2026-05-21: Firefox .mac.pkg = Intel macOS
			'portable'         => 'Portable',
			'portable version' => 'Portable',
			'intel'            => 'Intel',
			'universal'        => 'Universal',
			'standard'         => 'Standard',
			'x86_64'           => 'x64',
			'esr'              => 'ESR',
			'lts'              => 'LTS',
			'pro'              => 'Pro',
			'lite'             => 'Lite',
			'community'        => 'Community',
			'enterprise'       => 'Enterprise',
			'premium'          => 'Premium',
			'ultimate'         => 'Ultimate',
			'professional'     => 'Professional',
			'trial'            => 'Trial',
			'plus trial'       => 'Plus Trial',
			'premium trial'    => 'Premium Trial',
			'platinum trial'   => 'Platinum Trial',
			'beta'             => 'Beta',
			'alpha'            => 'Alpha',
			'rc'               => 'RC',
			'preview'          => 'Preview',
			'canary'           => 'Canary',
			'nightly'          => 'Nightly',
			'dev'              => 'Dev',
			'stable'           => 'Stable',
			'basic'            => 'Basic',
			'free'             => 'Free',
			'suite'            => 'Suite',
			'plus'             => 'Plus',
			'max'              => 'Max',
			'mini'             => 'Mini',
			'home'             => 'Home',
			'express'          => 'Express',
			// @MODIFIED 2026-05-02: Added 'platinum' to sync with normalize_variant_label() map.
			'platinum'         => 'Platinum',
			'server'           => 'Server',
			'workstation'      => 'Workstation',
			'2go'              => '2Go',
			'offline'          => 'Offline',
			'debug'            => 'Debug',
			'dch'              => 'DCH',
			'dc'               => 'DC',
			'minimalist'       => 'Minimalist',
			'installer'        => 'Installer',
			'whql'             => 'WHQL',
			'quadro'           => 'Quadro',
			'business'         => 'Business',
			// @ADDED 2026-05-21: Missing architecture/education variants from audit
			'education'        => 'Education',
			'educational'      => 'Education',
			'academic'         => 'Academic',
			'home student'     => 'Home Student',
			'student'          => 'Student',
			'personal'         => 'Personal',
			'starter'          => 'Starter',
			'basic edition'    => 'Basic',
			'free edition'     => 'Free',
			'home edition'     => 'Home',
		);

		$key = strtolower( $variant );
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}

		// ARM64 falls back to custom logic if not in map
		if ( strpos( $key, 'apple silicon' ) !== false || preg_match( '/\bm[1-4]\b/i', $variant )
		) {
			return 'ARM64';
		}

		// @MODIFIED 2026-05-02: Preserve known lowercase architecture prefixes in composed
		// variants (e.g. "x64 Portable", "x86 ESR") — ucwords would produce "X64 Portable".
		// @MODIFIED 2026-05-07: Guard against architecture prefix duplicating a token
		// inside the suffix. e.g. "x64 Professional x64" would split into prefix="x64"
		// and suffix="Professional x64" — normalize_variant_label dedupes WITHIN the
		// suffix but NOT against the prefix. Strip prefix from suffix if present.
		// @MODIFIED 2026-05-13: Map prefix through canonical map so 'x86' becomes 'x32'.
		if ( preg_match( '/^(x64|x86|arm64|arm|intel|universal)\s+(.+)$/i', $variant, $cm ) ) {
			$prefix_lower     = strtolower( $cm[1] );
			$prefix_canonical = isset( $map[ $prefix_lower ] ) ? $map[ $prefix_lower ] : $prefix_lower;
			$suffix_lower     = strtolower( trim( $cm[2] ) );
			if ( preg_match( '/^(x64|x86|arm64|arm|intel|universal)$/i', $suffix_lower ) ) {
				$suffix_canonical = isset( $map[ $suffix_lower ] ) ? $map[ $suffix_lower ] : $suffix_lower;
				if ( $suffix_canonical === $prefix_canonical ) {
					return $prefix_canonical;
				}
				return $prefix_canonical . ' ' . $suffix_canonical;
			}
			$suffix        = self::normalize_variant_label( $cm[2] );
			$suffix_tokens = preg_split( '/\s+/', $suffix );
			$cleaned       = array();
			foreach ( $suffix_tokens as $st ) {
				if ( strtolower( $st ) === $prefix_canonical ) {
					continue;
				}
				$cleaned[] = $st;
			}
			$suffix = implode( ' ', $cleaned );
			if ( $suffix === '' ) {
				return $prefix_canonical;
			}
			return $prefix_canonical . ' ' . $suffix;
		}
		return self::normalize_variant_label( $variant );
	}

	/**
	 * Normalize platform name to canonical form.
	 *
	 * @MODIFIED 2026-03-09: Standardized to macOS and using CANONICAL_PLATFORM_MAP
	 *
	 * @param string $platform Raw platform name
	 * @return string Normalized platform name
	 */
	public static function normalize_platform_name( $platform, $url = '' ) {
		$platform = trim( (string) $platform );
		if ( $platform === '' ) {
			return 'Other';
		}

		$key = strtolower( $platform );
		$key = str_replace( array( '-', '_' ), ' ', $key );
		$key = preg_replace( '/\s+/', ' ', $key );
		$key = trim( $key );

		// 1. GOD MODE: Prioritize official stores over labels
		$inferred = '';
		if ( ! empty( $url ) ) {
			$inferred        = self::infer_platform_from_url( $url );
			$is_strong_store = ( strpos( $url, 'play.google.com' ) !== false || strpos( $url, 'apps.apple.com' ) !== false );

			if ( $is_strong_store && $inferred !== '' ) {
				return $inferred;
			}
		}

		// 2. Exact match in canonical platform map
		if ( isset( self::CANONICAL_PLATFORM_MAP[ $key ] ) ) {
			return self::CANONICAL_PLATFORM_MAP[ $key ];
		}

		// 3. Substring matching of known platform keywords in the raw string
		if ( strpos( $key, 'linux' ) !== false ) {
			return 'Linux';
		}
		if ( strpos( $key, 'mac' ) !== false || strpos( $key, 'osx' ) !== false || strpos( $key, 'os x' ) !== false ) {
			return 'macOS';
		}
		if ( strpos( $key, 'android' ) !== false ) {
			return 'Android';
		}
		if ( strpos( $key, 'ios' ) !== false || strpos( $key, 'iphone' ) !== false || strpos( $key, 'ipad' ) !== false ) {
			return 'iOS';
		}
		if ( strpos( $key, 'win' ) !== false || strpos( $key, 'pc' ) !== false || strpos( $key, 'windows' ) !== false ) {
			return 'Windows';
		}

		// 4. Split compound platform strings
		if ( strpos( $platform, ';' ) !== false || strpos( $platform, ',' ) !== false || strpos( $platform, '/' ) !== false || strlen( $platform ) > 30 ) {
			$first_token = preg_split( '/[;,\/]/', $platform )[0];
			$first_token = trim( $first_token );

			if ( $first_token !== $platform ) {
				$normalized_token = self::normalize_platform_name( $first_token, $url );
				if ( $normalized_token !== 'Other' ) {
					return $normalized_token;
				}
			}
		}

		// 5. Fallback to inferred platform from URL if available
		if ( empty( $inferred ) && ! empty( $url ) ) {
			$inferred = self::infer_platform_from_url( $url );
		}
		if ( ! empty( $inferred ) ) {
			return $inferred;
		}

		return ucfirst( $platform );
	}

	/**
	 * Build a unique identity tuple for a download link.
	 * Two links with the same identity = same button = duplicate.
	 *
	 * @since 2.31.0
	 * @param array $link
	 * @return string
	 */
	public static function build_link_identity( array $link ) {
		$platform  = strtolower( $link['platform'] ?? 'windows' );
		$variant   = strtolower( $link['variant'] ?? 'standard' );
		$file_type = strtolower( $link['file_type'] ?? '' );
		return "{$platform}|{$variant}|{$file_type}";
	}

	/**
	 * Decode CDN URL patterns for platform/variant keywords.
	 *
	 * @since 2.31.0
	 * @param string $url
	 * @return array Array with keys 'platform' and 'variant'
	 */
	public static function decode_cdn_parameters( $url ) {
		$result = array( 'platform' => '', 'variant' => '' );
		if ( empty( $url ) ) {
			return $result;
		}

		$url_lower = strtolower( $url );

		// 1. Avast/AVG CDN: bits.avcdn.net / avcdn.net
		if ( strpos( $url_lower, 'avcdn.net' ) !== false ) {
			if ( strpos( $url_lower, 'platform_win' ) !== false ) {
				$result['platform'] = 'Windows';
			} elseif ( strpos( $url_lower, 'platform_mac' ) !== false ) {
				$result['platform'] = 'macOS';
			}
			if ( strpos( $url_lower, 'insttype_free' ) !== false ) {
				$result['variant'] = 'Free';
			}
			// Look for offline setup
			if ( strpos( $url_lower, '_setup_offline' ) !== false ) {
				$result['variant'] = 'Offline';
			} elseif ( strpos( $url_lower, '_setup_online' ) !== false ) {
				$result['variant'] = 'Online';
			}
		}

		// 2. Adobe CDN
		if ( strpos( $url_lower, 'adobe.com' ) !== false ) {
			if ( strpos( $url_lower, '/osx/' ) !== false || strpos( $url_lower, '/mac/' ) !== false || strpos( $url_lower, 'dmg' ) !== false ) {
				$result['platform'] = 'macOS';
			} elseif ( strpos( $url_lower, '/win/' ) !== false || strpos( $url_lower, 'exe' ) !== false || strpos( $url_lower, 'msi' ) !== false ) {
				$result['platform'] = 'Windows';
			}
		}

		// 3. Microsoft CDN
		if ( strpos( $url_lower, 'microsoft.com' ) !== false ) {
			if ( strpos( $url_lower, 'windowsserver' ) !== false ) {
				$result['platform'] = 'Windows Server';
			}
		}

		return $result;
	}

	/**
	 * Normalize a single download link.
	 *
	 * @MODIFIED 2026-03-09: Integrated is_valid_download_url() and improved platform fallback
	 * @MODIFIED 2026-04-22: Added $homepage parameter — rejects links whose URL resolves
	 * to the software homepage (AI fallback for missing portable links).
	 * @MODIFIED 2026-05-23: Added $software_name parameter and CDN parameter decoding.
	 *
	 * @param array  $link            Raw link data
	 * @param string $fallback_platform Platform to use if none can be detected
	 * @param string $homepage        Software homepage URL to guard against (optional)
	 * @param string $software_name   Software name (optional)
	 * @return array|null Normalized link or null if invalid
	 */
	public static function normalize_link( $link, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		$input_url = is_array( $link ) ? ( $link['url'] ?? '' ) : (string) $link;
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_link: PROCESSING url=' . $input_url . ' | homepage=' . $homepage . ' | software=' . $software_name );
		}
		if ( ! is_array( $link ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] normalize_link REJECTED: input is not an array | url=' . $input_url );
			}
			return null;
		}

		$url = isset( $link['url'] ) ? trim( (string) $link['url'] ) : '';
		$url = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );

		// [ROBUST FIX] Strip direct affiliate and tracking parameters
		$parsed = wp_parse_url( $url );
		if ( ! empty( $parsed['query'] ) ) {
			wp_parse_str( $parsed['query'], $query_args );
			$affiliate_keys = array( 'affiliate', 'aff', 'ref', 'tag', 'source', 'clickid', 'irclickid', 'partner', 'utm_source', 'utm_medium', 'utm_campaign' );
			$modified       = false;
			foreach ( array_keys( $query_args ) as $key ) {
				if ( in_array( strtolower( $key ), $affiliate_keys, true ) ) {
					unset( $query_args[ $key ] );
					$modified = true;
				}
			}
			if ( $modified ) {
				$base_url    = explode( '?', $url )[0];
				$clean_query = http_build_query( $query_args );
				$url         = $base_url . ( ! empty( $clean_query ) ? '?' . $clean_query : '' );
			}
		}

		if ( ! self::is_valid_download_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( sprintf(
					'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=is_valid_download_url=false | software=%s',
					$url, $software_name
				) );
			}
			return null;
		}

		// HOMEPAGE COLLISION GUARD (2026-04-22)
		// Reject any link whose URL (stripped of trailing slash) matches the homepage,
		// UNLESS the URL is in the admin-configured download allowlist
		// OR the link is a portal fallback injected by Discovery_Processor for Link Continuity
		// OR the link is a canonical source link marked with _bypass_homepage_guard.
		if ( ! empty( $homepage ) ) {
			$url_clean      = rtrim( strtolower( trim( $url ) ), '/' );
			$homepage_clean = rtrim( strtolower( trim( (string) $homepage ) ), '/' );
			if ( $homepage_clean !== '' && $url_clean === $homepage_clean ) {
				$is_portal_fallback      = ! empty( $link['_portal_fallback'] );
				$is_canonical_bypass     = ! empty( $link['_bypass_homepage_guard'] );
				if ( ! self::is_allowlisted_url( $url_clean ) && ! $is_portal_fallback && ! $is_canonical_bypass ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( sprintf(
							'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=homepage_collision | homepage=%s | software=%s',
							$url, $homepage, $software_name
						) );
					}
					return null;
				}
			}
		}

		// CHANGELOG COLLISION GUARD (2026-05-24)
		if ( ! empty( $changelogurl ) ) {
			$url_clean       = rtrim( strtolower( trim( $url ) ), '/' );
			$changelog_clean = rtrim( strtolower( trim( (string) $changelogurl ) ), '/' );
			if ( $changelog_clean !== '' && $url_clean === $changelog_clean ) {
				$is_portal_fallback  = ! empty( $link['_portal_fallback'] );
				$is_canonical_bypass = ! empty( $link['_bypass_homepage_guard'] );
				if ( ! self::is_allowlisted_url( $url_clean ) && ! $is_portal_fallback && ! $is_canonical_bypass ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( sprintf(
							'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=changelog_collision | changelog=%s | software=%s',
							$url, $changelogurl, $software_name
						) );
					}
					return null;
				}
			}
		}

		$platform = isset( $link['platform'] ) ? trim( (string) $link['platform'] ) : '';

		// CDN decode fallback (Finding #4)
		$cdn_data = self::decode_cdn_parameters( $url );
		
		if ( $platform === '' ) {
			$platform = self::infer_platform_from_url( $url );
		}
		if ( $platform === '' && ! empty( $cdn_data['platform'] ) ) {
			$platform = $cdn_data['platform'];
		}
		if ( $platform === '' ) {
			$platform = $fallback_platform;
		}
		// @MODIFIED 2026-03-13: Pass $url so compound platform strings resolve via URL inference
		$platform = self::normalize_platform_name( $platform, $url );

		$variant = isset( $link['variant'] ) ? trim( (string) $link['variant'] ) : 'Standard';
		$variant = self::normalize_variant_name( $variant );

		// If variant is generic, check CDN fallback
		$generic_variants = array( 'Standard', 'Default', 'Main', '' );
		if ( in_array( $variant, $generic_variants, true ) && ! empty( $cdn_data['variant'] ) ) {
			$variant = self::normalize_variant_name( $cdn_data['variant'] );
		}

		// @MODIFIED 2026-04-23: When structured variant is generic/empty, use URL-inferred fallback
		$link_text_for_extract = trim( (string) ( $link['text'] ?? '' ) );
		$url_extracted         = null;
		if ( in_array( $variant, $generic_variants, true ) && ( ! empty( $url ) || ! empty( $link_text_for_extract ) ) ) {
			$url_extracted = self::extract_version_from_url( $url, $link_text_for_extract, $software_name );
			if ( $url_extracted !== '' ) {
				$variant_tokens = self::extract_variant_tokens_from_composite( $url_extracted );
				if ( $variant_tokens !== '' ) {
					$url_variant = self::normalize_variant_name( $variant_tokens );
					if ( $url_variant !== 'Standard' && $url_variant !== $variant ) {
						$variant = $url_variant;
					}
				}
			}
			// @MODIFIED 2026-05-04: When URL extraction found no variant, fall through to anchor-text extraction
			if ( in_array( $variant, $generic_variants, true ) && ! empty( $link_text_for_extract ) ) {
				$anchor_variant = self::extract_variant_from_anchor_text( $link_text_for_extract, $software_name, $platform );
				if ( $anchor_variant !== '' && $anchor_variant !== 'Standard' && ! in_array( $anchor_variant, $generic_variants, true ) ) {
					$variant = $anchor_variant;
				}
			}
		} elseif ( ! empty( $url ) ) {
			// @MODIFIED 2026-05-02: Compose architecture and variant when variant is non-generic
			$url_extracted = self::extract_version_from_url( $url, $link_text_for_extract, $software_name );
			if ( $url_extracted !== '' ) {
				$arch_tokens = self::extract_variant_tokens_from_composite( $url_extracted, true );
				if ( $arch_tokens !== '' ) {
					$url_arch  = self::normalize_variant_name( $arch_tokens );
					$arch_only = array( 'x64', 'x32', 'ARM64', 'ARM', 'Intel', 'Universal' );
					if ( in_array( $url_arch, $arch_only, true ) ) {
						$variant_words = array_map( 'strtolower', preg_split( '/\s+/', $variant ) );
						if ( ! in_array( strtolower( $url_arch ), $variant_words, true ) ) {
							$variant = $url_arch . ' ' . $variant;
						}
					}
				}
			}
		}
		$version = isset( $link['version'] ) ? trim( (string) $link['version'] ) : '';
		if ( $version === '' && ( ! empty( $url ) || ! empty( $link_text_for_extract ) ) ) {
			if ( $url_extracted === null ) {
				$url_extracted = self::extract_version_from_url( $url, $link_text_for_extract, $software_name );
			}
			$version = $url_extracted;
			if ( preg_match( '/(\d+(?:\.\d+)+)(?=[^0-9.]|$)/', $version, $vm ) ) {
				$version = $vm[1];
			} elseif ( preg_match( '/(\d{4,})\b/', $version, $vm ) ) {
				$version = $vm[1];
			} elseif ( ! preg_match( '/^\d/', $version ) ) {
				$version = '';
			}
		}
		$channel = isset( $link['channel'] ) ? trim( (string) $link['channel'] ) : '';

		$text = isset( $link['text'] ) ? trim( wp_strip_all_tags( (string) $link['text'] ) ) : '';

		// @MODIFIED 2026-05-02: Delegated to infer_file_type_from_url() — single mapping table (GAP 7).
		// URL-based inference ALWAYS wins over AI-provided file_type when URL has a recognizable extension.
		// AI file_type is only used when the URL has no recognizable extension (portal/redirect URLs).
		$file_type = self::infer_file_type_from_url( $url );
		if ( empty( $file_type ) && ! empty( $link['file_type'] ) ) {
			$file_type = sanitize_text_field( (string) $link['file_type'] );
		}

		$return_url = esc_url_raw( $url );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_link: ACCEPTED url=' . $return_url . ' | platform=' . $platform . ' | variant=' . $variant . ' | file_type=' . $file_type . ' | is_primary=' . (!empty($link['is_primary']) ? 'yes' : 'no') . ' | software=' . $software_name );
		}
		return array(
			'platform'         => $platform,
			'variant'          => $variant,
			'file_type'        => $file_type,
			'version'          => $version,
			'channel'          => $channel,
			'text'             => $text,
			'url'              => $return_url,
			'is_primary'       => ! empty( $link['is_primary'] ),
			'_portal_fallback' => ! empty( $link['_portal_fallback'] ),
		);
	}


	/**
	 * Validate a link record (alias for normalize_link for validator usage).
	 *
	 * @since 2.27.0
	 * @MODIFIED 2026-04-22: Signature updated to match normalize_link's $homepage parameter.
	 * @MODIFIED 2026-05-23: Propagated $software_name.
	 */
	public static function validate_link_record( array $link, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		return self::normalize_link( $link, $fallback_platform, $homepage, $software_name, $changelogurl );
	}

	/**
	 * Check if an array has at least one valid download link.
	 *
	 * @since 2.27.0
	 */
	public static function has_valid_download( $links ) {
		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) ) {
				continue;
			}
			$url = isset( $link['url'] ) ? $link['url'] : '';
			if ( self::is_valid_download_url( $url ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Find the primary or first valid download URL from an array of links.
	 *
	 * @since 2.27.0
	 */
	public static function find_primary_download_url( $links ) {
		$fallback = '';
		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$url = trim( (string) $link['url'] );
			if ( ! self::is_valid_download_url( $url ) ) {
				continue;
			}
			if ( ! empty( $link['is_primary'] ) ) {
				return $url;
			}
			if ( $fallback === '' ) {
				$fallback = $url;
			}
		}
		return $fallback;
	}

/**
     * Validate that URL architecture matches variant architecture.
     * Prevents ARM64 URLs labeled as x64/x32 (or vice versa) from being published.
     *
     * @since 2.38.0
     * @param array $link Normalized link data.
     * @return bool True if architecture matches, false if mismatch.
     */
    private static function validate_architecture_match(array $link): bool
    {
        $url = strtolower($link['url'] ?? '');
        $variant = strtolower($link['variant'] ?? '');

        // ARM64 URL with x64/x32 variant = MISMATCH
        if ((strpos($url, 'arm64') !== false || strpos($url, 'aarch64') !== false)
            && in_array($variant, ['x64', 'x32', 'x86', 'amd64'], true)) {
            if (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) {
                error_log('[DownloadLinkHelper] ARCHITECTURE MISMATCH: ARM64 URL with x64/x32 variant | url=' . $link['url'] . ' | variant=' . $link['variant']);
            }
            return false;
        }

        // x64/amd64 URL with ARM64 variant = MISMATCH
        if ((strpos($url, 'x64') !== false || strpos($url, 'amd64') !== false)
            && in_array($variant, ['arm64', 'aarch64'], true)) {
            if (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) {
                error_log('[DownloadLinkHelper] ARCHITECTURE MISMATCH: x64 URL with ARM64 variant | url=' . $link['url'] . ' | variant=' . $link['variant']);
            }
            return false;
        }

        return true;
    }

    /**
     * Normalize an array of download links.
	 * Rejects invalid/placeholder URLs, deduplicates, and ensures exactly one primary.
	 *
	 * @MODIFIED 2026-03-09: Enforces canonical platform names on fallback
	 * @MODIFIED 2026-04-22: Added $homepage parameter — propagated to normalize_link()
	 * to reject homepage-as-download AI hallucinations at source.
	 * @MODIFIED 2026-05-23: Added $software_name parameter.
	 *
	 * @param array  $links            Raw links array
	 * @param string $fallback_platform Platform to use if none can be detected
	 * @param string $homepage         Software homepage URL. Links matching it are dropped.
	 * @param string $software_name    Software name.
	 * @param string $changelogurl     Changelog URL. Links matching it are dropped.
	 * @return array Normalized, deduplicated, validated links
	 */
	public static function normalize_links( $links, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		$fallback_platform = self::normalize_platform_name( $fallback_platform );
		$clean             = array();
		$seen              = array();
		$dropped_reasons  = array();

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_links: BATCH START input=' . count( (array) $links ) . ' | homepage=' . $homepage . ' | software=' . $software_name );
			foreach ( (array) $links as $_idx => $_link ) {
				$_url = is_array( $_link ) ? ( $_link['url'] ?? '' ) : (string) $_link;
				error_log( '[DownloadLinkHelper] normalize_links:   INPUT[' . $_idx . '] url=' . $_url );
			}
		}

		foreach ( (array) $links as $link ) {
			$input_url = is_array( $link ) ? ( $link['url'] ?? '' ) : (string) $link;
			$normalized = self::normalize_link( $link, $fallback_platform, $homepage, $software_name, $changelogurl );
			if ( ! $normalized ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					$dropped_reasons[] = $input_url ?: '(empty)';
					error_log( '[DownloadLinkHelper] normalize_links:   DROPPED url=' . $input_url . ' | reason=normalize_link_returned_null');
				}
				continue;
			}

			$key = strtolower( $normalized['url'] );
			if ( isset( $seen[ $key ] ) ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					$dropped_reasons[] = $normalized['url'] . ' (duplicate)';
					error_log( '[DownloadLinkHelper] normalize_links:   DROPPED url=' . $input_url . ' | reason=duplicate (key=' . $key . ')');
				}
				continue;
			}

			// [ISSUE-2 FIX] Validate architecture consistency between URL and variant.
			// Prevents ARM64 URLs labeled as x64/x32 from being published.
			if (!self::validate_architecture_match($normalized)) {
				if (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) {
					$dropped_reasons[] = $normalized['url'] . ' (architecture mismatch)';
					error_log('[DownloadLinkHelper] normalize_links:   DROPPED url=' . $input_url . ' | reason=architecture_mismatch');
				}
				continue;
			}

			$clean[]      = $normalized;
			$seen[ $key ] = true;
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] normalize_links:   ACCEPTED url=' . $normalized['url'] . ' | platform=' . ( $normalized['platform'] ?? '' ) . ' | variant=' . ( $normalized['variant'] ?? '' ) );
			}
		}

		// Log homepage-collision rejections if any links were dropped.
		if ( ! empty( $homepage ) ) {
			$dropped = count( (array) $links ) - count( $clean );
			if ( $dropped > 0 ) {
				error_log(
					sprintf(
						'[DownloadLinkHelper] Homepage collision guard dropped %d link(s). Homepage: %s',
						$dropped,
						$homepage
					)
				);
			}
		}

		// DIAGNOSTIC: Log batch summary
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			$total_in  = count( (array) $links );
			$total_out = count( $clean );
			error_log( sprintf(
				'[DownloadLinkHelper] normalize_links: input=%d | output=%d | dropped=%d | software=%s',
				$total_in, $total_out, $total_in - $total_out, $software_name
			) );
			if ( ! empty( $dropped_reasons ) ) {
				error_log( '[DownloadLinkHelper] DROPPED URLS: ' . implode( ' | ', $dropped_reasons ) );
			}
		}

		if ( ! empty( $clean ) ) {
			// @MODIFIED 2026-05-02: GAP 6 — Pass smart_windows_default=true for consistent primary selection.
			$clean = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_single_primary( $clean, true );
		}
		return array_values( $clean );
	}

	/**
	 * Get the primary link from a normalized links array.
	 *
	 * @MODIFIED 2026-03-08: Added for consistent primary link retrieval
	 *
	 * @param array $links Normalized links array
	 * @return array|null Primary link or null
	 */
	public static function get_primary_link( $links ) {
		foreach ( (array) $links as $link ) {
			if ( ! empty( $link['is_primary'] ) ) {
				return $link;
			}
		}

		return ! empty( $links[0] ) ? $links[0] : null;
	}

	/**
	 * Group download links by platform.
	 * Preserves first-seen platform order instead of forcing a hardcoded order.
	 *
	 * @MODIFIED 2026-03-08: Cleaned up dead commented-out ordering code
	 *
	 * @param array $links Array of download link data
	 * @return array Grouped links: platform => array of links
	 */
	public static function group_links_by_platform( $links ) {
		$grouped        = array();
		$platform_order = array();

		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) ) {
				continue;
			}

			$url      = isset( $link['url'] ) ? (string) $link['url'] : '';
			$platform = isset( $link['platform'] ) ? self::normalize_platform_name( $link['platform'], $url ) : 'Other';

			if ( ! isset( $grouped[ $platform ] ) ) {
				$grouped[ $platform ] = array();
				$platform_order[]     = $platform;
			}

			$grouped[ $platform ][] = $link;
		}

		$ordered = array();

		foreach ( $platform_order as $platform ) {
			$ordered[ $platform ] = self::sort_links_by_variant( $grouped[ $platform ] );
		}

		$priority = array(
			'Windows' => 0,
			'macOS'   => 1,
			'Linux'   => 2,
			'Android' => 3,
			'iOS'     => 4,
		);

		uksort(
			$ordered,
			function ( $a, $b ) use ( $priority ) {
				$p_a = isset( $priority[ $a ] ) ? $priority[ $a ] : 999;
				$p_b = isset( $priority[ $b ] ) ? $priority[ $b ] : 999;

				if ( $p_a !== $p_b ) {
					return $p_a - $p_b;
				}

				return strcasecmp( $a, $b );
			}
		);

		return $ordered;
	}

	/**
	 * Sort links by variant priority.
	 * Primary links first, then x64, x86, ARM64, ARM, Universal, Intel, Portable, Standard.
	 *
	 * @MODIFIED 2026-03-08: Added is_primary first-sort, expanded variant priority map
	 *
	 * @param array $platform_links Links for a specific platform
	 * @return array Sorted links
	 */
	public static function sort_links_by_variant( $platform_links ) {
		usort(
			$platform_links,
			function ( $a, $b ) {
				// @MODIFIED 2026-03-08: Primary links always sort first
				$primary_a = ! empty( $a['is_primary'] ) ? 0 : 1;
				$primary_b = ! empty( $b['is_primary'] ) ? 0 : 1;

				if ( $primary_a !== $primary_b ) {
					return $primary_a - $primary_b;
				}

				$v1 = isset( $a['variant'] ) ? self::normalize_variant_name( $a['variant'] ) : 'Standard';
				$v2 = isset( $b['variant'] ) ? self::normalize_variant_name( $b['variant'] ) : 'Standard';

				$priority = array(
					'x64'            => 0,
					'x32'            => 1,
					'ARM64'          => 2,
					'ARM'            => 3,
					'Universal'      => 4,
					'Intel'          => 5,
					'Portable'       => 6,
					'Standard'       => 7,
					'ESR'            => 8,
					'LTS'            => 9,
					'Enterprise'     => 10,
					'Pro'            => 11,
					'Professional'   => 12,
					'Premium'        => 13,
					'Ultimate'       => 14,
					'Platinum'       => 15,
					'Plus'           => 16,
					'Max'            => 17,
					'Suite'          => 18,
					'Community'      => 19,
					'Lite'           => 20,
					'Basic'          => 21,
					'Free'           => 22,
					'Mini'           => 23,
					'Home'           => 24,
					'Express'        => 25,
					'Beta'           => 30,
					'RC'             => 31,
					'Preview'        => 32,
					'Alpha'          => 33,
					'Canary'         => 34,
					'Nightly'        => 35,
					'Dev'            => 36,
					'Stable'         => 37,
					'Trial'          => 40,
					'Plus Trial'     => 41,
					'Premium Trial'  => 42,
					'Platinum Trial' => 43,
					'Server'         => 44,
					'Workstation'    => 45,
					'2Go'            => 46,
					'Offline'        => 47,
					'Debug'          => 48,
					'DCH'            => 49,
					'DC'             => 50,
					'Minimalist'     => 51,
					'Installer'      => 52,
					'WHQL'           => 53,
					'Quadro'         => 54,
				);
				$p1       = isset( $priority[ $v1 ] ) ? $priority[ $v1 ] : 99;
				$p2       = isset( $priority[ $v2 ] ) ? $priority[ $v2 ] : 99;

				// @MODIFIED 2026-05-02: For composed variants not in the priority map
				// (e.g. "x64 Portable", "ARM64 ESR"), derive priority from the architecture prefix
				// so "x64 Portable" sorts with x64 (0), not at the bottom (99).
				if ( $p1 === 99 && preg_match( '/^(x64|x86|ARM64|ARM|Intel|Universal)\s+/i', $v1, $pm1 ) ) {
					$pk1 = strtolower( $pm1[1] );
					$pk1 = ( $pk1 === 'arm64' ) ? 'ARM64' : $pk1;
					$pk1 = ( $pk1 === 'arm' ) ? 'ARM' : $pk1;
					$p1  = isset( $priority[ $pk1 ] ) ? $priority[ $pk1 ] : 99;
				}
				if ( $p2 === 99 && preg_match( '/^(x64|x86|ARM64|ARM|Intel|Universal)\s+/i', $v2, $pm2 ) ) {
					$pk2 = strtolower( $pm2[1] );
					$pk2 = ( $pk2 === 'arm64' ) ? 'ARM64' : $pk2;
					$pk2 = ( $pk2 === 'arm' ) ? 'ARM' : $pk2;
					$p2  = isset( $priority[ $pk2 ] ) ? $priority[ $pk2 ] : 99;
				}
				if ( $p1 === $p2 ) {
					return strcasecmp( $v1, $v2 );
				}

				return $p1 - $p2;
			}
		);

		return $platform_links;
	}

	/**
	 * Format download link text
	 *
	 * @MODIFIED 2026-04-24: Added $existing_text parameter for update preservation.
	 * When non-empty, returns it as-is instead of regenerating deterministic text.
	 * This preserves user-customized anchor text during version updates where only the URL changes.
	 *
	 * @param array  $link          Link data with platform and variant
	 * @param string $software_name Software name
	 * @param string $existing_text Previously stored text to preserve (optional)
	 * @return string Formatted download text
	 */
	public static function format_download_text( $link, $software_name, $existing_text = '' ) {
		$existing_text = trim( (string) $existing_text );
		$sn            = trim( wp_strip_all_tags( (string) $software_name ) );

		// --- Extract structured fields from link (always authoritative) ---
		$variant_from_field = isset( $link['variant'] ) ? self::normalize_variant_name( $link['variant'] ) : 'Standard';
		$url                = isset( $link['url'] ) ? (string) $link['url'] : '';
		$platform_from_field = isset( $link['platform'] ) ? self::normalize_platform_name( $link['platform'], $url ) : '';
		$file_type_from_field = isset( $link['file_type'] ) ? trim( (string) $link['file_type'] ) : '';

		// --- Determine best variant: structured field is primary, source text is fallback ---
		$best_variant = $variant_from_field;
		$is_structured_generic = in_array( strtolower( $best_variant ), array( '', 'standard', 'default', 'main' ), true );

		if ( $existing_text !== '' ) {
			// Check if existing text is already in "Download ..." format → preserve
			if ( preg_match( '/^download\b/i', $existing_text ) ) {
				$text = $existing_text;
				$text = preg_replace( '/\bDOWNLOADS?\b/', 'Download', $text );
				$text = preg_replace( '/^downloads?\b/i', 'Download', $text );
				$text = preg_replace_callback( '/\b[A-Z]{2,}\b/u', function( $m ) {
					return ucfirst( strtolower( $m[0] ) );
				}, $text );
				return trim( $text );
			}

			// Raw source text — parse it for variant tokens to fill gaps in structured data.
			// Source like "PicView ARM64", "Portable", "Portable 64-bit" carries variant
			// intelligence that the structured fields may lack.
			if ( $is_structured_generic ) {
				$text_variant = self::extract_variant_from_anchor_text( $existing_text, $sn, $platform_from_field );
				if ( $text_variant !== '' && strtolower( $text_variant ) !== 'standard' ) {
					$best_variant = $text_variant;
				}
			}
			// Fall through — rebuild proper format from structured fields below.
		} else {
			// No existing text — use link's own text field as secondary data source
			$link_text = isset( $link['text'] ) ? trim( wp_strip_all_tags( (string) $link['text'] ) ) : '';

			if ( $link_text !== '' && $is_structured_generic ) {
				$text_variant = self::extract_variant_from_anchor_text( $link_text, $sn, $platform_from_field );
				if ( $text_variant !== '' && strtolower( $text_variant ) !== 'standard' ) {
					$best_variant = $text_variant;
				}
			}
		}

		// --- Build base text from structured fields ---
		if ( $file_type_from_field === 'store' ) {
			if ( strcasecmp( $platform_from_field, 'Android' ) === 0 ) {
				$text = 'Download ' . $sn . ' from Google Play Store';
				return trim( $text );
			} elseif ( strcasecmp( $platform_from_field, 'iOS' ) === 0 ) {
				$text = 'Download ' . $sn . ' from Apple Store';
				return trim( $text );
			}
		}

		$text = 'Download ' . ( $sn !== '' ? $sn : 'the software' );
		if ( $platform_from_field !== '' ) {
			$text .= ' for ' . $platform_from_field;
		}

		// --- Append variant suffix ---
		$use_variant = '';
		if ( $best_variant !== '' && strcasecmp( $best_variant, 'Standard' ) !== 0 ) {
			$use_variant = self::deduplicate_variant_against_text( $best_variant, $text );
		}

		if ( $use_variant !== '' ) {
			$text .= ' - ' . $use_variant;
		} elseif ( $file_type_from_field !== '' ) {
			$platform_defaults = array(
				'Windows' => array( 'exe', 'msi' ),
				'Android' => array( 'apk', 'store' ),
				'iOS'     => array( 'store' ),
			);
			$is_default = false;
			if ( isset( $platform_defaults[ $platform_from_field ] ) ) {
				$is_default = in_array( strtolower( $file_type_from_field ), $platform_defaults[ $platform_from_field ], true );
			}
			if ( ! $is_default ) {
				$text .= ' (' . ucfirst( strtolower( $file_type_from_field ) ) . ')';
			}
		}

		$text = preg_replace_callback( '/\b[A-Z]{2,}\b/u', function( $m ) {
			return ucfirst( strtolower( $m[0] ) );
		}, $text );

		return trim( $text );
	}

	/**
	 * Remove variant tokens that are already present in source text.
	 * "Lite ARM" + text containing "Lite" → "ARM"
	 * "Platinum x64" + text without "Platinum" → "Platinum x64"
	 */
	private static function deduplicate_variant_against_text( $variant, $text, $software_name = '' ) {
		$tokens     = array_unique( array_filter( array_map( 'trim', preg_split( '/[\s,\/]+/', $variant ) ) ) );
		
		// If there is a " - " separator, only deduplicate against the suffix after the last " - "
		$last_dash = strrpos( $text, ' - ' );
		if ( $last_dash !== false ) {
			$searchable_text = substr( $text, $last_dash + 3 );
		} else {
			// Otherwise, strip the software name to avoid matching tokens within the software name
			$searchable_text = $text;
			if ( $software_name !== '' ) {
				$escaped_name = preg_quote( $software_name, '/' );
				$searchable_text = preg_replace( '/' . $escaped_name . '/i', '', $searchable_text );
			}
		}

		$text_lower = strtolower( $searchable_text );
		$result     = array();
		foreach ( $tokens as $t ) {
			$t = trim( $t );
			if ( $t === '' ) {
				continue;
			}
			if ( strpos( $text_lower, strtolower( $t ) ) === false ) {
				$result[] = $t;
			}
		}
		if ( empty( $result ) ) {
			return '';
		}
		return self::normalize_variant_name( implode( ' ', $result ) );
	}
	/**
	 * Extract variant/edition words from source anchor text.
	 * Used to recover edition info (Plus Trial, Premium, Suite, etc.) when variant field is empty.
	 *
	 * @param string $text Source anchor text
	 * @param string $software_name Software name to remove
	 * @param string $platform Platform to remove
	 * @return string Extracted variant
	 */
	private static function extract_variant_from_anchor_text( $text, $software_name = '', $platform = '' ) {
		$label = wp_strip_all_tags( (string) $text );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label );
		// @MODIFIED 2026-05-22: Decode HTML entities so &amp; matches & in software_name.
		// Entity-encoded anchor text (e.g. "R-Wipe &amp; Clean 20.0") would not have its
		// software name stripped because raw "&" ≠ "&amp;", leaving fragments to become
		// garbage variants via ucwords() fallback.
		$label = html_entity_decode( $label, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label );

		if ( $label === '' ) {
			return '';
		}

		// Remove software name (decode entities in both sides for reliable matching)
		if ( $software_name !== '' ) {
			$sn = html_entity_decode( $software_name, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			$sn = preg_replace( '/\s+/u', ' ', $sn );
			$sn = trim( $sn );
			if ( $sn !== '' ) {
				$label = preg_replace( '/' . preg_quote( $sn, '/' ) . '/iu', '', $label );
			}
		}

		// Remove platform (decode entities for consistency)
		if ( $platform !== '' ) {
			$pf = html_entity_decode( $platform, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			$pf = preg_replace( '/\s+/u', ' ', $pf );
			$pf = trim( $pf );
			if ( $pf !== '' ) {
				$label = preg_replace( '/' . preg_quote( $pf, '/' ) . '/iu', '', $label );
			}
		}

		// Remove common words
		$label = preg_replace( '/\bdownloads?\b/iu', '', $label );
		$label = preg_replace( '/\bfor\b/iu', '', $label );
		// @MODIFIED 2026-05-04: Strip "edition" noise word — AI link text often appends
		// "Edition" after the variant token (e.g. "Business Edition", "Free Edition").
		// Without this, normalize_variant_label receives "Business Edition" which tokenizes
		// to ["Business", "Edition"] producing "Business Edition" instead of "Business".
		$label = preg_replace( '/\bedition\b/iu', '', $label );
		// @MODIFIED 2026-05-21: Strip version-number-like tokens (e.g. "7.8", "2026", "b8985")
		// that leak into variant labels from anchor text such as "Download Tails 7.8" or
		// "VirtualDJ 2026 b8985". Prevents corruption like "Tails 7.8" or "2026 b8985".
		$label = preg_replace( '/\s*\d+\.\d+(?:\.\d+)*\s*/u', ' ', $label );
		$label = preg_replace( '/\s*\d{4}\s*/u', ' ', $label );
		$label = preg_replace( '/\s*b\d{4,6}\s*/iu', ' ', $label );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label, " \t\n\r\0\x0B-–—" );

		return self::normalize_variant_label( $label );
	}

	/**
	 * Public wrapper for extract_variant_from_anchor_text.
	 * Allows external callers (Article_Generator, Discovery_Processor) to extract
	 * variant tokens from anchor text without duplicating the regex logic.
	 *
	 * @since 2.30.0
	 * @param string $text Source anchor text
	 * @param string $software_name Software name to strip from text (optional)
	 * @param string $platform Platform name to strip from text (optional)
	 * @return string Extracted and normalized variant
	 */
	public static function extract_variant_from_anchor_text_public( $text, $software_name = '', $platform = '' ) {
		return self::extract_variant_from_anchor_text( $text, $software_name, $platform );
	}
	/**
	 * Normalize variant label to canonical form.
	 *
	 * @param string $variant Raw variant text
	 * @return string Normalized variant
	 */
	private static function normalize_variant_label( $variant ) {
		$variant = wp_strip_all_tags( (string) $variant );
		$variant = preg_replace( '/\s+/u', ' ', $variant );
		$variant = trim( (string) $variant );

		if ( $variant === '' ) {
			return '';
		}

		// Canonical variant mapping
		$map    = array(
			'plus trial'       => 'Plus Trial',
			'premium trial'    => 'Premium Trial',
			'platinum trial'   => 'Platinum Trial',
			'portable version' => 'Portable',
			'portable edition' => 'Portable',
			'64-bit'           => 'x64',
			'64 bit'           => 'x64',
			'64bit'            => 'x64',
			'64_bit'           => 'x64',
			'amd64'            => 'x64',
			'x86_64'           => 'x64',
			'win64'            => 'x64',
			'x64'              => 'x64',
			'32-bit'           => 'x32',
			'32 bit'           => 'x32',
			'32bit'            => 'x32',
			'32_bit'           => 'x32',
			'win32'            => 'x32',
			'x86'              => 'x32',
			'aarch64'          => 'ARM64',
			'arm64'            => 'ARM64',
			'arm'              => 'ARM',
			'portable'         => 'Portable',
			'intel'            => 'Intel',
			'mac'              => 'Intel',
			'universal'        => 'Universal',
			'standard'         => 'Standard',
			'suite'            => 'Suite',
			'esr'              => 'ESR',
			'lts'              => 'LTS',
			'pro'              => 'Pro',
			'lite'             => 'Lite',
			'community'        => 'Community',
			'enterprise'       => 'Enterprise',
			'premium'          => 'Premium',
			'ultimate'         => 'Ultimate',
			'professional'     => 'Professional',
			'basic'            => 'Basic',
			'free'             => 'Free',
			'plus'             => 'Plus',
			'max'              => 'Max',
			'mini'             => 'Mini',
			'home'             => 'Home',
			'express'          => 'Express',
			'beta'             => 'Beta',
			'alpha'            => 'Alpha',
			'rc'               => 'RC',
			'preview'          => 'Preview',
			'canary'           => 'Canary',
			'nightly'          => 'Nightly',
			'dev'              => 'Dev',
			'stable'           => 'Stable',
			'platinum'         => 'Platinum',
			'trial'            => 'Trial',
			'server'           => 'Server',
			'workstation'      => 'Workstation',
			'2go'              => '2Go',
			'offline'          => 'Offline',
			'online'           => 'Online',
			'debug'            => 'Debug',
			'dch'              => 'DCH',
			'dc'               => 'DC',
			'minimalist'       => 'Minimalist',
			'installer'        => 'Installer',
			'setup'            => 'Setup',
			'whql'             => 'WHQL',
			'quadro'           => 'Quadro',
			'business'         => 'Business',
			'education'        => 'Education',
			'educational'      => 'Education',
			'academic'         => 'Academic',
			'home student'     => 'Home Student',
			'student'          => 'Student',
			'personal'         => 'Personal',
			'starter'          => 'Starter',
			'basic edition'    => 'Basic',
			'free edition'     => 'Free',
			'home edition'     => 'Home',
			'edition'          => 'Edition',
			'version'          => 'Version',
			'build'            => 'Build',
		);
		$lookup = strtolower( $variant );
		if ( isset( $map[ $lookup ] ) ) {
			return $map[ $lookup ];
		}

		$arch_canonical = array(
			'x64'       => 'x64',
			'x32'       => 'x32',
			'arm64'     => 'ARM64',
			'arm'       => 'ARM',
			'intel'     => 'Intel',
			'universal' => 'Universal',
			'mac'       => 'Intel',
		);
		$arch_lower     = strtolower( $variant );
		if ( isset( $arch_canonical[ $arch_lower ] ) ) {
			return $arch_canonical[ $arch_lower ];
		}

		if ( strpos( $lookup, 'apple silicon' ) !== false || preg_match( '/\bm[1-4]\b/i', $variant ) ) {
			return 'ARM64';
		}

		$tokens = preg_split( '/[\s,\/]+/', $lookup );
		if ( count( $tokens ) > 1 ) {
			$normalized_tokens = array();
			$seen_canonical    = array();
			foreach ( $tokens as $t ) {
				$t = trim( $t );
				if ( $t === '' ) {
					continue;
				}
				$t_clean = preg_replace( '/[^a-z0-9]/i', '', $t );
				if ( $t_clean === '' ) {
					continue;
				}
				if ( isset( $map[ $t ] ) ) {
					$canonical = $map[ $t ];
				} elseif ( isset( $map[ $t_clean ] ) ) {
					$canonical = $map[ $t_clean ];
				} elseif ( isset( $arch_canonical[ $t_clean ] ) ) {
					$canonical = $arch_canonical[ $t_clean ];
				} else {
					return 'Standard';
				}
				$seen_key = strtolower( $canonical );
				if ( isset( $seen_canonical[ $seen_key ] ) ) {
					continue;
				}
				$seen_canonical[ $seen_key ] = true;
				$normalized_tokens[]         = $canonical;
			}
			$arch_groups = array(
				array( 'x64', 'x32' ),
				array( 'ARM64', 'ARM' ),
			);
			foreach ( $arch_groups as $group ) {
				$found = array();
				foreach ( $group as $arch ) {
					$pos = array_search( $arch, $normalized_tokens, true );
					if ( $pos !== false ) {
						$found[ $pos ] = $arch;
					}
				}
				if ( count( $found ) > 1 ) {
					if ( $group[0] === 'x64' && $group[1] === 'x32' ) {
						foreach ( $found as $pos => $arch ) {
							unset( $normalized_tokens[ $pos ] );
						}
						$normalized_tokens = array_values( $normalized_tokens );
						if ( empty( $normalized_tokens ) ) {
							return 'Standard';
						}
					} else {
						ksort( $found );
						$keep = reset( $found );
						foreach ( $found as $pos => $arch ) {
							if ( $arch !== $keep ) {
								unset( $normalized_tokens[ $pos ] );
							}
						}
						$normalized_tokens = array_values( $normalized_tokens );
					}
				}
			}
			$joined = implode( ' ', $normalized_tokens );
			if ( $joined !== '' ) {
				return $joined;
			}
		}

		return 'Standard';
	}
	/**
	 * Extract version, architecture, and edition information from a URL.
	 *
	 * Scans path, query, and fragment for:
	 * 1. Architecture tokens (win64, amd64, arm64, intel, apple, etc.)
	 * 2. Edition/channel keywords (pro, community, esr, lts, portable, etc.)
	 * 3. Version numbers
	 *
	 * @MODIFIED 2026-03-05: Added for distinguishable download links
	 * @MODIFIED 2026-04-23: Enhanced with architecture detection and expanded edition keywords.
	 *   Architecture tokens are extracted from URL boundaries (delimited by _ - . /)
	 *   to prevent false positives from substring matches inside words.
	 *
	 * @param string $url The download URL
	 * @return string Extracted version/arch/edition string or empty
	 */
	public static function extract_version_from_url( $url, $link_text = '', $software_name = '' ) {
		if ( empty( $url ) && empty( $link_text ) ) {
			return '';
		}

		$parts           = parse_url( $url );
		$searchable_text = ( $parts['path'] ?? '' ) . ' ' . ( $parts['query'] ?? '' ) . ' ' . ( $parts['fragment'] ?? '' );

		if ( ! empty( $link_text ) ) {
			$searchable_text .= ' ' . trim( (string) $link_text );
		}

		if ( empty( trim( $searchable_text ) ) ) {
			return '';
		}

		// Strip software name case-insensitively to avoid matching parts of the software name as edition/variant keywords (Finding #2)
		if ( ! empty( $software_name ) ) {
			$escaped_software_name = preg_quote( $software_name, '/' );
			$searchable_text = preg_replace( '/\b' . $escaped_software_name . '\b/i', '', $searchable_text );
			$searchable_text = preg_replace( '/' . $escaped_software_name . '/i', '', $searchable_text );
		}

		$filename       = basename( str_replace( '+', ' ', $parts['path'] ?? '' ) );
		$filename_lower = strtolower( $filename );
		$host_lower     = strtolower( $parts['host'] ?? '' );

		// 1. Architecture tokens — highest priority for link differentiation.
		// Delimiter-bounded matching prevents false positives inside words.
		$arch_map = array(
			'apple silicon' => 'ARM64',
			'aarch64'       => 'ARM64',
			'arm64'         => 'ARM64',
			'universal'     => 'Universal',
			'mac'           => 'Intel', // Firefox-style .mac.pkg = Intel macOS
			'amd64'         => 'x64',
			'x86_64'        => 'x64',
			'x64'           => 'x64',
			'win64'         => 'x64',
			'64bit'         => 'x64',
			'64-bit'        => 'x64',
			'64_bit'        => 'x64',
			'x86'           => 'x32',
			'i686'          => 'x32',
			'i386'          => 'x32',
			'win32'         => 'x32',
			'32bit'         => 'x32',
			'32-bit'        => 'x32',
			'32_bit'        => 'x32',
		);

		$found_arch = '';
		foreach ( $arch_map as $token => $canonical ) {
			$pattern = '/(?:^|[_\-\.\/])' . preg_quote( $token, '/' ) . '(?:$|[_\-\.\/])/i';
			if ( preg_match( $pattern, $searchable_text ) ) {
				$found_arch = $canonical;
				break;
			}
		}

		// Apple/Intel/Universal/ARM/Portable/Installer — filename and host fallbacks
		if ( empty( $found_arch ) ) {
			if ( preg_match( '/[_\-\.]apple[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-](?:m[1-4])[_\-\.\/]/i', $searchable_text )
			) {
				$found_arch = 'ARM64';
			} elseif ( preg_match( '/[_\-\.]macarm64[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-\.]mac\.arm64[_\-\.\/]/i', $searchable_text )
			) {
				$found_arch = 'ARM64';
			} elseif ( preg_match( '/[_\-\.]intel[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-\.]intel(?:$|[_\-\.\/])/i', $searchable_text )
			) {
				$found_arch = 'Intel';
			} elseif ( preg_match( '/[_\-\.]universal[_\-\.\/]/i', $searchable_text ) ) {
				$found_arch = 'Universal';
			} elseif ( preg_match( '/[_\-\.]portable[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'portable' ) !== false
				|| strpos( $host_lower, 'portableapps.com' ) !== false
			) {
				$found_arch = 'Portable';
			} elseif ( preg_match( '/[_\-\.]installer[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'installer' ) !== false
			) {
				$found_arch = 'Installer';
			} elseif ( preg_match( '/[_\-\.]whql[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'whql' ) !== false
			) {
				$found_arch = 'WHQL';
			} elseif ( preg_match( '/[_\-\.]arm[_\-\.\/]/i', $searchable_text ) ) {
				$found_arch = 'ARM';
			}
		}

		// 2. Edition/channel keywords — pro, community, esr, lts, etc.
		$edition_keywords = array(
			'esr',
			'lts',
			'leap',
			'tumbleweed',
			'pro',
			'lite',
			'ultimate',
			'premium',
			'community',
			'enterprise',
			'preview',
			'beta',
			'alpha',
			'rc',
			'canary',
			'nightly',
			'dev',
			'stable',
			'plus',
			'basic',
			'professional',
			'trial',
			'suite',
			'express',
			'max',
			'mini',
			'home',
			'free',
			'platinum',
			'server',
			'workstation',
			'2go',
			'offline',
			'debug',
			'dch',
			'dc',
			'minimalist',
			'quadro',
			'business',
			'education',
			'academic',
			'student',
			'personal',
			'starter',
		);
		$found_editions   = array();
		if ( preg_match( '/\d\.?\d*esr(?![a-z0-9])/i', $searchable_text ) ) {
			$found_editions[] = 'esr';
		}

		foreach ( $edition_keywords as $keyword ) {
			if ( $keyword === 'esr' && in_array( 'esr', $found_editions, true ) ) {
				continue;
			}
			if ( preg_match( '/(?:^|[^a-z0-9])' . preg_quote( $keyword, '/' ) . '(?![a-z0-9])/i', $searchable_text ) ) {
				$found_editions[] = $keyword;
			}
		}
		// 3. Version-like strings
		$version = '';
		if ( preg_match( '/(?:^|[^a-z0-9])(?:v|ver|version)?\s*(\d+\.\d+(?:\.\d+)*)\b/i', $searchable_text, $matches ) ) {
			$version = $matches[1];
		} elseif ( preg_match( '/(?:^|[^a-z0-9])(?:v|ver|version)?\s*(\d{4,})\b/i', $searchable_text, $matches ) ) {
			$version = $matches[1];
		}

		// Assemble: edition keywords → architecture → version
		$parts_out = array();
		if ( ! empty( $found_editions ) ) {
			foreach ( $found_editions as $ek ) {
				$parts_out[] = ucfirst( $ek );
			}
		}
		if ( ! empty( $found_arch ) ) {
			$parts_out[] = $found_arch;
		}
		if ( ! empty( $version ) ) {
			$parts_out[] = $version;
		}

		return trim( implode( ' ', $parts_out ) );

		return trim( implode( ' ', $parts_out ) );
	}

	/**
	 * Specifically detect hallucinated/fake YouTube URLs generated by AI.
	 *
	 * @since 2.27.0
	 * @param string $url URL to check
	 * @return bool True if fake YouTube URL
	 */
	public static function is_placeholder_youtube_url( string $url ): bool {
		if ( strpos( $url, 'youtube.com/watch' ) === false && strpos( $url, 'youtu.be/' ) === false ) {
			return false;
		}

		// Extract the v= parameter or the path segment
		$video_id = '';
		if ( preg_match( '/(?:v=|\/)([\w-]{11})(?:\&|$|\?)/', $url, $matches ) ) {
			$video_id = $matches[1];
		}

		if ( empty( $video_id ) ) {
			return false;
		}

		// Known LLM hallucination IDs
		$known_fakes = array(
			'11011111011',
			'00000000000',
			'11111111111',
			'12345678901',
			'abcdefghijk',
			'xxxxxxxxxxx',
			'dQw4w9WgXcQ', // Rickroll
		);

		if ( in_array( $video_id, $known_fakes, true ) ) {
			return true;
		}

		// Heuristic: If ID is entirely digits or entirely the same char
		if ( preg_match( '/^(\d)\1{10}$/', $video_id ) || preg_match( '/^([a-zA-Z])\1{10}$/', $video_id ) ) {
			return true;
		}

		// Heuristic: Binary strings '11011111011' etc
		if ( preg_match( '/^[01]{11}$/', $video_id ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Infer file_type from a download URL based on file extension or store domain.
	 * Single source of truth for file_type inference — used by normalize_link()
	 * and format_download_text() to avoid maintaining two separate mapping tables.
	 *
	 * @since 2.30.0
	 * @param string $url Download URL
	 * @return string Inferred file_type or empty string
	 */
	public static function infer_file_type_from_url( $url ) {
		if ( empty( $url ) || ! is_string( $url ) ) {
			return '';
		}

		static $file_type_map = array(
			'exe'      => 'exe',
			'msi'      => 'msi',
			'msix'     => 'msix',
			'msp'      => 'msp',
			'appx'     => 'appx',
			'dmg'      => 'dmg',
			'pkg'      => 'pkg',
			'apk'      => 'apk',
			'ipa'      => 'ipa',
			'deb'      => 'deb',
			'rpm'      => 'rpm',
			'appimage' => 'appimage',
			'zip'      => 'portable',
			'7z'       => 'portable',
			'tar.gz'   => 'archive',
			'tgz'      => 'archive',
			'tar.xz'   => 'archive',
			'tar.bz2'  => 'archive',
			'sh'       => 'shell',
			'run'      => 'shell',
			'bin'      => 'shell',
		);

		$url_path = (string) parse_url( $url, PHP_URL_PATH );
		if ( preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|apk|ipa|deb|rpm|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $url_path, $em ) ) {
			$ext = strtolower( $em[1] );
			if ( isset( $file_type_map[ $ext ] ) ) {
				return $file_type_map[ $ext ];
			}
			return $ext;
		}

		$url_host = strtolower( (string) parse_url( $url, PHP_URL_HOST ) );
		if ( strpos( $url_host, 'play.google.com' ) !== false || strpos( $url_host, 'apps.apple.com' ) !== false || strpos( $url_host, 'apps.microsoft.com' ) !== false || strpos( $url_host, 'itunes.apple.com' ) !== false ) {
			return 'store';
		}

		return '';
	}

	private static function extract_variant_tokens_from_composite( $composite, $architecture_only = false ) {
		$composite = trim( (string) $composite );
		if ( $composite === '' ) {
			return '';
		}
		$tokens         = preg_split( '/\s+/', $composite );
		$non_version    = array();
		$seen           = array();
		$arch_canonical = array( 'x64', 'x32', 'ARM64', 'ARM', 'Intel', 'Universal' );
		foreach ( $tokens as $token ) {
			if ( preg_match( '/^\d/', $token ) ) {
				continue;
			}
			$normalized = self::normalize_variant_name( $token );
			if ( $architecture_only ) {
				if ( in_array( $normalized, $arch_canonical, true ) ) {
					$seen_key = strtolower( $normalized );
					if ( ! isset( $seen[ $seen_key ] ) ) {
						$seen[ $seen_key ] = true;
						$non_version[]     = $normalized;
					}
				}
			} else {
				$seen_key = strtolower( $normalized );
				if ( ! isset( $seen[ $seen_key ] ) ) {
					$seen[ $seen_key ] = true;
					$non_version[]     = $normalized;
				}
			}
		}
		return implode( ' ', $non_version );
	}
}
