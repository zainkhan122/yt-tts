<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
	exit;
}

class PromptEngine
{
	private AIProviderInterface $ai_provider;

	private Logger $logger;

	public function __construct(AIProviderInterface $ai_provider, Logger $logger)
	{
		$this->ai_provider = $ai_provider;
		$this->logger = $logger;
		$this->logger->info('PromptEngine initialized (provider: ' . $ai_provider->get_model() . ')');
	}

	public function generate(array $prompt_data, string $strategy = 'gemini'): array
	{
		$this->logger->info("Starting generation with strategy: {$strategy}");

		return $this->generate_direct($prompt_data);
	}

	private function generate_direct(array $prompt_data): array
	{
		$has_blueprint = !empty($prompt_data['structure_blueprint']);
		$this->logger->info('Using direct generation: ' . $this->ai_provider->get_model(), [
			'has_blueprint' => $has_blueprint,
			'search_intent' => $prompt_data['search_intent'] ?? 'mixed',
		]);

		$article = $this->ai_provider->generate($prompt_data);

		$provider_slug = $this->get_provider_slug();
		$article['_generation_method'] = $provider_slug . '_direct';

		$this->logger->info('Article generated via ' . $this->ai_provider->get_model() . ' direct');

		return $article;
	}

	public function get_ai_client(): AIProviderInterface
	{
		return $this->ai_provider;
	}

	private function get_provider_slug(): string
	{
		if (method_exists($this->ai_provider, 'get_provider_slug')) {
			$slug = $this->ai_provider->get_provider_slug();
			if ($slug !== '' && $slug !== 'unknown') {
				return $slug;
			}
		}

		$class = strtolower((string) get_class($this->ai_provider));

		if (strpos($class, 'gemini') !== false) {
			return 'gemini';
		}
		if (strpos($class, 'openrouter') !== false) {
			return 'openrouter';
		}
		if (strpos($class, 'groq') !== false) {
			return 'groq';
		}
		if (strpos($class, 'custom') !== false) {
			return 'custom';
		}

		return 'ai';
	}

	public function get_expected_method(): string
	{
		return $this->get_provider_slug() . '_direct';
	}
}
