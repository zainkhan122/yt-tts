<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * User Dashboard for MCQ Plugin
 * Progress tracking, statistics, achievements display
 *
 * MODIFICATIONS (v2.4):
 * - REMOVED the enqueue_dashboard_assets() method.
 * - All asset loading is now centralized in 39-template-loader.php.
 */

class NM_User_Dashboard {

	private static $instance = null;

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Register dashboard page
		add_action( 'init', array( $this, 'register_dashboard_page' ) );

		// Template redirect
		add_filter( 'template_include', array( $this, 'dashboard_template' ) );

		// Asset enqueueing is REMOVED from this file.
	}

	/**
	 * Register virtual dashboard page
	 */
	public function register_dashboard_page() {
		// Add rewrite rule for dashboard
		add_rewrite_rule(
			'^mcq-dashboard/?$',
			'index.php?nm_dashboard=1',
			'top'
		);

		add_rewrite_tag( '%nm_dashboard%', '1' );
	}

	/**
	 * Load dashboard template
	 */
	public function dashboard_template( $template ) {
		if ( get_query_var( 'nm_dashboard' ) ) {
			if ( ! is_user_logged_in() ) {
				wp_redirect( home_url( '/mcq-login/' ) );
				exit;
			}

			$dashboard_template = NM_PLUGIN_DIR . 'templates/dashboard.php';

			if ( file_exists( $dashboard_template ) ) {
				return $dashboard_template;
			}
		}

		return $template;
	}

	/**
	 * ❌ REMOVED: Enqueue dashboard assets
	 * This function is now empty as logic is in 39-template-loader.php
	 */
	public function enqueue_dashboard_assets() {
		// This function is intentionally left empty.
		// All logic has been moved to NM_Template_Loader::enqueue_assets()
	}
}
