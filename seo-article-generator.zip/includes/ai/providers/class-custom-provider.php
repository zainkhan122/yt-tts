<?php

namespace SEO_Article_Generator\AI\Providers;

use SEO_Article_Generator\AI_Exception;
use SEO_Article_Generator\AI\AI_Rate_Limit_Exception;
use SEO_Article_Generator\AI\API_Error_Parser;
use SEO_Article_Generator\AI\API_Error_Info;
use SEO_Article_Generator\AI\Quota_State_Manager;
use SEO_Article_Generator\AI\JSON_Recovery;
use SEO_Article_Generator\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Custom_Provider extends Abstract_Provider {

    const CHAT_ROUTE = '/chat/completions';

    private string $provider_slug;
    private array $provider_config;
    private string $current_model;
    private array $fallback_models = [];
    private bool $fallback_enabled = false;
    private string $api_url;

    private int $route_retries = 0;
    private int $token_retries = 0;
    private int $tool_retries = 0;
    private int $schema_retries = 0;

    private const MAX_SELF_CORRECTION_RETRIES = 3;

    private static array $MODEL_MAX_TOKENS = [
        'glm-4'           => 4096,
        'glm-5'           => 8192,
        'deepseek-chat'   => 8192,
        'deepseek-v3'     => 8192,
        'deepseek-v4'     => 8192,
        'deepseek-r1'     => 8192,
        'deepseek-reasoner'=> 8192,
        'qwen3-235b-a22b' => 8192,
        'qwen2.5-72b-instruct' => 8192,
        'minimax-m2'      => 8192,
    ];

    private static array $MODELS_NO_RESPONSE_FORMAT = [
        'moonshot-v1-8k',
        'moonshot-v1-32k',
        'moonshot-v1-128k',
        'MiniMax-Text-01',
        'minimax-text-01',
        'minimaxai/minimax-m2.7',
        'abab6.5s-chat',
        'abab7-chat-preview',
        'z-ai/glm-5.1:reasoning',
        'google/gemma-4-31b-it',
        'google/gemma-3-27b-it',
    ];

    public function __construct(string $api_key, Logger $logger, $ai_client, string $provider_slug, array $provider_config) {
        parent::__construct($api_key, $logger, $ai_client);
        $this->provider_slug = sanitize_key($provider_slug);
        $this->provider_config = $provider_config;
        $this->api_url = rtrim($provider_config['api_url'] ?? '', '/');

        $models = array_values((array)($provider_config['models'] ?? []));
        $ids = array_filter(array_map(function($m) {
            return (string)($m['model_id'] ?? '');
        }, $models));
        $fallback_model = $provider_config['_fallback_model'] ?? '';
        if ($fallback_model !== '' && in_array($fallback_model, $ids, true)) {
            // Start at the requested model, then rotate through ALL other configured
            // models (preserving saved order) — never drop earlier models.
            $this->current_model = (string) $fallback_model;
            $this->fallback_models = array_values(array_filter($ids, function($id) use ($fallback_model) {
                return $id !== $fallback_model;
            }));
        } elseif (!empty($ids)) {
            $this->current_model = $ids[0];
            $this->fallback_models = array_values(array_slice($ids, 1));
        } else {
            $this->current_model = 'unknown-model';
        }

        $this->fallback_enabled = !empty($provider_config['fallback_enabled']);
    }

    public function generate_article(array $prompt_data): array {
        $this->logger->info("Custom provider {$this->provider_slug}: starting article generation.", [
            'model'          => $this->current_model,
            'fallback_count' => count($this->fallback_models),
        ]);

        $system_prompt = \SEO_Article_Generator\Generator\Prompt_Builder::build_system_prompt(array(
            'enable_web_search' => !empty($this->provider_config['enable_web_search']),
            'focus_keyword'     => $prompt_data['focus_keyword'] ?? '',
        ));
        $user_prompt = $this->build_user_prompt($prompt_data);

        $messages = [
            ['role' => 'system', 'content' => $system_prompt],
            ['role' => 'user',   'content' => $user_prompt],
        ];

        return $this->chat_completion_retry_loop($messages, $prompt_data);
    }

    private function build_user_prompt(array $prompt_data): string {
        $prompt_builder = new \SEO_Article_Generator\Generator\Prompt_Builder();
        $context = $prompt_data['_generation_context'] ?? null;
        return $prompt_builder->build_full_instruction_set($prompt_data, $context);
    }

    private function hop_to_next_model(string $next_model, array &$tried_models): void
    {
        $this->current_model = $next_model;
        $tried_models[]       = $next_model;
        $this->route_retries   = 0;
        $this->token_retries   = 0;
        $this->tool_retries    = 0;
        $this->schema_retries  = 0;
    }

    private function chat_completion_retry_loop(array $messages, array $prompt_data): array {
        $max_attempts = 1 + ($this->fallback_enabled ? count($this->fallback_models) : 0);
        $remaining_fallbacks = $this->fallback_models;
        $tried_models = [$this->current_model];
        $attempt = 0;

        $enable_web_search = !empty($this->provider_config['enable_web_search']);
        $web_search_type = $this->provider_config['web_search_config']['type'] ?? 'none';
        $use_openrouter_native = !empty($this->provider_config['use_openrouter_native_search']);
        $is_openrouter_url = strpos($this->api_url, 'openrouter.ai') !== false
            || strpos($this->api_url, 'openrouterapi.ai') !== false;

        // Skip plugin web search if OpenRouter native search is enabled or if search type is set to openrouter_native
        // OpenRouter models handle search internally when enabled on their dashboard
        if (($use_openrouter_native && $is_openrouter_url) || $web_search_type === 'openrouter_native') {
            $active_web_search = false;
        } else {
            $active_web_search = $enable_web_search && $web_search_type !== 'none';
        }
        $active_web_search_type = $web_search_type;
        $use_json_schema = !empty($this->provider_config['supports_json_schema']);

        $url = $this->api_url . self::CHAT_ROUTE;

        while ($attempt < $max_attempts) {
            $attempt++;
            $model_max = $this->get_max_tokens_for_model($this->current_model);

            $body = [
                'model'       => $this->current_model,
                'messages'    => $messages,
                'stream'      => false,
                'temperature' => 0.2,
                'max_tokens'  => $model_max,
            ];

            $headers = [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ];
            if (strpos($url, 'openrouter.ai') !== false) {
                $headers['HTTP-Referer'] = get_site_url();
                $headers['X-Title']      = get_bloginfo('name');
            }

            if ($use_json_schema) {
                $body['response_format'] = [
                    'type'        => 'json_schema',
                    'json_schema' => [
                        'name'   => 'articleSchema',
                        'strict' => true,
                        'schema' => $this->get_structured_output_schema($prompt_data),
                    ]
                ];
            } elseif ($this->model_supports_response_format($this->current_model)) {
                $body['response_format'] = ['type' => 'json_object'];
            }

            if ($active_web_search) {
                $body['tools'] = $this->build_web_search_tool($active_web_search_type);
            }

            $body = apply_filters('seo_gen_custom_provider_request_body', $body, $this->provider_slug, $this->current_model);

            $this->last_raw_prompt = wp_json_encode($body, JSON_PRETTY_PRINT);

            $response = $this->ai_client->execute_safe_request($url, [
                'headers' => $headers,
                'body'    => wp_json_encode($body),
                'timeout' => 180, // Free-tier models (e.g. OpenRouter free) need up to 3 min for large prompts
            ], $this->provider_slug, $this->current_model);

            if (is_wp_error($response)) {
                $error_code = $response->get_error_code();
                $error_message = $response->get_error_message();
                $error_data = $response->get_error_data();

                if ($error_code === 'rate_limit' || $error_code === 'misconfigured') {
                    if (!is_array($error_data)) {
                        $error_data = [];
                    }
                    $error_info = isset($error_data['error_info']) && $error_data['error_info'] instanceof API_Error_Info
                        ? $error_data['error_info'] : null;

                    $decision = $error_info !== null ? $this->intra_provider_fallback_decision($error_info) : 'hop';

                    if ($decision === 'hop' && $this->fallback_enabled && !empty($remaining_fallbacks)) {
                        $next_model = array_shift($remaining_fallbacks);
                        $this->logger->warning("Custom provider {$this->provider_slug}: " . ($error_code === 'misconfigured' ? 'model not found' : 'rate limit') . ". Falling back from {$this->current_model} to {$next_model}.");
                        $this->hop_to_next_model($next_model, $tried_models);
                        continue;
                    }

                    if ($decision === 'delegate') {
                        throw new AI_Rate_Limit_Exception($error_message, 429, array_merge((array) $error_data, [
                            'provider'             => $this->provider_slug,
                            'model'                => $this->current_model,
                            'tried_models'         => $tried_models,
                            'all_models_exhausted' => true,
                        ]));
                    }

                    throw new AI_Exception("{$this->provider_slug} API error: " . $error_message, [
                        'provider'             => $this->provider_slug,
                        'model'                => $this->current_model,
                        'tried_models'         => $tried_models,
                        'all_models_exhausted' => true,
                    ]);
                }

                // [FALLBACK-FIX] Transport-layer WP_Errors that are NOT rate_limit/
                // misconfigured (e.g. cURL error 28 timeout, http_request_failed,
                // connection reset, DNS failure) previously threw AI_Exception at
                // line 227 immediately, abandoning all configured fallback models.
                // This mirrors the proven 5xx hop branch (lines 276-285) so a
                // single free-tier model hang can no longer kill the job while
                // fallback models remain untried. Log evidence 2026-07-23:
                // 4 cURL-28 timeouts on poolside/laguna-xs-2.1:free killed jobs
                // 5541/5545 despite fallback_count=13.
                if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("Custom provider {$this->provider_slug}: transport error ({$error_code}) on {$this->current_model}. Falling back to {$next_model}.");
                    $this->hop_to_next_model($next_model, $tried_models);
                    continue;
                }

                throw new AI_Exception("API request failed: " . $error_message, [
                    'provider'             => $this->provider_slug,
                    'model'                => $this->current_model,
                    'tried_models'         => $tried_models,
                    'all_models_exhausted' => true,
                ]);
            }

            $code = wp_remote_retrieve_response_code($response);
            $raw_body = wp_remote_retrieve_body($response);
            $this->last_raw_response = $raw_body;

            if ($code === 429 || $code === 403) {
                $resp_headers = wp_remote_retrieve_headers($response);
                $headers_array = is_array($resp_headers) ? $resp_headers : [];
                if ($resp_headers instanceof \Requests_Utility_CaseInsensitiveDictionary) {
                    $headers_array = $resp_headers->getAll();
                } elseif (!is_array($headers_array)) {
                    $headers_array = [];
                }
                $error_info = API_Error_Parser::parse($this->provider_slug, $code, $raw_body, $headers_array);
                Quota_State_Manager::calibrate_from_error($this->provider_slug, $this->current_model, $error_info);

                $decision = $this->intra_provider_fallback_decision($error_info);

                if ($decision === 'hop' && $this->fallback_enabled && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("Custom provider {$this->provider_slug}: quota/rate limit. Falling back from {$this->current_model} to {$next_model}.");
                    $this->hop_to_next_model($next_model, $tried_models);
                    continue;
                }

                if ($decision === 'delegate') {
                    throw new AI_Rate_Limit_Exception(
                        "{$this->provider_slug} daily quota/credits exhausted ({$code}).",
                        $code,
                        array(
                            'provider'             => $this->provider_slug,
                            'model'                => $this->current_model,
                            'tried_models'         => $tried_models,
                            'all_models_exhausted' => true,
                        )
                    );
                }

                throw new AI_Exception("{$this->provider_slug} API error ({$code}): " . substr($raw_body, 0, 200), [
                    'provider'             => $this->provider_slug,
                    'model'                => $this->current_model,
                    'tried_models'         => $tried_models,
                    'all_models_exhausted' => true,
                ]);
            }

            if ($code >= 500) {
                if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("Custom provider {$this->provider_slug}: server error {$code}. Falling back to {$next_model}.");
                    $this->hop_to_next_model($next_model, $tried_models);
                    continue;
                }
                throw new AI_Exception("{$this->provider_slug} returned Server Error {$code}");
            }

            if ($code === 400) {
                $err_msg = strtolower($raw_body);

                if (preg_match('#available on (/[vV]\d+/chat/completions)#i', $raw_body, $route_match)) {
                    $this->route_retries++;
                    if ($this->route_retries > self::MAX_SELF_CORRECTION_RETRIES) {
                        if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                            $next_model = array_shift($remaining_fallbacks);
                            $this->logger->warning("Custom provider {$this->provider_slug}: route redirect retries exhausted. Falling back to {$next_model}.");
                            $this->hop_to_next_model($next_model, $tried_models);
                            continue;
                        }
                        throw new AI_Exception("Custom provider {$this->provider_slug}: route redirect retries exhausted.");
                    }
                    $corrected_url = preg_replace('#/[vV]\d+/chat/completions$#', '', $this->api_url) . $route_match[1];
                    $this->logger->warning("Custom provider {$this->provider_slug}: redirecting to recommended route: " . $corrected_url);
                    $url = $corrected_url;
                    $attempt--;
                    continue;
                }

                $is_token_error = (strpos($err_msg, 'max_tokens') !== false || strpos($err_msg, 'exceeds the maximum') !== false);
                if ($is_token_error && $model_max > 512) {
                    $this->token_retries++;
                    if ($this->token_retries > self::MAX_SELF_CORRECTION_RETRIES) {
                        if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                            $next_model = array_shift($remaining_fallbacks);
                            $this->logger->warning("Custom provider {$this->provider_slug}: max_tokens retries exhausted. Falling back to {$next_model}.");
                            $this->hop_to_next_model($next_model, $tried_models);
                            continue;
                        }
                        throw new AI_Exception("Custom provider {$this->provider_slug}: max_tokens retries exhausted.");
                    }
                    $model_max = intval($model_max / 2);
                    $this->logger->warning("Custom provider {$this->provider_slug}: max tokens rejected. Retrying with halved limit: {$model_max}.");
                    $attempt--;
                    continue;
                }

                $is_tool_conflict = ($active_web_search && (
                    strpos($err_msg, 'tool') !== false
                    || strpos($err_msg, 'web_search') !== false
                    || strpos($err_msg, 'input should be') !== false
                ));
                if ($is_tool_conflict) {
                    $this->tool_retries++;
                    if ($this->tool_retries > self::MAX_SELF_CORRECTION_RETRIES) {
                        if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                            $next_model = array_shift($remaining_fallbacks);
                            $this->logger->warning("Custom provider {$this->provider_slug}: tool conflict retries exhausted. Falling back to {$next_model}.");
                            $this->hop_to_next_model($next_model, $tried_models);
                            continue;
                        }
                        throw new AI_Exception("Custom provider {$this->provider_slug}: tool conflict retries exhausted.");
                    }
                    $this->logger->warning("Custom provider {$this->provider_slug}: tool/web-search rejection. Disabling search and retrying.");
                    $active_web_search = false;
                    $messages = $this->strip_web_search_from_messages($messages);
                    $attempt--;
                    continue;
                }

                $is_schema_conflict = ($use_json_schema && (
                    strpos($err_msg, 'response_format') !== false
                    || strpos($err_msg, 'json_schema') !== false
                    || strpos($err_msg, 'failed to deserialize') !== false
                ));
                if ($is_schema_conflict) {
                    $this->schema_retries++;
                    if ($this->schema_retries > self::MAX_SELF_CORRECTION_RETRIES) {
                        if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                            $next_model = array_shift($remaining_fallbacks);
                            $this->logger->warning("Custom provider {$this->provider_slug}: schema conflict retries exhausted. Falling back to {$next_model}.");
                            $this->hop_to_next_model($next_model, $tried_models);
                            continue;
                        }
                        throw new AI_Exception("Custom provider {$this->provider_slug}: schema conflict retries exhausted.");
                    }
                    $this->logger->warning("Custom provider {$this->provider_slug}: JSON Schema rejected. Falling back to json_object.");
                    $use_json_schema = false;
                    $attempt--;
                    continue;
                }

                // No self-correction matched: hop to next model if available
                if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("Custom provider {$this->provider_slug}: 400 error on {$this->current_model}. Falling back to {$next_model}.");
                    $this->hop_to_next_model($next_model, $tried_models);
                    continue;
                }
                throw new AI_Exception("Custom provider {$this->provider_slug} rejected request with 400: " . substr($raw_body, 0, 500));
            }

            if ($code !== 200) {
                if ($this->fallback_enabled && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("Custom provider {$this->provider_slug}: unexpected HTTP {$code}. Falling back to {$next_model}.");
                    $this->hop_to_next_model($next_model, $tried_models);
                    continue;
                }
                throw new AI_Exception("{$this->provider_slug} returned HTTP {$code}");
            }

            Quota_State_Manager::record_success($this->provider_slug, $this->current_model);

            $data = json_decode($raw_body, true);
            if (!is_array($data) || empty($data['choices'][0]['message'])) {
                throw new AI_Exception("Custom provider {$this->provider_slug} returned invalid response structure.");
            }

            $message = $data['choices'][0]['message'] ?? [];
            $content = $message['content'] ?? '';

            if (empty($content) && !empty($message['tool_calls'])) {
                $tool_args = [];
                foreach ($message['tool_calls'] as $tc) {
                    $args = $tc['function']['arguments'] ?? '';
                    if ($args !== '') {
                        $tool_args[] = $args;
                    }
                }
                if (!empty($tool_args)) {
                    $content = implode("\n", $tool_args);
                }
            }

            if (empty($content)) {
                throw new AI_Exception("Empty completion content received from {$this->provider_slug}");
            }

            $article = $this->decode_json_payload($content);
            $article = $this->strip_citations_recursive($article);

            $sources = $this->extract_web_search_sources($data, $active_web_search_type);
            if (!empty($sources)) {
                $article['_sources_index'] = $sources;
                $article['_web_search_results'] = $data['web_search_info'] ?? $data['search_results'] ?? [];
            }

            $article['_actual_provider'] = $this->provider_slug;
            $article['_actual_model'] = $this->current_model;

            $this->logger->info("Custom provider {$this->provider_slug}: article generation succeeded.", [
                'model'       => $this->current_model,
                'article_keys' => array_keys($article),
            ]);

            return $article;
        }

        $this->logger->error("Custom provider {$this->provider_slug}: all fallback models exhausted.", [
            'tried_models' => $tried_models,
            'attempts'     => count($tried_models),
        ]);
        throw new AI_Rate_Limit_Exception("All fallback models exhausted for custom provider {$this->provider_slug}", 429, array(
            'provider'             => $this->provider_slug,
            'model'                => $this->current_model,
            'tried_models'         => $tried_models,
            'all_models_exhausted' => true,
        ));
    }

    /**
     * Decide what the intra-provider fallback loop should do with a given error.
     * Consulted from BOTH the gateway 'rate_limit' WP_Error path and the direct
     * 429/403 response path so behaviour is identical and driven by the single
     * API_Error_Info::recommended_action() policy.
     */
    private function intra_provider_fallback_decision(API_Error_Info $error_info): string
    {
        $action = $error_info->recommended_action();
        if ($action === API_Error_Info::ACTION_BLOCK_DAILY) {
            // OpenRouter free tier: daily quota is PER-MODEL, not per-key.
            // Hop to next model in chain; outer loop handles exhaustion.
            return 'hop';
        }
        if ($action === API_Error_Info::ACTION_HARD_FAIL) {
            // Auth / request-shape: deterministic, never fixed by switching models.
            return 'hard';
        }
        // ACTION_ROUTE_NEXT, ACTION_SAFETY_BLOCK, ACTION_SKIP_MODEL -> try next model.
        return 'hop';
    }

        private function get_structured_output_schema(array $prompt_data): array {
        $regen_sections = $prompt_data['regen_sections'] ?? ['all'];
        $context = $prompt_data['_generation_context'] ?? null;
        $is_new_post = $context instanceof \SEO_Article_Generator\Generator\Generation_Context && $context->type === 'new';
        $is_upgrade = $context instanceof \SEO_Article_Generator\Generator\Generation_Context && $context->type === 'upgrade';
        
        $map = [
            'hero'               => ['hero_section'],
            'introduction'       => ['introduction'],
            'moat'               => ['moat_data', 'software_type'],
            'download'           => ['download_section'],
            'tech_specs'        => ['tech_specs', 'system_requirements'],
            'system_requirements' => ['system_requirements'],
            'features'           => ['features'],
            'whats_new'         => ['whats_new'],
            'pros_cons'         => ['pros_cons'],
            'installation'       => ['installation_guide'],
            'troubleshooting'    => ['installation_guide'],
            'video'              => ['video_url'],
            'faqs'               => ['faqs'],
            'competitors'        => ['competitors', 'comparison_field_order', 'main_software_comparison'],
            'related_software'  => ['related_software'],
            'tags'               => ['tags'],
        ];

        $keys_to_include = ['needs_manual_input'];
        if (in_array('all', $regen_sections, true)) {
            $keys_to_include = array_merge($keys_to_include, [
                'title', 'slug', 'meta_description', 'focus_keyword', 'long_tail_keywords', 'keyword_variations',
                'hero_section', 'introduction', 'moat_data', 'software_type', 'download_section',
                'tech_specs', 'system_requirements', 'features', 'whats_new', 'pros_cons', 'installation_guide',
                'video_url', 'faqs', 'competitors', 'comparison_field_order', 'main_software_comparison',
                'related_software', 'tags', 'editor_rating', 'category'
            ]);
        } else {
            foreach ($regen_sections as $sec) {
                if (isset($map[$sec])) {
                    $keys_to_include = array_merge($keys_to_include, $map[$sec]);
                }
            }
            if ($is_new_post || $is_upgrade) {
                $keys_to_include = array_merge($keys_to_include, [
                    'title', 'slug', 'meta_description', 'focus_keyword', 'long_tail_keywords', 'keyword_variations'
                ]);
            }
        }
        $keys_to_include = array_values(array_unique($keys_to_include));

        $all_properties = [
            'title' => ['type' => 'string'],
            'meta_description' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'focus_keyword' => ['type' => 'string'],
            'long_tail_keywords' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'keyword_variations' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'introduction' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'tech_specs' => [
                'type' => 'object',
                'properties' => [
                    'software_name' => ['type' => ['string', 'null']],
                    'file_name' => ['type' => ['string', 'null']],
                    'version' => ['type' => ['string', 'null']],
                    'license' => ['type' => ['string', 'null']],
                    'developer' => ['type' => ['string', 'null']],
                    'homepage' => ['type' => ['string', 'null']],
                    'changelogurl' => ['type' => ['string', 'null']],
                    'file_size' => ['type' => ['string', 'null']],
                    'os_support' => ['type' => ['string', 'null']],
                    'language_support' => ['type' => ['string', 'null']],
                    'last_updated' => ['type' => ['string', 'null']],
                ],
                'required' => [
                    'software_name', 'file_name', 'version', 'license', 'developer',
                    'homepage', 'changelogurl', 'file_size', 'os_support', 'language_support',
                    'last_updated'
                ],
                'additionalProperties' => false
            ],
            'safety' => [
                'type' => 'object',
                'properties' => [
                    'verified_download' => ['type' => 'boolean'],
                    'file_hash' => ['type' => ['string', 'null']],
                    'scanned_by' => ['type' => ['string', 'null']],
                ],
                'required' => ['verified_download', 'file_hash', 'scanned_by'],
                'additionalProperties' => false
            ],
            'pros_cons' => [
                'type' => 'object',
                'properties' => [
                    'pros' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'cons' => ['type' => 'array', 'items' => ['type' => 'string']],
                ],
                'required' => ['pros', 'cons'],
                'additionalProperties' => false
            ],
            'video_url' => ['type' => ['string', 'null']],
            'features' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'name' => ['type' => 'string'],
                        'description' => ['type' => 'string'],
                    ],
                    'required' => ['name', 'description'],
                    'additionalProperties' => false
                ]
            ],
            'whats_new' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'system_requirements' => [
                'type' => 'object',
                'properties' => [
                    'minimum' => [
                        'type' => ['object', 'null'],
                        'properties' => [
                            'os' => ['type' => ['string', 'null']],
                            'processor' => ['type' => ['string', 'null']],
                            'ram' => ['type' => ['string', 'null']],
                            'disk_space' => ['type' => ['string', 'null']],
                            'graphics' => ['type' => ['string', 'null']],
                        ],
                        'required' => ['os', 'processor', 'ram', 'disk_space', 'graphics'],
                        'additionalProperties' => false
                    ],
                    'recommended' => [
                        'type' => ['object', 'null'],
                        'properties' => [
                            'os' => ['type' => ['string', 'null']],
                            'processor' => ['type' => ['string', 'null']],
                            'ram' => ['type' => ['string', 'null']],
                            'disk_space' => ['type' => ['string', 'null']],
                        ],
                        'required' => ['os', 'processor', 'ram', 'disk_space'],
                        'additionalProperties' => false
                    ]
                ],
                'required' => ['minimum', 'recommended'],
                'additionalProperties' => false
            ],
            'faqs' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'question' => ['type' => 'string'],
                        'answer' => ['type' => 'string'],
                    ],
                    'required' => ['question', 'answer'],
                    'additionalProperties' => false
                ]
            ],
            'installation_guide' => [
                'type' => 'object',
                'properties' => [
                    'steps' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'compatibility_notes' => ['type' => ['string', 'null']],
                    'common_issues' => ['type' => 'array', 'items' => ['type' => 'string']],
                ],
                'required' => ['steps', 'compatibility_notes', 'common_issues'],
                'additionalProperties' => false
            ],
            'tags' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'comparison_field_order' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'main_software_comparison' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'field' => ['type' => 'string'],
                        'value' => ['type' => ['string', 'null']],
                    ],
                    'required' => ['field', 'value'],
                    'additionalProperties' => false
                ]
            ],
            'competitors' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'name' => ['type' => 'string'],
                        'comparison_fields' => [
                            'type' => 'array',
                            'items' => [
                                'type' => 'object',
                                'properties' => [
                                    'field' => ['type' => 'string'],
                                    'value' => ['type' => ['string', 'null']],
                                ],
                                'required' => ['field', 'value'],
                                'additionalProperties' => false
                            ]
                        ],
                        'verdict' => ['type' => ['string', 'null']],
                    ],
                    'required' => ['name', 'comparison_fields', 'verdict'],
                    'additionalProperties' => false
                ]
            ],
            'software_type' => ['type' => ['string', 'null']],
            'moat_data' => [
                'type' => 'object',
                'properties' => [
                    'content' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'heading' => ['type' => 'string'],
                                'recipe' => ['type' => 'string'],
                                'why' => ['type' => 'string'],
                            ],
                            'required' => ['heading', 'recipe', 'why'],
                            'additionalProperties' => false
                        ]
                    ]
                ],
                'required' => ['content'],
                'additionalProperties' => false
            ],
            'hero_section' => [
                'type' => 'object',
                'properties' => [
                    'software_name' => ['type' => ['string', 'null']],
                    'version' => ['type' => ['string', 'null']],
                    'license' => ['type' => ['string', 'null']],
                    'file_size' => ['type' => ['string', 'null']],
                    'rating' => ['type' => ['number', 'null']],
                    'download_links' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'min_os' => ['type' => ['string', 'null']],
                    'last_updated' => ['type' => ['string', 'null']],
                ],
                'required' => ['software_name', 'version', 'license', 'file_size', 'rating', 'download_links', 'min_os', 'last_updated'],
                'additionalProperties' => false
            ],
            'editor_rating' => ['type' => 'integer'],
            'category' => ['type' => ['string', 'null']],
            'needs_manual_input' => [
                'type' => 'array',
                'items' => ['type' => 'string']
            ],
            'download_section' => [
                'type' => 'object',
                'properties' => [
                    'heading' => ['type' => ['string', 'null']],
                    'links' => ['type' => 'array', 'items' => ['type' => 'string']],
                ],
                'required' => ['heading', 'links'],
                'additionalProperties' => false
            ]
        ];

        $properties = [];
        $required = [];
        foreach ($keys_to_include as $key) {
            if (isset($all_properties[$key])) {
                $properties[$key] = $all_properties[$key];
                $required[] = $key;
            }
        }

        return [
            'type' => 'object',
            'properties' => $properties,
            'required' => $required,
            'additionalProperties' => false
        ];
    }
    private function get_max_tokens_for_model(string $model): int {
        $requested = 8192;
        foreach (self::$MODEL_MAX_TOKENS as $pattern => $cap) {
            if ($model === $pattern || stripos($model, $pattern) === 0) {
                return min($requested, $cap);
            }
        }
        $base = explode('-', str_replace('/', '-', $model))[0];
        foreach (self::$MODEL_MAX_TOKENS as $pattern => $cap) {
            if (stripos($pattern, $base) === 0 || stripos($base, $pattern) === 0) {
                return min($requested, $cap);
            }
        }
        return min($requested, 8192);
    }

    private function model_supports_response_format(string $model): bool {
        if (in_array($model, self::$MODELS_NO_RESPONSE_FORMAT, true)) {
            return false;
        }
        foreach (self::$MODELS_NO_RESPONSE_FORMAT as $pattern) {
            if (stripos($model, $pattern) === 0) {
                return false;
            }
        }
        $no_format_prefixes = ['moonshot', 'minimax', 'abab'];
        $base = explode('-', str_replace('/', '-', $model))[0];
        return !in_array(strtolower($base), $no_format_prefixes, true);
    }

    private function build_web_search_tool(string $type): array {
        switch ($type) {
            case 'google_search':
                return [['google_search' => new \stdClass()]];
            case 'zhipuai':
                return [[
                    'type' => 'web_search',
                    'web_search' => [
                        'enable'        => true,
                        'search_engine' => $this->provider_config['web_search_config']['search_engine'] ?? 'search_pro',
                        'search_result' => true,
                        'count'         => (int)($this->provider_config['web_search_config']['search_count'] ?? 10),
                    ]
                ]];
            case 'kimi':
                return [['type' => 'web_search', 'web_search' => ['enable' => true, 'search_result' => true]]];
            case 'minimax':
                return [['type' => 'web_search', 'web_search' => ['enable' => true]]];
            default:
                return [];
        }
    }

    private function strip_web_search_from_messages(array $messages): array {
        $marker = '## Web Search Instructions';
        foreach ($messages as $i => $msg) {
            if (($msg['role'] ?? '') === 'system' && strpos($msg['content'] ?? '', $marker) !== false) {
                $parts = explode($marker, $msg['content'], 2);
                $messages[$i]['content'] = rtrim($parts[0]);
            }
        }
        return $messages;
    }

    private function extract_web_search_sources(array $data, string $type): array {
        $sources = [];
        if ($type === 'zhipuai') {
            $results = $data['web_search_info']['search_result'] ?? [];
            foreach ($results as $i => $r) {
                if (!empty($r['link'])) {
                    $sources[] = [
                        'id'    => $i + 1,
                        'label' => $r['title'] ?? ('Source ' . ($i + 1)),
                        'url'   => $r['link'],
                    ];
                }
            }
        } elseif ($type === 'kimi' && !empty($data['citations'])) {
            foreach ($data['citations'] as $i => $c) {
                $url = $c['url'] ?? $c['link'] ?? '';
                if ($url !== '') {
                    $sources[] = [
                        'id'    => $i + 1,
                        'label' => $c['title'] ?? $c['name'] ?? ('Source ' . ($i + 1)),
                        'url'   => $url,
                    ];
                }
            }
        } elseif ($type === 'minimax') {
            $results = $data['search_results'] ?? [];
            foreach ($results as $i => $r) {
                $url = $r['url'] ?? $r['link'] ?? '';
                if ($url !== '') {
                    $sources[] = [
                        'id'    => $i + 1,
                        'label' => $r['title'] ?? $r['name'] ?? ('Source ' . ($i + 1)),
                        'url'   => $url,
                    ];
                }
            }
        }
        return $sources;
    }

    private function decode_json_payload(string $text): array {
        if (preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $text, $m)) {
            $text = $m[1];
        }

        $trimmed = trim($text);

        if (!preg_match('/^[\{\[]/', $trimmed)) {
            $start = strpos($trimmed, '{');
            $end = strrpos($trimmed, '}');
            if ($start !== false && $end !== false && $end > $start) {
                $trimmed = substr($trimmed, $start, $end - $start + 1);
            }
        }

        // DEBUG: Log raw response before JSON recovery
        if ($this->logger) {
            $this->logger->debug('Custom provider JSON payload preview', [
                'provider' => $this->provider_slug,
                'length' => strlen($trimmed),
                'preview' => substr($trimmed, 0, 500),
            ]);
        }

        try {
            return JSON_Recovery::decode($trimmed, $this->provider_slug, $this->logger);
        } catch (\Throwable $e) {
            if ($this->logger) {
                $this->logger->error('Custom provider JSON decode failed', [
                    'provider' => $this->provider_slug,
                    'error' => $e->getMessage(),
                    'raw_content' => $trimmed,
                ]);
            }
            throw $e;
        }
    }

    public function test_connection(): array {
        $url = $this->api_url . self::CHAT_ROUTE;
        if (empty($this->api_url)) {
            throw new AI_Exception('API URL is not configured.');
        }

        $headers = [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type'  => 'application/json',
        ];
        if (strpos($url, 'openrouter.ai') !== false) {
            $headers['HTTP-Referer'] = get_site_url();
            $headers['X-Title']      = get_bloginfo('name');
        }

        $body = [
            'model'      => $this->current_model,
            'messages'   => [['role' => 'user', 'content' => 'Ping']],
            'max_tokens' => 5,
            'temperature'=> 0,
            'stream'     => false,
        ];

        $this->logger->info("Custom provider {$this->provider_slug}: testing connection.", [
            'url'   => preg_replace('/key=[^&]+/', 'key=***', $url),
            'model' => $this->current_model,
        ]);

        $response = $this->ai_client->execute_safe_request($url, [
            'headers' => $headers,
            'body'    => wp_json_encode($body),
            'timeout' => 30,
        ], $this->provider_slug, $this->current_model);

        if (is_wp_error($response)) {
            $error_code = $response->get_error_code();
            $error_message = $response->get_error_message();
            $this->logger->error("Custom provider {$this->provider_slug}: connection test failed: {$error_message}");
            if ($error_code === 'rate_limit') {
                throw new AI_Rate_Limit_Exception($error_message, 429, $response->get_error_data());
            }
            throw new AI_Exception('Connection failed: ' . $error_message);
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $raw = wp_remote_retrieve_body($response);
            $this->logger->error("Custom provider {$this->provider_slug}: connection test returned HTTP {$code}.");
            throw new AI_Exception("API returned {$code}: " . substr($raw, 0, 200));
        }

        $this->logger->info("Custom provider {$this->provider_slug}: connection test passed.");

        return [
            'status'   => 'connected',
            'model'    => $this->current_model,
            'provider' => $this->provider_slug,
        ];
    }
}
