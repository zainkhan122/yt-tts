<?php

namespace DIT\TrendStudio\Services;

if (!defined('ABSPATH')) {
	exit;
}

class Social_Cleanup_Service
{
    private const CRON_HOOK = 'dit_ts_social_cleanup_cron';

    private const EVICTABLE_META_KEYS = [
        '_dit_ts_social_collage_id',
        '_dit_ts_social_image_url',
        '_wpas_media_src',
        '_wpas_mess',
    ];

    // Share history older than this many days will be purged
    private const SHARE_HISTORY_MAX_AGE_DAYS = 30;

    public function init()
    {
        add_action('dit_ts_daily_cleanup', [$this, 'run_social_meta_cleanup']);
    }

    public function run_social_meta_cleanup(): void
	{
		global $wpdb;

		$age_days = max(1, (int) get_option('dit_ts_social_cleanup_age_days', 0)
			?: (int) get_option('dit_ts_draft_cleanup_age_days', 7));
		$cutoff = gmdate('Y-m-d H:i:s', time() - ($age_days * DAY_IN_SECONDS));

		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT sm.id, sm.post_id
			FROM {$wpdb->prefix}dit_ts_social_meta sm
			INNER JOIN {$wpdb->posts} p ON p.ID = sm.post_id
			WHERE sm.status IN ('published','completed','failed')
			AND sm.created_at <= %s
			AND p.post_status = 'publish'
			LIMIT 200",
			$cutoff
		), ARRAY_A);

		if (empty($rows)) {
			$this->cleanup_orphaned_pending();
			$this->cleanup_share_history();
			return;
		}

		$cleaned_post_ids = [];

		foreach ($rows as $row) {
			$post_id = (int) $row['post_id'];

			if (in_array($post_id, $cleaned_post_ids, true)) {
				continue;
			}
			$cleaned_post_ids[] = $post_id;

			$collage_id = (int) get_post_meta($post_id, '_dit_ts_social_collage_id', true);
			if ($collage_id > 0) {
				$parent = (int) get_post_field('post_parent', $collage_id);
				if ($parent === 0 || $parent === $post_id) {
					wp_delete_attachment($collage_id, true);
				}
			}

			foreach (self::EVICTABLE_META_KEYS as $key) {
				delete_post_meta($post_id, $key);
			}

			$wpdb->query($wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}dit_ts_social_queue
				WHERE post_id = %d AND status IN ('sent','failed')",
				$post_id
			));
		}

		$ids = wp_list_pluck($rows, 'id');
		$ids = array_map('intval', $ids);
		if (!empty($ids)) {
			$ph = implode(',', array_fill(0, count($ids), '%d'));
			$wpdb->query($wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}dit_ts_social_meta WHERE id IN ($ph)",
				...$ids
			));
		}

		$this->cleanup_orphaned_pending();
		$this->cleanup_share_history();
	}

	/**
	 * Purge share history older than SHARE_HISTORY_MAX_AGE_DAYS.
	 * Cleans both Buffer (_nm_buffer_share_history) and Jetpack (_wpas_done_*) post meta.
	 */
	private function cleanup_share_history(): void
	{
		global $wpdb;

		$max_age = max(1, self::SHARE_HISTORY_MAX_AGE_DAYS);
		$cutoff = gmdate('Y-m-d H:i:s', time() - ($max_age * DAY_IN_SECONDS));

		// 1. Delete Buffer share history older than cutoff
		// _nm_buffer_share_history is stored per-post; we check the post's publish date
		// since the meta itself doesn't have a timestamp per entry
		$old_buffer_posts = $wpdb->get_col($wpdb->prepare(
			"SELECT DISTINCT pm.post_id
			FROM {$wpdb->postmeta} pm
			INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			WHERE pm.meta_key = '_nm_buffer_share_history'
			AND p.post_date_gmt <= %s
			LIMIT 200",
			$cutoff
		));

		foreach ($old_buffer_posts as $post_id) {
			delete_post_meta((int) $post_id, '_nm_buffer_share_history');
		}

		// 2. Delete Jetpack share done flags older than cutoff
		$old_jetpack_posts = $wpdb->get_col($wpdb->prepare(
			"SELECT DISTINCT pm.post_id
			FROM {$wpdb->postmeta} pm
			INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			WHERE pm.meta_key LIKE '\\_wpas\\_done\\_%'
			AND p.post_date_gmt <= %s
			LIMIT 200",
			$cutoff
		));

		foreach ($old_jetpack_posts as $post_id) {
			$done_keys = $wpdb->get_col($wpdb->prepare(
				"SELECT meta_key FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE '\\_wpas\\_done\\_%'",
				(int) $post_id
			));
			foreach ($done_keys as $key) {
				delete_post_meta((int) $post_id, $key);
			}
		}
	}

	private function cleanup_orphaned_pending(): void
	{
		global $wpdb;

		$table = $wpdb->prefix . 'dit_ts_social_meta';
		$orphan_cutoff = gmdate('Y-m-d H:i:s', time() - (3 * DAY_IN_SECONDS));

		$orphaned = $wpdb->get_col($wpdb->prepare(
			"SELECT sm.id FROM {$table} sm
			LEFT JOIN {$wpdb->posts} p ON p.ID = sm.post_id
			WHERE sm.status = 'pending'
			AND sm.created_at <= %s
			AND (p.ID IS NULL OR p.post_status NOT IN ('draft','pending','future','publish'))",
			$orphan_cutoff
		));

		if (empty($orphaned)) {
			return;
		}

		$ph = implode(',', array_fill(0, count($orphaned), '%d'));
		$wpdb->query($wpdb->prepare(
			"DELETE FROM {$table} WHERE id IN ($ph)",
			...array_map('intval', $orphaned)
		));
	}

	public function deactivate()
	{
		wp_clear_scheduled_hook(self::CRON_HOOK);
	}
}
