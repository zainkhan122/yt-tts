<?php
/**
 * DIT Video Module — Publish_Integrator
 *
 * Handles the "draft → publish" lifecycle:
 *   - When a DIT post that already has a generated video is published, run after
 *     DIT's own Buffer share so the shared YouTube Short link can be captured.
 *   - Insert the YouTube native Gutenberg embed block after the 2nd paragraph of
 *     the post body, so the published article embeds the Short natively.
 *   - Optionally detach/allow deletion of the local video attachment once the
 *     YT link is embedded (the post references YT instead of the local file).
 *
 * All of this is best-effort and logged; it never blocks publishing.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Publish_Integrator
{
    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    /** @var YT_Lookup */
    protected $yt;

    public function __construct(Settings $settings, Logger $logger, YT_Lookup $yt)
    {
        $this->settings = $settings;
        $this->logger   = $logger;
        $this->yt       = $yt;
    }

    public function register_hooks(): void
    {
        // Run on publish, after DIT's Buffer share hook (priority 20+).
        add_action('dit_ts_job_auto_published', array($this, 'on_publish'), 40, 3);
        add_action('transition_post_status', array($this, 'on_transition'), 40, 3);
    }

    public function on_transition($new_status, $old_status, $post): void
    {
        if ('publish' !== $new_status || 'publish' === $old_status) {
            return;
        }
        if ('post' !== ($post->post_type ?? '')) {
            return;
        }
        $this->maybe_embed((int) $post->ID);
    }

    public function on_publish($job_id, $post_id, $idea_id): void
    {
        $this->maybe_embed((int) $post_id);
        // Optionally share the video to other connected SMNs via DIT's Buffer.
        $this->maybe_share_video_smn((int) $post_id);
    }

    /**
     * If enabled, share the generated video to all enabled non-YouTube Buffer
     * channels (Instagram / Facebook / TikTok / etc) using DIT's own Buffer client.
     * The video attachment URL is resolved via _dit_ts_video_id. Best-effort.
     */
    protected function maybe_share_video_smn(int $post_id): void
    {
        if (!$this->settings->get_bool('share_video_all_smn', true)) {
            return;
        }
        $video_id = (int) get_post_meta($post_id, '_dit_ts_video_id', true);
        if (!$video_id) {
            return;
        }
        $video_url = wp_get_attachment_url($video_id);
        if (!$video_url) {
            return;
        }
        // Already shared?
        if (get_post_meta($post_id, '_dit_ts_video_smn_shared', true) === '1') {
            return;
        }

        $text = trim((string) get_post_meta($post_id, '_dit_ts_urdu_description', true));
        if ($text === '') {
            $text = (string) $post_id;
        }

        try {
            if (!class_exists('\\DIT\\TrendStudio\\Integrations\\Buffer\\Account_Manager')) {
                return;
            }
            $accounts = \DIT\TrendStudio\Integrations\Buffer\Account_Manager::get_enabled_accounts();
            $shared = 0;
            foreach ($accounts as $account_id => $account) {
                if (empty($account['api_key'])) {
                    continue;
                }
                $client = new \DIT\TrendStudio\Integrations\Buffer\Client($account['api_key'], $this->logger, $account_id);
                $channels = $client->get_channels();
                foreach ($channels as $channel_id => $channel_data) {
                    $svc = strtolower($channel_data['service'] ?? '');
                    // YouTube handled by DIT's existing flow; here we cover the rest.
                    if ($svc === 'youtube' || $svc === 'pinterest') {
                        continue;
                    }
                    $result = $client->create_post(
                        (string) $channel_id,
                        $text,
                        $svc,
                        'video',
                        $video_url
                    );
                    if (!empty($result['success'])) {
                        $shared++;
                        $this->logger->info("DIT Video: shared video to SMN channel {$svc} ({$channel_id}) for post {$post_id}.");
                    } else {
                        $this->logger->warning('DIT Video: SMN share failed for channel ' . $svc . ': ' . wp_json_encode($result['errors'] ?? ''));
                    }
                }
            }
            if ($shared > 0) {
                update_post_meta($post_id, '_dit_ts_video_smn_shared', '1');
                $this->logger->info('DIT Video: multi-SMN video share done (' . $shared . ' channels) for post ' . $post_id);
            }
        } catch (\Throwable $e) {
            $this->logger->error('DIT Video: multi-SMN share error: ' . $e->getMessage());
        }
    }

    /**
     * If the post has a generated video, resolve the YouTube link and insert a
     * native YT embed block after the 2nd paragraph. Idempotent.
     */
    public function maybe_embed(int $post_id): void
    {
        $video_id = (int) get_post_meta($post_id, '_dit_ts_video_id', true);
        if (!$video_id || (string) get_post_meta($post_id, '_dit_ts_video_ready', true) !== '1') {
            return;
        }
        // Already embedded?
        if (get_post_meta($post_id, '_dit_ts_youtube_embedded', true) === '1') {
            return;
        }

        $yt_title = trim((string) get_post_meta($post_id, '_dit_ts_youtube_title', true));
        $watch    = $this->yt->find_video_by_title($yt_title);
        $embed    = $this->yt->embed_url($watch);

        if ($embed === '') {
            $this->logger->warning('Publish_Integrator: could not resolve YT link for post ' . $post_id . ' (title: ' . $yt_title . ').');
            return;
        }

        $ok = $this->insert_youtube_block($post_id, $embed);
        if (!$ok) {
            return;
        }

        update_post_meta($post_id, '_dit_ts_youtube_embedded', '1');
        update_post_meta($post_id, '_dit_ts_youtube_watch_url', $watch);

        // ALWAYS detach the local video once the YT link is embedded. The local
        // file is now redundant (just eating server space) and cleanup deletes it.
        $this->detach_video($post_id, $video_id);

        $this->logger->info('Publish_Integrator: embedded YT for post ' . $post_id . ' -> ' . $watch . ' (local video detached)');
    }

    /**
     * Insert a Gutenberg core/embed (YouTube) block after the 2nd paragraph.
     */
    protected function insert_youtube_block(int $post_id, string $embed_url): bool
    {
        $post = get_post($post_id);
        if (!$post) {
            return false;
        }
        $block = "<!-- wp:core-embed/youtube {\"url\":\"{$embed_url}\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\n{$embed_url}\n</div></figure>\n<!-- /wp:core-embed/youtube -->";

        $content = $post->post_content;
        $inserted = $this->insert_after_2nd_paragraph($content, $block);
        if ($inserted === $content) {
            return false;
        }

        wp_update_post(array(
            'ID'           => $post_id,
            'post_content' => $inserted,
        ));
        return true;
    }

    /**
     * Insert $insertion after the 2nd closing </p> tag (works for both block and
     * classic content). Falls back to appending if <2 paragraphs.
     */
    protected function insert_after_2nd_paragraph(string $content, string $insertion): string
    {
        $pos = 0;
        for ($i = 0; $i < 2; $i++) {
            $next = strpos($content, '</p>', $pos);
            if (false === $next) {
                return $content . $insertion; // fewer than 2 paragraphs
            }
            $pos = $next + 4;
        }
        return substr($content, 0, $pos) . "\n\n" . $insertion . "\n\n" . substr($content, $pos);
    }

    /**
     * Detach (and allow later deletion of) the local video attachment.
     * Deletes it outright so the server space is freed immediately — the post now
     * references the YouTube embed, not the local file.
     */
    protected function detach_video(int $post_id, int $video_id): void
    {
        if ($video_id > 0 && get_post_type($video_id) === 'attachment') {
            // Remove the local file + attachment now that YT is embedded.
            wp_delete_attachment($video_id, true);
            delete_post_meta($post_id, '_dit_ts_video_id');
            $this->logger->info('Publish_Integrator: deleted local video attachment #' . $video_id . ' for post ' . $post_id);
        }
    }
}
