<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\Utils\Plugin_Time;

if (!defined('ABSPATH')) {
    exit;
}

class Quota_State_Manager
{
    private static function state_key(string $provider, string $model = ''): string
    {
        $slug = sanitize_key($provider);
        if ($model !== '') {
            $slug .= '_' . sanitize_key($model);
        }
        return 'seogen_qs_' . $slug;
    }

    public static function get_state(string $provider, string $model = ''): array
    {
        $key = self::state_key($provider, $model);
        $raw = get_transient($key);
        if (!is_array($raw)) {
            return self::default_state();
        }
        return array_merge(self::default_state(), $raw);
    }

    public static function record_success(string $provider, string $model = '', array $usage = array()): void
    {
        $state = self::get_state($provider, $model);
        $now = Plugin_Time::now_utc_ts();

        $window = $state['rpm_window'] ?? 60;
        $window_start = (int) ($state['rpm_window_start'] ?? 0);
        if ($now - $window_start >= $window) {
            $state['rpm_used'] = 0;
            $state['rpm_window_start'] = $now;
        }
        $state['rpm_used'] = (int) ($state['rpm_used'] ?? 0) + 1;

        $day_key = 'rpd_day_' . Quota_Reset_Calculator::gemini_next_rpd_reset_ts(0);
        if (($state['rpd_day_key'] ?? '') !== $day_key) {
            $state['rpd_used'] = 0;
            $state['rpd_day_key'] = $day_key;
        }
        $state['rpd_used'] = (int) ($state['rpd_used'] ?? 0) + 1;

        $tpm_window_start = (int) ($state['tpm_window_start'] ?? 0);
        if ($now - $tpm_window_start >= 60) {
            $state['tpm_used'] = 0;
            $state['tpm_window_start'] = $now;
        }
        $tpm_delta = (int) ($usage['total_tokens'] ?? 0);
        if ($tpm_delta > 0) {
            $state['tpm_used'] = (int) ($state['tpm_used'] ?? 0) + $tpm_delta;
        }

        $state['last_success_at'] = $now;
        $state['last_provider'] = $provider;
        $state['last_model'] = $model;

        self::save_state($provider, $model, $state);
    }

    public static function calibrate_from_error(string $provider, string $model, API_Error_Info $error_info): void
    {
        $state = self::get_state($provider, $model);
        $now = Plugin_Time::now_utc_ts();

        if ($error_info->is_quota_error()) {
            $type = $error_info->get_error_type();

            if ($type === API_Error_Info::TYPE_QUOTA_RPD) {
                $state['rpd_used'] = $state['rpd_limit'] > 0 ? $state['rpd_limit'] : (int) ($state['rpd_used'] ?? 0) + 1;
                $reset_ts = $error_info->get_reset_at_ts();
                if ($reset_ts > $now) {
                    $state['rpd_reset_at'] = $reset_ts;
                }
                if ($error_info->get_quota_limit() > 0) {
                    $state['rpd_limit'] = $error_info->get_quota_limit();
                }
            }

            if ($type === API_Error_Info::TYPE_QUOTA_RPM) {
                $state['rpm_used'] = $state['rpm_limit'] > 0 ? $state['rpm_limit'] : (int) ($state['rpm_used'] ?? 0) + 1;
                if ($error_info->get_quota_limit() > 0) {
                    $state['rpm_limit'] = $error_info->get_quota_limit();
                }
                $state['rpm_window_start'] = $now;
            }

            if ($type === API_Error_Info::TYPE_QUOTA_TPM) {
                $state['tpm_used'] = $state['tpm_limit'] > 0 ? $state['tpm_limit'] : (int) ($state['tpm_used'] ?? 0);
                if ($error_info->get_quota_limit() > 0) {
                    $state['tpm_limit'] = $error_info->get_quota_limit();
                }
            }

            if ($type === API_Error_Info::TYPE_QUOTA_UNKNOWN && $error_info->get_quota_limit() > 0) {
                $state['rpm_limit'] = $error_info->get_quota_limit();
            }
        }

        $state['last_error_at'] = $now;
        $state['last_error_type'] = $error_info->get_error_type();

        self::save_state($provider, $model, $state);
    }

    public static function get_recommended_interval(string $provider, string $model = ''): int
    {
        $state = self::get_state($provider, $model);
        $base = self::base_interval_for_provider($provider);

        $rpm_ratio = self::ratio($state, 'rpm');
        $rpd_ratio = self::ratio($state, 'rpd');

        $multiplier = 1.0;
        if ($rpm_ratio > 0.85) {
            $multiplier = 3.0;
        } elseif ($rpm_ratio > 0.70) {
            $multiplier = 2.0;
        } elseif ($rpm_ratio > 0.50) {
            $multiplier = 1.5;
        }

        if ($rpd_ratio > 0.90) {
            $multiplier = max($multiplier, 4.0);
        } elseif ($rpd_ratio > 0.75) {
            $multiplier = max($multiplier, 2.5);
        }

        return (int) ceil($base * $multiplier);
    }

    public static function should_slow_down(string $provider, string $model = ''): bool
    {
        $state = self::get_state($provider, $model);
        return self::ratio($state, 'rpm') > 0.70 || self::ratio($state, 'rpd') > 0.75;
    }

    public static function next_safe_slot_ts(string $provider, string $model = ''): int
    {
        $state = self::get_state($provider, $model);
        $now = Plugin_Time::now_utc_ts();
        $earliest = $now;

        $rpm_start = (int) ($state['rpm_window_start'] ?? 0);
        $rpm_window = (int) ($state['rpm_window'] ?? 60);
        if ($rpm_start > 0 && self::ratio($state, 'rpm') > 0.85) {
            $rpm_reset = $rpm_start + $rpm_window;
            $earliest = max($earliest, $rpm_reset);
        }

        $rpd_reset = (int) ($state['rpd_reset_at'] ?? 0);
        if ($rpd_reset > $now && self::ratio($state, 'rpd') > 0.95) {
            $earliest = max($earliest, $rpd_reset);
        }

        return $earliest;
    }

    private static function ratio(array $state, string $bucket): float
    {
        $used = (int) ($state[$bucket . '_used'] ?? 0);
        $limit = (int) ($state[$bucket . '_limit'] ?? 0);
        if ($limit <= 0) {
            return 0.0;
        }
        return $used / $limit;
    }

    private static function base_interval_for_provider(string $provider): int
    {
        switch ($provider) {
            case 'gemini': return 6;
            case 'openai': return 5;
            case 'groq': return 4;
            case 'perplexity': return 5;
            default:
                $registry = Provider_Registry::get_instance();
                if ($registry->is_custom($provider)) {
                    return (int) $registry->get_min_interval($provider);
                }
                return 6;
        }
    }

    private static function default_state(): array
    {
        return array(
            'rpm_used' => 0,
            'rpm_limit' => 0,
            'rpm_window' => 60,
            'rpm_window_start' => 0,
            'rpd_used' => 0,
            'rpd_limit' => 0,
            'rpd_day_key' => '',
            'rpd_reset_at' => 0,
            'tpm_used' => 0,
            'tpm_limit' => 0,
            'tpm_window_start' => 0,
            'last_success_at' => 0,
            'last_error_at' => 0,
            'last_error_type' => '',
            'last_provider' => '',
            'last_model' => '',
        );
    }

    private static function save_state(string $provider, string $model, array $state): void
    {
        $key = self::state_key($provider, $model);
        $ttl = 900;
        $rpd_reset = (int) ($state['rpd_reset_at'] ?? 0);
        $now = Plugin_Time::now_utc_ts();
        if ($rpd_reset > $now) {
            $ttl = max($ttl, $rpd_reset - $now + 300);
        }
        set_transient($key, $state, $ttl);
    }
}
