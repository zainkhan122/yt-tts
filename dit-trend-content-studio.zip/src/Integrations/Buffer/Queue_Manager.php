<?php

namespace DIT\TrendStudio\Integrations\Buffer;

class Queue_Manager
{
    const SHARE_HISTORY_META = '_nm_buffer_share_history';

    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    public function is_enabled(): bool
    {
        return !empty(Account_Manager::get_enabled_accounts());
    }

    public function share_to_buffer(int $post_id): void
    {
        if (!$this->is_enabled()) {
            $this->log_info('Skipping — no enabled Buffer accounts configured.');
            return;
        }

        if (get_post_type($post_id) !== 'post') {
            return;
        }

        $gen_flag = get_post_meta($post_id, '_dit_ts_generated', true);
        if ((string) $gen_flag !== '1') {
            return;
        }

        $lang_flag = get_post_meta($post_id, '_dit_ts_language_flag', true);
        if ($lang_flag === 'roman_urdu') {
            $this->log_info("Skipping post {$post_id}: Roman Urdu language flag set.");
            return;
        }

        $urdu_head = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_heading', true)));
        $urdu_desc = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_description', true)));
        $_hashtags = get_post_meta($post_id, '_dit_ts_hashtags', true);
        $hashtags = is_array($_hashtags) ? implode(' ', $_hashtags) : (string) $_hashtags;

        if (empty($urdu_head) || empty($urdu_desc)) {
            global $wpdb;
            $row = $wpdb->get_row($wpdb->prepare(
                "SELECT urdu_heading, urdu_description, hashtags FROM {$wpdb->prefix}dit_ts_social_meta WHERE post_id = %d AND status IN ('pending','completed','published') ORDER BY id DESC LIMIT 1",
                $post_id
            ), ARRAY_A);
            if ($row) {
                $urdu_head = $urdu_head ?: trim(wp_strip_all_tags((string) $row['urdu_heading']));
                $urdu_desc = $urdu_desc ?: trim(wp_strip_all_tags((string) $row['urdu_description']));
                $hashtags = $hashtags ?: (string) $row['hashtags'];
            }
        }

        if (empty($urdu_head) || empty($urdu_desc)) {
            $this->log_info("Skipping post {$post_id}: Urdu assets missing.");
            return;
        }

        $link = get_permalink($post_id);
        $image_url = $this->get_primary_image($post_id);

        $this->log_info("Starting share for post {$post_id}.");

        $accounts = Account_Manager::get_enabled_accounts();
        $total_shared = 0;

        foreach ($accounts as $account_id => $account) {
            $client = new Client($account['api_key'], $this->logger, $account_id);

            if (!$this->check_daily_limit($account_id, $account)) {
                $this->log_info("Skipping account {$account['name']} — daily limit reached.");
                continue;
            }

            $channels = $client->get_channels();
            if (empty($channels)) {
                $this->log_info("No Buffer channels found for account {$account['name']}.");
                continue;
            }

            $account_channels = $account['channels'] ?? [];
            $channel_posts = [];
            $shared_count = 0;

            foreach ($channels as $channel_id => $channel_data) {
                $ch_config = $account_channels[$channel_id] ?? [];
                if (!isset($ch_config['enabled']) || empty($ch_config['enabled'])) {
                    $this->log_info("Skipping channel {$channel_data['name']} (not enabled in account {$account['name']}).");
                    continue;
                }

                $service = $channel_data['service'];
                $post_type = $ch_config['post_type'] ?? 'post';
                // YouTube only supports video post type
                if ($service === 'youtube') {
                    $post_type = 'video';
                }
                $template = !empty($ch_config['template'])
                    ? $ch_config['template']
                    : get_option('dit_ts_jetpack_template', "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}");
                $is_link_post = !empty($ch_config['is_link_post']);
                $share_as_story = !empty($ch_config['share_as_story']);
                $pinterest_board_id = $ch_config['pinterest_board_id'] ?? null;
                $pinterest_title_template = $ch_config['pinterest_title'] ?? '{urdu_head}';

                if ($service === 'instagram' && empty($image_url)) {
                    $this->log_info('Skipping Instagram — no image available.');
                    continue;
                }

                if ($service === 'tiktok' && empty($image_url)) {
                    $this->log_info("Skipping TikTok channel {$channel_data['name']} — no media available.");
                    continue;
                }

                if ($service === 'pinterest' && empty($pinterest_board_id)) {
                    $this->log_info("Skipping Pinterest channel {$channel_data['name']} — no board selected in settings.");
                    continue;
                }

                if ($service === 'pinterest' && empty($image_url)) {
                    $this->log_info("Skipping Pinterest channel {$channel_data['name']} — no image available.");
                    continue;
                }

                // YouTube requires video — check for video file
                if ($service === 'youtube') {
                    $video_url = $this->get_primary_video($post_id);
                    if (empty($video_url)) {
                        $this->log_info("Skipping YouTube channel {$channel_data['name']} — no video available.");
                        continue;
                    }
                    // Use video_url as the image_url for YouTube video upload
                    $image_url = $video_url;
                }

                // Determine post types to create: main post + optional story
                $post_types_to_create = [$post_type];
                if ($share_as_story && in_array($service, ['facebook', 'instagram'], true) && $post_type !== 'story') {
                    $post_types_to_create[] = 'story';
                }

                foreach ($post_types_to_create as $current_post_type) {
                    $is_story = ($current_post_type === 'story');
                    // Generate unique key for each post (channel_id_post_type) to support main + story
                    $post_key = $channel_id . '||' . $current_post_type;
                    $message = $this->render_template($template, $urdu_head, $urdu_desc, $hashtags, $link, $image_url, $post_id);

                    $pinterest_title = '';
                    if ($service === 'pinterest') {
                        $pinterest_title = $this->render_template($pinterest_title_template, $urdu_head, $urdu_desc, $hashtags, $link, '', $post_id);
                        $pinterest_title = trim(wp_strip_all_tags($pinterest_title));
                    }

                $tiktok_title = '';
                if ($service === 'tiktok' && !empty($urdu_head)) {
                    $tiktok_title = $urdu_head;
                }

                $youtube_title = '';
                $youtube_category_id = '';
                $youtube_privacy = '';
                $youtube_embeddable = null;
                $youtube_license = '';
                $youtube_made_for_kids = null;
                $youtube_notify_subscribers = null;
                $youtube_is_ai_generated = null;

                if ($service === 'youtube') {
                    // Render YouTube title through template system (supports placeholders)
                    $youtube_title_template = $ch_config['youtube_title'] ?? '{urdu_head}';
                    $youtube_title = $this->render_template($youtube_title_template, $urdu_head, $urdu_desc, $hashtags, $link, $image_url, $post_id);
                    $youtube_title = trim(wp_strip_all_tags($youtube_title));
                    $youtube_category_id = $ch_config['youtube_category_id'] ?? '22'; // Default: People & Blogs
                    $youtube_privacy = $ch_config['youtube_privacy'] ?? 'public';
                    $youtube_embeddable = isset($ch_config['youtube_embeddable']) ? (bool) $ch_config['youtube_embeddable'] : true;
                    $youtube_license = $ch_config['youtube_license'] ?? 'youtube';
                    $youtube_made_for_kids = isset($ch_config['youtube_made_for_kids']) ? (bool) $ch_config['youtube_made_for_kids'] : false;
                    $youtube_notify_subscribers = isset($ch_config['youtube_notify_subscribers']) ? (bool) $ch_config['youtube_notify_subscribers'] : true;
                    $youtube_is_ai_generated = isset($ch_config['youtube_is_ai_generated']) ? (bool) $ch_config['youtube_is_ai_generated'] : false;
                }

                $channel_posts[$post_key] = [
                    'text' => $message,
                    'service' => $service,
                    'post_type' => $current_post_type,
                    'image_url' => $image_url,
                    'is_link_post' => $is_link_post,
                    'link_url' => $link,
                    'pinterest_board_id' => $pinterest_board_id,
                    'pinterest_title' => $pinterest_title,
                    'tiktok_title' => $tiktok_title,
                    'youtube_title' => $youtube_title,
                    'youtube_category_id' => $youtube_category_id,
                    'youtube_privacy' => $youtube_privacy,
                    'youtube_embeddable' => $youtube_embeddable,
                    'youtube_license' => $youtube_license,
                    'youtube_made_for_kids' => $youtube_made_for_kids,
                    'youtube_notify_subscribers' => $youtube_notify_subscribers,
                    'youtube_is_ai_generated' => $youtube_is_ai_generated,
                    'channel_id' => $channel_id, // Real Buffer channel ID for API
                ];
            } // end foreach post_types_to_create
        } // end foreach channels

        if (empty($channel_posts)) {
                $this->log_info("No channels to share for account {$account['name']}.");
                continue;
            }

            $batch_result = $client->create_posts_batch($channel_posts);

            if (!$batch_result['success']) {
                $error_msg = $batch_result['errors'][0]['message'] ?? 'Unknown error';
                $this->log_error("Batch createPost failed for account {$account['name']} post {$post_id} - {$error_msg}");
                continue;
            }

            foreach ($batch_result['results'] as $post_key => $result) {
                // Extract channel_id from post_key (format: channel_id||post_type)
                $delimiter_pos = strrpos($post_key, '||');
                $channel_id = $delimiter_pos !== false ? substr($post_key, 0, $delimiter_pos) : $post_key;
                $channel_data = $channels[$channel_id];
                if ($result['success']) {
                    $post_type_label = $delimiter_pos !== false ? ' (' . substr($post_key, $delimiter_pos + 2) . ')' : '';
                    $this->log_info("Shared post {$post_id} to {$channel_data['name']} ({$channel_data['service']}{$post_type_label}) (account {$account['name']}).");
                    $this->record_share($post_id, $channel_id, $channel_data['service'], $result['post'], $account_id);
                    $this->increment_daily_counter($account_id, $post_id);
                    $shared_count++;
                } else {
                    $error_msg = $result['errors'][0]['message'] ?? 'Unknown error';
                    $full_error = $result['errors'][0]['full_error'] ?? null;
                    $this->log_error("createPost error on {$channel_data['name']} ({$channel_data['service']}) (account {$account['name']}) - {$error_msg}" . ($full_error ? " - Full: " . wp_json_encode($full_error) : ""));
                }
            }

            if ($shared_count > 0) {
                $this->log_info("Account {$account['name']}: shared {$shared_count} post(s).");
                $total_shared += $shared_count;
            }
        }

        if ($total_shared === 0) {
            $this->log_info("No channels shared for post {$post_id} across any account.");
        }
    }

    private function get_primary_image(int $post_id): string
    {
        $collage_id = (int) get_post_meta($post_id, '_dit_ts_social_collage_id', true);
        if ($collage_id) {
            $url = wp_get_attachment_url($collage_id);
            if ($url) {
                return $url;
            }
        }

        $thumb_id = (int) get_post_thumbnail_id($post_id);
        if ($thumb_id) {
            return wp_get_attachment_url($thumb_id) ?: '';
        }

        return '';
    }

    private function get_primary_video(int $post_id): string
    {
        // Check for video attachment in post meta
        $video_id = (int) get_post_meta($post_id, '_dit_ts_video_id', true);
        if ($video_id) {
            $url = wp_get_attachment_url($video_id);
            if ($url) {
                return $url;
            }
        }

        // Check for video URL in post meta (external video URL)
        $video_url = get_post_meta($post_id, '_dit_ts_video_url', true);
        if (!empty($video_url)) {
            return $video_url;
        }

        return '';
    }

    private function render_template(string $template, string $urdu_head, string $urdu_desc, string $hashtags, string $link, string $image_url, int $post_id): string
    {
        $parsed = \DIT\TrendStudio\Services\Social_Queue_Manager::split_desc_and_hashtags($urdu_desc, $hashtags);

        $message = str_replace(
            ['{urdu_head}', '{urdu_desc}', '{hashtags}', '{link}', '{primary_image}', '\n'],
            [
                wp_strip_all_tags(html_entity_decode(trim($urdu_head), ENT_QUOTES | ENT_HTML5, 'UTF-8')),
                $parsed['desc'],
                $parsed['tags'],
                $link,
                $image_url,
                "\n",
            ],
            $template
        );

        return preg_replace("/\n{3,}/", "\n\n", trim($message));
    }

    private function check_daily_limit(string $account_id, array $account): bool
    {
        $limit = (int) ($account['daily_limit'] ?? 5);
        if ($limit <= 0) {
            return true;
        }

        $tracker_key = Account_Manager::get_tracker_key($account_id);
        $tracker = get_option($tracker_key, ['date' => '', 'ids' => []]);
        if (!is_array($tracker)) {
            $tracker = ['date' => '', 'ids' => []];
        }

        $today = gmdate('Y-m-d');
        if ($tracker['date'] !== $today) {
            $tracker = ['date' => $today, 'ids' => []];
            update_option($tracker_key, $tracker);
            return true;
        }

        if (count($tracker['ids']) >= $limit) {
            $this->log_info("Daily limit ({$limit}) reached for account {$account_id}.");
            return false;
        }

        return true;
    }

    private function increment_daily_counter(string $account_id, int $post_id): void
    {
        $tracker_key = Account_Manager::get_tracker_key($account_id);
        $tracker = get_option($tracker_key, ['date' => '', 'ids' => []]);
        if (!is_array($tracker)) {
            $tracker = ['date' => gmdate('Y-m-d'), 'ids' => []];
        }

        $today = gmdate('Y-m-d');
        if ($tracker['date'] !== $today) {
            $tracker = ['date' => $today, 'ids' => []];
        }

        if (!in_array($post_id, $tracker['ids'], true)) {
            $tracker['ids'][] = $post_id;
            update_option($tracker_key, $tracker);
        }
    }

    private function record_share(int $post_id, string $channel_id, string $service, array $post_data, string $account_id = ''): void
    {
        $history = get_post_meta($post_id, self::SHARE_HISTORY_META, true);
        if (!is_array($history)) {
            $history = [];
        }

        $history[] = [
            'channel_id' => $channel_id,
            'service' => $service,
            'post_id' => $post_id,
            'buffer_post_id' => $post_data['id'] ?? '',
            'due_at' => $post_data['dueAt'] ?? '',
            'shared_at' => gmdate('Y-m-d H:i:s'),
            'account_id' => $account_id,
        ];

        update_post_meta($post_id, self::SHARE_HISTORY_META, $history);
    }

    private function log_info(string $message): void
    {
        if ($this->logger) {
            $this->logger->info("NM Buffer Integration: {$message}");
        }
    }

    private function log_error(string $message): void
    {
        if ($this->logger) {
            $this->logger->error("NM Buffer Integration: {$message}");
        }
    }

}
