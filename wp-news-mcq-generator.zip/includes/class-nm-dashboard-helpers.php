<?php
/**
 * Admin Dashboard Helper Class
 * Provides static functions for fetching dashboard data.
 * Version: 2.1 - Removed Fuzzy Match
 *
 * @MODIFIED: Removed all logic related to "fuzzy" duplicate detection
 * from get_dashboard_stats_data() to align with the new 2-layer detector.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Dashboard_Helpers {

	/**
	 * Get all dashboard stats in one go.
	 */
	public static function get_dashboard_stats_data() {
		global $wpdb;
		$log_table = $wpdb->prefix . 'nm_generation_log';

		// 1. Post Counts
		$post_counts = wp_count_posts( 'mcq' );

		// 2. Reported Count
		$reported_count = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'mcq' AND pm.meta_key = 'mcq_report_status' AND pm.meta_value = 'reported'"
		);

		// 3. Duplicates in last 7 days (and 24 hours)
		$seven_days_ago    = current_time( 'mysql', true, 'gmt' );
		$seven_days_ago_ts = strtotime( '-7 days', current_time( 'timestamp' ) );
		$seven_days_ago    = gmdate( 'Y-m-d H:i:s', $seven_days_ago_ts );

		$twenty_four_hours_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-24 hours', current_time( 'timestamp' ) ) );

		// ✅ MODIFICATION: Removed 'fuzzy' from the query
		$duplicate_stats = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_key, COUNT(*) as count
             FROM {$log_table}
             WHERE type = 'duplicate' AND timestamp >= %s
             AND meta_key IN ('exact', 'semantic')
             GROUP BY meta_key",
				$seven_days_ago
			)
		);

		$duplicates_24h = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
             FROM {$log_table}
             WHERE type = 'duplicate' AND timestamp >= %s",
				$twenty_four_hours_ago
			)
		);

		$dupe_chart_data = array(
			'exact'    => 0,
			'semantic' => 0,
		); // ✅ MODIFIED: Removed 'fuzzy'
		$total_dupes     = 0;
		foreach ( $duplicate_stats as $stat ) {
			if ( isset( $dupe_chart_data[ $stat->meta_key ] ) ) {
				$dupe_chart_data[ $stat->meta_key ] = (int) $stat->count;
				$total_dupes                       += (int) $stat->count;
			}
		}

		// 4. Generation Activity (Today)
		$today_start_gmt = gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) );
		$hourly_stats    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT HOUR(timestamp) as hour, COUNT(*) as count
             FROM {$log_table}
             WHERE type = 'success' AND timestamp >= %s
             GROUP BY HOUR(timestamp)
             ORDER BY hour ASC",
				$today_start_gmt
			)
		);

		$gen_chart_data = array_fill( 0, 24, 0 );
		foreach ( $hourly_stats as $stat ) {
			$gen_chart_data[ (int) $stat->hour ] = (int) $stat->count;
		}

		// 5. Embedding Stats
		$embedding_stats = ( new NM_Embedding_Database() )->get_statistics();

		return array(
			'post_counts'      => array(
				'publish' => $post_counts->publish ?? 0,
				'draft'   => $post_counts->draft ?? 0,
				'total'   => ( $post_counts->publish ?? 0 ) + ( $post_counts->draft ?? 0 ) + ( $post_counts->pending ?? 0 ),
			),
			'reported_count'   => $reported_count,
			'duplicates_24h'   => $duplicates_24h,
			'duplicate_chart'  => array(
				'labels'      => array( 'Exact Match', 'Semantic Match' ), // ✅ MODIFIED
				'data'        => array_values( $dupe_chart_data ),
				'total'       => $total_dupes,
				'most_common' => self::get_most_common_duplicate( $dupe_chart_data ),
			),
			'generation_chart' => array(
				'labels' => array_map(
					function ( $h ) {
						return str_pad( $h, 2, '0', STR_PAD_LEFT ) . ':00'; },
					range( 0, 23 )
				),
				'data'   => $gen_chart_data,
				'total'  => array_sum( $gen_chart_data ),
			),
			'embedding_stats'  => array(
				'coverage' => $embedding_stats['coverage_percentage'] ?? 0,
				'size_mb'  => $embedding_stats['table_size_mb'] ?? 0,
				'orphaned' => $embedding_stats['orphaned_embeddings'] ?? 0,
			),
		);
	}

	/**
	 * Helper to find the most common duplicate type
	 */
	private static function get_most_common_duplicate( $data ) {
		if ( empty( $data ) || array_sum( $data ) === 0 ) {
			return 'N/A';
		}
		arsort( $data );
		$top_key = key( $data );
		switch ( $top_key ) {
			case 'exact':
				return 'Exact Match';
			case 'semantic':
				return 'Semantic Match';
			default:
				return 'N/A';
		}
	}

	/**
	 * Get system health data.
	 */
	public static function get_system_health_data() {
		global $wpdb;
		$health = array();

		// 1. Check WP-Cron
		$health['wp_cron'] = array(
			'label'  => 'WordPress Cron',
			'value'  => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'Disabled' : 'Enabled',
			'status' => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'bad' : 'good',
			'desc'   => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'Using server cron is recommended.' : 'Active.',
		);

		// 2. Check all plugin cron jobs
		$cron_jobs = array(
			'nm_news_generation_cron'              => 'Cron: News',
			'nm_topic_generation_cron'             => 'Cron: Topic',
			'nm_feed_import_cron'                  => 'Cron: Feed',
			'nm_generate_current_affairs_mcq_cron' => 'Cron: CA Feeder',
			'nm_ca_queue_worker_cron'              => 'Cron: CA Worker',
		);

		foreach ( $cron_jobs as $key => $label ) {
			$timestamp   = wp_next_scheduled( $key );
			$enabled_key = str_replace( array( '_cron', '_generation', '_mcq', '_generate', '_affairs', '_ca', '_worker', '_import' ), '', $key ) . '_enabled';
			$enabled_key = str_replace( 'topic', 'topic_generation', $enabled_key );
			$enabled_key = str_replace( 'feed', 'feed_importer', $enabled_key );
			$enabled     = get_option( 'nm_' . $enabled_key, 0 );

			if ( ! $enabled ) {
				$health[ $key ] = array(
					'label'  => $label,
					'value'  => 'Disabled',
					'status' => 'off',
					'desc'   => 'Disabled in settings.',
				);
			} elseif ( $timestamp ) {
				$time_diff      = $timestamp - current_time( 'timestamp' );
				$health[ $key ] = array(
					'label'  => $label,
					'value'  => 'Scheduled',
					'status' => 'good',
					'desc'   => 'Next run in ' . human_time_diff( current_time( 'timestamp' ), $timestamp ),
				);
			} else {
				$health[ $key ] = array(
					'label'  => $label,
					'value'  => 'Not Scheduled',
					'status' => 'bad',
					'desc'   => 'Cron is not scheduled. Try saving settings again.',
				);
			}
		}

		// 3. Check for stuck crons
		foreach ( array( 'news', 'topic' ) as $type ) {
			if ( NM_Generation_Service::is_generation_locked( $type ) ) {
				$health[ 'stuck_' . $type ] = array(
					'label'  => 'Stuck Cron: ' . ucfirst( $type ),
					'value'  => 'Stuck',
					'status' => 'bad',
					'desc'   => 'Generation process has been locked for > 10 min. <a href="#" class="nm-fix-cron-link" data-cron-key="' . $type . '">Click to fix</a>',
				);
			}
		}

		return $health;
	}

	/**
	 * Get Top Topics.
	 */
	public static function get_top_topics() {
		$topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'hide_empty' => true,
				'number'     => 10,
				'orderby'    => 'count',
				'order'      => 'DESC',
				'fields'     => 'all',
			)
		);

		if ( is_wp_error( $topics ) || empty( $topics ) ) {
			return '"Topic","Count"\r\n"No topics found",0';
		}

		$csv_data = '"Topic","Count"' . "\r\n";
		foreach ( $topics as $topic ) {
			$csv_data .= '"' . esc_html( $topic->name ) . '","' . (int) $topic->count . '"' . "\r\n";
		}

		return $csv_data;
	}
}
