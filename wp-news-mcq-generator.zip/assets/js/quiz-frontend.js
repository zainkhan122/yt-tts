jQuery(document).ready(function ($) {
  "use strict";

  const startBtn = $("#nm-start-quiz-btn");
  if (startBtn.length === 0) return;

  const overlay = $("#nm-quiz-modal-overlay");
  const closeBtn = $("#nm-quiz-close-btn");

  const setupPane = $("#nm-quiz-setup-pane");
  const questionPane = $("#nm-quiz-question-pane");
  const resultsPane = $("#nm-quiz-results-pane");

  const topicInput = $("#nm-quiz-topic-input");
  const topicSlugInput = $("#nm-quiz-topic-slug");
  const suggestionsBox = $("#nm-topic-suggestions");
  const countInput = $("#nm-quiz-count-input");
  const generateBtn = $("#nm-generate-quiz-btn");

  let quizQuestions = [];
  let currentQuestionIndex = 0;
  let userScore = 0;
  let timerInterval;
  let searchTimeout;

  function startQuiz() {
    currentQuestionIndex = 0;
    userScore = 0;
    setupPane.removeClass("active");
    resultsPane.removeClass("active");
    questionPane.addClass("active");
    displayQuestion();
  }

  function displayQuestion() {
    clearInterval(timerInterval);
    const questionData = quizQuestions[currentQuestionIndex];
    let optionsHtml = "";
    $.each(questionData.options, function (key, value) {
      optionsHtml += `<li class="quiz-option" data-option="${key}">${value}</li>`;
    });

    // ✅ MODIFIED v7.3.3: Restructured with flexbox sections for sticky header/footer
    const questionHtml = `
            <div class="nm-quiz-header">
                <div class="nm-quiz-timer" id="nm-quiz-timer-display">20</div>
                <div class="nm-quiz-progress">Question ${currentQuestionIndex + 1
      } of ${quizQuestions.length}</div>
            </div>
            <div class="nm-quiz-body">
                <h3 class="nm-quiz-question-title">${questionData.question}</h3>
                <ul class="nm-quiz-options">${optionsHtml}</ul>
            </div>
            <div class="nm-quiz-footer">
                <button class="nm-quiz-next-btn" id="nm-quiz-skip-btn" disabled>Next Question →</button>
            </div>
        `;
    questionPane.html(questionHtml);
    startTimer();
  }

  function startTimer() {
    let timeLeft = 20; // ✅ v7.3.3: Increased from 10s to 20s for comfortable reading time
    const timerDisplay = $("#nm-quiz-timer-display");
    timerInterval = setInterval(() => {
      timeLeft--;
      timerDisplay.text(timeLeft);
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        handleAnswerSelection(null);
      }
    }, 1000);
  }

  function handleAnswerSelection(selectedOption) {
    clearInterval(timerInterval);
    const questionData = quizQuestions[currentQuestionIndex];
    const correctAnswer = questionData.answer;
    const nextBtn = $("#nm-quiz-skip-btn");

    $(".quiz-option").addClass("disabled");
    if (selectedOption) {
      if (selectedOption.data("option") === correctAnswer) {
        userScore++;
        selectedOption.addClass("correct");
      } else {
        selectedOption.addClass("wrong");
        $(`.quiz-option[data-option="${correctAnswer}"]`).addClass("correct");
      }
    } else {
      $(`.quiz-option[data-option="${correctAnswer}"]`).addClass("correct");
    }

    // ✅ NEW v7.3.3: Enable Next button after answer is selected
    nextBtn.prop("disabled", false).text("Next Question →");

    // ✅ MODIFIED v7.3.3: Auto-advance after 2 seconds OR wait for manual click
    setTimeout(() => {
      currentQuestionIndex++;
      if (currentQuestionIndex < quizQuestions.length) {
        displayQuestion();
      } else {
        showResults();
      }
    }, 2000);
  }

  function showResults() {
    const scorePercentage = Math.round(
      (userScore / quizQuestions.length) * 100
    );
    const topicName = topicInput.val();

    // ===== LOG QUIZ COMPLETION TO DASHBOARD =====
    if (
      typeof nm_quiz_object !== "undefined" &&
      nm_quiz_object.is_user_logged_in === "yes"
    ) {
      $.ajax({
        url: nm_quiz_object.ajax_url,
        type: "POST",
        data: {
          action: "nm_log_quiz_activity",
          nonce: nm_quiz_object.nonce,
          type: "quiz",
          quiz_id: Math.floor(Math.random() * 100000),
          quiz_title: topicName + " Quiz",
          topic: topicName,
          score: scorePercentage,
          total_questions: quizQuestions.length,
          correct_answers: userScore,
        },
        success: function (response) {
          if (response.success) {
            console.log("✅ Quiz logged to dashboard:", response.data);
          }
        },
      });
    }
    // ===== END QUIZ LOGGING =====
    const shareTitle = `I scored ${userScore}/${quizQuestions.length} on the ${topicName} Quiz! Can you beat my score?`;
    const pageUrl = window.location.href;

    // --- DEFINITIVE FIX: Build the share links ---
    const shareText = encodeURIComponent(shareTitle + " " + pageUrl);
    const xLink = `https://x.com/intent/tweet?text=${encodeURIComponent(
      shareTitle
    )}&url=${encodeURIComponent(pageUrl)}`;
    const facebookLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
      pageUrl
    )}`;
    const whatsappLink = `https://api.whatsapp.com/send?text=${shareText}`;

    const shareLinksHtml = `Share on: <a href="${xLink}" target="_blank">X</a> | <a href="${facebookLink}" target="_blank">Facebook</a> | <a href="${whatsappLink}" target="_blank" data-action="share/whatsapp/share">WhatsApp</a> | <a href="#" class="nm-share-copy-link" data-link="${pageUrl}">Copy Link</a>${navigator.share ? ` | <a href="#" class="nm-share-native" data-url="${pageUrl}" data-title="${shareTitle}" data-text="Can you beat my score? Check out this quiz!">Share</a>` : ""}`;
    // --- END FIX ---

    const resultsHtml = `
            <h2>Quiz Complete!</h2>
            <div class="nm-quiz-results-summary">
                <p>Your Score:</p>
                <div class="nm-final-score">${userScore} / ${quizQuestions.length}</div>
                <div class="nm-final-percentage">${scorePercentage}%</div>
            </div>
            <div class="nm-quiz-results-actions">
                <button id="nm-quiz-restart-btn" class="button-primary">Try Again</button>
                <button id="nm-quiz-share-results-btn">Share Your Score</button>
            </div>
            <div class="nm-share-container-results" style="display:none; text-align:center; margin-top: 15px;">
                ${shareLinksHtml}
            </div>
        `;
    resultsPane.html(resultsHtml);
    questionPane.removeClass("active");
    resultsPane.addClass("active");
  }

  function resetQuiz() {
    quizQuestions = [];
    currentQuestionIndex = 0;
    userScore = 0;
    clearInterval(timerInterval);
    topicInput.val("");
    topicSlugInput.val("");
    countInput.val("10");
    generateBtn.text("Generate Quiz").prop("disabled", true);
    resultsPane.removeClass("active");
    setupPane.addClass("active");
  }

  // --- EVENT HANDLERS ---
  // ✅ MODIFIED v7.3.8: Added body scroll lock for mobile
  startBtn.on("click", () => {
    overlay.fadeIn();
    $("body").addClass("nm-modal-open"); // Lock body scroll
  });

  closeBtn.on("click", () => {
    overlay.fadeOut();
    $("body").removeClass("nm-modal-open"); // Unlock body scroll
  });
  overlay.on("click", function (e) {
    if ($(e.target).is(overlay)) {
      overlay.fadeOut();
    }
  });

  // ✅ MODIFIED: Enhanced Topic Search with Enter Key Support & Visual Feedback
  topicInput.on("keyup", function (e) {
    clearTimeout(searchTimeout);

    // Handle Enter Key (13)
    if (e.which === 13) {
      // If there are suggestions visible, select the first one
      const firstSuggestion = suggestionsBox.find("div").first();
      if (firstSuggestion.length && firstSuggestion.data("slug")) {
        firstSuggestion.click();
      }
      return;
    }

    const searchTerm = $(this).val();
    generateBtn.prop("disabled", true);
    topicSlugInput.val("");

    if (searchTerm.length < 2) {
      suggestionsBox.empty().hide();
      return;
    }

    // Show searching feedback
    suggestionsBox.html('<div class="nm-searching">Searching...</div>').show();

    searchTimeout = setTimeout(() => {
      // Safety check for localization object
      if (typeof nm_quiz_object === 'undefined') {
        suggestionsBox.html('<div class="nm-error">Error: Quiz config missing.</div>');
        return;
      }

      $.ajax({
        url: nm_quiz_object.rest_url + "/topics/search",
        type: "GET",
        data: {
          term: searchTerm,
        },
        success: function (response) {
          suggestionsBox.empty(); // Clear "Searching..."

          if (response.success && response.data.length > 0) {
            $.each(response.data, (index, topic) =>
              suggestionsBox.append(
                `<div data-slug="${topic.slug}">${topic.name}</div>`
              )
            );
            suggestionsBox.show();
          } else {
            suggestionsBox.append('<div class="nm-no-results">No topics found.</div>').show();
          }
        },
        error: function () {
          suggestionsBox.html('<div class="nm-error">Search failed. Try again.</div>').show();
        }
      });
    }, 300);
  });

  suggestionsBox.on("click", "div", function () {
    const item = $(this);
    // Ignore clicks on info messages
    if (item.hasClass('nm-searching') || item.hasClass('nm-no-results') || item.hasClass('nm-error')) {
      return;
    }

    const topicName = item.text();
    const topicSlug = item.data("slug");

    if (topicSlug) {
      topicInput.val(topicName);
      topicSlugInput.val(topicSlug);
      generateBtn.prop("disabled", false);
      // Optional: Focus the count input or generate button
      generateBtn.focus();
    }
    suggestionsBox.empty().hide();
  });

  // @MODIFIED v9.0.1: Switched from admin-ajax.php to REST API to bypass 403 blocks
  generateBtn.on("click", function () {
    const topic = topicSlugInput.val();
    const count = countInput.val();
    if (!topic || !count) {
      alert("Please select a topic and number of questions.");
      return;
    }
    $(this).text("Generating...").prop("disabled", true);

    // Primary: REST API (bypasses admin-ajax.php 403 blocks)
    $.ajax({
      url: nm_quiz_object.rest_url + "/quiz/generate",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify({
        topic_slug: topic,
        count: parseInt(count, 10),
      }),
      success: function (response) {
        if (response.success && response.data && response.data.length > 0) {
          quizQuestions = response.data;
          startQuiz();
        } else {
          alert(
            "Could not find enough questions for this topic. Please try a different topic or a smaller number."
          );
          generateBtn.text("Generate Quiz").prop("disabled", false);
        }
      },
      error: function () {
        // Fallback: try admin-ajax.php in case REST API is disabled
        $.ajax({
          url: nm_quiz_object.ajax_url,
          type: "POST",
          data: {
            action: "nm_generate_quiz",
            nonce: nm_quiz_object.nonce,
            topic_slug: topic,
            count: count,
          },
          success: function (response) {
            if (response.success && response.data && response.data.length > 0) {
              quizQuestions = response.data;
              startQuiz();
            } else {
              alert(
                "Could not find enough questions for this topic. Please try a different topic or a smaller number."
              );
              generateBtn.text("Generate Quiz").prop("disabled", false);
            }
          },
          error: function () {
            alert("An error occurred while generating the quiz. Please try again.");
            generateBtn.text("Generate Quiz").prop("disabled", false);
          },
        });
      },
    });
  });

  questionPane.on("click", ".quiz-option:not(.disabled)", function () {
    handleAnswerSelection($(this));
  });

  // ✅ NEW v7.3.3: Manual Next button to skip to next question immediately
  questionPane.on("click", "#nm-quiz-skip-btn:not(:disabled)", function () {
    clearInterval(timerInterval);
    currentQuestionIndex++;
    if (currentQuestionIndex < quizQuestions.length) {
      displayQuestion();
    } else {
      showResults();
    }
  });

  resultsPane.on("click", "#nm-quiz-restart-btn", function () {
    resetQuiz();
  });

  // --- DEFINITIVE FIX: Simplified share button logic ---
  resultsPane.on("click", "#nm-quiz-share-results-btn", function () {
    // Simply toggle the visibility of the container with the links.
    resultsPane.find(".nm-share-container-results").slideToggle();
  });
});

