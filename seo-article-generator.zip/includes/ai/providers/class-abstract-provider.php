<?php

namespace SEO_Article_Generator\AI\Providers;

use SEO_Article_Generator\Logger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Abstract AI Provider
 * 
 * @since 2.13.5
 */
abstract class Abstract_Provider implements Provider_Interface
{
    /**
     * API Key
     * @var string
     */
    protected $api_key;

    /**
     * Logger instance
     * @var Logger
     */
    protected $logger;

    /**
     * Max retries
     * @var int
     */
    protected $max_retries = 5;

    /**
     * AI Client instance
     * @var \SEO_Article_Generator\AI\AI_Client
     */
    protected $ai_client;

    /**
     * Last raw prompt sent to AI
     * @var string|null
     */
    protected $last_raw_prompt = null;

    /**
     * Last raw response received from AI
     * @var string|null
     */
    protected $last_raw_response = null;

    /**
     * Get last raw prompt
     * @return string|null
     */
    public function get_last_raw_prompt()
    {
        return $this->last_raw_prompt;
    }

    /**
     * Get last raw response
     * @return string|null
     */
    public function get_last_raw_response()
    {
        return $this->last_raw_response;
    }

    /**
     * Constructor
     * 
     * @param string $api_key
     * @param Logger $logger
     * @param \SEO_Article_Generator\AI\AI_Client $ai_client
     */
    public function __construct($api_key, $logger, $ai_client)
    {
        $this->api_key = $api_key;
        $this->logger = $logger;
        $this->ai_client = $ai_client;
    }

    /**
     * Recursively strip citation markers
     * 
     * @param mixed $data
     * @return mixed
     */
    protected function strip_citations_recursive($data)
    {
        if (is_string($data)) {
            $data = preg_replace('/\s*(?:\[\d+(?:,\s*\d+)*\])+/', '', $data);
            $data = preg_replace('/\s*\[(?:web|page|file|memory|conversation_history):\d+\]/i', '', $data);
            $data = preg_replace('/\s{2,}/', ' ', $data);
            $data = preg_replace('/\s+([.,;:])/', '$1', $data);
            return trim($data);
        }

        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = $this->strip_citations_recursive($value);
            }
        }

        return $data;
    }

    /**
     * Build partial regeneration instruction
     * 
     * @param array $regen_sections
     * @return string
     */
    protected function build_partial_regen_instruction($regen_sections)
    {
        if (empty($regen_sections)) {
            return '';
        }

        $section_map = array(
            'introduction' => 'introduction (opening paragraph)',
            'features' => 'features list',
            'tech_specs' => 'tech_specs table data',
            'download' => 'download_section with links',
            'pros_cons' => 'pros_cons arrays',
            'faqs' => 'faqs array',
            'installation' => 'installation_guide steps',
            'competitors' => 'competitors array (comparison table)',
            'moat' => 'moat_data content (recipes/best settings)',
        );

        $requested = array();
        foreach ($regen_sections as $section) {
            if (isset($section_map[$section])) {
                $requested[] = $section_map[$section];
            }
        }

        if (empty($requested)) {
            return '';
        }

        $sections_list = implode(', ', $requested);

        return <<<INSTRUCTION
PARTIAL REGENERATION MODE:
Generate ONLY the following sections: {$sections_list}
For all OTHER sections in the JSON schema, return empty strings or empty arrays.
Focus all your web research on the requested sections only.
INSTRUCTION;
    }

    /**
     * Build section skip instruction
     * 
     * @param array $prompt_data
     * @return string
     */
    protected function build_section_skip_instruction($prompt_data)
    {
        $skip_sections = array();

        if (empty($prompt_data['include_faqs'])) {
            $skip_sections[] = 'faqs (set to empty array [])';
        }

        if (empty($prompt_data['include_pros_cons'])) {
            $skip_sections[] = 'pros_cons (set pros and cons to empty arrays [])';
        }

        if (empty($prompt_data['include_competitors'])) {
            $skip_sections[] = 'competitors (set to empty array [])';
        }

        if (empty($prompt_data['include_moat'])) {
            $skip_sections[] = 'moat_data (set content to empty array [])';
        }

        if (empty($prompt_data['include_installation'])) {
            $skip_sections[] = 'installation_guide (set steps to empty array [])';
        }

        if (empty($skip_sections)) {
            return '';
        }

        return 'SECTION TOGGLES: User has disabled the following sections - DO NOT generate content for: ' . implode(', ', $skip_sections) . '. Leave these fields as empty arrays in your response.';
    }

    /**
     * Test API connection
     * @return array
     */
    abstract public function test_connection();
}
