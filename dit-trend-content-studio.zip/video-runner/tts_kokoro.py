#!/usr/bin/env python3
"""
DIT Video Module — Kokoro TTS (self-hosted, optional).
NOTE: Kokoro does NOT support Urdu. It supports English, Hindi, Spanish,
French, Italian, Japanese, Portuguese, Chinese. Use hf_alpha (Hindi female)
as the closest to a South-Asian female voice, or af_heart (English female).

Usage: python3 tts_kokoro.py <textfile> <output.mp3> <voice> <speed>
"""
import os, sys, subprocess, time

CACHE = os.path.expanduser("~/.cache/kokoro")
MODEL_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files/kokoro-v0_19.onnx"
VOICES_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin"
MODEL = os.path.join(CACHE, "kokoro-v0_19.onnx")
VOICES = os.path.join(CACHE, "voices-v1.0.bin")

VOICE = "af_heart"
LANG = "en-us"

def ensure_model():
    os.makedirs(CACHE, exist_ok=True)
    if not os.path.exists(MODEL):
        print("downloading kokoro model (325MB)...")
        subprocess.run(["curl", "-sL", "--max-time", "550", "-o", MODEL, MODEL_URL], check=True)
    if not os.path.exists(VOICES):
        print("downloading voices (28MB)...")
        subprocess.run(["curl", "-sL", "--max-time", "120", "-o", VOICES, VOICES_URL], check=True)

def main():
    if len(sys.argv) < 4:
        sys.stderr.write("Usage: tts_kokoro.py <textfile> <output.mp3> <voice> <speed>\n")
        sys.exit(1)
    textfile = sys.argv[1]
    out = sys.argv[2]
    voice = sys.argv[3] if len(sys.argv) > 3 else VOICE
    speed = float(sys.argv[4]) if len(sys.argv) > 4 else 1.15

    ensure_model()
    try:
        import soundfile as sf
        from kokoro_onnx import Kokoro
    except ImportError as e:
        sys.stderr.write("kokoro-onnx / soundfile not installed: %s\n" % e)
        sys.exit(2)

    kokoro = Kokoro(MODEL, VOICES)
    with open(textfile, encoding="utf-8") as f:
        text = f.read().strip()

    t = time.time()
    samples, sr = kokoro.create(text, voice=voice, speed=speed, lang=LANG)
    print("generated %.1fs audio in %.1fs" % (len(samples)/sr, time.time()-t))

    tmp = out + ".wav"
    sf.write(tmp, samples, sr)

    # mp3 encode via ffmpeg (imageio_ffmpeg or system).
    try:
        import imageio_ffmpeg
        ff = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        ff = "ffmpeg"
    subprocess.run([ff, "-y", "-i", tmp, "-codec:a", "libmp3lame", "-b:a", "128k", "-ac", "1", out], check=True, capture_output=True)
    os.remove(tmp)
    print("saved:", out)

if __name__ == "__main__":
    main()
