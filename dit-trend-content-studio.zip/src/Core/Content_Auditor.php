<?php

/**
 * Content Auditor
 *
 * Extracts factual claims from generated content and matches them to source citations.
 * Flags unverified claims for editorial review.
 *
 * @package DIT_TrendStudio\Core
 * @MODIFIED 2025-12-18 - Phase 3: Initial implementation for E-E-A-T compliance.
 * @MODIFIED 2026-02-05 - Restored from backup to fix missing class.
 */

namespace DIT\TrendStudio\Core;

use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Audits generated content for factual claims and source verification.
 *
 * Implements claim extraction using NLP patterns and matches claims
 * to available sources for E-E-A-T compliance.
 */
class Content_Auditor
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Hard claim patterns (REQUIRE citations).
     * Statistics, dates, quotes, superlatives, attribution.
     *
     * @since 1.8.0 - Separated hard/soft claim types for citation policy
     * @var array
     */
    private const HARD_CLAIM_PATTERNS = [
        // Statistics and numbers
        '/\b\d+(?:\.\d+)?%?\s+(?:of|percent|million|billion|thousand)/i',
        // Dates and timelines
        '/\b(?:in|on|since|during|by)\s+\d{4}\b/i',
        '/\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?,?\s*\d{4}/i',
        // Attribution patterns
        '/\baccording to\b/i',
        '/\b(?:said|stated|reported|announced|confirmed|revealed)\b/i',
        // Definitive superlatives
        '/\bis\s+(?:the\s+)?(?:first|largest|smallest|oldest|newest|best|worst|only|most)\b/i',
        // Quoted content
        '/"[^"]{10,}"/i',
    ];

    /**
     * Soft claim patterns (exempt from citation requirements).
     * Modal/predictive language common in fashion-forward commentary.
     *
     * @since 1.8.0
     * @var array
     */
    private const SOFT_CLAIM_PATTERNS = [
        // Modal/predictive words (not factual claims)
        '/\b(?:will|shall|must|should|could|would|may|might|always|never)\b/i',
    ];

    /**
     * Combined claim patterns for backward compatibility.
     * @deprecated Use HARD_CLAIM_PATTERNS or SOFT_CLAIM_PATTERNS
     */
    private const CLAIM_PATTERNS = [
        '/\b\d+(?:\.\d+)?%?\s+(?:of|percent|million|billion|thousand)/i',
        '/\b(?:in|on|since|during|by)\s+\d{4}\b/i',
        '/\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?,?\s*\d{4}/i',
        '/\baccording to\b/i',
        '/\b(?:said|stated|reported|announced|confirmed|revealed)\b/i',
        '/\bis\s+(?:the\s+)?(?:first|largest|smallest|oldest|newest|best|worst|only|most)\b/i',
        '/\b(?:will|shall|must|always|never)\b/i',
        '/"[^"]{10,}"/i',
    ];

    /**
     * Robotic AI-writing patterns (regex).
     * Flags common clichés that reduce editorial quality.
     * @since 1.6.0
     *
     * @var array
     */
    private const ROBOTIC_PATTERNS = [
        '/\bin the ever-evolving landscape\b/i',
        '/\btapestry of\b/i',
        '/\bdelves into\b/i',
        '/\ba testament to\b/i',
        '/\bcrucial role\b/i',
        '/\bin conclusion\b/i',
        '/\bfurthermore\b/i',
        '/\bit\'s important to remember\b/i',
        '/\bshines a light on\b/i',
        '/\bcomprehensive guide\b/i',
        '/\bultimate guide\b/i',
        '/\btake a deep dive\b/i',
        '/\bunlock the potential\b/i',
        '/\bpaving the way\b/i',
    ];

    /**
     * Source verification confidence thresholds.
     */
    private const CONFIDENCE_HIGH = 0.8;
    private const CONFIDENCE_MEDIUM = 0.5;
    private const CONFIDENCE_LOW = 0.2;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Audit content and return claim analysis.
     *
     * @param string $content       HTML content to audit
     * @param array  $sources       Available sources [{url, label}, ...]
     * @param array  $intelligence  Intelligence data from research phase
     * @param array  $sources_index Numbered source index for inline citation validation
     * @return array Audit result with claims, matches, and unverified items
     */
    public function audit(string $content, array $sources = [], array $intelligence = [], array $sources_index = []): array
    {
        $this->logger->info('Starting content audit');

        // Extract claims from content
        $claims = $this->extract_claims($content);

        // Match claims to sources
        $matched_claims = $this->match_claims_to_sources($claims, $sources, $intelligence);

        // Detect roboticisms (v1.6.0)
        $roboticisms = $this->detect_roboticisms($content);

        // Calculate audit summary
        $verified_count = count(array_filter($matched_claims, fn($c) => $c['verified']));
        $unverified_count = count($matched_claims) - $verified_count;

        // Inline citation validation (Phase 3: Strict Inline Sourcing)
        $citation_audit = [];
        if (!empty($sources_index)) {
            $citation_audit = $this->validate_inline_citations($content, $sources_index);
        }

        $result = [
            'total_claims'                   => count($matched_claims),
            'verified_claims'                => $verified_count,
            'unverified_claims'              => $unverified_count,
            'roboticisms'                    => $roboticisms,
            'roboticism_count'               => count($roboticisms),
            'verification_rate'              => count($matched_claims) > 0
                ? round($verified_count / count($matched_claims) * 100, 1)
                : 100,
            'claims'                         => $matched_claims,
            'audit_timestamp'                => current_time('mysql'),
            // Inline citation metrics
            'citation_coverage_percent'      => $citation_audit['citation_coverage_percent'] ?? null,
            'missing_citation_claims_count'  => $citation_audit['missing_citation_count'] ?? 0,
            'invalid_citation_count'         => $citation_audit['invalid_citation_count'] ?? 0,
            'inline_citation_details'        => $citation_audit['claims'] ?? [],
        ];

        $this->logger->info('Content audit complete', [
            'total'             => $result['total_claims'],
            'verified'          => $result['verified_claims'],
            'unverified'        => $result['unverified_claims'],
            'citation_coverage' => $result['citation_coverage_percent'],
        ]);

        return $result;
    }

    /**
     * Validate inline citations in content.
     *
     * Checks that claim sentences have [N] citation tags where N is a valid source index.
     *
     * @since 1.8.0 Phase 3: Strict Inline Sourcing
     * @param string $content       HTML content to validate
     * @param array  $sources_index Numbered source index [{id, label, url}, ...]
     * @return array Validation results with coverage metrics
     */
    public function validate_inline_citations(string $content, array $sources_index): array
    {
        $max_source_id = count($sources_index);
        $claims = $this->extract_claims($content);

        $results = [];
        $missing_count = 0;
        $invalid_count = 0;
        $hard_claims_total = 0;
        $hard_claims_cited = 0;

        foreach ($claims as $claim) {
            // Find all [N] citation tags in the sentence
            preg_match_all('/\[(\d+)\]/', $claim['sentence'], $matches);
            $citation_ids = array_map('intval', $matches[1] ?? []);
            $invalid_ids = array_filter($citation_ids, fn($id) => $id < 1 || $id > $max_source_id);

            $has_citation = !empty($citation_ids);
            $has_invalid = !empty($invalid_ids);
            $is_hard_claim = ($claim['claim_type'] ?? 'soft') === 'hard';

            $results[] = [
                'sentence'             => $claim['sentence'],
                'claim_type'           => $claim['claim_type'] ?? 'soft',
                'has_inline_citation'  => $has_citation,
                'citation_ids'         => $citation_ids,
                'invalid_citation_ids' => array_values($invalid_ids),
            ];

            // Track hard claims for coverage calc (soft claims exempt)
            if ($is_hard_claim) {
                $hard_claims_total++;
                if ($has_citation) {
                    $hard_claims_cited++;
                } else {
                    $missing_count++;
                }
            }
            if ($has_invalid) {
                $invalid_count++;
            }
        }

        $total = count($claims);
        $cited = $total - $missing_count;

        return [
            'claim_count'               => $total,
            'claims_with_citations'     => $cited,
            'missing_citation_count'    => $missing_count,
            'invalid_citation_count'    => $invalid_count,
            'hard_claims_total'         => $hard_claims_total,
            'hard_claims_cited'         => $hard_claims_cited,
            'citation_coverage_percent' => $hard_claims_total > 0 ? round($hard_claims_cited / $hard_claims_total * 100, 1) : 100.0,
            'claims'                    => $results,
        ];
    }

    /**
     * Extract factual claims from content.
     *
     * @param string $content HTML content
     * @return array List of claim objects [{text, sentence, position, pattern_matched}, ...]
     */
    public function extract_claims(string $content): array
    {
        $claims = [];

        // Strip HTML and normalize whitespace
        $text = wp_strip_all_tags($content);
        $text = preg_replace('/\s+/', ' ', $text);

        // Split into sentences
        $sentences = $this->split_into_sentences($text);

        foreach ($sentences as $index => $sentence) {
            $sentence = trim($sentence);
            if (strlen($sentence) < 20) {
                continue; // Skip very short sentences
            }

            // Check each claim pattern
            foreach (self::CLAIM_PATTERNS as $pattern) {
                if (preg_match($pattern, $sentence, $matches)) {
                    $claims[] = [
                        'text'            => $matches[0],
                        'sentence'        => $sentence,
                        'position'        => $index,
                        'pattern_matched' => $pattern,
                        'claim_type'      => $this->classify_claim_type($pattern),
                    ];
                    break; // One match per sentence is enough
                }
            }
        }

        $this->logger->info('Extracted claims', ['count' => count($claims)]);

        return $claims;
    }

    /**
     * Classify claim type based on matched pattern.
     *
     * @since 1.8.0 - Hard/soft claim classification
     * @param string $pattern Regex pattern that matched
     * @return string 'hard' or 'soft'
     */
    private function classify_claim_type(string $pattern): string
    {
        // Check if pattern is in soft claim patterns (modal words)
        foreach (self::SOFT_CLAIM_PATTERNS as $soft_pattern) {
            if ($pattern === $soft_pattern) {
                return 'soft';
            }
        }
        return 'hard';
    }

    /**
     * Split text into sentences.
     *
     * @param string $text Plain text
     * @return array Array of sentences
     */
    private function split_into_sentences(string $text): array
    {
        // Split on sentence-ending punctuation followed by space and capital letter
        $sentences = preg_split(
            '/(?<=[.!?])\s+(?=[A-Z])/',
            $text,
            -1,
            PREG_SPLIT_NO_EMPTY
        );

        return $sentences ?: [];
    }

    /**
     * Match extracted claims to available sources.
     *
     * @param array $claims       Extracted claims
     * @param array $sources      Available sources
     * @param array $intelligence Research intelligence data
     * @return array Claims with verification status
     */
    public function match_claims_to_sources(array $claims, array $sources, array $intelligence = []): array
    {
        $matched = [];
        $facts = $intelligence['facts'] ?? [];
        $raw_research = $intelligence['raw_research'] ?? '';

        foreach ($claims as $claim) {
            $verification = $this->verify_claim($claim, $sources, $facts, $raw_research);

            $matched[] = array_merge($claim, [
                'verified'        => $verification['verified'],
                'confidence'      => $verification['confidence'],
                'matched_source'  => $verification['matched_source'],
                'matched_fact'    => $verification['matched_fact'],
                'suggestion'      => $verification['suggestion'],
            ]);
        }

        return $matched;
    }

    /**
     * Verify a single claim against sources and facts.
     *
     * @param array  $claim       Claim data
     * @param array  $sources     Available sources
     * @param array  $facts       Research facts
     * @param string $raw_research Raw research content
     * @return array Verification result
     */
    private function verify_claim(array $claim, array $sources, array $facts, string $raw_research): array
    {
        $result = [
            'verified'       => false,
            'confidence'     => 0.0,
            'matched_source' => null,
            'matched_fact'   => null,
            'suggestion'     => '',
        ];

        $claim_text = strtolower($claim['sentence']);
        $claim_keywords = $this->extract_keywords($claim_text);

        // 1. Check against research facts
        foreach ($facts as $fact) {
            $fact_lower = strtolower($fact);
            $similarity = $this->calculate_similarity($claim_text, $fact_lower);

            if ($similarity > self::CONFIDENCE_MEDIUM) {
                $result['verified'] = true;
                $result['confidence'] = $similarity;
                $result['matched_fact'] = $fact;
                break;
            }
        }

        // 2. Check against raw research
        if (!$result['verified'] && !empty($raw_research)) {
            $research_lower = strtolower($raw_research);
            $keyword_matches = 0;

            foreach ($claim_keywords as $keyword) {
                if (strpos($research_lower, $keyword) !== false) {
                    $keyword_matches++;
                }
            }

            if (count($claim_keywords) > 0) {
                $match_ratio = $keyword_matches / count($claim_keywords);
                if ($match_ratio > 0.6) {
                    $result['verified'] = true;
                    $result['confidence'] = min($match_ratio, 0.7);
                    $result['matched_fact'] = 'Found in research content';
                }
            }
        }

        // 3. Check for source attribution in claim
        if (!$result['verified']) {
            foreach ($sources as $source) {
                $source_label = strtolower($source['label'] ?? '');
                $source_domain = $this->extract_domain($source['url'] ?? '');

                if (
                    strpos($claim_text, $source_label) !== false ||
                    strpos($claim_text, $source_domain) !== false
                ) {
                    $result['verified'] = true;
                    $result['confidence'] = self::CONFIDENCE_HIGH;
                    $result['matched_source'] = $source;
                    break;
                }
            }
        }

        // 4. Generate suggestion for unverified claims
        if (!$result['verified']) {
            $result['suggestion'] = $this->generate_suggestion($claim);
        }

        return $result;
    }

    /**
     * Extract meaningful keywords from text.
     *
     * @param string $text Text to extract keywords from
     * @return array Keywords
     */
    private function extract_keywords(string $text): array
    {
        // Remove common stop words
        $stop_words = [
            'the',
            'a',
            'an',
            'is',
            'are',
            'was',
            'were',
            'be',
            'been',
            'being',
            'have',
            'has',
            'had',
            'do',
            'does',
            'did',
            'will',
            'would',
            'could',
            'should',
            'may',
            'might',
            'must',
            'shall',
            'can',
            'need',
            'dare',
            'to',
            'of',
            'in',
            'for',
            'on',
            'with',
            'at',
            'by',
            'from',
            'as',
            'into',
            'through',
            'during',
            'before',
            'after',
            'above',
            'below',
            'between',
            'under',
            'again',
            'further',
            'then',
            'once',
            'here',
            'there',
            'when',
            'where',
            'why',
            'how',
            'all',
            'each',
            'few',
            'more',
            'most',
            'other',
            'some',
            'such',
            'no',
            'nor',
            'not',
            'only',
            'own',
            'same',
            'so',
            'than',
            'too',
            'very',
            'just',
            'and',
            'but',
            'or',
            'if',
            'because',
            'until',
            'while',
            'that',
            'which',
            'who',
            'whom',
            'this',
            'these',
            'those',
            'am',
            'its',
        ];

        // Extract words
        preg_match_all('/\b[a-z]{3,}\b/', $text, $matches);
        $words = $matches[0] ?? [];

        // Filter stop words and return unique keywords
        $keywords = array_filter($words, fn($w) => !in_array($w, $stop_words));

        return array_unique($keywords);
    }

    /**
     * Calculate similarity between two texts.
     *
     * @param string $text1 First text
     * @param string $text2 Second text
     * @return float Similarity score (0-1)
     */
    private function calculate_similarity(string $text1, string $text2): float
    {
        $words1 = $this->extract_keywords($text1);
        $words2 = $this->extract_keywords($text2);

        if (empty($words1) || empty($words2)) {
            return 0.0;
        }

        $intersection = count(array_intersect($words1, $words2));
        $union = count(array_unique(array_merge($words1, $words2)));

        return $union > 0 ? $intersection / $union : 0.0;
    }

    /**
     * Extract domain from URL.
     *
     * @param string $url URL
     * @return string Domain
     */
    private function extract_domain(string $url): string
    {
        $parsed = wp_parse_url($url);
        $host = $parsed['host'] ?? '';

        return strtolower(preg_replace('/^www\./', '', $host));
    }

    /**
     * Generate a suggestion for an unverified claim.
     *
     * @param array $claim Claim data
     * @return string Suggestion text
     */
    private function generate_suggestion(array $claim): string
    {
        $type = $claim['claim_type'] ?? 'factual_assertion';

        $suggestions = [
            'statistic'         => 'Add a source citation for this statistical claim.',
            'date_time'         => 'Verify the date/time mentioned and add source if needed.',
            'attribution'       => 'Confirm the attribution and link to the original source.',
            'quote'             => 'Verify the quote accuracy and add proper attribution.',
            'direct_quote'      => 'Add source link for this direct quote.',
            'superlative'       => 'Verify this superlative claim with authoritative source.',
            'factual_assertion' => 'Consider adding a source to support this claim.',
        ];

        return $suggestions[$type] ?? $suggestions['factual_assertion'];
    }

    /**
     * Get only unverified claims from audit result.
     *
     * @param array $audit_result Full audit result
     * @return array Unverified claims only
     */
    public function get_unverified_claims(array $audit_result): array
    {
        $claims = $audit_result['claims'] ?? [];

        return array_filter($claims, fn($c) => !$c['verified']);
    }

    /**
     * Detect common AI roboticisms in content.
     * @since 1.6.0
     *
     * @param string $content HTML content
     * @return array List of detected roboticisms [{text, suggestion}, ...]
     */
    public function detect_roboticisms(string $content): array
    {
        $detected = [];
        $text = wp_strip_all_tags($content);

        foreach (self::ROBOTIC_PATTERNS as $pattern) {
            if (preg_match_all($pattern, $text, $matches)) {
                foreach ($matches[0] as $match) {
                    $detected[] = [
                        'text' => $match,
                        'suggestion' => 'Avoid this AI cliché; use more natural, editorial language.',
                    ];
                }
            }
        }

        return $detected;
    }

    /**
     * Format audit result for display in admin UI.
     *
     * @param array $audit_result Full audit result
     * @return string HTML formatted summary
     */
    public function format_for_display(array $audit_result): string
    {
        $unverified = $this->get_unverified_claims($audit_result);
        $roboticisms = $audit_result['roboticisms'] ?? [];

        if (empty($unverified) && empty($roboticisms)) {
            return '<div class="dit-ts-audit-pass"><span class="dashicons dashicons-yes-alt"></span> Professional audit passed</div>';
        }

        $html = '<div class="dit-ts-audit-warning">';

        if (!empty($unverified)) {
            $html .= '<h4><span class="dashicons dashicons-warning"></span> ' . count($unverified) . ' Unverified Claims</h4>';
            $html .= '<ul class="dit-ts-unverified-claims">';
            foreach ($unverified as $claim) {
                $html .= '<li class="dit-ts-claim-item">';
                $html .= '<blockquote>' . esc_html(wp_trim_words($claim['sentence'], 20)) . '</blockquote>';
                $html .= '<p class="dit-ts-claim-suggestion"><strong>Suggestion:</strong> ' . esc_html($claim['suggestion']) . '</p>';
                $html .= '</li>';
            }
            $html .= '</ul>';
        }

        if (!empty($roboticisms)) {
            $html .= '<h4><span class="dashicons dashicons-admin-customizer"></span> ' . count($roboticisms) . ' Roboticisms Detected</h4>';
            $html .= '<ul class="dit-ts-roboticisms">';
            foreach ($roboticisms as $robot) {
                $html .= '<li class="dit-ts-claim-item">';
                $html .= '<blockquote>"' . esc_html($robot['text']) . '"</blockquote>';
                $html .= '<p class="dit-ts-claim-suggestion"><strong>Editor Note:</strong> ' . esc_html($robot['suggestion']) . '</p>';
                $html .= '</li>';
            }
            $html .= '</ul>';
        }

        $html .= '</div>';

        return $html;
    }
}
