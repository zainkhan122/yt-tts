<?php
$files = ['news-card', 'dual-photo', 'text-heavy'];
$base = dirname(__DIR__) . '/assets/img/previews/';

foreach ($files as $f) {
    $path = $base . $f . '.png';
    if (!file_exists($path)) {
        echo "$f: FILE NOT FOUND\n";
        continue;
    }
    $info = getimagesize($path);
    $img = imagecreatefrompng($path);

    $nonBlack = 0;
    $hasRed = 0;
    $hasWhite = 0;
    $total = 0;

    for ($i = 0; $i < 1000; $i++) {
        $x = rand(0, $info[0] - 1);
        $y = rand(0, $info[1] - 1);
        $rgb = imagecolorat($img, $x, $y);
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        $total++;
        if ($r > 20 || $g > 20 || $b > 20) $nonBlack++;
        if ($r > 200 && $g < 50 && $b < 80) $hasRed++;
        if ($r > 200 && $g > 200 && $b > 200) $hasWhite++;
    }
    imagedestroy($img);

    $pct = round($nonBlack / $total * 100);
    echo "$f.png: {$info[0]}x{$info[1]} | Non-black: $pct% | Red pixels: $hasRed | White pixels: $hasWhite\n";
}
