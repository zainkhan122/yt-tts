<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders HTML templates to PNG via headless Chromium (Puppeteer).
 *
 * Replaces the GD+Pango compositing path with browser-quality rendering
 * that respects CSS Grid, flexbox, absolute positioning, and Nastaliq shaping.
 */
class HtmlTemplateRenderer {

	private string $temp_dir;

	public function __construct() {
		$this->temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $this->temp_dir ) ) {
			wp_mkdir_p( $this->temp_dir );
		}
	}

	/**
	 * Render a template to PNG via Chromium.
	 *
	 * @param string $template  Template slug (e.g. 'news-card').
	 * @param array  $job_data  Job data from QueueProcessor.
	 * @return string|null      Path to output PNG, or null on failure.
	 */
	public function render( string $template, array $job_data ): ?string {
		$template_path = Config::get_template_path( $template );
		if ( ! $template_path || ! file_exists( $template_path ) ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_data['job_id'] ?? 0, [ 'template' => $template ], '500' );
			return null;
		}

		$html = file_get_contents( $template_path );
		if ( $html === false ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_data['job_id'] ?? 0, [ 'template' => $template ], '500' );
			return null;
		}

		$replacements = $this->build_token_replacements( $template, $job_data );
		$html = str_replace( array_keys( $replacements ), array_values( $replacements ), $html );

		$html_file = $this->temp_dir . '/template_' . uniqid() . '.html';
		if ( file_put_contents( $html_file, $html ) === false ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_data['job_id'] ?? 0, [], '500' );
			return null;
		}

		$output_png = $this->temp_dir . '/render_' . uniqid() . '.png';
		$width  = (int) ( $job_data['width']  ?? 1080 );
		$height = (int) ( $job_data['height'] ?? 1350 );

		$success = $this->call_chromium( $html_file, $output_png, $width, $height, $job_data['job_id'] ?? 0 );

		@unlink( $html_file );

		if ( ! $success || ! file_exists( $output_png ) || filesize( $output_png ) < 500 ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_data['job_id'] ?? 0, [
				'template'      => $template,
				'file_exists'   => file_exists( $output_png ),
				'file_size'     => file_exists( $output_png ) ? filesize( $output_png ) : 0,
				'render_script' => Config::RENDER_SCRIPT,
				'script_exists' => Config::file_exists_robust( Config::RENDER_SCRIPT ),
			], '500' );
			@unlink( $output_png );
			return null;
		}

		return $output_png;
	}

	/**
	 * Build the complete token replacement map for a template.
	 */
	private function build_token_replacements( string $template, array $job_data ): array {
		$brand  = $job_data['brand']  ?? Config::get_brand_settings();
		$colors = $job_data['colors'] ?? [];
		$focal  = $job_data['focal_point'] ?? [];

		$headline = $job_data['headline'] ?? '';
		$hook     = $job_data['hook']     ?? '';
		$language = $job_data['language'] ?? 'en';

		$width  = (int) ( $job_data['width']  ?? 1080 );
		$height = (int) ( $job_data['height'] ?? 1350 );

		$headline_char_count = mb_strlen( $headline, 'UTF-8' );
		$is_urdu             = ( $language === 'ur' );

		// If description is explicitly disabled in Brand Kit, suppress it.
		// FIX: We no longer suppress this by default because it removes required text from the rendered image.
		if ( isset( $brand['enable_description'] ) && $brand['enable_description'] === '0' ) {
			$hook = '';
		}
		
		$hook_char_count     = mb_strlen( $hook, 'UTF-8' );

		// Calculate dynamic image height ratio early to scale text dynamically
		$image_zone = $job_data['image_zone'] ?? null;
		$source_w = ! empty( $job_data['source_width'] ) ? (int) $job_data['source_width'] : 0;
		$source_h = ! empty( $job_data['source_height'] ) ? (int) $job_data['source_height'] : 0;

		if ( $source_w > 0 && $source_h > 0 ) {
			$image_h_ratio = ( $source_h / $source_w ) * ( $width / $height );
			// Cap at 0.82 — tall source images (1080x1350) naturally want >75%.
			$image_h_ratio = max( 0.40, min( 0.82, $image_h_ratio ) );
		} else {
			$image_h_ratio = isset( $image_zone['h'] ) ? floatval( $image_zone['h'] ) : 0.70;
			$image_h_ratio = min( 0.82, $image_h_ratio );
		}

		// Allow admin override of image height percentage.
		$image_height_override = $brand['image_height_override'] ?? '';
		if ( $image_height_override !== '' && $image_height_override !== '0' ) {
			$image_h_ratio = floatval( $image_height_override ) / 100.0;
		}
		$image_h_ratio = max( 0.30, min( 0.82, $image_h_ratio ) );

		// Gentle scale: only reduce text when the image takes >82% of canvas.
		// The HTML template already uses cqh-based padding/clamp() to adapt the
		// layout, so aggressive shrinking here only makes Urdu Nastaliq unreadable.
		$space_scale = 1.0;
		if ( $image_h_ratio > 0.82 ) {
			$space_scale = max( 0.85, ( 1.0 - $image_h_ratio ) / 0.18 );
		}

		// Size-preset multiplier ('' = auto-adaptive, or a preset key like 'small','medium','large','xlarge').
		$size_preset          = $brand['font_size_preset'] ?? '';
		$preset_def           = Config::SIZE_PRESETS[ $size_preset ] ?? null;
		$preset_heading_mult  = ( $preset_def !== null && $size_preset !== '' ) ? (float) $preset_def['heading'] : 1.0;
		$preset_hook_mult     = ( $preset_def !== null && $size_preset !== '' ) ? (float) $preset_def['hook']     : 1.0;

		// Compute available text area height BEFORE font sizing so we can cap font size.
		// Layout: .text-container goes from top:image_h_pct% to bottom:brand_h_pct%.
		// Its actual height = (1 - image_h_ratio - brand_h_pct/100) * canvas_height.
		// CSS padding: container 14px top + 14px bottom, headline 8px top + 8px bottom = 44px.
		$brand_h_pct_val = isset( $brand['brand_bar_height_pct'] ) && $brand['brand_bar_height_pct'] !== '' ? floatval( $brand['brand_bar_height_pct'] ) : 10.0;
		$text_container_h = (int) round( $height * ( 1.0 - $image_h_ratio - ( $brand_h_pct_val / 100.0 ) ) );

		// Proportional split between heading and hook for font-sizing caps.
		// These proportions mirror the CSS flex layout: heading-section takes content height,
		// description-section (hook) gets the remainder via flex:1.
		$heading_prop = isset( $brand['heading_height_proportion'] ) && $brand['heading_height_proportion'] !== '' ? floatval( $brand['heading_height_proportion'] ) : 21.0;
		$desc_prop    = isset( $brand['desc_height_proportion'] ) && $brand['desc_height_proportion'] !== '' ? floatval( $brand['desc_height_proportion'] ) : 10.0;
		if ( empty( $hook ) ) {
			$heading_prop += $desc_prop;
			$desc_prop = 0.0;
		}
		$total_prop = $heading_prop + $desc_prop;
		$heading_ratio = $total_prop > 0 ? ( $heading_prop / $total_prop ) : 1.0;
		$hook_ratio    = $total_prop > 0 ? ( $desc_prop / $total_prop ) : 0.0;

		$heading_padding  = $is_urdu ? 12 : 44; // Urdu uses clamp(4px,0.6cqh,8px) vertical ≈ 12px total
		$hook_padding     = 24; // hook block padding estimation
		$available_heading_h = max( 0, (int) round( $text_container_h * $heading_ratio ) - $heading_padding );
		$available_hook_h    = max( 0, (int) round( $text_container_h * $hook_ratio ) - $hook_padding );

		$headline_line_height = $is_urdu ? '1.60' : '1.25';
		$hook_line_height     = $is_urdu ? '1.65' : '1.4';
		$word_break_mode      = $is_urdu ? 'normal' : 'break-word';
		$overflow_wrap_mode   = $is_urdu ? 'normal' : 'break-word';

		$headline_font_size = self::compute_adaptive_font_size( $headline_char_count, $is_urdu, 'headline' );
		$hook_font_size     = self::compute_adaptive_font_size( $hook_char_count, $is_urdu, 'hook' );

		// Apply space scale and preset multiplier
		$headline_font_size = (int) round( $headline_font_size * $space_scale * $preset_heading_mult );
		$hook_font_size     = (int) round( $hook_font_size * $space_scale * $preset_hook_mult );

		// Height-based font size cap: shrink font until text fits in available height,
		// then grow font to fill the space if there's room.
		$hl_lh_float   = (float) $headline_line_height;
		$hl_font_ceil  = $is_urdu ? 180 : 84;
		$est_hl_lines  = self::estimate_line_count( $headline_char_count, $headline_font_size, $is_urdu, $width );
		$max_hl_lines  = max( 1, (int) floor( $available_heading_h / ( $headline_font_size * $hl_lh_float ) ) );

		if ( $est_hl_lines > $max_hl_lines ) {
			// Shrink: font too large for available height.
			$test_fs = $headline_font_size;
			while ( $test_fs > 48 ) {
				$test_fs -= 2;
				$test_lines = self::estimate_line_count( $headline_char_count, $test_fs, $is_urdu, $width );
				$test_max   = max( 1, (int) floor( $available_heading_h / ( $test_fs * $hl_lh_float ) ) );
				if ( $test_lines <= $test_max ) {
					break;
				}
			}
			$headline_font_size = max( 48, $test_fs );
		}

		// Growth: if text fits easily, enlarge font to fill available height.
		while ( $headline_font_size < $hl_font_ceil ) {
			$growth_fs = $headline_font_size + 2;
			$growth_lines = self::estimate_line_count( $headline_char_count, $growth_fs, $is_urdu, $width );
			$growth_max   = max( 1, (int) floor( $available_heading_h / ( $growth_fs * $hl_lh_float ) ) );
			if ( $growth_lines <= $growth_max ) {
				$headline_font_size = $growth_fs;
			} else {
				break;
			}
		}

		$hook_lh_float = (float) $hook_line_height;
		$hk_font_ceil  = $is_urdu ? 42 : 48;
		$est_hk_lines  = self::estimate_line_count( $hook_char_count, $hook_font_size, $is_urdu, $width );
		$max_hk_lines  = max( 1, (int) floor( $available_hook_h / ( $hook_font_size * $hook_lh_float ) ) );

		if ( $est_hk_lines > $max_hk_lines ) {
			// Shrink: font too large for available height.
			$test_fs = $hook_font_size;
			while ( $test_fs > 22 ) {
				$test_fs -= 2;
				$test_lines = self::estimate_line_count( $hook_char_count, $test_fs, $is_urdu, $width );
				$test_max   = max( 1, (int) floor( $available_hook_h / ( $test_fs * $hook_lh_float ) ) );
				if ( $test_lines <= $test_max ) {
					break;
				}
			}
			$hook_font_size = max( 22, $test_fs );
		}

		// Growth: if text fits easily, enlarge font to fill available height.
		while ( $hook_font_size < $hk_font_ceil ) {
			$growth_fs = $hook_font_size + 2;
			$growth_lines = self::estimate_line_count( $hook_char_count, $growth_fs, $is_urdu, $width );
			$growth_max   = max( 1, (int) floor( $available_hook_h / ( $growth_fs * $hook_lh_float ) ) );
			if ( $growth_lines <= $growth_max ) {
				$hook_font_size = $growth_fs;
			} else {
				break;
			}
		}

		$est_headline_fs = $headline_font_size;
		$est_hook_fs     = $hook_font_size;

		$headline_line_count = self::estimate_line_count( $headline_char_count, $est_headline_fs, $is_urdu, $width );
		$hook_line_count     = self::estimate_line_count( $hook_char_count, $est_hook_fs, $is_urdu, $width );

		// Dynamic image expansion: if actual text is much shorter than available space,
		// expand the image to reduce the empty text container background.
		// This prevents "huge heading background" when heading is 1-2 lines.
		// Only updates $image_h_ratio (consumed at line 368+) and $available_heading_h /
		// $available_hook_h (consumed at line 279 for line count caps).
		$actual_heading_h = $headline_line_count * $est_headline_fs * $hl_lh_float + $heading_padding;
		$actual_hook_h    = $hook_line_count * $est_hook_fs * $hook_lh_float + $hook_padding;
		$actual_text_h    = $actual_heading_h + $actual_hook_h;

		if ( $text_container_h > 0 && $actual_text_h > 0 && $actual_text_h < $text_container_h * 0.60 ) {
			$needed_text_h = $actual_text_h / 0.60; // Target 60% usage for breathing room
			$needed_text_pct = $needed_text_h / $height;
			// Raise cap to 0.82 when text is very short (less than 35% of text container)
			// to prevent excessive black background behind short headlines.
			$dynamic_cap = $actual_text_h < $text_container_h * 0.35 ? 0.82 : 0.75;
			$new_image_h = min( $dynamic_cap, 1.0 - $needed_text_pct - ( $brand_h_pct_val / 100.0 ) );

			if ( $new_image_h > $image_h_ratio ) {
				$image_h_ratio = $new_image_h;
				// Recompute text container height for line count caps
				$text_container_h = (int) round( $height * ( 1.0 - $image_h_ratio - ( $brand_h_pct_val / 100.0 ) ) );
				$available_heading_h = max( 0, (int) round( $text_container_h * $heading_ratio ) - $heading_padding );
				$available_hook_h = max( 0, (int) round( $text_container_h * $hook_ratio ) - $hook_padding );
			}
		}

		// Final line count caps
		$max_headline_lines = max( 1, (int) floor( $available_heading_h / ( $est_headline_fs * $hl_lh_float ) ) );
		$max_hook_lines     = max( 1, (int) floor( $available_hook_h / ( $est_hook_fs * $hook_lh_float ) ) );

		$headline_line_count = min( $headline_line_count, $max_headline_lines );
		$hook_line_count     = min( $hook_line_count, $max_hook_lines );

		$headline_font = $brand['font_headline'] ?? Config::DEFAULT_BRAND_FONT_HEADLINE;
		$body_font     = $brand['font_body']     ?? Config::DEFAULT_BRAND_FONT_BODY;
		
		// REMOVED hardcoded override of user's Noto Nastaliq Urdu selection.
		// If user selected Jameel Noori Nastaliq in brand settings, we respect it.

		$font_specs = Config::get_available_fonts();
		$headline_spec = $font_specs[ $headline_font ] ?? [ 'weight' => '800', 'fallback' => 'sans-serif', 'self_hosted' => false ];
		$body_spec     = $font_specs[ $body_font ]     ?? [ 'weight' => '700', 'fallback' => 'sans-serif', 'self_hosted' => false ];

		$primary_color   = $colors['primary']   ?? $brand['primary_color']   ?? Config::DEFAULT_BRAND_PRIMARY_COLOR;
		$secondary_color = $colors['secondary'] ?? $brand['secondary_color'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR;
		$accent_color    = $colors['accent']    ?? $brand['accent_color']    ?? Config::DEFAULT_BRAND_ACCENT_COLOR;
		$emphasis_color  = $colors['emphasis']  ?? $brand['emphasis_color']  ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR;
		$key_term_color  = $colors['key_term']  ?? $brand['key_term_color']  ?? Config::DEFAULT_BRAND_KEY_TERM_COLOR;
		$breaking_color  = $colors['breaking']  ?? $brand['breaking_color']  ?? Config::DEFAULT_BRAND_BREAKING_COLOR;
		$text_backing    = $colors['text_backing'] ?? $brand['text_backing_color'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR;
		$overlay_opacity = floatval( $colors['overlay_opacity'] ?? 0.7 );

		$text_color = self::compute_contrast_text_color( $text_backing );
		$badge_text_color = self::compute_contrast_text_color( $accent_color );
		$secondary_color = self::ensure_readable_on_dark( $secondary_color, $text_backing );
		$css_position = $focal['css_position'] ?? '50% 33%';

		$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;
		$logo_html = '';
		if ( ! empty( $brand['logo_url'] ) ) {
			$logo_html = '<img src="' . esc_url( $brand['logo_url'] ) . '" alt="">';
		}

		$brand_name = $brand['brand_name'] ?? '';
		$brand_url = $brand['brand_url'] ?? '';
		$branding_footer = '';
		if ( ! empty( $brand_url ) ) {
			$branding_footer = '<a href="' . esc_url( $brand_url ) . '" target="_blank" rel="noopener">' . esc_html( $brand_url ) . '</a>';
		}

		// Category badge — derived from AI category, with template fallback
		$category_badge = $job_data['category_badge'] ?? '';
		if ( empty( $category_badge ) ) {
			$category = $job_data['category'] ?? '';
			if ( ! empty( $category ) ) {
				$badge_map = Config::get_category_badge_map();
				$category_badge = $badge_map[ $category ] ?? 'خبر';
			} else {
				$fallback_map = [
					'news-card'  => 'خبر',
					'dual-photo' => 'خبر',
					'text-heavy' => 'بیان',
				];
				$category_badge = $fallback_map[ $template ] ?? 'خبر';
			}
		}

		// Photo labels for dual-photo template
		$photo_label_1 = $job_data['photo_label_1'] ?? '';
		$photo_label_2 = $job_data['photo_label_2'] ?? '';

		// Attribution for text-heavy template
		$attribution = $job_data['attribution'] ?? '';

		// EYEBROW and key_terms from AI output
		$eyebrow = $job_data['eyebrow'] ?? '';
		$key_terms = $job_data['key_terms'] ?? [];
		$key_terms_html = '';
		if ( ! empty( $key_terms ) && is_array( $key_terms ) ) {
			$key_terms_escaped = array_map( static fn( $t ) => esc_html( $t ), array_slice( $key_terms, 0, 3 ) );
			$key_terms_html = '<span class="key-terms">' . implode( ' • ', $key_terms_escaped ) . '</span>';
		}

		$emphasis_word = $job_data['emphasis_word'] ?? '';
		$headline_with_emphasis = $this->apply_emphasis_to_headline( $headline, $emphasis_word );

		$google_fonts = $this->build_google_fonts_url( $headline_font, $body_font, $headline_spec, $body_spec );
		$self_hosted_css = $this->build_self_hosted_font_css( $headline_font, $body_font, $headline_spec, $body_spec );

		$dark_backing_css = 'background:' . $text_backing . ';';

		// Evidence box HTML (for templates that support a second image)
		$image_url_2 = $job_data['image_url_2'] ?? '';

		// Calculate percentages
		$image_h_pct = $image_h_ratio * 100;
		$brand_h_pct = isset( $brand['brand_bar_height_pct'] ) && $brand['brand_bar_height_pct'] !== '' ? floatval( $brand['brand_bar_height_pct'] ) : 10.0;
		$separator_h_pct = isset( $brand['brand_separator_height_pct'] ) && $brand['brand_separator_height_pct'] !== '' ? floatval( $brand['brand_separator_height_pct'] ) : 2.0;
		$text_h_pct = ( 1.0 - $image_h_ratio ) * 100;

		$remaining_text_h_pct = max( 0.0, $text_h_pct - $brand_h_pct - $separator_h_pct );

		// Reuse proportions computed earlier for font-sizing caps.
		$desc_display_css = empty( $hook ) ? 'none' : 'flex';
		$heading_h_pct = $remaining_text_h_pct * $heading_ratio;
		$desc_h_pct = $remaining_text_h_pct * $hook_ratio;

		$heading_top_pct = $image_h_pct + $separator_h_pct;
		$desc_top_pct = $image_h_pct + $separator_h_pct + $heading_h_pct;
		$overlay_bottom_pct = 100.0 - $image_h_pct;
		$text_block_height_pct = $remaining_text_h_pct;

		// Resolve styles with fallbacks (with adjusted default vertical padding for Urdu)
		$heading_font_size_css  = (string) $headline_font_size . 'px';
		$heading_line_height_css = ( ! empty( $brand['heading_line_height'] ) ) ? $brand['heading_line_height'] : $headline_line_height;
		$heading_padding_css     = ( ! empty( $brand['heading_padding'] ) ) ? $brand['heading_padding'] : 'clamp(2px,0.3cqh,4px) clamp(10px,1.5cqw,16px) clamp(2px,0.3cqh,4px) clamp(10px,1.5cqw,16px)';
		$heading_bg_color_css    = ( ! empty( $brand['heading_bg_color'] ) ) ? $brand['heading_bg_color'] : $text_backing;
		$heading_text_color_css   = ( ! empty( $brand['heading_text_color'] ) ) ? $brand['heading_text_color'] : $text_color;

		$desc_font_size_css      = (string) $hook_font_size . 'px';
		$desc_line_height_css    = ( ! empty( $brand['desc_line_height'] ) ) ? $brand['desc_line_height'] : $hook_line_height;
		$desc_padding_css        = ( ! empty( $brand['desc_padding'] ) ) ? $brand['desc_padding'] : ( $is_urdu ? 'clamp(10px,1.5cqh,16px) clamp(14px,2cqw,24px)' : '4px 0 0 0' );
		$desc_bg_color_css       = ( ! empty( $brand['desc_bg_color'] ) ) ? $brand['desc_bg_color'] : $breaking_color;
		$desc_text_color_css      = ( ! empty( $brand['desc_text_color'] ) ) ? $brand['desc_text_color'] : $secondary_color;

		$brand_bar_padding_css    = ( ! empty( $brand['brand_bar_padding'] ) ) ? $brand['brand_bar_padding'] : '0 clamp(14px,2cqw,24px)';
		$brand_bar_bg_color_css   = ( ! empty( $brand['brand_bar_bg_color'] ) ) ? $brand['brand_bar_bg_color'] : 'rgba(0,0,0,0.45)';
		$brand_bar_text_color_css  = ( ! empty( $brand['brand_bar_text_color'] ) ) ? $brand['brand_bar_text_color'] : $text_color;
		$brand_bar_font_size_css  = ( ! empty( $brand['brand_bar_font_size'] ) ) ? $brand['brand_bar_font_size'] . 'px' : Config::DEFAULT_BRAND_BAR_FONT_SIZE . 'px';
		$brand_bar_letter_spacing_css = ( ! empty( $brand['brand_bar_letter_spacing'] ) ) ? $brand['brand_bar_letter_spacing'] . 'px' : Config::DEFAULT_BRAND_BAR_LETTER_SPACING . 'px';
		$brand_bar_accent_line_css   = ( isset( $brand['brand_bar_accent_line'] ) && $brand['brand_bar_accent_line'] === '1' ) ? '1px solid ' . $accent_color : 'none';

		$logo_max_height_bottom_css = ( ! empty( $brand['logo_max_height_bottom'] ) ) ? $brand['logo_max_height_bottom'] : 'clamp(18px,2.5cqh,26px)';
		$logo_max_width_bottom_css  = ( ! empty( $brand['logo_max_width_bottom'] ) ) ? $brand['logo_max_width_bottom'] : 'clamp(60px,10cqw,100px)';
		$logo_max_height_top_css    = ( ! empty( $brand['logo_max_height_top'] ) ) ? $brand['logo_max_height_top'] : 'clamp(24px,3cqh,34px)';
		$logo_max_width_top_css     = ( ! empty( $brand['logo_max_width_top'] ) ) ? $brand['logo_max_width_top'] : 'clamp(70px,11cqw,110px)';

		return [
			'{{IMAGE_HEIGHT_PCT}}'      => (string) $image_h_pct,
			'{{SEPARATOR_HEIGHT_PCT}}'  => (string) $separator_h_pct,
			'{{HEADING_HEIGHT_PCT}}'    => (string) $heading_h_pct,
			'{{DESC_HEIGHT_PCT}}'       => (string) $desc_h_pct,
			'{{BRAND_HEIGHT_PCT}}'      => (string) $brand_h_pct,
			'{{HEADING_TOP_PCT}}'       => (string) $heading_top_pct,
			'{{DESC_TOP_PCT}}'          => (string) $desc_top_pct,
			'{{OVERLAY_BOTTOM_PCT}}'    => (string) $overlay_bottom_pct,
			'{{TEXT_BLOCK_HEIGHT_PCT}}' => (string) $text_block_height_pct,
			'{{DESC_DISPLAY_CSS}}'      => $desc_display_css,
			'{{RENDER_WIDTH}}'          => (string) $width,
			'{{RENDER_HEIGHT}}'         => (string) $height,
			'{{IMAGE_URL}}'             => $job_data['image_url'] ?? '',
			'{{IMAGE_URL_2}}'           => $image_url_2,
			'{{IMAGE_URL_3}}'           => $job_data['image_url_3'] ?? '',
			'{{IMAGE_URL_4}}'           => $job_data['image_url_4'] ?? '',
			'{{HEADLINE}}'              => $headline_with_emphasis,
			'{{HOOK}}'                  => htmlspecialchars( $hook, ENT_QUOTES, 'UTF-8' ),
			'{{FOCAL_POSITION}}'        => $css_position,
			'{{EMPHASIS_COLOR}}'        => $emphasis_color,
			'{{KEY_TERM_COLOR}}'        => $key_term_color,
			'{{IMAGE_URL_BLUR}}'        => $job_data['image_url'] ?? '',
			'{{TEXT_COLOR}}'            => $text_color,
			'{{ACCENT_COLOR}}'          => $accent_color,
			'{{SECONDARY_COLOR}}'       => $secondary_color,
			'{{PRIMARY_COLOR}}'         => $primary_color,
			'{{BREAKING_COLOR}}'        => $breaking_color,
			'{{TEXT_BACKING_COLOR}}'    => $text_backing,
			'{{OVERLAY_OPACITY}}'       => (string) $overlay_opacity,
			'{{HEADLINE_FONT}}'         => $headline_font,
			'{{HEADLINE_FONT_FALLBACK}}' => $headline_spec['fallback'] ?? 'sans-serif',
			'{{HEADLINE_FONT_WEIGHT}}'   => $headline_spec['weight'] ?? '800',
			'{{BODY_FONT}}'             => $body_font,
			'{{BODY_FONT_FALLBACK}}'    => $body_spec['fallback'] ?? 'sans-serif',
			'{{BODY_FONT_WEIGHT}}'      => $body_spec['weight'] ?? '700',
			'{{DARK_BACKING_CSS}}'      => $dark_backing_css,
			'{{LOGO_POSITION}}'         => $logo_position,
			'{{LOGO_HTML}}'             => $logo_html,
			'{{BRAND_NAME}}'            => esc_html( $brand_name ),
			'{{BRAND_URL}}'             => esc_url( $brand_url ),
			'{{BRANDING_FOOTER}}'       => $branding_footer,
			'{{GOOGLE_FONTS_URL}}'      => $google_fonts,
			'{{SELF_HOSTED_FONT_CSS}}'  => $self_hosted_css,
			'{{TEXT_SHADOW}}'           => '1px 1px 3px rgba(0,0,0,0.8)',
			'{{EYEBROW}}'               => esc_html( $eyebrow ),
			'{{KEY_TERMS_HTML}}'        => $key_terms_html,
			'{{CATEGORY_BADGE}}'        => esc_html( $category_badge ),
			'{{PHOTO_LABEL_1}}'         => esc_html( $photo_label_1 ),
			'{{PHOTO_LABEL_2}}'         => esc_html( $photo_label_2 ),
			'{{ATTRIBUTION}}'           => esc_html( $attribution ),
			'{{HEADLINE_FONT_SIZE}}'    => (string) $headline_font_size,
			'{{HOOK_FONT_SIZE}}'        => (string) $hook_font_size,
			'{{HEADLINE_LINE_COUNT}}'   => (string) $headline_line_count,
			'{{HOOK_LINE_COUNT}}'       => (string) $hook_line_count,
			'{{HEADLINE_LINE_HEIGHT}}'  => $headline_line_height,
			'{{HOOK_LINE_HEIGHT}}'      => $hook_line_height,
			'{{WORD_BREAK_MODE}}'       => $word_break_mode,
			'{{OVERFLOW_WRAP_MODE}}'    => $overflow_wrap_mode,
			'{{LANGUAGE_CLASS}}'        => $is_urdu ? 'lang-ur' : 'lang-en',
			'{{IS_URDU}}'               => $is_urdu ? 'true' : 'false',
			'{{HTML_DIR}}'              => $is_urdu ? 'rtl' : 'ltr',
			'{{BADGE_TEXT_COLOR}}'      => $badge_text_color,

			// Customizable tokens
			'{{HEADING_FONT_SIZE_CSS}}'  => $heading_font_size_css,
			'{{HEADING_LINE_HEIGHT_CSS}}' => $heading_line_height_css,
			'{{HEADING_PADDING_CSS}}'     => $heading_padding_css,
			'{{HEADING_BG_COLOR_CSS}}'    => $heading_bg_color_css,
			'{{HEADING_TEXT_COLOR_CSS}}'   => $heading_text_color_css,

			'{{DESC_FONT_SIZE_CSS}}'      => $desc_font_size_css,
			'{{DESC_LINE_HEIGHT_CSS}}'    => $desc_line_height_css,
			'{{DESC_PADDING_CSS}}'        => $desc_padding_css,
			'{{DESC_BG_COLOR_CSS}}'       => $desc_bg_color_css,
			'{{DESC_TEXT_COLOR_CSS}}'      => $desc_text_color_css,

			'{{BRAND_BAR_PADDING_CSS}}'    => $brand_bar_padding_css,
			'{{BRAND_BAR_BG_COLOR_CSS}}'   => $brand_bar_bg_color_css,
			'{{BRAND_BAR_TEXT_COLOR_CSS}}'  => $brand_bar_text_color_css,
			'{{BRAND_BAR_FONT_SIZE_CSS}}'  => $brand_bar_font_size_css,
			'{{BRAND_BAR_LETTER_SPACING_CSS}}' => $brand_bar_letter_spacing_css,
			'{{BRAND_BAR_ACCENT_LINE_CSS}}'    => $brand_bar_accent_line_css,

			'{{LOGO_MAX_HEIGHT_BOTTOM_CSS}}' => $logo_max_height_bottom_css,
			'{{LOGO_MAX_WIDTH_BOTTOM_CSS}}'  => $logo_max_width_bottom_css,
			'{{LOGO_MAX_HEIGHT_TOP_CSS}}'    => $logo_max_height_top_css,
			'{{LOGO_MAX_WIDTH_TOP_CSS}}'     => $logo_max_width_top_css,
		];
	}

	/**
	 * Build Google Fonts import URL for the two fonts used.
	 */
	private function build_google_fonts_url( string $headline_font, string $body_font, array $headline_spec, array $body_spec ): string {
		$fonts = [];
		$unique = [];

		if ( empty( $headline_spec['self_hosted'] ) ) {
			$key = $headline_font . ':' . ( $headline_spec['weight'] ?? '800' );
			if ( ! isset( $unique[ $key ] ) ) {
				$fonts[] = $headline_font . ':' . ( $headline_spec['weight'] ?? '800' );
				$unique[ $key ] = true;
			}
		}
		if ( $body_font !== $headline_font && empty( $body_spec['self_hosted'] ) ) {
			$key = $body_font . ':' . ( $body_spec['weight'] ?? '700' );
			if ( ! isset( $unique[ $key ] ) ) {
				$fonts[] = $body_font . ':' . ( $body_spec['weight'] ?? '700' );
				$unique[ $key ] = true;
			}
		}

		if ( empty( $fonts ) ) {
			return '';
		}

		return 'https://fonts.googleapis.com/css2?' . http_build_query( [ 'family' => implode( '&family=', $fonts ) ] ) . '&display=swap';
	}

/**
 * Build @font-face CSS for self-hosted fonts.
 * Checks VPS system fonts first, then plugin assets.
 */
private function build_self_hosted_font_css( string $headline_font, string $body_font, array $headline_spec, array $body_spec ): string {
$css_parts = [];
$unique = [];

// VPS system font paths (checked first)
$vps_font_paths = [
'/usr/share/fonts/dit-trendstudio/',
'/usr/local/share/fonts/dit-trendstudio/',
'/usr/share/fonts/truetype/noto/',
];

// Plugin assets (fallback)
$plugin_fonts_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts';

if ( ! empty( $headline_spec['self_hosted'] ) ) {
$font_file = $this->resolve_font_filename( $headline_font );
if ( $font_file && ! isset( $unique[ $font_file ] ) ) {
$css_parts[] = $this->font_face_css_with_paths( $headline_font, $font_file, $vps_font_paths, $plugin_fonts_dir, $headline_spec['weight'] ?? '400' );
$unique[ $font_file ] = true;
}
}
if ( $body_font !== $headline_font && ! empty( $body_spec['self_hosted'] ) ) {
$font_file = $this->resolve_font_filename( $body_font );
if ( $font_file && ! isset( $unique[ $font_file ] ) ) {
$css_parts[] = $this->font_face_css_with_paths( $body_font, $font_file, $vps_font_paths, $plugin_fonts_dir, $body_spec['weight'] ?? '400' );
$unique[ $font_file ] = true;
}
}

return implode( "\n", $css_parts );
}

	private function resolve_font_filename( string $font_family ): string {
		$map = [
			'Noto Nastaliq Urdu'    => 'NotoNastaliqUrdu-Regular.ttf',
			'Jameel Noori Nastaliq' => 'JameelNooriNastaliq.ttf',
			'Nafees Web Naskh'      => 'NafeesWebNaskh.ttf',
			'Noto Sans Arabic'      => 'NotoSansArabic-Regular.ttf',
		];
		return $map[ $font_family ] ?? '';
	}

private function font_face_css_with_paths( string $family, string $filename, array $vps_paths, string $plugin_fonts_dir, string $weight ): string {
$font_url = '';

// Check VPS system font paths first
foreach ( $vps_paths as $vps_path ) {
$test_path = $vps_path . $filename;
if ( file_exists( $test_path ) ) {
$font_url = 'file://' . $test_path;
break;
}
}

// If not found in VPS paths, check plugin assets
if ( empty( $font_url ) ) {
$plugin_path = $plugin_fonts_dir . '/' . $filename;
if ( file_exists( $plugin_path ) ) {
$font_url = 'file://' . $plugin_path;
}
}

if ( empty( $font_url ) ) {
return '';
}

return sprintf(
'@font-face{font-family:\'%s\';src:url(\'%s\') format(\'truetype\');font-weight:%s;font-style:normal;font-display:swap;}',
$family,
$font_url,
$weight
);
}

	/**
	 * Call the Node.js + Puppeteer render script via proc_open() with stream timeout.
	 * Prevents indefinite blocking when Chromium hangs (GPU contention, shared-memory
	 * exhaustion from co-located Puppeteer scripts, etc.).
	 */
	private function call_chromium( string $html_file, string $output_png, int $width, int $height, int $job_id ): bool {
		if ( ! Config::file_exists_robust( Config::NODE_PATH ) ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_id, [ 'path' => Config::NODE_PATH ], '500' );
			return false;
		}
		if ( ! Config::file_exists_robust( Config::RENDER_SCRIPT ) ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_id, [ 'path' => Config::RENDER_SCRIPT ], '500' );
			return false;
		}

		$descriptors = [
			0 => [ 'pipe', 'r' ],
			1 => [ 'pipe', 'w' ],
			2 => [ 'pipe', 'w' ],
		];

		$cmd = sprintf(
			'%s %s %s %s %d %d',
			escapeshellarg( Config::NODE_PATH ),
			escapeshellarg( Config::RENDER_SCRIPT ),
			escapeshellarg( $html_file ),
			escapeshellarg( $output_png ),
			$width,
			$height
		);

		Logger::info( Config::LOG_ACTION_CHROMIUM_RENDER_START, $job_id, [
			'html_file'  => basename( $html_file ),
			'output_png' => basename( $output_png ),
			'dimensions' => $width . 'x' . $height,
			'timeout'    => Config::CHROMIUM_RENDER_TIMEOUT,
		], '200' );

		$start = microtime( true );
		$process = @proc_open( $cmd, $descriptors, $pipes );

		if ( ! is_resource( $process ) ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_id, [
				'error' => 'proc_open failed to launch process',
			], '500' );
			return false;
		}

		$timeout = Config::CHROMIUM_RENDER_TIMEOUT;
		$output_lines = [];
		$timed_out = false;

		stream_set_timeout( $pipes[1], $timeout );
		stream_set_timeout( $pipes[2], $timeout );

		$stdout = '';
		$stderr = '';
		$deadline = $start + $timeout;

		while ( !feof( $pipes[1] ) || !feof( $pipes[2] ) ) {
			$remaining = $deadline - microtime( true );
			if ( $remaining <= 0 ) {
				$timed_out = true;
				break;
			}

			$read = [];
			if ( !feof( $pipes[1] ) ) {
				$read[] = $pipes[1];
			}
			if ( !feof( $pipes[2] ) ) {
				$read[] = $pipes[2];
			}
			if ( empty( $read ) ) {
				break;
			}

			$except = null;
			$changed = @stream_select( $read, $except, $except, (int) ceil( min( $remaining, 2.0 ) ) * 1000000 );

			if ( $changed === false ) {
				break;
			}
			if ( $changed === 0 ) {
				$timed_out = true;
				break;
			}

			foreach ( $read as $stream ) {
				$chunk = @fread( $stream, 8192 );
				if ( $chunk === false || $chunk === '' ) {
					continue;
				}
				if ( $stream === $pipes[1] ) {
					$stdout .= $chunk;
				} else {
					$stderr .= $chunk;
				}
			}
		}

		if ( $timed_out ) {
			proc_terminate( $process, 9 );
			proc_close( $process );
			$elapsed = microtime( true ) - $start;
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_id, [
				'error'   => 'render_timed_out',
				'elapsed' => round( $elapsed, 2 ),
				'timeout' => $timeout,
				'stderr'  => substr( $stderr, -500 ),
			], '500' );
			return false;
		}

		fclose( $pipes[0] );
		fclose( $pipes[1] );
		fclose( $pipes[2] );
		$ret = proc_close( $process );
		$elapsed = microtime( true ) - $start;

		$output_json = trim( $stdout );
		$result = json_decode( $output_json, true );

		if ( $ret !== 0 || empty( $result['success'] ) ) {
			Logger::error( Config::LOG_ACTION_CHROMIUM_RENDER_FAILED, $job_id, [
				'error'    => $result['error'] ?? ( $stderr !== '' ? substr( $stderr, -500 ) : 'unknown' ),
				'output'   => substr( $output_json, -1000 ),
				'return'   => $ret,
				'elapsed'  => round( $elapsed, 2 ),
			], '500' );
			return false;
		}

		Logger::info( Config::LOG_ACTION_CHROMIUM_RENDER_SUCCESS, $job_id, [
			'bytes'   => $result['bytes'] ?? 0,
			'elapsed' => round( $elapsed, 2 ),
		], '200', '', $elapsed );

		return true;
	}

	public static function compute_adaptive_font_size( int $char_count, bool $is_urdu, string $element ): int {
		if ( $element === 'headline' ) {
			if ( $is_urdu ) {
				// FIX: Increased font sizes significantly since the description is removed
				// and the heading has the full area. Nastaliq looks much better when big.
				// Further increased base from 96->105, min from 48->52 for larger Urdu text.
				if ( $char_count <= 40 ) {
					return 105; 
				}
				$size = 105 - ( ( $char_count - 40 ) * ( 105 - 52 ) / ( 130 - 40 ) );
				return max( 52, (int) round( $size ) );
			}
			if ( $char_count <= 30 ) {
				return 84;
			}
			$size = 84 - ( ( $char_count - 30 ) * ( 84 - 44 ) / ( 120 - 30 ) );
			return max( 44, (int) round( $size ) );
		}

		if ( $element === 'hook' ) {
			if ( $is_urdu ) {
				if ( $char_count <= 60 ) {
					return 36;
				}
				$size = 36 - ( ( $char_count - 60 ) * ( 36 - 22 ) / ( 180 - 60 ) );
				return max( 22, (int) round( $size ) );
			}
			if ( $char_count <= 100 ) {
				return 40;
			}
			$size = 40 - ( ( $char_count - 100 ) * ( 40 - 24 ) / ( 300 - 100 ) );
			return max( 24, (int) round( $size ) );
		}

		return $is_urdu ? 28 : 32;
	}

	private static function estimate_line_count( int $char_count, int $font_size, bool $is_urdu, int $canvas_width = 1080 ): int {
		// Use actual container width (canvas minus padding: ~6% each side = 12% total)
		$container_width = $canvas_width - (int)( $canvas_width * 0.12 );
		if ( $is_urdu ) {
			// Nastaliq Urdu: connected script with keshidas and diacritics.
			// Real effective glyph width is ~0.25x font size due to vertical stacking and cursive overlap.
			$estimated_width = $char_count * ( $font_size * 0.33 );
			return (int) max( 1, ceil( $estimated_width / $container_width ) );
		} else {
			// Latin/English: more compact
			$chars_per_line = max( 15, (int) ( $container_width / ( $font_size * 0.55 ) ) );
		}
		return max( 1, (int) ceil( $char_count / $chars_per_line ) );
	}

private static function compute_contrast_text_color( string $bg_hex ): string {
		$bg_hex = ltrim( $bg_hex, '#' );
		if ( strlen( $bg_hex ) !== 6 || ! ctype_xdigit( $bg_hex ) ) {
			return '#ffffff';
		}
		$r = hexdec( substr( $bg_hex, 0, 2 ) );
		$g = hexdec( substr( $bg_hex, 2, 2 ) );
		$b = hexdec( substr( $bg_hex, 4, 2 ) );
		$brightness = ( $r * 299 + $g * 587 + $b * 114 ) / 1000;
		return $brightness > 128 ? '#1a1a1a' : '#ffffff';
	}

	private static function ensure_readable_on_dark( string $color_hex, string $bg_hex ): string {
		$bg_brightness = self::hex_brightness( $bg_hex );
		$color_brightness = self::hex_brightness( $color_hex );
		if ( $bg_brightness < 100 && $color_brightness < 150 ) {
			return '#ffffff';
		}
		return $color_hex;
	}

	private static function hex_brightness( string $hex ): int {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return 0;
		}
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );
		return (int) ( ( $r * 299 + $g * 587 + $b * 114 ) / 1000 );
	}

	private function apply_emphasis_to_headline( string $headline, string $emphasis_word ): string {
		if ( empty( $emphasis_word ) || mb_strlen( trim( $emphasis_word ), 'UTF-8' ) < 2 ) {
			return $headline;
		}

		$emphasis_word = trim( $emphasis_word );

		if ( stripos( $headline, $emphasis_word ) === false ) {
			return $headline;
		}

		$emphasis_color = $this->get_brand_emphasis_color();
		$escaped = preg_quote( $emphasis_word, '/' );
		$pattern = '/(' . $escaped . ')/iu';
		$replacement = '<span class="text-highlight" style="color:' . esc_attr( $emphasis_color ) . ';">$1</span>';

		$result = preg_replace( $pattern, $replacement, $headline, 1 );

		if ( $result === null ) {
			return $headline;
		}

		return $result;
	}

	private function get_brand_emphasis_color(): string {
		$brand = Config::get_brand_settings();
		return $brand['emphasis_color'] ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR;
	}

	private static function parse_font_size_to_int( $font_size_str, int $default_fallback ): int {
		if ( empty( $font_size_str ) ) {
			return $default_fallback;
		}
		if ( preg_match( '/\d+/', $font_size_str, $matches ) ) {
			return (int) $matches[0];
		}
		return $default_fallback;
	}
}
