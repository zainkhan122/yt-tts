<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Cloudflare R2 Storage Client (S3 Compatible)
 *
 * Handles uploading video files to Cloudflare R2 / S3.
 * Implements S3 Signature V4 for PutObject.
 */
class R2Storage {

    private $endpoint;
    private $access_key;
    private $secret_key;
    private $bucket;
    private $region = 'auto';

    public function __construct() {
        $this->endpoint   = Config::get_r2_endpoint();
        $this->access_key = Config::get_r2_access_key();
        $this->secret_key = Config::get_r2_secret_key();
        $this->bucket     = Config::get_r2_bucket();
    }

    /**
     * Upload a file to R2.
     *
     * @param string $file_path Local path to file.
     * @param string $key Remote key (path in bucket).
     * @param string $content_type Mime type.
     * @return string|WP_Error Public URL on success, WP_Error on failure.
     */
    public function upload_file( string $file_path, string $key, string $content_type = 'video/mp4' ) {
        if ( empty( $this->access_key ) || empty( $this->secret_key ) || empty( $this->endpoint ) ) {
            Logger::log( 'R2 Upload: Missing Config', 'error', [ 'endpoint' => $this->endpoint ? 'set' : 'empty', 'bucket' => $this->bucket ? 'set' : 'empty' ] );
            return new \WP_Error( 'missing_config', 'R2/S3 Credentials missing. Configure in Settings > Buffer API > R2 Settings.' );
        }

        if ( empty( $this->bucket ) ) {
            Logger::log( 'R2 Upload: Missing Bucket', 'error' );
            return new \WP_Error( 'missing_bucket', 'R2 bucket not configured.' );
        }

        if ( ! file_exists( $file_path ) ) {
            Logger::log( 'R2 Upload: File not found', 'error', [ 'path' => $file_path ] );
            return new \WP_Error( 'file_not_found', 'File does not exist: ' . $file_path );
        }

        $file_size = filesize( $file_path );
        if ( $file_size === false || $file_size === 0 ) {
            Logger::log( 'R2 Upload: File empty or unreadable', 'error', [ 'path' => $file_path, 'size' => $file_size ] );
            return new \WP_Error( 'file_empty', 'File is empty or unreadable: ' . $file_path );
        }

        $uri  = '/' . $this->bucket . '/' . $key;
        $host = parse_url( $this->endpoint, PHP_URL_HOST );
        $url  = $this->endpoint . $uri;

        // Calculate payload hash
        $ctx = hash_init( 'sha256' );
        $stream = fopen( $file_path, 'rb' );
        if ( ! $stream ) {
            return new \WP_Error( 'open_failed', 'Cannot open file: ' . $file_path );
        }
        while ( ! feof( $stream ) ) {
            hash_update( $ctx, fread( $stream, 8192 ) );
        }
        $payload_hash = hash_final( $ctx );
        fclose( $stream );

        $timestamp = gmdate( 'Ymd\THis\Z' );
        $date      = gmdate( 'Ymd' );

        $headers = [
            'host'                => $host,
            'x-amz-content-sha256' => $payload_hash,
            'x-amz-date'          => $timestamp,
            'content-type'        => $content_type,
        ];

        ksort( $headers );
        $canonical_headers = '';
        $signed_headers    = '';
        foreach ( $headers as $k => $v ) {
            $canonical_headers .= $k . ':' . $v . "\n";
            $signed_headers    .= $k . ';';
        }
        $signed_headers = rtrim( $signed_headers, ';' );

        $canonical_request = "PUT\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

        $algorithm       = 'AWS4-HMAC-SHA256';
        $credential_scope = "{$date}/{$this->region}/s3/aws4_request";
        $string_to_sign  = "{$algorithm}\n{$timestamp}\n{$credential_scope}\n" . hash( 'sha256', $canonical_request );

        $k_secret = 'AWS4' . $this->secret_key;
        $k_date   = hash_hmac( 'sha256', $date, $k_secret, true );
        $k_region = hash_hmac( 'sha256', $this->region, $k_date, true );
        $k_service = hash_hmac( 'sha256', 's3', $k_region, true );
        $k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );
        $signature = hash_hmac( 'sha256', $string_to_sign, $k_signing );

        $authorization = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

        $ch = curl_init( $url );
        $fp = fopen( $file_path, 'rb' );
        if ( ! $fp ) {
            return new \WP_Error( 'open_failed', 'Cannot open file for upload: ' . $file_path );
        }

        curl_setopt_array( $ch, [
            CURLOPT_PUT            => true,
            CURLOPT_INFILE         => $fp,
            CURLOPT_INFILESIZE     => $file_size,
            CURLOPT_HTTPHEADER     => [
                "Authorization: {$authorization}",
                "x-amz-date: {$timestamp}",
                "x-amz-content-sha256: {$payload_hash}",
                "Content-Type: {$content_type}",
                "Host: {$host}",
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 300,
            CURLOPT_SSL_VERIFYPEER => true,
        ] );

        $start_time = microtime( true );
        $response_body = curl_exec( $ch );
        $duration      = microtime( true ) - $start_time;
        $http_code     = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error    = curl_error( $ch );
        fclose( $fp );
        curl_close( $ch );

        Logger::log( 'r2_upload', null, wp_json_encode( [ 'url' => $url, 'method' => 'PUT', 'key' => $key, 'size' => $file_size ] ), (string) $http_code, '', $duration, 'info' );

        if ( $curl_error ) {
            Logger::log( 'R2 Upload cURL Error', 'error', [ 'error' => $curl_error, 'key' => $key ] );
            return new \WP_Error( 'curl_error', $curl_error );
        }

        if ( $http_code !== 200 ) {
            $msg = 'R2 Upload Failed: ' . $http_code . ' ' . substr( $response_body, 0, 500 );
            Logger::log( 'R2 Upload Failed', 'error', [ 'code' => $http_code, 'msg' => $msg, 'key' => $key ] );
            return new \WP_Error( 'upload_failed', $msg );
        }

        $public_domain = Config::get_r2_public_domain();
        if ( $public_domain === '' ) {
            Logger::log( 'R2 Upload: Missing public domain', 'error', [
                'hint' => 'Configure the R2 public domain (Workers custom domain or public bucket) under Settings > Buffer API > R2 Settings.',
            ] );
            return new \WP_Error( 'missing_public_domain', 'R2 public domain not configured. Set the public-facing CDN URL in Settings > Buffer API > R2 Settings (`ai_collage_r2_public_domain`). Bucket/key are: ' . $this->bucket . '/' . $key );
        }

        return rtrim( $public_domain, '/' ) . '/' . $key;
    }

    /**
     * Delete an object from R2.
     *
     * @param string $key Remote key (path in bucket).
     * @return true|\WP_Error True when deleted or already absent, WP_Error on failure.
     */
    public function delete_object( string $key ) {
        if ( empty( $this->access_key ) || empty( $this->secret_key ) || empty( $this->endpoint ) || empty( $this->bucket ) ) {
            return new \WP_Error( 'missing_config', 'R2/S3 credentials or bucket missing.' );
        }

        $uri  = '/' . $this->bucket . '/' . $key;
        $host = parse_url( $this->endpoint, PHP_URL_HOST );
        $url  = $this->endpoint . $uri;

        // Empty body for DELETE.
        $payload_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

        $timestamp = gmdate( 'Ymd\THis\Z' );
        $date      = gmdate( 'Ymd' );

        $headers = [
            'host'                 => $host,
            'x-amz-content-sha256' => $payload_hash,
            'x-amz-date'           => $timestamp,
        ];

        ksort( $headers );
        $canonical_headers = '';
        $signed_headers    = '';
        foreach ( $headers as $k => $v ) {
            $canonical_headers .= $k . ':' . $v . "\n";
            $signed_headers    .= $k . ';';
        }
        $signed_headers = rtrim( $signed_headers, ';' );

        $canonical_request = "DELETE\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

        $algorithm        = 'AWS4-HMAC-SHA256';
        $credential_scope = "{$date}/{$this->region}/s3/aws4_request";
        $string_to_sign   = "{$algorithm}\n{$timestamp}\n{$credential_scope}\n" . hash( 'sha256', $canonical_request );

        $k_secret   = 'AWS4' . $this->secret_key;
        $k_date     = hash_hmac( 'sha256', $date, $k_secret, true );
        $k_region   = hash_hmac( 'sha256', $this->region, $k_date, true );
        $k_service  = hash_hmac( 'sha256', 's3', $k_region, true );
        $k_signing  = hash_hmac( 'sha256', 'aws4_request', $k_service, true );
        $signature  = hash_hmac( 'sha256', $string_to_sign, $k_signing );

        $authorization = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

        $ch = curl_init( $url );
        curl_setopt_array( $ch, [
            CURLOPT_CUSTOMREQUEST  => 'DELETE',
            CURLOPT_HTTPHEADER     => [
                "Authorization: {$authorization}",
                "x-amz-date: {$timestamp}",
                "x-amz-content-sha256: {$payload_hash}",
                "Host: {$host}",
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ] );

        $response_body = curl_exec( $ch );
        $http_code     = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error    = curl_error( $ch );
        curl_close( $ch );

        if ( $curl_error ) {
            Logger::log( 'R2 Delete cURL Error', 'error', [ 'error' => $curl_error, 'key' => $key ] );
            return new \WP_Error( 'curl_error', $curl_error );
        }

        if ( ! in_array( $http_code, [ 200, 204, 404 ], true ) ) {
            $msg = 'R2 Delete Failed: ' . $http_code . ' ' . substr( $response_body, 0, 500 );
            Logger::log( 'R2 Delete Failed', 'error', [ 'code' => $http_code, 'key' => $key, 'msg' => $msg ] );
            return new \WP_Error( 'delete_failed', $msg );
        }

        Logger::log( 'r2_object_deleted', null, wp_json_encode( [ 'key' => $key, 'method' => 'DELETE', 'code' => $http_code ] ), (string) $http_code, '', 0.0, 'info' );
        return true;
    }

    /**
     * Test R2 connection by performing a HEAD request for a dummy object.
     *
     * @return true|WP_Error True on successful connection (404/200), WP_Error on failure.
     */
    public function test_connection() {
        if ( empty( $this->access_key ) || empty( $this->secret_key ) || empty( $this->endpoint ) || empty( $this->bucket ) ) {
            return new \WP_Error( 'missing_config', 'R2/S3 credentials or bucket missing.' );
        }

        $public_domain = Config::get_r2_public_domain();
        if ( empty( $public_domain ) ) {
            return new \WP_Error( 'missing_public_domain', 'R2 public domain not configured. Set ai_collage_r2_public_domain in Settings > Buffer API > R2 Settings.' );
        }
        $pd_host   = wp_parse_url( $public_domain, PHP_URL_HOST );
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        if ( $pd_host && $site_host && strtolower( $pd_host ) === strtolower( $site_host ) ) {
            return new \WP_Error( 'public_domain_is_site', 'R2 public domain points at this WordPress site (' . $site_host . '). Videos will be unplayable. Set a Cloudflare Workers custom domain or enable Public Bucket on the R2 bucket and use the generated URL.' );
        }

        $dummy_key = 'ai-collage-test-connection-dummy-object';
        $uri = '/' . $this->bucket . '/' . $dummy_key;
        $host = parse_url( $this->endpoint, PHP_URL_HOST );
        $url = $this->endpoint . $uri;

        $timestamp = gmdate( 'Ymd\THis\Z' );
        $date      = gmdate( 'Ymd' );

        $payload_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'; // empty string SHA256

        $headers = [
            'host'                => $host,
            'x-amz-content-sha256' => $payload_hash,
            'x-amz-date'          => $timestamp,
        ];

        ksort( $headers );
        $canonical_headers = '';
        $signed_headers    = '';
        foreach ( $headers as $k => $v ) {
            $canonical_headers .= $k . ':' . $v . "\n";
            $signed_headers    .= $k . ';';
        }
        $signed_headers = rtrim( $signed_headers, ';' );

        $canonical_request = "HEAD\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

        $algorithm       = 'AWS4-HMAC-SHA256';
        $credential_scope = "{$date}/{$this->region}/s3/aws4_request";
        $string_to_sign  = "{$algorithm}\n{$timestamp}\n{$credential_scope}\n" . hash( 'sha256', $canonical_request );

        $k_secret = 'AWS4' . $this->secret_key;
        $k_date   = hash_hmac( 'sha256', $date, $k_secret, true );
        $k_region = hash_hmac( 'sha256', $this->region, $k_date, true );
        $k_service = hash_hmac( 'sha256', 's3', $k_region, true );
        $k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );
        $signature = hash_hmac( 'sha256', $string_to_sign, $k_signing );

        $authorization = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

        $ch = curl_init( $url );
        curl_setopt_array( $ch, [
            CURLOPT_CUSTOMREQUEST  => 'HEAD',
            CURLOPT_NOBODY         => true,
            CURLOPT_HTTPHEADER     => [
                "Authorization: {$authorization}",
                "x-amz-date: {$timestamp}",
                "x-amz-content-sha256: {$payload_hash}",
                "Host: {$host}",
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ] );

        curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error = curl_error( $ch );
        curl_close( $ch );

        if ( $curl_error ) {
            return new \WP_Error( 'curl_error', 'R2 Test cURL Error: ' . $curl_error );
        }

        if ( in_array( $http_code, [ 200, 404 ], true ) ) {
            return true;
        }

        return new \WP_Error( 'connection_failed', 'R2 Test Failed: Endpoint returned: ' . $http_code );
    }
}