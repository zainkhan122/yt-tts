<?php
/**
 * Reset Password Template
 * @version 1.1 - Hardened with XSS Prevention
 *
 * @MODIFIED: Added esc_attr() and esc_url() to all dynamic output.
 */

if (!defined('ABSPATH')) exit;

get_header();

$reset_key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
$email = isset($_GET['email']) ? sanitize_email($_GET['email']) : '';
?>

<div class="nm-auth-wrapper">
    <div class="nm-auth-container">
        <div class="nm-auth-box">
            
            <div class="nm-auth-promo">
                <div class="nm-promo-content">
                    <h2>Forgot Password?</h2>
                    <p>No problem. Enter your email to get a reset link, or use the link from your email to create a new password.</p>
                </div>
            </div>

            <div class="nm-auth-form-container">
                <?php if ($reset_key && $email): ?>
                    <div class="nm-auth-header">
                        <h1>Reset Password</h1>
                        <p>Enter your new password below</p>
                    </div>

                    <form id="nm-reset-password-form" class="nm-auth-form">
                        <input type="hidden" name="key" value="<?php echo esc_attr($reset_key); ?>">
                        <input type="hidden" name="email" value="<?php echo esc_attr($email); ?>">

                        <div class="nm-form-group">
                            <label for="password">New Password</label>
                            <div class="nm-password-field">
                                <input type="password" id="password" name="password" required>
                                <span class="nm-toggle-password">
                                    <i class="fa fa-eye"></i>
                                </span>
                            </div>
                        </div>

                        <div class="nm-form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>

                        <button type="submit" class="nm-btn nm-btn-primary nm-btn-block">Reset Password</button>
                    </form>
                <?php else: ?>
                    <div class="nm-auth-header">
                        <h1>Forgot Password?</h1>
                        <p>Enter your email to receive a reset link</p>
                    </div>

                    <form id="nm-forgot-password-form" class="nm-auth-form">
                        <div class="nm-form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" required>
                        </div>

                        <button type="submit" class="nm-btn nm-btn-primary nm-btn-block">Send Reset Link</button>
                    </form>
                <?php endif; ?>

                <div class="nm-auth-footer">
                    <p>Remember your password? <a href="<?php echo esc_url(home_url('/mcq-login/')); ?>" class="nm-link-primary">Login</a></p>
                </div>
            </div>

        </div>
    </div>
</div>

<?php get_footer(); ?>