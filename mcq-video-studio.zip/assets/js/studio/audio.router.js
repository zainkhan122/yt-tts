/**
 * MCQVS Audio Router
 *
 * Two modes:
 *  - Legacy: edge-trigger SFX + ducking callbacks (frame-based)
 *  - Deterministic: WebAudio lookahead scheduler (timeline-locked)
 *
 * @since 2026-02-05
 */
(function (window) {
  "use strict";

  const _num = (v, d) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
  };

  const _clamp01 = (v) => Math.max(0, Math.min(1, _num(v, 0)));

  const _safeDecodeAudioData = (ac, arrayBuffer) => {
    return new Promise((resolve, reject) => {
      try {
        const p = ac.decodeAudioData(arrayBuffer, resolve, reject);
        if (p && typeof p.then === "function") p.then(resolve).catch(reject);
      } catch (e) {
        reject(e);
      }
    });
  };

  class MCQVS_AudioRouter {
    constructor(opts = {}) {
      this._getPlan = (typeof opts.getPlan === "function") ? opts.getPlan : () => null;
      this._getFlags = (typeof opts.getFlags === "function") ? opts.getFlags : () => ({ audioEnabled: true, sfxEnabled: true, musicEnabled: true });
      this._getSfxUrl = (typeof opts.getSfxUrl === "function") ? opts.getSfxUrl : () => null;
      this._getMusicUrl = (typeof opts.getMusicUrl === "function") ? opts.getMusicUrl : () => null;

      this._legacyPlaySfx = (typeof opts.playSfx === "function") ? opts.playSfx : () => { };
      this._legacyDuck = (typeof opts.duck === "function") ? opts.duck : null;
      this._legacyUnduck = (typeof opts.unduck === "function") ? opts.unduck : null;

      this._deterministic = !!opts.deterministic;
      this._lookaheadMs = Math.max(60, _num(opts.lookaheadMs, 180));
      this._minLatencySec = Math.max(0.005, _num(opts.minLatencyMs, 15) / 1000);
      this._gainRampSec = Math.max(0.015, _num(opts.gainRampMs, 40) / 1000);

      this._ac = null;
      this._master = null;
      this._musicGain = null;
      this._sfxGain = null;
      this._buffers = new Map();
      // @NEW 2026-06-29: Track in-flight decode promises so first-tick cannot schedule a SFX
      // whose buffer is still decoding — that's what produced cumulative SFX-vs-scene drift.
      this._inflightBuffers = new Map();

      this._isPlaying = false;
      this._t0TimelineMs = 0;
      this._t0AudioSec = 0;
      this._lastTimelineMs = 0;
      this._cursor = 0;

      this._scheduled = [];

      this._musicSrc = null;
      this._musicUrlActive = null;
      this._musicNormal = _clamp01(opts.musicVolume != null ? opts.musicVolume : 0.30);
      this._sfxNormal = _clamp01(opts.sfxVolume != null ? opts.sfxVolume : 0.80);
      this._ducked = false;
      this._duckTarget = null;
      // @NEW 2026-02-23: Hard gate to prevent accidental resumption during stop sequence
      this._stopLock = 0;
      this._musicLoading = false; // @NEW 2026-02-16: Re-entry lock
      // @NEW 2026-06-29: Per-URL retry cap so a permanently broken SFX can't stall the cursor.
      this._sfxRetryMax = 3;
    }

    _ensureContext() {
      if (!this._deterministic) return null;
      if (this._ac) return this._ac;

      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) {
        this._deterministic = false; // fallback to legacy tick/playSfx path
        return null;
      }

      const ac = new Ctx();
      const master = ac.createGain();
      const musicGain = ac.createGain();
      const sfxGain = ac.createGain();

      master.gain.value = 1;
      musicGain.gain.value = this._musicNormal;
      sfxGain.gain.value = this._sfxNormal;

      musicGain.connect(master);
      sfxGain.connect(master);
      master.connect(ac.destination);

      this._ac = ac;
      this._master = master;
      this._musicGain = musicGain;
      this._sfxGain = sfxGain;
      return ac;
    }

	async _resumeContext() {
		// @SAFETY 2026-02-23: Do not resume if stop-locked (prevents echo during stop sequence)
		if (Date.now() < this._stopLock) return;

		const ac = this._ensureContext();
		if (!ac) return;
		if (ac.state === "suspended") {
			try {
				await ac.resume();
				// @FIX 2026-05-02: Wait for AudioContext to fully transition to 'running'
				// Chrome resumes async — starting sources before 'running' produces no sound
				let waits = 0;
				while (ac.state === 'suspended' && waits < 20) {
					await new Promise(r => setTimeout(r, 10));
					waits++;
				}
			} catch (_) { }
		}
	}

    async _ensureBuffer(url) {
      if (!this._deterministic) return null;
      let u = String(url || "").trim();
      if (!u) return null;

      // @PATCH 2026-02-14: Normalize legacy assets/ relative paths to absolute if possible
      if (u.startsWith('./assets/')) {
        const base = (window.MCQVSConfig && window.MCQVSConfig.assetsUrl) || "";
        if (base) u = u.replace('./assets/', base.replace(/\/+$/, '') + '/');
      }

      if (this._buffers.has(u)) return this._buffers.get(u);

      const ac = this._ensureContext();
      if (!ac) return null;

      // Coalesce concurrent decodes of the same URL.
      if (this._inflightBuffers && this._inflightBuffers.has(u)) {
        return this._inflightBuffers.get(u);
      }

      try {
        // @MODIFIED 2026-02-14: Add fetch timeout safety (5s) to prevent hanging
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const res = await fetch(u, {
          cache: "force-cache",
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
        const ab = await res.arrayBuffer();
        const buf = await _safeDecodeAudioData(ac, ab);
        this._buffers.set(u, buf);
        return buf;
      } catch (e) {
        console.error('[MCQVS] Audio Load Failed:', u, e);
        return null;
      } finally {
        if (this._inflightBuffers) this._inflightBuffers.delete(u);
      }
    }

    _timelineToAudioSec(timelineMs) {
      return this._t0AudioSec + (Math.max(0, _num(timelineMs, 0)) - this._t0TimelineMs) / 1000;
    }

    _rampGain(gainNode, target) {
      if (!this._ac || !gainNode) return;
      const t = this._ac.currentTime;
      const v = _clamp01(target);
      try {
        gainNode.gain.cancelScheduledValues(t);
        gainNode.gain.setValueAtTime(gainNode.gain.value, t);
        gainNode.gain.linearRampToValueAtTime(v, t + this._gainRampSec);
      } catch (_) {
        try { gainNode.gain.value = v; } catch (_) { }
      }
    }

    async prime() {
      if (!this._deterministic) return;
      this._ensureContext();
      await this._resumeContext();

      // @NEW 2026-06-29: A fresh prime implies a fresh plan. Reset per-URL retry counts
      // so previously-failed SFX get a fair shot against the new buffers (e.g. uploads,
      // library swap, or a hot reload of assets/).
      if (this._sfxRetry) this._sfxRetry.clear();
      this._sfxRetry = this._sfxRetry || new Map();

      const plan = this._getPlan();
      const toLoad = new Set();

      // @NEW 2026-06-29: Prime EVERY SFX URL across the full plan (was: only lookahead).
      // Decoding in advance removes the cold-buffer race that caused SFX to drift mid-video.
      const sfxEvents = plan && Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
      for (const ev of sfxEvents) {
        const name = String(ev && ev.name || "");
        const url = this._getSfxUrl(name);
        if (url) toLoad.add(url);
      }
      const musicUrl = this._getMusicUrl();
      if (musicUrl) toLoad.add(musicUrl);

      await Promise.all(Array.from(toLoad).map((u) => this._ensureBuffer(u).catch(() => null)));
    }

    async play(fromMs = 0) {
      const flags = this._getFlags() || {};
      if (!flags.audioEnabled) { this.stop(); return; }

      this._lastTimelineMs = Math.max(0, _num(fromMs, 0));
      if (!this._deterministic) return;

      await this._resumeContext();
      this._stopScheduledSfx();

      // @NEW 2026-06-29: Pre-await ALL SFX buffers reachable inside the lookahead window
      // before flipping _isPlaying=true. Without this the first scheduled audio sample
      // raced the decode pipeline, allowing later _t0AudioSec to drift on every cycle.
      try {
        const plan = this._getPlan();
        const upTo = this._lastTimelineMs + this._lookaheadMs;
        const sfxEvents = plan && Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
        const urls = new Set();
        for (const ev of sfxEvents) {
          const at = _num(ev && ev.atMs, NaN);
          if (!Number.isFinite(at) || at > upTo) break;
          const u = this._getSfxUrl(String(ev && ev.name || ""));
          if (u) urls.add(u);
        }
        const musicUrl = this._getMusicUrl();
        if (musicUrl) urls.add(musicUrl);
        await Promise.all(Array.from(urls).map((u) => this._ensureBuffer(u).catch(() => null)));
      } catch (_) { /* swallow — prime is best-effort */ }

      this._t0TimelineMs = this._lastTimelineMs;
      this._t0AudioSec = this._ac ? this._ac.currentTime : 0;

      this._cursor = this._findCursor(this._lastTimelineMs);
      this._isPlaying = true;

      await this._ensureMusicState(this._lastTimelineMs, true);
    }

	pause(atMs = 0) {
		this._lastTimelineMs = Math.max(0, _num(atMs, 0));
		if (!this._deterministic) return;

		this._stopLock = Date.now() + 50; // @FIX 2026-05-02: Reduced from 500ms to 50ms
		this._isPlaying = false;
		this._stopScheduledSfx();
		this._stopMusic();

		// @FIX 2026-05-02: Do NOT suspend AudioContext on pause — _resumeContext handles it on next play
	}

	stop() {
		this._stopLock = Date.now() + 50; // @FIX 2026-05-02: Reduced from 500ms to 50ms — 500ms blocked legitimate play-after-stop
		this._isPlaying = false;
		this._stopScheduledSfx();
		this._stopMusic(true);
		this._cursor = 0;
		this._lastTimelineMs = 0;
		this._ducked = false;
		this._duckTarget = null;

		if (this._deterministic && this._musicGain) {
			this._musicGain.gain.value = this._musicNormal;
		}

		// @FIX 2026-05-02: Do NOT suspend AudioContext on stop — let _resumeContext handle it on next play.
		// Suspending here creates a race: stop() suspends → play() calls _resumeContext() within 500ms →
		// _stopLock gate blocks resume → AudioContext stays suspended → no sound on first play attempt.
	}

    async seek(toMs = 0) {
      const ms = Math.max(0, _num(toMs, 0));
      this._lastTimelineMs = ms;
      if (!this._deterministic) return;

      this._stopScheduledSfx();
      this._cursor = this._findCursor(ms);

      if (this._isPlaying) {
        this._t0TimelineMs = ms;
        this._t0AudioSec = this._ac ? this._ac.currentTime : 0;
        await this._ensureMusicState(ms, true);
      } else {
        this._stopMusic();
      }
    }

    async tick(timelineMs, prevMs, isManual) {
      const flags = this._getFlags() || {};
      const nowMs = Math.max(0, _num(timelineMs, 0));
      const prev = Math.max(0, _num(prevMs, nowMs));
      this._lastTimelineMs = nowMs;

      if (!flags.audioEnabled) { this.stop(); return; }

      if (!this._deterministic) {
        this._legacyTick(nowMs, prev, !!isManual, flags);
        return;
      }

      // @FIX 2026-07-01 RESUME_DRIFT: Cache pre-resume ac.currentTime so stale timebase
      // cannot drift if Chrome resumes async behind us (prevents 10-50ms first-tick lag).
      const preResumeAudioSec = this._ac ? this._ac.currentTime : 0;
      await this._resumeContext();
      if (!this._ac || this._ac.state !== 'running') {
        this._t0AudioSec = preResumeAudioSec;
      }

      if (isManual) {
        await this.seek(nowMs);
        this._applyDuck(nowMs);
        return;
      }

      // @SAFETY 2026-02-14: Strict check ensures no unplanned playback when paused/scrubbing
      if (!this._isPlaying) {
        this._stopMusic();
        this._stopScheduledSfx();
        return;
      }

      await this._ensureMusicState(nowMs, false);
      this._applyDuck(nowMs);

      if (!flags.sfxEnabled) {
        this._stopScheduledSfx();
        return;
      }

      const plan = this._getPlan();
      const sfxEvents = plan && Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
      if (!sfxEvents.length) return;

      this._sfxRetry = this._sfxRetry || new Map();

      const upper = nowMs + this._lookaheadMs;
      // @FIX 2026-06-30 SFX_DRIFT: Do NOT await buffer loading inside the tick loop.
      // prime() has pre-decoded every SFX URL — check _buffers synchronously instead.
      // Buffers that are still decoding (in-flight) or have permanently failed are
      // skipped and retried on the next tick. This eliminates the cumulative async
      // yield that pushed _ac.currentTime past the computed _timelineToAudioSec target.
      while (this._cursor < sfxEvents.length) {
        const ev = sfxEvents[this._cursor];
        const atMs = _num(ev && ev.atMs, NaN);
        if (!Number.isFinite(atMs)) { this._cursor++; continue; }
        if (atMs > upper) break;

        const name = String(ev && ev.name || "");
        const url = this._getSfxUrl(name);
        if (url) {
          const cached = this._buffers.has(url);
          const inFlight = this._inflightBuffers && this._inflightBuffers.has(url);
          if (!cached && inFlight) {
            // Buffer still decoding — retry next tick.
            break;
          }
          if (!cached && !inFlight) {
            // Buffer not in cache and not loading — permanent failure or never primed.
            // Count retries so we don't stall the cursor forever on broken URLs.
            const tries = (this._sfxRetry.get(url) || 0) + 1;
            this._sfxRetry.set(url, tries);
            if (tries >= this._sfxRetryMax) {
              this._cursor++;
              continue;
            }
            break;
          }
          this._sfxRetry.delete(url);
        }

        this._scheduleSfxEvent(ev, atMs);
        this._cursor++;
      }
    }

    _findCursor(fromMs) {
      const plan = this._getPlan();
      const sfxEvents = plan && Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
      if (!sfxEvents.length) return 0;
      const ms = Math.max(0, _num(fromMs, 0));
      for (let i = 0; i < sfxEvents.length; i++) {
        const at = _num(sfxEvents[i] && sfxEvents[i].atMs, NaN);
        if (Number.isFinite(at) && at >= ms) return i;
      }
      return sfxEvents.length;
    }

    _stopScheduledSfx() {
      if (!this._scheduled.length) return;
      for (const it of this._scheduled) {
        try { it.src.stop(0); } catch (_) { }
        try { it.src.disconnect(); } catch (_) { }
        try { it.gain.disconnect(); } catch (_) { }
      }
      this._scheduled.length = 0;
    }

    _stopMusic(hard = false) {
      if (!this._musicSrc) return;
      try { this._musicSrc.stop(0); } catch (_) { }
      try { this._musicSrc.disconnect(); } catch (_) { }
      this._musicSrc = null;
      if (hard) this._musicUrlActive = null;
    }

	async _ensureMusicState(timelineMs, forceRestart) {
		const flags = this._getFlags() || {};
		const musicEnabled = !!(flags.audioEnabled && flags.musicEnabled);

		if (!musicEnabled) { this._stopMusic(); return; }

		const url = this._getMusicUrl();
		const u = url ? String(url).trim() : "";
		if (!u) { this._stopMusic(); return; }

		if (!forceRestart && this._musicSrc && this._musicUrlActive === u) return;
		if (this._musicLoading) return; // @NEW 2026-02-16: Prevent overlapping fetches

		this._stopMusic();
		this._musicUrlActive = u;
		this._musicLoading = true;

		const buf = await this._ensureBuffer(u);
		this._musicLoading = false;

		// @SAFETY 2026-02-16: Verify we are still playing and the URL hasn't changed during fetch
		if (!this._isPlaying || this._musicUrlActive !== u) return;

		if (!buf || !this._ac || !this._musicGain) return;

		// @FIX 2026-05-02: Ensure AudioContext is running before starting music source
		// Prevents silent playback when context was suspended (e.g. after stop+play cycle)
		await this._resumeContext();
		if (!this._ac || this._ac.state !== 'running') return;

		const src = this._ac.createBufferSource();
		src.buffer = buf;
		src.loop = true;
		src.connect(this._musicGain);

		const dur = _num(buf.duration, 0);
		const offsetSec = dur > 0 ? ((Math.max(0, _num(timelineMs, 0)) / 1000) % dur) : 0;
		const when = Math.max(this._ac.currentTime + this._minLatencySec, this._ac.currentTime);

		try { src.start(when, offsetSec); } catch (_) { try { src.start(when); } catch (_) { } }

		this._musicSrc = src;
	}

    _scheduleSfxEvent(ev, atMs) {
      const name = String(ev && ev.name || "");
      if (!name) return;

      const url = this._getSfxUrl(name);
      if (!url) { this._legacyPlaySfx(name, { volume: _num(ev && ev.gain, 1) }); return; }

      // @FIX 2026-07-01 SFX_DRIFT: Synchronous buffer lookup only — no async yield.
      // The tick loop (line 361) already verifies _buffers.has(url) before calling this.
      const buf = this._buffers && this._buffers.has(url) ? this._buffers.get(url) : null;
      if (!buf) return;

      // @SAFETY 2026-02-16: Verify we are still playing before scheduling SFX
      if (!this._isPlaying) return;

      if (!buf || !this._ac || !this._sfxGain) { this._legacyPlaySfx(name, { volume: _num(ev && ev.gain, 1) }); return; }

      const src = this._ac.createBufferSource();
      src.buffer = buf;

      const g = this._ac.createGain();
      g.gain.value = _clamp01(_num(ev && ev.gain, 1));

      src.connect(g);
      g.connect(this._sfxGain);

      const targetAudioSec = this._timelineToAudioSec(atMs);
      const when = Math.max(this._ac.currentTime + this._minLatencySec, targetAudioSec);

      try { src.start(when); } catch (_) { }

      this._scheduled.push({ src, gain: g, atMs, when });

      src.onended = () => {
        const idx = this._scheduled.findIndex((x) => x && x.src === src);
        if (idx >= 0) this._scheduled.splice(idx, 1);
        try { src.disconnect(); } catch (_) { }
        try { g.disconnect(); } catch (_) { }
      };
    }

    _applyDuck(timelineMs) {
      const plan = this._getPlan();
      const windows = plan && Array.isArray(plan.duckWindows) ? plan.duckWindows : [];
      const t = Math.max(0, _num(timelineMs, 0));

      let active = null;
      for (let i = 0; i < windows.length; i++) {
        const w = windows[i];
        if (!w) continue;
        const s = _num(w.startMs, NaN);
        const e = _num(w.endMs, NaN);
        if (!Number.isFinite(s) || !Number.isFinite(e)) continue;
        if (t >= s && t <= e) { active = w; break; }
      }

      if (!this._deterministic) {
        if (active && this._legacyDuck) this._legacyDuck(_clamp01(_num(active.volume, 0.2)));
        if (!active && this._legacyUnduck) this._legacyUnduck();
        return;
      }

      if (!this._musicGain) return;

      if (active) {
        const target = Math.min(this._musicNormal, _clamp01(_num(active.volume, 0.18)));
        if (!this._ducked || this._duckTarget !== target) {
          this._ducked = true;
          this._duckTarget = target;
          this._rampGain(this._musicGain, target);
        }
      } else {
        if (this._ducked) {
          this._ducked = false;
          this._duckTarget = null;
          this._rampGain(this._musicGain, this._musicNormal);
        }
      }
    }

    _legacyTick(timelineMs, prevMs, isManual, flags) {
      const plan = this._getPlan();
      if (!plan) return;

      if (flags && flags.musicEnabled && Array.isArray(plan.duckWindows)) {
        const active = plan.duckWindows.find((w) => timelineMs >= w.startMs && timelineMs <= w.endMs);
        if (active && this._legacyDuck) this._legacyDuck(active.volume);
        if (!active && this._legacyUnduck) this._legacyUnduck();
      }

      if (isManual) return;
      if (!flags || !flags.sfxEnabled) return;

      const sfx = Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
      for (const ev of sfx) {
        const at = _num(ev && ev.atMs, NaN);
        if (!Number.isFinite(at)) continue;
        if (at > prevMs && at <= timelineMs) {
          this._legacyPlaySfx(String(ev.name || ""), { volume: _num(ev.gain, 1) });
        }
      }
    }
  }

  window.MCQVS_AudioRouter = MCQVS_AudioRouter;
})(window);
