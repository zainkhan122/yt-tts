<?php

/**
 * Generation Logger Class
 *
 * This class replaces the procedural 27-generation-logging.php file.
 * All functions are now static methods.
 *
 * @version 1.1 - Added missing helper functions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Generation_Logger {


	/**
	 * Initialize the logger hooks
	 */
	public static function init() {
		add_action( 'init', array( self::class, 'create_log_tables' ), 5 );
		add_action( 'admin_init', array( self::class, 'create_log_tables' ) );
	}

	/**
	 * Create the log tables
	 */
	public static function create_log_tables() {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		$runs    = $wpdb->prefix . 'nm_generation_runs';
		$events  = $wpdb->prefix . 'nm_generation_events';

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		dbDelta(
			"CREATE TABLE $runs (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          started_at DATETIME NOT NULL,
          finished_at DATETIME NULL,
          trigger_type VARCHAR(20) NOT NULL DEFAULT 'manual',
          source_type VARCHAR(20) NOT NULL DEFAULT 'topic',
          source_ref VARCHAR(191) NULL,
          created_count INT NOT NULL DEFAULT 0,
          duplicate_count INT NOT NULL DEFAULT 0,
          error_count INT NOT NULL DEFAULT 0,
          notes VARCHAR(255) NULL,
          PRIMARY KEY (id),
          KEY k_started (started_at),
          KEY k_trigger (trigger_type),
          KEY k_source (source_type, source_ref)
        ) $charset;"
		);

		dbDelta(
			"CREATE TABLE $events (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          run_id BIGINT UNSIGNED NULL,
          ts DATETIME NOT NULL,
          event_type VARCHAR(20) NOT NULL,
          severity VARCHAR(20) NOT NULL DEFAULT 'info',
          source_type VARCHAR(20) NOT NULL,
          source_ref VARCHAR(191) NULL,
          mcq_id BIGINT UNSIGNED NULL,
          question_excerpt VARCHAR(255) NULL,
          duplicate_method VARCHAR(32) NULL,
          similarity DECIMAL(5,2) NULL,
          error_code VARCHAR(64) NULL,
          error_message TEXT NULL,
          meta LONGTEXT NULL,
          PRIMARY KEY (id),
          KEY k_run (run_id),
          KEY k_ts (ts),
          KEY k_type (event_type),
          KEY k_source (source_type, source_ref),
          KEY k_mcq (mcq_id)
        ) $charset;"
		);
	}

	/**
	 * Get the current run ID
	 */
	public static function get_current_run_id() {
		return isset( $GLOBALS['nm_current_run_id'] ) ? (int) $GLOBALS['nm_current_run_id'] : null;
	}

	/**
	 * Start a new generation run
	 */
	public static function start_run( $trigger, $source_type, $source_ref = null ) {
		global $wpdb;
		$runs = $wpdb->prefix . 'nm_generation_runs';
		$wpdb->insert(
			$runs,
			array(
				'started_at'   => current_time( 'mysql', true ), // UTC
				'trigger_type' => sanitize_text_field( $trigger ?: 'manual' ),
				'source_type'  => sanitize_text_field( $source_type ?: 'other' ),
				'source_ref'   => $source_ref ? sanitize_text_field( $source_ref ) : null,
			),
			array( '%s', '%s', '%s', '%s' )
		);
		$GLOBALS['nm_current_run_id'] = (int) $wpdb->insert_id;
		return $GLOBALS['nm_current_run_id'];
	}

	/**
	 * Finish a generation run
	 */
	public static function finish_run( $run_id, $created = 0, $dup = 0, $err = 0, $notes = null ) {
		if ( ! $run_id ) {
			return;
		}
		global $wpdb;
		$runs = $wpdb->prefix . 'nm_generation_runs';
		$wpdb->update(
			$runs,
			array(
				'finished_at'     => current_time( 'mysql', true ), // UTC
				'created_count'   => (int) $created,
				'duplicate_count' => (int) $dup,
				'error_count'     => (int) $err,
				'notes'           => $notes ? sanitize_text_field( $notes ) : null,
			),
			array( 'id' => (int) $run_id ),
			array( '%s', '%d', '%d', '%d', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Main logging event handler.
	 */
	public static function genlog_event( $args ) {
		global $wpdb;
		$events = $wpdb->prefix . 'nm_generation_events';

		// 🔒 Gracefully handle missing table during activation or edge cases
		$table_exists = $wpdb->get_var( $wpdb->prepare(
			"SHOW TABLES LIKE %s",
			$events
		) );
		if ( $table_exists !== $events ) {
			// Table doesn't exist yet — attempt to create it, then try again
			self::create_log_tables();
			// Re-check
			$table_exists = $wpdb->get_var( $wpdb->prepare(
				"SHOW TABLES LIKE %s",
				$events
			) );
			if ( $table_exists !== $events ) {
				// Still failed — silently skip logging to avoid fatal errors during activation
				return;
			}
		}

		$defaults = array(
			'run_id'           => self::get_current_run_id(), // Use class method
			'ts'               => current_time( 'mysql', true ), // UTC
			'event_type'       => 'info',
			'severity'         => 'info',
			'source_type'      => 'other',
			'source_ref'       => null,
			'mcq_id'           => null,
			'question_excerpt' => null,
			'duplicate_method' => null,
			'similarity'       => null,
			'error_code'       => null,
			'error_message'    => null,
			'meta'             => null,
		);
		$row      = array_merge( $defaults, is_array( $args ) ? $args : array() );

		$row['event_type']  = sanitize_key( $row['event_type'] );
		$row['severity']    = sanitize_key( $row['severity'] );
		$row['source_type'] = sanitize_key( $row['source_type'] );

		if ( ! empty( $row['meta'] ) && is_array( $row['meta'] ) ) {
			if ( empty( $row['error_message'] ) && ! empty( $row['meta']['message'] ) ) {
				$row['error_message'] = $row['meta']['message'];
			}

			// @NEW 2025-12-19: Truncate large strings in meta to prevent memory exhaustion
			array_walk_recursive(
				$row['meta'],
				function ( &$item ) {
					if ( is_string( $item ) && strlen( $item ) > 10000 ) {
						$item = mb_substr( $item, 0, 10000 ) . '... [TRUNCATED]';
					}
				}
			);

			$row['meta'] = wp_json_encode( $row['meta'] );
		}

		if ( ! empty( $row['question_excerpt'] ) ) {
			$row['question_excerpt'] = mb_substr( wp_strip_all_tags( $row['question_excerpt'] ), 0, 250 );
		}

		if ( ! empty( $row['error_message'] ) ) {
			$row['error_message'] = mb_substr( wp_strip_all_tags( $row['error_message'] ), 0, 255 );
		}

		if ( isset( $row['similarity'] ) && $row['similarity'] !== null ) {
			$row['similarity'] = round( (float) $row['similarity'], 2 );
		}

		$formats = array( '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%f', '%s', '%s', '%s' );

		$wpdb->insert(
			$events,
			array(
				'run_id'           => $row['run_id'],
				'ts'               => $row['ts'],
				'event_type'       => $row['event_type'],
				'severity'         => $row['severity'],
				'source_type'      => $row['source_type'],
				'source_ref'       => $row['source_ref'],
				'mcq_id'           => $row['mcq_id'],
				'question_excerpt' => $row['question_excerpt'],
				'duplicate_method' => $row['duplicate_method'],
				'similarity'       => $row['similarity'],
				'error_code'       => $row['error_code'],
				'error_message'    => $row['error_message'],
				'meta'             => $row['meta'],
			),
			$formats
		);
	}

	/**
	 * ✅ NEW: Backwards-compatibility wrapper for old nm_log_activity calls.
	 * Maps old parameters to the new structured event.
	 */
	public static function nm_log_activity( $message, $severity = 'info', $meta = array() ) {
		$etype = ( $severity === 'success' ) ? 'created' : ( ( $severity === 'duplicate' ) ? 'duplicate' : ( ( $severity === 'error' ) ? 'error' : ( ( $severity === 'warning' ) ? 'skipped' : 'info' ) ) );

		self::genlog_event(
			array(
				'event_type'       => $etype,
				'severity'         => $severity,
				'source_type'      => isset( $meta['source_type'] ) ? $meta['source_type'] : 'other',
				'source_ref'       => isset( $meta['source_ref'] ) ? $meta['source_ref'] : null,
				'mcq_id'           => isset( $meta['mcq_id'] ) ? $meta['mcq_id'] : null,
				'question_excerpt' => isset( $meta['question'] ) ? $meta['question'] : null, // The "what"
				'error_code'       => isset( $meta['error_code'] ) ? $meta['error_code'] : null,
				'error_message'    => $message, // The "why"
				'meta'             => $meta + array( 'legacy_message' => $message ),
			)
		);
	}

	/**
	 * ✅ NEW: Backwards-compatibility wrapper for old nm_log_duplicate_detection calls.
	 */
	public static function nm_log_duplicate_detection( $method, $similarity = null, $meta = array() ) {
		self::genlog_event(
			array(
				'event_type'       => 'duplicate',
				'severity'         => 'duplicate',
				'duplicate_method' => $method,
				'similarity'       => is_null( $similarity ) ? null : ( (float) $similarity * 100.0 ),
				'source_type'      => isset( $meta['source_type'] ) ? $meta['source_type'] : 'other',
				'source_ref'       => isset( $meta['source_ref'] ) ? $meta['source_ref'] : null,
				'question_excerpt' => isset( $meta['question'] ) ? $meta['question'] : null,
				'error_message'    => 'Duplicate (' . $method . ')', // Add the "why"
				'meta'             => $meta,
			)
		);
	}

	/**
	 * ✅ NEW: Default log retention in days (when option not set).
	 * Centralized here so cron cleanup and the settings page use the same value.
	 */
	const DEFAULT_RETENTION_DAYS = 30;
	const MIN_RETENTION_DAYS     = 1;
	const MAX_RETENTION_DAYS     = 365;

	/**
	 * ✅ NEW: Return the configured retention days, clamped to safe bounds.
	 */
	public static function get_retention_days() {
		$raw = get_option( 'nm_log_retention_days', self::DEFAULT_RETENTION_DAYS );
		$raw = is_numeric( $raw ) ? (int) $raw : self::DEFAULT_RETENTION_DAYS;
		if ( $raw < self::MIN_RETENTION_DAYS ) {
			$raw = self::MIN_RETENTION_DAYS;
		}
		if ( $raw > self::MAX_RETENTION_DAYS ) {
			$raw = self::MAX_RETENTION_DAYS;
		}
		return $raw;
	}

	/**
	 * ✅ NEW: Page size for the Logs admin page. Hard cap so accidental huge page
	 * requests do not lock the database.
	 */
	const LOGS_PAGE_SIZE       = 25;
	const LOGS_PAGE_SIZE_MAX   = 200;

	/**
	 * ✅ NEW: Allowed severities + event types for filter UI (single source of truth).
	 */
	public static function get_allowed_severities() {
		return array( 'info', 'success', 'warning', 'error', 'duplicate' );
	}

	public static function get_allowed_event_types() {
		return array( 'info', 'created', 'duplicate', 'error', 'skipped' );
	}

	/**
	 * ✅ NEW: Paginated query used by the Logs admin page and AJAX handler.
	 *
	 * @param array $args { severity, event_type, source_type, search, per_page, page }
	 * @return array { rows: array, total: int, page: int, per_page: int, total_pages: int }
	 */
	public static function query_logs( $args = array() ) {
		global $wpdb;
		$events = $wpdb->prefix . 'nm_generation_events';

		$defaults = array(
			'severity'    => '',
			'event_type'  => '',
			'source_type' => '',
			'search'      => '',
			'per_page'    => self::LOGS_PAGE_SIZE,
			'page'        => 1,
		);
		$args     = array_merge( $defaults, is_array( $args ) ? $args : array() );

		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : self::LOGS_PAGE_SIZE;
		if ( $per_page < 1 ) {
			$per_page = 1;
		}
		if ( $per_page > self::LOGS_PAGE_SIZE_MAX ) {
			$per_page = self::LOGS_PAGE_SIZE_MAX;
		}
		$page = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset = ( $page - 1 ) * $per_page;

		$where  = array( '1=1' );
		$params = array();

		$severity = sanitize_key( $args['severity'] );
		if ( in_array( $severity, self::get_allowed_severities(), true ) ) {
			$where[]  = 'severity = %s';
			$params[] = $severity;
		}

		$event_type = sanitize_key( $args['event_type'] );
		if ( in_array( $event_type, self::get_allowed_event_types(), true ) ) {
			$where[]  = 'event_type = %s';
			$params[] = $event_type;
		}

		$source_type = sanitize_key( $args['source_type'] );
		if ( '' !== $source_type ) {
			$where[]  = 'source_type = %s';
			$params[] = $source_type;
		}

		$search = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(error_message LIKE %s OR question_excerpt LIKE %s OR source_ref LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$where_sql = implode( ' AND ', $where );

		// Bail out if table does not exist (e.g., fresh install, activation race).
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events ) );
		if ( $exists !== $events ) {
			return array(
				'rows'        => array(),
				'total'       => 0,
				'page'        => $page,
				'per_page'    => $per_page,
				'total_pages' => 0,
			);
		}

		$total_sql = "SELECT COUNT(*) FROM {$events} WHERE {$where_sql}";
		if ( ! empty( $params ) ) {
			$total_sql = $wpdb->prepare( $total_sql, $params );
		}
		$total = (int) $wpdb->get_var( $total_sql );

		$rows_sql = "SELECT id, run_id, ts, event_type, severity, source_type, source_ref, mcq_id, question_excerpt, duplicate_method, similarity, error_code, error_message, meta
			FROM {$events}
			WHERE {$where_sql}
			ORDER BY id DESC
			LIMIT %d OFFSET %d";
		$rows_params              = array_merge( $params, array( $per_page, $offset ) );
		$rows_sql_prepared        = $wpdb->prepare( $rows_sql, $rows_params );
		$raw_rows                 = $wpdb->get_results( $rows_sql_prepared, ARRAY_A );

		$rows = array();
		if ( is_array( $raw_rows ) ) {
			foreach ( $raw_rows as $r ) {
				$rows[] = array(
					'id'               => (int) $r['id'],
					'run_id'           => isset( $r['run_id'] ) ? (int) $r['run_id'] : 0,
					'ts_utc'           => $r['ts'],
					'ts'               => get_date_from_gmt( $r['ts'], 'Y-m-d H:i:s' ),
					'event_type'       => $r['event_type'],
					'severity'         => $r['severity'],
					'source_type'      => $r['source_type'],
					'source_ref'       => $r['source_ref'],
					'mcq_id'           => isset( $r['mcq_id'] ) && $r['mcq_id'] ? (int) $r['mcq_id'] : 0,
					'question_excerpt' => $r['question_excerpt'],
					'duplicate_method' => $r['duplicate_method'],
					'similarity'       => $r['similarity'],
					'error_code'       => $r['error_code'],
					'message'          => $r['error_message'],
				);
			}
		}

		return array(
			'rows'        => $rows,
			'total'       => $total,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * ✅ NEW: Delete events older than the configured retention window.
	 * Also prunes orphan runs whose events all vanished.
	 *
	 * @param int|null $days Override retention (used by manual trigger). Falls back to option.
	 * @return array { events_deleted:int, runs_deleted:int }
	 */
	public static function purge_old_logs( $days = null ) {
		global $wpdb;

		if ( null === $days ) {
			$days = self::get_retention_days();
		}
		$days = max( self::MIN_RETENTION_DAYS, (int) $days );

		$events = $wpdb->prefix . 'nm_generation_events';
		$runs   = $wpdb->prefix . 'nm_generation_runs';

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events ) );
		if ( $exists !== $events ) {
			return array(
				'events_deleted' => 0,
				'runs_deleted'   => 0,
			);
		}

		// ✅ The 'ts' column stores UTC ('current_time( "mysql", true )' everywhere in this class).
		// Use gmdate() so the cutoff is comparable to UTC values, not the WP site's local time.
		$cutoff      = gmdate( 'Y-m-d H:i:s', strtotime( '-' . (int) $days . ' days' ) );
		$events_deleted = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$events} WHERE ts < %s",
				$cutoff
			)
		);

		// Clean up runs that no longer back any event (avoid runaway table growth).
		$runs_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $runs ) );
		$runs_deleted = 0;
		if ( $runs_exists === $runs ) {
			$runs_deleted = (int) $wpdb->query(
				"DELETE r FROM {$runs} r
				 LEFT JOIN {$events} e ON e.run_id = r.id
				 WHERE e.id IS NULL"
			);
		}

		return array(
			'events_deleted' => $events_deleted,
			'runs_deleted'   => $runs_deleted,
		);
	}

	/**
	 * ✅ NEW: Truncate ALL events (manual "Clear now" button).
	 *
	 * @return array { events_deleted:int, runs_deleted:int }
	 */
	public static function purge_all_logs() {
		global $wpdb;

		$events = $wpdb->prefix . 'nm_generation_events';
		$runs   = $wpdb->prefix . 'nm_generation_runs';

		$events_deleted = 0;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events ) ) === $events ) {
			$events_deleted = (int) $wpdb->query( "TRUNCATE TABLE {$events}" );
		}

		$runs_deleted = 0;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $runs ) ) === $runs ) {
			$runs_deleted = (int) $wpdb->query( "TRUNCATE TABLE {$runs}" );
		}

		return array(
			'events_deleted' => $events_deleted,
			'runs_deleted'   => $runs_deleted,
		);
	}

	/**
	 * ✅ NEW: Aggregate counts shown above the Logs table (per severity).
	 *
	 * @return array { total:int, by_severity: array<string,int>, retention_days:int }
	 */
	public static function get_log_stats() {
		global $wpdb;
		$events = $wpdb->prefix . 'nm_generation_events';
		$stats  = array(
			'total'           => 0,
			'by_severity'     => array(),
			'retention_days'  => self::get_retention_days(),
		);

		foreach ( self::get_allowed_severities() as $s ) {
			$stats['by_severity'][ $s ] = 0;
		}

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events ) ) !== $events ) {
			return $stats;
		}

		$total      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$events}" );
		$stats['total'] = $total;

		$rows = $wpdb->get_results(
			"SELECT severity, COUNT(*) AS c FROM {$events} GROUP BY severity",
			ARRAY_A
		);
		if ( is_array( $rows ) ) {
			foreach ( $rows as $r ) {
				$sev = sanitize_key( $r['severity'] );
				if ( isset( $stats['by_severity'][ $sev ] ) ) {
					$stats['by_severity'][ $sev ] = (int) $r['c'];
				}
			}
		}

		return $stats;
	}

	/**
	 * ✅ NEW: Build CSV text for the full filtered log (used by the Download button).
	 *
	 * @param array $args Same shape as query_logs().
	 * @return string CSV body
	 */
	public static function build_logs_csv( $args = array() ) {
		// Force a high but capped limit so CSV covers everything within the filter.
		$args['per_page'] = self::LOGS_PAGE_SIZE_MAX;
		$args['page']     = 1;

		$rows = self::query_logs( $args );

		$fh = fopen( 'php://temp', 'w+' );
		if ( $fh === false ) {
			return '';
		}

		// UTF-8 BOM so Excel opens it cleanly.
		fwrite( $fh, "\xEF\xBB\xBF" );

		fputcsv(
			$fh,
			array(
				'ID',
				'Timestamp (Site TZ)',
				'Timestamp (UTC)',
				'Severity',
				'Event Type',
				'Source',
				'Source Reference',
				'Run ID',
				'MCQ ID',
				'Question Excerpt',
				'Duplicate Method',
				'Similarity',
				'Error Code',
				'Message',
			)
		);

		foreach ( $rows['rows'] as $r ) {
			fputcsv(
				$fh,
				array(
					$r['id'],
					$r['ts'],
					$r['ts_utc'],
					$r['severity'],
					$r['event_type'],
					$r['source_type'],
					$r['source_ref'],
					$r['run_id'],
					$r['mcq_id'],
					$r['question_excerpt'],
					$r['duplicate_method'],
					$r['similarity'],
					$r['error_code'],
					$r['message'],
				)
			);
		}

		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return $csv === false ? '' : $csv;
	}
}
