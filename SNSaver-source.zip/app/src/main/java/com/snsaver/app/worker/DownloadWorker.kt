package com.snsaver.app.worker
import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.snsaver.app.data.network.*
import com.snsaver.app.data.preferences.AppPreferences
import com.snsaver.app.domain.model.*
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.util.*
import dagger.assisted.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@HiltWorker class DownloadWorker @AssistedInject constructor(
 @Assisted context:Context,@Assisted params:WorkerParameters,
 private val repo:DownloadRepository,private val cobalt:CobaltApiService,private val scraper:MetadataScraper,
 private val prefs:AppPreferences,private val files:FileHelper,private val gallery:MediaStoreHelper
):CoroutineWorker(context,params){
 override suspend fun doWork():Result{val id=inputData.getLong(KEY,-1);if(id<0)return Result.failure();val original=repo.get(id)?:return Result.failure()
  return try{
   repo.setStatus(id,DownloadStatus.EXTRACTING,10)
   val media=cobalt.fetch(original.sourceUrl,prefs.apiEndpoint.first(),prefs.apiKey.first())
   val meta=scraper.scrape(original.sourceUrl,original.platform)
   val type=when{media.urls.size>1->MediaType.CAROUSEL;media.types.firstOrNull()=="photo"->MediaType.IMAGE;else->MediaType.VIDEO}
   val saved=mutableListOf<String>();var bytes=0L
   media.urls.forEachIndexed{index,url->repo.setStatus(id,DownloadStatus.DOWNLOADING,20+(index*70/media.urls.size));val ext=if(media.types.getOrNull(index)=="photo")"jpg" else "mp4";val file=files.download(url,"${original.platform.shortName.lowercase()}_${System.currentTimeMillis()}_$index.$ext"){done,total->if(total>0)setProgressAsync(workDataOf("progress" to (20+(done*70/total).toInt()).coerceAtMost(95)))};saved+=file.absolutePath;bytes+=file.length();if(prefs.saveToGallery.first())runCatching{gallery.save(file,if(ext=="jpg")MediaType.IMAGE else MediaType.VIDEO)}}
   val thumb=if(type==MediaType.VIDEO)runCatching{files.thumbnail(saved.first()).absolutePath}.getOrNull() else meta.thumbnail?:saved.firstOrNull()
   repo.update(original.copy(status=DownloadStatus.COMPLETED,progress=100,mediaType=type,mediaUrls=media.urls,downloadedFiles=saved,filePath=saved.firstOrNull(),thumbnailPath=thumb,caption=meta.caption,hashtags=meta.hashtags,title=meta.title,profileName=meta.profileName,profileUrl=meta.profileUrl,fileSize=bytes,errorMessage=null))
   Result.success()
  }catch(e:Exception){repo.fail(id,e.message?:"Download failed");if(runAttemptCount<2)Result.retry() else Result.failure()}
 }
 companion object{const val KEY="ITEM_ID";fun request(id:Long)=OneTimeWorkRequestBuilder<DownloadWorker>().setInputData(workDataOf(KEY to id)).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,java.time.Duration.ofSeconds(15)).build()}
}
