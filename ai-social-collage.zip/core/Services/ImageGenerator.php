<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageAIProviderInterface;
use AiSocialCollage\Database\JobManager;
use AiSocialCollage\Database\ApiCallManager;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\ImageAI\PollinationsProvider;
use AiSocialCollage\Services\ImageAI\StabilityProvider;
use AiSocialCollage\Services\ImageAI\CloudflareWorkerProvider;
use AiSocialCollage\Services\ImageAI\PlaceholderProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ImageGenerator {

	public static function generate_for_job( $job ) {
		$provider_key = get_option( Config::OPTION_IMAGE_PROVIDER, Config::DEFAULT_IMAGE_PROVIDER );
		if ( ! Config::is_valid_image_provider( $provider_key ) ) {
			$provider_key = Config::DEFAULT_IMAGE_PROVIDER;
		}

		// When provider is 'none', fail immediately with clear logging.
		if ( $provider_key === Config::PROVIDER_IMAGE_NONE ) {
			Logger::error( 'ai_image_generation_skipped', $job->id, [
				'provider' => $provider_key,
				'reason' => 'Image provider set to "None". No image will be generated for this post.',
			], '200' );
			return '';
		}

		$provider = self::create_provider( $provider_key );
		$prompt = self::build_prompt( $job->ai_headline, $job->ai_hook );
		$brand = Config::get_brand_settings();

		$context = [
			'job_id' => $job->id,
			'post_id' => $job->post_id,
			'caller' => 'ImageGenerator::generate_for_job',
		];

		$request_hash = ApiCallManager::hash_request( $provider_key, [ 'prompt' => $prompt ] );
		$call_id = ApiCallManager::create_call( [
			'job_id' => $job->id,
			'provider' => $provider_key,
			'model' => $provider->get_model_name(),
			'request_hash' => $request_hash,
			'request_payload' => [ 'prompt_length' => mb_strlen( $prompt ) ],
			'quota_allowed' => true,
			'status' => Config::API_CALL_PENDING,
			'caller_context' => $context['caller'],
		] );

		$start_time = microtime( true );

		try {
			$image_path = $provider->generate_image( $prompt, Config::IMAGE_WIDTH, Config::IMAGE_HEIGHT );
			$execution_time = microtime( true ) - $start_time;

			$attachment_id = self::sideload_to_media_library( $image_path, $job->post_id );

			if ( file_exists( $image_path ) ) {
				@unlink( $image_path );
			}

			$image_url = wp_get_attachment_url( $attachment_id );

			ApiCallManager::update_call( $call_id, [
				'response_code' => '200',
				'execution_time' => $execution_time,
				'status' => Config::API_CALL_SUCCESS,
			] );

			JobManager::update_ai_generated_image_url( $job->id, $image_url );

			Logger::info( Config::LOG_ACTION_AI_IMAGE_GENERATED, $job->id, [
				'provider' => $provider_key,
				'attachment_id' => $attachment_id,
				'execution_time' => round( $execution_time, 3 ),
			], '200' );

			return $image_url;

		} catch ( \Exception $e ) {
			$execution_time = microtime( true ) - $start_time;

			ApiCallManager::update_call( $call_id, [
				'response_code' => '500',
				'response_body' => $e->getMessage(),
				'execution_time' => $execution_time,
				'status' => Config::API_CALL_FAILED,
			] );

			Logger::error( 'ai_image_generation_failed', $job->id, [
				'provider' => $provider_key,
				'error' => $e->getMessage(),
			], '500' );

			$fallback_provider = new PlaceholderProvider();
			$image_path = $fallback_provider->generate_image( $job->ai_headline ?: 'News', Config::IMAGE_WIDTH, Config::IMAGE_HEIGHT );
			$attachment_id = self::sideload_to_media_library( $image_path, $job->post_id );

			if ( file_exists( $image_path ) ) {
				@unlink( $image_path );
			}

			$image_url = wp_get_attachment_url( $attachment_id );
			JobManager::update_ai_generated_image_url( $job->id, $image_url );

			Logger::warning( 'ai_image_fallback_to_placeholder', $job->id, [
				'attachment_id' => $attachment_id,
			], '200' );

			return $image_url;
		}
	}

	private static function create_provider( $provider_key ) {
		$api_key = get_option( Config::OPTION_IMAGE_PROVIDER_KEY, '' );

		switch ( $provider_key ) {
			case Config::PROVIDER_IMAGE_POLLINATIONS:
				return new PollinationsProvider( $api_key );
			case Config::PROVIDER_IMAGE_STABILITY:
				return new StabilityProvider( $api_key );
			case Config::PROVIDER_IMAGE_CLOUDFLARE_WORKER:
				$worker_url = get_option( Config::OPTION_IMAGE_PROVIDER_WORKER_URL, '' );
				return new CloudflareWorkerProvider( $worker_url, $api_key );
			case Config::PROVIDER_IMAGE_PLACEHOLDER:
			default:
				return new PlaceholderProvider();
		}
	}

	private static function build_prompt( $headline, $hook ) {
		$parts = [];
		if ( ! empty( $headline ) ) {
			$parts[] = "Professional photojournalism image for headline: \"{$headline}\"";
		}
		if ( ! empty( $hook ) ) {
			$parts[] = "Context: " . mb_substr( $hook, 0, 200 );
		}
		$parts[] = "Style: dramatic lighting, cinematic composition, news photography, high quality";

		return implode( '. ', $parts );
	}

	private static function sideload_to_media_library( $file_path, $post_id ) {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$file_array = [
			'name' => basename( $file_path ),
			'tmp_name' => $file_path,
		];

		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			throw new \Exception( 'Failed to attach AI-generated image: ' . $attachment_id->get_error_message() );
		}

		update_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, '1' );

		return $attachment_id;
	}
}
