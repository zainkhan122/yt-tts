package com.snsaver.app.data.preferences
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.map
import javax.inject.Inject
private val Context.store by preferencesDataStore("settings")
class AppPreferences @Inject constructor(@ApplicationContext private val context:Context){
 private object K{val endpoint=stringPreferencesKey("endpoint");val key=stringPreferencesKey("key");val gallery=booleanPreferencesKey("gallery");val theme=stringPreferencesKey("theme")}
 val apiEndpoint=context.store.data.map{it[K.endpoint]?:"https://api.cobalt.tools/"}
 val apiKey=context.store.data.map{it[K.key].orEmpty()}
 val saveToGallery=context.store.data.map{it[K.gallery]?:true}
 val theme=context.store.data.map{it[K.theme]?:"system"}
 suspend fun endpoint(v:String)=context.store.edit{it[K.endpoint]=v}
 suspend fun apiKey(v:String)=context.store.edit{it[K.key]=v}
 suspend fun gallery(v:Boolean)=context.store.edit{it[K.gallery]=v}
 suspend fun theme(v:String)=context.store.edit{it[K.theme]=v}
}
