<?php

/**
 * AJAX Handler for Server-Side Batch Rendering and FFmpeg Jobs
 *
 * @package MCQ_Video_Studio
 * 
 * @DEPRECATED 2026-01-10: Server-side batch rendering has been removed.
 * Client-only FFmpeg.wasm export is now the sole rendering path.
 * 
 * ONLY ajax_check_ffmpeg() remains in active use for diagnostics.
 * All other methods in this class are deprecated and will be removed in a future version.
 * The AJAX action registrations for these methods have been removed from class-vs-core.php.
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Batch_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Check FFmpeg Path
     */
    public function ajax_check_ffmpeg()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $path = sanitize_text_field($_POST['path'] ?? 'ffmpeg');

        // @NEW 2026-01-10: Smart Local Fallback
        if ($path === 'ffmpeg' && strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $local_check = 'C:\Program Files\Softdeluxe\Free Download Manager\ffmpeg.exe';
            if (file_exists($local_check)) {
                $path = $local_check;
            }
        }

        // Security Fix: Escape shell command (Use escapeshellarg for path with spaces)
        $cmd = defined('PHP_OS_FAMILY') && PHP_OS_FAMILY === 'Windows'
            ? escapeshellarg($path) . ' -version'
            : escapeshellcmd($path) . ' -version';

        exec($cmd, $output, $return_var);

        if ($return_var === 0) {
            wp_send_json_success(array('version' => $output[0]));
        } else {
            // @NEW 2026-01-09: Central Logging
            VS_Error_Logger::get_instance()->log('FFmpeg check failed', 'error', array('path' => $path, 'output' => $output));
            wp_send_json_error('FFmpeg not found at: ' . $path);
        }
    }

    /**
     * AJAX: Start Batch Job
     */
    public function ajax_start_batch_job()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = wp_generate_uuid4();
        $job_data = array(
            'status'     => 'initializing',
            'created'    => gmdate('Y-m-d H:i:s'),
            'total'      => absint($_POST['total_frames'] ?? 0),
            'processed'  => 0,
            'settings'   => json_decode(wp_unslash($_POST['settings'] ?? '{}'), true),
        );

        update_option('mcqvs_batch_job_' . $job_id, $job_data);
        wp_send_json_success(array('job_id' => $job_id));
    }

    /**
     * AJAX: Upload Frame Chunk (ZIP)
     * @MODIFIED 2026-01-08: Added ZIP extraction and frame counting
     */
    public function ajax_upload_frame_chunk()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $start_frame = absint($_POST['start_frame'] ?? 0);

        if (empty($job_id)) {
            VS_Error_Logger::get_instance()->log('Batch Upload: Invalid Job ID', 'error');
            wp_send_json_error('Invalid job ID');
        }

        $upload_dir = wp_upload_dir()['basedir'] . '/mcq-video-studio/batch/' . $job_id;
        $frames_dir = $upload_dir . '/frames';
        wp_mkdir_p($frames_dir);

        $extracted_count = 0;

        // Handle ZIP upload
        if (isset($_FILES['chunk']) && class_exists('ZipArchive')) {
            $chunk_file = $upload_dir . '/chunk_' . time() . '.zip';
            move_uploaded_file($_FILES['chunk']['tmp_name'], $chunk_file);

            // Extract ZIP
            $zip = new ZipArchive();
            if ($zip->open($chunk_file) === true) {
                // Security Fix: Zip Slip Protection
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $name = $zip->getNameIndex($i);
                    // Reject directory traversal, absolute paths, and non-jpgs
                    if (strpos($name, '..') !== false || strpos($name, '/') === 0 || strpos($name, '\\') !== false || substr($name, -4) !== '.jpg') {
                        continue;
                    }
                    $zip->extractTo($frames_dir, $name);
                    $extracted_count++;
                }
                $zip->close();
                unlink($chunk_file); // Cleanup ZIP after extraction
            }
        }
        // Handle individual frame uploads (fallback)
        elseif (isset($_FILES['frames'])) {
            foreach ($_FILES['frames']['tmp_name'] as $key => $tmp_name) {
                $name = sanitize_file_name($_FILES['frames']['name'][$key]);
                if (substr($name, -4) === '.jpg') {
                    move_uploaded_file($tmp_name, $frames_dir . '/' . $name);
                    $extracted_count++;
                }
            }
        }

        // Update job progress
        $job_data = get_option('mcqvs_batch_job_' . $job_id);
        if ($job_data) {
            $job_data['processed'] = ($job_data['processed'] ?? 0) + $extracted_count;
            $job_data['status'] = 'uploading';
            update_option('mcqvs_batch_job_' . $job_id, $job_data);
        }

        wp_send_json_success(array(
            'uploaded' => $job_data['processed'] ?? $extracted_count,
            'extracted' => $extracted_count
        ));
    }

    /**
     * AJAX: Process Batch Job (FFmpeg Encoding)
     * @MODIFIED 2026-01-08: Implements full FFmpeg command generation and cron scheduling
     */
    public function ajax_process_batch_job()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $job_data = get_option('mcqvs_batch_job_' . $job_id);

        if (! $job_data) {
            VS_Error_Logger::get_instance()->log('Batch Process: Job not found', 'error', array('job_id' => $job_id));
            wp_send_json_error('Job not found');
        }

        // Update status to processing
        $job_data['status'] = 'processing';
        update_option('mcqvs_batch_job_' . $job_id, $job_data);

        // Schedule background processing via WP Cron
        wp_schedule_single_event(time(), 'mcqvs_process_ffmpeg_job', array($job_id));

        wp_send_json_success(array('message' => 'FFmpeg processing scheduled'));
    }

    /**
     * Background FFmpeg Processing (Called by WP Cron)
     * @NEW 2026-01-08: Actual FFmpeg command execution
     */
    /**
     * Background FFmpeg Processing (Called by WP Cron)
     * @NEW 2026-01-08: Actual FFmpeg command execution with Audio Merging
     */
    public function process_ffmpeg_job($job_id)
    {
        $job_data = get_option('mcqvs_batch_job_' . $job_id);
        if (! $job_data) {
            return;
        }

        $upload_dir = wp_upload_dir()['basedir'] . '/mcq-video-studio/batch/' . $job_id;
        $frames_dir = $upload_dir . '/frames';
        $output_file = $upload_dir . '/output.mp4';

        // Get FFmpeg path
        $ffmpeg_path = get_option('mcqvs_ffmpeg_path', 'ffmpeg');

        // @NEW 2026-01-10: Smart Local Fallback
        if ($ffmpeg_path === 'ffmpeg' && strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $local_check = 'C:\Program Files\Softdeluxe\Free Download Manager\ffmpeg.exe';
            if (file_exists($local_check)) {
                $ffmpeg_path = $local_check;
            }
        }

        // Parse Settings for Audio
        $settings = isset($job_data['settings']) ? json_decode($job_data['settings'], true) : [];
        $bg_music_url = $settings['bg_music'] ?? null;
        $audio_enabled = $settings['audio_enabled'] ?? false;

        $audio_input_cmd = '';
        $filter_cmd = '';
        $map_cmd = '';
        $audio_path = null;

        if ($audio_enabled && $bg_music_url) {
            $audio_path = $this->resolve_audio_path($bg_music_url);
            if ($audio_path && file_exists($audio_path)) {
                // Input 1: Background Music (Looped)
                // -stream_loop -1 must come BEFORE the input
                // Security Fix: Escape audio path
                $audio_input_cmd = sprintf(' -stream_loop -1 -i %s', escapeshellarg($audio_path));

                // Mix audio: Volume 30%
                $filter_cmd = ' -filter_complex "[1:a]volume=0.3[a]"';

                // Map streams: Video from 0, Mixed Audio from filter [a]
                // -shortest ensures video stops when the shortest stream ends (but we looped audio, 
                // so strictly speaking -shortest cuts audio to match video length)
                $map_cmd = ' -map 0:v -map "[a]" -shortest';
            }
        }

        // Build FFmpeg command
        // Input 0: Video frames
        // Input 1: Audio (Optional)
        // Security Fix: Escape all paths using escapeshellarg for Windows compatibility
        $ffmpeg_cmd = defined('PHP_OS_FAMILY') && PHP_OS_FAMILY === 'Windows'
            ? escapeshellarg($ffmpeg_path)
            : escapeshellcmd($ffmpeg_path);

        $command = sprintf(
            '%s -y -framerate 30 -pattern_type glob -i %s %s -c:v libx264 -pix_fmt yuv420p -preset ultrafast %s %s %s 2>&1',
            $ffmpeg_cmd,
            escapeshellarg($frames_dir . '/frame_*.jpg'),
            $audio_input_cmd,
            $filter_cmd, // Fixed string, safe
            $map_cmd,   // Fixed string, safe
            escapeshellarg($output_file)
        );

        // Execute FFmpeg
        exec($command, $output, $return_var);

        if ($return_var === 0 && file_exists($output_file)) {
            // Success - copy to public uploads and create URL
            $public_dir = wp_upload_dir()['basedir'] . '/mcq-video-studio/exports';
            wp_mkdir_p($public_dir);

            $public_file = $public_dir . '/video_' . $job_id . '.mp4';
            copy($output_file, $public_file);

            $public_url = wp_upload_dir()['baseurl'] . '/mcq-video-studio/exports/video_' . $job_id . '.mp4';

            $job_data['status'] = 'complete';
            $job_data['output_url'] = $public_url;
            $job_data['completed_at'] = gmdate('Y-m-d H:i:s');

            // Cleanup frames
            $this->cleanup_frames($frames_dir);
        } else {
            $job_data['status'] = 'error';
            $job_data['error'] = implode("\n", $output);

            // @NEW 2026-01-09: Central Logging for FFmpeg Failure
            VS_Error_Logger::get_instance()->log(
                'FFmpeg Batch Job Failed',
                'error',
                array('job_id' => $job_id, 'command' => $command, 'output' => $output)
            );
        }

        update_option('mcqvs_batch_job_' . $job_id, $job_data);
    }

    /**
     * Resolve Audio URL to Local Path
     */
    private function resolve_audio_path($url)
    {
        if (!$url) return null;

        // 1. Remove cache busters
        $url = strtok($url, '?');

        // 2. Check if local URL
        $site_url = get_site_url();
        if (strpos($url, $site_url) !== false) {
            // Convert URL to Path
            $rel_path = str_replace($site_url, '', $url);
            // Security Fix: Normalize and Containment Check
            $path = wp_normalize_path(ABSPATH . ltrim($rel_path, '/'));

            // Allow WP_CONTENT_DIR or ABSPATH (flexible but safe)
            if (strpos($path, wp_normalize_path(ABSPATH)) === 0 && strpos($path, '..') === false) {
                return $path;
            }
        }

        // 3. Handle Plugin Relative Paths (e.g. ./assets/...)
        // This usually shouldn't happen from frontend sends full URL, but safeguards:
        if (strpos($url, 'assets/') !== false) {
            // Assuming plugin dir structure
            if (strpos($url, './') === 0) {
                $path = wp_normalize_path(plugin_dir_path(dirname(__FILE__)) . substr($url, 2));
                if (strpos($path, wp_normalize_path(WP_PLUGIN_DIR)) === 0 && strpos($path, '..') === false) {
                    return $path;
                }
            }
        }

        return null; // External URLs not supported in local ffmpeg without -protocol_whitelist
    }

    /**
     * Cleanup extracted frames after encoding
     */
    private function cleanup_frames($frames_dir)
    {
        if (! is_dir($frames_dir)) {
            return;
        }

        $files = glob($frames_dir . '/*.jpg');
        foreach ($files as $file) {
            @unlink($file);
        }
        @rmdir($frames_dir);
    }

    /**
     * AJAX: Get Job Status (Polling)
     */
    public function ajax_get_job_status()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $job_data = get_option('mcqvs_batch_job_' . $job_id);

        if (! $job_data) {
            wp_send_json_error('Job not found');
        }

        wp_send_json_success($job_data);
    }

    /**
     * Register cron hook for FFmpeg processing
     */
    public static function register_cron_hooks()
    {
        add_action('mcqvs_process_ffmpeg_job', array(self::get_instance(), 'process_ffmpeg_job'));
    }
}

// Register cron hooks on load
VS_AJAX_Batch_Handler::register_cron_hooks();
