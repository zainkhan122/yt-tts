<?php
/**
 * Database Manager
 *
 * @package WP_News_MCQ_Generator
 * @version 1.4 - Cleaned up activation/deactivation hooks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Database_Manager {

	/**
	 * Main Activation Hook.
	 *
	 * @MODIFIED: Removed CPT registration and flush_rewrite_rules.
	 * These are now handled by the main plugin activation hook.
	 */
	public static function on_activation() {
		global $wpdb;

		// 1. ❌ REMOVED: CPT Registration (now in main plugin file)

		// 2. Require dbDelta function
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// 3. Create all tables
		self::create_gamification_tables( $wpdb );
		self::create_optimizer_tables( $wpdb );
		self::create_embedding_table( $wpdb );
		self::create_subscribers_table( $wpdb );
		self::create_generation_log_tables( $wpdb );
		self::create_security_log_tables( $wpdb );

		// 4. Register custom role
		self::register_custom_roles();

		// 5. Set Default Options
		self::set_default_options();

		// 6. Schedule Cron Jobs
		if ( ! wp_next_scheduled( 'nm_initial_sync_cron' ) ) {
			wp_schedule_single_event( time() + 30, 'nm_initial_sync_cron' );
		}
		if ( class_exists( 'NM_Cron_Manager' ) && method_exists( 'NM_Cron_Manager', 'schedule_all_crons' ) ) {
			NM_Cron_Manager::schedule_all_crons();
		}

		// 7. ❌ REMOVED: Flush Rewrite Rules (now in main plugin file)

		// 8. Set Database Version
		update_option( 'nm_db_version', '2.0' );
		update_option( 'nm_gamification_installed', true );

	}

	/**
	 * Main Deactivation Hook.
	 *
	 * @MODIFIED: Removed flush_rewrite_rules.
	 * @MODIFIED: Changed role removal logic.
	 */
	public static function on_deactivation() {

		// ✅ NEW: Remove our custom role
		if ( get_role( 'quiz_taker' ) ) {
			remove_role( 'quiz_taker' );
		}

		// Clear all plugin cron jobs
		$hooks = array(
			'nm_generate_mcqs_cron',
			'nm_generate_mcqs_from_topics_cron',
			'nm_feed_import_cron',
			'nm_generate_current_affairs_mcq_cron',
			'nm_ca_queue_worker_cron',
			'nm_current_affairs_cron_hook',
			'nm_current_affairs_queue_worker_cron',
			'nm_initial_sync_cron',
			'nm_weekly_db_cleanup',
			'nm_monthly_buffer_history_cleanup',
			'nm_cleanup_rate_limits_cron',
			'nm_cleanup_notifications_cron',
			'nm_cleanup_security_logs_cron',
			'nm_daily_story_image_cleanup',
			'nm_recalculate_leaderboards_cron',
			'nm_email_digest_cron',
			'nm_send_daily_digest',
			'nm_embedding_backfill_cron',
			'nm_cleanup_old_mcqs_cron',
		);

		foreach ( $hooks as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}

		update_option( 'nm_plugin_deactivated_at', current_time( 'mysql' ) );

		// ❌ REMOVED: Flush Rewrite Rules (now in main plugin file)

	}

	/**
	 * ✅ NEW: Creates the custom 'quiz_taker' role
	 */
	private static function register_custom_roles() {
		// Remove old 'upload_files' capability from Subscriber, in case it's still there
		$subscriber_role = get_role( 'subscriber' );
		if ( $subscriber_role && $subscriber_role->has_cap( 'upload_files' ) ) {
			$subscriber_role->remove_cap( 'upload_files' );
		}

		// Add the new 'Quiz Taker' role
		add_role(
			'quiz_taker',
			'Quiz Taker',
			array(
				'read' => true, // Only basic read capabilities
			)
		);
	}

	/**
	 * Creates all 7 gamification tables
	 */
	private static function create_gamification_tables( $wpdb ) {
		$charset_collate = $wpdb->get_charset_collate();

		// 1. Rate Limits Table
		$sql_rate_limits = "CREATE TABLE {$wpdb->prefix}nm_rate_limits (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            attempt_key varchar(64) NOT NULL,
            action varchar(50) NOT NULL,
            identifier varchar(255) NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY attempt_key (attempt_key),
            KEY created_at (created_at),
            KEY action (action)
        ) $charset_collate;";
		dbDelta( $sql_rate_limits );

		// 2. Points Log Table
		$sql_points_log = "CREATE TABLE {$wpdb->prefix}nm_points_log (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            points int(11) NOT NULL,
            reason varchar(255) DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY created_at (created_at),
            KEY points (points)
        ) $charset_collate;";
		dbDelta( $sql_points_log );

		// 3. User Answers Table
		$sql_user_answers = "CREATE TABLE {$wpdb->prefix}nm_user_answers (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            mcq_id bigint(20) UNSIGNED NOT NULL,
            selected_answer varchar(10) NOT NULL,
            is_correct tinyint(1) NOT NULL DEFAULT 0,
            answered_at datetime NOT NULL,
            time_taken int(11) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY mcq_id (mcq_id),
            KEY answered_at (answered_at),
            KEY is_correct (is_correct),
            KEY user_mcq (user_id, mcq_id)
        ) $charset_collate;";
		dbDelta( $sql_user_answers );

		// 4. Certificates Table
		$sql_certificates = "CREATE TABLE {$wpdb->prefix}nm_certificates (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            certificate_id varchar(100) NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            achievement_key varchar(100) NOT NULL,
            achievement_name varchar(255) NOT NULL,
            issued_date datetime NOT NULL,
            verification_code varchar(50) NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY certificate_id (certificate_id),
            KEY user_id (user_id),
            KEY achievement_key (achievement_key),
            KEY issued_date (issued_date)
        ) $charset_collate;";
		dbDelta( $sql_certificates );

		// 5. Notifications Table
		$sql_notifications = "CREATE TABLE {$wpdb->prefix}nm_notifications (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            type varchar(50) NOT NULL,
            title varchar(255) NOT NULL,
            message text NOT NULL,
            data text,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY is_read (is_read),
            KEY created_at (created_at),
            KEY type (type)
        ) $charset_collate;";
		dbDelta( $sql_notifications );

		// 6. User Sessions Table
		$sql_sessions = "CREATE TABLE {$wpdb->prefix}nm_user_sessions (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            session_token varchar(64) NOT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent varchar(255) NOT NULL,
            login_time datetime NOT NULL,
            last_activity datetime NOT NULL,
            expires_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_token (session_token),
            KEY user_id (user_id),
            KEY expires_at (expires_at)
        ) $charset_collate;";
		dbDelta( $sql_sessions );

		// 7. Quiz Sessions Table
		$sql_quiz_sessions = "CREATE TABLE {$wpdb->prefix}nm_quiz_sessions (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            session_id varchar(64) NOT NULL,
            topic_id bigint(20) UNSIGNED DEFAULT NULL,
            total_questions int(11) NOT NULL DEFAULT 0,
            answered_questions int(11) NOT NULL DEFAULT 0,
            correct_answers int(11) NOT NULL DEFAULT 0,
            start_time datetime NOT NULL,
            end_time datetime DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'active',
            PRIMARY KEY  (id),
            UNIQUE KEY session_id (session_id),
            KEY user_id (user_id),
            KEY status (status),
            KEY start_time (start_time)
        ) $charset_collate;";
		dbDelta( $sql_quiz_sessions );
	}

	/**
	 * Creates the optimized MCQ data table.
	 * Delegates to NM_Database_Optimizer so there is a single source of truth.
	 */
	private static function create_optimizer_tables( $wpdb ) {
		if ( class_exists( 'NM_Database_Optimizer' ) ) {
			NM_Database_Optimizer::create_tables();
		}
	}
	/**
	 * Creates the mcq_embeddings table
	 */
	private static function create_embedding_table( $wpdb ) {
		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $wpdb->prefix . 'mcq_embeddings';

		$sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id bigint(20) UNSIGNED NOT NULL,
            embedding_hash varchar(64) NOT NULL,
            embedding longtext NOT NULL,
            question_text text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_id (post_id),
            KEY embedding_hash (embedding_hash),
            KEY created_at (created_at)
        ) {$charset_collate};";
		dbDelta( $sql );
	}

	/**
	 * Creates the nm_subscribers table
	 */
	private static function create_subscribers_table( $wpdb ) {
		$table_name      = $wpdb->prefix . 'nm_subscribers';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            email varchar(255) NOT NULL,
            name varchar(100) DEFAULT NULL,
            status varchar(20) DEFAULT 'active',
            source varchar(50) DEFAULT 'website',
            subscribed_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_email_date datetime DEFAULT NULL,
            confirm_token varchar(64) DEFAULT NULL,
            unsubscribe_token varchar(64) DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY email_unique (email),
            KEY status_index (status),
            KEY source_index (source)
        ) $charset_collate;";
		dbDelta( $sql );
	}

	/**
	 * Creates the generation log tables
	 */
	private static function create_generation_log_tables( $wpdb ) {
		$charset = $wpdb->get_charset_collate();
		$runs    = $wpdb->prefix . 'nm_generation_runs';
		$events  = $wpdb->prefix . 'nm_generation_events';

		$sql_runs = "CREATE TABLE $runs (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          started_at DATETIME NOT NULL,
          finished_at DATETIME NULL,
          trigger_type VARCHAR(20) NOT NULL DEFAULT 'manual',
          source_type VARCHAR(20) NOT NULL DEFAULT 'topic',
          source_ref VARCHAR(191) NULL,
          created_count INT NOT NULL DEFAULT 0,
          duplicate_count INT NOT NULL DEFAULT 0,
          error_count INT NOT NULL DEFAULT 0,
          notes VARCHAR(255) NULL,
          PRIMARY KEY (id),
          KEY k_started (started_at),
          KEY k_trigger (trigger_type),
          KEY k_source (source_type, source_ref)
        ) $charset;";
		dbDelta( $sql_runs );

		$sql_events = "CREATE TABLE $events (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          run_id BIGINT UNSIGNED NULL,
          ts DATETIME NOT NULL,
          event_type VARCHAR(20) NOT NULL,
          severity VARCHAR(20) NOT NULL DEFAULT 'info',
          source_type VARCHAR(20) NOT NULL,
          source_ref VARCHAR(191) NULL,
          mcq_id BIGINT UNSIGNED NULL,
          question_excerpt VARCHAR(255) NULL,
          duplicate_method VARCHAR(32) NULL,
          similarity DECIMAL(5,2) NULL,
          error_code VARCHAR(64) NULL,
          error_message TEXT NULL,
          meta LONGTEXT NULL,
          PRIMARY KEY (id),
          KEY k_run (run_id),
          KEY k_ts (ts),
          KEY k_type (event_type),
          KEY k_source (source_type, source_ref),
          KEY k_mcq (mcq_id)
        ) $charset;";
		dbDelta( $sql_events );
	}

	/**
	 * Creates the security log tables
	 */
	private static function create_security_log_tables( $wpdb ) {
		$table_name      = $wpdb->prefix . 'nm_security_log';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(50) NOT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent text,
            event_data longtext,
            severity enum('low','medium','high','critical') DEFAULT 'medium',
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY ip_address (ip_address),
            KEY event_type (event_type),
            KEY timestamp (timestamp),
            KEY severity (severity)
        ) $charset_collate;";
		dbDelta( $sql );
	}

	/**
	 * Sets default plugin options
	 */
	private static function set_default_options() {
		$defaults = array(
			'nm_enable_user_system'   => 1,
			'nm_enable_gamification'  => 1,
			'nm_enable_leaderboard'   => 1,
			'nm_enable_certificates'  => 1,
			'nm_enable_notifications' => 1,
			'nm_enable_pwa'           => 1,
			'nm_points_per_correct'   => 10,
			'nm_points_quiz_complete' => 50,
			'nm_points_daily_login'   => 5,
		);

		foreach ( $defaults as $key => $value ) {
			if ( get_option( $key ) === false ) {
				add_option( $key, $value );
			}
		}
	}
}
