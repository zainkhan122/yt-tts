<?php
/**
 * Groq_Client.php
 *
 * AI Provider implementation for the Groq API (OpenAI-compatible).
 * Matches TrendsStudio architecture with robust error handling and fallback waterfalls.
 *
 * @package DIT\TrendStudio\Content
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\AI\StructuredOutputSchema;
use DIT\TrendStudio\Infrastructure\Logger;

class Groq_Client implements AIProviderInterface {

    use AI_Network_Trait;

    // -------------------------------------------------------------------------
    // Constants
    // -------------------------------------------------------------------------

    const API_URL      = 'https://api.groq.com/openai/v1/chat/completions';
    const MODELS_URL   = 'https://api.groq.com/openai/v1/models';
	const DEFAULT_MODEL = 'openai/gpt-oss-120b'; // Best free model: json_schema strict + 65K output

    /**
     * How many seconds to wait between waterfall model switches.
     */
    const FALLBACK_DELAY_SECONDS = 2;

    /**
     * Max seconds to wait when respecting a Retry-After header on a 429.
     */
    const MAX_RETRY_AFTER_WAIT = 20;

    /**
     * Transient TTL for marking a model as "daily limit exhausted".
     */
    const EXHAUSTED_MODEL_TTL = 3600;

    // -------------------------------------------------------------------------
    // Properties
    // -------------------------------------------------------------------------

    /** @var string */
    private string $api_key;

    /** @var Logger */
    private $logger;

    /** @var PromptSchemaBuilder */
    private PromptSchemaBuilder $promptSchema;

	/** @var VisualManifestService */
	private VisualManifestService $visuals;

	/** @var string Last output schema from prompt builder (for json_schema enforcement) */
	private string $last_output_schema = '';

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    public function __construct( string $api_key, Logger $logger ) {
        $this->api_key      = $api_key;
        $this->logger       = $logger;
        $this->promptSchema = new PromptSchemaBuilder($logger);
        $this->visuals      = new VisualManifestService();
        $this->provider_slug = 'groq';
    }

    // -------------------------------------------------------------------------
    // Static Helpers (Settings / Config)
    // -------------------------------------------------------------------------

    /**
     * Retrieve API key from WP options or a defined constant.
     */
    public static function get_api_key(): string {
        $key = get_option( 'dit_ts_groq_api_key', '' );
        if ( ! empty( $key ) ) {
            return $key;
        }
        if ( defined( 'GROQ_API_KEY' ) ) {
            return \GROQ_API_KEY;
        }
        return '';
    }

    /**
     * Retrieve the user-selected primary model from WP options.
     */
    public static function get_model_id(): string {
        return get_option( 'dit_ts_groq_model', self::DEFAULT_MODEL );
    }

    /**
     * AIProviderInterface: return the active model name.
     */
    public function get_model(): string {
        return self::get_model_id();
    }

    // -------------------------------------------------------------------------
    // AIProviderInterface – Public Generation Methods
    // -------------------------------------------------------------------------

    public function generate( array $promptData ): array {
        return $this->generateFromResearch( $promptData, [
            'research_content' => '',
            'sources'          => [],
        ] );
    }

	public function generateFromResearch( array $promptData, array $researchData ): array {
		$visual_manifest = [];
		$output_schema = '';

		$bundle = $this->promptSchema->build_writing_bundle( $promptData, $researchData, $visual_manifest, $output_schema, $this->visuals, 10 );
		$this->last_output_schema = $output_schema;
		$raw = $this->chat_completion( $bundle['user_prompt'], true, $bundle['system_prompt'] );
		$article = $this->apply_visual_manifest( $raw, $visual_manifest );

		return is_array( $article ) ? $article : (array) $article;
	}

    public function generateCustomJson( string $prompt ): array {
        return $this->chat_completion( $prompt, true );
    }

    // -------------------------------------------------------------------------
    // Core Chat Completion – Waterfall with Retry Logic
    // -------------------------------------------------------------------------

	private function chat_completion( string $user_prompt, bool $json_mode = true, string $system_prompt = '' ): array {



        $primary_model = self::get_model_id();
        $model_chain   = array_merge( [ $primary_model ], $this->get_fallback_chain( $primary_model ) );

        $model_chain = \array_values( \array_filter( $model_chain, function ( $this_model ) {
            return ! $this->is_model_exhausted( $this_model );
        } ) );

        if ( empty( $model_chain ) ) {
            throw new AI_Exception(
                'All Groq models are currently rate-limited or exhausted. Please try again later.'
            );
        }

        $last_exception = null;

        foreach ( $model_chain as $index => $model ) {
            $is_fallback = $index > 0;

            if ( $is_fallback ) {
                $this->logger->warning( "Groq Waterfall: switching to model [{$index}] → {$model}" );
                \sleep( self::FALLBACK_DELAY_SECONDS );
            } else {
                $this->logger->info( "Calling Groq API (model: {$model})" );
            }

            try {
                return $this->attempt_single_model( $model, $user_prompt, $json_mode, $system_prompt );
            } catch ( AI_Exception $e ) {
                $last_exception = $e;
                $this->logger->warning( "Groq model [{$model}] failed: " . $e->getMessage() );
                continue;
            } catch ( \Exception $e ) {
                $last_exception = $e;
                $this->logger->error( "Groq critical error on model [{$model}]: " . $e->getMessage() );
                continue;
            }
        }

        throw new AI_Exception(
            'All Groq models in the fallback chain failed. Last error: ' .
            ( $last_exception ? $last_exception->getMessage() : 'Unknown error' )
        );
    }

	private function attempt_single_model( string $model, string $user_prompt, bool $json_mode, string $system_prompt = '' ): array {

		$final_system = ! empty( $system_prompt ) ? $system_prompt : 'You are an expert AI assistant. You MUST output valid JSON only. No markdown fences, no explanation, just raw JSON.';

		$messages = [
			[
				'role' => 'system',
				'content' => $final_system,
			],
			[
				'role' => 'user',
				'content' => $user_prompt,
			],
		];

		$body = [
			'model' => $model,
			'messages' => $messages,
			'temperature' => 0.7,
			'max_tokens' => 32768,
		];

		if ( $json_mode ) {
			$enforce = (bool) \get_option( 'dit_ts_ai_enforce_structured_output', true );
			$schema_capable = $this->model_supports_json_schema( $model );

			if ( $enforce && $schema_capable ) {
				$mode = StructuredOutputSchema::detect_mode_from_output_schema( $this->last_output_schema ?: '' );
				$body['response_format'] = [
					'type' => 'json_schema',
					'json_schema' => [
						'name' => 'trendstudioArticle',
						'strict' => $this->model_supports_json_schema_strict( $model ),
						'schema' => StructuredOutputSchema::json_schema_article( $mode ),
					],
				];
			} else {
				$body['response_format'] = [ 'type' => 'json_object' ];
			}
		}

        $request_args = [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => \wp_json_encode( $body ),
            'timeout' => 90,
        ];

        $max_attempts = 3;
        $last_error   = null;

        for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {

            $response = \wp_remote_post( self::API_URL, $request_args );

            if ( \is_wp_error( $response ) ) {
                $last_error = $response->get_error_message();
                if ( $attempt < $max_attempts ) {
                    \sleep( $this->exponential_backoff( $attempt ) );
                    continue;
                }
                throw new AI_Exception( "Groq API network error after {$max_attempts} attempts: {$last_error}" );
            }

            $code     = \wp_remote_retrieve_response_code( $response );
            $raw_body = \wp_remote_retrieve_body( $response );

            if ( $code === 401 ) {
                throw new AI_Exception( 'Groq API authentication failed (401). Check your API key.' );
            }

if ( $code === 429 ) {
                // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
                $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                    $headers = \wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse('groq', $code, $raw_body, (array) $headers);
                    Quota_State_Manager::calibrate_from_error('groq', $error_info);
                }

                $retry_after = $this->parse_retry_after( $response );
                $reason = class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry';

                if ( $retry_after !== null && $retry_after <= self::MAX_RETRY_AFTER_WAIT ) {
                    $this->logger->warning( "Groq [{$model}] rate limited. Waiting {$retry_after}s..." );
                    \sleep( (int) $retry_after + 1 );
                    $response = \wp_remote_post( self::API_URL, $request_args );
                    if ( ! \is_wp_error( $response ) && \wp_remote_retrieve_response_code( $response ) === 200 ) {
                        $raw_body = \wp_remote_retrieve_body( $response );
                        $code = 200;
                        if (class_exists(Quota_State_Manager::class)) {
                            Quota_State_Manager::record_success('groq', $model);
                        }
                    } else {
                        $this->mark_model_exhausted( $model );
                        throw new AI_Exception( "Groq [{$model}] still rate-limited. Marking exhausted.", array(
                            'reason' => $reason,
                            'provider' => 'groq',
                            'model' => $model,
                            'error_class' => $error_info['error_type'],
                            'quota_bucket' => $error_info['quota_bucket'],
                            'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                            'retry_after' => (int) $retry_after,
                            'http_code' => $code,
                            'error_body' => \substr( $raw_body, 0, 500 ),
                        ));
                    }
                } else {
                    $this->mark_model_exhausted( $model );
                    throw new AI_Exception( "Groq [{$model}] rate limit hit (429). Marking exhausted.", array(
                        'reason' => $reason,
                        'provider' => 'groq',
                        'model' => $model,
                        'error_class' => $error_info['error_type'],
                        'quota_bucket' => $error_info['quota_bucket'],
                        'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                        'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                        'http_code' => $code,
                        'error_body' => \substr( $raw_body, 0, 500 ),
                    ));
}
            }

		if ( $code >= 500 ) {
			if ( $attempt < $max_attempts ) {
				\sleep( $this->exponential_backoff( $attempt ) );
				continue;
			}
			throw new AI_Exception( "Groq API server error after {$max_attempts} attempts: {$code}" );
		}

		if ( $code !== 200 && ! empty( $body['response_format'] ) && $body['response_format']['type'] === 'json_schema' ) {
			$this->logger->warning( "Groq [{$model}] rejected json_schema response_format ({$code}). Retrying with json_object." );
			unset( $body['response_format'] );
			$body['response_format'] = [ 'type' => 'json_object' ];
			$request_args['body'] = \wp_json_encode( $body );
			$response = \wp_remote_post( self::API_URL, $request_args );
			if ( ! \is_wp_error( $response ) && \wp_remote_retrieve_response_code( $response ) === 200 ) {
				$raw_body = \wp_remote_retrieve_body( $response );
				$code = 200;
			}
		}

		if ( $code !== 200 ) {
                throw new AI_Exception( "Groq API returned {$code}: " . \substr( $raw_body, 0, 500 ) );
            }
            
            $data    = \json_decode( $raw_body, true );
            $content = $data['choices'][0]['message']['content'] ?? '';

            // @MODIFIED 2026-04-23 - Three-Layer Intelligence: record success with guard
            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success('groq', $model);
            }

            if ( empty( $content ) ) {
                throw new AI_Exception( "Groq [{$model}] returned empty content." );
            }

            if ( ! $json_mode ) {
                return [ 'content' => $content ];
            }

            $clean  = Sanitizer::clean( (string) $content );
            $parsed = Sanitizer::parse( $clean );

            if ( ! \is_array( $parsed ) ) {
                throw new AI_Exception( "Groq [{$model}] JSON parse failed." );
            }

            return $parsed;
        }

        throw new AI_Exception( "Groq [{$model}] exhausted all retry attempts." );
    }

	private function get_fallback_chain( string $current_model ): array {
		$candidates = [
			'openai/gpt-oss-120b',
			'openai/gpt-oss-20b',
			'llama-3.3-70b-versatile',
			'qwen/qwen3-32b',
			'meta-llama/llama-4-scout-17b-16e-instruct',
			'llama-3.1-8b-instant',
		];

		return \array_values( \array_filter( $candidates, fn( $m ) => $m !== $current_model ) );
	}

    private function is_model_exhausted( string $model ): bool {
        $key = 'dit_ts_groq_exhausted_' . \md5( $model );
        return \get_transient( $key ) === 'exhausted';
    }

    private function mark_model_exhausted( string $model ): void {
        $key = 'dit_ts_groq_exhausted_' . \md5( $model );
        \set_transient( $key, 'exhausted', self::EXHAUSTED_MODEL_TTL );
    }

    private function parse_retry_after( $response ): ?int {
        $headers     = \wp_remote_retrieve_headers( $response );
        $retry_after = $headers['retry-after'] ?? $headers['Retry-After'] ?? null;
        if ( $retry_after === null ) return null;
        if ( \is_numeric( $retry_after ) ) return (int) $retry_after;
        $timestamp = \strtotime( (string) $retry_after );
        if ( $timestamp !== false ) return \max( 0, $timestamp - \time() );
        return null;
    }

    private function exponential_backoff( int $attempt ): int {
        return \min( (int) \pow( 2, $attempt ), 15 );
    }

    private function build_writing_prompt( array $prompt_data, array $research_data, array &$visual_manifest = [], string &$output_schema_out = '' ): string {
        return $this->promptSchema->buildFromResearchPrompt(
            $prompt_data,
            $research_data,
            $visual_manifest,
            $output_schema_out,
            $this->visuals,
            10
        );
    }

    private function apply_visual_manifest( $data, array $visual_manifest ) {
        return $this->visuals->apply( $data, $visual_manifest );
    }

	public function test_connection(): array {
		return [
			'status' => 'connected',
			'model' => \count( self::get_curated_models() ) . ' curated models available',
		];
	}

	public static function get_curated_models(): array {
		return [
			'openai/gpt-oss-120b' => 'GPT-OSS 120B (Best for Magazine Writing — json_schema strict)',
			'openai/gpt-oss-20b' => 'GPT-OSS 20B (Fast Drafting — json_schema strict)',
			'llama-3.3-70b-versatile' => 'Llama 3.3 70B Versatile (Reliable Fallback — json_object)',
			'qwen/qwen3-32b' => 'Qwen-3 32B (Creative Alternative — json_object)',
			'meta-llama/llama-4-scout-17b-16e-instruct' => 'Llama 4 Scout 17B (Last Resort — json_schema best-effort)',
			'llama-3.1-8b-instant' => 'Llama 3.1 8B Instant (Ultra-Fast Draft — json_object)',
		];
	}

	public static function model_supports_json_schema( string $model_id ): bool {
		return in_array( $model_id, [
			'openai/gpt-oss-120b',
			'openai/gpt-oss-20b',
			'meta-llama/llama-4-scout-17b-16e-instruct',
		], true );
	}

	public static function model_supports_json_schema_strict( string $model_id ): bool {
		return in_array( $model_id, [
			'openai/gpt-oss-120b',
			'openai/gpt-oss-20b',
		], true );
	}

	public static function get_free_models(): array {
		return self::get_curated_models();
	}
}
