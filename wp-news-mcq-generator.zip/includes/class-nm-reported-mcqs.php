<?php
/**
 * Reported MCQs Class
 *
 * @version 1.1 - Refactored to register its own admin menu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Reported_MCQs {

	public static function init() {
		// ✅ MODIFIED: Added admin_menu hook
		add_action( 'admin_menu', array( self::class, 'register_submenu' ), 15 ); // 15 = after duplicate tool

		// This hook was already here
		add_action( 'admin_init', array( self::class, 'handle_clear_report_action' ) );
	}

	/**
	 * ✅ NEW: Register the submenu page
	 */
	public static function register_submenu() {
		add_submenu_page(
			'nm_mcq_generator',     // Parent Slug
			'Reported MCQs',       // Page Title
			'🚨 Reported MCQs',    // Menu Title
			'manage_options',      // Capability
			'nm_reported_mcqs',    // Menu Slug
			array( self::class, 'render_page' ) // Callback
		);
	}

	public static function handle_clear_report_action() {
		if ( isset( $_GET['action'], $_GET['mcq_id'], $_GET['_wpnonce'] ) && $_GET['action'] === 'nm_clear_report' ) {
			if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'nm_clear_report_nonce_' . $_GET['mcq_id'] ) ) {
				wp_die( 'Security check failed.' );
			}
			$post_id = intval( $_GET['mcq_id'] );
			delete_post_meta( $post_id, 'mcq_reported' );
			delete_post_meta( $post_id, 'mcq_report_reason' );
			wp_redirect( admin_url( 'admin.php?page=nm_reported_mcqs' ) );
			exit;
		}
	}

	public static function render_page() {
		?>
		<div class="wrap">
			<h1>🚨 Reported MCQs</h1>
			<p>Review the following MCQs that have been reported by users. You can edit the question or clear the report status.</p>
			
			<table class="wp-list-table widefat fixed striped">
				<thead><tr><th>Question</th><th>Reason</th><th>Actions</th></tr></thead>
				<tbody>
					<?php
					$query = new WP_Query(
						array(
							'post_type'      => 'mcq',
							'posts_per_page' => -1,
							'meta_key'       => 'mcq_reported',
							'meta_value'     => 'yes',
						)
					);
					if ( $query->have_posts() ) :
						while ( $query->have_posts() ) :
							$query->the_post();
							$id         = get_the_ID();
							$nonce      = wp_create_nonce( 'nm_clear_report_nonce_' . $id );
							$clear_link = admin_url( 'admin.php?page=nm_reported_mcqs&action=nm_clear_report&mcq_id=' . $id . '&_wpnonce=' . $nonce );
							$edit_link  = get_edit_post_link( $id );
							$view_link  = get_permalink( $id );
							?>
						<tr>
							<td><strong><a href="<?php echo esc_url( $edit_link ); ?>"><?php the_title(); ?></a></strong></td>
							<td><?php echo esc_html( get_post_meta( $id, 'mcq_report_reason', true ) ?: 'None' ); ?></td>
							<td>
								<a href="<?php echo esc_url( $edit_link ); ?>">Edit</a> |
								<a href="<?php echo esc_url( $view_link ); ?>" target="_blank">View</a> |
								<a href="<?php echo esc_url( $clear_link ); ?>" style="color:#a00;" onclick="return confirm('Are you sure you want to clear the report status for this MCQ?');">Clear Report</a>
							</td>
						</tr>
											<?php
					endwhile;
						wp_reset_postdata(); else :
							?>
						<tr><td colspan="3">✅ No reported MCQs.</td></tr>
											<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
?>
