<?php
/**
 * Link Whisper Bridge — auto-apply Link Whisper's contextual internal links.
 *
 * APPROACH (v3 — zone-only):
 * Instead of feeding LW the full post and filtering results, we give LW ONLY
 * the 3 allowed zones (intro, moat, features). This guarantees 100% of LW's
 * sentence-level suggestions target allowed-zone content.
 *
 * Flow:
 * 1. Extract intro/moat/features HTML from the post
 * 2. Concatenate into zone-only content
 * 3. Inject into Wpil_Model_Post::setContent() (in-memory, no DB write)
 * 4. Call LW's getPostSuggestions() — analyzes ONLY zone content
 * 5. LW returns phrases with suggestions (sentences + target posts)
 * 6. For each phrase: find anchor in zone HTML → insert <a> tag
 * 7. Reassemble zones back into full post content
 *
 * This leverages LW's full NLP: sentence splitting, title-word matching,
 * target-keyword scoring, AI relatedness — all working on zone content only.
 *
 * @since 2.34.14 Original bridge
 * @since 2.34.17 Reversed approach (target names in zone text)
 * @since 2.34.18 Zone-only approach: LW analyzes only allowed zones
 * @since 2.34.19 Multi-word anchors using LW's getSuggestionAnchorWords() min/max span
 */

namespace SEO_Article_Generator\Links;

use SEO_Article_Generator\Logger;

class Link_Whisper_Bridge {

	/** @var Logger */
	private $logger;

	/** Maximum links to auto-apply per post. */
	private const MAX_LINKS = 3;

	/**
	 * Canonical zone names where internal links are allowed.
	 * Must match Article_Schema::SECTION_REGISTRY keys.
	 */
	private const ALLOWED_ZONES = array( 'introduction', 'moat', 'features' );

	public function __construct( Logger $logger ) {
		$this->logger = $logger;
	}

	/**
	 * Is Link Whisper Premium active and its classes available?
	 */
	public static function is_available(): bool {
		return class_exists( 'Wpil_Suggestion' )
			&& class_exists( 'Wpil_Post' )
			&& class_exists( 'Wpil_Model_Post' );
	}

	/**
	 * Inject internal links using Link Whisper's NLP on zone-only content.
	 *
	 * @param string $content  The full post HTML content.
	 * @param int    $post_id  The WordPress post ID (must already exist).
	 * @return string Modified content with links inserted in allowed zones only.
	 */
	public function inject( string $content, int $post_id ): string {
		if ( $post_id <= 0 || trim( $content ) === '' ) {
			return $content;
		}

		try {
			// ─── Step 1: Extract allowed zone blocks ──────────────────
			$zones = $this->extract_allowed_zones( $content );
			if ( empty( $zones ) ) {
				$this->logger->info( "Link Whisper Bridge: no intro/moat/features zones found in post #{$post_id}" );
				return $content;
			}

			$zone_names = array_keys( $zones );
			$this->logger->info(
				"Link Whisper Bridge: extracted zones for post #{$post_id}",
				array( 'zones' => $zone_names )
			);

			// ─── Step 2: Count existing internal links in zones ───────
			// FIX: Before calling LW, count how many internal links already
			// exist in the allowed zones. On updates, previous runs may have
			// already injected links. Without this check, LW adds UP TO 3
			// MORE links every run, causing link accumulation (6+, 9+).
			// This mirrors the exact pattern used by Internal_Link_Injector.
			$existing_links = 0;
			foreach ( $zones as $zone ) {
				$existing_links += preg_match_all( '#<a\b[^>]*href\s*=#i', $zone['html'] );
			}
			$remaining_budget = max( 0, self::MAX_LINKS - $existing_links );

			if ( $remaining_budget <= 0 ) {
				$this->logger->info(
					"Link Whisper Bridge: post #{$post_id} already has {$existing_links} internal link(s) in zones (cap=" . self::MAX_LINKS . "). Skipping injection."
				);
				return $content;
			}

			// ─── Step 3: Build zone-only content for LW ──────────────
			$zone_content = '';
			foreach ( $zones as $zone ) {
				$zone_content .= $zone['html'] . "\n\n";
			}

			if ( trim( $zone_content ) === '' ) {
				$this->logger->info( "Link Whisper Bridge: zone content is empty for post #{$post_id}" );
				return $content;
			}

			// ─── Step 4: Inject zone content into LW post model ──────
			$post = new \Wpil_Model_Post( $post_id );
			$post->setContent( $zone_content );

			// ─── Step 5: Call LW suggestion engine ───────────────────
			$use_ai = false;
			if ( method_exists( 'Wpil_Settings', 'get_use_ai_suggestions' ) ) {
				$use_ai = (bool) \Wpil_Settings::get_use_ai_suggestions();
			}

			if ( $use_ai && method_exists( 'Wpil_Suggestion', 'getAIPostSuggestions' ) ) {
				$phrases = \Wpil_Suggestion::getAIPostSuggestions( $post, null, false, null, 0, 0 );
			} else {
				$phrases = \Wpil_Suggestion::getPostSuggestions( $post, null, false, null, 0, 0 );
			}

			if ( empty( $phrases ) || ! is_array( $phrases ) ) {
				$this->logger->info( "Link Whisper Bridge: LW returned no suggestions for post #{$post_id}" );
				return $content;
			}

			$this->logger->info(
				"Link Whisper Bridge: LW returned " . count( $phrases ) . " phrase(s) for post #{$post_id}",
				array(
					'engine'         => $use_ai ? 'ai' : 'keyword',
					'lw_min_anchor'  => $this->get_lw_min_anchor_length(),
					'lw_max_anchor'  => $this->get_lw_max_anchor_length(),
				)
			);

			// ─── Step 6: Apply links from LW suggestions ────────────
			$inserted   = 0;
			$used_urls  = array();
			$used_zones = array();
			$log_items  = array();

			foreach ( $phrases as $phrase ) {
				if ( $inserted >= $remaining_budget ) {
					break;
				}

				if ( empty( $phrase->suggestions ) || ! is_array( $phrase->suggestions ) ) {
					continue;
				}

				// Get the sentence text LW identified.
				$sentence_text = trim( strip_tags( $phrase->text ?? '' ) );
				if ( $sentence_text === '' || mb_strlen( $sentence_text ) < 10 ) {
					continue;
				}

				// Try each suggestion (sorted by score, best first).
				foreach ( $phrase->suggestions as $suggestion ) {
					if ( $inserted >= $remaining_budget ) {
						break;
					}

					$target_post = $suggestion->post ?? null;
					if ( ! $target_post || empty( $target_post->id ) ) {
						continue;
					}

					$tid = (int) $target_post->id;
					if ( $tid === $post_id ) {
						continue;
					}

					// Get target URL.
					$url = '';
					if ( method_exists( $target_post, 'getViewLink' ) ) {
						$url = $target_post->getViewLink();
					}
					if ( empty( $url ) ) {
						$url = get_permalink( $tid );
					}
					if ( empty( $url ) ) {
						continue;
					}

					// Skip if URL already in the full post.
					if ( strpos( $content, $url ) !== false ) {
						continue;
					}

					// Skip if we already used this URL.
					if ( isset( $used_urls[ $url ] ) ) {
						continue;
					}

					// ─── Find which zone contains this sentence ───
					$found_zone = null;
					foreach ( $zones as $zkey => $zone ) {
						$zone_plain = wp_strip_all_tags( html_entity_decode( $zone['html'], ENT_QUOTES, 'UTF-8' ) );
						if ( $this->sentence_in_text( $zone_plain, $sentence_text ) ) {
							$found_zone = $zkey;
							break;
						}
					}

					if ( $found_zone === null ) {
						continue;
					}

					// ─── Derive anchor text from LW's suggestion ───
					// LW provides the matched words; use them to build the anchor.
					$anchor = $this->derive_anchor( $sentence_text, $suggestion, $target_post );
					if ( $anchor === '' ) {
						continue;
					}

					// ─── Insert link into zone HTML ─────────────────
					$zone_html = $zones[ $found_zone ]['html'];
					$inserted_html = $this->insert_anchor( $zone_html, $anchor, $url );

					if ( $inserted_html === null ) {
						continue;
					}

					$zones[ $found_zone ]['html'] = $inserted_html;
					$used_urls[ $url ] = true;
					$inserted++;
					$log_items[] = array(
						'target_id'   => $tid,
						'target_name' => $target_post->getTitle() ?? '',
						'zone'        => $found_zone,
						'anchor'      => $anchor,
						'word_count'  => str_word_count( $anchor ),
						'url'         => $url,
						'score'       => (float) ( $suggestion->total_score ?? 0 ),
						'sentence'    => mb_substr( $sentence_text, 0, 80 ),
					);

					// Only one link per sentence.
					break;
				}
			}

			// ─── Step 7: Reassemble zones into full content ─────────
			if ( $inserted > 0 ) {
				$content = $this->reassemble_zones( $content, $zones );
				$this->store_link_meta( $post_id, $log_items );
				$this->logger->info(
					"Link Whisper Bridge: applied {$inserted} link(s) to post #{$post_id} (existing={$existing_links}, budget={$remaining_budget})",
					array( 'links' => $log_items )
				);
			} else {
				$this->logger->info(
					"Link Whisper Bridge: no links placed for post #{$post_id} (existing={$existing_links}, budget={$remaining_budget})",
					array(
						'phrases'     => count( $phrases ),
						'zones'       => $zone_names,
						'engine'      => $use_ai ? 'ai' : 'keyword',
					)
				);
			}

			return $content;

		} catch ( \Throwable $e ) {
			$this->logger->warning(
				'Link Whisper Bridge error: ' . $e->getMessage()
			);
			return $content;
		}
	}

	// ─── Anchor derivation ──────────────────────────────────────────────

	/**
	 * Derive anchor text from LW's sentence and suggestion data.
	 *
	 * Uses LW's getSuggestionAnchorWords() to find the min/max word positions
	 * of the matched stemmed words in the sentence, then extracts the original
	 * words spanning that range. This produces multi-word anchors that respect
	 * LW's min/max anchor size settings.
	 *
	 * @param string            $sentence    The sentence text LW identified.
	 * @param object            $suggestion  LW suggestion object.
	 * @param \Wpil_Model_Post  $target_post The target post.
	 * @return string Anchor text or '' if not usable.
	 */
	private function derive_anchor( string $sentence, $suggestion, $target_post ): string {
		// Try using LW's matched words with getSuggestionAnchorWords() for proper span.
		$words = $suggestion->words ?? array();
		if ( ! empty( $words ) && is_array( $words ) ) {
			$anchor = $this->compute_anchor_from_lw_positions( $sentence, $words );
			if ( $anchor !== '' && $this->is_valid_anchor( $anchor ) ) {
				return $anchor;
			}
		}

		// Fallback: use target post title.
		$title = $target_post->getTitle() ?? '';
		if ( $title === '' ) {
			return '';
		}

		$anchor = $this->clean_title_anchor( $title );
		if ( $anchor !== '' && $this->is_valid_anchor( $anchor ) ) {
			return $anchor;
		}

		return '';
	}

	/**
	 * Compute anchor text using LW's getSuggestionAnchorWords() min/max positions.
	 *
	 * Replicates the logic from Wpil_Suggestion::addAnchors():
	 * 1. Split sentence into raw words (preserve original case)
	 * 2. Build stemmed array (preserving keys, removing ignored words)
	 * 3. Call Wpil_Suggestion::getSuggestionAnchorWords() to get min/max positions
	 * 4. Extract original words from min to max position
	 *
	 * This produces multi-word anchors that span all words between the first
	 * and last matched word, matching what LW's editor UI would show.
	 *
	 * @param string   $sentence       The original sentence text.
	 * @param string[] $suggestion_words LW's stemmed matched words.
	 * @return string The anchor text in original case, or ''.
	 */
	private function compute_anchor_from_lw_positions( string $sentence, array $suggestion_words ): string {
		// Step 1: Split sentence into raw words (same as addAnchors).
		$sentence_clean = trim( preg_replace( '/\s+/', ' ', $sentence ) );
		$words_real = array_map( function ( $w ) {
			return trim( $w, "():'\"" );
		}, explode( ' ', $sentence_clean ) );

		if ( empty( $words_real ) ) {
			return '';
		}

		// Step 2: Build stemmed array, removing ignored/short words (preserving keys).
		$stemmed = $words_real;
		foreach ( $stemmed as $key => $value ) {
			$value = trim( $value, '.,;:!?()[]{}"\'-' );
			if ( mb_strlen( $value ) < 2 ) {
				unset( $stemmed[ $key ] );
				continue;
			}
			$stemmed[ $key ] = \Wpil_Stemmer::Stem( mb_strtolower( strip_tags( $value ) ) );
		}

		if ( empty( $stemmed ) ) {
			return '';
		}

		// Step 3: Call LW's getSuggestionAnchorWords() to get min/max positions.
		// This is a public static method that handles duplicate word disambiguation.
		if ( ! method_exists( 'Wpil_Suggestion', 'getSuggestionAnchorWords' ) ) {
			// Fallback to simple reconstruction if LW method unavailable.
			return $this->reconstruct_anchor_from_words( $sentence, $suggestion_words );
		}

		$anchor_indexes = \Wpil_Suggestion::getSuggestionAnchorWords( $stemmed, $suggestion_words, true );

		if ( empty( $anchor_indexes ) || ! isset( $anchor_indexes['min'], $anchor_indexes['max'] ) ) {
			return '';
		}

		$min = (int) $anchor_indexes['min'];
		$max = (int) $anchor_indexes['max'];

		// Step 4: Validate against LW's min/max anchor settings.
		$span_length = $max - $min + 1;
		$lw_min = $this->get_lw_min_anchor_length();
		$lw_max = $this->get_lw_max_anchor_length();

		if ( $span_length < $lw_min ) {
			return '';
		}
		if ( $lw_max > 0 && $span_length > $lw_max ) {
			return '';
		}

		// Step 5: Extract original words from min to max position.
		if ( ! isset( $words_real[ $min ] ) || ! isset( $words_real[ $max ] ) ) {
			return '';
		}

		$anchor_parts = array();
		for ( $i = $min; $i <= $max; $i++ ) {
			if ( isset( $words_real[ $i ] ) ) {
				$anchor_parts[] = $words_real[ $i ];
			}
		}

		if ( empty( $anchor_parts ) ) {
			return '';
		}

		return implode( ' ', $anchor_parts );
	}

	/**
	 * Get LW's configured minimum anchor length.
	 *
	 * @return int Minimum word count (default 1).
	 */
	private function get_lw_min_anchor_length(): int {
		if ( method_exists( 'Wpil_Suggestion', 'get_min_anchor_length' ) ) {
			return (int) \Wpil_Suggestion::get_min_anchor_length();
		}
		if ( method_exists( 'Wpil_Settings', 'getSuggestionMinAnchorSize' ) ) {
			return (int) \Wpil_Settings::getSuggestionMinAnchorSize();
		}
		return 1;
	}

	/**
	 * Get LW's configured maximum anchor length.
	 *
	 * @return int Maximum word count (default 5).
	 */
	private function get_lw_max_anchor_length(): int {
		if ( method_exists( 'Wpil_Suggestion', 'get_max_anchor_length' ) ) {
			return (int) \Wpil_Suggestion::get_max_anchor_length();
		}
		if ( method_exists( 'Wpil_Settings', 'getSuggestionMaxAnchorSize' ) ) {
			return (int) \Wpil_Settings::getSuggestionMaxAnchorSize();
		}
		return 5;
	}

	/**
	 * Fallback: reconstruct anchor from individual stemmed word matches.
	 *
	 * Used only when Wpil_Suggestion::getSuggestionAnchorWords() is unavailable.
	 *
	 * @param string   $sentence The original sentence.
	 * @param string[] $words    LW's stemmed matched words.
	 * @return string The anchor text in original case, or ''.
	 */
	private function reconstruct_anchor_from_words( string $sentence, array $words ): string {
		$sentence_lower = mb_strtolower( $sentence );
		$sentence_words = preg_split( '/\s+/', $sentence );

		$matched = array();
		foreach ( $words as $stemmed_word ) {
			$stemmed_lower = mb_strtolower( $stemmed_word );
			foreach ( $sentence_words as $sw ) {
				$sw_lower = mb_strtolower( trim( $sw, '.,;:!?()[]{}"\'-' ) );
				if ( $sw_lower === $stemmed_lower || str_starts_with( $sw_lower, $stemmed_lower ) ) {
					$matched[] = trim( $sw, '.,;:!?()[]{}"\'-' );
					break;
				}
			}
		}

		if ( empty( $matched ) ) {
			return '';
		}

		return implode( ' ', $matched );
	}

	/**
	 * Derive a clean anchor from a post title.
	 *
	 * Strips SEO suffixes, version numbers, generic words.
	 */
	private function clean_title_anchor( string $title ): string {
		// Strip SEO suffix: "X Download ... - Softwares Wave"
		$parts = preg_split( '/\s+(Download|Free Download|\|)\s*/i', $title );
		$name  = trim( $parts[0] ?? '' );
		// Remove trailing version.
		$name = trim( preg_replace( '/\b\d+(\.\d+)+.*$/', '', $name ) );
		$name = trim( preg_replace( '/\s+/', ' ', $name ) );

		if ( $name === '' || mb_strlen( $name ) < 3 ) {
			return '';
		}

		return $name;
	}

	/**
	 * Check if an anchor text is valid (not generic, not too short).
	 */
	private function is_valid_anchor( string $anchor ): bool {
		if ( mb_strlen( $anchor ) < 3 ) {
			return false;
		}

		$generic = array(
			'windows', 'macos', 'linux', 'android', 'ios', 'iphone', 'ipad',
			'desktop', 'laptop', 'mobile', 'tablet', 'browser', 'chrome',
			'firefox', 'edge', 'safari', 'opera', 'download', 'free',
			'official', 'latest', 'version', 'update', 'software', 'app',
			'application', 'tool', 'utility', 'program', 'feature', 'features',
			'settings', 'options', 'menu', 'file', 'files', 'folder', 'screen',
			'video', 'audio', 'image', 'photo', 'music', 'player', 'editor',
			'converter', 'manager', 'security', 'antivirus', 'firewall',
			'backup', 'restore', 'scan', 'clean', 'fix', 'repair',
			'install', 'uninstall', 'setup', 'run', 'open', 'click',
			'select', 'choose', 'start', 'stop', 'play', 'pause',
			'support', 'help', 'guide', 'tutorial', 'tips', 'tricks',
			'best', 'top', 'new', 'old', 'pro', 'premium', 'lite',
		);

		$words = preg_split( '/\s+/', mb_strtolower( $anchor ) );
		$non_generic = array_filter( $words, function ( $w ) use ( $generic ) {
			return ! in_array( $w, $generic, true );
		} );

		if ( empty( $non_generic ) ) {
			return false;
		}

		// Single-word anchors must be proper nouns (capitalized).
		if ( count( $words ) === 1 && $anchor !== ucfirst( $anchor ) && $anchor !== mb_strtoupper( $anchor ) ) {
			return false;
		}

		return true;
	}

	// ─── Sentence matching ──────────────────────────────────────────────

	/**
	 * Check if a sentence appears in zone text.
	 *
	 * Uses a fuzzy match: takes the first N words of the sentence (enough to
	 * be distinctive) and checks if they appear in the zone text. This handles
	 * minor formatting differences between LW's sentence and our zone text.
	 *
	 * @param string $zone_text  Plain text of the zone.
	 * @param string $sentence   The sentence LW identified.
	 * @return bool True if the sentence is found in the zone.
	 */
	private function sentence_in_text( string $zone_text, string $sentence ): bool {
		// Normalize both strings for comparison.
		$zone_norm    = preg_replace( '/\s+/', ' ', trim( mb_strtolower( $zone_text ) ) );
		$sentence_norm = preg_replace( '/\s+/', ' ', trim( mb_strtolower( $sentence ) ) );

		// Direct substring match.
		if ( strpos( $zone_norm, $sentence_norm ) !== false ) {
			return true;
		}

		// Fuzzy: take first 8 words of sentence and search.
		$sent_words = explode( ' ', $sentence_norm );
		if ( count( $sent_words ) >= 5 ) {
			$needle = implode( ' ', array_slice( $sent_words, 0, min( 8, count( $sent_words ) ) ) );
			if ( strpos( $zone_norm, $needle ) !== false ) {
				return true;
			}
		}

		// Fuzzy: take last 8 words.
		if ( count( $sent_words ) >= 5 ) {
			$needle = implode( ' ', array_slice( $sent_words, -8 ) );
			if ( strpos( $zone_norm, $needle ) !== false ) {
				return true;
			}
		}

		return false;
	}

	// ─── Link insertion ─────────────────────────────────────────────────

	/**
	 * Insert an <a> tag wrapping the first occurrence of $anchor in $html.
	 *
	 * @param string $html   Zone HTML.
	 * @param string $anchor Anchor text.
	 * @param string $url    Target URL.
	 * @return string|null Modified HTML or null on failure.
	 */
	private function insert_anchor( string $html, string $anchor, string $url ): ?string {
		// Find the anchor in the HTML (case-insensitive, preserving case).
		$pos = mb_stripos( $html, $anchor );
		if ( $pos === false ) {
			return null;
		}

		// Don't insert if already inside an <a> tag.
		$before = mb_substr( $html, 0, $pos );
		if ( preg_match( '/<a\s[^>]*$/i', $before ) ) {
			return null;
		}

		// Check if there's already a link nearby after.
		$after = mb_substr( $html, $pos );
		if ( preg_match( '/^' . preg_quote( $anchor, '/' ) . '\s*<\/a>/i', $after ) ) {
			return null;
		}

		// Extract the exact text to wrap (preserve original case).
		$actual = mb_substr( $html, $pos, mb_strlen( $anchor ) );
		$link   = '<a href="' . esc_url( $url ) . '">' . $actual . '</a>';

		return mb_substr( $html, 0, $pos ) . $link . mb_substr( $html, $pos + mb_strlen( $anchor ) );
	}

	// ─── Zone parsing ───────────────────────────────────────────────────

	/**
	 * Extract the 3 allowed zone blocks from the full content.
	 *
	 * @param string $content  Full post HTML.
	 * @return array<string,array{full_match:string,html:string,start:int,end:int}>
	 */
	private function extract_allowed_zones( string $content ): array {
		$zones   = array();
		$pattern = '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"([^"]+)"[^}]*\}\s*-->\s*\n(.*?)\n\s*<!--\s*\/wp:seo-gen\/section\s*-->/s';

		if ( preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $matches as $match ) {
				$zone_name = $match[1][0];
				if ( ! in_array( $zone_name, self::ALLOWED_ZONES, true ) ) {
					continue;
				}
				$zones[ $zone_name ] = array(
					'full_match' => $match[0][0],
					'html'       => $match[2][0],
					'start'      => $match[0][1],
					'end'        => $match[0][1] + strlen( $match[0][0] ),
				);
			}
		}

		return $zones;
	}

	/**
	 * Replace the zone blocks in the full content with their modified versions.
	 *
	 * @param string $content  Original full HTML.
	 * @param array  $zones    Modified zone data.
	 * @return string Reassembled content.
	 */
	private function reassemble_zones( string $content, array $zones ): string {
		uasort( $zones, function ( $a, $b ) {
			return $b['start'] <=> $a['start'];
		} );

		foreach ( $zones as $zone ) {
			if ( preg_match( '/^(<!--\s*wp:seo-gen\/section\s+\{[^}]*\}\s*-->\s*\n)/s', $zone['full_match'], $prefix ) ) {
				$new_block = $prefix[1] . $zone['html'] . "\n" . '<!-- /wp:seo-gen/section -->';
			} else {
				$new_block = $zone['full_match'];
			}
			$content = substr_replace( $content, $new_block, $zone['start'], $zone['end'] - $zone['start'] );
		}

		return $content;
	}

	// ─── Link Whisper meta storage ──────────────────────────────────────

	/**
	 * Store applied links in Link Whisper's wpil_links post meta.
	 *
	 * @param int   $post_id    Post ID.
	 * @param array $log_items  Applied link data.
	 */
	private function store_link_meta( int $post_id, array $log_items ): void {
		if ( ! method_exists( 'Wpil_Toolbox', 'get_encoded_post_meta' ) ) {
			return;
		}

		$existing = \Wpil_Toolbox::get_encoded_post_meta( $post_id, 'wpil_links', true );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		foreach ( $log_items as $item ) {
			$existing[] = array(
				'post_origin'          => 'internal',
				'site_url'             => '',
				'sentence'             => $item['anchor'],
				'sentence_with_anchor' => '<a href="' . esc_url( $item['url'] ) . '">' . $item['anchor'] . '</a>',
				'id'                   => $item['target_id'],
				'type'                 => 'post',
			);
		}

		if ( method_exists( 'Wpil_Toolbox', 'update_encoded_post_meta' ) ) {
			\Wpil_Toolbox::update_encoded_post_meta( $post_id, 'wpil_links', $existing );
		}
	}
}
