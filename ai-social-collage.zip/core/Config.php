<?php
namespace AiSocialCollage;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Config {

    // ── Plugin Meta ─────────────────────────────────────────────────────────
	const VERSION = '3.0.0';

    // ── Database Table Names (without prefix, add $wpdb->prefix when using) ─
    const TABLE_JOBS = 'ai_collage_jobs';
    const TABLE_LOGS = 'ai_collage_logs';
    const TABLE_API_CALLS = 'ai_collage_api_calls';

    // ── WordPress Option Names ─────────────────────────────────────────────
    const OPTION_CAMPAIGNS = 'ai_collage_campaigns';
const OPTION_GEMINI_KEY = 'ai_collage_gemini_key';
	const OPTION_GROQ_KEY = 'ai_collage_groq_key';
	const OPTION_SERP_API_KEY = 'ai_collage_serp_api_key';
	const OPTION_CLOUDINARY_CLOUD_NAME = 'ai_collage_cloudinary_cloud_name';
	const OPTION_CLOUDINARY_API_KEY = 'ai_collage_cloudinary_api_key';
	const OPTION_CLOUDINARY_API_SECRET = 'ai_collage_cloudinary_api_secret';
	const OPTION_GEMINI_MODEL = 'ai_collage_gemini_model';
	const OPTION_GROQ_MODEL = 'ai_collage_groq_model';
    const OPTION_RETENTION_DAYS = 'ai_collage_retention_days';
    const OPTION_LOG_RETENTION_DAYS = 'ai_collage_log_retention_days';
    const OPTION_IMAGE_RETENTION_DAYS = 'ai_collage_image_retention_days';
    const OPTION_GENERATED_POST_RETENTION_DAYS = 'ai_collage_generated_post_retention_days';
    const OPTION_GENERATED_POST_RETENTION_CATEGORIES = 'ai_collage_generated_post_retention_categories';
    const OPTION_SOURCE_POST_RETENTION_DAYS = 'ai_collage_source_post_retention_days';
    const OPTION_SOURCE_POST_RETENTION_CATEGORIES = 'ai_collage_source_post_retention_categories';
    const OPTION_DELETE_DATA_ON_UNINSTALL = 'ai_collage_delete_data_on_uninstall';
    const OPTION_BRAND_NAME = 'ai_collage_brand_name';
    const OPTION_BRAND_URL = 'ai_collage_brand_url';
    const OPTION_BRAND_LOGO_ID = 'ai_collage_brand_logo_id';
    const OPTION_BRAND_LOGO_URL = 'ai_collage_brand_logo_url';
    const OPTION_BRAND_PRIMARY_COLOR = 'ai_collage_brand_primary_color';
    const OPTION_BRAND_SECONDARY_COLOR = 'ai_collage_brand_secondary_color';
	const OPTION_BRAND_ACCENT_COLOR = 'ai_collage_brand_accent_color';
	const OPTION_BRAND_EMPHASIS_COLOR = 'ai_collage_brand_emphasis_color';
	const OPTION_BRAND_KEY_TERM_COLOR = 'ai_collage_brand_key_term_color';
	const OPTION_BRAND_BREAKING_COLOR = 'ai_collage_brand_breaking_color';
	const OPTION_BRAND_TEXT_BACKING_COLOR = 'ai_collage_brand_text_backing_color';
	const OPTION_BRAND_LOGO_POSITION = 'ai_collage_brand_logo_position';
	const OPTION_BRAND_FONT_HEADLINE = 'ai_collage_brand_font_headline';
    const OPTION_BRAND_FONT_BODY = 'ai_collage_brand_font_body';
	const OPTION_FONT_SIZE_PRESET = 'ai_collage_font_size_preset';
	const OPTION_HEADING_FONT_SIZE = 'ai_collage_heading_font_size';
	const OPTION_HEADING_LINE_HEIGHT = 'ai_collage_heading_line_height';
	const OPTION_HEADING_PADDING = 'ai_collage_heading_padding';
	const OPTION_HEADING_BG_COLOR = 'ai_collage_heading_bg_color';
	const OPTION_HEADING_TEXT_COLOR = 'ai_collage_heading_text_color';
	const OPTION_DESC_FONT_SIZE = 'ai_collage_desc_font_size';
	const OPTION_DESC_LINE_HEIGHT = 'ai_collage_desc_line_height';
	const OPTION_DESC_PADDING = 'ai_collage_desc_padding';
	const OPTION_DESC_BG_COLOR = 'ai_collage_desc_bg_color';
	const OPTION_DESC_TEXT_COLOR = 'ai_collage_desc_text_color';
	const OPTION_BRAND_BAR_PADDING = 'ai_collage_brand_bar_padding';
	const OPTION_BRAND_BAR_BG_COLOR = 'ai_collage_brand_bar_bg_color';
	const OPTION_BRAND_BAR_TEXT_COLOR = 'ai_collage_brand_bar_text_color';
	const OPTION_BRAND_BAR_FONT_SIZE = 'ai_collage_brand_bar_font_size';
	const OPTION_BRAND_BAR_LETTER_SPACING = 'ai_collage_brand_bar_letter_spacing';
	const OPTION_BRAND_BAR_ACCENT_LINE = 'ai_collage_brand_bar_accent_line';
	const OPTION_BRAND_BAR_HEIGHT_PCT = 'ai_collage_brand_bar_height_pct';
	const OPTION_BRAND_SEPARATOR_HEIGHT_PCT = 'ai_collage_brand_separator_height_pct';
	const OPTION_HEADING_HEIGHT_PROPORTION = 'ai_collage_heading_height_proportion';
	const OPTION_DESC_HEIGHT_PROPORTION = 'ai_collage_desc_height_proportion';
	const OPTION_ENABLE_DESCRIPTION = 'ai_collage_enable_description';
	const OPTION_IMAGE_HEIGHT_OVERRIDE = 'ai_collage_image_height_pct_override';
	const OPTION_LOGO_MAX_HEIGHT_BOTTOM = 'ai_collage_logo_max_height_bottom';
	const OPTION_LOGO_MAX_WIDTH_BOTTOM = 'ai_collage_logo_max_width_bottom';
	const OPTION_LOGO_MAX_HEIGHT_TOP = 'ai_collage_logo_max_height_top';
	const OPTION_LOGO_MAX_WIDTH_TOP = 'ai_collage_logo_max_width_top';
	const OPTION_SMART_AI_ENABLED = 'ai_collage_smart_ai_enabled';
	const OPTION_AUTO_COLOR_ENABLED = 'ai_collage_auto_color_enabled';
	const OPTION_SMART_CROP_ENABLED = 'ai_collage_smart_crop_enabled';
    const OPTION_SHOW_PLUGIN_CREDIT = 'ai_collage_show_plugin_credit';
	const OPTION_CUSTOM_PROVIDERS = 'ai_collage_custom_providers';
	const OPTION_OPENROUTER_LAST_SYNC = 'ai_collage_openrouter_last_sync';
	const OPTION_ZEN_LAST_SYNC = 'ai_collage_zen_last_sync';
	const OPTION_CROSS_PROVIDER_FALLBACK = 'ai_collage_cross_provider_fallback';
	const OPTION_AI_MAX_OUTPUT_TOKENS = 'ai_collage_ai_max_output_tokens';
	const OPTION_PIPELINE_PAUSED = 'ai_collage_pipeline_paused';
	const OPTION_VIABILITY_SCORING_ENABLED = 'ai_collage_viability_scoring_enabled';
	const OPTION_VIABILITY_SCORE_THRESHOLD = 'ai_collage_viability_score_threshold';
	const OPTION_VIABILITY_LOG_ONLY_MODE = 'ai_collage_viability_log_only_mode';
	const OPTION_IMAGE_EXTRACTION_ENABLED = 'ai_collage_image_extraction_enabled';
	const OPTION_IMAGE_EXTRACTION_DEBUG = 'ai_collage_image_extraction_debug';
	const OPTION_VERIFICATION_ENABLED = 'ai_collage_verification_enabled';
	const OPTION_VERIFICATION_PROVIDER_CHAIN = 'ai_collage_verification_provider_chain';
	const OPTION_VERIFICATION_CONFIDENCE_THRESHOLD = 'ai_collage_verification_threshold';
	const OPTION_HF_API_KEY = 'ai_collage_hf_api_key';
	const OPTION_GOOGLE_VISION_KEY = 'ai_collage_google_vision_key';
	const OPTION_MAX_QUEUE_DEPTH = 'ai_collage_max_queue_depth';
	const OPTION_HEALTH_MONITOR_FORCED_RUN = 'ai_collage_health_monitor_forced_run';
	const OPTION_LAST_CLEANUP_RUN = 'ai_collage_last_cleanup_run';

	// ── Newsroom Workflow & Posting Options ──────────────────────────────
	const OPTION_PUBLISH_MODE = 'ai_collage_publish_mode'; // 'draft' or 'publish'
	const OPTION_PRIME_TIME_ENABLED = 'ai_collage_prime_time_enabled';
	const OPTION_PRIME_TIME_SLOTS = 'ai_collage_prime_time_slots'; // JSON array of times e.g., ['08:00', '13:00', '20:00']
	const OPTION_WHATSAPP_BROADCAST = 'ai_collage_whatsapp_broadcast';
	const OPTION_AUTO_HASHTAGS_ENABLED = 'ai_collage_auto_hashtags_enabled';
	const OPTION_HASHTAG_STRATEGY = 'ai_collage_hashtag_strategy'; // 'ai' or 'trending'
	const OPTION_APPEND_TAGS_TO_POST = 'ai_collage_append_tags_to_post';

    // ── Post Meta Keys ─────────────────────────────────────────────────────
	const META_CAMPAIGN_DATA = '_ai_collage_campaign_data';
	const META_IS_AI_COLLAGE = '_is_ai_social_collage';
	const META_DOMINANT_COLORS = '_ai_collage_dominant_colors';
	const META_FOCAL_POINT = '_ai_collage_focal_point';
	const META_RSS_SOURCE_URL = '_ai_collage_rss_source_url';
	const META_RSS_SOURCE_NAME = '_ai_collage_rss_source_name';
	const META_AUTO_META = '_ai_collage_auto_meta';
	const META_RSS_CONTENT = '_ai_collage_feed_content';
	const META_RSS_SOURCE_IMAGE = '_ai_collage_rss_source_image';
	const META_RSS_SOURCE_VIDEO = '_ai_collage_rss_source_video';
	const META_SOURCE_VIDEO = '_ai_collage_source_video';
	const META_PREPROCESSED_IMAGE = '_ai_collage_preprocessed_image';
	const META_WHATSAPP_MESSAGE = '_ai_collage_whatsapp_message';
	const META_GENERATED_HASHTAGS = '_ai_collage_generated_hashtags';
	const META_VERIFICATION_ISSUES = '_ai_collage_verification_issues';
	const META_VERIFICATION_DETAILS = '_ai_collage_verification_details';
	const META_VERIFICATION_CONFIDENCE = '_ai_collage_verification_confidence';
	const META_VERIFICATION_PROVIDER = '_ai_collage_verification_provider';
	const PROVIDER_VERIFICATION_HF = 'verification_hf';
	const PROVIDER_VERIFICATION_GOOGLE = 'verification_google';

// ── Action Scheduler Hooks ─────────────────────────────────────────────
	const ACTION_POLL_CAMPAIGNS = 'ai_social_collage_poll_campaigns';
	const ACTION_PROCESS_JOB = 'ai_social_collage_process_job';
	const ACTION_DAILY_CLEANUP = 'ai_social_collage_daily_cleanup';
	const ACTION_COMPLETED = 'ai_social_collage_completed';
	const ACTION_BEFORE_RENDER = 'ai_social_collage_before_render';
	const ACTION_AFTER_RENDER = 'ai_social_collage_after_render';
	const ACTION_SOCIAL_POST = 'ai_social_collage_social_post';
	const ACTION_POLL_FEEDS = 'ai_social_collage_poll_feeds';
	const ACTION_REFRESH_BUFFER_STATS = 'ai_social_collage_refresh_buffer_stats';
	const ACTION_SYNC_OPENROUTER_MODELS = 'ai_social_collage_sync_openrouter_models';
	const ACTION_SYNC_ZEN_MODELS = 'ai_social_collage_sync_zen_models';
	const ACTION_PUBLISH_SCHEDULED = 'ai_social_collage_publish_scheduled';
	const ACTION_RETRY_STUCK_R2 = 'ai_social_collage_retry_stuck_r2_uploads';
	const ACTION_RETRY_BUFFER_PENDING = 'ai_social_collage_retry_buffer_pending_shares';

	// ── Action Scheduler Group ─────────────────────────────────────────────
	const AS_GROUP = 'ai_social_collage_group';

// ── Job Status Values ─────────────────────────────────────────────────-
	const STATUS_PENDING = 'pending';
	const STATUS_REWRITING = 'rewriting';
	const STATUS_RENDERING = 'rendering';
	const STATUS_COMPLETED = 'completed';
	const STATUS_FAILED = 'failed';
	const STATUS_DISCARDED = 'discarded';
	const STATUS_READY_FOR_REVIEW = 'ready_for_review';
	const STATUS_SCHEDULED = 'scheduled';

    public static function get_all_job_statuses() {
        return [
            self::STATUS_PENDING,
            self::STATUS_REWRITING,
            self::STATUS_RENDERING,
            self::STATUS_COMPLETED,
            self::STATUS_FAILED,
            self::STATUS_DISCARDED,
            self::STATUS_SCHEDULED,
            self::STATUS_READY_FOR_REVIEW,
        ];
    }

    public static function is_valid_status( $status ) {
        return in_array( $status, self::get_all_job_statuses(), true );
    }

    // ── AI Provider Strategies ─────────────────────────────────────────────
    const STRATEGY_GEMINI = 'Gemini Only';
    const STRATEGY_GROQ = 'Groq';
    const DEFAULT_STRATEGY = self::STRATEGY_GEMINI;
	const DEFAULT_GEMINI_MODEL = 'gemini-2.0-flash';
	const DEFAULT_GROQ_MODEL = 'llama3-8b-8192';

    public static function get_strategies() {
        $strategies = [
            self::STRATEGY_GEMINI => 'Gemini Only',
            self::STRATEGY_GROQ => 'Groq (Fast)',
        ];
        $custom = self::get_custom_providers();
        foreach ( $custom as $profile ) {
            $id = $profile['id'] ?? '';
            if ( $id !== '' ) {
                $strategies[ $id ] = ( $profile['name'] ?? $id ) . ' (Custom)';
            }
        }
        return $strategies;
    }

    public static function is_valid_strategy( $strategy ) {
        return array_key_exists( $strategy, self::get_strategies() );
    }

    public static function strategy_to_provider( $strategy ) {
        $map = [
            self::STRATEGY_GEMINI => self::PROVIDER_GEMINI,
            self::STRATEGY_GROQ => self::PROVIDER_GROQ,
        ];
        if ( isset( $map[ $strategy ] ) ) {
            return $map[ $strategy ];
        }
        if ( self::is_custom_provider( $strategy ) ) {
            return $strategy;
        }
        return $strategy;
    }

    // ── Templates ──────────────────────────────────────────────────────────
    const TEMPLATE_NEWS_CARD     = 'news-card';
    const TEMPLATE_DUAL_PHOTO    = 'dual-photo';
    const TEMPLATE_TEXT_HEAVY    = 'text-heavy';
    const TEMPLATE_AUTO          = 'auto';
    const DEFAULT_TEMPLATE       = self::TEMPLATE_NEWS_CARD;

	public static function get_templates() {
		return [
			self::TEMPLATE_AUTO        => 'Auto — AI Selects Best',
			self::TEMPLATE_NEWS_CARD   => 'News Card — Single Photo',
			self::TEMPLATE_DUAL_PHOTO  => 'Dual Photo — Comparison',
			self::TEMPLATE_TEXT_HEAVY  => 'Text Heavy — Quote / Statement',
		];
	}

	public static function get_template_categories() {
		return [
			'entertainment'    => [ self::TEMPLATE_NEWS_CARD ],
			'tech'             => [ self::TEMPLATE_NEWS_CARD ],
			'celebrity-urdu'   => [ self::TEMPLATE_DUAL_PHOTO, self::TEMPLATE_NEWS_CARD ],
			'controversy-urdu' => [ self::TEMPLATE_NEWS_CARD ],
			'film-action'      => [ self::TEMPLATE_NEWS_CARD ],
			'emotional-urdu'   => [ self::TEMPLATE_DUAL_PHOTO ],
			'inspirational-urdu' => [ self::TEMPLATE_TEXT_HEAVY ],
			'breaking-urdu'    => [ self::TEMPLATE_NEWS_CARD ],
			'news'             => [ self::TEMPLATE_NEWS_CARD ],
			'modern'           => [ self::TEMPLATE_NEWS_CARD ],
			'impact'           => [ self::TEMPLATE_NEWS_CARD ],
			'sports'           => [ self::TEMPLATE_NEWS_CARD ],
			'politics'         => [ self::TEMPLATE_NEWS_CARD ],
		];
	}

	public static function get_category_badge_map() {
		return [
			'entertainment'      => 'تفریح',
			'tech'               => 'ٹیکنالوجی',
			'celebrity-urdu'     => 'مشہور',
			'controversy-urdu'   => 'تنازعہ',
			'film-action'        => 'فلم',
			'emotional-urdu'     => 'جذباتی',
			'inspirational-urdu' => 'متاثر',
			'breaking-urdu'      => 'بریکنگ',
			'news'               => 'خبر',
			'modern'             => 'جدید',
			'impact'             => 'اثر',
			'sports'             => 'کھیل',
			'politics'           => 'سیاست',
		];
	}

	public static function get_template_language( $template ) {
		if ( $template === self::TEMPLATE_AUTO ) {
			return 'auto';
		}
		return 'ur';
	}

	public static function get_template_image_slots( $template ) {
		$multi_image = [
			self::TEMPLATE_DUAL_PHOTO => 2,
		];
		return $multi_image[ $template ] ?? 1;
	}

	public static function get_template_dark_backing_type( $template ) {
		return 'solid';
	}

	public static function is_valid_template( $template ) {
		if ( $template === self::TEMPLATE_AUTO ) {
			return true;
		}
		return array_key_exists( $template, self::get_templates() );
	}

	public static function get_template_path( $template ) {
		if ( $template === self::TEMPLATE_AUTO ) {
			return null;
		}
		if ( ! self::is_valid_template( $template ) ) {
			return null;
		}
		return AI_SOCIAL_COLLAGE_PATH . 'templates/' . $template . '.html';
	}

public static function template_exists( $template ) {
$path = self::get_template_path( $template );
return $path && file_exists( $path );
}

public static function get_template_previews() {
$previews = [];
$templates = self::get_templates();
$preview_base_url = AI_SOCIAL_COLLAGE_URL . 'assets/img/previews/';
foreach ( $templates as $template_key => $template_label ) {
if ( $template_key === self::TEMPLATE_AUTO ) {
continue;
}
$preview_file = $preview_base_url . $template_key . '.png';
$previews[ $template_key ] = $preview_file;
}
return $previews;
}

	public static function file_exists_robust( string $path ): bool {
		if ( file_exists( $path ) ) {
			return true;
		}
		if ( function_exists( 'exec' ) ) {
			$disabled = array_map( 'trim', explode( ',', ini_get( 'disable_functions' ) ) );
			if ( ! in_array( 'exec', $disabled, true ) ) {
				@exec( 'test -f ' . escapeshellarg( $path ) . ' 2>/dev/null', $_, $rc );
				return $rc === 0;
			}
		}
		return false;
	}

	public static function is_chromium_rendering_available(): bool {
        if ( ! function_exists( 'exec' ) ) {
            return false;
        }
        $disabled = explode( ',', ini_get( 'disable_functions' ) );
        if ( in_array( 'exec', array_map( 'trim', $disabled ), true ) ) {
            return false;
        }
        return self::file_exists_robust( self::NODE_PATH )
            && self::file_exists_robust( self::RENDER_SCRIPT )
            && self::file_exists_robust( self::get_chromium_path() );
    }

    public static function check_chromium_health(): array {
        $disabled = array_map( 'trim', explode( ',', ini_get( 'disable_functions' ) ) );
        $exec_ok = function_exists( 'exec' ) && ! in_array( 'exec', $disabled, true );
        $script_dir = dirname( self::RENDER_SCRIPT );
        $puppeteer_dir = $script_dir . '/node_modules/puppeteer-core';
        $chromium_path = self::get_chromium_path();

        $checks = [
            'exec' => $exec_ok,
            'node' => @file_exists( self::NODE_PATH ) || ( $exec_ok && self::probe_file_shell( self::NODE_PATH ) ),
            'render_script' => @file_exists( self::RENDER_SCRIPT ) || ( $exec_ok && self::probe_file_shell( self::RENDER_SCRIPT ) ),
            'chromium' => @file_exists( $chromium_path ) || ( $exec_ok && self::probe_file_shell( $chromium_path ) ),
            'chromium_path' => $chromium_path,
            'puppeteer' => @is_dir( $puppeteer_dir ) || ( $exec_ok && self::probe_dir_shell( $puppeteer_dir ) ),
        ];

        $checks['all_available'] = $checks['exec'] && $checks['node'] && $checks['render_script']
            && $checks['chromium'] && $checks['puppeteer'];

        return $checks;
    }

    private static function probe_file_shell( string $path ): bool {
        @exec( 'test -f ' . escapeshellarg( $path ) . ' 2>/dev/null', $_, $rc );
        return $rc === 0;
    }

    private static function probe_dir_shell( string $path ): bool {
        @exec( 'test -d ' . escapeshellarg( $path ) . ' 2>/dev/null', $_, $rc );
        return $rc === 0;
    }

// ── Platform Output Sizes ──────────────────────────────────────────────
    const SIZE_INSTAGRAM_PORTRAIT = 'instagram-portrait';
    const SIZE_INSTAGRAM_SQUARE = 'instagram-square';
    const SIZE_INSTAGRAM_STORY = 'instagram-story';
    const SIZE_TWITTER_CARD = 'twitter-card';
    const SIZE_LINKEDIN_POST = 'linkedin-post';
    const SIZE_PINTEREST_PIN = 'pinterest-pin';
	const SIZE_FACEBOOK_SHARE = 'facebook-share';
	const SIZE_WHATSAPP_STATUS = 'whatsapp-status';
	const SIZE_4TO5_RATIO = '4to5-ratio';
	const DEFAULT_SIZE = self::SIZE_4TO5_RATIO;

    public static function get_platform_sizes() {
        return [
            self::SIZE_INSTAGRAM_PORTRAIT => [ 'label' => 'Instagram Portrait', 'width' => 1080, 'height' => 1350 ],
            self::SIZE_INSTAGRAM_SQUARE => [ 'label' => 'Instagram Square', 'width' => 1080, 'height' => 1080 ],
            self::SIZE_INSTAGRAM_STORY => [ 'label' => 'Instagram Story', 'width' => 1080, 'height' => 1920 ],
            self::SIZE_TWITTER_CARD => [ 'label' => 'Twitter/X Card', 'width' => 1200, 'height' => 675 ],
            self::SIZE_LINKEDIN_POST => [ 'label' => 'LinkedIn Post', 'width' => 1200, 'height' => 627 ],
            self::SIZE_PINTEREST_PIN => [ 'label' => 'Pinterest Pin', 'width' => 1000, 'height' => 1500 ],
			self::SIZE_FACEBOOK_SHARE => [ 'label' => 'Facebook Share', 'width' => 1200, 'height' => 630 ],
			self::SIZE_WHATSAPP_STATUS => [ 'label' => 'WhatsApp Status', 'width' => 1080, 'height' => 1920 ],
			self::SIZE_4TO5_RATIO => [ 'label' => '4:5 Ratio (Base)', 'width' => 800, 'height' => 1000 ],
		];
    }

    public static function get_platform_dimensions( $size_key ) {
        $sizes = self::get_platform_sizes();
        if ( isset( $sizes[ $size_key ] ) ) {
            return [ 'width' => $sizes[ $size_key ]['width'], 'height' => $sizes[ $size_key ]['height'] ];
        }
        return [ 'width' => 800, 'height' => 1000 ];
    }

    public static function is_valid_platform_size( $size_key ) {
        return array_key_exists( $size_key, self::get_platform_sizes() );
    }

    // ── Brand Defaults ─────────────────────────────────────────────────────
    const DEFAULT_BRAND_NAME = '';
    const DEFAULT_BRAND_URL = '';
    const DEFAULT_BRAND_LOGO_ID = 0;
    const DEFAULT_BRAND_LOGO_URL = '';
	const DEFAULT_BRAND_PRIMARY_COLOR = '#00C853';
	const DEFAULT_BRAND_SECONDARY_COLOR = '#ffffff';
	const DEFAULT_BRAND_ACCENT_COLOR = '#FF1744';
	const DEFAULT_BRAND_EMPHASIS_COLOR = '#FFD700';
	const DEFAULT_BRAND_KEY_TERM_COLOR = '#00C853';
	const DEFAULT_BRAND_BREAKING_COLOR = '#FF1744';
	const DEFAULT_BRAND_TEXT_BACKING_COLOR = '#000000';
	const DEFAULT_BRAND_LOGO_POSITION = 'top-right';
	const DEFAULT_BRAND_FONT_HEADLINE = 'Montserrat';
    const DEFAULT_BRAND_FONT_BODY = 'Inter';

	const DEFAULT_FONT_SIZE_PRESET = 'large';
	const DEFAULT_HEADING_FONT_SIZE = '';
	const DEFAULT_HEADING_LINE_HEIGHT = '';
	const DEFAULT_HEADING_PADDING = 'clamp(2px,0.3cqh,4px) clamp(10px,1.5cqw,16px) clamp(2px,0.3cqh,4px) clamp(10px,1.5cqw,16px)';
	const DEFAULT_VIDEO_HEADING_FONT_SIZE = '';
	const DEFAULT_VIDEO_HEADING_HEIGHT_PROPORTION = '25.0';
	const DEFAULT_VIDEO_HEADING_PADDING = '';
	const DEFAULT_HEADING_BG_COLOR = '';
	const DEFAULT_HEADING_TEXT_COLOR = '';
	const DEFAULT_DESC_FONT_SIZE = '';
	const DEFAULT_DESC_LINE_HEIGHT = '';
	const DEFAULT_DESC_PADDING = '';
	const DEFAULT_DESC_BG_COLOR = '';
	const DEFAULT_DESC_TEXT_COLOR = '';
	const DEFAULT_BRAND_BAR_PADDING = '0 clamp(14px,2cqw,24px)';
	const DEFAULT_BRAND_BAR_BG_COLOR = 'rgba(0,0,0,0.45)';
	const DEFAULT_BRAND_BAR_TEXT_COLOR = '';
	const DEFAULT_BRAND_BAR_FONT_SIZE = '24';
	const DEFAULT_BRAND_BAR_LETTER_SPACING = '10';
	const DEFAULT_BRAND_BAR_ACCENT_LINE = '1';
	const DEFAULT_BRAND_BAR_HEIGHT_PCT = '10.0';
	const DEFAULT_BRAND_SEPARATOR_HEIGHT_PCT = '2.0';
	const DEFAULT_HEADING_HEIGHT_PROPORTION = '25.0';
	const DEFAULT_DESC_HEIGHT_PROPORTION = '10.0';
	const DEFAULT_IMAGE_HEIGHT_OVERRIDE  = '';
	const DEFAULT_LOGO_MAX_HEIGHT_BOTTOM = 'clamp(18px,2.5cqh,26px)';
	const DEFAULT_LOGO_MAX_WIDTH_BOTTOM = 'clamp(60px,10cqw,100px)';
	const DEFAULT_LOGO_MAX_HEIGHT_TOP = 'clamp(24px,3cqh,34px)';
	const DEFAULT_LOGO_MAX_WIDTH_TOP = 'clamp(70px,11cqw,110px)';

	// Size presets map user-friendly labels to CSS values.
	// Key = stored option value, Value = [ 'label' => UI label, 'heading' => CSS, 'hook' => CSS ].
	const SIZE_PRESETS = [
		''      => [ 'label' => 'Auto-Adaptive (Recommended)',  'heading' => '', 'hook' => '' ],
		'small' => [ 'label' => 'Small',   'heading' => '0.82', 'hook' => '0.85' ],
		'medium'=> [ 'label' => 'Medium',  'heading' => '1.00', 'hook' => '1.00' ],
		'large' => [ 'label' => 'Large',   'heading' => '1.18', 'hook' => '1.12' ],
		'xlarge'=> [ 'label' => 'Extra Large', 'heading' => '1.38', 'hook' => '1.22' ],
	];

	public static function get_brand_settings() {
		$settings = [
			'brand_name' => get_option( self::OPTION_BRAND_NAME, self::DEFAULT_BRAND_NAME ),
			'brand_url' => get_option( self::OPTION_BRAND_URL, self::DEFAULT_BRAND_URL ),
			'brand_logo_id' => (int) get_option( self::OPTION_BRAND_LOGO_ID, self::DEFAULT_BRAND_LOGO_ID ),
			'brand_logo_url' => (string) get_option( self::OPTION_BRAND_LOGO_URL, self::DEFAULT_BRAND_LOGO_URL ),
			'primary_color' => get_option( self::OPTION_BRAND_PRIMARY_COLOR, self::DEFAULT_BRAND_PRIMARY_COLOR ),
			'secondary_color' => get_option( self::OPTION_BRAND_SECONDARY_COLOR, self::DEFAULT_BRAND_SECONDARY_COLOR ),
			'accent_color' => get_option( self::OPTION_BRAND_ACCENT_COLOR, self::DEFAULT_BRAND_ACCENT_COLOR ),
			'emphasis_color' => get_option( self::OPTION_BRAND_EMPHASIS_COLOR, self::DEFAULT_BRAND_EMPHASIS_COLOR ),
			'key_term_color' => get_option( self::OPTION_BRAND_KEY_TERM_COLOR, self::DEFAULT_BRAND_KEY_TERM_COLOR ),
			'breaking_color' => get_option( self::OPTION_BRAND_BREAKING_COLOR, self::DEFAULT_BRAND_BREAKING_COLOR ),
			'text_backing_color' => get_option( self::OPTION_BRAND_TEXT_BACKING_COLOR, self::DEFAULT_BRAND_TEXT_BACKING_COLOR ),
			'logo_position' => get_option( self::OPTION_BRAND_LOGO_POSITION, self::DEFAULT_BRAND_LOGO_POSITION ),
			'font_headline' => get_option( self::OPTION_BRAND_FONT_HEADLINE, self::DEFAULT_BRAND_FONT_HEADLINE ),
			'font_body' => get_option( self::OPTION_BRAND_FONT_BODY, self::DEFAULT_BRAND_FONT_BODY ),
			'font_size_preset' => get_option( self::OPTION_FONT_SIZE_PRESET, self::DEFAULT_FONT_SIZE_PRESET ),
			'heading_font_size' => get_option( self::OPTION_HEADING_FONT_SIZE, self::DEFAULT_HEADING_FONT_SIZE ),
			'video_heading_font_size' => get_option( self::OPTION_VIDEO_HEADING_FONT_SIZE, self::DEFAULT_VIDEO_HEADING_FONT_SIZE ),
			'video_heading_height_proportion' => get_option( self::OPTION_VIDEO_HEADING_HEIGHT_PROPORTION, self::DEFAULT_VIDEO_HEADING_HEIGHT_PROPORTION ),
			'video_heading_padding' => get_option( self::OPTION_VIDEO_HEADING_PADDING, self::DEFAULT_VIDEO_HEADING_PADDING ),
			'heading_line_height' => get_option( self::OPTION_HEADING_LINE_HEIGHT, self::DEFAULT_HEADING_LINE_HEIGHT ),
			'heading_padding' => get_option( self::OPTION_HEADING_PADDING, self::DEFAULT_HEADING_PADDING ),
			'heading_bg_color' => get_option( self::OPTION_HEADING_BG_COLOR, self::DEFAULT_HEADING_BG_COLOR ),
			'heading_text_color' => get_option( self::OPTION_HEADING_TEXT_COLOR, self::DEFAULT_HEADING_TEXT_COLOR ),
			'desc_font_size' => get_option( self::OPTION_DESC_FONT_SIZE, self::DEFAULT_DESC_FONT_SIZE ),
			'desc_line_height' => get_option( self::OPTION_DESC_LINE_HEIGHT, self::DEFAULT_DESC_LINE_HEIGHT ),
			'desc_padding' => get_option( self::OPTION_DESC_PADDING, self::DEFAULT_DESC_PADDING ),
			'desc_bg_color' => get_option( self::OPTION_DESC_BG_COLOR, self::DEFAULT_DESC_BG_COLOR ),
			'desc_text_color' => get_option( self::OPTION_DESC_TEXT_COLOR, self::DEFAULT_DESC_TEXT_COLOR ),
			'brand_bar_padding' => get_option( self::OPTION_BRAND_BAR_PADDING, self::DEFAULT_BRAND_BAR_PADDING ),
			'brand_bar_bg_color' => get_option( self::OPTION_BRAND_BAR_BG_COLOR, self::DEFAULT_BRAND_BAR_BG_COLOR ),
			'brand_bar_text_color' => get_option( self::OPTION_BRAND_BAR_TEXT_COLOR, self::DEFAULT_BRAND_BAR_TEXT_COLOR ),
			'brand_bar_font_size' => get_option( self::OPTION_BRAND_BAR_FONT_SIZE, self::DEFAULT_BRAND_BAR_FONT_SIZE ),
			'brand_bar_letter_spacing' => get_option( self::OPTION_BRAND_BAR_LETTER_SPACING, self::DEFAULT_BRAND_BAR_LETTER_SPACING ),
			'brand_bar_accent_line' => get_option( self::OPTION_BRAND_BAR_ACCENT_LINE, self::DEFAULT_BRAND_BAR_ACCENT_LINE ),
			'brand_bar_height_pct' => get_option( self::OPTION_BRAND_BAR_HEIGHT_PCT, self::DEFAULT_BRAND_BAR_HEIGHT_PCT ),
			'brand_separator_height_pct' => get_option( self::OPTION_BRAND_SEPARATOR_HEIGHT_PCT, self::DEFAULT_BRAND_SEPARATOR_HEIGHT_PCT ),
			'heading_height_proportion' => get_option( self::OPTION_HEADING_HEIGHT_PROPORTION, self::DEFAULT_HEADING_HEIGHT_PROPORTION ),
			'desc_height_proportion' => get_option( self::OPTION_DESC_HEIGHT_PROPORTION, self::DEFAULT_DESC_HEIGHT_PROPORTION ),
			'image_height_override' => get_option( self::OPTION_IMAGE_HEIGHT_OVERRIDE, self::DEFAULT_IMAGE_HEIGHT_OVERRIDE ),
			'enable_description' => get_option( self::OPTION_ENABLE_DESCRIPTION, '0' ),
			'logo_max_height_bottom' => get_option( self::OPTION_LOGO_MAX_HEIGHT_BOTTOM, self::DEFAULT_LOGO_MAX_HEIGHT_BOTTOM ),
			'logo_max_width_bottom' => get_option( self::OPTION_LOGO_MAX_WIDTH_BOTTOM, self::DEFAULT_LOGO_MAX_WIDTH_BOTTOM ),
			'logo_max_height_top' => get_option( self::OPTION_LOGO_MAX_HEIGHT_TOP, self::DEFAULT_LOGO_MAX_HEIGHT_TOP ),
			'logo_max_width_top' => get_option( self::OPTION_LOGO_MAX_WIDTH_TOP, self::DEFAULT_LOGO_MAX_WIDTH_TOP ),
			'logo_url' => '',
		];

if ( ! empty( $settings['brand_logo_url'] ) ) {
	$settings['logo_url'] = esc_url_raw( $settings['brand_logo_url'] );
} elseif ( $settings['brand_logo_id'] > 0 ) {
	$url = wp_get_attachment_url( $settings['brand_logo_id'] );
	$settings['logo_url'] = $url ? $url : '';
}

		return $settings;
	}

	public static function get_available_fonts() {
		return [
			'Montserrat' => [ 'label' => 'Montserrat', 'weight' => '800', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Inter' => [ 'label' => 'Inter', 'weight' => '700', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Playfair Display' => [ 'label' => 'Playfair Display', 'weight' => '700', 'fallback' => 'serif', 'self_hosted' => false ],
			'Oswald' => [ 'label' => 'Oswald', 'weight' => '700', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Roboto' => [ 'label' => 'Roboto', 'weight' => '700', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Noto Nastaliq Urdu' => [ 'label' => 'Noto Nastaliq Urdu', 'weight' => '400', 'fallback' => 'serif', 'self_hosted' => true ],
			'Poppins' => [ 'label' => 'Poppins', 'weight' => '700', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Bebas Neue' => [ 'label' => 'Bebas Neue', 'weight' => '400', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Lora' => [ 'label' => 'Lora', 'weight' => '700', 'fallback' => 'serif', 'self_hosted' => false ],
			'Raleway' => [ 'label' => 'Raleway', 'weight' => '800', 'fallback' => 'sans-serif', 'self_hosted' => false ],
			'Jameel Noori Nastaliq' => [ 'label' => 'Jameel Noori Nastaliq', 'weight' => '400', 'fallback' => '"Noto Nastaliq Urdu", "Noto Sans Arabic", "Urdu Typesetting", "Geeza Pro", serif', 'self_hosted' => true ],
			'Nafees Web Naskh' => [ 'label' => 'Nafees Web Naskh', 'weight' => '400', 'fallback' => '"Noto Nastaliq Urdu", "Noto Sans Arabic", "Urdu Typesetting", "Geeza Pro", serif', 'self_hosted' => true ],
			'Noto Nastaliq Urdu' => [ 'label' => 'Noto Nastaliq Urdu', 'weight' => '400', 'fallback' => '"Noto Sans Arabic", "Urdu Typesetting", "Geeza Pro", serif', 'self_hosted' => true ],
			'Noto Sans Arabic' => [ 'label' => 'Noto Sans Arabic', 'weight' => '400', 'fallback' => '"Noto Nastaliq Urdu", "Urdu Typesetting", "Geeza Pro", sans-serif', 'self_hosted' => true ],
		];
	}

	public static function get_self_hosted_fonts() {
		$fonts = self::get_available_fonts();
		$self_hosted = [];
		foreach ( $fonts as $name => $spec ) {
			if ( ! empty( $spec['self_hosted'] ) ) {
				$self_hosted[ $name ] = $spec;
			}
		}
		return $self_hosted;
	}

	public static function detect_language( $content ) {
		if ( empty( $content ) ) {
			return 'en';
		}
		$stripped = wp_strip_all_tags( $content );
		$stripped = html_entity_decode( $stripped, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$total = mb_strlen( $stripped, 'UTF-8' );
		if ( $total === 0 ) {
			return 'en';
		}
		$urdu_chars = preg_match_all( '/[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', $stripped );
		$ratio = $urdu_chars / $total;
		return ( $ratio > 0.2 ) ? 'ur' : 'en';
	}

	public static function resolve_collage_language( $ai_headline, $ai_hook, $post_content, $auto_meta = [], $campaign = [] ) {
		if ( ! empty( $campaign['language'] ) && in_array( $campaign['language'], [ 'en', 'ur' ], true ) ) {
			return $campaign['language'];
		}

		if ( ! empty( $campaign['output_language'] ) && in_array( $campaign['output_language'], [ 'en', 'ur' ], true ) ) {
			return $campaign['output_language'];
		}

		if ( ! empty( $auto_meta['ai_language'] ) && in_array( $auto_meta['ai_language'], [ 'en', 'ur' ], true ) ) {
			return $auto_meta['ai_language'];
		}

		$headline_lang = self::detect_language( $ai_headline . ' ' . $ai_hook );
		if ( $headline_lang !== 'en' ) {
			return $headline_lang;
		}

		$content_lang = self::detect_language( $post_content );
		if ( $content_lang === 'ur' ) {
			return 'ur';
		}

		return 'en';
	}

    // ── Frequency Options ──────────────────────────────────────────────────
    const FREQUENCY_5_MINS = '5 Mins';
    const FREQUENCY_15_MINS = '15 Mins';
    const FREQUENCY_30_MINS = '30 Mins';
    const FREQUENCY_1_HOUR = '1 Hour';
    const FREQUENCY_2_HOURS = '2 Hours';
    const FREQUENCY_4_HOURS = '4 Hours';
    const FREQUENCY_6_HOURS = '6 Hours';
    const FREQUENCY_8_HOURS = '8 Hours';
    const FREQUENCY_10_HOURS = '10 Hours';
    const FREQUENCY_12_HOURS = '12 Hours';
    const FREQUENCY_1_DAY = '1 Day';
    const FREQUENCY_TWICE_DAILY = 'Twice Daily';
    const FREQUENCY_2_DAYS = 'Every 2 Days';

    /** @deprecated Use FREQUENCY_1_HOUR */
    const FREQUENCY_HOURLY = self::FREQUENCY_1_HOUR;

    public static function get_frequencies() {
        return [
            self::FREQUENCY_5_MINS => 300,
            self::FREQUENCY_15_MINS => 900,
            self::FREQUENCY_30_MINS => 1800,
            self::FREQUENCY_1_HOUR => 3600,
            self::FREQUENCY_2_HOURS => 7200,
            self::FREQUENCY_4_HOURS => 14400,
            self::FREQUENCY_6_HOURS => 21600,
            self::FREQUENCY_8_HOURS => 28800,
            self::FREQUENCY_10_HOURS => 36000,
            self::FREQUENCY_12_HOURS => 43200,
            self::FREQUENCY_1_DAY => 86400,
            self::FREQUENCY_TWICE_DAILY => 43200,
            self::FREQUENCY_2_DAYS => 172800,
        ];
    }

    public static function get_frequency_interval( $frequency ) {
        $frequencies = self::get_frequencies();
        return $frequencies[ $frequency ] ?? 3600;
    }

    public static function is_valid_frequency( $frequency ) {
        return array_key_exists( $frequency, self::get_frequencies() );
    }

    // ── Target Verticals ───────────────────────────────────────────────────
	const VERTICAL_SHOWBIZ_PK = 'Showbiz - PK';
	const VERTICAL_TECH_GLOBAL = 'Tech - Global';
	const VERTICAL_SPORTS = 'Sports';
	const VERTICAL_POLITICS = 'Politics';
	const VERTICAL_BUSINESS = 'Business';
	const VERTICAL_CELEBRITY_URDU = 'Celebrity - Urdu';
	const VERTICAL_CONTROVERSY = 'Controversy';
	const VERTICAL_EMOTIONAL_SOCIAL = 'Emotional / Social';
	const VERTICAL_HEALTH_INSPIRATIONAL = 'Health / Inspirational';
	const VERTICAL_BREAKING_URDU = 'Breaking - Urdu';
	const VERTICAL_ENTERTAINMENT = 'Entertainment';
	const VERTICAL_NEWS = 'News';
	const VERTICAL_FILM_ACTION = 'Film - Action';
	const VERTICAL_MODERN = 'Modern / Lifestyle';
	const VERTICAL_IMPACT = 'Impact';

    public static function get_vertical_category_map() {
        return [
            self::VERTICAL_SHOWBIZ_PK => 'celebrity-urdu',
            self::VERTICAL_TECH_GLOBAL => 'tech',
            self::VERTICAL_SPORTS => 'sports',
            self::VERTICAL_POLITICS => 'politics',
            self::VERTICAL_BUSINESS => 'news',
            self::VERTICAL_CELEBRITY_URDU => 'celebrity-urdu',
            self::VERTICAL_CONTROVERSY => 'controversy-urdu',
            self::VERTICAL_EMOTIONAL_SOCIAL => 'emotional-urdu',
            self::VERTICAL_HEALTH_INSPIRATIONAL => 'inspirational-urdu',
            self::VERTICAL_BREAKING_URDU => 'breaking-urdu',
            self::VERTICAL_ENTERTAINMENT => 'entertainment',
            self::VERTICAL_NEWS => 'news',
            self::VERTICAL_FILM_ACTION => 'film-action',
            self::VERTICAL_MODERN => 'modern',
            self::VERTICAL_IMPACT => 'impact',
        ];
    }

    public static function get_verticals() {
		return [
			self::VERTICAL_SHOWBIZ_PK => 'Showbiz - PK',
			self::VERTICAL_TECH_GLOBAL => 'Tech - Global',
			self::VERTICAL_SPORTS => 'Sports',
			self::VERTICAL_POLITICS => 'Politics',
			self::VERTICAL_BUSINESS => 'Business',
			self::VERTICAL_CELEBRITY_URDU => 'Celebrity - Urdu',
			self::VERTICAL_CONTROVERSY => 'Controversy',
			self::VERTICAL_EMOTIONAL_SOCIAL => 'Emotional / Social',
			self::VERTICAL_HEALTH_INSPIRATIONAL => 'Health / Inspirational',
			self::VERTICAL_BREAKING_URDU => 'Breaking - Urdu',
			self::VERTICAL_ENTERTAINMENT => 'Entertainment',
			self::VERTICAL_NEWS => 'News',
			self::VERTICAL_FILM_ACTION => 'Film - Action',
			self::VERTICAL_MODERN => 'Modern / Lifestyle',
			self::VERTICAL_IMPACT => 'Impact',
		];
	}

    // ── Publish Status Options ─────────────────────────────────────────────
    const PUBLISH_STATUS_DRAFT = 'draft';
    const PUBLISH_STATUS_PUBLISH = 'publish';
    const DEFAULT_PUBLISH_STATUS = self::PUBLISH_STATUS_DRAFT;

    public static function get_publish_statuses() {
        return [
            self::PUBLISH_STATUS_DRAFT => 'Draft',
            self::PUBLISH_STATUS_PUBLISH => 'Publish',
        ];
    }

    public static function is_valid_publish_status( $status ) {
        return array_key_exists( $status, self::get_publish_statuses() );
    }

    // ── Quota Management ───────────────────────────────────────────────────
    const QUOTA_MAX_REQUESTS = 10;
    const QUOTA_TIME_WINDOW = 60;
    const QUOTA_TRANSIENT_PREFIX = 'ai_collage_quota_';

	// ── Registered API Providers ───────────────────────────────────────────
	const PROVIDER_GEMINI = 'gemini';
	const PROVIDER_GROQ = 'groq';
	const PROVIDER_CUSTOM_PREFIX = 'custom_';

	// ── Chromium Rendering Paths ───────────────────────────────────────────
	const NODE_PATH     = '/usr/bin/node';
	const RENDER_SCRIPT = '/usr/local/lib/puppeteer/render.js';
	const CHROMIUM_RENDER_TIMEOUT = 45;
	const RENDER_WATCHDOG_TIMEOUT = 90;

	/**
	 * Auto-detect Chromium binary across Linux distributions and architectures.
	 * Searches common paths and uses `which` as fallback.
	 */
	public static function get_chromium_path(): string {
		static $cached = null;
		if ( $cached !== null ) {
			return $cached;
		}

		$candidates = [
			'/usr/bin/chromium-browser',
			'/usr/bin/chromium',
			'/usr/sbin/chromium-browser',
			'/usr/sbin/chromium',
			'/snap/bin/chromium',
			'/snap/chromium/current/usr/lib/chromium-browser/chrome',
			'/usr/lib/chromium/chromium',
			'/usr/lib/chromium-browser/chromium-browser',
			'/usr/lib64/chromium-browser/chromium-browser',
			'/usr/lib/chromium/chrome',
			'/usr/bin/google-chrome',
			'/usr/bin/google-chrome-stable',
		];

		foreach ( $candidates as $path ) {
			if ( file_exists( $path ) && is_executable( $path ) ) {
				$cached = $path;
				return $cached;
			}
		}

		if ( function_exists( 'exec' ) ) {
			@exec( 'which chromium-browser 2>/dev/null', $out1, $rc1 );
			if ( $rc1 === 0 && ! empty( $out1[0] ) ) {
				$cached = $out1[0];
				return $cached;
			}
			@exec( 'which chromium 2>/dev/null', $out2, $rc2 );
			if ( $rc2 === 0 && ! empty( $out2[0] ) ) {
				$cached = $out2[0];
				return $cached;
			}
		}

		$cached = '/usr/bin/chromium-browser';
		return $cached;
	}

	// ── Custom Provider Web Search Types ──────────────────────────────────
	const WEB_SEARCH_NONE = 'none';
	const WEB_SEARCH_ZHIPUAI = 'zhipuai';
	const WEB_SEARCH_KIMI = 'kimi';
	const WEB_SEARCH_MINIMAX = 'minimax';
	const WEB_SEARCH_GOOGLE = 'google_search';
	const WEB_SEARCH_PERPLEXITY = 'perplexity';

	public static function get_web_search_types() {
		return [
			self::WEB_SEARCH_NONE => 'None',
			self::WEB_SEARCH_ZHIPUAI => 'ZhipuAI (GLM)',
			self::WEB_SEARCH_KIMI => 'Kimi/Moonshot',
			self::WEB_SEARCH_MINIMAX => 'MiniMax',
			self::WEB_SEARCH_GOOGLE => 'Google Search (Gemini)',
			self::WEB_SEARCH_PERPLEXITY => 'Perplexity',
		];
	}

	public static function is_valid_web_search_type( $type ) {
		return array_key_exists( $type, self::get_web_search_types() );
	}
	const PROVIDER_IMAGE_POLLINATIONS = 'pollinations';
	const PROVIDER_IMAGE_STABILITY = 'stability';
	const PROVIDER_IMAGE_CLOUDFLARE_WORKER = 'cloudflare-worker';
	const PROVIDER_IMAGE_PLACEHOLDER = 'placeholder';
	const PROVIDER_IMAGE_NONE = 'none';

	public static function get_registered_providers() {
		$builtin = [
			self::PROVIDER_GEMINI => 'Google Gemini',
			self::PROVIDER_GROQ => 'Groq',
		];
		$custom = self::get_custom_providers();
		foreach ( $custom as $profile ) {
			$id = $profile['id'] ?? '';
			if ( $id !== '' ) {
				$builtin[ $id ] = $profile['name'] ?? $id;
			}
		}
		return $builtin;
	}

	public static function is_valid_provider( $provider ) {
		return array_key_exists( $provider, self::get_registered_providers() );
	}

	public static function is_custom_provider( $provider ) {
		return strpos( $provider, self::PROVIDER_CUSTOM_PREFIX ) === 0;
	}

	public static function get_custom_providers() {
		$saved = get_option( self::OPTION_CUSTOM_PROVIDERS, '[]' );
		$providers = json_decode( $saved, true );
		return is_array( $providers ) ? $providers : [];
	}

	public static function save_custom_providers( array $providers ) {
		$clean = [];
		foreach ( $providers as $profile ) {
			$validated = self::validate_custom_profile( $profile );
			if ( $validated !== null ) {
				$clean[] = $validated;
			}
		}
		update_option( self::OPTION_CUSTOM_PROVIDERS, wp_json_encode( $clean ) );
		return $clean;
	}

	public static function validate_custom_profile( array $profile ) {
		$id = isset( $profile['id'] ) ? sanitize_key( $profile['id'] ) : '';
		if ( $id === '' ) {
			return null;
		}
		if ( in_array( $id, [ self::PROVIDER_GEMINI, self::PROVIDER_GROQ ], true ) ) {
			return null;
		}
		$name = isset( $profile['name'] ) ? sanitize_text_field( $profile['name'] ) : $id;
		$api_url = isset( $profile['api_url'] ) ? esc_url_raw( $profile['api_url'] ) : '';
		if ( $api_url === '' || strpos( $api_url, 'https://' ) !== 0 ) {
			return null;
		}
		$api_key = isset( $profile['api_key'] ) ? sanitize_text_field( $profile['api_key'], 'raw' ) : '';
		$enable_web_search = ! empty( $profile['enable_web_search'] );
		$web_search_type = isset( $profile['web_search_config']['type'] ) && self::is_valid_web_search_type( $profile['web_search_config']['type'] )
			? $profile['web_search_config']['type']
			: self::WEB_SEARCH_NONE;
		$models = [];
		if ( isset( $profile['models'] ) && is_array( $profile['models'] ) ) {
			foreach ( $profile['models'] as $m ) {
				$display = isset( $m['display_name'] ) ? sanitize_text_field( $m['display_name'] ) : '';
				$model_id = isset( $m['model_id'] ) ? sanitize_text_field( $m['model_id'] ) : '';
				if ( $model_id !== '' ) {
					$models[] = [
						'display_name' => $display !== '' ? $display : $model_id,
						'model_id' => $model_id,
					];
				}
			}
		}
		if ( empty( $models ) ) {
			return null;
		}
		$fallback_enabled = ! empty( $profile['fallback_enabled'] );
		return [
			'id' => $id,
			'name' => $name,
			'api_url' => $api_url,
			'api_key' => $api_key,
			'enable_web_search' => $enable_web_search,
			'web_search_config' => [ 'type' => $web_search_type ],
			'models' => $models,
			'fallback_enabled' => $fallback_enabled,
		];
	}

	public static function get_custom_profile( $provider_id ) {
		if ( ! self::is_custom_provider( $provider_id ) ) {
			return null;
		}
		$providers = self::get_custom_providers();
		foreach ( $providers as $p ) {
			if ( ( $p['id'] ?? '' ) === $provider_id ) {
				return $p;
			}
		}
		return null;
	}

	/**
	 * Check if a provider has a valid API key configured.
	 * Returns false for: missing options, empty custom profiles, custom profiles without api_key.
	 */
	public static function has_valid_api_key( string $provider ): bool {
		if ( self::is_custom_provider( $provider ) ) {
			$profile = self::get_custom_profile( $provider );
			if ( ! is_array( $profile ) ) {
				return false;
			}
			$api_key = $profile['api_key'] ?? '';
			return ! empty( $api_key );
		}

		switch ( $provider ) {
			case self::PROVIDER_GEMINI:
				$key = get_option( self::OPTION_GEMINI_KEY, '' );
				return ! empty( $key );
			case self::PROVIDER_GROQ:
				$key = get_option( self::OPTION_GROQ_KEY, '' );
				return ! empty( $key );
			default:
				return false;
		}
	}

	public static function get_image_providers() {
		return [
			self::PROVIDER_IMAGE_NONE => 'None (Skip Image Generation)',
			self::PROVIDER_IMAGE_POLLINATIONS => 'Pollinations AI',
			self::PROVIDER_IMAGE_STABILITY => 'Stability AI',
			self::PROVIDER_IMAGE_CLOUDFLARE_WORKER => 'Cloudflare Worker AI',
			self::PROVIDER_IMAGE_PLACEHOLDER => 'Branded Placeholder',
		];
	}

	public static function is_valid_image_provider( $provider ) {
		return array_key_exists( $provider, self::get_image_providers() );
	}

	const OPTION_IMAGE_PROVIDER = 'ai_collage_image_provider';
	const OPTION_IMAGE_PROVIDER_KEY = 'ai_collage_image_provider_key';
	const OPTION_IMAGE_PROVIDER_WORKER_URL = 'ai_collage_image_worker_url';
	const DEFAULT_IMAGE_PROVIDER = self::PROVIDER_IMAGE_PLACEHOLDER;

	const OPTION_RSS_FEEDS = 'ai_collage_rss_feeds';
	const OPTION_RSS_ENABLED = 'ai_collage_rss_enabled';
	const OPTION_RSS_FREQUENCY = 'ai_collage_rss_frequency';
	const OPTION_RSS_MAX_PER_RUN = 'ai_collage_rss_max_per_run';
	const OPTION_RSS_BLOCK_KEYWORDS = 'ai_collage_rss_block_keywords';
	const OPTION_RSS_MIN_CONTENT_LENGTH = 'ai_collage_rss_min_content_length';
	const OPTION_RSS_PREFILTER_THRESHOLD = 'ai_collage_rss_prefilter_threshold';
	const RSS_FREQUENCY_30_MINS = 1800;
	
	// Social Media Options
	const OPTION_SOCIAL_ATTRIBUTION_TEMPLATE = 'ai_collage_social_attribution_template';
	const OPTION_SOCIAL_CREDIT_TEMPLATE = 'ai_collage_social_credit_template';
	const OPTION_PROCESSING_MODE = 'ai_collage_processing_mode';
	const OPTION_BRANDING_REMOVAL_ENABLED = 'ai_collage_branding_removal_enabled';
	const OPTION_OCR_ENABLED = 'ai_collage_ocr_enabled';
	const OPTION_YTDLP_PATH = 'ai_collage_ytdlp_path';
	const OPTION_GALLERY_DL_PATH = 'ai_collage_gallery_dl_path';
	
	// Social Media Source Types
	const SOURCE_TYPE_RSS = 'rss';
	const SOURCE_TYPE_SOCIAL_MEDIA = 'social_media';
	const SOURCE_TYPE_INSTAGRAM = 'instagram';
	const SOURCE_TYPE_FACEBOOK = 'facebook';
	const SOURCE_TYPE_TWITTER = 'twitter';
	const SOURCE_TYPE_TIKTOK = 'tiktok';
	const SOURCE_TYPE_YOUTUBE = 'youtube';
	const SOURCE_TYPE_LINKEDIN = 'linkedin';
	
	// Processing Modes
	const PROCESSING_MODE_REPOST = 'repost';
	const PROCESSING_MODE_REWRITE = 'rewrite';
	const PROCESSING_MODE_AI_COLLAGE = 'ai_collage';
	
	// Attribution Templates
	const ATTRIBUTION_TEMPLATE_DEFAULT = 'default';
	const ATTRIBUTION_TEMPLATE_DETAILED = 'detailed';
	const ATTRIBUTION_TEMPLATE_SIMPLE = 'simple';
	
	const RSS_FREQUENCY_HOURLY = 3600;
	const RSS_FREQUENCY_2_HOURS = 7200;
	const RSS_FREQUENCY_6_HOURS = 21600;
	const RSS_DEFAULT_FREQUENCY = self::RSS_FREQUENCY_HOURLY;
	const RSS_DEFAULT_MAX_PER_RUN = 5;
	const RSS_DEFAULT_MIN_CONTENT_LENGTH = 100;
	const RSS_DEFAULT_PREFILTER_THRESHOLD = 30;

	public static function get_default_block_keywords() {
		return [
			'weather forecast',
			'horoscope',
			'lottery results',
			'obituary',
			'public notice',
			'press release',
			'corporate announcement',
			'earnings report',
			'quarterly results',
			'stock market update',
			'routine maintenance',
			'scheduled downtime',
			'policy update',
			'administrative notice',
		];
	}

	public static function get_default_source_reputation() {
		return [
			'bbc.co.uk' => 10,
			'reuters.com' => 10,
			'apnews.com' => 10,
			'geo.tv' => 8,
			'dawn.com' => 8,
			'nytimes.com' => 9,
			'theguardian.com' => 9,
			'aljazeera.com' => 8,
		];
	}

	public static function get_rss_frequencies() {
		return [
			self::RSS_FREQUENCY_30_MINS => 'Every 30 Minutes',
			self::RSS_FREQUENCY_HOURLY => 'Every Hour',
			self::RSS_FREQUENCY_2_HOURS => 'Every 2 Hours',
			self::RSS_FREQUENCY_6_HOURS => 'Every 6 Hours',
		];
	}

	public static function is_valid_rss_frequency( $seconds ) {
		return array_key_exists( $seconds, self::get_rss_frequencies() );
	}

	public static function get_rss_feeds() {
		$feeds = get_option( self::OPTION_RSS_FEEDS, [] );
		if ( ! is_array( $feeds ) || empty( $feeds ) ) {
			$defaults = self::get_default_rss_feeds();
			if ( ! empty( $defaults ) ) {
				update_option( self::OPTION_RSS_FEEDS, $defaults );
				return $defaults;
			}
			return [];
		}
		return $feeds;
	}

	public static function get_default_rss_feeds() {
		return [
			[
				'id' => 'feed_bbc_urdu',
				'name' => 'BBC Urdu',
				'url' => 'https://feeds.bbci.co.uk/urdu/rss.xml',
				'language' => 'ur',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
			[
				'id' => 'feed_bbc_world',
				'name' => 'BBC World News',
				'url' => 'https://feeds.bbci.co.uk/news/world/rss.xml',
				'language' => 'en',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
			[
				'id' => 'feed_bbc_tech',
				'name' => 'BBC Technology',
				'url' => 'https://feeds.bbci.co.uk/news/technology/rss.xml',
				'language' => 'en',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
			[
				'id' => 'feed_nyt_world',
				'name' => 'NYT World News',
				'url' => 'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
				'language' => 'en',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
			[
				'id' => 'feed_geo_pakistan',
				'name' => 'Geo News Pakistan',
				'url' => 'https://www.geo.tv/rss/1/1',
				'language' => 'en',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
			[
				'id' => 'feed_dawn',
				'name' => 'Dawn News',
				'url' => 'https://www.dawn.com/feed',
				'language' => 'en',
				'category' => '',
				'campaign_id' => '',
				'active' => true,
				'last_poll' => '',
				'last_poll_count' => 0,
			],
		];
	}

	public static function get_rss_feed( $feed_id ) {
		$feeds = self::get_rss_feeds();
		foreach ( $feeds as $feed ) {
			if ( ( $feed['id'] ?? '' ) === $feed_id ) {
				return $feed;
			}
		}
		return null;
	}

    // ── API Call Statuses ──────────────────────────────────────────────────
    const API_CALL_PENDING = 'pending';
    const API_CALL_SUCCESS = 'success';
    const API_CALL_FAILED = 'failed';
    const API_CALL_BLOCKED = 'blocked';

    public static function get_api_call_statuses() {
        return [ self::API_CALL_PENDING, self::API_CALL_SUCCESS, self::API_CALL_FAILED, self::API_CALL_BLOCKED ];
    }

    // ── Cleanup ────────────────────────────────────────────────────────────
	const DEFAULT_RETENTION_DAYS = 30;
	const DEFAULT_LOG_RETENTION_DAYS = 5;
	const DEFAULT_IMAGE_RETENTION_DAYS = 30;
	const DEFAULT_GENERATED_POST_RETENTION_DAYS = 30;
	const DEFAULT_SOURCE_POST_RETENTION_DAYS = 7;
	const DEFAULT_BUFFER_DRAFT_RETENTION_DAYS = 2;
	const DEFAULT_MAX_QUEUE_DEPTH = 50;
	const DEFAULT_DELETE_DATA_ON_UNINSTALL = false;

    // ── Image Settings ─────────────────────────────────────────────────────
    const IMAGE_WIDTH = 1080;
    const IMAGE_HEIGHT = 1350;
	const IMAGE_QUALITY = 92;
	const IM_CONVERT_PATH = '/usr/bin/convert';
	const RENDER_MODE_PANGO = 'pango';
	const DEFAULT_RENDER_MODE = self::RENDER_MODE_PANGO;

    // ── Cron Settings ──────────────────────────────────────────────────────
    const CRON_POLL_INTERVAL = 300;

    // ── Smart AI ───────────────────────────────────────────────────────────
    const SMART_AI_COLOR_COUNT = 5;
    const SMART_AI_FOCAL_PADDING = 0.1;
    const SMART_AI_MIN_BRIGHTNESS = 0.3;

    // ── Social Bridge ──────────────────────────────────────────────────────
    const SOCIAL_HOOK_PREFIX = 'ai_social_collage_publish_to_';
    const SOCIAL_HOOK_ALL = 'ai_social_collage_publish';
	const SOCIAL_PLATFORM_INSTAGRAM = 'instagram';
	const SOCIAL_PLATFORM_FACEBOOK = 'facebook';
	const SOCIAL_PLATFORM_TWITTER = 'twitter';
	const SOCIAL_PLATFORM_LINKEDIN = 'linkedin';
	const SOCIAL_PLATFORM_PINTEREST = 'pinterest';
	const SOCIAL_PLATFORM_WHATSAPP = 'whatsapp';

	public static function get_social_platforms() {
		return [
			self::SOCIAL_PLATFORM_INSTAGRAM => 'Instagram',
			self::SOCIAL_PLATFORM_FACEBOOK => 'Facebook',
			self::SOCIAL_PLATFORM_TWITTER => 'Twitter/X',
			self::SOCIAL_PLATFORM_LINKEDIN => 'LinkedIn',
			self::SOCIAL_PLATFORM_PINTEREST => 'Pinterest',
			self::SOCIAL_PLATFORM_WHATSAPP => 'WhatsApp',
		];
	}

	const DEFAULT_SOCIAL_ZONES = [
		'facebook_generic' => [
			'logo_zone' => [
				'x' => 0.0,
				'y' => 0.0,
				'w' => 1.0,
				'h' => 0.10,
			],
			'text_zone' => [
				'x' => 0.0,
				'y' => 0.60,
				'w' => 1.0,
				'h' => 0.40,
			],
			'image_zone' => [
				'x' => 0.0,
				'y' => 0.0,
				'w' => 1.0,
				'h' => 0.60,
			],
		],
	];

    // ── Logging ────────────────────────────────────────────────────────────
    const LOG_ACTION_GEMINI_REQUEST = 'gemini_api_request';
    const LOG_ACTION_GEMINI_RESPONSE = 'gemini_api_response';
    const LOG_ACTION_GROQ_REQUEST = 'groq_api_request';
    const LOG_ACTION_GROQ_RESPONSE = 'groq_api_response';
	const LOG_ACTION_RENDER_SUCCESS = 'render_success';
	const LOG_ACTION_RENDER_ERROR = 'render_error';
    const LOG_ACTION_AI_REWRITTEN = 'ai_rewritten';
    const LOG_ACTION_RENDER_AND_PUBLISH = 'render_and_publish_completed';
    const LOG_ACTION_MANUAL_RUN = 'manual_run_queued';
    const LOG_ACTION_CAMPAIGN_JOB_QUEUED = 'campaign_job_queued';
    const LOG_ACTION_DAILY_CLEANUP = 'daily_cleanup_executed';
    const LOG_ACTION_SMART_AI_COLORS = 'smart_ai_colors_extracted';
	const LOG_ACTION_SMART_AI_FOCAL = 'smart_ai_focal_detected';
	const LOG_ACTION_SOCIAL_POST = 'social_post_dispatched';
	const LOG_ACTION_AI_IMAGE_GENERATED = 'ai_image_generated';
	const LOG_ACTION_RSS_ITEM_INGESTED = 'rss_item_ingested';
	const LOG_ACTION_RSS_FEED_POLLED = 'rss_feed_polled';
	const LOG_ACTION_RSS_ITEM_NO_TITLE = 'rss_item_no_title';
	const LOG_ACTION_RSS_ITEM_NO_CONTENT = 'rss_item_no_content';
	const LOG_ACTION_AUTO_TEMPLATE_SELECTED = 'auto_template_selected';
	const LOG_ACTION_CAMPAIGN_STOPPED = 'campaign_stopped';
	const LOG_ACTION_PIPELINE_PAUSED = 'pipeline_paused';
	const LOG_ACTION_PIPELINE_RESUMED = 'pipeline_resumed';
	const LOG_ACTION_STUCK_JOB_FAILED = 'stuck_job_failed';
	const LOG_ACTION_CUSTOM_PROVIDER_RESPONSE = 'custom_provider_api_response';
	const LOG_ACTION_CHROMIUM_RENDER_START = 'chromium_render_start';
	const LOG_ACTION_CHROMIUM_RENDER_SUCCESS = 'chromium_render_success';
	const LOG_ACTION_CHROMIUM_RENDER_FAILED = 'chromium_render_failed';
	const LOG_ACTION_VIABILITY_SCORED = 'viability_scored';
	const LOG_ACTION_VIABILITY_DISCARDED = 'viability_discarded';
	const LOG_ACTION_IMAGE_PREPROCESSED = 'image_preprocessed';
	const LOG_ACTION_PREFILTER_BLOCKED = 'prefilter_blocked';
	const LOG_ACTION_SOCIAL_MEDIA_DOWNLOADED = 'social_media_downloaded';
	const LOG_ACTION_BRANDING_REMOVED = 'branding_removed';
	const LOG_ACTION_OCR_EXTRACTED = 'ocr_extracted';
    const LOG_ACTION_AI_BRANDING_DETECTED = 'ai_branding_detected';
	const LOG_ACTION_JETPACK_SYNC = 'jetpack_sync_completed';
	const LOG_ACTION_BUFFER_SHARE = 'buffer_share_completed';
	const LOG_ACTION_IMAGE_VERIFICATION = 'image_verification_completed';
	const LOG_ACTION_OPENROUTER_SYNC = 'openrouter_models_synced';
	const LOG_ACTION_ZEN_SYNC = 'zen_models_synced';

	// ── Video Pipeline Constants ────────────────────────────────────────────
	const CONTENT_TYPE_IMAGE = 'image';
	const CONTENT_TYPE_VIDEO = 'video';
	const CONTENT_TYPE_AUTO  = 'auto';
	const META_CONTENT_TYPE  = '_ai_collage_content_type';
	const OPTION_VIDEO_ENABLED = 'ai_collage_video_enabled';
	const OPTION_VIDEO_MAX_DURATION = 'ai_collage_video_max_duration';
	const OPTION_VIDEO_REEL_WIDTH = 'ai_collage_video_reel_width';
	const OPTION_VIDEO_REEL_HEIGHT = 'ai_collage_video_reel_height';
	const OPTION_VIDEO_HEADING_FONT_SIZE = 'ai_collage_video_heading_font_size';
	const OPTION_VIDEO_HEADING_HEIGHT_PROPORTION = 'ai_collage_video_heading_height_proportion';
	const OPTION_VIDEO_HEADING_PADDING = 'ai_collage_video_heading_padding';
	const DEFAULT_VIDEO_MAX_DURATION = 60;
	const DEFAULT_VIDEO_REEL_WIDTH = 1080;
	const DEFAULT_VIDEO_REEL_HEIGHT = 1920;
	const VIDEO_EXTENSIONS = [ 'mp4', 'mov', 'webm', 'avi', 'mkv', 'flv', 'wmv' ];
	const LOG_ACTION_VIDEO_FRAME_ANALYSIS = 'video_frame_analysis';
	const LOG_ACTION_VIDEO_CROPPED = 'video_cropped';
	const LOG_ACTION_VIDEO_REEL_GENERATED = 'video_reel_generated';
	const LOG_ACTION_VIDEO_UNSUPPORTED = 'video_unsupported_format';

	// ── Cloudflare R2 Settings (for video upload to Buffer) ──────────────
	const OPTION_R2_ENDPOINT = 'ai_collage_r2_endpoint';
	const OPTION_R2_ACCESS_KEY = 'ai_collage_r2_access_key';
	const OPTION_R2_SECRET_KEY = 'ai_collage_r2_secret_key';
	const OPTION_R2_BUCKET = 'ai_collage_r2_bucket';
	const OPTION_R2_PUBLIC_DOMAIN = 'ai_collage_r2_public_domain';
	const OPTION_VIDEO_R2_BUFFER_AUTO = 'ai_collage_video_r2_buffer_auto';
	const LOG_ACTION_R2_UPLOAD = 'r2_upload_completed';

	// ── Video Zone Modes ──────────────────────────────────────────────────
	const VIDEO_ZONE_MODE_AUTO = 'auto';
	const VIDEO_ZONE_MODE_MANUAL = 'manual';

    // ── Jetpack Social Options ─────────────────────────────────────────────
    const OPTION_JETPACK_ENABLED = 'ai_collage_jetpack_enabled';
    const OPTION_JETPACK_DISABLE_LINK = 'ai_collage_jetpack_disable_link';
    const OPTION_JETPACK_TEMPLATE = 'ai_collage_jetpack_template';
    const OPTION_JETPACK_NETWORKS = 'ai_collage_jetpack_networks';
    const OPTION_JETPACK_NETWORK_TEMPLATES = 'ai_collage_jetpack_network_templates';
    const OPTION_JETPACK_OPTIONS_OVERRIDE = 'ai_collage_jetpack_options_override';

    // ── Buffer API Options ─────────────────────────────────────────────────
    const OPTION_BUFFER_ENABLED = 'ai_collage_buffer_enabled';
    const OPTION_BUFFER_DISABLE_LINK = 'ai_collage_buffer_disable_link';
    const OPTION_BUFFER_ACCESS_TOKEN = 'ai_collage_buffer_access_token';
    const OPTION_BUFFER_DAILY_LIMIT = 'ai_collage_buffer_daily_limit';
    const OPTION_BUFFER_CHANNELS = 'ai_collage_buffer_channels';
    const OPTION_BUFFER_CHANNEL_TYPES = 'ai_collage_buffer_channel_types';
    const OPTION_BUFFER_CHANNEL_TEMPLATES = 'ai_collage_buffer_channel_templates';
    const OPTION_BUFFER_GLOBAL_TEMPLATE = 'ai_collage_buffer_global_template';
    const OPTION_BUFFER_LINK_POSTS = 'ai_collage_buffer_link_posts';
    const OPTION_BUFFER_PINTEREST_BOARDS = 'ai_collage_buffer_pinterest_boards';
    const OPTION_BUFFER_PINTEREST_TITLES = 'ai_collage_buffer_pinterest_titles';
    const OPTION_BUFFER_TRACKER = 'ai_collage_buffer_tracker';
    const OPTION_BUFFER_SHARE_MODE = 'ai_collage_buffer_share_mode';
    const OPTION_BUFFER_DRAFT_RETENTION_DAYS = 'ai_collage_buffer_draft_retention_days';
    const OPTION_BUFFER_STATS_CACHE = 'ai_collage_buffer_stats_cache';
    const OPTION_BUFFER_SHARE_TO_STORY = 'ai_collage_buffer_share_to_story';
    const OPTION_BUFFER_CHANNEL_STORY_TOGGLE = 'ai_collage_buffer_channel_story_toggle';

    // ── Buffer Share Modes ─────────────────────────────────────────────────
    const BUFFER_SHARE_MODES = [
        'draft' => 'Save as Draft (Manual Review)',
        'ideas' => 'Save as Idea (Content Backlog)',
        'auto'  => 'Auto-Share (Scheduled)',
    ];

    // ── Per-Network Hashtag Options ────────────────────────────────────────
    const OPTION_JETPACK_NETWORK_HASHTAGS = 'ai_collage_jetpack_network_hashtags';
	const OPTION_BUFFER_CHANNEL_HASHTAGS = 'ai_collage_buffer_channel_hashtags';
	const OPTION_BUFFER_ACCOUNTS = 'ai_collage_buffer_accounts';
	const OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX = 'ai_collage_buffer_account_tracker_';
	const OPTION_BUFFER_ACCOUNT_TIKTOK_TRACKER_PREFIX = 'ai_collage_buffer_account_tiktok_tracker_';
	const DEFAULT_TIKTOK_DAILY_LIMIT = 10;
	const MAX_TIKTOK_DAILY_LIMIT = 25;
	const OPTION_BUFFER_PENDING_SHARES = 'ai_collage_buffer_pending_shares';

	// ── Buffer Queue Full Actions ──────────────────────────────────────────
	const BUFFER_QUEUE_FULL_ACTIONS = [
		'publish_oldest' => 'Publish Oldest Scheduled Post Now (Make Room)',
		'wait'           => 'Wait for a Free Slot (Retry Automatically)',
	];
const DEFAULT_QUEUE_FULL_ACTION = 'publish_oldest';

	// ── YouTube Post Metadata (Buffer YoutubePostMetadataInput) ────────────
	// categoryId values match the YouTube category IDs published in the
	// Buffer API docs (https://developers.buffer.com/types/YoutubePostMetadataInput.html).
	const BUFFER_YOUTUBE_CATEGORIES = [
		'1'  => 'Film & Animation',
		'2'  => 'Autos & Vehicles',
		'10' => 'Music',
		'15' => 'Pets & Animals',
		'17' => 'Sports',
		'19' => 'Travel & Events',
		'20' => 'Gaming',
		'22' => 'People & Blogs',
		'23' => 'Comedy',
		'24' => 'Entertainment',
		'25' => 'News & Politics',
		'26' => 'Howto & Style',
		'27' => 'Education',
		'28' => 'Science & Technology',
		'29' => 'Nonprofits & Activism',
	];
	const DEFAULT_YOUTUBE_CATEGORY_ID = '24';

	/**
	 * YoutubePrivacy enum values (https://developers.buffer.com/types/YoutubePrivacy.html).
	 * Buffer applies `public` when omitted.
	 */
	const BUFFER_YOUTUBE_PRIVACY = [
		'public'   => 'Public',
		'unlisted' => 'Unlisted',
		'private'  => 'Private',
	];
	const DEFAULT_YOUTUBE_PRIVACY = 'public';


    // ── Social Meta Keys ───────────────────────────────────────────────────
    const META_SOCIAL_COLLAGE_ID = '_ai_collage_social_collage_id';
    const META_JETPACK_MESSAGE = '_wpas_mess';
    const META_JETPACK_IMAGE = '_wpas_media_src';
    const META_JETPACK_OPTIONS = '_wpas_options';
    const META_BUFFER_SHARE_HISTORY = '_ai_collage_buffer_share_history';

    // ── Jetpack Networks ───────────────────────────────────────────────────
    const JETPACK_NETWORKS = [
        'facebook', 'instagram-business', 'threads', 'linkedin',
        'tumblr', 'mastodon', 'nextdoor', 'bluesky',
    ];

    // ── Buffer Services ────────────────────────────────────────────────────
    const BUFFER_SERVICES = [
        'facebook', 'instagram', 'twitter', 'linkedin',
        'pinterest', 'youtube', 'threads', 'tiktok',
    ];

    // ── Per-service caption character limits ────────────────────────────────
    // Buffer rejects captions exceeding the platform limit
    // ("Invalid post: Threads posts cannot exceed 500 characters.").
    // 0 = no truncation applied.
    const BUFFER_SERVICE_CAPTION_LIMITS = [
        'twitter'   => 280,
        'threads'   => 500,
        'instagram' => 2200,
        'facebook'  => 63206,
        'linkedin'  => 3000,
        'pinterest' => 500,
        'tiktok'    => 2200,
        'youtube'   => 5000,
    ];

    public static function get_buffer_service_caption_limit( string $service ): int {
        return (int) ( self::BUFFER_SERVICE_CAPTION_LIMITS[ $service ] ?? 0 );
    }

    const LOG_LEVEL_INFO = 'info';
    const LOG_LEVEL_DEBUG = 'debug';
    const LOG_LEVEL_ERROR = 'error';
    const LOG_LEVEL_WARNING = 'warning';

    public static function get_log_levels() {
        return [
            self::LOG_LEVEL_INFO => 'Info',
            self::LOG_LEVEL_DEBUG => 'Debug',
            self::LOG_LEVEL_ERROR => 'Error',
            self::LOG_LEVEL_WARNING => 'Warning',
        ];
    }

    // ── Campaign Value Helper ──────────────────────────────────────────────
    public static function get_campaign_value( $campaign, $key, $default ) {
        if ( ! is_array( $campaign ) || ! isset( $campaign[ $key ] ) ) {
            return $default;
        }

        $value = $campaign[ $key ];

        switch ( $key ) {
            case 'ai_strategy':
                return self::is_valid_strategy( $value ) ? $value : $default;
		case 'template':
			return ( self::is_valid_template( $value ) ) ? $value : $default;
            case 'frequency':
                return self::is_valid_frequency( $value ) ? $value : $default;
            case 'publish_status':
                return self::is_valid_publish_status( $value ) ? $value : $default;
            case 'platform_size':
                return self::is_valid_platform_size( $value ) ? $value : $default;
            case 'destination_category':
                return is_numeric( $value ) ? (int) $value : 0;
            case 'active':
                return ! empty( $value );
            case 'content_type':
                return in_array( $value, [ 'auto', 'image', 'video' ], true ) ? $value : $default;
            default:
                return $value;
        }
    }

	public static function get_valid_campaign_keys() {
		return [
			'id', 'name', 'source_category', 'tags', 'target_vertical',
			'destination_category', 'frequency', 'publish_status',
			'ai_strategy', 'template', 'platform_size', 'active', 'last_run',
			'language', 'logo_position', 'emphasis_color', 'key_term_color',
			'breaking_color', 'text_backing_color', 'headline_font',
			'brand_override_enabled', 'primary_color', 'secondary_color', 'accent_color', 'font_body',
			'stopped',
			'image_extraction_enabled', 'detection_mode', 'content_type',
			'logo_zone', 'text_zone', 'image_zone',
			'video_zone_enabled', 'video_zone_mode', 'video_content_zone',
			'social_media_enabled', 'social_platforms', 'social_processing_mode',
		];
	}

	public static function get_campaign_brand_settings( $campaign ) {
		$global = self::get_brand_settings();

		if ( empty( $campaign['brand_override_enabled'] ) ) {
			return $global;
		}

	$brand = $global;
		$overrides = [
			'primary_color'      => 'primary_color',
			'secondary_color'    => 'secondary_color',
			'accent_color'       => 'accent_color',
			'emphasis_color'     => 'emphasis_color',
			'key_term_color'     => 'key_term_color',
			'breaking_color'     => 'breaking_color',
			'text_backing_color' => 'text_backing_color',
			'logo_position'      => 'logo_position',
			'headline_font'      => 'font_headline',
			'font_body'          => 'font_body',
		];

		foreach ( $overrides as $campaign_key => $brand_key ) {
			if ( ! empty( $campaign[ $campaign_key ] ) ) {
				$brand[ $brand_key ] = $campaign[ $campaign_key ];
			}
		}

		return $brand;
	}

	public static function get_attribution_templates() {
		return [
			self::ATTRIBUTION_TEMPLATE_DEFAULT => 'Credit (c) @{handle} — {source_url}',
			self::ATTRIBUTION_TEMPLATE_DETAILED => 'Shared from @{handle} on {platform}: {source_url}',
			self::ATTRIBUTION_TEMPLATE_SIMPLE => 'via @{handle}',
		];
	}

	public static function get_processing_modes() {
		return [
			self::PROCESSING_MODE_REPOST => 'Repost (Original + Attribution)',
			self::PROCESSING_MODE_REWRITE => 'Rewrite (AI Content)',
			self::PROCESSING_MODE_AI_COLLAGE => 'AI Collage (Enhanced)',
		];
	}

	public static function get_social_source_platforms() {
		return [
			self::SOURCE_TYPE_INSTAGRAM => 'Instagram',
			self::SOURCE_TYPE_FACEBOOK => 'Facebook',
			self::SOURCE_TYPE_TWITTER => 'Twitter/X',
			self::SOURCE_TYPE_TIKTOK => 'TikTok',
			self::SOURCE_TYPE_YOUTUBE => 'YouTube',
			self::SOURCE_TYPE_LINKEDIN => 'LinkedIn',
		];
	}
	
	// ── Newsroom Workflow Helpers ───────────────────────────────────────
	public static function get_publish_modes() {
		return [
			'draft' => 'Save as Draft (Review Required)',
			'publish' => 'Publish Immediately',
		];
	}
	
	public static function get_hashtag_strategies() {
		return [
			'ai' => 'AI-Generated (Context-Aware)',
			'trending' => 'Trending Topics (Pakistan)',
		];
	}
	
	public static function get_prime_time_slots() {
		$default_slots = ['08:00', '13:00', '20:00'];
		$slots = get_option( self::OPTION_PRIME_TIME_SLOTS, $default_slots );
		return is_array( $slots ) ? $slots : $default_slots;
	}
	
	public static function is_prime_time_enabled() {
		return (bool) get_option( self::OPTION_PRIME_TIME_ENABLED, false );
	}
	
	public static function should_publish_immediately() {
		$mode = get_option( self::OPTION_PUBLISH_MODE, 'draft' );
		return $mode === 'publish';
	}

	// ── Jetpack Social Helpers ─────────────────────────────────────────────
	public static function is_jetpack_enabled() {
		return (bool) get_option( self::OPTION_JETPACK_ENABLED, false );
	}

	public static function is_jetpack_link_disabled() {
		return (bool) get_option( self::OPTION_JETPACK_DISABLE_LINK, false );
	}

	public static function get_jetpack_template() {
		return get_option( self::OPTION_JETPACK_TEMPLATE, "{headline}\n\n{description}\n\n{hashtags}\n\n{link}" );
	}

	public static function get_jetpack_networks() {
		$networks = get_option( self::OPTION_JETPACK_NETWORKS, [] );
		if ( empty( $networks ) || ! is_array( $networks ) ) {
			$networks = array_fill_keys( self::JETPACK_NETWORKS, true );
		}
		return $networks;
	}

	public static function get_jetpack_network_templates() {
		return get_option( self::OPTION_JETPACK_NETWORK_TEMPLATES, [] );
	}

	// ── R2 Storage Helpers ───────────────────────────────────────────────────

	public static function get_r2_endpoint(): string {
		return trim( (string) get_option( self::OPTION_R2_ENDPOINT, '' ) );
	}

	public static function get_r2_access_key(): string {
		return trim( (string) get_option( self::OPTION_R2_ACCESS_KEY, '' ) );
	}

	public static function get_r2_secret_key(): string {
		return trim( (string) get_option( self::OPTION_R2_SECRET_KEY, '' ) );
	}

	public static function get_r2_bucket(): string {
		return trim( (string) get_option( self::OPTION_R2_BUCKET, '' ) );
	}

	public static function get_r2_public_domain(): string {
		return trim( (string) get_option( self::OPTION_R2_PUBLIC_DOMAIN, '' ) );
	}

	public static function is_r2_configured(): bool {
		return self::get_r2_endpoint() !== ''
			&& self::get_r2_access_key() !== ''
			&& self::get_r2_secret_key() !== ''
			&& self::get_r2_bucket() !== ''
			&& self::get_r2_public_domain() !== '';
	}

	public static function is_video_r2_buffer_auto_enabled(): bool {
		return (bool) get_option( self::OPTION_VIDEO_R2_BUFFER_AUTO, false );
	}

	public static function validate_r2_public_domain(): ?string {
		$public_domain = self::get_r2_public_domain();
		if ( $public_domain === '' ) {
			return 'R2 public domain not configured. Set a Cloudflare Workers custom domain or enable Public Bucket on the R2 bucket.';
		}
		$pd_host = wp_parse_url( $public_domain, PHP_URL_HOST );
		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( $pd_host && $site_host && strtolower( $pd_host ) === strtolower( $site_host ) ) {
			return 'R2 public domain points at this WordPress site (' . $site_host . '). Videos will be unplayable. Set a Cloudflare Workers custom domain or enable Public Bucket on the R2 bucket and use the generated URL.';
		}
		return null;
	}

	// ── Buffer API Helpers (existing, add R2 check) ────────────────────────
	public static function is_buffer_enabled() {
		$active = self::get_active_buffer_accounts();
		if ( ! empty( $active ) ) {
			return true;
		}
		if ( ! empty( get_option( self::OPTION_BUFFER_ACCESS_TOKEN, '' ) ) ) {
			return (bool) get_option( self::OPTION_BUFFER_ENABLED, false );
		}
		return false;
	}

	public static function is_buffer_link_disabled() {
		return (bool) get_option( self::OPTION_BUFFER_DISABLE_LINK, false );
	}

	public static function get_buffer_access_token() {
		$active = self::get_active_buffer_accounts();
		if ( ! empty( $active ) ) {
			$first = reset( $active );
			return (string) ( $first['api_key'] ?? '' );
		}
		return get_option( self::OPTION_BUFFER_ACCESS_TOKEN, '' );
	}

	public static function get_buffer_daily_limit() {
		$active = self::get_active_buffer_accounts();
		if ( ! empty( $active ) ) {
			$first = reset( $active );
			return max( 0, (int) ( $first['daily_limit'] ?? 5 ) );
		}
		return (int) get_option( self::OPTION_BUFFER_DAILY_LIMIT, 5 );
	}

	public static function get_buffer_channels() {
		return get_option( self::OPTION_BUFFER_CHANNELS, [] );
	}

	public static function get_buffer_channel_types() {
		return get_option( self::OPTION_BUFFER_CHANNEL_TYPES, [] );
	}

	public static function get_buffer_channel_templates() {
		return get_option( self::OPTION_BUFFER_CHANNEL_TEMPLATES, [] );
	}

	public static function get_buffer_global_template() {
		return get_option( self::OPTION_BUFFER_GLOBAL_TEMPLATE, "{headline}\n\n{description}\n\n{hashtags}\n\n{link}" );
	}

	public static function get_buffer_link_posts() {
		return get_option( self::OPTION_BUFFER_LINK_POSTS, [] );
	}

	public static function get_buffer_tracker() {
		$tracker = get_option( self::OPTION_BUFFER_TRACKER, [ 'date' => '', 'ids' => [] ] );
		if ( ! is_array( $tracker ) ) {
			$tracker = [ 'date' => '', 'ids' => [] ];
		}
		return $tracker;
	}

	public static function increment_buffer_tracker( $post_id ) {
		$tracker = self::get_buffer_tracker();
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			$tracker = [ 'date' => $today, 'ids' => [] ];
		}
		$tracker['ids'][] = (int) $post_id;
		update_option( self::OPTION_BUFFER_TRACKER, $tracker );
	}

	public static function buffer_daily_limit_reached( string $account_id = '' ) {
		if ( $account_id !== '' ) {
			return self::buffer_account_daily_limit_reached( $account_id );
		}
		$active = self::get_active_buffer_accounts();
		if ( ! empty( $active ) ) {
			foreach ( $active as $acct_id => $acct ) {
				if ( self::buffer_account_daily_limit_reached( $acct_id ) ) {
					return true;
				}
			}
			return false;
		}
		$limit = self::get_buffer_daily_limit();
		if ( $limit <= 0 ) {
			return false;
		}
		$tracker = self::get_buffer_tracker();
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			return false;
		}
		return count( $tracker['ids'] ) >= $limit;
	}

	public static function get_buffer_pinterest_boards() {
		return get_option( self::OPTION_BUFFER_PINTEREST_BOARDS, [] );
	}

	public static function get_buffer_pinterest_titles() {
		return get_option( self::OPTION_BUFFER_PINTEREST_TITLES, [] );
	}

	// ── Per-Network Hashtag Helpers ────────────────────────────────────────
	public static function get_jetpack_network_hashtags() {
		return get_option( self::OPTION_JETPACK_NETWORK_HASHTAGS, [] );
	}

	public static function get_buffer_channel_hashtags() {
		return get_option( self::OPTION_BUFFER_CHANNEL_HASHTAGS, [] );
	}

	public static function get_buffer_share_mode() {
		$mode = get_option( self::OPTION_BUFFER_SHARE_MODE, 'draft' );
		return array_key_exists( $mode, self::BUFFER_SHARE_MODES ) ? $mode : 'draft';
	}

	public static function is_buffer_share_to_story_enabled(): bool {
		return (bool) get_option( self::OPTION_BUFFER_SHARE_TO_STORY, false );
	}

	public static function get_buffer_channel_story_toggles(): array {
		return get_option( self::OPTION_BUFFER_CHANNEL_STORY_TOGGLE, [] );
	}

	public static function should_share_to_story( string $channel_id ): bool {
		if ( ! self::is_buffer_share_to_story_enabled() ) {
			return false;
		}
		$toggles = self::get_buffer_channel_story_toggles();
		return ! empty( $toggles[ $channel_id ] );
	}

	// ── Multi-Account Buffer Helpers ─────────────────────────────────────

	public static function get_buffer_accounts(): array {
		$stored = get_option( self::OPTION_BUFFER_ACCOUNTS, '' );
		$accounts = is_string( $stored ) ? json_decode( $stored, true ) : ( is_array( $stored ) ? $stored : [] );
		if ( ! is_array( $accounts ) ) {
			$accounts = [];
		}

		// Re-key numerically-indexed arrays by account ID
		if ( ! empty( $accounts ) && is_int( array_key_first( $accounts ) ) ) {
			$keyed = [];
			foreach ( $accounts as $acct ) {
				$acct_id = $acct['id'] ?? '';
				if ( $acct_id !== '' ) {
					$keyed[ $acct_id ] = $acct;
				}
			}
			$accounts = $keyed;
		}

		$has_accounts = ! empty( $accounts ) && is_array( $accounts );
		$has_legacy   = ! empty( get_option( self::OPTION_BUFFER_ACCESS_TOKEN, '' ) );

		if ( $has_accounts ) {
			return $accounts;
		}

		if ( $has_legacy ) {
			return self::migrate_legacy_buffer_to_accounts();
		}

		return [];
	}

	public static function get_active_buffer_accounts(): array {
		$accounts = self::get_buffer_accounts();
		$active = [];
		foreach ( $accounts as $acct ) {
			if ( ! empty( $acct['enabled'] ) && ! empty( $acct['api_key'] ) ) {
				$active[ $acct['id'] ] = $acct;
			}
		}
		return $active;
	}

	public static function get_buffer_account( string $id ): ?array {
		$accounts = self::get_buffer_accounts();
		return $accounts[ $id ] ?? null;
	}

	public static function get_buffer_account_token( string $id ): string {
		$acct = self::get_buffer_account( $id );
		if ( ! is_array( $acct ) || empty( $acct['api_key'] ) ) {
			$legacy = get_option( self::OPTION_BUFFER_ACCESS_TOKEN, '' );
			return $id === 'default' ? (string) $legacy : '';
		}
		return (string) $acct['api_key'];
	}

	public static function get_buffer_account_daily_limit( string $id ): int {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) ) {
			return max( 0, (int) ( $acct['daily_limit'] ?? 5 ) );
		}
		return self::get_buffer_daily_limit();
	}

	public static function get_buffer_account_channels( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_ids'] ) && is_array( $acct['channel_ids'] ) ) {
			return $acct['channel_ids'];
		}
		return self::get_buffer_channels();
	}

	public static function get_buffer_account_channel_types( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_types'] ) && is_array( $acct['channel_types'] ) ) {
			return $acct['channel_types'];
		}
		return self::get_buffer_channel_types();
	}

	public static function get_buffer_account_channel_templates( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_templates'] ) && is_array( $acct['channel_templates'] ) ) {
			return $acct['channel_templates'];
		}
		return self::get_buffer_channel_templates();
	}

	public static function get_buffer_account_channel_story_templates( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_story_templates'] ) && is_array( $acct['channel_story_templates'] ) ) {
			return $acct['channel_story_templates'];
		}
		return [];
	}

	public static function get_buffer_account_global_template( string $id ): string {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['global_template'] ) ) {
			return (string) $acct['global_template'];
		}
		return self::get_buffer_global_template();
	}

	public static function get_buffer_account_link_posts( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['link_posts'] ) && is_array( $acct['link_posts'] ) ) {
			return $acct['link_posts'];
		}
		return self::get_buffer_link_posts();
	}

	public static function get_buffer_account_channel_hashtags( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_hashtags'] ) && is_array( $acct['channel_hashtags'] ) ) {
			return $acct['channel_hashtags'];
		}
		return self::get_buffer_channel_hashtags();
	}

	public static function get_buffer_account_pinterest_boards( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['pinterest_boards'] ) && is_array( $acct['pinterest_boards'] ) ) {
			return $acct['pinterest_boards'];
		}
		return self::get_buffer_pinterest_boards();
	}

	public static function get_buffer_account_pinterest_titles( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['pinterest_titles'] ) && is_array( $acct['pinterest_titles'] ) ) {
			return $acct['pinterest_titles'];
		}
		return self::get_buffer_pinterest_titles();
	}

	public static function get_buffer_account_share_mode( string $id ): string {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['share_mode'] ) ) {
			$mode = (string) $acct['share_mode'];
			return array_key_exists( $mode, self::BUFFER_SHARE_MODES ) ? $mode : 'draft';
		}
		return self::get_buffer_share_mode();
	}

	/**
	 * Per-account YouTube privacy setting (YoutubePrivacy enum: public|unlisted|private).
	 * Applied to YoutubePostMetadataInput.privacy when sharing to YouTube via Buffer.
	 */
	public static function get_buffer_account_youtube_privacy( string $id ): string {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['youtube_privacy'] ) ) {
			$privacy = (string) $acct['youtube_privacy'];
			return array_key_exists( $privacy, self::BUFFER_YOUTUBE_PRIVACY ) ? $privacy : self::DEFAULT_YOUTUBE_PRIVACY;
		}
		return self::DEFAULT_YOUTUBE_PRIVACY;
	}

	public static function get_buffer_account_youtube_titles( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['youtube_titles'] ) && is_array( $acct['youtube_titles'] ) ) {
			return $acct['youtube_titles'];
		}
		return [];
	}

	public static function get_buffer_account_youtube_categories( string $id ): array {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['youtube_categories'] ) && is_array( $acct['youtube_categories'] ) ) {
			return $acct['youtube_categories'];
		}
		return [];
	}

	public static function is_buffer_account_link_disabled( string $id ): bool {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['disable_link'] ) ) {
			return (bool) $acct['disable_link'];
		}
		return self::is_buffer_link_disabled();
	}

	public static function is_buffer_account_share_to_story_enabled( string $id ): bool {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['share_to_story'] ) ) {
			return (bool) $acct['share_to_story'];
		}
		return self::is_buffer_share_to_story_enabled();
	}

	public static function should_buffer_account_share_to_story( string $id, string $channel_id ): bool {
		if ( ! self::is_buffer_account_share_to_story_enabled( $id ) ) {
			return false;
		}
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['channel_story_toggles'] ) && is_array( $acct['channel_story_toggles'] ) ) {
			return ! empty( $acct['channel_story_toggles'][ $channel_id ] );
		}
		return self::should_share_to_story( $channel_id );
	}

	public static function get_buffer_account_tracker( string $id ): array {
		$option_name = self::OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX . $id;
		$tracker = get_option( $option_name, [ 'date' => '', 'ids' => [] ] );
		if ( ! is_array( $tracker ) ) {
			$tracker = [ 'date' => '', 'ids' => [] ];
		}
		return $tracker;
	}

	public static function increment_buffer_account_tracker( string $id, int $post_id ): void {
		$option_name = self::OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX . $id;
		$tracker = self::get_buffer_account_tracker( $id );
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			$tracker = [ 'date' => $today, 'ids' => [] ];
		}
		$tracker['ids'][] = $post_id;
		update_option( $option_name, $tracker );
	}

	public static function buffer_account_daily_limit_reached( string $id ): bool {
		$limit = self::get_buffer_account_daily_limit( $id );
		if ( $limit <= 0 ) {
			return false;
		}
		$tracker = self::get_buffer_account_tracker( $id );
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			return false;
		}
		return count( $tracker['ids'] ) >= $limit;
	}

	// ── Per-Account TikTok Daily Limit (separate from the global daily limit) ─

	public static function get_buffer_account_tiktok_daily_limit( string $id ): int {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) ) {
			return max( 0, min( self::MAX_TIKTOK_DAILY_LIMIT, (int) ( $acct['tiktok_daily_limit'] ?? self::DEFAULT_TIKTOK_DAILY_LIMIT ) ) );
		}
		return self::DEFAULT_TIKTOK_DAILY_LIMIT;
	}

	public static function get_buffer_account_tiktok_tracker( string $id ): array {
		$option_name = self::OPTION_BUFFER_ACCOUNT_TIKTOK_TRACKER_PREFIX . $id;
		$tracker = get_option( $option_name, [ 'date' => '', 'ids' => [] ] );
		if ( ! is_array( $tracker ) ) {
			$tracker = [ 'date' => '', 'ids' => [] ];
		}
		return $tracker;
	}

	public static function increment_buffer_account_tiktok_tracker( string $id, int $post_id ): void {
		$option_name = self::OPTION_BUFFER_ACCOUNT_TIKTOK_TRACKER_PREFIX . $id;
		$tracker = self::get_buffer_account_tiktok_tracker( $id );
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			$tracker = [ 'date' => $today, 'ids' => [] ];
		}
		$tracker['ids'][] = $post_id;
		update_option( $option_name, $tracker );
	}

	public static function buffer_account_tiktok_daily_limit_reached( string $id ): bool {
		$limit = self::get_buffer_account_tiktok_daily_limit( $id );
		if ( $limit <= 0 ) {
			return false;
		}
		$tracker = self::get_buffer_account_tiktok_tracker( $id );
		$today = gmdate( 'Y-m-d' );
		if ( $tracker['date'] !== $today ) {
			return false;
		}
		return count( $tracker['ids'] ) >= $limit;
	}

	// ── Per-Account Queue Full Action (when a channel hits the scheduled-posts limit) ─

	public static function get_buffer_account_queue_full_action( string $id ): string {
		$acct = self::get_buffer_account( $id );
		if ( is_array( $acct ) && isset( $acct['queue_full_action'] ) ) {
			$action = (string) $acct['queue_full_action'];
			return array_key_exists( $action, self::BUFFER_QUEUE_FULL_ACTIONS ) ? $action : self::DEFAULT_QUEUE_FULL_ACTION;
		}
		return self::DEFAULT_QUEUE_FULL_ACTION;
	}

	public static function save_buffer_accounts( array $accounts ): array {
		$clean = [];
		foreach ( $accounts as $profile ) {
			$validated = self::validate_buffer_account( $profile );
			if ( $validated !== null ) {
				$clean[] = $validated;
			}
		}
		update_option( self::OPTION_BUFFER_ACCOUNTS, wp_json_encode( $clean ) );
		return $clean;
	}

	public static function validate_buffer_account( array $profile ): ?array {
		$id = isset( $profile['id'] ) ? sanitize_key( $profile['id'] ) : '';
		if ( $id === '' ) {
			return null;
		}
		$name              = isset( $profile['name'] ) ? sanitize_text_field( $profile['name'] ) : $id;
		$api_key           = isset( $profile['api_key'] ) ? sanitize_text_field( $profile['api_key'] ) : '';
		$enabled           = ! empty( $profile['enabled'] );
		$daily_limit       = max( 0, min( 50, (int) ( $profile['daily_limit'] ?? 5 ) ) );
		$tiktok_daily_limit = max( 0, min( self::MAX_TIKTOK_DAILY_LIMIT, (int) ( $profile['tiktok_daily_limit'] ?? self::DEFAULT_TIKTOK_DAILY_LIMIT ) ) );
		$disable_link      = ! empty( $profile['disable_link'] );
		$share_to_story    = ! empty( $profile['share_to_story'] );
		$global_template   = isset( $profile['global_template'] ) ? sanitize_textarea_field( wp_unslash( $profile['global_template'] ) ) : '';

		$share_mode = sanitize_text_field( $profile['share_mode'] ?? 'draft' );
		if ( ! array_key_exists( $share_mode, self::BUFFER_SHARE_MODES ) ) {
			$share_mode = 'draft';
		}

		$queue_full_action = sanitize_text_field( $profile['queue_full_action'] ?? self::DEFAULT_QUEUE_FULL_ACTION );
		if ( ! array_key_exists( $queue_full_action, self::BUFFER_QUEUE_FULL_ACTIONS ) ) {
			$queue_full_action = self::DEFAULT_QUEUE_FULL_ACTION;
		}

		$channel_ids       = isset( $profile['channel_ids'] ) && is_array( $profile['channel_ids'] )
			? array_values( array_filter( array_map( 'sanitize_text_field', $profile['channel_ids'] ) ) ) : [];
		$channel_types     = isset( $profile['channel_types'] ) && is_array( $profile['channel_types'] ) ? $profile['channel_types'] : [];
		$channel_templates = isset( $profile['channel_templates'] ) && is_array( $profile['channel_templates'] ) ? $profile['channel_templates'] : [];
		$link_posts        = isset( $profile['link_posts'] ) && is_array( $profile['link_posts'] ) ? $profile['link_posts'] : [];
		$channel_hashtags  = isset( $profile['channel_hashtags'] ) && is_array( $profile['channel_hashtags'] ) ? $profile['channel_hashtags'] : [];
		$pinterest_boards  = isset( $profile['pinterest_boards'] ) && is_array( $profile['pinterest_boards'] ) ? $profile['pinterest_boards'] : [];
		$pinterest_titles  = isset( $profile['pinterest_titles'] ) && is_array( $profile['pinterest_titles'] ) ? $profile['pinterest_titles'] : [];
		$story_toggles     = isset( $profile['channel_story_toggles'] ) && is_array( $profile['channel_story_toggles'] ) ? $profile['channel_story_toggles'] : [];
		$channel_story_templates = isset( $profile['channel_story_templates'] ) && is_array( $profile['channel_story_templates'] ) ? $profile['channel_story_templates'] : [];

		$sanitized_types = [];
		foreach ( $channel_types as $ch => $type ) {
			$sanitized_types[ sanitize_text_field( $ch ) ] = sanitize_text_field( $type );
		}
		$sanitized_templates = [];
		foreach ( $channel_templates as $ch => $tpl ) {
			$sanitized_templates[ sanitize_text_field( $ch ) ] = sanitize_textarea_field( wp_unslash( $tpl ) );
		}
		$sanitized_link_posts = [];
		foreach ( $link_posts as $ch => $val ) {
			$sanitized_link_posts[ sanitize_text_field( $ch ) ] = (bool) $val;
		}
		$sanitized_hashtags = [];
		foreach ( $channel_hashtags as $ch => $tags ) {
			$sanitized_hashtags[ sanitize_text_field( $ch ) ] = sanitize_text_field( wp_unslash( $tags ) );
		}
		$sanitized_boards = [];
		foreach ( $pinterest_boards as $ch => $board ) {
			$sanitized_boards[ sanitize_text_field( $ch ) ] = sanitize_text_field( $board );
		}
		$sanitized_titles = [];
		foreach ( $pinterest_titles as $ch => $title ) {
			$sanitized_titles[ sanitize_text_field( $ch ) ] = sanitize_text_field( $title );
		}
		$sanitized_story = [];
		foreach ( $story_toggles as $ch => $val ) {
			$sanitized_story[ sanitize_text_field( $ch ) ] = (bool) $val;
		}
		$sanitized_story_templates = [];
		foreach ( $channel_story_templates as $ch => $tpl ) {
			$sanitized_story_templates[ sanitize_text_field( $ch ) ] = sanitize_textarea_field( wp_unslash( $tpl ) );
		}

		$youtube_privacy = sanitize_text_field( $profile['youtube_privacy'] ?? '' );
		if ( ! array_key_exists( $youtube_privacy, self::BUFFER_YOUTUBE_PRIVACY ) ) {
			$youtube_privacy = self::DEFAULT_YOUTUBE_PRIVACY;
		}
		$youtube_titles    = isset( $profile['youtube_titles'] ) && is_array( $profile['youtube_titles'] ) ? $profile['youtube_titles'] : [];
		$youtube_categories = isset( $profile['youtube_categories'] ) && is_array( $profile['youtube_categories'] ) ? $profile['youtube_categories'] : [];
		$sanitized_yt_titles = [];
		foreach ( $youtube_titles as $ch => $title ) {
			$sanitized_yt_titles[ sanitize_text_field( $ch ) ] = sanitize_text_field( $title );
		}
		$sanitized_yt_categories = [];
		foreach ( $youtube_categories as $ch => $cat ) {
			$cat = sanitize_text_field( $cat );
			if ( array_key_exists( $cat, self::BUFFER_YOUTUBE_CATEGORIES ) ) {
				$sanitized_yt_categories[ sanitize_text_field( $ch ) ] = $cat;
			}
		}

		return [
			'id'                    => $id,
			'name'                  => $name,
			'api_key'               => $api_key,
			'enabled'               => $enabled,
			'daily_limit'           => $daily_limit,
			'tiktok_daily_limit'    => $tiktok_daily_limit,
			'disable_link'          => $disable_link,
			'share_to_story'        => $share_to_story,
			'share_mode'            => $share_mode,
			'youtube_privacy'       => $youtube_privacy,
			'queue_full_action'     => $queue_full_action,
			'global_template'       => $global_template,
			'channel_ids'           => $channel_ids,
			'channel_types'         => $sanitized_types,
			'channel_templates'     => $sanitized_templates,
			'link_posts'            => $sanitized_link_posts,
			'channel_hashtags'      => $sanitized_hashtags,
			'pinterest_boards'      => $sanitized_boards,
			'pinterest_titles'      => $sanitized_titles,
			'youtube_titles'        => $sanitized_yt_titles,
			'youtube_categories'    => $sanitized_yt_categories,
			'channel_story_toggles' => $sanitized_story,
			'channel_story_templates' => $sanitized_story_templates,
		];
	}

	private static function migrate_legacy_buffer_to_accounts(): array {
		$legacy_token = get_option( self::OPTION_BUFFER_ACCESS_TOKEN, '' );
		$channels     = (array) get_option( self::OPTION_BUFFER_CHANNELS, [] );
		$channel_types     = (array) get_option( self::OPTION_BUFFER_CHANNEL_TYPES, [] );
		$channel_templates = (array) get_option( self::OPTION_BUFFER_CHANNEL_TEMPLATES, [] );
		$link_posts        = (array) get_option( self::OPTION_BUFFER_LINK_POSTS, [] );
		$channel_hashtags  = (array) get_option( self::OPTION_BUFFER_CHANNEL_HASHTAGS, [] );
		$pinterest_boards  = (array) get_option( self::OPTION_BUFFER_PINTEREST_BOARDS, [] );
		$pinterest_titles  = (array) get_option( self::OPTION_BUFFER_PINTEREST_TITLES, [] );
		$story_toggles     = (array) get_option( self::OPTION_BUFFER_CHANNEL_STORY_TOGGLE, [] );

		$synthetic = [
			'id'                    => 'default',
			'name'                  => 'Primary Account',
			'api_key'               => $legacy_token,
			'enabled'               => (bool) get_option( self::OPTION_BUFFER_ENABLED, false ),
			'daily_limit'           => max( 0, (int) get_option( self::OPTION_BUFFER_DAILY_LIMIT, 5 ) ),
			'tiktok_daily_limit'    => self::DEFAULT_TIKTOK_DAILY_LIMIT,
			'disable_link'          => (bool) get_option( self::OPTION_BUFFER_DISABLE_LINK, false ),
			'share_to_story'        => (bool) get_option( self::OPTION_BUFFER_SHARE_TO_STORY, false ),
			'share_mode'            => self::get_buffer_share_mode(),
			'queue_full_action'     => self::DEFAULT_QUEUE_FULL_ACTION,
			'global_template'       => get_option( self::OPTION_BUFFER_GLOBAL_TEMPLATE, '' ),
			'channel_ids'           => array_values( array_filter( array_map( 'sanitize_text_field', $channels ) ) ),
			'channel_types'         => $channel_types,
			'channel_templates'     => $channel_templates,
			'link_posts'            => $link_posts,
			'channel_hashtags'      => $channel_hashtags,
			'pinterest_boards'      => $pinterest_boards,
			'pinterest_titles'      => $pinterest_titles,
			'channel_story_toggles' => $story_toggles,
		];

		update_option( self::OPTION_BUFFER_ACCOUNTS, wp_json_encode( [ $synthetic ] ) );
		return [ 'default' => $synthetic ];
	}

	// ── Timezone Display Helper ───────────────────────────────────────────
	// All timestamps are stored internally in UTC. UI display MUST render in
	// the WordPress site timezone (Settings > General), never a hardcoded zone.
	public static function utc_to_site_display( string $utc_datetime, string $format = 'Y-m-d H:i:s' ): string {
		if ( empty( $utc_datetime ) || $utc_datetime === '0000-00-00 00:00:00' ) {
			return $utc_datetime;
		}
		try {
			$dt = new \DateTime( $utc_datetime, new \DateTimeZone( 'UTC' ) );
			$dt->setTimezone( wp_timezone() );
			return $dt->format( $format );
		} catch ( \Exception $e ) {
			return $utc_datetime;
		}
	}

	// ── Defensive Option Reader ──────────────────────────────────────────────
	/**
	 * Read an option that must be an array. Returns $default if the stored
	 * value is not an array (e.g. serialized string, false, etc.).
	 */
	public static function get_option_array( string $option, $default = [] ) {
		$value = get_option( $option, $default );
		return is_array( $value ) ? $value : $default;
	}

	// ── Video Branded Border Detection ────────────────────────────────────

	/**
	 * Detect yellow/orange branded border in a video frame (Diva-style).
	 * Samples pixels from all 4 edges and checks for yellow dominance.
	 *
	 * @param string $frame_path Path to frame image (JPEG/PNG).
	 * @return bool True if branded border detected.
	 */
	public static function has_branded_border( string $frame_path ): bool {
		if ( ! file_exists( $frame_path ) ) {
			return false;
		}

		$im = self::load_image( $frame_path );
		if ( ! $im ) {
			return false;
		}

		$w = imagesx( $im );
		$h = imagesy( $im );
		if ( $w < 20 || $h < 20 ) {
			imagedestroy( $im );
			return false;
		}

		$yellow = 0;
		$total  = 0;
		$sample = 12;

		// Top edge
		for ( $i = 0; $i < $sample; $i++ ) {
			$x = (int) ( $w * ( $i + 1 ) / ( $sample + 1 ) );
			$color = self::sample_pixel( $im, $x, 4 );
			if ( $color ) { $total++; if ( self::is_yellow_orange( $color ) ) $yellow++; }
		}
		// Bottom edge
		for ( $i = 0; $i < $sample; $i++ ) {
			$x = (int) ( $w * ( $i + 1 ) / ( $sample + 1 ) );
			$color = self::sample_pixel( $im, $x, $h - 5 );
			if ( $color ) { $total++; if ( self::is_yellow_orange( $color ) ) $yellow++; }
		}
		// Left edge
		for ( $i = 0; $i < $sample; $i++ ) {
			$y = (int) ( $h * ( $i + 1 ) / ( $sample + 1 ) );
			$color = self::sample_pixel( $im, 4, $y );
			if ( $color ) { $total++; if ( self::is_yellow_orange( $color ) ) $yellow++; }
		}
		// Right edge
		for ( $i = 0; $i < $sample; $i++ ) {
			$y = (int) ( $h * ( $i + 1 ) / ( $sample + 1 ) );
			$color = self::sample_pixel( $im, $w - 5, $y );
			if ( $color ) { $total++; if ( self::is_yellow_orange( $color ) ) $yellow++; }
		}

		imagedestroy( $im );

		if ( $total === 0 ) {
			return false;
		}

		$ratio = $yellow / $total;
		// Branded if >55% of border pixels are yellow/orange
		return $ratio > 0.55;
	}

	/**
	 * Load an image file into a GD resource.
	 */
	private static function load_image( string $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		switch ( $ext ) {
			case 'jpg':
			case 'jpeg':
				return @imagecreatefromjpeg( $path );
			case 'png':
				return @imagecreatefrompng( $path );
			case 'webp':
				if ( function_exists( 'imagecreatefromwebp' ) ) {
					return @imagecreatefromwebp( $path );
				}
				return null;
		}
		// Try JPEG as fallback
		if ( function_exists( 'imagecreatefromjpeg' ) ) {
			return @imagecreatefromjpeg( $path );
		}
		return null;
	}

	/**
	 * Sample a single pixel color from a GD image.
	 */
	private static function sample_pixel( $im, int $x, int $y ): ?array {
		$x = max( 0, $x );
		$y = max( 0, $y );
		$w = imagesx( $im );
		$h = imagesy( $im );
		if ( $x >= $w || $y >= $h ) {
			return null;
		}
		$rgb = imagecolorat( $im, $x, $y );
		return [
			'r' => ( $rgb >> 16 ) & 0xFF,
			'g' => ( $rgb >> 8 ) & 0xFF,
			'b' => $rgb & 0xFF,
		];
	}

	/**
	 * Check if a color is yellow/orange (Diva-style branding).
	 * Yellow: R >= 200, G >= 140, B <= 100
	 * Orange: R >= 200, G >= 100-160, B <= 80
	 */
	private static function is_yellow_orange( array $c ): bool {
		// Yellow range
		if ( $c['r'] >= 200 && $c['g'] >= 140 && $c['b'] <= 100 ) {
			return true;
		}
		// Orange range
		if ( $c['r'] >= 200 && $c['g'] >= 100 && $c['g'] <= 170 && $c['b'] <= 80 ) {
			return true;
		}
		return false;
	}
}
