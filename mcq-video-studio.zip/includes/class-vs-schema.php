<?php

/**
 * Video Studio Schema Definitions
 *
 * Centralized schema definitions for all plugin tables.
 * Ensures consistency between installer, repositories, and code.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Schema
{

    const VERSION = '1.5.1';

    public static function get_tables_to_create()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix;

        return array(
            'vs_logs' => "CREATE TABLE {$prefix}vs_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                ts DATETIME NOT NULL,
                level VARCHAR(16) NOT NULL DEFAULT 'info',
                source VARCHAR(32) NOT NULL DEFAULT 'SERVER',
                message TEXT NOT NULL,
                context_json LONGTEXT DEFAULT NULL,
                user_id BIGINT UNSIGNED DEFAULT NULL,
                request_uri VARCHAR(255) DEFAULT NULL,
                INDEX idx_logs_ts (ts),
                INDEX idx_logs_level (level),
                INDEX idx_logs_source (source),
                INDEX idx_logs_level_ts (level, ts)
            ) $charset_collate;",

            'vs_topics' => "CREATE TABLE {$prefix}vs_topics (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                slug VARCHAR(255) NOT NULL,
                parent_id BIGINT(20) UNSIGNED DEFAULT 0,
                type VARCHAR(20) NOT NULL DEFAULT 'exam',
                code VARCHAR(50) DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY unique_slug (slug),
                INDEX idx_parent (parent_id),
                INDEX idx_type (type)
            ) $charset_collate;",

'vs_mcq_bank' => "CREATE TABLE {$prefix}vs_mcq_bank (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  content_hash CHAR(32) NOT NULL,
  question_text TEXT NOT NULL,
  options JSON NOT NULL,
  correct_index TINYINT UNSIGNED NOT NULL DEFAULT 0,
  explanation TEXT,
  topic_id BIGINT(20) UNSIGNED NOT NULL,
  difficulty VARCHAR(10) DEFAULT 'medium',
  status VARCHAR(20) DEFAULT 'draft',
                usage_count INT UNSIGNED DEFAULT 0,
                last_used_job_id VARCHAR(64) DEFAULT NULL,
                parent_post_id BIGINT(20) UNSIGNED DEFAULT NULL,
                source_ref VARCHAR(100) DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY unique_content (content_hash),
                INDEX idx_topic_status (topic_id, status),
                INDEX idx_parent_post (parent_post_id)
            ) $charset_collate;",

            'vs_exam_calendar' => "CREATE TABLE {$prefix}vs_exam_calendar (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                exam_name VARCHAR(255) NOT NULL,
                exam_date DATE NULL,
                syllabus_config JSON NULL,
                generation_schedule JSON NULL,
                status VARCHAR(50) DEFAULT 'active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",

        'vs_jobs' => "CREATE TABLE {$prefix}vs_jobs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            job_id VARCHAR(64) NOT NULL UNIQUE,
            topic_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            exam_id BIGINT UNSIGNED DEFAULT NULL,
            project_id BIGINT UNSIGNED DEFAULT NULL COMMENT 'Links job to originating project',
            question_count TINYINT UNSIGNED DEFAULT 5,
            status VARCHAR(30) DEFAULT 'pending',
            video_path VARCHAR(500) DEFAULT NULL,
            video_url VARCHAR(500) DEFAULT NULL,
            platform VARCHAR(20) DEFAULT 'all',
            retry_count TINYINT UNSIGNED DEFAULT 0,
            error_message TEXT DEFAULT NULL,
            quiz_data LONGTEXT DEFAULT NULL COMMENT 'JSON: Array of question objects',
            settings LONGTEXT DEFAULT NULL COMMENT 'JSON: Template, background, music config',
            model_provider VARCHAR(128) DEFAULT NULL COMMENT 'Provider slug used for this job (e.g. gemini, custom provider ID)',
            model_id VARCHAR(128) DEFAULT NULL COMMENT 'Model ID used for this job (e.g. gpt-4o-mini)',
            parent_batch_id VARCHAR(64) DEFAULT NULL COMMENT 'Groups jobs from same bulk schedule',
            INDEX idx_model_provider (model_provider),
            scheduled_at DATETIME NOT NULL COMMENT 'When the job should be processed',
            publish_at DATETIME DEFAULT NULL COMMENT 'When the video should be published to social media',
            buffer_requeued_to DATETIME DEFAULT NULL COMMENT 'Last publish_at reassigned by exponential-backoff Buffer retry re-queue',
            published_channels VARCHAR(500) DEFAULT NULL COMMENT 'JSON: Array of Buffer channel IDs that received this video',
            buffer_post_ids VARCHAR(500) DEFAULT NULL COMMENT 'JSON: Array of Buffer post IDs from successful pushes',
            started_at DATETIME DEFAULT NULL,
            completed_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL,
            INDEX idx_status_scheduled (status, scheduled_at),
            INDEX idx_topic (topic_id),
            INDEX idx_project (project_id),
            INDEX idx_parent_batch (parent_batch_id),
            INDEX idx_publish_at (publish_at),
            INDEX idx_status_publish (status, publish_at)
        ) $charset_collate;",

'vs_projects' => "CREATE TABLE {$prefix}vs_projects (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(255) NOT NULL DEFAULT '',
  template VARCHAR(50) DEFAULT 'modern',
  settings JSON DEFAULT NULL,
  status VARCHAR(30) DEFAULT 'draft',
                video_url VARCHAR(500) DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user (user_id),
                INDEX idx_status (status)
            ) $charset_collate;",

            'vs_project_questions' => "CREATE TABLE {$prefix}vs_project_questions (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                project_id BIGINT UNSIGNED NOT NULL,
                question_text TEXT NOT NULL,
                options JSON NOT NULL,
                correct_index TINYINT UNSIGNED NOT NULL DEFAULT 0,
                background VARCHAR(50) DEFAULT 'gradient',
                sort_order INT DEFAULT 0,
                INDEX idx_project (project_id)
            ) $charset_collate;"
        );
    }

    public static function get_job_statuses()
    {
        return array(
            'pending',
            'rendering',
            'uploading',
            'completed',
            'failed',
            'cancelled',
            'ready_for_render'
        );
    }

    public static function get_project_statuses()
    {
        return array(
            'draft',
            'rendering',
            'completed',
            'failed',
            'cancelled'
        );
    }

    public static function get_platforms()
    {
        return array(
            'youtube',
            'tiktok',
            'instagram',
            'all'
        );
    }

    public static function is_valid_job_status($status)
    {
        return in_array($status, self::get_job_statuses(), true);
    }

    public static function is_valid_project_status($status)
    {
        return in_array($status, self::get_project_statuses(), true);
    }

    public static function is_valid_platform($platform)
    {
        return in_array($platform, self::get_platforms(), true);
    }

    public static function get_valid_job_transitions()
    {
        return array(
            'pending'          => array('ready_for_render', 'rendering', 'cancelled'),
            // @FIX (cross-file audit): `rendering -> completed` is required by the headless
            //              recovery path (`VS_Automation_Engine::run_headless_render_queue` ->
            //              `recover_completed_render`) when the renderer exits cleanly.
            //              Without it, recovery silently failed and the previous-loop's
            //              "spawn succeeded, completion never logged" pattern emerged.
            'rendering'        => array('uploading', 'failed', 'ready_for_render', 'completed'),
            'uploading'        => array('completed', 'failed'),
            'ready_for_render' => array('rendering', 'cancelled', 'failed'),
            'failed'           => array('pending', 'ready_for_render'),
            'cancelled'        => array(),
            'completed'        => array()
        );
    }

    public static function can_transition_job_status($from, $to)
    {
        $transitions = self::get_valid_job_transitions();
        return isset($transitions[$from]) && in_array($to, $transitions[$from], true);
    }

    public static function get_valid_project_transitions()
    {
        return array(
            'draft'     => array('rendering', 'cancelled'),
            'rendering' => array('completed', 'failed', 'cancelled'),
            'failed'    => array('draft'),
            'cancelled' => array('draft'),
            'completed' => array(),
        );
    }

    public static function can_transition_project_status($from, $to)
    {
        $transitions = self::get_valid_project_transitions();
        return isset($transitions[$from]) && in_array($to, $transitions[$from], true);
    }
}

class VS_Job_Status
{
    const PENDING = 'pending';
    const RENDERING = 'rendering';
    const UPLOADING = 'uploading';
    const COMPLETED = 'completed';
    const FAILED = 'failed';
    const CANCELLED = 'cancelled';
    const READY_FOR_RENDER = 'ready_for_render';

    public static function is_valid($status)
    {
        return VS_Schema::is_valid_job_status($status);
    }

    public static function can_transition($from, $to)
    {
        return VS_Schema::can_transition_job_status($from, $to);
    }

    public static function get_all()
    {
        return VS_Schema::get_job_statuses();
    }
}

class VS_Project_Status
{
    const DRAFT = 'draft';
    const RENDERING = 'rendering';
    const COMPLETED = 'completed';
    const FAILED = 'failed';
    const CANCELLED = 'cancelled';

    public static function is_valid($status)
    {
        return VS_Schema::is_valid_project_status($status);
    }

    public static function can_transition($from, $to)
    {
        return VS_Schema::can_transition_project_status($from, $to);
    }

    public static function get_all()
    {
        return VS_Schema::get_project_statuses();
    }
}