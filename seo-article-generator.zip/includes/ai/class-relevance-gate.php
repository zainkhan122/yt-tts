<?php

/**
 * Relevance Gate for Perplexity API Search Results
 *
 * Validates that search_results from Perplexity are actually about
 * the requested software, preventing off-topic grounding (e.g., Photoshop
 * results when requesting PotPlayer).
 *
 * @package SEO_Article_Generator
 * @since 2.14.0
 */

namespace SEO_Article_Generator\AI;

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Relevance Gate Class
 *
 * Checks if Perplexity API search_results are relevant to the requested software.
 * Uses token matching (handles "PotPlayer" vs "Pot Player") and homepage host matching.
 *
 * @since 2.14.0
 */
class Relevance_Gate
{

    /**
     * Check if search results are relevant to the requested software
     *
     * @param array       $search_results The search_results array from Perplexity API response.
     * @param string      $software_name  The requested software name.
     * @param string|null $homepage       Optional homepage URL for domain matching.
     * @param int         $min_required   Minimum number of relevant results required. Default 2.
     * @return bool True if enough relevant results found.
     */
    public static function is_relevant(array $search_results, string $software_name, ?string $homepage = null, int $min_required = 2): bool
    {
        if (empty($software_name) || empty($search_results)) {
            return false;
        }

        return self::count_relevant($search_results, $software_name, $homepage) >= $min_required;
    }

    /**
     * Count relevant search results
     *
     * @param array       $search_results The search_results array from Perplexity API response.
     * @param string      $software_name  The requested software name.
     * @param string|null $homepage       Optional homepage URL for domain matching.
     * @return int Number of relevant results.
     */
    public static function count_relevant(array $search_results, string $software_name, ?string $homepage = null): int
    {
        $tokens        = self::build_tokens($software_name);
        $homepage_host = self::host_from_url($homepage);

        $count = 0;
        foreach ($search_results as $result) {
            if (self::is_result_relevant($result, $tokens, $homepage_host)) {
                ++$count;
            }
        }

        return $count;
    }

    /**
     * Build token variations for matching
     *
     * Handles variations like "PotPlayer" vs "Pot Player" vs "potplayer".
     *
     * @param string $software_name The software name.
     * @return array Array of lowercase token variations.
     */
    private static function build_tokens(string $software_name): array
    {
        $name = trim($software_name);
        if (empty($name)) {
            return array();
        }

        $lower = mb_strtolower($name);

        // Normalize: keep letters/numbers/spaces only.
        $spaced = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $lower);
        $spaced = trim(preg_replace('/\s+/', ' ', $spaced));

        // Concatenated form: "pot player" -> "potplayer".
        $concat = str_replace(' ', '', $spaced);

        // Original lowercase raw (sometimes includes dots or dashes).
        $raw = $lower;

        return array_values(array_unique(array_filter(array($concat, $spaced, $raw))));
    }

    /**
     * Check if a single search result is relevant
     *
     * @param array       $result        Single search result with title, url, snippet.
     * @param array       $tokens        Array of token variations to match.
     * @param string|null $homepage_host Homepage host for domain matching.
     * @return bool True if result is relevant.
     */
    private static function is_result_relevant(array $result, array $tokens, ?string $homepage_host): bool
    {
        $title   = isset($result['title']) ? (string) $result['title'] : '';
        $url     = isset($result['url']) ? (string) $result['url'] : '';
        $snippet = isset($result['snippet']) ? (string) $result['snippet'] : '';

        $haystack = mb_strtolower($title . ' ' . $url . ' ' . $snippet);

        // Host match (if homepage provided).
        if ($homepage_host) {
            $result_host = self::host_from_url($url);
            if ($result_host && self::host_ends_with($result_host, $homepage_host)) {
                return true;
            }

            // Also check for CDN variants (e.g., daum.net -> daumcdn.net).
            $cdn_host = self::get_cdn_variant($homepage_host);
            if ($cdn_host && $result_host && self::host_ends_with($result_host, $cdn_host)) {
                return true;
            }
        }

        // Token matches.
        foreach ($tokens as $token) {
            $token = trim(mb_strtolower($token));
            if (empty($token)) {
                continue;
            }

            // If token contains spaces, require word boundary match.
            if (false !== strpos($token, ' ')) {
                $pattern = '/\b' . preg_quote($token, '/') . '\b/u';
                if (preg_match($pattern, $haystack)) {
                    return true;
                }
            } else {
                // For concatenated tokens, substring match is acceptable (e.g., "potplayer").
                if (false !== strpos($haystack, $token)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Extract host from URL
     *
     * @param string|null $url The URL.
     * @return string|null Normalized hostname or null.
     */
    private static function host_from_url(?string $url): ?string
    {
        if (! $url) {
            return null;
        }

        $host = wp_parse_url($url, PHP_URL_HOST);
        if (! $host) {
            return null;
        }

        $host = mb_strtolower($host);
        $host = preg_replace('/^www\./i', '', $host);

        return $host ?: null;
    }

    /**
     * Check if host ends with domain
     *
     * Matches exact domain or subdomains.
     *
     * @param string $host   The host to check.
     * @param string $domain The domain to match against.
     * @return bool True if host matches or is subdomain.
     */
    private static function host_ends_with(string $host, string $domain): bool
    {
        $host   = mb_strtolower(preg_replace('/^www\./i', '', $host));
        $domain = mb_strtolower(preg_replace('/^www\./i', '', $domain));

        if ($host === $domain) {
            return true;
        }

        // Subdomain match.
        $suffix = '.' . $domain;
        return substr($host, -strlen($suffix)) === $suffix;
    }

    /**
     * Get CDN variant of a domain
     *
     * Maps known official domains to their CDN equivalents.
     *
     * @param string $host The homepage host.
     * @return string|null CDN domain variant or null.
     */
    private static function get_cdn_variant(string $host): ?string
    {
        // Common CDN patterns.
        $cdn_mappings = array(
            'daum.net'      => 'daumcdn.net',
            'naver.com'     => 'pstatic.net',
            'kakao.com'     => 'kakaocdn.net',
            'microsoft.com' => 'msecnd.net',
            'github.com'    => 'githubusercontent.com',
        );

        foreach ($cdn_mappings as $official => $cdn) {
            if (self::host_ends_with($host, $official)) {
                return $cdn;
            }
        }

        return null;
    }
}
