<?php
/**
 * Admission Gate
 *
 * @package SEO_Article_Generator\Core
 */

namespace SEO_Article_Generator\Core;

use SEO_Article_Generator\Utils\Plugin_Time;

if (!defined('\ABSPATH')) {
    exit();
}

/**
 * Authoritative Admission Gate for API and Scanner work.
 * Handles global concurrency, provider health, and deduplication.
 */
final class Admission_Gate
{
    private static $instance = null;

    /**
     * @return self
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * [CRITICAL] Admission Gate Check
     *
     * Verifies if the generation pipeline can accept this item.
     * Performs atomic SQL checks for global inflight limits and item-level deduplication.
     *
     * @param string $software Software name for deduplication.
     * @param string $version  Version string for deduplication.
     * @param bool   $skip_provider_check Pass true for background worker fast-path (skips expensive provider health check).
     * @return array{ok:bool,reason:string,retry_after:int}
     */
    public function can_proceed(string $software, string $version, bool $skip_provider_check = false): array
    {
        // 1. Check Global Pause
        if ("1" !== (string) \get_option("seo_gen_discovery_enabled", "1")) {
            return ["ok" => false, "reason" => "Pipeline is globally paused.", "retry_after" => 300];
        }

        // 2. Check Provider Health - skip when the caller will re-validate post-claim
        if ( ! $skip_provider_check && class_exists('\\SEO_Article_Generator\\AI\\AI_Client') ) {
            $bootstrap = \SEO_Article_Generator\AI\AI_Client::resolve_bootstrap_provider();
            if (empty($bootstrap["ok"])) {
                $retry = (int) ($bootstrap["retry_after"] ?? 60);
                return [
                    "ok"          => false,
                    "reason"      => "AI Providers unavailable: " . ($bootstrap["reason"] ?? "unknown"),
                    "retry_after" => $retry,
                ];
            }
        }

        // 3. Atomic Inflight Check (Deduplication is enforced atomically in claim_slot)
        $max_inflight = (int) \get_option("seo_gen_max_parallel_jobs", 3);
        $current      = (int) \get_option("seo_gen_inflight_generations", 0);

        if ($current >= $max_inflight) {
            return ["ok" => false, "reason" => "Global generation limit reached ({$max_inflight}).", "retry_after" => 60];
        }

        return ["ok" => true, "reason" => "Ready to proceed.", "retry_after" => 0];
    }

    /**
     * [CRITICAL] Claim Generation Slot
     *
     * Uses atomic SQL INSERT ... ON DUPLICATE KEY UPDATE to eliminate
     * the DELETE-then-INSERT race window.
     */
    public function claim_slot(string $software, string $version): bool
    {
        global $wpdb;

        $item_lock_key = "seo_gen_lock_" . \md5($software . $version);
        $now           = (string) \time();
        $stale_cutoff  = (string) ( \time() - 1800 );
        $table         = $wpdb->prefix . "options";

        /*
         * Atomic claim: INSERT succeeds only if the row is absent.
         * If the row exists AND its timestamp is stale (> 30 min), overwrite it
         * atomically using ON DUPLICATE KEY UPDATE with a conditional guard.
         * This eliminates the DELETE-then-INSERT race window.
         */
        $wpdb->suppress_errors(true);
        $claimed_item = (bool) $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$table} (option_name, option_value, autoload)
             VALUES (%s, %s, 'no')
             ON DUPLICATE KEY UPDATE
                 option_value = IF(
                     CAST(option_value AS UNSIGNED) < %s,
                     VALUES(option_value),
                     option_value
                 )",
            $item_lock_key,
            $now,
            $stale_cutoff
        ) );
        $wpdb->suppress_errors(false);

        /*
         * MySQL ON DUPLICATE KEY UPDATE returns 2 for a genuine overwrite,
         * 1 for a fresh INSERT, 0 if the guard blocked us (row is live).
         * rows_affected == 0 means another live process owns this item.
         */
        if ( ! $claimed_item && (int) $wpdb->rows_affected === 0 ) {
            return false;
        }

        // 2. Seed counter row if missing (post-reinstall, DB cleanup, cache flush)
        $max_inflight = (int) \get_option("seo_gen_max_parallel_jobs", 3);

        $wpdb->query(
            "INSERT IGNORE INTO {$table} (option_name, option_value, autoload)
             VALUES ('seo_gen_inflight_generations', '0', 'no')"
        );

        // 3. Atomic Global Inflight Increment
        $claimed_global = (bool) $wpdb->query( $wpdb->prepare(
            "UPDATE {$table}
             SET option_value = CAST(option_value AS UNSIGNED) + 1
             WHERE option_name = 'seo_gen_inflight_generations'
             AND CAST(option_value AS UNSIGNED) < %d",
            $max_inflight
        ) );

        if ( ! $claimed_global ) {
            $wpdb->query( $wpdb->prepare(
                "DELETE FROM {$table} WHERE option_name = %s AND option_value = %s",
                $item_lock_key,
                $now
            ) );
            return false;
        }

        return true;
    }

    public function release_slot(string $software, string $version): void
    {
        global $wpdb;

        $item_lock_key = "seo_gen_lock_" . \md5($software . $version);
        $table         = $wpdb->prefix . "options";

        // Use raw SQL DELETE — claim_slot() wrote via raw INSERT, bypassing WP
        // object cache. delete_option() may silently no-op.
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE option_name = %s",
            $item_lock_key
        ) );
        \wp_cache_delete( $item_lock_key, 'options' );
        \wp_cache_delete( 'alloptions', 'options' );

        $wpdb->query(
            "UPDATE {$table}
             SET option_value = CAST(option_value AS UNSIGNED) - 1
             WHERE option_name = 'seo_gen_inflight_generations'
             AND CAST(option_value AS UNSIGNED) > 0"
        );
        \wp_cache_delete( 'seo_gen_inflight_generations', 'options' );
    }

    /**
     * [NEW] Parallel Scout Cap (Bug D)
     */
    public function can_proceed_scout(): bool
    {
        $max_scouts = (int) \get_option("seo_gen_max_parallel_scouts", 2);
        $current    = (int) \get_option("seo_gen_inflight_scouts", 0);

        return $current < $max_scouts;
    }

    public function claim_scout_slot(): bool
    {
        global $wpdb;
        $max_scouts = (int) \get_option("seo_gen_max_parallel_scouts", 2);
        $table = $wpdb->prefix . "options";

        return (bool) $wpdb->query($wpdb->prepare(
            "UPDATE {$table} 
             SET option_value = CAST(option_value AS UNSIGNED) + 1 
             WHERE option_name = 'seo_gen_inflight_scouts' 
             AND CAST(option_value AS UNSIGNED) < %d",
            $max_scouts
        ));
    }

    public function release_scout_slot(): void
    {
        global $wpdb;
        $table = $wpdb->prefix . "options";
        $wpdb->query(
            "UPDATE {$table} 
             SET option_value = CAST(option_value AS UNSIGNED) - 1 
             WHERE option_name = 'seo_gen_inflight_scouts' 
             AND CAST(option_value AS UNSIGNED) > 0"
        );
    }

    public function get_inflight_metrics(): array
    {
        return [
            "generations" => (int) \get_option("seo_gen_inflight_generations", 0),
            "scouts"      => (int) \get_option("seo_gen_inflight_scouts", 0),
            "max_gen"     => (int) \get_option("seo_gen_max_parallel_jobs", 3),
            "max_scout"   => (int) \get_option("seo_gen_max_parallel_scouts", 2),
        ];
    }

    /**
     * Self-healing: reconcile inflight counter against actual jobs table.
     * Call from dashboard reset or scheduled cleanup to recover from crash leaks.
     */
    public function reset_stale_counters(): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'options';

        $real_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . \SEO_Article_Generator\Installer::table_jobs() .
            " WHERE status IN ('processing','generating','validating')"
        );

        $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET option_value = %d
             WHERE option_name = 'seo_gen_inflight_generations'",
            $real_count
        ) );

        $stale_cutoff = (string) ( time() - 1800 );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE option_name LIKE 'seo\_gen\_lock\_%'
             AND CAST(option_value AS UNSIGNED) > 0
             AND CAST(option_value AS UNSIGNED) < %s",
            $stale_cutoff
        ) );

        \wp_cache_delete( 'seo_gen_inflight_generations', 'options' );
        \wp_cache_delete( 'alloptions', 'options' );
    }

    /**
     * Returns inflight metrics read directly from the database,
     * bypassing any object-cache layer. Use for preflight checks
     * where stale data could cause misleading UI responses.
     */
    public function get_inflight_metrics_uncached(): array {
        global $wpdb;

        $table = $wpdb->prefix . "options";

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value
                   FROM {$table}
                  WHERE option_name IN (%s, %s, %s, %s)",
                'seo_gen_inflight_generations',
                'seo_gen_inflight_scouts',
                'seo_gen_max_parallel_jobs',
                'seo_gen_max_parallel_scouts'
            ),
            ARRAY_A
        );

        $map = [];
        foreach ( (array) $rows as $row ) {
            $map[ (string) $row['option_name'] ] = (int) $row['option_value'];
        }

        return [
            'generations' => $map['seo_gen_inflight_generations']  ?? 0,
            'scouts'      => $map['seo_gen_inflight_scouts']        ?? 0,
            'max_gen'     => $map['seo_gen_max_parallel_jobs']      ?? 3,
            'max_scout'   => $map['seo_gen_max_parallel_scouts']    ?? 2,
        ];
    }
}
