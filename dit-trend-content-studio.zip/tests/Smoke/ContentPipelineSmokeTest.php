<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Smoke;

use PHPUnit\Framework\TestCase;
use DIT\TrendStudio\Content\ContentPipeline;
use DIT\TrendStudio\Content\PromptEngine;
use DIT\TrendStudio\Tests\Fakes\FakeContentCleaner;
use DIT\TrendStudio\Tests\Fakes\FakeLogger;
use DIT\TrendStudio\Tests\Fakes\FakeMediaPassthrough;
use DIT\TrendStudio\Tests\Fakes\FakeAIProvider;

final class ContentPipelineSmokeTest extends TestCase
{
    public function test_pipeline_restores_visual_tokens_and_normalizes_sections(): void
    {
        $logger = new FakeLogger();
        $cleaner = new FakeContentCleaner();
        $mediaPassthrough = new FakeMediaPassthrough();

        $aiProvider = new FakeAIProvider([
            'headline' => 'Summer Lawn Edit',
            'sections' => [
                [
                    'heading' => 'Introduction',
                    'bodyhtml' => '<p>First paragraph.</p><p>[VISUAL_0]</p><p>Second paragraph.</p>',
                ],
            ],
            '_generation_method' => 'test_method'
        ]);

        $promptEngine = new PromptEngine($aiProvider, $logger);

        $pipeline = new ContentPipeline(
            $promptEngine,
            $logger,
            $mediaPassthrough,
            $cleaner,
            function ($key, $default = null) {
                return $default;
            }
        );

        $input = [
            'vertical' => 'showbiz_pk',
            'idea_text' => '<p>Lead</p><img src="https://example.com/a.jpg" alt="Image A">',
        ];

        $result = $pipeline->generateContent($input);

        $this->assertSame('Summer Lawn Edit', $result['headline']);
        $this->assertCount(1, $result['sections']);

        // Assert token restoration
        $this->assertStringContainsString('https://example.com/a.jpg', $result['sections'][0]['body_html']);
        $this->assertStringContainsString('data-dit-visual="0"', $result['sections'][0]['body_html']);

        // Assert collaborator calls
        $this->assertCount(1, $cleaner->calls);
        $this->assertCount(1, $mediaPassthrough->calls);
    }
}
