#!/usr/bin/env python3
"""
DIT Video Module — Urdu TTS via Microsoft Edge (free neural voices).

Enhancements to make Edge-TTS sound more like a Pakistani vlogger (less robotic):
  - rate (+x%) for energetic/fast pacing
  - pitch boost (+Hz) for a brighter, more confident female voice
  - loudness normalization (loudnorm to -16 LUFS) for consistent professional audio
  - silence trimming at head/tail (natural starts/ends)
Uses edge-tts (ur-PK-UzmaNeural female / ur-PK-AsadNeural male).

Usage: python3 tts.py <textfile> <output.mp3> <voice> <speed> [lang]
  speed: 1.0 normal, 1.15 energetic (mapped to +15% rate)
"""
import asyncio, os, re, sys, subprocess, tempfile

VOICE = "ur-PK-UzmaNeural"
LANG  = "ur-PK"
PITCH = "+4Hz"   # brighten female voice

def get_ffmpeg():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"

def loudnorm_and_trim(src, dst):
    """Normalize to ~-16 LUFS and trim leading/trailing silence."""
    ff = get_ffmpeg()
    # trim silence (min 0.2s) then loudnorm
    cmd = [
        ff, "-y", "-i", src,
        "-af", "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.2:"
               "stop_periods=1:stop_threshold=-45dB:stop_silence=0.2,"
               "loudnorm=I=-16:TP=-1.5:LRA=11",
        "-ar", "44100", "-ac", "1", "-c:a", "libmp3lame", "-b:a", "128k",
        dst,
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        return True
    except Exception:
        return False

async def main():
    if len(sys.argv) < 4:
        sys.stderr.write("Usage: tts.py <textfile> <output.mp3> <voice> <speed> [lang]\n")
        sys.exit(1)
    textfile = sys.argv[1]
    out = sys.argv[2]
    voice = sys.argv[3] if len(sys.argv) > 3 else VOICE
    speed = float(sys.argv[4]) if len(sys.argv) > 4 else 1.15
    lang = sys.argv[5] if len(sys.argv) > 5 else LANG

    try:
        import edge_tts
    except ImportError:
        sys.stderr.write("edge-tts not installed. Run: pip install edge-tts\n")
        sys.exit(2)

    with open(textfile, encoding="utf-8") as f:
        text = f.read().strip()
    if not text:
        sys.stderr.write("empty text\n")
        sys.exit(3)

    rate_pct = int(round((speed - 1.0) * 100))
    rate = ("+%d%%" % rate_pct) if rate_pct >= 0 else ("%d%%" % rate_pct)

    tmp_raw = out + ".raw.mp3"
    communicate = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=PITCH, volume="+0%")
    await communicate.save(tmp_raw)

    # Post-process: loudness normalize + trim silence for a professional finish.
    if loudnorm_and_trim(tmp_raw, out):
        if os.path.exists(tmp_raw):
            os.remove(tmp_raw)
    else:
        # fallback: move raw
        if os.path.exists(tmp_raw):
            os.replace(tmp_raw, out)
    print("saved:", out, "voice:", voice, "rate:", rate, "pitch:", PITCH)

if __name__ == "__main__":
    asyncio.run(main())
