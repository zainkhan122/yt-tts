/* global jQuery, aiCollageData */
jQuery( document ).ready( function ( $ ) {

// ── Helper: Build Campaign Card HTML ──────────────────────────────────────

function buildCategoryOptions( selectedValue ) {
	selectedValue = parseInt( selectedValue, 10 ) || 0;
	var html = '<option value="0">-- Select --</option>';
	if ( aiCollageData.categories && aiCollageData.categories.length ) {
		$.each( aiCollageData.categories, function ( i, cat ) {
			var tid = parseInt( cat.term_id, 10 ) || 0;
			var sel = ( tid === selectedValue ) ? ' selected' : '';
			html += '<option value="' + tid + '"' + sel + '>'
			+ $( '<div>' ).text( cat.label ).html()
			+ '</option>';
		} );
	}
	return html;
}

function buildSelectOptions( items, selectedValue ) {
	var html = '';
	if ( items ) {
		$.each( items, function ( key, label ) {
			var sel = ( key === selectedValue ) ? ' selected' : '';
			html += '<option value="' + $( '<div>' ).text( key ).html() + '"' + sel + '>'
				+ $( '<div>' ).text( label ).html()
				+ '</option>';
		} );
	}
	return html;
}

// @MODIFIED: Grouped template dropdown with optgroup + language tag [EN]/[UR]
	function buildGroupedTemplateOptions( selectedValue ) {
		var html = '<option value="auto"' + ( selectedValue === 'auto' ? ' selected' : '' ) + '>Auto \u2014 AI Selects Best Template</option>';
	var categoryLabels = {
		'entertainment':   '\uD83C\uDFAC Entertainment (EN)',
		'tech':            '\uD83D\uDD27 Tech (EN)',
		'celebrity-urdu':  '\u2B50 Celebrity Gossip (UR)',
		'controversy-urdu':'\uD83D\uDD25 Viral Controversy (UR)',
		'film-action':     '\uD83C\uDFAC Film Teaser (EN)',
		'emotional-urdu':  '\uD83D\uDC94 Emotional (UR)',
		'breaking-urdu':   '\uD83D\uDEA8 Breaking (UR)',
		'news':            '\uD83D\uDCF0 News',
		'modern':          '\uD83C\uDFA8 Modern',
		'impact':          '\uD83D\uDCA5 Impact'
	};
	if ( aiCollageData.template_categories ) {
		$.each( aiCollageData.template_categories, function ( catKey, templateKeys ) {
			var groupLabel = categoryLabels[ catKey ] || $( '<div>' ).text( catKey ).html();
			html += '<optgroup label="' + groupLabel + '">';
			$.each( templateKeys, function ( i, tKey ) {
				var tLabel = aiCollageData.templates[ tKey ] || tKey;
				var lang = ( aiCollageData.template_languages && aiCollageData.template_languages[ tKey ] )
					? aiCollageData.template_languages[ tKey ].toUpperCase()
					: 'EN';
				var sel = ( tKey === selectedValue ) ? ' selected' : '';
				html += '<option value="' + $( '<div>' ).text( tKey ).html() + '"' + sel + '>'
					+ $( '<div>' ).text( tLabel ).html() + ' [' + lang + ']'
					+ '</option>';
			} );
			html += '</optgroup>';
		} );
	}
	return html;
}

	function buildPlatformSizeOptions( selectedValue ) {
		var html = '';
		if ( aiCollageData.platform_sizes ) {
			$.each( aiCollageData.platform_sizes, function ( key, info ) {
				var sel = ( key === selectedValue ) ? ' selected' : '';
				html += '<option value="' + $( '<div>' ).text( key ).html() + '"' + sel + '>'
					+ $( '<div>' ).text( info.label ).html()
					+ '</option>';
			} );
		}
		return html;
	}

	function buildCampaignCard( id ) {
		var defaultTemplate = 'news-card';
		var defaultSize = 'instagram-portrait';

		return (
			'<div class="campaign-card" data-id="' + id + '">' +
			'<div class="campaign-grid">' +

			'<div class="grid-col">' +
			'<label>Campaign Name</label>' +
			'<input type="text" name="name" value="" class="campaign-name">' +
			'<label>Source Category (Slug)</label>' +
			'<input type="text" name="source_category" value="" placeholder="e.g. showbiz">' +
			'<label>Tags</label>' +
			'<input type="text" name="tags" value="" placeholder="e.g. fashion, trends">' +
			'</div>' +

			'<div class="grid-col">' +
			'<label>Target Vertical</label>' +
			'<select name="target_vertical">' +
			buildSelectOptions( aiCollageData.verticals, '' ) +
			'</select>' +
			'<label>Destination Category</label>' +
			'<select name="destination_category">' + buildCategoryOptions( 0 ) + '</select>' +
			'</div>' +

			'<div class="grid-col">' +
			'<label>Frequency</label>' +
			'<select name="frequency">' +
			(function() {
				var fhtml = '';
				if ( aiCollageData.frequencies ) {
					$.each( aiCollageData.frequencies, function ( i, f ) {
						fhtml += '<option value="' + $( '<div>' ).text( f ).html() + '"' + ( f === 'Every Hour' ? ' selected' : '' ) + '>' + $( '<div>' ).text( f ).html() + '</option>';
				} );
				}
				return fhtml;
			})() +
			'</select>' +
			'<label>Publish Status</label>' +
			'<select name="publish_status">' +
			buildSelectOptions( aiCollageData.publish_statuses, 'draft' ) +
			'</select>' +
			'<label>AI Strategy</label>' +
		'<select name="ai_strategy">' +
		buildSelectOptions( aiCollageData.strategies, 'Gemini Only' ) +
		'</select>' +
		'<label>Output Language</label>' +
		'<select name="output_language">' +
		'<option value="auto">Auto — Detect from Source</option>' +
		'<option value="en">English</option>' +
		'<option value="ur">Urdu (اردو)</option>' +
		'</select>' +
	// @MODIFIED: Grouped template dropdown with optgroup
		'<label>Template</label>' +
		'<select name="template">' +
		buildGroupedTemplateOptions( defaultTemplate ) +
		'</select>' +
		'<div class="content-type-section" style="margin-top:15px;padding-top:15px;border-top:1px solid #ddd;">' +
		'<label>Content Type</label>' +
		'<select name="content_type">' +
		'<option value="auto">Auto (detect from post)</option>' +
		'<option value="image">Image Only (force collage)</option>' +
		'<option value="video">Video Only (force video pipeline)</option>' +
		'</select>' +
		'<p style="font-size:12px;color:#666;margin-top:4px;">Select "Image Only" to prevent video detection for this campaign.</p>' +
		'</div>' +
      // @MODIFIED: Headline font dropdown for Urdu Nastaliq auto-switch
      '<label>Headline Font</label>' +
      '<select name="headline_font">' +
      buildSelectOptions( aiCollageData.fonts, '' ) +
      '</select>' +
      '<div class="brand-override-toggle">' +
      '<label><input type="checkbox" name="brand_override_enabled" value="1"> Override Brand Settings</label>' +
      '</div>' +
      '<div class="brand-override-section" style="display:none;">' +
      '<label>Primary / Key Term Color</label>' +
      '<input type="color" name="primary_color" value="#00C853">' +
      '<label>Secondary / Text Color</label>' +
      '<input type="color" name="secondary_color" value="#ffffff">' +
      '<label>Accent / Alert Color</label>' +
      '<input type="color" name="accent_color" value="#FF1744">' +
      '<label>Emphasis Color (Yellow)</label>' +
      '<input type="color" name="emphasis_color" value="#FFD700">' +
      '<label>Key Term Color (Green)</label>' +
      '<input type="color" name="key_term_color" value="#00C853">' +
      '<label>Breaking/Alert Color (Red)</label>' +
      '<input type="color" name="breaking_color" value="#FF1744">' +
      '<label>Text Backing Color (Dark)</label>' +
      '<input type="color" name="text_backing_color" value="#000000">' +
      '<label>Logo Position</label>' +
      '<select name="logo_position">' +
      '<option value="top-right">Top Right</option>' +
      '<option value="top-left">Top Left</option>' +
      '<option value="bottom-left">Bottom Left</option>' +
      '<option value="bottom-right">Bottom Right</option>' +
      '</select>' +
      '<label>Body Font</label>' +
      '<select name="font_body">' +
      buildSelectOptions( aiCollageData.fonts, '' ) +
      '</select>' +
      '</div>' +
      '<div class="image-extraction-section">' +
      '<label><input type="checkbox" name="image_extraction_enabled" value="1"> Extract &amp; Clean Source Image</label>' +
      '<div class="image-extraction-options" style="display:none;">' +
      '<label>Detection Mode</label>' +
      '<select name="detection_mode">' +
      '<option value="hybrid">Hybrid (auto-detect, fallback to manual)</option>' +
      '<option value="auto">Auto-detect only</option>' +
      '<option value="manual">Manual zones</option>' +
      '</select>' +
      '<div class="manual-zone-config" style="display:none;">' +
      '<label>Logo Zone (X%, Y%, W%, H%)</label>' +
      '<div class="zone-row">' +
      '<input type="number" step="0.01" min="0" max="1" name="logo_zone_x" value="0" placeholder="X" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="logo_zone_y" value="0" placeholder="Y" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="logo_zone_w" value="0.08" placeholder="W" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="logo_zone_h" value="0.05" placeholder="H" style="width:60px;">' +
      '</div>' +
      '<label>Text Zone (X%, Y%, W%, H%)</label>' +
      '<div class="zone-row">' +
      '<input type="number" step="0.01" min="0" max="1" name="text_zone_x" value="0" placeholder="X" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="text_zone_y" value="0.60" placeholder="Y" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="text_zone_w" value="1.0" placeholder="W" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="text_zone_h" value="0.40" placeholder="H" style="width:60px;">' +
      '</div>' +
      '<label>Image Zone (X%, Y%, W%, H%)</label>' +
      '<div class="zone-row">' +
      '<input type="number" step="0.01" min="0" max="1" name="image_zone_x" value="0" placeholder="X" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="image_zone_y" value="0" placeholder="Y" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="image_zone_w" value="1.0" placeholder="W" style="width:60px;">' +
      '<input type="number" step="0.01" min="0" max="1" name="image_zone_h" value="0.60" placeholder="H" style="width:60px;">' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div class="video-zone-section" style="margin-top:12px; padding:10px; border:1px solid #c3c4c7; border-radius:4px; background:#f9f9f9;">' +
      '<label><input type="checkbox" name="video_zone_enabled" value="1"> Configure Video Processing Zones</label>' +
      '<div class="video-zone-options" style="display:none;">' +
      '<label>Video Zone Mode</label>' +
      '<select name="video_zone_mode">' +
      '<option value="auto">Auto (AI Detection)</option>' +
      '<option value="manual">Manual Zones</option>' +
      '</select>' +
      '<p class="description">"Auto" detects content area via AI. "Manual" uses your crop settings below.</p>' +
      '<div class="manual-video-zone-config" style="display:none;">' +
      '<label>Video Crop — how much to trim from each side</label>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;">' +
      '<div style="text-align:center;">' +
      '<label style="font-size:11px;font-weight:600;">Top</label>' +
      '<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_top" value="0" class="video-zone-crop-input" style="width:60px;">' +
      '<div style="font-size:10px;color:#666;">e.g. 0.12</div>' +
      '</div>' +
      '<div style="text-align:center;">' +
      '<label style="font-size:11px;font-weight:600;">Right</label>' +
      '<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_right" value="0" class="video-zone-crop-input" style="width:60px;">' +
      '<div style="font-size:10px;color:#666;">e.g. 0.04</div>' +
      '</div>' +
      '<div style="text-align:center;">' +
      '<label style="font-size:11px;font-weight:600;">Bottom</label>' +
      '<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_bottom" value="0" class="video-zone-crop-input" style="width:60px;">' +
      '<div style="font-size:10px;color:#666;">e.g. 0.04</div>' +
      '</div>' +
      '<div style="text-align:center;">' +
      '<label style="font-size:11px;font-weight:600;">Left</label>' +
      '<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_left" value="0" class="video-zone-crop-input" style="width:60px;">' +
      '<div style="font-size:10px;color:#666;">e.g. 0.04</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      // @MODIFIED: Aspect ratio visual indicator next to platform size
		'<label>Platform Size</label>' +
		'<div class="platform-size-row">' +
		'<select name="platform_size">' +
		buildPlatformSizeOptions( defaultSize ) +
		'</select>' +
		'<div class="aspect-ratio-indicator" title="Aspect ratio preview"></div>' +
		'</div>' +
			'</div>' +

	'<div class="grid-col status-col">' +
	'<label>Status</label>' +
	'<div class="status-box">' +
	'<span class="dashicons dashicons-clock"></span>' +
	'<span>Managed by Cron</span>' +
	'</div>' +
	'<label><input type="checkbox" name="active" value="1" checked> Active</label>' +
	'<button type="button" class="button stop-campaign-btn" data-id="' + id + '">Stop</button>' +
	'<input type="hidden" name="stopped" value="0">' +
	'</div>' +

	'<div class="grid-col actions-col">' +
			'<button type="button" class="button button-primary run-btn" data-id="' + id + '">Run</button>' +
			'<button type="button" class="button button-link delete-btn" data-id="' + id + '">Remove</button>' +
			'</div>' +

			'</div>' +
			'</div>'
		);
	}

	// ── Campaigns Page ────────────────────────────────────────────────────────

	$( '#add-campaign' ).on( 'click', function () {
		var id = 'new_' + Date.now().toString();
		$( '#campaigns-list' ).append( buildCampaignCard( id ) );
	} );

	$( document ).on( 'click', '.delete-btn', function () {
		var id = $( this ).data( 'id' );
		if ( confirm( 'Remove this campaign?' ) ) {
			$( '.campaign-card[data-id="' + id + '"]' ).remove();
		}
	} );

	$( document ).on( 'click', '.run-btn', function () {
	var $btn = $( this );
	var campaignId = $btn.data( 'id' );

	if ( ! campaignId || String( campaignId ).indexOf( 'new_' ) === 0 ) {
		alert( 'Save the campaign configuration first before running it manually.' );
		return;
	}

	$btn.prop( 'disabled', true ).text( 'Running…' );

	$.ajax( {
		url: aiCollageData.ajax_url,
		type: 'POST',
		data: {
		action: 'ai_collage_run_campaign',
		nonce: aiCollageData.nonce,
		campaign_id: campaignId,
		},
		success: function ( response ) {
		if ( response.success ) {
			alert( 'Success: ' + response.data.message );
		} else {
			alert( 'Error: ' + response.data );
		}
		},
		error: function () {
		alert( 'AJAX error — could not contact the server.' );
		},
		complete: function () {
		$btn.prop( 'disabled', false ).text( 'Run' );
		},
	} );
	} );

	$( document ).on( 'click', '.stop-campaign-btn', function () {
	var $btn = $( this );
	var campaignId = $btn.data( 'id' );

	if ( ! campaignId || String( campaignId ).indexOf( 'new_' ) === 0 ) {
		alert( 'Save the campaign configuration first.' );
		return;
	}

	if ( ! confirm( 'Stop this campaign? It will be deactivated and won\'t run until resumed.' ) ) { return; }

	$btn.prop( 'disabled', true ).text( 'Stopping…' );

	$.ajax( {
		url: aiCollageData.ajax_url,
		type: 'POST',
		data: {
		action: 'ai_collage_stop_campaign',
		nonce: aiCollageData.nonce,
		campaign_id: campaignId,
		},
		success: function ( response ) {
		if ( response.success ) {
			alert( 'Campaign stopped.' );
			location.reload();
		} else {
			alert( 'Error: ' + response.data );
		}
		},
		error: function () {
		alert( 'AJAX error — could not contact the server.' );
		},
		complete: function () {
		$btn.prop( 'disabled', false ).text( 'Stop' );
		},
	} );
	} );

	$( document ).on( 'click', '.start-campaign-btn', function () {
	var $btn = $( this );
	var campaignId = $btn.data( 'id' );

	if ( ! campaignId ) { return; }

	$btn.prop( 'disabled', true ).text( 'Resuming…' );

	var $card = $btn.closest( '.campaign-card' );
	$card.find( '[name="active"]' ).prop( 'checked', true );
	$card.find( '[name="stopped"]' ).val( '0' );

	$.ajax( {
		url: aiCollageData.ajax_url,
		type: 'POST',
		data: {
		action: 'ai_collage_save_campaigns',
		nonce: aiCollageData.nonce,
		campaigns: (function() {
			var campaigns = [];
			$( '.campaign-card' ).each( function () {
			var $c = $( this );
			campaigns.push( {
				id: String( $c.data( 'id' ) ),
				name: $c.find( '[name="name"]' ).val(),
				source_category: $c.find( '[name="source_category"]' ).val(),
				tags: $c.find( '[name="tags"]' ).val(),
				target_vertical: $c.find( '[name="target_vertical"]' ).val(),
				destination_category: parseInt( $c.find( '[name="destination_category"]' ).val(), 10 ) || 0,
				frequency: $c.find( '[name="frequency"]' ).val(),
				publish_status: $c.find( '[name="publish_status"]' ).val(),
				ai_strategy: $c.find( '[name="ai_strategy"]' ).val(),
				template: $c.find( '[name="template"]' ).val(),
				output_language: $c.find( '[name="output_language"]' ).val() || 'auto',
				headline_font: $c.find( '[name="headline_font"]' ).val(),
				platform_size: $c.find( '[name="platform_size"]' ).val(),
				active: $c.find( '[name="active"]' ).is( ':checked' ) ? 1 : 0,
				last_run: 0,
				brand_override_enabled: $c.find( '[name="brand_override_enabled"]' ).is( ':checked' ) ? 1 : 0,
				primary_color: $c.find( '[name="primary_color"]' ).val() || '',
				secondary_color: $c.find( '[name="secondary_color"]' ).val() || '',
				accent_color: $c.find( '[name="accent_color"]' ).val() || '',
				emphasis_color: $c.find( '[name="emphasis_color"]' ).val() || '',
				key_term_color: $c.find( '[name="key_term_color"]' ).val() || '',
				breaking_color: $c.find( '[name="breaking_color"]' ).val() || '',
				text_backing_color: $c.find( '[name="text_backing_color"]' ).val() || '',
				logo_position: $c.find( '[name="logo_position"]' ).val() || '',
				font_body: $c.find( '[name="font_body"]' ).val() || '',
				stopped: 0,
				image_extraction_enabled: $c.find( '[name="image_extraction_enabled"]' ).is( ':checked' ) ? 1 : 0,
				detection_mode: $c.find( '[name="detection_mode"]' ).val() || 'hybrid',
				content_type: $c.find( '[name="content_type"]' ).val() || 'auto',
				logo_zone: {
					x: parseFloat( $c.find( '[name="logo_zone_x"]' ).val() ) || 0.0,
					y: parseFloat( $c.find( '[name="logo_zone_y"]' ).val() ) || 0.0,
					w: parseFloat( $c.find( '[name="logo_zone_w"]' ).val() ) || 0.08,
					h: parseFloat( $c.find( '[name="logo_zone_h"]' ).val() ) || 0.05,
				},
				text_zone: {
					x: parseFloat( $c.find( '[name="text_zone_x"]' ).val() ) || 0.0,
					y: parseFloat( $c.find( '[name="text_zone_y"]' ).val() ) || 0.60,
					w: parseFloat( $c.find( '[name="text_zone_w"]' ).val() ) || 1.0,
					h: parseFloat( $c.find( '[name="text_zone_h"]' ).val() ) || 0.40,
				},
				image_zone: {
					x: parseFloat( $c.find( '[name="image_zone_x"]' ).val() ) || 0.0,
					y: parseFloat( $c.find( '[name="image_zone_y"]' ).val() ) || 0.0,
					w: parseFloat( $c.find( '[name="image_zone_w"]' ).val() ) || 1.0,
					h: parseFloat( $c.find( '[name="image_zone_h"]' ).val() ) || 0.60,
				},
				video_zone_enabled: $c.find( '[name="video_zone_enabled"]' ).is( ':checked' ) ? 1 : 0,
				video_zone_mode: $c.find( '[name="video_zone_mode"]' ).val() || 'auto',
				video_content_zone: (function() {
					var t = parseFloat( $c.find( '[name="video_content_zone_top"]' ).val() ) || 0,
						r = parseFloat( $c.find( '[name="video_content_zone_right"]' ).val() ) || 0,
						b = parseFloat( $c.find( '[name="video_content_zone_bottom"]' ).val() ) || 0,
						l = parseFloat( $c.find( '[name="video_content_zone_left"]' ).val() ) || 0;
					if ( l + r >= 1 ) { l = 0; r = 0; }
					if ( t + b >= 1 ) { t = 0; b = 0; }
					return { x: l, y: t, w: Math.max( 0.01, 1 - l - r ), h: Math.max( 0.01, 1 - t - b ) };
				})(),
			} );
			} );
			return campaigns;
		})(),
		},
		success: function ( response ) {
		if ( response.success ) {
			alert( 'Campaign resumed.' );
			location.reload();
		} else {
			alert( 'Error: ' + JSON.stringify( response.data ) );
		}
		},
		error: function () {
		alert( 'AJAX error — could not contact the server.' );
		},
		complete: function () {
		$btn.prop( 'disabled', false ).text( 'Resume' );
		},
	} );
	} );

	// ── Campaigns Page: Save All ────────────────────────────────────────────

	$( '#save-campaigns' ).on( 'click', function () {
		var $btn = $( this );
		var campaigns = [];

		$( '.campaign-card' ).each( function () {
			var $card = $( this );
			var cardId = $card.data( 'id' );
			if ( ! cardId ) { return; }
			campaigns.push( {
				id: String( cardId ),
				name: $card.find( '[name="name"]' ).val(),
				source_category: $card.find( '[name="source_category"]' ).val(),
				tags: $card.find( '[name="tags"]' ).val(),
				target_vertical: $card.find( '[name="target_vertical"]' ).val(),
				destination_category: parseInt( $card.find( '[name="destination_category"]' ).val(), 10 ) || 0,
				frequency: $card.find( '[name="frequency"]' ).val(),
				publish_status: $card.find( '[name="publish_status"]' ).val(),
				ai_strategy: $card.find( '[name="ai_strategy"]' ).val(),
				template: $card.find( '[name="template"]' ).val(),
				output_language: $card.find( '[name="output_language"]' ).val() || 'auto',
				headline_font: $card.find( '[name="headline_font"]' ).val(),
				platform_size: $card.find( '[name="platform_size"]' ).val(),
				active: $card.find( '[name="active"]' ).is( ':checked' ) ? 1 : 0,
				last_run: 0,
				brand_override_enabled: $card.find( '[name="brand_override_enabled"]' ).is( ':checked' ) ? 1 : 0,
				primary_color: $card.find( '[name="primary_color"]' ).val() || '',
				secondary_color: $card.find( '[name="secondary_color"]' ).val() || '',
				accent_color: $card.find( '[name="accent_color"]' ).val() || '',
				emphasis_color: $card.find( '[name="emphasis_color"]' ).val() || '',
				key_term_color: $card.find( '[name="key_term_color"]' ).val() || '',
				breaking_color: $card.find( '[name="breaking_color"]' ).val() || '',
				text_backing_color: $card.find( '[name="text_backing_color"]' ).val() || '',
				logo_position: $card.find( '[name="logo_position"]' ).val() || '',
			font_body: $card.find( '[name="font_body"]' ).val() || '',
			stopped: $card.find( '[name="stopped"]' ).val() === '1' ? 1 : 0,
			image_extraction_enabled: $card.find( '[name="image_extraction_enabled"]' ).is( ':checked' ) ? 1 : 0,
			detection_mode: $card.find( '[name="detection_mode"]' ).val() || 'hybrid',
			content_type: $card.find( '[name="content_type"]' ).val() || 'auto',
			logo_zone: {
				x: parseFloat( $card.find( '[name="logo_zone_x"]' ).val() ) || 0.0,
				y: parseFloat( $card.find( '[name="logo_zone_y"]' ).val() ) || 0.0,
				w: parseFloat( $card.find( '[name="logo_zone_w"]' ).val() ) || 0.08,
				h: parseFloat( $card.find( '[name="logo_zone_h"]' ).val() ) || 0.05,
			},
			text_zone: {
				x: parseFloat( $card.find( '[name="text_zone_x"]' ).val() ) || 0.0,
				y: parseFloat( $card.find( '[name="text_zone_y"]' ).val() ) || 0.60,
				w: parseFloat( $card.find( '[name="text_zone_w"]' ).val() ) || 1.0,
				h: parseFloat( $card.find( '[name="text_zone_h"]' ).val() ) || 0.40,
			},
			image_zone: {
				x: parseFloat( $card.find( '[name="image_zone_x"]' ).val() ) || 0.0,
				y: parseFloat( $card.find( '[name="image_zone_y"]' ).val() ) || 0.0,
				w: parseFloat( $card.find( '[name="image_zone_w"]' ).val() ) || 1.0,
				h: parseFloat( $card.find( '[name="image_zone_h"]' ).val() ) || 0.60,
			},
			video_zone_enabled: $card.find( '[name="video_zone_enabled"]' ).is( ':checked' ) ? 1 : 0,
			video_zone_mode: $card.find( '[name="video_zone_mode"]' ).val() || 'auto',
			video_content_zone: (function() {
				var t = parseFloat( $card.find( '[name="video_content_zone_top"]' ).val() ) || 0,
					r = parseFloat( $card.find( '[name="video_content_zone_right"]' ).val() ) || 0,
					b = parseFloat( $card.find( '[name="video_content_zone_bottom"]' ).val() ) || 0,
					l = parseFloat( $card.find( '[name="video_content_zone_left"]' ).val() ) || 0;
				if ( l + r >= 1 ) { l = 0; r = 0; }
				if ( t + b >= 1 ) { t = 0; b = 0; }
				return { x: l, y: t, w: Math.max( 0.01, 1 - l - r ), h: Math.max( 0.01, 1 - t - b ) };
			})(),
		} );
		} );

		$btn.prop( 'disabled', true ).text( 'Saving…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_save_campaigns',
				nonce: aiCollageData.nonce,
				campaigns: campaigns,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'Campaigns saved successfully.' );
					location.reload();
				} else {
					alert( 'Error saving campaigns: ' + JSON.stringify( response.data ) );
				}
			},
			error: function () {
				alert( 'AJAX error — could not save campaigns.' );
			},
			complete: function () {
				$btn.prop( 'disabled', false ).text( 'Save All Configurations' );
			},
		} );
	} );

	// ── Campaign: Auto-switch Nastaliq font for Urdu templates ────────────

// ── Campaign: Template Preview ─────────────────────────────────────────

function updateTemplatePreview( $templateSelect ) {
var $card = $templateSelect.closest( '.campaign-card' );
var $previewContainer = $card.find( '.template-preview-container' );
var $previewImage = $previewContainer.find( '.template-preview-image' );
var $previewPlaceholder = $previewContainer.find( '.template-preview-placeholder' );
var selectedTemplate = $templateSelect.val();
if ( ! selectedTemplate || selectedTemplate === 'auto' ) {
$previewImage.hide();
$previewPlaceholder.show().text( 'Select a template to preview' );
return;
}
var previewUrl = '';
if ( aiCollageData.template_previews && aiCollageData.template_previews[ selectedTemplate ] ) {
previewUrl = aiCollageData.template_previews[ selectedTemplate ];
}
if ( previewUrl ) {
var $img = $previewImage.find( 'img' );
if ( $img.length === 0 ) {
$previewImage.html( '<img src="" alt="Template Preview" />' );
$img = $previewImage.find( 'img' );
}
$img.attr( 'src', previewUrl ).attr( 'alt', selectedTemplate );
$previewImage.show();
$previewPlaceholder.hide();
} else {
$previewImage.hide();
$previewPlaceholder.show().text( 'No preview available' );
}
}

$( document ).on( 'change', '[name="template"]', function () {
var selectedTemplate = $( this ).val();
updateTemplatePreview( $( this ) );
if ( selectedTemplate && selectedTemplate.indexOf( 'urdu' ) !== -1 ) {
var $card = $( this ).closest( '.campaign-card' );
var $fontSelect = $card.find( '[name="headline_font"]' );
if ( $fontSelect.length && $fontSelect.val() !== 'Noto Nastaliq Urdu' ) {
if ( confirm( 'This is an Urdu template. Switch headline font to Noto Nastaliq Urdu?' ) ) {
$fontSelect.val( 'Noto Nastaliq Urdu' ).trigger( 'change' );
}
}
}
} );

$( document ).on( 'click', '.template-preview-image', function () {
var $img = $( this ).find( 'img' );
if ( $img.length && $img.attr( 'src' ) ) {
window.open( $img.attr( 'src' ), '_blank' );
}
} );

	// ── Campaign: Update aspect ratio indicator on platform size change ────

	function updateAspectRatioIndicator( $sizeSelect ) {
		var $card = $sizeSelect.closest( '.campaign-card' );
		var $indicator = $card.find( '.aspect-ratio-indicator' );
		if ( ! $indicator.length ) { return; }
		var sizeKey = $sizeSelect.val();
		var info = ( aiCollageData.platform_sizes && aiCollageData.platform_sizes[ sizeKey ] )
			? aiCollageData.platform_sizes[ sizeKey ] : null;
		if ( ! info || ! info.width || ! info.height ) {
			$indicator.css( { height: '30px', border: '1px solid #c3c4c7' } )
				.attr( 'title', 'Unknown ratio' );
			return;
		}
		var w = parseInt( info.width, 10 );
		var h = parseInt( info.height, 10 );
		var indicatorWidth = 30;
		var indicatorHeight = Math.round( ( h / w ) * indicatorWidth );
		if ( indicatorHeight > 60 ) { indicatorHeight = 60; }
		$indicator.css( {
			width: indicatorWidth + 'px',
			height: indicatorHeight + 'px'
		} ).attr( 'title', w + '×' + h );
	}

	$( document ).on( 'change', '[name="platform_size"]', function () {
		updateAspectRatioIndicator( $( this ) );
	} );

	$( '.campaign-card [name="platform_size"]' ).each( function () {
		updateAspectRatioIndicator( $( this ) );
	} );

	function buildWebSearchTypeOptions( selectedValue ) {
		var html = '';
		if ( aiCollageData.web_search_types ) {
			$.each( aiCollageData.web_search_types, function ( key, label ) {
				var sel = ( key === selectedValue ) ? ' selected' : '';
				html += '<option value="' + $( '<div>' ).text( key ).html() + '"' + sel + '>'
					+ $( '<div>' ).text( label ).html()
					+ '</option>';
			} );
		}
		return html;
	}

	function buildCustomProviderCard( id ) {
		var modelsHtml = '';
		modelsHtml += '<div class="cp-model-row">';
		modelsHtml += '<input type="text" name="cp_model_display" value="" class="cp-model-display regular-text" placeholder="Display name">';
		modelsHtml += '<input type="text" name="cp_model_id" value="" class="cp-model-id regular-text" placeholder="Model ID">';
		modelsHtml += '<button type="button" class="button button-small cp-remove-model">&times;</button>';
		modelsHtml += '</div>';

		return (
			'<div class="campaign-card custom-provider-card" data-id="' + id + '">' +
			'<div class="campaign-grid">' +
			'<div class="grid-col">' +
			'<label>Provider Name</label>' +
			'<input type="text" name="cp_name" value="" class="cp-name regular-text" placeholder="e.g. ZYDI vLLM">' +
			'<label>Provider ID (auto-generated)</label>' +
			'<input type="text" value="' + id + '" class="regular-text" readonly onclick="this.select();">' +
			'<label>API URL</label>' +
			'<input type="url" name="cp_api_url" value="" class="cp-api-url regular-text" placeholder="https://api.zydit.in/v1">' +
			'<label>API Key</label>' +
			'<input type="password" name="cp_api_key" value="" class="cp-api-key regular-text">' +
			'</div>' +
			'<div class="grid-col">' +
			'<label>Web Search</label>' +
			'<label><input type="checkbox" name="cp_enable_web_search" value="1" class="cp-enable-web-search"> Enable</label>' +
			'<label>Web Search Type</label>' +
			'<select name="cp_web_search_type" class="cp-web-search-type">' +
			buildWebSearchTypeOptions( 'none' ) +
			'</select>' +
			'<label>Model Fallback</label>' +
			'<label><input type="checkbox" name="cp_fallback_enabled" value="1" class="cp-fallback-enabled"> Enable fallback across models</label>' +
			'<label>Models</label>' +
			'<div class="cp-models-list">' + modelsHtml + '</div>' +
			'<button type="button" class="button button-small cp-add-model" style="margin-top:4px;">+ Add Model</button>' +
			'</div>' +
			'<div class="grid-col actions-col" style="justify-content:flex-start;align-items:flex-start;padding-top:24px;">' +
			'<button type="button" class="button button-secondary cp-test-connection" data-id="' + id + '">Test Connection</button>' +
			'<button type="button" class="button button-link-delete cp-remove-provider" data-id="' + id + '" style="margin-top:8px;">Remove Provider</button>' +
			'</div>' +
			'</div>' +
			'</div>'
		);
	}

	function collectCustomProviders() {
		var providers = [];
		$( '.custom-provider-card' ).each( function () {
			var $card = $( this );
			var cardId = $card.data( 'id' );
			if ( ! cardId ) { return; }
			var models = [];
			$card.find( '.cp-models-list .cp-model-row' ).each( function () {
				var $row = $( this );
				var display = $row.find( '.cp-model-display' ).val();
				var modelId = $row.find( '.cp-model-id' ).val();
				if ( modelId ) {
					models.push( { display_name: display || modelId, model_id: modelId } );
				}
			} );
			providers.push( {
				id: String( cardId ),
				name: $card.find( '.cp-name' ).val(),
				api_url: $card.find( '.cp-api-url' ).val(),
				api_key: $card.find( '.cp-api-key' ).val(),
				enable_web_search: $card.find( '.cp-enable-web-search' ).is( ':checked' ) ? 1 : 0,
				web_search_config: { type: $card.find( '.cp-web-search-type' ).val() || 'none' },
				models: models,
				fallback_enabled: $card.find( '.cp-fallback-enabled' ).is( ':checked' ) ? 1 : 0,
			} );
		} );
		return providers;
	}

	function syncCustomProvidersToJson() {
		var providers = collectCustomProviders();
		$( '#seo_gen_custom_providers_json' ).val( JSON.stringify( providers ) );
	}

	$( '#sgd-add-custom-provider' ).on( 'click', function () {
		var timestamp = Date.now().toString();
		var random = Math.random().toString( 36 ).substring( 2, 7 );
		var id = 'custom_' + timestamp + '_' + random;
		$( '#sgd-custom-providers-list' ).append( buildCustomProviderCard( id ) );
		$( '#sgd-custom-providers-list .custom-provider-empty' ).remove();
	} );

	$( document ).on( 'click', '.cp-remove-provider', function () {
		var id = $( this ).data( 'id' );
		if ( confirm( 'Remove this custom provider?' ) ) {
			$( '.custom-provider-card[data-id="' + id + '"]' ).remove();
		}
	} );

	$( document ).on( 'click', '.cp-add-model', function () {
		var $list = $( this ).closest( '.grid-col' ).find( '.cp-models-list' );
		var html = '<div class="cp-model-row">';
		html += '<input type="text" name="cp_model_display" value="" class="cp-model-display regular-text" placeholder="Display name">';
		html += '<input type="text" name="cp_model_id" value="" class="cp-model-id regular-text" placeholder="Model ID">';
		html += '<button type="button" class="button button-small cp-remove-model" title="Remove model">&times;</button>';
		html += '</div>';
		$list.append( html );
	} );

	$( document ).on( 'click', '.cp-remove-model', function () {
		$( this ).closest( '.cp-model-row' ).remove();
	} );

	$( document ).on( 'click', '.cp-test-connection', function () {
		var $btn = $( this );
		var providerId = $btn.data( 'id' );
		var $card = $btn.closest( '.custom-provider-card' );

		var apiUrl = $card.find( '.cp-api-url' ).val();
		var apiKey = $card.find( '.cp-api-key' ).val();
		var modelId = $card.find( '.cp-model-id' ).first().val();

		if ( ! apiUrl || ! apiKey || ! modelId ) {
			alert( 'Please fill in API URL, API Key, and at least one model before testing.' );
			return;
		}

		syncCustomProvidersToJson();
		var providersJson = $( '#seo_gen_custom_providers_json' ).val();

		$btn.prop( 'disabled', true ).text( 'Testing…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_test_custom_provider',
				nonce: aiCollageData.nonce,
				provider_id: providerId,
				providers_json: providersJson,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'Connection successful: ' + ( response.data.message || 'OK' ) );
				} else {
					alert( 'Connection failed: ' + response.data );
				}
			},
			error: function () {
				alert( 'AJAX error — could not test the connection.' );
			},
			complete: function () {
				$btn.prop( 'disabled', false ).text( 'Test Connection' );
			},
		} );
	} );

	// ── OpenRouter Free Model Sync ──────────────────────────────────────────

	$( document ).on( 'click', '.openrouter-sync-btn', function ( e ) {
		e.preventDefault();
		e.stopImmediatePropagation();

		var $btn = $( this );
		var $card = $btn.closest( '.custom-provider-card' );
		var $status = $card.find( '.openrouter-sync-status' );
		var $text = $status.find( '.openrouter-sync-text' );

		if ( ! confirm( 'Sync free models from OpenRouter? This will add new free models and remove expired ones.' ) ) {
			return;
		}

		$btn.prop( 'disabled', true ).text( 'Syncing…' );
		$text.text( 'Syncing models…' );
		$status.removeClass( 'sync-ok sync-warn' ).addClass( 'sync-warn' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_sync_openrouter_models',
				nonce: aiCollageData.nonce,
			},
			success: function ( response ) {
				if ( response.success ) {
					$status.removeClass( 'sync-warn' ).addClass( 'sync-ok' );
					$text.text( response.data.message );
					alert( response.data.message );
					location.reload();
				} else {
					$status.removeClass( 'sync-ok' ).addClass( 'sync-warn' );
					$text.text( 'Sync failed: ' + response.data );
					alert( 'Sync failed: ' + response.data );
				}
			},
			error: function ( jqXHR, textStatus, errorThrown ) {
				$status.removeClass( 'sync-ok' ).addClass( 'sync-warn' );
				$text.text( 'AJAX error during sync.' );
				alert( 'AJAX error: ' + textStatus + ' - ' + errorThrown );
			},
			complete: function () {
				$btn.prop( 'disabled', false ).text( 'Sync Free Models' );
			},
		} );
	} );

	// Sync custom provider JSON to hidden input before any form submit
	$( 'form' ).on( 'submit', function () {
		syncCustomProvidersToJson();
	} );

	// ── Logs Page: Download CSV ───────────────────────────────────────────────

	$( '#ai-collage-download-logs' ).on( 'click', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		var logLevel = $( '#log-level-filter' ).val() || '';
		var logSearch = $( '#log-search' ).val() || '';

		var params = {
			ai_collage_download_logs: '1',
			token: aiCollageData.download_token,
			log_level: logLevel,
			log_search: logSearch
		};

		var url = aiCollageData.home_url + '?' + $.param( params );
		window.location.href = url;
	} );

	// ── Logs Page: Clear All Logs ─────────────────────────────────────────────

	$( '#ai-collage-clear-logs' ).on( 'click', function () {
		var $btn = $( this );
		var nonce = $btn.data( 'nonce' );

		if ( ! confirm( 'Are you sure you want to delete ALL logs? This cannot be undone.' ) ) { return; }

		$btn.prop( 'disabled', true );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_clear_logs',
				nonce: nonce,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'All logs cleared.' );
					location.reload();
				} else {
					alert( 'Error: ' + response.data );
				}
			},
			error: function () { alert( 'Failed to clear logs.' ); },
			complete: function () { $btn.prop( 'disabled', false ); },
		} );
	} );

	// ── Feeds Page ────────────────────────────────────────────────────────────

	function buildFeedCard( id ) {
		var catOptions = '<option value="0">-- None --</option>';
	if ( aiCollageData.categories && aiCollageData.categories.length ) {
		$.each( aiCollageData.categories, function ( i, cat ) {
			catOptions += '<option value="' + $( '<div>' ).text( cat.value ).html() + '">' + $( '<div>' ).text( cat.label ).html() + '</option>';
		} );
	}
		var campaignOptions = '<option value="">-- None (use defaults) --</option>';
		if ( aiCollageData.campaigns ) {
			$.each( aiCollageData.campaigns, function ( i, c ) {
				campaignOptions += '<option value="' + $( '<div>' ).text( c.id ).html() + '">' + $( '<div>' ).text( c.name || c.id ).html() + '</option>';
			} );
		}

		return (
			'<div class="campaign-card feed-card" data-id="' + id + '">' +
			'<div class="campaign-grid">' +
			'<div class="grid-col">' +
			'<label>Feed Name</label>' +
			'<input type="text" name="feed_name" value="" class="feed-name" placeholder="e.g. BBC Urdu">' +
			'<label>Feed URL</label>' +
			'<input type="url" name="feed_url" value="" class="regular-text" placeholder="https://feeds.bbci.co.uk/urdu/rss.xml">' +
			'</div>' +
			'<div class="grid-col">' +
			'<label>Language</label>' +
			'<select name="feed_language">' +
			'<option value="en">English</option>' +
			'<option value="ur">Urdu</option>' +
			'</select>' +
			'<label>Category</label>' +
			'<select name="feed_category">' + catOptions + '</select>' +
			'<label>Campaign</label>' +
			'<select name="feed_campaign_id">' + campaignOptions + '</select>' +
			'</div>' +
			'<div class="grid-col status-col">' +
			'<label>Active</label>' +
			'<label><input type="checkbox" name="feed_active" value="1" checked> Enabled</label>' +
			'</div>' +
			'<div class="grid-col actions-col">' +
			'<button type="button" class="button button-secondary test-feed-btn" data-id="' + id + '">Test</button>' +
			'<button type="button" class="button button-secondary poll-feed-btn" data-id="' + id + '">Poll Now</button>' +
			'<button type="button" class="button button-link-delete remove-feed-btn" data-id="' + id + '">Remove</button>' +
			'</div>' +
			'</div>' +
			'</div>'
		);
	}

	$( '#add-feed' ).on( 'click', function () {
		var timestamp = Date.now().toString();
		var random = Math.random().toString( 36 ).substring( 2, 7 );
		var id = 'feed_' + timestamp + '_' + random;
		$( '#feeds-list' ).append( buildFeedCard( id ) );
	} );

	$( document ).on( 'click', '.remove-feed-btn', function () {
		var id = $( this ).data( 'id' );
		if ( confirm( 'Remove this feed?' ) ) {
			$( '.feed-card[data-id="' + id + '"]' ).remove();
		}
	} );

	$( document ).on( 'click', '.test-feed-btn', function () {
		var $btn = $( this );
		var $card = $btn.closest( '.feed-card' );
		var feedUrl = $card.find( '[name="feed_url"]' ).val();

		if ( ! feedUrl ) { alert( 'Enter a feed URL first.' ); return; }

		$btn.prop( 'disabled', true ).text( 'Testing…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_test_feed',
				nonce: aiCollageData.nonce,
				feed_url: feedUrl,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'Feed valid! Title: ' + ( response.data.title || 'N/A' ) + ', Items: ' + ( response.data.items || 0 ) );
				} else {
					alert( 'Feed test failed: ' + response.data );
				}
			},
			error: function () { alert( 'AJAX error.' ); },
			complete: function () { $btn.prop( 'disabled', false ).text( 'Test' ); },
		} );
	} );

	$( document ).on( 'click', '.poll-feed-btn', function () {
		var $btn = $( this );
		var feedId = $btn.data( 'id' );

		if ( ! feedId || feedId === '' ) {
			alert( 'Save the feed configuration first before polling.' );
			return;
		}

		$btn.prop( 'disabled', true ).text( 'Polling…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_poll_feed',
				nonce: aiCollageData.nonce,
				feed_id: feedId,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( response.data.message );
					location.reload();
				} else {
					alert( 'Error: ' + response.data );
				}
			},
			error: function () { alert( 'AJAX error.' ); },
			complete: function () { $btn.prop( 'disabled', false ).text( 'Poll Now' ); },
		} );
	} );

	$( '#save-feeds' ).on( 'click', function () {
		var $btn = $( this );
		var feeds = [];

$( '.feed-card' ).each( function () {
		var $card = $( this );
		var cardId = $card.data( 'id' );
		if ( ! cardId ) { return; }
		feeds.push( {
			id: String( cardId ),
				name: $card.find( '[name="feed_name"]' ).val(),
				url: $card.find( '[name="feed_url"]' ).val(),
				language: $card.find( '[name="feed_language"]' ).val() || 'en',
				category: $card.find( '[name="feed_category"]' ).val() || '',
				campaign_id: $card.find( '[name="feed_campaign_id"]' ).val() || '',
				active: $card.find( '[name="feed_active"]' ).is( ':checked' ) ? 1 : 0,
			} );
		} );

		$btn.prop( 'disabled', true ).text( 'Saving…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_save_feeds',
				nonce: aiCollageData.nonce,
				feeds: feeds,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'Feeds saved successfully.' );
					location.reload();
				} else {
					alert( 'Error saving feeds: ' + JSON.stringify( response.data ) );
				}
			},
			error: function () { alert( 'AJAX error — could not save feeds.' ); },
			complete: function () { $btn.prop( 'disabled', false ).text( 'Save All Feeds' ); },
		} );
	} );

	$( '#save-rss-settings' ).on( 'click', function () {
		var $btn = $( this );
		var rssEnabled = $( '#rss-enabled' ).is( ':checked' ) ? 1 : 0;
		var rssFrequency = $( '#rss-frequency' ).val();
		var rssMaxPerRun = $( '#rss-max-per-run' ).val();

		$btn.prop( 'disabled', true ).text( 'Saving…' );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: {
				action: 'ai_collage_save_rss_settings',
				nonce: aiCollageData.nonce,
				rss_enabled: rssEnabled,
				rss_frequency: rssFrequency,
				rss_max_per_run: rssMaxPerRun,
			},
			success: function ( response ) {
				if ( response.success ) {
					alert( 'RSS settings saved.' );
				} else {
					alert( 'Error: ' + response.data );
				}
			},
			error: function () { alert( 'AJAX error.' ); },
			complete: function () { $btn.prop( 'disabled', false ).text( 'Save Feed Settings' ); },
		} );
	} );

	// ── Campaign: Brand Override Toggle ───────────────────────────────────

	$( document ).on( 'change', '[name="brand_override_enabled"]', function () {
		var $card = $( this ).closest( '.campaign-card' );
		var $section = $card.find( '.brand-override-section' );
		if ( $( this ).is( ':checked' ) ) {
			$section.slideDown( 200 );
		} else {
			$section.slideUp( 200 );
		}
	} );

	// ── Campaign: Image Extraction Toggle ────────────────────────────────

	$( document ).on( 'change', '[name="image_extraction_enabled"]', function () {
		var $card = $( this ).closest( '.campaign-card' );
		var $section = $card.find( '.image-extraction-options' );
		if ( $( this ).is( ':checked' ) ) {
			$section.slideDown( 200 );
		} else {
			$section.slideUp( 200 );
		}
	} );

	$( document ).on( 'change', '[name="detection_mode"]', function () {
		var $card = $( this ).closest( '.campaign-card' );
		var $zoneConfig = $card.find( '.manual-zone-config' );
		if ( $( this ).val() === 'manual' ) {
			$zoneConfig.slideDown( 200 );
		} else {
			$zoneConfig.slideUp( 200 );
		}
	} );

	// ── Campaign: Video Zone Toggle ─────────────────────────────────────

	$( document ).on( 'change', '[name="video_zone_enabled"]', function () {
		var $card = $( this ).closest( '.campaign-card' );
		var $section = $card.find( '.video-zone-options' );
		if ( $( this ).is( ':checked' ) ) {
			$section.slideDown( 200 );
		} else {
			$section.slideUp( 200 );
		}
	} );

	$( document ).on( 'change', '[name="video_zone_mode"]', function () {
		var $card = $( this ).closest( '.campaign-card' );
		var $zoneConfig = $card.find( '.manual-video-zone-config' );
		var mode = $( this ).val();
		if ( mode === 'manual' ) {
			$zoneConfig.slideDown( 200 );
		} else {
			$zoneConfig.slideUp( 200 );
		}
	} );

	// ── Dashboard: Toggle Sections ────────────────────────────────────────

	$( document ).on( 'click', '.toggle-header', function () {
		var target = $( this ).data( 'target' );
		var $content = $( target );
		var $icon = $( this ).find( '.toggle-icon' );
		$content.slideToggle( 200 );
		$( this ).toggleClass( 'collapsed' );
	} );

	// ── Dashboard: Pipeline Pause/Resume ─────────────────────────────────

	$( document ).on( 'click', '.pipeline-toggle-btn', function () {
		var $btn = $( this );
		var paused = $btn.data( 'paused' ) == '1';
		var action = paused ? 'ai_collage_resume_pipeline' : 'ai_collage_pause_pipeline';
		var label = paused ? 'Resuming…' : 'Pausing…';

		if ( paused && ! confirm( 'Resume pipeline? Stuck jobs (>30 min) will be marked as failed.' ) ) { return; }
		if ( ! paused && ! confirm( 'Pause pipeline? No new jobs will be processed until resumed.' ) ) { return; }

		$btn.prop( 'disabled', true ).text( label );

		$.ajax( {
			url: aiCollageData.ajax_url,
			type: 'POST',
			data: { action: action, nonce: aiCollageData.nonce },
			success: function ( response ) {
				if ( response.success ) {
					alert( response.data.message );
					location.reload();
				} else {
					alert( 'Error: ' + response.data );
				}
			},
			error: function () { alert( 'AJAX error.' ); },
			complete: function () { $btn.prop( 'disabled', false ); },
		} );
	} );

// ── Dashboard: Clear Stuck Jobs ──────────────────────────────────────

$( document ).on( 'click', '.clear-stuck-btn', function () {
var $btn = $( this );
if ( ! confirm( 'Mark all stuck jobs as failed?' ) ) { return; }
$btn.prop( 'disabled', true ).text( 'Clearing…' );
$.ajax( {
url: aiCollageData.ajax_url,
type: 'POST',
data: { action: 'ai_collage_clear_stuck_jobs', nonce: aiCollageData.nonce },
success: function ( response ) {
if ( response.success ) {
alert( response.data.message );
location.reload();
} else {
alert( 'Error: ' + response.data );
}
},
error: function () { alert( 'AJAX error.' ); },
complete: function () { $btn.prop( 'disabled', false ).text( 'Clear Stuck Jobs' ); },
} );
} );

// ── Dashboard: Force Recover Stuck Jobs ────────────────────────

$( document ).on( 'click', '.force-recover-btn', function () {
var $btn = $( this );
if ( ! confirm( 'Force recover stuck jobs?\n\nThis will directly mark stuck REWRITING/RENDERING jobs as FAILED (bypassing Action Scheduler) and reset any stuck AS claims. Pipeline will be resumed if paused.' ) ) { return; }
$btn.prop( 'disabled', true ).text( 'Recovering…' );
$.ajax( {
url: aiCollageData.ajax_url,
type: 'POST',
data: { action: 'ai_collage_force_recover_jobs', nonce: aiCollageData.nonce },
success: function ( response ) {
if ( response.success ) {
alert( response.data.message );
location.reload();
} else {
alert( 'Error: ' + ( response.data || 'Unknown error' ) );
}
},
error: function () { alert( 'AJAX error.' ); },
complete: function () { $btn.prop( 'disabled', false ).text( 'Force Recover Stuck Jobs' ); },
} );
} );

// ── Dashboard: Reset System ──────────────────────────────────────

$( document ).on( 'click', '.reset-system-btn', function () {
var $btn = $( this );
if ( ! confirm( 'Reset entire system?\n\nThis will:\n- Fail all stuck jobs\n- Delete ALL pending/failed AS actions\n- Clear all provider cooldowns & quota state\n- Resume pipeline if paused\n\nThis cannot be undone.' ) ) { return; }
$btn.prop( 'disabled', true ).text( 'Resetting…' );
$.ajax( {
url: aiCollageData.ajax_url,
type: 'POST',
data: { action: 'ai_collage_reset_system', nonce: aiCollageData.nonce },
success: function ( response ) {
if ( response.success ) {
alert( response.data.message );
location.reload();
} else {
alert( 'Error: ' + ( response.data || 'Unknown error' ) );
}
},
error: function ( xhr, status, err ) { alert( 'AJAX error: ' + ( err || status || 'unknown' ) ); },
complete: function () { $btn.prop( 'disabled', false ).text( 'Reset System' ); },
} );
} );

// ── Dashboard: Health Monitor Forced Run Toggle ──────────────────────

$( document ).on( 'change', '.health-monitor-forced-run-toggle', function () {
	var $toggle = $( this );
	var enabled = $toggle.is( ':checked' ) ? '1' : '0';
	$.ajax( {
		url: aiCollageData.ajax_url,
		type: 'POST',
		data: {
			action: 'ai_collage_toggle_health_monitor_forced_run',
			nonce: aiCollageData.nonce,
			enabled: enabled
		},
		success: function ( response ) {
			if ( response.success ) {
				var $slider = $toggle.closest( '.health-monitor-toggle' ).find( '.slider' );
				var $round = $toggle.closest( '.health-monitor-toggle' ).find( '.slider-round' );
				if ( enabled === '1' ) {
					$slider.css( 'background-color', '#00a32a' );
					$round.css( 'left', '18px' );
				} else {
					$slider.css( 'background-color', '#ccc' );
					$round.css( 'left', '2px' );
				}
			} else {
				alert( 'Error: ' + response.data );
				$toggle.prop( 'checked', ! $toggle.is( ':checked' ) );
			}
		},
		error: function () {
			alert( 'AJAX error.' );
			$toggle.prop( 'checked', ! $toggle.is( ':checked' ) );
		},
	} );
} );

// ── Campaigns: Initialize template previews on load ───────────────────

$( '.campaign-card [name="template"]' ).each( function () {
	updateTemplatePreview( $( this ) );
} );

// ── Dashboard: Delete Buffer Drafts ──────────────────────────────────────

$( document ).on( 'click', '.nm-delete-buffer-drafts', function () {
	var $btn = $( this );
	var nonce = $btn.data( 'nonce' );

	if ( ! confirm( 'Delete ALL Buffer drafts? This cannot be undone.' ) ) { return; }

	$btn.prop( 'disabled', true ).text( 'Deleting…' );

	$.ajax( {
		url: aiCollageData.ajax_url,
		type: 'POST',
		data: {
			action: 'nm_delete_buffer_drafts',
			nonce: nonce,
		},
		success: function ( response ) {
			if ( response.success ) {
				alert( response.data.message );
				location.reload();
			} else {
				alert( 'Error: ' + response.data );
			}
		},
		error: function () { alert( 'AJAX error.' ); },
		complete: function () { $btn.prop( 'disabled', false ).text( 'Delete All Drafts' ); },
	} );
} );

} );
