/**
 * NM SEO Generator
 * AI-powered metadata generation for viral videos
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_SEOGenerator = {
    config: {
      ajaxUrl: "",
      nonce: "",
    },

    init(config) {
      this.config = config || {};
    },

    /**
     * Generate viral high-performer metadata
     * @param {string} topic - Video topic
     * @param {array} questions - List of questions in the video
     * @param {Object} options - { platform: 'tiktok'|'shorts'|'reels', keywords: '' }
     */
    generate: async function (topic, questions, options = {}) {
      const platform = options.platform || "tiktok";
      const keywords = options.keywords || "";

      console.log(
        `[NM SEO] Generating high-performer metadata for ${platform} on topic: ${topic}`
      );

      // Construct context from actual questions to avoid hallucinations
      const qContext = questions
        .slice(0, 5)
        .map((q, idx) => `${idx + 1}. ${q.question}`)
        .join("\n");

      // Platform-specific constraints
      const platformContext = {
        tiktok:
          "TikTok rewards long, keyword-rich descriptions (up to 4000 chars) for search rankings.",
        shorts:
          "YouTube Shorts needs high-density hashtags and concise titles (impactful 50-60 chars).",
        reels:
          "Instagram Reels favors aesthetic descriptions and niche trending hashtags.",
      }[platform];

      const prompt = `
                You are a world-class Social Media Growth Expert specializing in ${platform}.
                
                CONTENT CONTEXT:
                Topic: ${topic}
                Questions:
                ${qContext}
                
                STRATEGIC FOCUS:
                Target Keywords: ${keywords}
                Platform Context: ${platformContext}
                
                TASK: Generate viral, search-optimized metadata in JSON format.
                
                STRUCTURE:
                1. "title": 
                   - For TikTok: Intriguing, keyword-heavy, 5-8 words.
                   - For Shorts: High-impact, catchy, under 60 chars.
                   - Use ONE high-energy emoji.
                   
                2. "description": 
                   - Start with a "Psychological Hook" (curiosity gap).
                   - Incorporate "Target Keywords" naturally for algorithm indexing.
                   - Include a "Soft CTA" (e.g., "Check the comments to see if you are a genius").
                   - Length: 3-5 sentences (SEO intensive).
                   
                3. "tags": 
                   - Use the "3-3-3 Hierarchy":
                     - 3 Broad (e.g., #quiz, #trivia, #challenge)
                     - 3 Niche (related to the topic: ${topic})
                     - 3 Search-Specific (based on Keywords: ${keywords})
                   - Return as an array of strings.
                
                Tone: Challenging, high-IQ, slightly mysterious.
                JSON ONLY. NO MARKDOWN. NO CODE BLOCKS.
            `;

      return await this._callGemini(prompt);
    },

    _callGemini: async function (prompt) {
      // @MODIFIED 2025-12-18: Use dedicated SEO endpoint
      const formData = new FormData();
      formData.append("action", "mcqvs_generate_seo");
      formData.append("nonce", this.config.nonce);
      formData.append("prompt", prompt);

      try {
        const response = await fetch(this.config.ajaxUrl, {
          method: "POST",
          body: formData,
        });
        const data = await response.json();

        if (data.success && data.data) {
          return data.data;
        } else {
          console.error("[NM SEO] API Error:", data);
          // Fallback to defaults
          return this._getDefaults();
        }
      } catch (e) {
        console.error("[NM SEO] Fetch Error:", e);
        return this._getDefaults();
      }
    },

    _getDefaults: function () {
      return {
        title: "Only 1% Can Pass This! 🧠",
        description:
          "Think you know your trivia? Test your knowledge with these impossible questions! Don't forget to comment your score!",
        tags: [
          "#quiz",
          "#trivia",
          "#knowledge",
          "#challenge",
          "#fyp",
          "#viral",
        ],
      };
    },
  };

  window.MCQVS_SEOGenerator = MCQVS_SEOGenerator;
})(window);
