<?php

namespace SEO_Article_Generator\AI;

if (!defined('ABSPATH')) {
    exit;
}

final class Provider_Fallback_Manager
{
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    public function get_generation_snapshot(): array
    {
        return AI_Client::get_generation_snapshot();
    }

    public function get_primary_provider(): ?string
    {
        $resolved = AI_Client::resolve_bootstrap_provider();
        return !empty($resolved['ok']) ? (string) $resolved['provider'] : null;
    }

    public function get_provider_state(string $provider): array
    {
        $data = AI_Client::get_provider_details($provider);

        return array(
            'available'   => (bool) ($data['available'] ?? false),
            'reason'      => (string) ($data['state'] ?? 'unknown'),
            'retry_after' => (int) ($data['retry_after'] ?? 0),
        );
    }

    public function run_task(string $task, array $payload, array $policy = []): array
    {
        throw new \LogicException(
            'Provider_Fallback_Manager::run_task() is retired. Route provider execution through AI_Client only.'
        );
    }
}
