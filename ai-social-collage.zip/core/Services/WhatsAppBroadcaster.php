<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WhatsAppBroadcaster {
	
	/**
	 * Generate WhatsApp broadcast message from post data
	 *
	 * @param int $post_id Post ID
	 * @return array Formatted message data
	 */
	public static function generate_broadcast_message( $post_id ) {
		$title = get_the_title( $post_id );
		if ( empty( $title ) ) {
			return [ 'success' => false, 'message' => 'No title found' ];
		}
		
		$permalink = get_permalink( $post_id );
		$thumbnail_url = get_the_post_thumbnail_url( $post_id, 'medium' );
		
		// Get AI-generated content
		$auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
		$hook = $auto_meta['ai_hook'] ?? '';
		$hashtags = get_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, true );
		
		// Build message
		$message_parts = [];
		
		// Headline with Breaking indicator if applicable
		if ( strpos( $title, 'BREAKING' ) !== false ) {
			$message_parts[] = "🚨 *BREAKING NEWS* 🚨";
		}
		
		$message_parts[] = "*{$title}*";
		
		if ( ! empty( $hook ) ) {
			$message_parts[] = $hook;
		}
		
		if ( ! empty( $hashtags ) && is_array( $hashtags ) ) {
			$message_parts[] = implode( ' ', array_slice( $hashtags, 0, 5 ) );
		}
		
		$message_parts[] = "\n📖 Read more: {$permalink}";
		$message_parts[] = "\n_Sent via " . get_bloginfo( 'name' ) . "_";
		
		$message = implode( "\n", $message_parts );
		
		return [
			'success' => true,
			'message' => $message,
			'encoded' => urlencode( $message ),
			'thumbnail' => $thumbnail_url,
			'whatsapp_url' => "https://wa.me/?text=" . urlencode( $message ),
		];
	}
	
	/**
	 * Generate Telegram broadcast message
	 *
	 * @param int $post_id Post ID
	 * @return array Formatted message data
	 */
	public static function generate_telegram_message( $post_id ) {
		$result = self::generate_broadcast_message( $post_id );
		
		if ( $result['success'] ) {
			// Telegram supports markdown better
			$result['telegram_url'] = "https://t.me/share/url?url=" . urlencode( get_permalink( $post_id ) ) . "&text=" . urlencode( $result['message'] );
		}
		
		return $result;
	}
	
	/**
	 * Copy message to clipboard (via admin action)
	 */
	public static function admin_copy_action() {
		check_ajax_referer( 'ai_collage_whatsapp', 'nonce' );
		
		$post_id = intval( $_POST['post_id'] ?? 0 );
		if ( ! $post_id ) {
			wp_send_json_error( 'Invalid post ID' );
		}
		
		$data = self::generate_broadcast_message( $post_id );
		wp_send_json_success( $data );
	}
}
