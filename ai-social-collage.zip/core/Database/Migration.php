<?php
namespace AiSocialCollage\Database;

use AiSocialCollage\Config;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Migration {

	const SCHEMA_VERSION = '3.8';
	const OPTION_SCHEMA_VERSION = 'ai_collage_schema_version';

	public static function ensure_tables() {
		global $wpdb;
		$version = get_option( self::OPTION_SCHEMA_VERSION, '' );
		$api_calls_table = $wpdb->prefix . Config::TABLE_API_CALLS;
		$table_exists = $wpdb->get_var( "SHOW TABLES LIKE '$api_calls_table'" ) === $api_calls_table;
		$has_all_columns = $table_exists ? self::verify_table_columns( $api_calls_table ) : false;
		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
		$jobs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$jobs_table'" ) === $jobs_table;
		$has_all_jobs_columns = $jobs_exists ? self::verify_jobs_table_columns( $jobs_table ) : false;
		if ( $version === self::SCHEMA_VERSION && $has_all_columns && $has_all_jobs_columns ) {
			return;
		}
		if ( ! $table_exists || ! $has_all_columns || ! $jobs_exists || ! $has_all_jobs_columns ) {
			self::create_tables();
		}
		if ( $version !== self::SCHEMA_VERSION ) {
			self::maybe_upgrade();
			self::create_tables();
		} elseif ( ! $has_all_jobs_columns ) {
			self::upgrade_to_3_7();
			self::create_tables();
		}
	}

	private static function verify_table_columns( $table ) {
		global $wpdb;
		$required_columns = [
			'id', 'job_id', 'provider', 'model', 'request_hash', 'request_payload',
			'response_code', 'response_body', 'token_count_input', 'token_count_output',
			'execution_time', 'quota_allowed', 'status', 'caller_context', 'created_at',
		];
		$existing = $wpdb->get_col( "SHOW COLUMNS FROM `$table`" );
		foreach ( $required_columns as $col ) {
			if ( ! in_array( $col, $existing, true ) ) {
				return false;
			}
		}
		return true;
	}

	private static function verify_jobs_table_columns( $table ) {
		global $wpdb;
		$required_columns = [
			'id', 'post_id', 'status', 'ai_headline', 'ai_hook', 'image_metadata',
			'template', 'template_category', 'language', 'brand_logo_position',
			'image_url_2', 'image_url_3', 'image_url_4', 'headline_verified',
			'emphasis_color', 'key_term_color', 'breaking_color', 'text_backing_color',
			'ai_generated_image_url', 'ai_detailed_description', 'ai_eyebrow', 'ai_key_terms',
			'ai_emphasis_word', 'viability_score', 'viability_reason', 'retry_count',
			'original_image_path', 'video_url', 'publish_at', 'published_channels', 'buffer_post_ids',
		];
		$existing = $wpdb->get_col( "SHOW COLUMNS FROM `$table`" );
		foreach ( $required_columns as $col ) {
			if ( ! in_array( $col, $existing, true ) ) {
				return false;
			}
		}
		return true;
	}

public static function create_tables() {
		global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
		
$jobs_table = $wpdb->prefix . 'ai_collage_jobs';
		$sql_jobs = "CREATE TABLE $jobs_table (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		post_id bigint(20) NOT NULL,
		status varchar(50) NOT NULL DEFAULT 'pending',
		ai_headline text NULL,
		ai_hook text NULL,
		image_metadata longtext NULL,
		template varchar(50) NULL,
		template_category varchar(50) NULL,
		language varchar(5) NULL DEFAULT 'en',
		brand_logo_position varchar(20) NULL DEFAULT 'top-right',
		image_url_2 text NULL,
		image_url_3 text NULL,
		image_url_4 text NULL,
		headline_verified tinyint(1) NULL DEFAULT 0,
		emphasis_color varchar(7) NULL,
		key_term_color varchar(7) NULL,
		breaking_color varchar(7) NULL,
		text_backing_color varchar(7) NULL,
		ai_generated_image_url text NULL,
		ai_detailed_description text NULL,
		ai_eyebrow varchar(30) NULL,
		ai_key_terms text NULL,
		ai_emphasis_word varchar(50) NULL,
		viability_score int NULL DEFAULT NULL,
		viability_reason text NULL,
		retry_count int NOT NULL DEFAULT 0,
		original_image_path text NULL,
		created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		UNIQUE KEY post_id_status (post_id, status),
		KEY status (status),
		KEY template (template),
		KEY language (language),
		KEY created_at (created_at)
		) $charset_collate;";

		$logs_table = $wpdb->prefix . 'ai_collage_logs';
		$sql_logs = "CREATE TABLE $logs_table (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		job_id bigint(20) NULL,
		action varchar(255) NOT NULL,
		request_payload longtext NULL,
		response_code varchar(10) NULL,
		raw_response longtext NULL,
		execution_time float NULL,
		log_level varchar(20) NOT NULL DEFAULT 'info',
		created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY job_id (job_id),
		KEY log_level (log_level)
		) $charset_collate;";

		$api_calls_table = $wpdb->prefix . 'ai_collage_api_calls';
		$sql_api_calls = "CREATE TABLE $api_calls_table (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		job_id bigint(20) NULL,
		provider varchar(50) NOT NULL,
		model varchar(100) NOT NULL,
		request_hash varchar(64) NOT NULL,
		request_payload longtext NULL,
		response_code varchar(10) NULL,
		response_body longtext NULL,
		token_count_input int NULL,
		token_count_output int NULL,
		execution_time float NULL,
		quota_allowed tinyint(1) NOT NULL DEFAULT 0,
		status varchar(20) NOT NULL DEFAULT 'pending',
		caller_context varchar(100) NULL,
		created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY job_id (job_id),
		KEY provider (provider),
		KEY request_hash (request_hash),
		KEY status (status),
		KEY created_at (created_at)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Deduplicate post_id_status rows before dbDelta adds the UNIQUE KEY.
		// Retain the row with the lowest id for each (post_id, status) pair.
		$dup_check = $wpdb->query(
			"DELETE j1 FROM `$jobs_table` j1
			INNER JOIN `$jobs_table` j2
			WHERE j1.id > j2.id
			AND j1.post_id = j2.post_id
			AND j1.status = j2.status"
		);
		if ( $dup_check !== false && $dup_check > 0 ) {
			error_log( '[ai-social-collage] Migration: removed ' . (int) $dup_check . ' duplicate job rows before schema upgrade' );
		}

		@dbDelta( $sql_jobs );
		@dbDelta( $sql_logs );
		@dbDelta( $sql_api_calls );

		update_option( self::OPTION_SCHEMA_VERSION, self::SCHEMA_VERSION );
	}

	public static function maybe_upgrade() {
		$current_version = get_option( self::OPTION_SCHEMA_VERSION, '1.0' );

		if ( version_compare( $current_version, '2.0', '<' ) ) {
			self::upgrade_to_2_0();
			update_option( self::OPTION_SCHEMA_VERSION, '2.0' );
		}

	if ( version_compare( $current_version, '2.1', '<' ) ) {
		self::upgrade_to_2_1();
		update_option( self::OPTION_SCHEMA_VERSION, '2.1' );
	}

	if ( version_compare( $current_version, '2.2', '<' ) ) {
		self::upgrade_to_2_2();
		update_option( self::OPTION_SCHEMA_VERSION, '2.2' );
	}

	if ( version_compare( $current_version, '3.0', '<' ) ) {
		self::upgrade_to_3_0();
		update_option( self::OPTION_SCHEMA_VERSION, '3.0' );
	}

if ( version_compare( $current_version, '3.2', '<' ) ) {
self::upgrade_to_3_2();
update_option( self::OPTION_SCHEMA_VERSION, '3.2' );
}

if ( version_compare( $current_version, '3.3', '<' ) ) {
		self::upgrade_to_3_3();
		update_option( self::OPTION_SCHEMA_VERSION, '3.3' );
	}

	if ( version_compare( $current_version, '3.4', '<' ) ) {
	self::upgrade_to_3_4();
	update_option( self::OPTION_SCHEMA_VERSION, '3.4' );
}

if ( version_compare( $current_version, '3.5', '<' ) ) {
	self::upgrade_to_3_5();
	update_option( self::OPTION_SCHEMA_VERSION, '3.5' );
}

if ( version_compare( $current_version, '3.6', '<' ) ) {
		self::upgrade_to_3_6();
		update_option( self::OPTION_SCHEMA_VERSION, '3.6' );
	}

	if ( version_compare( $current_version, '3.7', '<' ) ) {
		self::upgrade_to_3_7();
		update_option( self::OPTION_SCHEMA_VERSION, '3.7' );
	}

	if ( version_compare( $current_version, '3.8', '<' ) ) {
		self::upgrade_to_3_8();
		update_option( self::OPTION_SCHEMA_VERSION, '3.8' );
	}
	}

	private static function upgrade_to_2_0() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			"ALTER TABLE `$table` ADD COLUMN `template` varchar(50) NULL AFTER `image_metadata`",
			"ALTER TABLE `$table` ADD COLUMN `template_category` varchar(50) NULL AFTER `template`",
			"ALTER TABLE `$table` ADD COLUMN `language` varchar(5) NULL DEFAULT 'en' AFTER `template_category`",
			"ALTER TABLE `$table` ADD COLUMN `brand_logo_position` varchar(20) NULL DEFAULT 'top-right' AFTER `language`",
			"ALTER TABLE `$table` ADD COLUMN `image_url_2` text NULL AFTER `brand_logo_position`",
			"ALTER TABLE `$table` ADD COLUMN `image_url_3` text NULL AFTER `image_url_2`",
			"ALTER TABLE `$table` ADD COLUMN `image_url_4` text NULL AFTER `image_url_3`",
			"ALTER TABLE `$table` ADD COLUMN `headline_verified` tinyint(1) NULL DEFAULT 0 AFTER `image_url_4`",
			"ALTER TABLE `$table` ADD COLUMN `emphasis_color` varchar(7) NULL AFTER `headline_verified`",
			"ALTER TABLE `$table` ADD COLUMN `key_term_color` varchar(7) NULL AFTER `emphasis_color`",
			"ALTER TABLE `$table` ADD COLUMN `breaking_color` varchar(7) NULL AFTER `key_term_color`",
			"ALTER TABLE `$table` ADD COLUMN `text_backing_color` varchar(7) NULL AFTER `breaking_color`",
		];

		$indexes = [
			"ALTER TABLE `$table` ADD INDEX `template` (`template`)",
			"ALTER TABLE `$table` ADD INDEX `language` (`language`)",
			"ALTER TABLE `$table` ADD INDEX `created_at` (`created_at`)",
		];

		foreach ( $columns as $sql ) {
			if ( self::column_missing( $table, self::extract_column_name( $sql ) ) ) {
				$wpdb->query( $sql );
			}
		}

		foreach ( $indexes as $sql ) {
			$index_name = self::extract_index_name( $sql );
			if ( ! self::index_exists( $table, $index_name ) ) {
				$wpdb->query( $sql );
			}
		}
	}

	private static function column_missing( $table, $column ) {
		global $wpdb;
		$row = $wpdb->get_row( "SHOW COLUMNS FROM `$table` LIKE '$column'" );
		return is_null( $row );
	}

	private static function index_exists( $table, $index_name ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s LIMIT 1",
			$table,
			$index_name
		) );
		return ! is_null( $row );
	}

	private static function extract_column_name( $sql ) {
		if ( preg_match( '/ADD COLUMN\s+`(\w+)`/i', $sql, $m ) ) {
			return $m[1];
		}
		return '';
	}

	private static function extract_index_name( $sql ) {
		if ( preg_match( '/ADD INDEX\s+`?(\w+)`?/i', $sql, $m ) ) {
			return $m[1];
		}
		return '';
	}

	private static function upgrade_to_2_1() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			"ALTER TABLE `$table` ADD COLUMN `ai_generated_image_url` text NULL AFTER `text_backing_color`",
		];

		foreach ( $columns as $sql ) {
			if ( self::column_missing( $table, self::extract_column_name( $sql ) ) ) {
				$wpdb->query( $sql );
			}
		}
	}

	private static function upgrade_to_2_2() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			"ALTER TABLE `$table` ADD COLUMN `ai_detailed_description` text NULL AFTER `ai_generated_image_url`",
		];

		foreach ( $columns as $sql ) {
			if ( self::column_missing( $table, self::extract_column_name( $sql ) ) ) {
				$wpdb->query( $sql );
			}
		}
	}

	private static function upgrade_to_3_0() {
		global $wpdb;
		$api_calls_table = $wpdb->prefix . Config::TABLE_API_CALLS;

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s AND NON_UNIQUE = 0 LIMIT 1",
			$api_calls_table,
			'request_hash'
		) );
		if ( is_null( $row ) ) {
			$wpdb->query( "DELETE t1 FROM `$api_calls_table` t1 INNER JOIN `$api_calls_table` t2 WHERE t1.id > t2.id AND t1.request_hash = t2.request_hash" );
			$wpdb->query( "ALTER TABLE `$api_calls_table` ADD UNIQUE KEY `request_hash` (`request_hash`)" );
		}

		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', [], Config::AS_GROUP );
		}
	}

	private static function upgrade_to_3_2() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			"ALTER TABLE `$table` ADD COLUMN `ai_eyebrow` varchar(30) NULL AFTER `ai_detailed_description`",
			"ALTER TABLE `$table` ADD COLUMN `ai_key_terms` text NULL AFTER `ai_eyebrow`",
		];

		foreach ( $columns as $sql ) {
			if ( self::column_missing( $table, self::extract_column_name( $sql ) ) ) {
				$wpdb->query( $sql );
			}
		}
	}

	private static function upgrade_to_3_3() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			"ALTER TABLE `$table` ADD COLUMN `viability_score` int NULL DEFAULT NULL AFTER `ai_key_terms`",
			"ALTER TABLE `$table` ADD COLUMN `viability_reason` text NULL AFTER `viability_score`",
		];

		foreach ( $columns as $sql ) {
			if ( self::column_missing( $table, self::extract_column_name( $sql ) ) ) {
				$wpdb->query( $sql );
			}
		}
	}

private static function upgrade_to_3_4() {
	global $wpdb;
	$table = $wpdb->prefix . Config::TABLE_JOBS;

	if ( self::column_missing( $table, 'ai_emphasis_word' ) ) {
		$wpdb->query(
			"ALTER TABLE `$table` ADD COLUMN `ai_emphasis_word` varchar(50) NULL AFTER `ai_detailed_description`"
		);
	}
}

private static function upgrade_to_3_5() {
	global $wpdb;
	
	// Ensure dbDelta is available
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	
	// Create social media sources table
	$social_media_table = $wpdb->prefix . 'ai_collage_social_media_sources';
	$sql_social_media = "CREATE TABLE $social_media_table (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		source_url varchar(255) NOT NULL,
		platform_type varchar(50) NOT NULL,
		source_author varchar(100) DEFAULT NULL,
		source_handle varchar(100) DEFAULT NULL,
		original_caption text DEFAULT NULL,
		original_hashtags text DEFAULT NULL,
		original_media_url varchar(500) DEFAULT NULL,
		branding_detected longtext DEFAULT NULL,
		last_monitored datetime DEFAULT NULL,
		monitoring_active tinyint(1) DEFAULT 1,
		PRIMARY KEY (id),
		UNIQUE KEY source_url (source_url)
	) $wpdb->get_charset_collate();";
	
	dbDelta( $sql_social_media );
	
	// Add social media columns to jobs table
	$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
	$columns = [
		"ALTER TABLE `$jobs_table` ADD COLUMN `processing_mode` varchar(20) NULL DEFAULT 'rewrite' AFTER `ai_detailed_description`",
		"ALTER TABLE `$jobs_table` ADD COLUMN `source_platform` varchar(50) NULL AFTER `processing_mode`",
		"ALTER TABLE `$jobs_table` ADD COLUMN `original_author` varchar(100) NULL AFTER `source_platform`",
		"ALTER TABLE `$jobs_table` ADD COLUMN `branding_removed` tinyint(1) NULL DEFAULT 0 AFTER `original_author`",
		"ALTER TABLE `$jobs_table` ADD COLUMN `ocr_extracted_text` longtext NULL AFTER `branding_removed`",
	];
	
	foreach ( $columns as $sql ) {
		if ( self::column_missing( $jobs_table, self::extract_column_name( $sql ) ) ) {
			$wpdb->query( $sql );
		}
	}
	
	// Update schema version
	update_option( self::OPTION_SCHEMA_VERSION, '3.5' );
}

private static function upgrade_to_3_6() {
	global $wpdb;
	$table = $wpdb->prefix . Config::TABLE_JOBS;

	if ( self::column_missing( $table, 'retry_count' ) ) {
		$wpdb->query(
			"ALTER TABLE `$table` ADD COLUMN `retry_count` int NOT NULL DEFAULT 0 AFTER `viability_reason`"
		);
	}
}

private static function upgrade_to_3_7() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		$columns = [
			'video_url'           => "ALTER TABLE `$table` ADD COLUMN `video_url` text NULL AFTER `original_image_path`",
			'publish_at'          => "ALTER TABLE `$table` ADD COLUMN `publish_at` datetime NULL DEFAULT NULL AFTER `video_url`",
			'published_channels'  => "ALTER TABLE `$table` ADD COLUMN `published_channels` longtext NULL AFTER `publish_at`",
			'buffer_post_ids'     => "ALTER TABLE `$table` ADD COLUMN `buffer_post_ids` longtext NULL AFTER `published_channels`",
		];

		foreach ( $columns as $col => $sql ) {
			if ( self::column_missing( $table, $col ) ) {
				$wpdb->query( $sql );
			}
		}

		$indexes = [
			'publish_at' => "ALTER TABLE `$table` ADD INDEX `publish_at` (`publish_at`)",
		];

		foreach ( $indexes as $idx => $sql ) {
			if ( ! self::index_exists( $table, $idx ) ) {
				$wpdb->query( $sql );
			}
		}
	}

	/**
	 * Ensure UNIQUE KEY `post_id_status` exists on the jobs table.
	 *
	 * The key is defined in create_tables() and has been since upgrade_to_2_0,
	 * but dbDelta silently skipped adding it on populated tables, leaving
	 * production databases with duplicate (post_id, status) rows. Production
	 * evidence 2026-08-24: post 29241 had rows 107984 + 3345 both in 'pending'
	 * (same for 29247/108004+3346, 29255/108025+3347, 29259/108040+3348). The
	 * QueueHealthMonitor's re-enqueue logic naturally picked the oldest row
	 * (smallest id) so processing kept working, but PostObserver's
	 * `INSERT ... ON DUPLICATE KEY UPDATE` was effectively a plain insert and
	 * the dangling rows piled up forever.
	 *
	 * Idempotent: returns immediately if the key already exists.
	 */
	private static function upgrade_to_3_8() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_JOBS;

		if ( self::index_exists( $table, 'post_id_status' ) ) {
			return;
		}

		// Same dedup strategy as create_tables(): keep the lowest id per
		// (post_id, status) pair so the UNIQUE KEY can be added without
		// colliding with an existing duplicate.
		$dedup = $wpdb->query(
			"DELETE j1 FROM `$table` j1
			 INNER JOIN `$table` j2
			 WHERE j1.id > j2.id
			   AND j1.post_id = j2.post_id
			   AND j1.status = j2.status"
		);
		if ( $dedup !== false && $dedup > 0 ) {
			error_log( '[ai-social-collage] Migration 3.8: removed ' . (int) $dedup . ' duplicate job rows before adding UNIQUE KEY post_id_status' );
		}

		$added = $wpdb->query( "ALTER TABLE `$table` ADD UNIQUE KEY `post_id_status` (`post_id`, `status`)" );
		if ( $added === false ) {
			error_log( '[ai-social-collage] Migration 3.8: FAILED to add UNIQUE KEY post_id_status — manual intervention required' );
		} else {
			error_log( '[ai-social-collage] Migration 3.8: added UNIQUE KEY post_id_status on `' . $table . '`' );
		}
	}
}
