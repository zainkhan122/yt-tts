<?php

/**
 * Admin Menu Manager
 *
 * This class handles the creation of the main admin menu
 * and all procedural submenu pages like 'Tools' and 'Calendar'.
 *
 * @version 1.1 - Added Content Calendar UI
 *
 * @MODIFIED: Ported all render functions from V23's 24-content-calendar.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Admin_Menu {


	/**
	 * Initialize the menu hooks
	 *
	 * Priority ladder (admin_menu):
	 *   5    – register parent menu (callback renders Dashboard directly)
	 *   6    – Dashboard submenu (FIRST child → parent URL promotes to Dashboard)
	 *   11   – CPT submenus (All MCQs, Add New, Topics, Exam Tags)
	 *   12   – Import MCQs
	 *   13   – Export MCQs
	 *   14   – Similar Questions
	 *   15   – Reported MCQs
	 *   16   – Content Calendar
	 *   17   – News Sources
	 *   18   – Embeddings
	 *   19   – Subscribers
	 *   20   – Logs
	 *   21   – Tools
	 *  998   – finalize_parent_link() ensures parent URL points to Dashboard
	 *  999   – hide_old_menus() removes native MCQs CPT menu
	 */
	public static function init() {
		// Parent menu (callback renders Dashboard directly).
		add_action( 'admin_menu', array( self::class, 'register_main_menu' ), 5 );

		// Dashboard MUST be first submenu (priority 6).
		add_action( 'admin_menu', array( 'NM_Admin_Dashboard', 'register_submenu' ), 6 );

		// Legacy submenus at their intended positions.
		add_action( 'admin_menu', array( self::class, 'register_calendar_submenu' ), 16 );
		add_action( 'admin_menu', array( self::class, 'register_logs_submenu'    ), 20 );
		add_action( 'admin_menu', array( self::class, 'register_tools_submenu'   ), 21 );

		// Settings submenu (always last).
		add_action( 'admin_menu', array( self::class, 'register_settings_submenu' ), 99 );

		// Final cleanup hooks.
		add_action( 'admin_menu', array( self::class, 'finalize_parent_link' ), 998 );
		add_action( 'admin_menu', array( self::class, 'hide_old_menus' ), 999 );

		// Toolbar links.
		add_action( 'admin_bar_menu', array( self::class, 'add_toolbar_items' ), 100 );
	}

	/**
	 * Create the Main Parent Menu and its core submenus
	 *
	 * Priorities are spaced intentionally:
	 *   5  -> parent menu only
	 *   99 -> Settings (last)
	 * Mid-range submenus are registered at their own priorities via dedicated hooks.
	 */
	public static function register_main_menu() {
		// The parent menu itself renders the Dashboard directly — no longer
		// uses the stale `dashboard_redirect()` wrapper that produced the
		// blank page (`?page=nm_mcq_generator` / `parent_file = nm_dashboard`).
		add_menu_page(
			'MCQ Generator',            // Page Title
			'📚 MCQ',                    // Menu Title
			'manage_options',
			'nm_mcq_generator',          // Parent slug — URL the browser stays on
			array( 'NM_Admin_Dashboard', 'render' ), // Direct Dashboard render
			'dashicons-welcome-learn-more',
			25
		);

		// Remove WordPress's auto-generated duplicate submenu whose title
		// mirrors the parent slug (nm_mcq_generator).  Must be removed
		// BEFORE Dashboard's nm_dashboard submenu is added so the sidebar
		// collapses to one entry under "📚 MCQ".
		remove_submenu_page( 'nm_mcq_generator', 'nm_mcq_generator' );
	}

	/**
	 * Late cleanup (priority 998): after every submenu has been registered
	 * across all modules, force the parent menu URL to nm_dashboard and
	 * remove wp's auto-generated duplicate entry for the parent slug.
	 *
	 * Without this step WordPress leaves the parent pointing to whatever
	 * first submenu was registered — which is no longer what we want now
	 * that submenu priorities are rearranged.
	 */
	public static function finalize_parent_link() {
		global $submenu;

		// 1. Re-write the parent row so its callback renders the Dashboard
		//    DIRECTLY.  The URL stays ?page=nm_mcq_generator (set by
		//    register_main_menu at priority 5); we only (re)bind the callback
		//    here because WordPress may have overwritten it while linking
		//    the first real child (Dashboard) during submenu registration.
		//    No redirect — previously dashboard_redirect() produced a blank page.
		add_menu_page(
			'MCQ Generator',
			'📚 MCQ',
			'manage_options',
			'nm_mcq_generator',
			array( 'NM_Admin_Dashboard', 'render' ),
			'dashicons-welcome-learn-more',
			25
		);

		// 2. Remove the auto-generated duplicate that wp adds when the parent
		//    slug matches a submenu slug.  Must happen AFTER all children are
		//    registered so Dashboard is the visible entry.
		if ( isset( $submenu['nm_mcq_generator'] ) ) {
			foreach ( $submenu['nm_mcq_generator'] as $i => $item ) {
				if ( isset( $item[2] ) && $item[2] === 'nm_mcq_generator' ) {
					unset( $submenu['nm_mcq_generator'][ $i ] );
					break;
				}
			}
		}
	}

	/**
	 * Register the Tools submenu (near the bottom, just above Settings)
	 */
	public static function register_tools_submenu() {
		add_submenu_page(
			'nm_mcq_generator',
			'Tools',
			'🔧 Tools',
			'manage_options',
			'nm_tools',
			array( self::class, 'render_tools_page' )
		);
	}

	/**
	 * Register the Content Calendar submenu (after Bulk / Scheduled group)
	 */
	public static function register_calendar_submenu() {
		add_submenu_page(
			'nm_mcq_generator',
			'Content Calendar',
			'📅 Content Calendar',
			'manage_options',
			'nm-content-calendar',
			array( self::class, 'render_calendar_page' )
		);
	}

	/**
	 * Register the dedicated Logs page (just below Subscribers, above Tools)
	 */
	public static function register_logs_submenu() {
		add_submenu_page(
			'nm_mcq_generator',
			'MCQ Generation Logs',
			'📋 Logs',
			'manage_options',
			'nm-mcq-logs',
			array( self::class, 'render_logs_page' )
		);
	}

	/**
	 * Register the Settings submenu (always last)
	 */
	public static function register_settings_submenu() {
		add_submenu_page(
			'nm_mcq_generator',
			'MCQ Settings',
			'⚙️ Settings',
			'manage_options',
			'news-mcq-generator',
			array( 'NM_Admin_Settings', 'render_options_page' )
		);
	}

	/**
	 * Redirects the main parent menu link to the Dashboard
	 */
	public static function dashboard_redirect() {
		wp_redirect( admin_url( 'admin.php?page=nm_dashboard' ) );
		exit;
	}

	/**
	 * Hides the default "MCQs" post type menu
	 */
	public static function hide_old_menus() {
		remove_menu_page( 'edit.php?post_type=mcq' );
		remove_submenu_page( 'options-general.php', 'news-mcq-generator' );
	}

	/**
	 * Adds quick links to the admin toolbar
	 */
	public static function add_toolbar_items( $admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$admin_bar->add_menu(
			array(
				'id'    => 'nm-quick-menu',
				'title' => '📊 MCQ',
				'href'  => admin_url( 'admin.php?page=nm_dashboard' ),
				'meta'  => array( 'title' => 'MCQ Generator' ),
			)
		);
		$admin_bar->add_menu(
			array(
				'parent' => 'nm-quick-menu',
				'id'     => 'nm-dashboard-link',
				'title'  => 'Dashboard',
				'href'   => admin_url( 'admin.php?page=nm_dashboard' ),
			)
		);
		$admin_bar->add_menu(
			array(
				'parent' => 'nm-quick-menu',
				'id'     => 'nm-add-new-link',
				'title'  => 'Add New MCQ',
				'href'   => admin_url( 'post-new.php?post_type=mcq' ),
			)
		);
		$admin_bar->add_menu(
			array(
				'parent' => 'nm-quick-menu',
				'id'     => 'nm-settings-link',
				'title'  => 'Settings',
				'href'   => admin_url( 'admin.php?page=news-mcq-generator' ),
			)
		);
		$admin_bar->add_menu(
			array(
				'parent' => 'nm-quick-menu',
				'id'     => 'nm-logs-link',
				'title'  => 'Logs',
				'href'   => admin_url( 'admin.php?page=nm-mcq-logs' ),
				'meta'   => array( 'title' => 'MCQ Generation Logs' ),
			)
		);
	}

	/**
	 * Renders the Tools page content
	 */
	public static function render_tools_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}
		?>
		<div class="wrap">
			<h1>🔧 MCQ Generator Tools</h1>

			<!-- E-A-T Data Backfill Section -->
			<div class="card" style="max-width: 800px; margin: 20px 0; padding: 20px;">
				<h2 class="title">📊 E-A-T Data Backfill</h2>
				<p>Backfill Expertise, Authoritativeness, and Trustworthiness data for existing MCQs that don't have E-A-T metadata.</p>
				<p class="description">
					This will set the following defaults for MCQs missing E-A-T data:
					<br>• <strong>Author:</strong> The QuizWire
					<br>• <strong>Fact Checked:</strong> Yes
					<br>• <strong>Difficulty:</strong> Medium
				</p>
				<p>
					<button id="nm-backfill-eat-btn" class="button button-primary button-large">
						<span class="dashicons dashicons-update-alt" style="margin-top: 3px;"></span>
						Backfill E-A-T Data
					</button>
					<span class="spinner" id="nm-backfill-spinner" style="float: none; margin-left: 10px;"></span>
				</p>
				<div id="nm-backfill-status" style="margin-top: 15px;"></div>
			</div>

			<!-- Manual Publishing Spike Section -->
			<div class="card" style="max-width: 800px; margin: 20px 0; padding: 20px;">
				<h2 class="title">⚡ Manual Publishing Spike</h2>
				<p>Instantly publish a batch of "ready" MCQs from the queue. Useful for breaking news coverage.</p>
				<form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="post">
					<input type="hidden" name="action" value="nm_spike_publish">
					<?php wp_nonce_field( 'nm_spike_publish' ); ?>
					<p>
						<label for="nm_spike_count">Number of MCQs to publish:</label>
						<input type="number" id="nm_spike_count" name="nm_spike_count" value="5" min="1" max="50" class="small-text">
					</p>
					<p>
						<button type="submit" class="button button-primary button-large">
							<span class="dashicons dashicons-megaphone" style="margin-top: 3px;"></span>
							Trigger Spike Now
						</button>
					</p>
				</form>
			</div>

			<!-- System Tools Section -->
			<div class="card" style="max-width: 800px; margin: 20px 0; padding: 20px;">
				<h2 class="title">System Tools</h2>
				<p>Links to various system management pages.</p>
				<p>
					<a href="<?php echo admin_url( 'admin.php?page=nm_migrate_embeddings' ); ?>" class="button">🔄 Manage Embeddings</a>
					&nbsp;
					<a href="<?php echo admin_url( 'admin.php?page=nm_dashboard' ); ?>" class="button button-primary">📊 View Dashboard</a>
					&nbsp;
					<a href="<?php echo admin_url( 'admin.php?page=nm_similar_questions' ); ?>" class="button">🔗 Review Duplicates</a>
				</p>
			</div>
		</div>

		<script>
			jQuery(document).ready(function($) {
				// E-A-T Backfill Handler
				$('#nm-backfill-eat-btn').on('click', function() {
					var $btn = $(this);
					var $spinner = $('#nm-backfill-spinner');
					var $status = $('#nm-backfill-status');

					// Confirm action
					if (!confirm('This will backfill E-A-T data for all existing MCQs that don\'t have it. Continue?')) {
						return;
					}

					// Disable button and show spinner
					$btn.prop('disabled', true);
					$spinner.addClass('is-active');
					$status.html('<p style="color: #666;">🔄 Processing backfill...</p>');

					// Make AJAX request
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_backfill_eat_data',
							_ajax_nonce: '<?php echo wp_create_nonce( 'nm_ajax_dashboard' ); ?>'
						},
						timeout: 120000, // 2 minutes timeout
						success: function(response) {
							if (response.success) {
								$status.html(
									'<div class="notice notice-success" style="padding: 10px; margin: 0;"><p><strong>✅ Success!</strong></p>' +
									'<p>' + response.data.message + '</p>' +
									'<p><strong>Statistics:</strong></p>' +
									'<ul>' +
									'<li>Total MCQs: ' + response.data.total + '</li>' +
									'<li>Updated: ' + response.data.updated + '</li>' +
									'<li>Already had data: ' + response.data.skipped + '</li>' +
									'</ul></div>'
								);
							} else {
								$status.html(
									'<div class="notice notice-error" style="padding: 10px; margin: 0;"><p><strong>❌ Error</strong></p>' +
									'<p>' + (response.data.message || 'Unknown error occurred') + '</p></div>'
								);
							}
						},
						error: function(xhr, status, error) {
							console.error('AJAX Error:', xhr.responseText);
							$status.html(
								'<div class="notice notice-error" style="padding: 10px; margin: 0;"><p><strong>❌ Error</strong></p>' +
								'<p>Failed to complete backfill. Error: ' + error + '</p>' +
								'<p>Check browser console for details.</p></div>'
							);
						},
						complete: function() {
							// Re-enable button and hide spinner
							$btn.prop('disabled', false);
							$spinner.removeClass('is-active');
						}
					});
				});
			});
		</script>
		<?php
	}

	/**
	 * ✅ NEW: Renders the Content Calendar page content (from V23)
	 */
	public static function render_calendar_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}
		?>
		<div class="wrap">
			<h1>📅 MCQ Content Calendar</h1>

			<div class="nm-calendar-stats" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;">
				<?php
				$stats = self::get_content_stats(); // ✅ MODIFIED: Call static method
				?>
				<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 8px; text-align: center;">
					<div style="font-size: 36px; font-weight: 700; margin-bottom: 5px;"><?php echo $stats['total_mcqs']; ?></div>
					<div style="font-size: 14px; opacity: 0.9;">Total MCQs</div>
				</div>

				<div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 25px; border-radius: 8px; text-align: center;">
					<div style="font-size: 36px; font-weight: 700; margin-bottom: 5px;"><?php echo $stats['this_week']; ?></div>
					<div style="font-size: 14px; opacity: 0.9;">Generated This Week</div>
				</div>

				<div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 25px; border-radius: 8px; text-align: center;">
					<div style="font-size: 36px; font-weight: 700; margin-bottom: 5px;"><?php echo $stats['scheduled']; ?></div>
					<div style="font-size: 14px; opacity: 0.9;">Scheduled</div>
				</div>

				<div style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 25px; border-radius: 8px; text-align: center;">
					<div style="font-size: 36px; font-weight: 700; margin-bottom: 5px;"><?php echo $stats['avg_per_day']; ?></div>
					<div style="font-size: 14px; opacity: 0.9;">Avg Per Day</div>
				</div>
			</div>

			<div class="nm-bulk-generation" style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px;">
				<h2 style="margin-top: 0;">🚀 Bulk MCQ Generation</h2>
				<p>Generate multiple MCQs at once from news sources or topics. Perfect for scaling your content library.</p>

				<form method="post" id="nm-bulk-generation-form">
					<?php wp_nonce_field( 'nm_bulk_generation', 'nm_bulk_nonce' ); ?>

					<table class="form-table">
						<tr>
							<th><label for="generation_type">Generation Type</label></th>
							<td>
								<select id="generation_type" name="generation_type" class="regular-text">
									<option value="news">📰 From Latest News</option>
									<option value="topics">📚 From Topics</option>
									<option value="mixed">🔀 Mixed (Recommended)</option>
								</select>
								<p class="description">Choose your content source.</p>
							</td>
						</tr>

						<tr>
							<th><label for="mcq_count">Number of MCQs</label></th>
							<td>
								<input type="number" id="mcq_count" name="mcq_count" value="50" min="10" max="100" class="regular-text">
								<p class="description">How many MCQs to generate (10-100). Recommended: 50</p>
							</td>
						</tr>

						<tr id="news-categories-row">
							<th><label>News Categories</label></th>
							<td>
								<?php
								$selected_cats = get_option( 'nm_news_categories', array() );
								$all_cats      = array( 'general', 'nation', 'business', 'technology', 'entertainment', 'sports', 'science', 'health' );

								foreach ( $all_cats as $cat ) {
									$checked = in_array( $cat, $selected_cats ) ? 'checked' : '';
									echo '<label style="display: inline-block; margin-right: 15px;">
                                            <input type="checkbox" name="news_categories[]" value="' . esc_attr( $cat ) . '" ' . $checked . '> 
                                            ' . ucfirst( $cat ) . '
                                          </label>';
								}
								?>
								<p class="description">Select news categories to pull from.</p>
							</td>
						</tr>

						<tr id="topics-row" style="display: none;">
							<th><label>Select Topics</label></th>
							<td>
								<div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;">
									<?php
									$topics = get_terms(
										array(
											'taxonomy'   => 'topic',
											'hide_empty' => false,
										)
									);
									foreach ( $topics as $topic ) {
										echo '<label style="display: block; margin-bottom: 5px;">
                                                <input type="checkbox" name="topics[]" value="' . $topic->term_id . '"> 
                                                ' . esc_html( $topic->name ) . '
                                              </label>';
									}
									?>
								</div>
								<p class="description">Select topics to generate MCQs for.</p>
							</td>
						</tr>

						<tr>
							<th><label for="publish_status">Publish Status</label></th>
							<td>
								<select id="publish_status" name="publish_status" class="regular-text">
									<option value="publish">✅ Publish Immediately</option>
									<option value="draft">📝 Save as Draft</option>
									<option value="smart_schedule">🧠 Smart Schedule (Human-like)</option>
									<option value="scheduled">📅 Schedule for Later</option>
								</select>
							</td>
						</tr>

						<tr id="schedule-row" style="display: none;">
							<th><label for="schedule_date">Schedule Date</label></th>
							<td>
								<input type="datetime-local" id="schedule_date" name="schedule_date" class="regular-text">
								<p class="description">When to publish these MCQs.</p>
							</td>
						</tr>

						<tr>
							<th><label for="mcqs_per_batch">MCQs per Batch</label></th>
							<td>
								<input type="number" id="mcqs_per_batch" name="mcqs_per_batch" value="10" min="5" max="20" class="regular-text">
								<p class="description">Generate in batches to avoid timeouts. Recommended: 10</p>
							</td>
						</tr>
					</table>

					<p class="submit">
						<button type="button" id="nm-start-bulk-generation" class="button button-primary button-hero">
							🚀 Start Bulk Generation
						</button>
						<span class="spinner" id="nm-bulk-spinner" style="float: none; margin-left: 10px;"></span>
					</p>
				</form>

				<div id="nm-bulk-progress" style="display: none; margin-top: 30px;">
					<h3>Generation Progress</h3>
					<div style="background: #f0f0f0; height: 30px; border-radius: 15px; overflow: hidden; position: relative;">
						<div id="nm-progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); height: 100%; width: 0%; transition: width 0.3s;"></div>
						<span id="nm-progress-text" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-weight: 600; color: #333;">0%</span>
					</div>

					<div id="nm-bulk-log" style="margin-top: 20px; max-height: 400px; overflow-y: auto; background: #f7f7f7; border: 1px solid #ccc; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 13px;">
						<div>Starting bulk generation...</div>
					</div>
				</div>
			</div>

			<div class="nm-scheduled-content" style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
				<h2 style="margin-top: 0;">📅 Scheduled Content</h2>
				<?php
				self::render_scheduled_content(); // ✅ MODIFIED: Call static method
				?>
			</div>
		</div>

		<script>
			jQuery(document).ready(function($) {
				// Toggle fields based on generation type
				$('#generation_type').on('change', function() {
					const type = $(this).val();
					if (type === 'news' || type === 'mixed') {
						$('#news-categories-row').show();
					} else {
						$('#news-categories-row').hide();
					}

					if (type === 'topics' || type === 'mixed') {
						$('#topics-row').show();
					} else {
						$('#topics-row').hide();
					}
				});

				// Toggle schedule date field
				$('#publish_status').on('change', function() {
					if ($(this).val() === 'scheduled') {
						$('#schedule-row').show();
					} else {
						$('#schedule-row').hide();
					}
				});

				// Bulk generation handler
				$('#nm-start-bulk-generation').on('click', function() {
					const btn = $(this);
					const formData = $('#nm-bulk-generation-form').serialize();
					const totalMCQs = parseInt($('#mcq_count').val());
					const batchSize = parseInt($('#mcqs_per_batch').val());
					const totalBatches = Math.ceil(totalMCQs / batchSize);

					let currentBatch = 0;
					let generatedCount = 0;

					btn.prop('disabled', true);
					$('#nm-bulk-spinner').addClass('is-active');
					$('#nm-bulk-progress').show();
					$('#nm-bulk-log').html('<div>Starting bulk generation...</div>');

					function processBatch() {
						if (currentBatch >= totalBatches) {
							$('#nm-bulk-log').append('<div style="color: green; font-weight: bold; margin-top: 10px;">✅ Bulk generation complete! Generated ' + generatedCount + ' MCQs.</div>');
							btn.prop('disabled', false);
							$('#nm-bulk-spinner').removeClass('is-active');
							return;
						}

						const batchMCQs = Math.min(batchSize, totalMCQs - generatedCount);
						currentBatch++;

						$('#nm-bulk-log').append('<div>📦 Processing batch ' + currentBatch + ' of ' + totalBatches + ' (' + batchMCQs + ' MCQs)...</div>');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: formData + '&action=nm_bulk_generate_batch&batch=' + currentBatch + '&batch_size=' + batchMCQs,
							timeout: 120000,
							success: function(response) {
								if (response.success) {
									generatedCount += response.data.generated;
									const progress = Math.round((generatedCount / totalMCQs) * 100);

									$('#nm-progress-bar').css('width', progress + '%');
									$('#nm-progress-text').text(progress + '%');

									$('#nm-bulk-log').append('<div style="color: green;">✅ Batch ' + currentBatch + ' complete: ' + response.data.generated + ' MCQs generated</div>');

									if (response.data.log && response.data.log.length > 0) {
										response.data.log.forEach(function(logEntry) {
											$('#nm-bulk-log').append('<div style="color: #666; padding-left: 20px;">  ' + logEntry + '</div>');
										});
									}

									// Auto-scroll log to bottom
									$('#nm-bulk-log').scrollTop($('#nm-bulk-log')[0].scrollHeight);

									// Process next batch after 2 second delay
									setTimeout(processBatch, 2000);
								} else {
									$('#nm-bulk-log').append('<div style="color: red;">❌ Error in batch ' + currentBatch + ': ' + (response.data.message || 'Unknown error') + '</div>');
									setTimeout(processBatch, 3000); // Continue anyway
								}
							},
							error: function(xhr, status, error) {
								console.error('AJAX Error:', xhr.responseText);
								$('#nm-bulk-log').append('<div style="color: red;">❌ Batch ' + currentBatch + ' failed: ' + error + '</div>');

								// Try to continue with next batch
								setTimeout(processBatch, 3000);
							}
						});
					}

					processBatch();
				});
			});
		</script>

		<style>
			.nm-calendar-stats>div {
				box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
				transition: transform 0.3s;
			}

			.nm-calendar-stats>div:hover {
				transform: translateY(-5px);
			}
		</style>
		<?php
	}

	/**
	 * ✅ NEW: Get content statistics (from V23)
	 */
	private static function get_content_stats() {
		global $wpdb;

		$total_mcqs = wp_count_posts( 'mcq' )->publish;

		$week_ago  = date( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
		$this_week = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'publish' AND post_date >= %s",
				$week_ago
			)
		);

		$scheduled = wp_count_posts( 'mcq' )->future;

		$avg_per_day = $this_week > 0 ? round( $this_week / 7, 1 ) : 0;

		return array(
			'total_mcqs'  => $total_mcqs,
			'this_week'   => $this_week,
			'scheduled'   => $scheduled,
			'avg_per_day' => $avg_per_day,
		);
	}

	/**
	 * ✅ NEW: Render scheduled content (from V23)
	 */
	private static function render_scheduled_content() {
		$scheduled_posts = get_posts(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'future',
				'posts_per_page' => 20,
				'orderby'        => 'date',
				'order'          => 'ASC',
			)
		);

		if ( empty( $scheduled_posts ) ) {
			echo '<p>No scheduled content yet. Use bulk generation with "Schedule for Later" to queue content.</p>';
			return;
		}
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th>Question</th>
					<th>Topic</th>
					<th>Scheduled For</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $scheduled_posts as $post ) :
					$topics      = get_the_terms( $post->ID, 'topic' );
					$topic_names = $topics ? implode( ', ', wp_list_pluck( $topics, 'name' ) ) : '-';
					?>
					<tr>
						<td><strong><?php echo esc_html( $post->post_title ); ?></strong></td>
						<td><?php echo esc_html( $topic_names ); ?></td>
						<td><?php echo get_the_date( 'M j, Y @ g:i a', $post ); ?></td>
						<td>
							<a href="<?php echo get_edit_post_link( $post->ID ); ?>" class="button button-small">Edit</a>
							<a href="<?php echo get_delete_post_link( $post->ID ); ?>" class="button button-small">Delete</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * ✅ NEW: Render the dedicated MCQ Generation Logs page.
	 *
	 * - Reads initial logs via the same NM_Generation_Logger (no new storage layer).
	 * - Filters: severity, event_type, source_type, free-text search.
	 * - Pagination, severity-rated count summary, CSV download, manual purge & clear buttons.
	 * - Auto-delete notice references the retention setting owned by NM_Admin_Settings.
	 */
	public static function render_logs_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		// Load initial page client-side via AJAX so the page itself stays light.
		$stats          = class_exists( 'NM_Generation_Logger' ) ? NM_Generation_Logger::get_log_stats() : array(
			'total'          => 0,
			'by_severity'    => array(),
			'retention_days' => 30,
		);
		$retention_days = isset( $stats['retention_days'] ) ? (int) $stats['retention_days'] : 30;

		$severity_options = class_exists( 'NM_Generation_Logger' ) ? NM_Generation_Logger::get_allowed_severities() : array( 'info', 'success', 'warning', 'error', 'duplicate' );
		$event_options    = class_exists( 'NM_Generation_Logger' ) ? NM_Generation_Logger::get_allowed_event_types() : array( 'info', 'created', 'duplicate', 'error', 'skipped' );
		?>
		<div class="wrap">
			<h1>📋 MCQ Generation Logs</h1>
			<p>
				Live feed of every event the plugin records (cron jobs, manual runs, duplicate detection, errors).
				Use the filters below to slice the log, export the current filter to CSV, or purge old entries.
				Retention is automatically enforced by the weekly cleanup (<strong><?php echo esc_html( $retention_days ); ?> days</strong>)
				— change it from <em>Settings → Uninstall / Logs</em>.
			</p>

			<!-- Summary cards -->
			<div id="nm-logs-summary" class="nm-logs-summary" style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 12px; margin: 16px 0 20px;">
				<?php
				$cards = array(
					'total'      => array( 'label' => 'Total', 'color' => '#2271b1' ),
					'info'       => array( 'label' => 'Info', 'color' => '#50575e' ),
					'success'    => array( 'label' => 'Success', 'color' => '#00a32a' ),
					'warning'    => array( 'label' => 'Warning', 'color' => '#dba617' ),
					'error'      => array( 'label' => 'Error', 'color' => '#d63638' ),
					'duplicate'  => array( 'label' => 'Duplicate', 'color' => '#826eb4' ),
				);
				foreach ( $cards as $key => $card ) :
					$count = isset( $stats['by_severity'][ $key ] ) ? (int) $stats['by_severity'][ $key ] : ( $key === 'total' ? (int) $stats['total'] : 0 );
					?>
					<div class="nm-logs-card" data-severity="<?php echo esc_attr( $key ); ?>" style="background: <?php echo esc_attr( $card['color'] ); ?>; color: #fff; padding: 14px; border-radius: 6px; cursor: pointer; text-align: center;">
						<div style="font-size: 22px; font-weight: 700; line-height: 1.1;"><?php echo esc_html( number_format_i18n( $count ) ); ?></div>
						<div style="font-size: 12px; opacity: .9; text-transform: uppercase;"><?php echo esc_html( $card['label'] ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<!-- Filters + actions -->
			<div class="nm-logs-toolbar" style="background: #fff; padding: 16px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,.06); margin-bottom: 16px;">
				<form id="nm-logs-filter-form" style="display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end;">
					<div>
						<label for="nm-logs-severity" style="display:block; font-weight:600;">Severity</label>
						<select id="nm-logs-severity" name="severity">
							<option value="">All</option>
							<?php foreach ( $severity_options as $s ) : ?>
								<option value="<?php echo esc_attr( $s ); ?>"><?php echo esc_html( ucfirst( $s ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div>
						<label for="nm-logs-event-type" style="display:block; font-weight:600;">Event Type</label>
						<select id="nm-logs-event-type" name="event_type">
							<option value="">All</option>
							<?php foreach ( $event_options as $e ) : ?>
								<option value="<?php echo esc_attr( $e ); ?>"><?php echo esc_html( ucfirst( $e ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div>
						<label for="nm-logs-source" style="display:block; font-weight:600;">Source</label>
						<select id="nm-logs-source" name="source_type">
							<option value="">All</option>
							<option value="cron">Cron</option>
							<option value="topic">Topic</option>
							<option value="news">News</option>
							<option value="feed">Feed</option>
							<option value="duplicate">Duplicate</option>
							<option value="import">Import</option>
							<option value="other">Other</option>
						</select>
					</div>
					<div style="flex: 1 1 220px;">
						<label for="nm-logs-search" style="display:block; font-weight:600;">Search</label>
						<input type="search" id="nm-logs-search" name="search" placeholder="Message, question excerpt, source ref…" style="width: 100%;">
					</div>
					<div>
						<button type="submit" class="button button-primary">Apply Filters</button>
						<button type="button" id="nm-logs-reset" class="button">Reset</button>
					</div>
					<div style="margin-left: auto; display: flex; gap: 8px;">
						<button type="button" id="nm-logs-refresh" class="button">🔄 Refresh</button>
						<button type="button" id="nm-logs-download" class="button">⬇️ Download CSV</button>
						<button type="button" id="nm-logs-purge-now" class="button">🧹 Purge Older Than <?php echo esc_html( $retention_days ); ?>d</button>
						<button type="button" id="nm-logs-clear" class="button button-link-delete" style="color:#b32d2e;">🗑️ Clear All</button>
					</div>
				</form>
			</div>

			<!-- Table -->
			<div class="nm-logs-table-wrap" style="background: #fff; padding: 0; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,.06);">
				<table class="wp-list-table widefat fixed striped" id="nm-logs-table">
					<thead>
						<tr>
							<th style="width: 150px;">Time</th>
							<th style="width: 90px;">Severity</th>
							<th style="width: 90px;">Type</th>
							<th style="width: 90px;">Source</th>
							<th>Message</th>
							<th>Question / Reference</th>
						</tr>
					</thead>
					<tbody id="nm-logs-rows">
						<tr><td colspan="6" style="text-align:center; padding: 24px;">Loading…</td></tr>
					</tbody>
				</table>
				<div class="nm-logs-footer" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 14px; border-top: 1px solid #e5e5e5;">
					<span id="nm-logs-count">—</span>
					<span>
						<button type="button" id="nm-logs-prev" class="button" disabled>« Prev</button>
						<span id="nm-logs-page-info">Page 1</span>
						<button type="button" id="nm-logs-next" class="button" disabled>Next »</button>
					</span>
				</div>
			</div>

			<div id="nm-logs-toast" style="display:none; margin-top: 14px;"></div>
		</div>

		<style>
			.nm-logs-card { transition: transform .15s ease; }
			.nm-logs-card:hover { transform: translateY(-2px); }
			#nm-logs-table td { vertical-align: top; word-break: break-word; }
			.nm-sev-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; color: #fff; }
			.nm-sev-info     { background: #50575e; }
			.nm-sev-success  { background: #00a32a; }
			.nm-sev-warning  { background: #dba617; }
			.nm-sev-error    { background: #d63638; }
			.nm-sev-duplicate{ background: #826eb4; }
			.nm-logs-table-wrap .nm-row-error td { background: #fcf0f1; }
			.nm-logs-table-wrap .nm-row-warning td { background: #fcf9e2; }
		</style>

		<script>
			jQuery(function ($) {
				const $form = $('#nm-logs-filter-form');
				const nonce = '<?php echo esc_js( wp_create_nonce( 'nm_ajax_dashboard' ) ); ?>';
				let state = { page: 1, perPage: 25 };

				function severityClass(sev) {
					return 'nm-sev-badge nm-sev-' + (sev || 'info');
				}

				function toast(msg, type) {
					const cls = (type === 'error') ? 'notice-error' : 'notice-success';
					$('#nm-logs-toast')
						.removeClass()
						.addClass('notice ' + cls)
						.css({ display: 'block', padding: '10px 14px', borderRadius: '4px', marginTop: '14px' })
						.html('<p>' + msg + '</p>');
					setTimeout(() => { $('#nm-logs-toast').fadeOut(); }, 6000);
				}

				function escapeHtml(s) {
					if (s === null || s === undefined) return '';
					return String(s)
						.replace(/&/g, '&')
						.replace(/</g, '<')
						.replace(/>/g, '>')
						.replace(/"/g, '"')
						.replace(/'/g, '&#039;');
				}

				function fetchLogs() {
					const data = Object.assign({}, state, {
						action: 'nm_get_logs_page',
						_ajax_nonce: nonce,
						severity:    $('#nm-logs-severity').val(),
						event_type:  $('#nm-logs-event-type').val(),
						source_type: $('#nm-logs-source').val(),
						search:      $('#nm-logs-search').val(),
					});

					$('#nm-logs-rows').html('<tr><td colspan="6" style="text-align:center; padding:24px;">Loading…</td></tr>');

					$.post(ajaxurl, data, function (resp) {
						if (!resp || !resp.success) {
							$('#nm-logs-rows').html('<tr><td colspan="6" style="text-align:center; padding:24px; color:#b32d2e;">Failed to load logs.</td></tr>');
							return;
						}
						const d = resp.data || {};
						const rows = d.rows || [];
						if (!rows.length) {
							$('#nm-logs-rows').html('<tr><td colspan="6" style="text-align:center; padding:24px;">No log entries match your filters.</td></tr>');
						} else {
							const html = rows.map(function (r) {
								const sev     = r.severity || 'info';
								const rowCls  = (sev === 'error') ? 'nm-row-error'
									: (sev === 'warning') ? 'nm-row-warning' : '';
								const msg     = r.message || ('(' + (r.event_type || '') + ')');
								const excerpt = r.question_excerpt || r.source_ref || '';
								return '<tr class="' + rowCls + '">'
									+ '<td>' + escapeHtml(r.ts) + '</td>'
									+ '<td><span class="' + severityClass(sev) + '">' + escapeHtml(sev) + '</span></td>'
									+ '<td>' + escapeHtml(r.event_type || '') + '</td>'
									+ '<td>' + escapeHtml(r.source_type || '') + '</td>'
									+ '<td>' + escapeHtml(msg) + '</td>'
									+ '<td>' + escapeHtml(excerpt) + '</td>'
									+ '</tr>';
							}).join('');
							$('#nm-logs-rows').html(html);
						}
						const tp     = d.total_pages || 0;
						const total  = d.total || 0;
						state.page   = d.page || 1;
						state.perPage= d.per_page || 25;
						$('#nm-logs-count').text(total + ' total' + (total ? ' — showing page ' + state.page + ' of ' + Math.max(1, tp) : ''));
						$('#nm-logs-page-info').text('Page ' + state.page + ' / ' + Math.max(1, tp));
						$('#nm-logs-prev').prop('disabled', state.page <= 1);
						$('#nm-logs-next').prop('disabled', state.page >= tp);
					}).fail(function () {
						$('#nm-logs-rows').html('<tr><td colspan="6" style="text-align:center; padding:24px; color:#b32d2e;">Server error while loading logs.</td></tr>');
					});
				}

				function fetchAndBustStats() {
					$.post(ajaxurl, { action: 'nm_get_logs_stats', _ajax_nonce: nonce }, function (resp) {
						if (resp && resp.success) {
							const s = resp.data || {};
							$('.nm-logs-card').each(function () {
								const key = $(this).data('severity');
								const v = (key === 'total') ? (s.total || 0) : ((s.by_severity && s.by_severity[key]) ? s.by_severity[key] : 0);
								$(this).find('div').first().text(v.toLocaleString());
							});
						}
					});
				}

				$form.on('submit', function (e) {
					e.preventDefault();
					state.page = 1;
					fetchLogs();
				});

				$('#nm-logs-reset').on('click', function () {
					$('#nm-logs-severity').val('');
					$('#nm-logs-event-type').val('');
					$('#nm-logs-source').val('');
					$('#nm-logs-search').val('');
					state.page = 1;
					fetchLogs();
				});

				$('#nm-logs-refresh').on('click', function () {
					fetchLogs();
					fetchAndBustStats();
				});

				$('.nm-logs-card').on('click', function () {
					const key = $(this).data('severity');
					$('#nm-logs-severity').val(key === 'total' ? '' : key);
					state.page = 1;
					fetchLogs();
				});

				$('#nm-logs-prev').on('click', function () {
					if (state.page > 1) { state.page--; fetchLogs(); }
				});
				$('#nm-logs-next').on('click', function () {
					state.page++; fetchLogs();
				});

				$('#nm-logs-download').on('click', function () {
					const params = new URLSearchParams();
					params.set('action', 'nm_download_logs_csv');
					params.set('_ajax_nonce', nonce);
					params.set('severity',    $('#nm-logs-severity').val() || '');
					params.set('event_type',  $('#nm-logs-event-type').val() || '');
					params.set('source_type', $('#nm-logs-source').val() || '');
					params.set('search',      $('#nm-logs-search').val() || '');
					// Same nonce handling for GET download — wp_ajax endpoint.
					window.location.href = ajaxurl + '?' + params.toString();
				});

				$('#nm-logs-purge-now').on('click', function () {
					if (!confirm('Purge logged events older than the configured retention window?')) return;
					$.post(ajaxurl, { action: 'nm_purge_logs', _ajax_nonce: nonce, mode: 'retention' }, function (resp) {
						if (resp && resp.success) {
							toast('Purged ' + (resp.data.events_deleted || 0) + ' events / ' + (resp.data.runs_deleted || 0) + ' orphan runs.', 'success');
							fetchLogs();
							fetchAndBustStats();
						} else {
							toast('Purge failed: ' + ((resp && resp.data && resp.data.message) || 'unknown error'), 'error');
						}
					}).fail(function () { toast('Server error during purge.', 'error'); });
				});

				$('#nm-logs-clear').on('click', function () {
					if (!confirm('This will TRUNCATE the entire log table. Are you sure?')) return;
					$.post(ajaxurl, { action: 'nm_purge_logs', _ajax_nonce: nonce, mode: 'all' }, function (resp) {
						if (resp && resp.success) {
							toast('Cleared ' + (resp.data.events_deleted || 0) + ' events / ' + (resp.data.runs_deleted || 0) + ' runs.', 'success');
							state.page = 1;
							fetchLogs();
							fetchAndBustStats();
						} else {
							toast('Clear failed: ' + ((resp && resp.data && resp.data.message) || 'unknown error'), 'error');
						}
					}).fail(function () { toast('Server error during clear.', 'error'); });
				});

				// Initial load
				fetchLogs();
			});
		</script>
		<?php
	}
}
?>
