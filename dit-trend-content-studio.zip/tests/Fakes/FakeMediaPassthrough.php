<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Fakes;

use DIT\TrendStudio\Services\Media_Passthrough;

final class FakeMediaPassthrough extends Media_Passthrough
{
    public array $calls = [];

    public function __construct() {}

    public function ensure_media_passthrough(array $article, array $input_data, string $vertical): array
    {
        $this->calls[] = [
            'article'    => $article,
            'input_data' => $input_data,
            'vertical'   => $vertical,
        ];

        return $article;
    }
}
