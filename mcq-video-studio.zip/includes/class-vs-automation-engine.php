<?php

/**
 * Automation Engine
 *
 * Handles daily scheduling of video generation jobs.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Automation_Engine
 *
 * Runs background tasks for video generation.
 *
 * @since 1.0.0
 */
class VS_Automation_Engine
{

    private static $instance = null;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('init', array($this, 'register_cron'));
        add_action('vs_daily_schedule_event', array($this, 'run_daily_scheduler'));
        add_action('vs_process_job_event', array($this, 'process_job'), 10, 1);
        add_action('vs_headless_render_cron', array($this, 'run_headless_render_queue'));
        // @NEW 2026-05-07: Scheduled publishing — pushes completed videos to Buffer at their publish_at time
        add_action('vs_publish_scheduled_cron', array($this, 'run_publish_scheduler'));
        // @FIX (cross-file audit): Single-action AS handler bound to claim-id, so each
        //              scheduled render is auditable in wp_actionscheduler_actions and
        //              dedupe-by-job-id is possible (see `run_headless_render_queue`).
        add_action('mcqvs_render_claim', array($this, 'handle_render_claim_action'), 10, 1);
    }

    public function register_cron()
    {
        if (!wp_get_schedules() || !isset(wp_get_schedules()['mcqvs_five_minutes'])) {
            add_filter('cron_schedules', function ($schedules) {
                $schedules['mcqvs_five_minutes'] = array(
                    'interval' => 300,
                    'display' => __('Every 5 Minutes (MCQVS)', 'mcq-video-studio'),
                );
                return $schedules;
            });
        }

        if (!wp_next_scheduled('vs_daily_schedule_event')) {
            // @FIX: Use the WP timezone for "tomorrow 06:00" so the daily run sticks to the
            //       site's wall clock rather than the server's PHP-default timezone.
				try {
					$tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
				} catch (Exception $e) {
					$tz = new DateTimeZone('UTC');
				}
				$now = new DateTime('now', $tz);
				$anchor = new DateTime('tomorrow 06:00:00', $tz);
				$interval = $now->diff($anchor);
				$seconds_until_anchor = $interval->s + ($interval->days * 86400);
				wp_schedule_event(time() + $seconds_until_anchor, 'daily', 'vs_daily_schedule_event');
        }

        if (function_exists('as_has_scheduled_action') && !as_has_scheduled_action('vs_headless_render_cron')) {
            as_schedule_recurring_action(time() + 120, 300, 'vs_headless_render_cron', array(), 'mcq-video-studio');
        }

        if (function_exists('as_has_scheduled_action') && !as_has_scheduled_action('vs_publish_scheduled_cron')) {
            as_schedule_recurring_action(time() + 300, 900, 'vs_publish_scheduled_cron', array(), 'mcq-video-studio');
        }

        if (!wp_next_scheduled('mcqvs_orphan_kill_cron')) {
            wp_schedule_event(time() + 300, 'mcqvs_five_minutes', 'mcqvs_orphan_kill_cron');
        }
    }

    /**
     * Daily Scheduler: Creates jobs based on rotation matrix.
     * Respects mcqvs_automation_enabled and mcqvs_automation_count settings.
     */
    public function run_daily_scheduler()
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Automation: Skipped (global STOP active)', 'info');
            }
            return;
        }
        $enabled = get_option('mcqvs_automation_enabled', false);
        if (!$enabled) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Automation: Skipped (Disabled via mcqvs_automation_enabled)', 'info');
            }
            return;
        }

        // @FIX 1.5.0 (SSOT): If the NEW Video Scheduler is enabled, it is the single
        // source of truth for auto video generation. Skip the legacy daily scheduler
        // so the two never both create jobs for the same topics on the same run.
        if (class_exists('VS_Video_Scheduler')) {
            $vs_cfg = VS_Video_Scheduler::get_config();
            if (!empty($vs_cfg['enabled'])) {
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log('Automation: Legacy daily scheduler skipped — Video Scheduler is enabled (SSOT).', 'info');
                }
                return;
            }
        }

        $max_daily = absint(get_option('mcqvs_automation_count', 3));
        if ($max_daily < 1) {
            $max_daily = 3;
        }

        $api     = VS_API_Client::init();
        $sources = $api->get_sources('topic');

        if (is_wp_error($sources) || empty($sources)) {
            VS_Error_Logger::get_instance()->log('Automation: Failed to fetch sources', 'error', array('error' => is_wp_error($sources) ? $sources->get_error_message() : 'Empty response'));
            return;
        }

        $job_repo = VS_Job_Repository::init();
        $jobs_scheduled = 0;

        foreach ($sources as $topic) {
            if ($jobs_scheduled >= $max_daily) {
                break;
            }
            if ($topic['count'] < 5) {
                continue;
            }

            $reserved = $api->reserve_questions($topic['id'], null, 5, 'auto_' . uniqid());

            // @FIX: Merge global Studio defaults (branding, voiceover, sfx, hook/cta)
            //       so daily automation renders match preview and manual download exactly.
            $studio_defaults = class_exists('VS_Content_Planner') ? VS_Content_Planner::get_studio_render_defaults() : array(
                'hookText'   => 'Can you score 5/5?',
                'hookVisible' => true,
                'ctaText'    => '',
                'brandName'  => 'Quiz Master',
                'quizName'   => '',
                'logoPath'   => '',
                'voiceover'  => array('enabled' => true, 'provider' => 'edge', 'voice' => (class_exists('VS_Settings') ? VS_Settings::get_next_rotation_voice() : 'en-US-AriaNeural'), 'rate' => 1.0, 'pitch' => 0.0, 'speakHook' => true, 'speakOptions' => true, 'speakAnswer' => true, 'speakCta' => true,                 'answerPhrase' => 'correct answer is', 'webspeechCapturedAudio' => true),
                'sfxEnabled' => true,
            );
            $job_settings = array(
                'topic_name' => $topic['name'] ?? 'Quiz',
                'template'   => get_option('mcqvs_default_template', 'trivia'),
                'save_mode'  => get_option('mcqvs_delivery_mode', 'local'),
                'hookText'   => $studio_defaults['hookText'],
                'hookVisible' => $studio_defaults['hookVisible'],
                'ctaText'    => $studio_defaults['ctaText'],
                'ctaStyle'   => $studio_defaults['ctaStyle'] ?? 'subscribe',
                'brandName'  => $studio_defaults['brandName'],
                'quizName'   => $studio_defaults['quizName'],
                'logoPath'   => $studio_defaults['logoPath'],
                'logoPosition' => $studio_defaults['logoPosition'] ?? 'all',
                'voiceover'  => $studio_defaults['voiceover'],
                'sfxEnabled' => $studio_defaults['sfxEnabled'],
            );

            $model_provider = null;
            $model_id = null;
            if (class_exists('VS_Provider_Registry')) {
                $rotation = VS_Provider_Registry::get_instance()->get_next_model('automation');
                $model_provider = $rotation['provider'];
                $model_id = $rotation['model'];
            }

            $job_id = $job_repo->create_job(array(
                'topic_id'       => $topic['id'],
                'question_count' => 5,
                'platform'       => 'all',
                'status'         => is_wp_error($reserved) ? VS_Job_Status::PENDING : VS_Job_Status::READY_FOR_RENDER,
                'quiz_data'      => is_wp_error($reserved) ? null : wp_json_encode($reserved),
                'settings'       => wp_json_encode($job_settings),
                'scheduled_at'   => gmdate('Y-m-d H:i:s'),
                'model_provider' => $model_provider,
                'model_id'       => $model_id,
            ));

            if (! is_wp_error($job_id)) {
                if (is_wp_error($reserved)) {
                    wp_schedule_single_event(time() + ($jobs_scheduled * 300), 'vs_process_job_event', array($job_id));
                }
                $jobs_scheduled++;

                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log("Automation: Scheduled job {$job_id} for topic {$topic['id']}", 'info');
                }
            } else {
                VS_Error_Logger::get_instance()->log('Automation: Failed to create job', 'error', array('error' => $job_id->get_error_message()));
            }
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log("Automation: Completed. Scheduled {$jobs_scheduled} jobs (max: {$max_daily})", 'info');
        }
    }

    /**
     * Process a single job.
     *
     * @param string $job_id Job ID.
     */
    public function process_job($job_id)
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            return;
        }
        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);

        if (!$job) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} not found", 'warning');
            }
            return;
        }

        if (VS_Job_Status::PENDING !== $job['status'] && VS_Job_Status::READY_FOR_RENDER !== $job['status']) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} has invalid status {$job['status']}", 'warning');
            }
            return;
        }

        $quiz_data = json_decode($job['quiz_data'] ?? '', true);
        if (empty($quiz_data) || !is_array($quiz_data)) {
            $api = VS_API_Client::init();
            $questions = $api->reserve_questions($job['topic_id'], $job['exam_id'], $job['question_count'], $job_id);

            if (is_wp_error($questions)) {
                VS_Error_Logger::get_instance()->log('Automation: Reservation failed', 'error', array('job_id' => $job_id, 'error' => $questions->get_error_message()));
                $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $questions->get_error_message()));
                return;
            }

            $job_repo->update_status($job_id, VS_Job_Status::READY_FOR_RENDER, array(
                'quiz_data' => wp_json_encode($questions)
            ));

            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} reserved " . count($questions) . " questions, marked ready_for_render", 'info');
            }
            return;
        }

        // @NEW 2026-08-03: PENDING job with quiz_data already populated (Content Planner calendar-scheduled).
        // Transition to READY_FOR_RENDER so the render queue picks it up.
        if ($job['status'] === VS_Job_Status::PENDING) {
            $job_repo->update_status($job_id, VS_Job_Status::READY_FOR_RENDER);
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} transitioned PENDING -> READY_FOR_RENDER (calendar-scheduled, quiz_data ready)", 'info');
            }
            // Re-queue to be picked up by render queue on next tick
            wp_schedule_single_event(time() + 10, 'vs_process_job_event', array($job_id));
            return;
        }

        $headless_enabled = get_option('mcqvs_headless_rendering_enabled', false);
        if ($headless_enabled && class_exists('VS_Headless_Renderer')) {
            if (!$job_repo->acquire_job_lock($job_id, 300)) {
                VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} already locked, skipping.", 'info');
                return;
            }

            $renderer = VS_Headless_Renderer::get_instance();
            $result = $renderer->render_job($job_id);
            if (is_wp_error($result)) {
                $job_repo->release_job_lock($job_id);
                VS_Error_Logger::get_instance()->log('Automation: Headless render spawn failed', 'error', array('job_id' => $job_id, 'error' => $result->get_error_message()));
                $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $result->get_error_message()));
            } else {
                $job_repo->update_status($job_id, VS_Job_Status::RENDERING);
                VS_Error_Logger::get_instance()->log("Automation: Headless render spawned for job {$job_id}", 'info');
            }
        } else {
            if ($job['status'] !== VS_Job_Status::READY_FOR_RENDER) {
                $job_repo->update_status($job_id, VS_Job_Status::READY_FOR_RENDER);
            }
            VS_Error_Logger::get_instance()->log("Automation: Job {$job_id} queued for browser auto-runner", 'info');
        }
    }

    /**
     * WP-Cron hook: Processes ready_for_render jobs via headless Chrome.
     * Runs every 5 minutes. Picks up jobs and spawns Node.js render process.
     */
    public function run_headless_render_queue()
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.queue',
                    'skipped',
                    'headless-render-cron',
                    'Render queue skipped: global STOP active.',
                    'info',
                    array('_type' => 'pipeline')
                );
            }
            return;
        }
        if (!class_exists('VS_Headless_Renderer')) {
            return;
        }

        $headless_enabled = get_option('mcqvs_headless_rendering_enabled', false);
        if (!$headless_enabled) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.queue',
                    'skipped',
                    'headless-render-cron',
                    'Headless rendering is disabled, skipping render queue',
                    'info',
                    array('headless_enabled' => $headless_enabled)
                );
            }
            return;
        }

        // @FIX (cross-file audit 2026-07-08): Honor the dashboard's manual reset pause.
        //              When the user clicks "Reset Stuck Pipeline" we set a transient
        //              pause window so the very next cron tick doesn't immediately
        //              re-pick the rows the user just reset.
        $pause_until = (int) get_transient('mcqvs_render_queue_pause_until');
        if ($pause_until > time()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.queue',
                    'skipped',
                    'headless-render-cron',
                    'Render queue paused by manual reset until ' . gmdate('c', $pause_until),
                    'info',
                    array('pause_until' => gmdate('c', $pause_until))
                );
            }
            return;
        }

        $concurrency = absint(get_option('mcqvs_render_concurrency', 1));
        $job_repo = VS_Job_Repository::init();
        $renderer = VS_Headless_Renderer::get_instance();

        // @FIX (cross-file audit): Bind the queue to the active `parent_batch_id` when one
        //       is published. This stops the 5-minute AS cycle from spawning renders for
        //       `READY_FOR_RENDER` rows left behind by a previous retry cycle (the cause
        //       of "Automation Scheduled A vs Spawn ran B" mismatches between
        //       `vs_daily_schedule_event` and `vs_headless_render_cron`).
        $active_batch = get_option('mcqvs_content_plan_pending_batches', '');
        $pending = $job_repo->get_jobs_by_status_for_batch(
            VS_Job_Status::READY_FOR_RENDER,
            $concurrency,
            is_string($active_batch) ? $active_batch : null
        );

        // @FIX (cross-file audit 2026-07-08): Honor the per-job "manual reset cooldown"
        //       stamped by the dashboard's "Reset Stuck Pipeline" button. Without this,
        //       a user-initiated reset would silently re-spawn the same row on the very
        //       next 5-min tick (because the row stays in `READY_FOR_RENDER`).
        if (! empty($pending)) {
            $filtered = array();
            foreach ($pending as $job) {
                $cooldown_until = (int) get_transient('mcqvs_reset_cooldown_' . $job['job_id']);
                if ($cooldown_until > time()) {
                    continue;
                }
                $filtered[] = $job;
            }
            $pending = $filtered;
        }

        // ── Render completion sweep ──
        // MUST RUN BEFORE the auto-cleaner. Reaps every RENDERING job whose
        // Node process has exited. Catches renders that completed (status file
        // has "completed") but were never finalized because the liveness check
        // is a one-shot AS action at +30s (too early for any real render).
        // Runs every 5-min tick. Uses reap_dead_render() which already handles:
        //   - reading the node status JSON → finalize_server_render()
        //   - log-scan recovery fallback
        //   - auto-retry on external kill (exit=0, retry_count<2)
        //   - deterministic failure with node error tail
        // Does not interfere with alive processes (reap returns early).
        // @FIX 2026-07-20: Sweep BEFORE auto-cleaner. Previously the auto-cleaner
        //       (clear_stuck_jobs) ran first and blindly bulk-updated RENDERING
        //       rows to FAILED using a blanket timestamp threshold, without checking
        //       PID liveness or per-job timeout. The sweep never got to see jobs
        //       that were still alive at 91% progress.
        if (class_exists('VS_Headless_Renderer')) {
            $sweep_jobs = $job_repo->get_jobs_by_status(VS_Job_Status::RENDERING, 20);
            foreach ($sweep_jobs as $s_job) {
                // @FIX 2026-08-09: Spawn grace. claim_job_for_render() flips the row to
                //       RENDERING in the DB first and only THEN schedules the
                //       mcqvs_render_claim AS action which actually spawns render-node.js
                //       and stamps mcqvs_render_pid_. A concurrent queue tick sweeping
                //       RENDERING rows inside that window saw a "rendering job with no pid"
                //       and failed it ~1s after claim (render_process_died pid=0, no
                //       completion marker, node log missing). Skip rows whose started_at
                //       is younger than the 180s spawn grace window.
                $sweep_started_at = strtotime((string) ($s_job['started_at'] ?? '') . ' UTC');
                if ($sweep_started_at > 0 && (time() - $sweep_started_at) < 180) {
                    continue;
                }
                VS_Headless_Renderer::reap_dead_render($s_job['job_id']);
            }
        }

        // @FIX 2026-07-09: AUTO-CLEANER MUST RUN ON EVERY 5-min TICK
        //       (regardless of whether there are pending renders to claim).
        //       Run AFTER the completion sweep so recently-finalized jobs
        //       are not swept as stuck.
        $stuck_minutes = (int) get_option('mcqvs_stuck_threshold_minutes', 0);
        if ($stuck_minutes <= 0) {
            $render_timeout = max(60, absint(get_option('mcqvs_render_timeout', 900)));
            if ($render_timeout < 600) {
                $render_timeout = 900;
            }
            $stuck_minutes = max(15, (int) ceil($render_timeout * 2 / 60));
        }
        $job_repo->clear_stuck_jobs($stuck_minutes, 120);

        // @FIX 2026-08-07: Auto-recover jobs the auto-cleaner killed by mistake
        // (calendar-scheduled PENDING jobs swept while waiting for scheduled_at).
        // Only rows carrying the [stuck-fail@ marker are touched (bounded by
        // retry_count). PENDING recoveries re-schedule vs_process_job_event so
        // the PENDING->READY_FOR_RENDER transition still fires at the right time.
        $recovered = $job_repo->recover_failed_jobs();
        foreach ($recovered as $rj) {
            if ($rj['status'] !== VS_Job_Status::PENDING) {
                continue;
            }
            $cron_time = strtotime($rj['scheduled_at'] . ' UTC');
            if ($cron_time > time()) {
                wp_schedule_single_event($cron_time, 'vs_process_job_event', array($rj['job_id']));
            } elseif (function_exists('as_enqueue_async_action')) {
                as_enqueue_async_action('vs_process_job_event', array($rj['job_id']), 'mcq-video-studio');
            } else {
                wp_schedule_single_event(time(), 'vs_process_job_event', array($rj['job_id']));
            }
        }

        // @FIX 2026-08-07: Enforce a TRUE concurrency cap. `mcqvs_render_concurrency`
        //       limits how many renders may be ACTIVE at once, not just how many are
        //       claimed per 5-min tick. Without this guard, every tick claimed the next
        //       READY_FOR_RENDER job even while a previous render was still running, so
        //       renders overlapped despite concurrency=1. Count jobs currently in
        //       RENDERING state; when the cap is reached, skip claiming new renders this
        //       tick. The completion sweep, auto-cleaner and recovery above still run.
        $active_rendering = $job_repo->get_jobs_by_status(VS_Job_Status::RENDERING, 200);
        $active_count = is_array($active_rendering) ? count($active_rendering) : 0;
        $slots_left = max(0, $concurrency - $active_count);
        if ($slots_left <= 0) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.queue',
                    'skipped',
                    'headless-render-cron',
                    "Render queue at concurrency cap: {$active_count}/{$concurrency} active. No new claims this tick.",
                    'info',
                    array('active_rendering' => $active_count, 'concurrency' => $concurrency)
                );
            }
            return;
        }
        if (is_array($pending) && count($pending) > $slots_left) {
            $pending = array_slice($pending, 0, $slots_left);
        }

        if (empty($pending)) {
            // @VERIFICATION 2026-07-06: Log when no jobs found for monitoring
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.queue',
                    'completed',
                    'headless-render-cron',
                    'Headless render queue: No READY_FOR_RENDER jobs found',
                    'info',
                    array(
                        'active_batch' => is_string($active_batch) ? $active_batch : null,
                        'concurrency' => $concurrency,
                    )
                );
            }
            return;
        }

        // @VERIFICATION 2026-07-06: Cross-check batch integrity before processing
        if (is_string($active_batch) && $active_batch !== '') {
            $tracker = get_option('mcqvs_batch_tracker', array());
            // The tracker is keyed by integer batch index, so the active UUID is stored
            // under the `_batch_id` sentinel key. Validate against that instead of the
            // old `empty($tracker)` test (which passed for any non-empty tracker and
            // therefore never caught a genuinely stale batch).
            $tracked_batch = is_array($tracker) ? (string) ($tracker['_batch_id'] ?? '') : '';
            if ($tracked_batch === '' || $tracked_batch !== $active_batch) {
                // @FIX (ROOT CAUSE 2026-07-17): The Master Reset (and any opt-key nuke)
                //        wipes `mcqvs_batch_tracker` but leaves `mcqvs_content_plan_pending_batches`
                //        set, so every subsequent tick logs a spurious "no tracker entry"
                //        warning and the integrity check never becomes meaningful. Since we
                //        only reach here when an active batch exists AND the queue just
                //        found its READY_FOR_RENDER jobs (stamped with that same
                //        parent_batch_id in the claim path), the active batch is genuine.
                //        Re-seed the tracker's `_batch_id` sentinel so the warning stops and
                //        future mismatches are real. Only warn when the tracker points at a
                //        DIFFERENT batch (genuine rotation we should surface).
                if ($tracked_batch !== '' && $tracked_batch !== $active_batch) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.batch_mismatch',
                        'warning',
                        'headless-render-cron',
                        "Active batch {$active_batch} differs from tracked batch {$tracked_batch}. Possible stale batch option.",
                        'warning',
                        array('active_batch' => $active_batch, 'tracked_batch' => $tracked_batch)
                    );
                }
                if (!is_array($tracker)) {
                    $tracker = array();
                }
                $tracker['_batch_id'] = $active_batch;
                update_option('mcqvs_batch_tracker', $tracker);
                $tracked_batch = $active_batch;
            }
        }

        VS_Error_Logger::get_instance()->log_pipeline(
            'render.queue',
            'started',
            'headless-render-cron',
            'Headless render queue: Found ' . count($pending) . ' jobs ready to render.',
            'info',
            array(
                'pending_count' => count($pending),
                'concurrency'   => $concurrency,
                'claim_batch'   => is_string($active_batch) ? $active_batch : null,
                'job_ids'       => array_column($pending, 'job_id'),
            )
        );

        foreach ($pending as $job) {
            $job_id = $job['job_id'];

            if ($renderer->is_render_running($job_id)) {
                continue;
            }

            $existing = $job_repo->get_job($job_id);
            if ($existing && $existing['status'] === VS_Job_Status::RENDERING) {
                $recovery = $this->recover_completed_render($job_id);
                if ($recovery['action'] === 'completed') {
                    $extra = $recovery['video_url'] ? array('video_url' => $recovery['video_url']) : array();
                    $job_repo->update_status($job_id, VS_Job_Status::COMPLETED, $extra);
                    $job_repo->release_job_lock($job_id);
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.recovery',
                        'completed',
                        $job_id,
                        "Headless: Recovered completed render for {$job_id} from log",
                        'info',
                        array('job_id' => $job_id, 'video_url' => $recovery['video_url'] ?? '')
                    );
                    continue;
                }
                if ($recovery['action'] === 'failed') {
                    $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $recovery['error']));
                    $job_repo->release_job_lock($job_id);
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.recovery',
                        'failed',
                        $job_id,
                        "Headless: Process for {$job_id} died, marking failed: {$recovery['error']}",
                        'warning',
                        array('job_id' => $job_id, 'error' => $recovery['error'])
                    );
                    continue;
                }
                // @FIX (cross-file audit): recovery['action'] === 'unknown' means the log scan
                //              found no completion marker. We now fail the job with a clear reason.
                //              Previously this block referenced undefined $log_content which
                //              caused PHP notices and masked the real error.
                $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => 'Render process died: no_completion_marker'));
                $job_repo->release_job_lock($job_id);
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.recovery',
                    'failed',
                    $job_id,
                    "Headless: Process for {$job_id} died, cause: no_completion_marker",
                    'warning',
                    array('job_id' => $job_id, 'reason' => 'no_completion_marker')
                );
                continue;
            }

            // @FIX (ROOT CAUSE 2026-07-17): Action Scheduler can run multiple
            //       `vs_headless_render_cron` workers concurrently. Use atomic DB-level
            //       claim instead of transient lock to prevent race conditions.
            //       claim_job_for_render() returns true only if the job was in
            //       READY_FOR_RENDER status and successfully transitioned to RENDERING.
            if (!$job_repo->claim_job_for_render($job_id)) {
                // Another worker already claimed this job; skip.
                continue;
            }

            if (function_exists('as_unschedule_action')) {
                // Cancel any stale AS task for the same job so we don't double-spawn.
                @as_unschedule_action('mcqvs_render_claim', array($job_id), 'mcq-video-studio');
            }
            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time(), 'mcqvs_render_claim', array($job_id), 'mcq-video-studio');
            }

            VS_Error_Logger::get_instance()->log_pipeline(
                'render.spawned',
                'completed',
                $job_id,
                "Render claim scheduled for job {$job_id}",
                'info',
                array('job_id' => $job_id, 'claim_batch' => is_string($active_batch) ? $active_batch : null)
            );
        }

    }

    /**
     * @FIX (cross-file audit): Single-action AS handler that wraps `VS_Headless_Renderer::render_job()`
     *              with claim validation. If the claim batch was rotated while the action was queued,
     *              the action exits early instead of double-spawning — the precise cause of the observed
     *              "scheduled A vs rendered B" mismatches in headless-render-cron pipeline logs.
     *
     * Hooked from `register_cron()`.
     *
     * @param string $job_id
     */
    public function handle_render_claim_action($job_id)
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            return;
        }
        if (!is_string($job_id) || $job_id === '') {
            return;
        }
        if (!class_exists('VS_Job_Repository') || !class_exists('VS_Headless_Renderer')) {
            return;
        }
        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (!$job) {
            return;
        }
        // Only spawn for the expected lifecycle stage.
        // @FIX 2026-07-22: With atomic claim in run_headless_render_queue(), the job
        // is already RENDERING when this AS action fires. Accept that state.
        if (!in_array($job['status'], array(VS_Job_Status::READY_FOR_RENDER, VS_Job_Status::PENDING, VS_Job_Status::RENDERING), true)) {
            VS_Error_Logger::get_instance()->log("Render claim AS: job {$job_id} no longer ready (status={$job['status']}). Dropping.", 'info');
            return;
        }
        // @FIX 2026-07-22: If already RENDERING, another worker claimed it — just exit.
        if ($job['status'] === VS_Job_Status::RENDERING) {
            VS_Error_Logger::get_instance()->log("Render claim AS: job {$job_id} already RENDERING (atomic claim). Proceeding.", 'info');
        }
        // @FIX (cross-file audit 2026-07-08): Honor the per-job "manual reset cooldown"
        //       stamped by the dashboard's "Reset Stuck Pipeline" button. Without this,
        //       a leftover claim action (scheduled before the user clicked Reset) would
        //       re-promote the row back to `rendering` and make the reset invisible.
        $cooldown_until = (int) get_transient('mcqvs_reset_cooldown_' . $job_id);
        if ($cooldown_until > time()) {
            VS_Error_Logger::get_instance()->log("Render claim AS: job {$job_id} in manual-reset cooldown until " . gmdate('c', $cooldown_until) . ". Dropping.", 'info');
            return;
        }
        // @FIX: If the active batch rotated, drop the claim ONLY for jobs that
        //       BELONG to a planner batch (have a non-empty parent_batch_id).
        //       Automation-created and AS-worker-created jobs have
        //       parent_batch_id = NULL and must always be claimable regardless
        //       of whether a content planner batch is active.
        $active_batch = get_option('mcqvs_content_plan_pending_batches', '');
        $stamped_batch = (string) ($job['parent_batch_id'] ?? '');
        if (is_string($active_batch) && $active_batch !== '' && $stamped_batch !== '') {
            if ($stamped_batch !== $active_batch) {
                VS_Error_Logger::get_instance()->log("Render claim AS: job {$job_id} batch={$stamped_batch} no longer active (active={$active_batch}). Dropping.", 'info');
                return;
            }
        }
        if (!$job_repo->acquire_job_lock($job_id, 300)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.claim_lock',
                    'failed',
                    $job_id,
                    "Render claim lock failed for {$job_id}: another process holds the lock",
                    'warning',
                    array('job_id' => $job_id, 'reason' => 'lock_acquisition_failed')
                );
            }
            return;
        }
        $renderer = VS_Headless_Renderer::get_instance();
        $result = $renderer->render_job($job_id);
        if (is_wp_error($result)) {
            $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $result->get_error_message()));
            $job_repo->release_job_lock($job_id);
            VS_Error_Logger::get_instance()->log('Automation: Headless render claim failed', 'error', array('job_id' => $job_id, 'error' => $result->get_error_message()));
        } else {
            VS_Error_Logger::get_instance()->log("Automation: Render claim AS spawned job {$job_id}", 'info', array('job_id' => $job_id));
        }
    }

    /**
     * WP-Cron hook: Publishes completed videos to Buffer at their scheduled publish_at time.
     * Runs every 15 minutes. Picks up completed jobs whose publish_at has arrived
     * and that haven't been published yet.
     *
     * Pipeline: ready_for_render → rendering → completed → [THIS STEP] → Buffer
     *
     * @NEW 2026-05-07
     */
    public function run_publish_scheduler()
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'publish.scheduler',
                    'skipped',
                    'cron',
                    'Publish scheduler skipped: global STOP active.',
                    'info',
                    array('_type' => 'pipeline')
                );
            }
            return;
        }
        $buffer_token = get_option('mcqvs_buffer_access_token', '');
        $auto_publish = get_option('mcqvs_auto_publish_enabled', false);
        if (empty($buffer_token) || !$auto_publish) {
            // @VERIFICATION: Log skipped runs for monitoring
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'publish.scheduler',
                    'skipped',
                    'cron',
                    'Publish scheduler skipped: token=' . (empty($buffer_token) ? 'missing' : 'ok') . ', auto_publish=' . ($auto_publish ? 'true' : 'false'),
                    'info',
                    array('buffer_token_set' => !empty($buffer_token), 'auto_publish_enabled' => $auto_publish)
                );
            }
            return;
        }

        if (!class_exists('VS_Job_Repository')) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline('publish.scheduler', 'failed', 'cron', 'VS_Job_Repository not found', 'error');
            }
            return;
        }

        $job_repo = VS_Job_Repository::init();
        $jobs = $job_repo->get_jobs_ready_for_publish(20);

        if (empty($jobs)) {
            // @VERIFICATION: Log when no jobs found for metrics
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline('publish.scheduler', 'completed', 'cron', 'No jobs ready for publish', 'info', array('jobs_count' => 0));
            }
            return;
        }

        VS_Error_Logger::get_instance()->log_pipeline(
            'publish.scheduler',
            'started',
            'cron',
            'Publish scheduler: Found ' . count($jobs) . ' videos ready for publishing.',
            'info',
            array('jobs_count' => count($jobs), 'job_ids' => array_column($jobs, 'job_id'))
        );

        $success_count = 0;
        $failed_count = 0;
        $skipped_count = 0;

        foreach ($jobs as $job) {
            $job_id = $job['job_id'];
            $video_url = $job['video_url'];

            if (empty($video_url)) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'publish.skip',
                    'failed',
                    $job_id,
                    "Job {$job_id} has no video_url",
                    'error',
                    array('job_id' => $job_id, 'video_url' => $video_url)
                );
                $failed_count++;
                continue;
            }

            // @VERIFICATION: Check publish_at alignment before push
            $job_settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
            if (!empty($job_settings['_publish_computed_at']) && !empty($job_settings['_publish_start_date'])) {
                $stored_publish_at = $job['publish_at'] ?? '';
                $expected_start = $job_settings['_publish_start_date'];
                $stored_offset = $job_settings['_publish_offset'] ?? 0;
                
                // Recalculate to verify alignment
                $recalc_publish_at = VS_Content_Planner::compute_publish_at($expected_start, $job_settings['publish_time'] ?? '09:00', $job_settings['publish_frequency'] ?? 'daily', $stored_offset);
                if ($recalc_publish_at && $stored_publish_at !== $recalc_publish_at) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'publish.mismatch',
                        'warning',
                        $job_id,
                        "publish_at mismatch: stored={$stored_publish_at}, recalculated={$recalc_publish_at}",
                        'warning',
                        array('job_id' => $job_id, 'stored_publish_at' => $stored_publish_at, 'recalc_publish_at' => $recalc_publish_at)
                    );
                }
            }

            $result = $this->push_job_to_buffer($job_id, $video_url, $job);

            if (is_wp_error($result)) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'buffer.push',
                    'failed',
                    $job_id,
                    "Buffer push failed for job {$job_id}: " . $result->get_error_message(),
                    'error',
                    array('job_id' => $job_id, 'video_url' => $video_url, 'error' => $result->get_error_message())
                );
                $failed_count++;
            } elseif (is_array($result) && !empty($result['skipped'])) {
                $skip_reason = $result['reason'] ?? 'already_published';
                VS_Error_Logger::get_instance()->log_pipeline(
                    'buffer.push',
                    'skipped',
                    $job_id,
                    "Buffer push skipped for job {$job_id}: {$skip_reason}",
                    'info',
                    array('job_id' => $job_id, 'skip_reason' => $skip_reason)
                );
                $skipped_count++;
            } else {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'buffer.push',
                    'completed',
                    $job_id,
                    "Buffer push succeeded for job {$job_id}",
                    'info',
                    array('job_id' => $job_id, 'video_url' => $video_url, 'result' => $result)
                );
                $success_count++;

                // @NEW 2026-08-13 (Phase 4): Back-link the published video to the source
                // article(s)/MCQ page(s) so articles embed the Short and social posts link
                // back to the site.
                do_action( 'mcqvs_video_job_published', $job_id, $video_url );
            }
        }

        // @VERIFICATION: Summary metrics for each cron run
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'publish.scheduler',
                'completed',
                'cron',
                "Publish scheduler complete: {$success_count} success, {$failed_count} failed, {$skipped_count} skipped",
                'info',
                array('success' => $success_count, 'failed' => $failed_count, 'skipped' => $skipped_count, 'total' => count($jobs))
            );
        }
    }

    /**
     * Push a completed job to Buffer.
     * Delegates to VS_Buffer_Client::push_job_to_buffer for shared cron + AJAX path.
     *
     * @NEW 2026-05-07
     */
    private function push_job_to_buffer($job_id, $video_url, $job)
    {
        return VS_Buffer_Client::push_job_to_buffer($job_id, $video_url, $job);
    }

    /**
     * Reconcile a 'rendering' job whose child PID has died.
     * @FIX 2026-07-10: Migrated from flat-file log grep to wp_vs_logs DB query.
     *              render.js now sends all operational output through reportToWP()
     *              into the unified plugin logging system. Recovery queries the
     *              vs_logs table for RENDER_SERVICE entries with the matching job_id
     *              to determine final render state.
     *
     * @param string $job_id
     * @return array { action: 'completed'|'failed'|'unknown', video_url?: string, error?: string }
     */
    private function recover_completed_render($job_id)
    {
        return self::recover_completed_render_public($job_id);
    }

    /**
     * @FIX 2026-07-10: Public shim — queries wp_vs_logs for RENDER_SERVICE entries
     *              instead of grepping a flat log file.
     *
     * Return shape: array with `action` key ('completed'|'failed'|'unknown'),
     * optional `video_url` and `error`.
     *
     * @param string $job_id
     * @return array
     */
    public static function recover_completed_render_public($job_id)
    {
        global $wpdb;
        $logs_table = $wpdb->prefix . 'vs_logs';

        // Check if the logs table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$logs_table}'");
        if (!$table_exists) {
            return array('action' => 'unknown');
        }

        // Search for render.finished entries (completed render)
        $sql = $wpdb->prepare(
            "SELECT context_json FROM {$logs_table}
             WHERE source = 'RENDER_SERVICE'
               AND context_json LIKE %s
               AND context_json LIKE %s
             ORDER BY ts DESC
             LIMIT 5",
            '%' . $wpdb->esc_like('"stage":"render.finished"') . '%',
            '%' . $wpdb->esc_like($job_id) . '%'
        );
        $results = $wpdb->get_col($sql);

        if (!empty($results)) {
            foreach ($results as $row) {
                $ctx = json_decode($row, true);
                if (!is_array($ctx)) continue;
                $msg = $ctx['_raw_message'] ?? '';
                if (stripos($msg, 'status=completed') !== false) {
                    return array('action' => 'completed');
                }
                if (stripos($msg, 'status=failed') !== false || stripos($msg, 'status=cancelled') !== false) {
                    return array('action' => 'failed', 'error' => 'Render reported non-completed status');
                }
            }
        }

        // Check for fatal/render.timeout entries (failed render)
        $sql_fatal = $wpdb->prepare(
            "SELECT context_json FROM {$logs_table}
             WHERE source = 'RENDER_SERVICE'
               AND (context_json LIKE %s OR context_json LIKE %s)
               AND context_json LIKE %s
             ORDER BY ts DESC
             LIMIT 3",
            '%' . $wpdb->esc_like('"stage":"render.fatal"') . '%',
            '%' . $wpdb->esc_like('"stage":"render.timeout"') . '%',
            '%' . $wpdb->esc_like($job_id) . '%'
        );
        $fatal_results = $wpdb->get_col($sql_fatal);

        if (!empty($fatal_results)) {
            $errors = array();
            foreach ($fatal_results as $row) {
                $ctx = json_decode($row, true);
                if (is_array($ctx) && !empty($ctx['_raw_message'])) {
                    $errors[] = $ctx['_raw_message'];
                }
            }
            return array(
                'action' => 'failed',
                'error'  => 'Render error: ' . implode('; ', array_slice($errors, 0, 2)),
            );
        }

        return array('action' => 'unknown');
    }
}