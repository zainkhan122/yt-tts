<?php
namespace AiSocialCollage;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Logger {

    public static function get_valid_levels() {
        return array_keys( Config::get_log_levels() );
    }

    public static function is_valid_level( $level ) {
        return in_array( strtolower( $level ), self::get_valid_levels(), true );
    }

	public static function log( $action, $job_id = null, $request_payload = '', $response_code = '', $raw_response = '', $execution_time = 0.0, $log_level = 'info' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'ai_collage_logs';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return;
		}

		$level = self::is_valid_level( $log_level ) ? strtolower( $log_level ) : Config::LOG_LEVEL_INFO;

		$stored_payload = is_string( $request_payload ) && self::is_json_string( $request_payload )
			? $request_payload
			: maybe_serialize( $request_payload );

		$stored_response = is_string( $raw_response ) && self::is_json_string( $raw_response )
			? $raw_response
			: maybe_serialize( $raw_response );

		$wpdb->insert(
			$table_name,
			[
				'job_id' => $job_id,
				'action' => sanitize_text_field( $action ),
				'request_payload' => $stored_payload,
				'response_code' => sanitize_text_field( $response_code ),
				'raw_response' => $stored_response,
				'execution_time' => (float) $execution_time,
				'log_level' => $level,
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s' ]
		);
	}

	private static function is_json_string( $value ) {
		if ( ! is_string( $value ) || $value === '' ) {
			return false;
		}
		$first = $value[0];
		return $first === '{' || $first === '[';
	}

    public static function info( $action, $job_id = null, $request_payload = '', $response_code = '', $raw_response = '', $execution_time = 0.0 ) {
        self::log( $action, $job_id, $request_payload, $response_code, $raw_response, $execution_time, Config::LOG_LEVEL_INFO );
    }

    public static function debug( $action, $job_id = null, $request_payload = '', $response_code = '', $raw_response = '', $execution_time = 0.0 ) {
        self::log( $action, $job_id, $request_payload, $response_code, $raw_response, $execution_time, Config::LOG_LEVEL_DEBUG );
    }

    public static function error( $action, $job_id = null, $request_payload = '', $response_code = '', $raw_response = '', $execution_time = 0.0 ) {
        self::log( $action, $job_id, $request_payload, $response_code, $raw_response, $execution_time, Config::LOG_LEVEL_ERROR );
    }

    public static function warning( $action, $job_id = null, $request_payload = '', $response_code = '', $raw_response = '', $execution_time = 0.0 ) {
        self::log( $action, $job_id, $request_payload, $response_code, $raw_response, $execution_time, Config::LOG_LEVEL_WARNING );
    }
}
