<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;

if (!defined('ABSPATH')) {
    exit;
}

class Custom_Client implements AIProviderInterface
{
    use AI_Network_Trait;

    const DEFAULT_MODEL = 'glm-4';
    const CHAT_ENDPOINT = '/chat/completions';

    private static array $MODEL_MAX_TOKENS = [
        'glm-4' => 32768,
        'glm-4-plus' => 32768,
        'glm-4-air' => 32768,
        'glm-4-airx' => 32768,
        'glm-4-long' => 32768,
        'glm-4-flash' => 32768,
        'glm-4-flashx' => 32768,
        'glm-4v' => 32768,
        'glm-4v-plus' => 32768,
        'glm-5' => 32768,
        'moonshot-v1-8k' => 32768,
        'moonshot-v1-32k' => 32768,
        'moonshot-v1-128k' => 32768,
        'kimi-latest' => 32768,
        'MiniMax-Text-01' => 32768,
        'minimax-text-01' => 32768,
        'minimax-m2' => 32768,
        'abab6.5s-chat' => 32768,
        'abab7-chat-preview' => 32768,
        'doubao-1.5-pro-32k' => 32768,
        'doubao-1.5-pro-256k' => 32768,
        'deepseek-chat' => 32768,
        'deepseek-reasoner' => 32768,
        'deepseek-v3' => 32768,
        'deepseek-v4' => 32768,
        'deepseek-r1' => 32768,
        'qwen3-235b-a22b' => 32768,
        'qwen3-32b' => 32768,
        'qwen3-30b-a3b' => 32768,
        'qwen2.5-72b-instruct' => 32768,
        'qwen2.5-32b-instruct' => 32768,
        'qwen2.5-14b-instruct' => 32768,
        'qwen2.5-7b-instruct' => 32768,
        'gemma-4' => 32768,
        'gemma-3' => 32768,
    ];

    private static array $MODELS_NO_RESPONSE_FORMAT = [
        'moonshot-v1-8k',
        'moonshot-v1-32k',
        'moonshot-v1-128k',
        'MiniMax-Text-01',
        'minimax-text-01',
        'abab6.5s-chat',
        'abab7-chat-preview',
        'z-ai/glm-5.1:reasoning',
        'google/gemma-4-31b-it',
        'google/gemma-3-27b-it',
        'minimaxai/minimax-m2.7',
    ];

    private string $api_key;

    private string $api_url;

    protected Logger $logger;

    private PromptSchemaBuilder $promptSchema;

    private VisualManifestService $visuals;

    private array $provider_config;

    private string $current_model;

    private string $original_model;

    private array $fallback_models;

    private bool $fallback_enabled;

    private string $model_override;

    public function __construct(
        string $api_key,
        Logger $logger,
        string $api_url = '',
        string $provider_slug = 'custom',
        array $provider_config = []
    ) {
        $this->provider_slug = \sanitize_key($provider_slug);
        $this->api_key = \trim($api_key);

        if ($api_url !== '') {
            $this->api_url = \rtrim(\trim($api_url), '/');
        } else {
            $profile_url = $provider_config['api_url'] ?? '';
            if ($profile_url !== '') {
                $this->api_url = \rtrim(\trim($profile_url), '/');
            } else {
                $this->api_url = \rtrim(\trim((string) \get_option('dit_ts_custom_api_url', '')), '/');
            }
        }

        $this->logger = $logger;
        $this->promptSchema = new PromptSchemaBuilder($logger);
        $this->visuals = new VisualManifestService();
        $this->provider_config = $provider_config;
        $this->model_override = '';

        $models = (array) ($provider_config['models'] ?? []);
        $models = array_values($models);
        if (!empty($models) && isset($models[0]['model_id'])) {
            $this->current_model = (string) $models[0]['model_id'];
            $this->fallback_models = array_map(function ($m) {
                return (string) ($m['model_id'] ?? '');
            }, array_slice($models, 1));
            $this->fallback_models = array_filter($this->fallback_models, function ($id) {
                return $id !== '';
            });
        } else {
            $this->current_model = self::get_model_id();
            $this->fallback_models = [];
        }

        $this->original_model = $this->current_model;
        $this->fallback_enabled = !empty($provider_config['fallback_enabled']);
    }

    public function set_model_override(string $model_id): void
    {
        $model_id = \trim($model_id);
        if ($model_id === '') {
            return;
        }
        $this->model_override = $model_id;
        $this->current_model = $model_id;
        $this->fallback_models = [];

        $models = (array) ($this->provider_config['models'] ?? []);
        foreach ($models as $i => $m) {
            $mid = (string) ($m['model_id'] ?? '');
            if ($mid === $model_id) {
                $this->fallback_models = array_map(function ($m) {
                    return (string) ($m['model_id'] ?? '');
                }, array_slice($models, $i + 1));
                $this->fallback_models = array_filter($this->fallback_models, function ($id) {
                    return $id !== '';
                });
                break;
            }
        }
    }

    private function get_max_tokens_for_model(string $model): int
    {
        $requested = (int) \get_option('dit_ts_ai_max_output_tokens', 32768);

        foreach (self::$MODEL_MAX_TOKENS as $pattern => $cap) {
            if ($model === $pattern || stripos($model, $pattern) === 0) {
                return min($requested, $cap);
            }
        }

        $base = explode('-', str_replace('/', '-', $model))[0];
        foreach (self::$MODEL_MAX_TOKENS as $pattern => $cap) {
            if (stripos($pattern, $base) === 0 || stripos($base, $pattern) === 0) {
                return min($requested, $cap);
            }
        }

        return min($requested, 32768);
    }

    private function model_supports_response_format(string $model): bool
    {
        if (in_array($model, self::$MODELS_NO_RESPONSE_FORMAT, true)) {
            return false;
        }
        foreach (self::$MODELS_NO_RESPONSE_FORMAT as $pattern) {
            if (stripos($model, $pattern) === 0) {
                return false;
            }
        }
        $no_format_prefixes = ['moonshot', 'minimax', 'abab'];
        $base = explode('-', str_replace('/', '-', $model))[0];
        return !in_array(strtolower($base), $no_format_prefixes, true);
    }

    public function get_provider_slug(): string
    {
        return $this->provider_slug;
    }

    public function get_provider_config(): array
    {
        return $this->provider_config;
    }

    public function get_current_model(): string
    {
        return $this->current_model;
    }

	private function increment_call_count(): void
	{
		\DIT\TrendStudio\Infrastructure\Usage_Tracker::increment($this->provider_slug);
	}

    public static function get_api_key(): string
    {
        $key = (string) \get_option('dit_ts_custom_api_key', '');
        if ($key !== '') {
            return $key;
        }
        $providers = self::get_custom_providers();
        $default_id = (string) \get_option('dit_ts_custom_default_provider', '');
        if ($default_id !== '' && isset($providers[$default_id])) {
            return (string) ($providers[$default_id]['api_key'] ?? '');
        }
        $first = reset($providers);
        if (!empty($first)) {
            return (string) ($first['api_key'] ?? '');
        }
        return '';
    }

    public static function get_api_url(): string
    {
        $url = (string) \get_option('dit_ts_custom_api_url', '');
        if ($url !== '') {
            return $url;
        }
        $providers = self::get_custom_providers();
        $default_id = (string) \get_option('dit_ts_custom_default_provider', '');
        if ($default_id !== '' && isset($providers[$default_id])) {
            return (string) ($providers[$default_id]['api_url'] ?? '');
        }
        $first = reset($providers);
        if (!empty($first)) {
            return (string) ($first['api_url'] ?? '');
        }
        return '';
    }

    public static function get_model_id(): string
    {
        $custom = (string) \get_option('dit_ts_custom_model_custom', '');
        if ($custom !== '') {
            return $custom;
        }
        $flat_model = (string) \get_option('dit_ts_custom_model', self::DEFAULT_MODEL);
        if ($flat_model !== '' && $flat_model !== self::DEFAULT_MODEL) {
            return $flat_model;
        }
        $providers = self::get_custom_providers();
        $default_id = (string) \get_option('dit_ts_custom_default_provider', '');
        if ($default_id !== '' && isset($providers[$default_id])) {
            $models = (array) ($providers[$default_id]['models'] ?? []);
            if (!empty($models) && isset($models[0]['model_id'])) {
                return (string) $models[0]['model_id'];
            }
        }
        $first = reset($providers);
        if (!empty($first)) {
            $models = (array) ($first['models'] ?? []);
            if (!empty($models) && isset($models[0]['model_id'])) {
                return (string) $models[0]['model_id'];
            }
        }
        return (string) \get_option('dit_ts_custom_model', self::DEFAULT_MODEL);
    }

    public static function get_custom_providers(): array
    {
        $raw = \get_option('dit_ts_custom_providers', []);
        if (is_string($raw)) {
            $raw = \json_decode($raw, true);
        }
        if (!\is_array($raw)) {
            return [];
        }
        $indexed = [];
        foreach ($raw as $profile) {
            if (!empty($profile['id'])) {
                $indexed[$profile['id']] = $profile;
            }
        }
        return $indexed;
    }

    public function get_model(): string
    {
        return $this->current_model;
    }

    public function test_connection(): array
    {
        $url = $this->api_url . self::CHAT_ENDPOINT;
        if (empty($this->api_url)) {
            throw new AI_Exception('Custom Provider API URL is not configured.');
        }

        $model = $this->current_model ?: self::get_model_id();

        $response = $this->call_api_with_retry($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => \wp_json_encode([
                'model' => $model,
                'messages' => [['role' => 'user', 'content' => 'Ping']],
                'max_tokens' => 5,
                'temperature' => 0,
                'stream' => false,
            ]),
            'timeout' => 30,
        ]);

        if (\is_wp_error($response)) {
            throw new AI_Exception('Connection failed: ' . $response->get_error_message());
        }

        $code = (int) \wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $raw = (string) \wp_remote_retrieve_body($response);
            throw new AI_Exception('API returned error code ' . $code . ': ' . \substr($raw, 0, 300));
        }

        return [
            'status' => 'connected',
            'model' => $model . ' @ ' . $this->api_url,
            'provider' => $this->provider_slug,
        ];
    }

    public function probe_quota(): bool
    {
        try {
            $result = $this->test_connection();
            return ($result['status'] ?? '') === 'connected';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function generate(array $prompt_data): array
    {
        return $this->generateFromResearch($prompt_data, []);
    }

    public function generateFromResearch(array $promptData, array $researchData): array
    {
        $visual_manifest = [];
        $output_schema = '';

        $bundle = $this->promptSchema->build_writing_bundle(
            $promptData,
            $researchData,
            $visual_manifest,
            $output_schema,
            $this->visuals,
            10
        );

        $web_search_type = $this->provider_config['web_search_config']['type'] ?? 'none';
        $enable_web_search = !empty($this->provider_config['enable_web_search']) && $web_search_type !== 'none';

        $system_prompt = (string) ($bundle['system_prompt'] ?? '');
        if ($enable_web_search) {
            $system_prompt .= PromptSchemaBuilder::get_web_search_instructions($web_search_type);
        }

        $this->logger->info('Calling Custom Provider API for writing', [
            'model' => $this->current_model,
            'url' => $this->api_url,
            'provider' => $this->provider_slug,
            'web_search' => $enable_web_search ? $web_search_type : 'off',
        ]);

        $messages = [
            ['role' => 'system', 'content' => $system_prompt],
            ['role' => 'user', 'content' => $bundle['user_prompt']],
        ];

        return $this->chat_completion($messages, true, $bundle['output_schema'] ?? '', $visual_manifest, $enable_web_search, $web_search_type);
    }

    public function generateCustomJson(string $prompt): array
    {
        $messages = [
            ['role' => 'system', 'content' => 'Return VALID JSON ONLY.'],
            ['role' => 'user', 'content' => $prompt],
        ];

        return $this->chat_completion($messages, true);
    }

    private function chat_completion(
        array $messages,
        bool $json_mode = true,
        string $output_schema = '',
        array $visual_manifest = [],
        bool $enable_web_search = false,
        string $web_search_type = 'none'
    ): array {
        if (empty($this->api_url)) {
            throw new AI_Exception('Custom Provider API URL is not configured.');
        }

        // @MODIFIED 2026-07-17 - Force-enable per-provider model iteration (see patch (d)).
        // Previously gated on $this->fallback_enabled, which meant a custom provider whose config
        // had fallback_enabled=false would never loop beyond the primary model, silently throwing
        // all_models_exhausted=true on the first error even when fallback_models were registered.
        // Per requirement "each model must be used in each custom provider before moving to next",
        // the retry bound now always includes every registered fallback model, independent of the
        // per-provider opt-in flag. The flag is retained on the instance only for backward-compatible
        // introspection; it no longer constrains iteration.
        $max_model_attempts = 1 + count($this->fallback_models);
        $max_model_attempts = max(1, min($max_model_attempts, 10));

        $remaining_fallbacks = $this->fallback_models;
        $attempt = 0;
        $last_exception = null;
        $original_model = $this->current_model;

	$active_web_search = $enable_web_search;
	$active_web_search_type = $web_search_type;

	while ($attempt < $max_model_attempts) {
		$attempt++;

		if ($attempt > 1) {
			$active_web_search = $enable_web_search;
			$active_web_search_type = $web_search_type;
		}

		$model_max = $this->get_max_tokens_for_model($this->current_model);

		$body = [
			'model' => $this->current_model,
			'messages' => $messages,
			'stream' => false,
			'temperature' => 0.7,
			'max_tokens' => $model_max,
		];

		$supports_rf = $this->model_supports_response_format($this->current_model);
		if ($json_mode && $supports_rf) {
			$body['response_format'] = ['type' => 'json_object'];
		}

		if ($active_web_search && $active_web_search_type !== 'none') {
			$body['tools'] = $this->build_web_search_tool($active_web_search_type);
		}

            $url = $this->api_url . self::CHAT_ENDPOINT;

            $response = $this->call_api_with_retry($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->api_key,
                    'Content-Type' => 'application/json',
                ],
                'body' => \wp_json_encode($body),
                'timeout' => 120,
            ]);

            if (\is_wp_error($response)) {
                throw new AI_Exception('Custom Provider API request failed: ' . $response->get_error_message());
            }

            $code = (int) \wp_remote_retrieve_response_code($response);
            $raw_body = \wp_remote_retrieve_body($response);

            if ($code !== 200) {
                $slug = $this->provider_slug;
                $error_info = ['error_type' => 'unknown_error', 'quota_bucket' => 'unknown', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class)) {
                    $headers = \wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse($slug, $code, $raw_body, (array) $headers);
                }

                $is_rpd = ($error_info['quota_bucket'] === API_Error_Parser::RPD || $error_info['error_type'] === 'daily_quota');
                $is_quota_zero = !empty($error_info['is_quota_zero']);

                // 1. If it's a 400 error, try soft-healing retries on the SAME model first
                if ($code === 400) {
                    $parsed_error = \json_decode($raw_body, true);
                    $err_msg = strtolower((string) ($parsed_error['error']['message'] ?? $raw_body));

                    $looks_like_max_tokens = (
                        strpos($err_msg, 'max_tokens') !== false
                        || strpos($err_msg, 'max output') !== false
                        || strpos($err_msg, 'max output tokens') !== false
                        || strpos($err_msg, 'exceeds the maximum') !== false
                        || strpos($err_msg, 'exceeds model') !== false
                    );

                    if ($looks_like_max_tokens && $model_max > 2048) {
                        $halved = (int) floor($model_max / 2);
                        $this->logger->warning("{$this->provider_slug} max_tokens rejected for {$this->current_model}; retrying with {$halved}.", [
                            'provider' => $this->provider_slug,
                            'original_max' => $model_max,
                            'reduced_max' => $halved,
                        ]);

                        $body['max_tokens'] = $halved;
                        if ($enable_web_search) {
                            unset($body['tools']);
                        }

                        $response = $this->call_api_with_retry($url, [
                            'headers' => [
                                'Authorization' => 'Bearer ' . $this->api_key,
                                'Content-Type' => 'application/json',
                            ],
                            'body' => \wp_json_encode($body),
                            'timeout' => 120,
                        ]);

                        if (!\is_wp_error($response)) {
                            $code = (int) \wp_remote_retrieve_response_code($response);
                            $raw_body = \wp_remote_retrieve_body($response);
                            if ($code === 200) {
                                goto parse_success_response;
                            }
                        }
                    }

                    $looks_like_tools_json_conflict = (
                        $active_web_search && $json_mode && $supports_rf
                        && (strpos($err_msg, 'tool') !== false || strpos($err_msg, 'web_search') !== false)
                        && (strpos($err_msg, 'response') !== false || strpos($err_msg, 'json') !== false || strpos($err_msg, 'schema') !== false)
                    );

                    if ($looks_like_tools_json_conflict && $attempt === 1) {
                        $this->logger->warning("{$this->provider_slug} tools+JSON conflict detected; retrying without tools.", [
                            'provider' => $this->provider_slug,
                            'code' => $code,
                        ]);
                        $active_web_search = false;
                        $active_web_search_type = 'none';
                        $messages = $this->strip_web_search_from_messages($messages);
                        continue;
                    }

                    $looks_like_tool_type_rejected = (
                        $active_web_search
                        && (strpos($err_msg, "input should be 'function'") !== false
                            || strpos($err_msg, "expected 'function'") !== false
                            || strpos($err_msg, 'unknown variant') !== false
                            || strpos($err_msg, 'tool type') !== false
                            || strpos($err_msg, 'unsupported tool') !== false
                            || strpos($err_msg, 'invalid tool') !== false)
                    );

                    if ($looks_like_tool_type_rejected && $attempt === 1) {
                        $this->logger->warning("{$this->provider_slug} tool type rejected by model {$this->current_model}; retrying without tools.", [
                            'provider' => $this->provider_slug,
                            'model' => $this->current_model,
                            'code' => $code,
                        ]);
                        $active_web_search = false;
                        $active_web_search_type = 'none';
                        $messages = $this->strip_web_search_from_messages($messages);
                        continue;
                    }

                    $looks_like_tool_rejection_generic = (
                        $active_web_search && $attempt === 1
                        && !$looks_like_tools_json_conflict
                        && !$looks_like_tool_type_rejected
                        && !$looks_like_max_tokens
                        && (strpos($err_msg, 'tool') !== false
                            || strpos($err_msg, 'web_search') !== false
                            || strpos($err_msg, 'function') !== false)
                    );

                    if ($looks_like_tool_rejection_generic) {
                        $this->logger->warning("{$this->provider_slug} 400 with tools enabled; retrying without tools as precaution.", [
                            'provider' => $this->provider_slug,
                            'model' => $this->current_model,
                            'code' => $code,
                            'error_preview' => \substr($err_msg, 0, 200),
                        ]);
                        $active_web_search = false;
                        $active_web_search_type = 'none';
                        $messages = $this->strip_web_search_from_messages($messages);
                        continue;
                    }

                    $looks_like_response_format_rejection = (
                        $json_mode && $supports_rf
                        && (strpos($err_msg, 'response_format') !== false
                            || strpos($err_msg, 'json_object') !== false
                            || strpos($err_msg, 'json mode') !== false
                            || strpos($err_msg, 'structured output') !== false
                            || strpos($err_msg, 'failed to deserialize') !== false
                            || strpos($err_msg, 'unknown variant') !== false)
                    );

                    if ($looks_like_response_format_rejection && $attempt === 1) {
                        $this->logger->warning("{$this->provider_slug} response_format rejected; retrying without json_object.", [
                            'provider' => $this->provider_slug,
                            'model' => $this->current_model,
                        ]);
                        $supports_rf = false;
                        continue;
                    }

                    // Auto-detect route mismatch 400 error
                    if (preg_match('#available on (/[vV]\d+/chat/completions)#i', $raw_body, $route_match)) {
                        $new_route = $route_match[1];
                        $base_url = preg_replace('#/[vV]\d+/chat/completions$#', '', $this->api_url);
                        $corrected_url = $base_url . $new_route;
                        if ($corrected_url !== $url) {
                            $this->logger->warning("{$this->provider_slug} 400: model {$this->current_model} requires route {$new_route}; retrying.", [
                                'provider' => $this->provider_slug,
                                'model' => $this->current_model,
                                'original_url' => $url,
                                'corrected_url' => $corrected_url,
                            ]);
                            $url = $corrected_url;
                            $response = $this->call_api_with_retry($url, [
                                'headers' => [
                                    'Authorization' => 'Bearer ' . $this->api_key,
                                    'Content-Type' => 'application/json',
                                ],
                                'body' => \wp_json_encode($body),
                                'timeout' => 120,
                            ]);
                            if (!\is_wp_error($response)) {
                                $code = (int) \wp_remote_retrieve_response_code($response);
                                $raw_body = \wp_remote_retrieve_body($response);
                                if ($code === 200) {
                                    goto parse_success_response;
                                }
                            }
                        }
                    }
                }

                // 2. If it is NOT an RPD (daily limit) or Quota Zero error, and we have fallback models left, shift and continue!
                // @MODIFIED 2026-07-17 - Force-enable per-provider model iteration.
                // Previously gated on $this->fallback_enabled (a per-provider opt-in flag), which silently
                // skipped remaining models and threw all_models_exhausted=true on the very first error.
                // Per requirement "each model must be used in each custom provider before moving to next":
                // remaining models MUST be tried unless the failure is a hard provider-level block
                // (RPD daily limit or quota-zero), regardless of the per-provider fallback toggle.
                if (!$is_rpd && !$is_quota_zero && !empty($remaining_fallbacks)) {
                    $next_model = array_shift($remaining_fallbacks);
                    $this->logger->warning("{$this->provider_slug} error {$code}; trying fallback model {$next_model}.", [
                        'provider' => $this->provider_slug,
                        'model' => $this->current_model,
                        'next_model' => $next_model,
                        'code' => $code,
                    ]);
                    $this->current_model = $next_model;
                    continue;
                }

                // 3. Otherwise (either RPD/QuotaZero error or fallback exhausted), throw AI_Exception to bubble up to cross-provider fallback!
                // @MODIFIED 2026-07-17 - $all_exhausted now reflects ONLY model pool state, not the per-provider opt-in flag.
                // Provider-level flag can't falsely short-circuit the cross-provider fallback decision anymore.
                $all_exhausted = empty($remaining_fallbacks);
                $reason = $is_rpd ? 'daily_quota_exhausted' : (class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry');
                $qpm = class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager');
                $consecutive = $qpm ? \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_consecutive_daily_quota_429s($slug) : 0;

                $this->logger->error("{$this->provider_slug} API error {$code}, no further local model fallbacks possible. Throwing exception.", [
                    'code' => $code,
                    'body' => \substr($raw_body, 0, 300),
                    'is_rpd' => $is_rpd,
                    'all_exhausted' => $all_exhausted
                ]);

                throw new AI_Exception("{$this->provider_slug} API error ({$code}): " . ($error_info['error_status'] ?: \substr($raw_body, 0, 200)), [
                    'reason' => $reason,
                    'provider' => $slug,
                    'consecutive_count' => $consecutive + 1,
                    'error_class' => $error_info['error_type'],
                    'quota_bucket' => $error_info['quota_bucket'],
                    'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                    'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                    'http_code' => $code,
                    'error_body' => \substr($raw_body, 0, 500),
                    'all_models_exhausted' => $all_exhausted,
                ]);
            }

            parse_success_response:

            $slug = $this->provider_slug;
            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success($slug, $this->current_model);
            }

$data = \json_decode($raw_body, true);
        $message = $data['choices'][0]['message'] ?? [];
        $content = $message['content'] ?? '';

        if (empty($content) && !empty($message['tool_calls'])) {
            $tool_args = [];
            foreach ($message['tool_calls'] as $tc) {
                $args = $tc['function']['arguments'] ?? '';
                if ($args !== '') {
                    $tool_args[] = $args;
                }
            }
            if (!empty($tool_args)) {
                $merged = implode("\n", $tool_args);
                $decoded = \json_decode($merged, true);
                if (\is_array($decoded)) {
                    $this->logger->info("{$this->provider_slug} model returned tool_calls instead of content; extracting arguments.", [
                        'provider' => $this->provider_slug,
                        'model' => $this->current_model,
                        'tool_call_count' => count($message['tool_calls']),
                    ]);
                    $content = $merged;
                }
            }
        }

        if (empty($content)) {
            throw new AI_Exception('Empty response from ' . $this->provider_slug . ' API');
        }

            $parsed = Sanitizer::parse((string) $content);

            if (!\is_array($parsed)) {
                throw new AI_Exception(
                    'Failed to parse ' . $this->provider_slug . ' JSON response',
                    [
                        'sanitizer_error' => Sanitizer::get_last_error(),
                        'content_preview' => \substr((string) $content, 0, 1200),
                    ]
                );
            }

            $sources_index = $this->extract_web_search_sources($data);
            if (!empty($sources_index)) {
                $parsed['_sources_index'] = $sources_index;
                $parsed['_web_search_results'] = $data['web_search_info'] ?? [];
            }

            $parsed['_actual_provider'] = $this->provider_slug;
            $parsed['_actual_model'] = $this->current_model;

            $result = $this->apply_visual_manifest($parsed, $visual_manifest);
            $this->current_model = $original_model;
            return $result;
        }

        $this->current_model = $original_model;
        throw new AI_Exception(
            "All models exhausted for provider {$this->provider_slug} after {$attempt} attempts.",
            [
                'provider' => $this->provider_slug,
                'all_models_exhausted' => true,
                'attempts' => $attempt,
            ]
        );
    }

private function build_web_search_tool(string $type): array
    {
        switch ($type) {
            case 'zhipuai':
                $search_engine = $this->provider_config['web_search_config']['search_engine'] ?? 'search_pro';
                $search_count = (int) ($this->provider_config['web_search_config']['search_count'] ?? 10);
                return [[
                    'type' => 'web_search',
                    'web_search' => [
                        'enable' => true,
                        'search_engine' => $search_engine,
                        'search_result' => true,
                        'search_prompt' => 'Verify facts using {search_result} and cite with [N].',
                        'count' => $search_count,
                    ],
                ]];

            case 'kimi':
                return [[
                    'type' => 'web_search',
                    'web_search' => [
                        'enable' => true,
                        'search_result' => true,
                    ],
                ]];

            case 'minimax':
                return [[
                    'type' => 'web_search',
                    'web_search' => [
                        'enable' => true,
                    ],
                ]];

default:
                return [];
            }
    }

    private function strip_web_search_from_messages(array $messages): array
    {
        $marker = '## Web Search Instructions';
        foreach ($messages as $i => $msg) {
            if (($msg['role'] ?? '') === 'system' && strpos($msg['content'] ?? '', $marker) !== false) {
                $parts = explode($marker, $msg['content'], 2);
                $messages[$i]['content'] = rtrim($parts[0]);
            }
        }
        return $messages;
    }

    private function extract_web_search_sources(array $response_data): array
    {
        $type = $this->provider_config['web_search_config']['type'] ?? 'none';
        $sources = [];

        if ($type === 'zhipuai') {
            $results = $response_data['web_search_info']['search_result'] ?? [];
            foreach ($results as $i => $r) {
                if (!empty($r['link'])) {
                    $sources[] = [
                        'id' => $i + 1,
                        'label' => $r['title'] ?? ('Source ' . ($i + 1)),
                        'url' => $r['link'],
                    ];
                }
            }
        } elseif ($type === 'kimi') {
            if (!empty($response_data['citations'])) {
                foreach ($response_data['citations'] as $i => $c) {
                    $url = $c['url'] ?? $c['link'] ?? '';
                    $label = $c['title'] ?? $c['name'] ?? ('Source ' . ($i + 1));
                    if ($url !== '') {
                        $sources[] = [
                            'id' => $i + 1,
                            'label' => $label,
                            'url' => $url,
                        ];
                    }
                }
            }
        } elseif ($type === 'minimax') {
            $results = $response_data['search_results'] ?? [];
            foreach ($results as $i => $r) {
                $url = $r['url'] ?? $r['link'] ?? '';
                $label = $r['title'] ?? $r['name'] ?? ('Source ' . ($i + 1));
                if ($url !== '') {
                    $sources[] = [
                        'id' => $i + 1,
                        'label' => $label,
                        'url' => $url,
                    ];
                }
            }
        }

        return $sources;
    }

    private function apply_visual_manifest(array $article, array $visual_manifest): array
    {
        if (empty($visual_manifest)) {
            return $article;
        }
        return $this->visuals->apply($article, $visual_manifest);
    }
}
