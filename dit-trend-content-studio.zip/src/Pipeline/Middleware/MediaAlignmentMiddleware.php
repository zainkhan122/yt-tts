<?php

namespace DIT\TrendStudio\Pipeline\Middleware;

use DIT\TrendStudio\Contracts\MiddlewareInterface;
use DIT\TrendStudio\Content\Media\MediaMatcher;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MediaAlignmentMiddleware
 *
 * Applies semantic matching to the dress queue for Fashion PK vertical.
 * @MODIFIED 2026-05-06 - Phase 3 Structured Blocks Support: builds dress_queue from
 * visual_ref blocks in sections when structured_blocks mode is active.
 */
class MediaAlignmentMiddleware implements MiddlewareInterface
{
    public function handle(array $data, array $context, callable $next): array
    {
        $vertical = $context['vertical'] ?? 'general';

        if ($vertical === 'fashion_pk' && !empty($data['sections'])) {
            $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');

            if ($pmode === 'structured_blocks') {
                // Build a virtual dress_queue from visual_ref IDs in the section blocks
                $data = $this->align_structured_blocks($data, $context);
            } else {
                // Token matcher mode: reorder dress_queue populated by SwapVisualsMiddleware
                $dress_queue = $data['dress_queue'] ?? [];
                if (!empty($dress_queue)) {
                    $data['dress_queue'] = MediaMatcher::match_fashion_dress_slots($data['sections'], $dress_queue);
                }
            }
        }

        return $next($data);
    }

    /**
     * Reorder visual_ref IDs in structured_blocks mode to match H3 slots.
     * Builds a virtual queue from visual_ref entries, runs MediaMatcher, then
     * remaps the IDs in the blocks.
     */
    private function align_structured_blocks(array $data, array $context): array
    {
        $vmap = $data['_source_visual_map'] ?? [];
        if (empty($vmap)) {
            return $data;
        }

        // Extract visual_ref IDs in order of appearance and build a virtual dress_queue
        $visual_ids = [];
        $visual_positions = []; // section_idx => block_idx => visual_id
        foreach ($data['sections'] as $s_idx => $section) {
            $blocks = $section['blocks'] ?? [];
            foreach ($blocks as $b_idx => $block) {
                if (($block['type'] ?? '') === 'visual_ref') {
                    $id = (int) ($block['id'] ?? -1);
                    if ($id >= 0) {
                        $visual_ids[] = $id;
                        $visual_positions[] = ['s' => $s_idx, 'b' => $b_idx, 'id' => $id];
                    }
                }
            }
        }

        if (count($visual_ids) < 2) {
            return $data;
        }

        // Build virtual dress_queue with hint text from source_visual_map
        $virtual_queue = [];
        foreach ($visual_ids as $id) {
            $token = '[VISUAL_' . $id . ']';
            $meta  = $vmap[$token] ?? [];
            $hint  = trim(
                (string) (($meta['heading'] ?? '') . ' ' . ($meta['context'] ?? '') . ' ' . ($meta['alt'] ?? '') . ' ' . ($meta['preceding_p'] ?? ''))
            );
            $virtual_queue[] = [
                'src'         => (string) ($meta['url'] ?? ''),
                'alt'         => (string) ($meta['alt'] ?? ''),
                'hint'        => $hint,
                'visual_idx'  => $id,
            ];
        }

        // Run MediaMatcher to get reordered queue
        $reordered = MediaMatcher::match_fashion_dress_slots($data['sections'], $virtual_queue);

        // Remap visual_ref IDs in the sections based on reordered queue
        $reordered_ids = [];
        foreach ($reordered as $img) {
            $reordered_ids[] = (int) ($img['visual_idx'] ?? -1);
        }

        $assign_idx = 0;
        foreach ($data['sections'] as $s_idx => &$section) {
            $blocks = &$section['blocks'];
            if (!is_array($blocks)) {
                continue;
            }
            foreach ($blocks as $b_idx => &$block) {
                if (($block['type'] ?? '') === 'visual_ref' && isset($reordered_ids[$assign_idx])) {
                    $block['id'] = $reordered_ids[$assign_idx];
                    $assign_idx++;
                }
            }
            unset($block);
        }
        unset($section);

        return $data;
    }
}
