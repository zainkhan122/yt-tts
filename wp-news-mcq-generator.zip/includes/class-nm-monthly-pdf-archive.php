<?php
/**
 * Monthly PDF Archive Generator
 *
 * Generates a downloadable, professionally formatted monthly PDF of MCQs for each
 * configured topic (parents + optional sub-topics) and maintains ONE evergreen page
 * per topic (e.g. /geography-mcqs-with-answers/). Each month the page's SEO title,
 * content and "download this month" CTA are updated, with an accordion of past months'
 * PDFs. Built on Dompdf (vendored under includes/lib/vendor).
 *
 * @package wp-news-mcq-generator
 * @since   9.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Monthly_PDF_Archive {

	/** Enable/disable the whole archive system. */
	const OPTION_ENABLED = 'nm_pdf_archive_enabled';

	/** Selected topic term IDs (parents + sub-topics). */
	const OPTION_TOPICS = 'nm_pdf_archive_topics';

	/** Cron hook (runs daily, generates once per topic per month). */
	const CRON_HOOK = 'nm_pdf_archive_cron';

	/** Meta key storing the topic term id on each PDF archive page. */
	const META_TOPIC = '_nm_pdf_topic_term_id';

	/** Meta key storing the list of generated months [{year,month,file,url,count}]. */
	const META_MONTHS = '_nm_pdf_months';

	/** @NEW 9.5.6: Meta key storing the complete-bank volume index [{vol,file,url,count,from,to,frozen,updated}]. */
	const META_VOLUMES = '_nm_pdf_volumes';

	/** @NEW 9.5.6: Meta key storing the 'Y-m' the volumes were last refreshed (1st-of-month trigger). */
	const META_VOLUMES_MONTH = '_nm_pdf_volumes_month';

	/** @NEW 9.5.6: Option key for max questions per complete-bank volume (default 200, clamped 100–300). */
	const OPTION_VOLUME_CAP = 'nm_pdf_volume_cap';

	/** Sub-directory under uploads where PDFs are stored. */
	const DIR = 'nm-monthly-pdfs';

	/** Singleton. */
	private static $instance = null;

	public static function init() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( self::CRON_HOOK, array( $this, 'run_cron' ) );
		// Inject Article + FAQ schema on PDF archive pages via Rank Math.
		add_filter( 'rank_math/json_ld', array( $this, 'inject_archive_schema' ), 99, 2 );
	}

	/* ------------------------------------------------------------------
	 * Settings helpers
	 * ---------------------------------------------------------------- */

	public static function is_enabled() {
		return (bool) get_option( self::OPTION_ENABLED, 0 );
	}

	/** @return int[] Selected topic term IDs. */
	public static function get_topics() {
		$t = get_option( self::OPTION_TOPICS, array() );
		return is_array( $t ) ? array_values( array_filter( array_map( 'absint', $t ) ) ) : array();
	}

	/**
	 * @NEW 9.5.6: Max questions per complete-bank volume. Default 200 — safely inside
	 * Dompdf's memory/render comfort zone on typical hosting; clamped to 100–300.
	 *
	 * @return int
	 */
	public static function volume_cap() {
		$cap = (int) get_option( self::OPTION_VOLUME_CAP, 200 );
		return max( 100, min( 300, $cap ) );
	}

	/**
	 * @NEW 9.5.6: Quality gate shared by monthly + complete-bank collectors — reported/
	 * flagged MCQs must never reach a downloadable file (a wrong answer in a PDF a user
	 * already saved cannot be hotfixed).
	 *
	 * @return array WP_Query meta_query clause.
	 */
	public static function quality_gate_meta_query() {
		return array(
			'relation' => 'OR',
			array(
				'key'     => 'mcq_reported',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => 'mcq_reported',
				'value'   => 'yes',
				'compare' => '!=',
			),
		);
	}

	/**
	 * Compute the target (year, month) for the scheduled cron.
	 * Defaults to the PREVIOUS completed calendar month (site timezone) so that on the
	 * 1st we compile the month that just finished — never an empty current month.
	 *
	 * @return array [year, month]
	 */
	public static function target_month() {
		$now = current_time( 'timestamp' );
		$y   = (int) date( 'Y', $now );
		$m   = (int) date( 'n', $now ) - 1; // previous month
		if ( $m < 1 ) {
			$m = 12;
			$y--;
		}
		return array( $y, $m );
	}

	/* ------------------------------------------------------------------
	 * Cron
	 * ---------------------------------------------------------------- */

	/**
	 * Daily cron. For each configured topic, if this (topic, month) hasn't been
	 * generated yet, build the PDF + update the evergreen page. This catches up
	 * even if WP-Cron is delayed.
	 */
	public function run_cron() {
		if ( ! self::is_enabled() ) {
			return;
		}
		list( $year, $month ) = self::target_month();
		$topics = self::get_topics();
		if ( empty( $topics ) ) {
			return;
		}
		foreach ( $topics as $term_id ) {
			$this->ensure_archive( $term_id, $year, $month );
			// @NEW 9.5.6: Complete-bank volumes — refreshed once per calendar month
			// (first cron run on/after the 1st; daily cron gives automatic catch-up).
			self::maybe_refresh_volumes( $term_id );
		}
	}

	/**
	 * @NEW 9.5.6: Refresh a topic's complete-bank volumes if not yet done this
	 * calendar month. Runs from the daily cron, so the refresh lands on the 1st
	 * (or the first day WP-Cron actually fires after it).
	 *
	 * @param int $term_id
	 * @return array|false Result array when a refresh ran, false when skipped.
	 */
	public static function maybe_refresh_volumes( $term_id ) {
		$term = get_term( $term_id, 'topic' );
		if ( ! $term || is_wp_error( $term ) ) {
			return false;
		}
		$page_id = self::ensure_page( $term );
		if ( ! $page_id ) {
			return false;
		}
		$current_month = date( 'Y-m', current_time( 'timestamp' ) );
		if ( get_post_meta( $page_id, self::META_VOLUMES_MONTH, true ) === $current_month ) {
			return false; // already refreshed this month
		}
		return self::ensure_complete_volumes( $term_id );
	}

	/**
	 * @NEW 9.5.6: Build/refresh the COMPLETE question-bank volumes for a topic.
	 *
	 * Append-only chronological volumes (user-approved design):
	 *  - Vol 1 = oldest {cap} questions, Vol 2 = next {cap}, and so on.
	 *  - A volume that reaches the cap is FROZEN: its file is never rebuilt, so its
	 *    URL and bytes stay stable forever (bookmarks/backlinks keep working).
	 *  - Only the LAST (open) volume is regenerated as new questions arrive —
	 *    same filename each time, file overwritten (stable URL).
	 *  - Membership is anchored to post ID order, so boundaries never shift.
	 *
	 * @param int $term_id Parent topic term id.
	 * @return array { page_id, volumes, built, total_questions } or { error }.
	 */
	public static function ensure_complete_volumes( $term_id ) {
		$term = get_term( $term_id, 'topic' );
		if ( ! $term || is_wp_error( $term ) ) {
			return array( 'error' => 'Invalid topic term.' );
		}
		$page_id = self::ensure_page( $term );
		if ( ! $page_id ) {
			return array( 'error' => 'Could not create archive page.' );
		}

		$mcqs = static::collect_all_mcqs( $term_id );
		if ( empty( $mcqs ) ) {
			update_post_meta( $page_id, self::META_VOLUMES_MONTH, date( 'Y-m', current_time( 'timestamp' ) ) );
			return array( 'page_id' => $page_id, 'volumes' => 0, 'built' => 0, 'total_questions' => 0 );
		}

		$cap    = self::volume_cap();
		$chunks = self::partition_volumes( $mcqs, $cap );

		$volumes = get_post_meta( $page_id, self::META_VOLUMES, true );
		if ( ! is_array( $volumes ) ) {
			$volumes = array();
		}

		$dir = self::pdf_dir( $term );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$total_vols = count( $chunks );
		$built      = 0;

		foreach ( $chunks as $i => $chunk ) {
			$vol      = $i + 1;
			$is_full  = count( $chunk ) >= $cap;
			$filename = sprintf( '%s-complete-vol-%02d.pdf', sanitize_title( $term->slug ), $vol );
			$file     = trailingslashit( $dir ) . $filename;
			$existing = isset( $volumes[ $vol ] ) ? $volumes[ $vol ] : null;

			// FROZEN volumes are immutable: never re-render while the file exists.
			if ( $existing && ! empty( $existing['frozen'] ) && file_exists( $file ) ) {
				continue;
			}

			$start_num = $i * $cap + 1;
			$html      = static::build_volume_pdf_html( $term, $vol, $total_vols, $chunk, $start_num );
			$res       = static::render_pdf_file( $file, $html );

			if ( is_wp_error( $res ) ) {
				if ( class_exists( 'NM_Generation_Logger' ) ) {
					NM_Generation_Logger::nm_log_activity(
						sprintf( '[PDF VOLUMES] Failed to render "%s" Vol %d: %s', $term->name, $vol, $res->get_error_message() ),
						'error'
					);
				}
				continue;
			}

			$volumes[ $vol ] = array(
				'vol'     => $vol,
				'file'    => $file,
				'url'     => self::pdf_url( $term, $filename ),
				'count'   => count( $chunk ),
				'from'    => $start_num,
				'to'      => $start_num + count( $chunk ) - 1,
				'frozen'  => $is_full, // full volume freezes after this (first) build
				'updated' => current_time( 'mysql' ),
			);
			$built++;
		}

		ksort( $volumes );
		update_post_meta( $page_id, self::META_VOLUMES, $volumes );
		update_post_meta( $page_id, self::META_VOLUMES_MONTH, date( 'Y-m', current_time( 'timestamp' ) ) );

		// Refresh the archive page so the Complete Bank section reflects new counts.
		$months     = get_post_meta( $page_id, self::META_MONTHS, true );
		$months     = is_array( $months ) ? $months : array();
		$latest     = ! empty( $months ) ? reset( $months ) : null;
		$page_year  = $latest ? (int) $latest['year'] : (int) date( 'Y', current_time( 'timestamp' ) );
		$page_month = $latest ? (int) $latest['month'] : (int) date( 'n', current_time( 'timestamp' ) );
		self::update_page_content( $page_id, $term, $page_year, $page_month, $latest && ! empty( $latest['url'] ), $latest ? (int) $latest['count'] : 0 );

		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity(
				sprintf( '[PDF VOLUMES] "%s": %d volume(s), %d question(s), %d file(s) (re)built.', $term->name, $total_vols, count( $mcqs ), $built ),
				'success'
			);
		}

		return array(
			'page_id'         => $page_id,
			'volumes'         => $total_vols,
			'built'           => $built,
			'total_questions' => count( $mcqs ),
		);
	}

	/**
	 * Ensure a topic's evergreen page exists AND that a PDF exists for the target month.
	 *
	 * @param int $term_id Topic term id.
	 * @param int $year
	 * @param int $month
	 * @return array { page_id, pdf_url, pdf_file, generated } or error array.
	 */
	public static function ensure_archive( $term_id, $year, $month ) {
		$term = get_term( $term_id, 'topic' );
		if ( ! $term || is_wp_error( $term ) ) {
			return array( 'error' => 'Invalid topic term.' );
		}

		// 1. Ensure the evergreen page exists.
		$page_id = self::ensure_page( $term );
		if ( ! $page_id ) {
			return array( 'error' => 'Could not create archive page.' );
		}

		// 2. Collect this month's MCQs for this topic (including sub-topics).
		$mcqs = self::collect_mcqs( $term_id, $year, $month );
		if ( empty( $mcqs ) ) {
			// No MCQs this month -> still refresh the page (accordion) but no PDF.
			self::update_page_content( $page_id, $term, $year, $month, false );
			return array( 'page_id' => $page_id, 'pdf_url' => '', 'pdf_file' => '', 'generated' => false, 'count' => 0 );
		}

		// 3. Generate the PDF (idempotent per topic+month).
		$pdf = self::generate_pdf( $term, $year, $month, $mcqs );
		if ( is_wp_error( $pdf ) ) {
			return array( 'error' => $pdf->get_error_message(), 'page_id' => $page_id );
		}

		// 4. Record this month and refresh the page.
		self::record_month( $page_id, $year, $month, $pdf['file'], $pdf['url'], count( $mcqs ) );
		self::update_page_content( $page_id, $term, $year, $month, true, count( $mcqs ) );

		return array(
			'page_id'   => $page_id,
			'pdf_url'   => $pdf['url'],
			'pdf_file'  => $pdf['file'],
			'generated' => true,
			'count'     => count( $mcqs ),
		);
	}

	/* ------------------------------------------------------------------
	 * Page management
	 * ---------------------------------------------------------------- */

	/**
	 * Find or create the evergreen page for a topic.
	 *
	 * @param WP_Term $term
	 * @return int page id
	 */
	private static function ensure_page( $term ) {
		$slug = sanitize_title( $term->slug . '-mcqs-with-answers' );

		// Find by slug.
		$existing = get_posts(
			array(
				'post_type'      => 'page',
				'name'           => $slug,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( ! empty( $existing ) ) {
			return (int) $existing[0];
		}

		// Find by meta (topic term) in case slug differs.
		$by_meta = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => self::META_TOPIC,
				'meta_value'     => $term->term_id,
			)
		);
		if ( ! empty( $by_meta ) ) {
			return (int) $by_meta[0];
		}

		// Create.
		$page_id = wp_insert_post(
			array(
				'post_type'     => 'page',
				'post_status'   => 'draft', // created as draft; owner reviews/publishes
				'post_title'    => 'Download ' . $term->name . ' MCQs with Answers/Explanations (PDF)',
				'post_name'     => $slug,
				'post_content'  => '',
			),
			true
		);
		if ( is_wp_error( $page_id ) || empty( $page_id ) ) {
			return 0;
		}

		update_post_meta( $page_id, self::META_TOPIC, (int) $term->term_id );
		update_post_meta( $page_id, self::META_MONTHS, array() );
		return (int) $page_id;
	}

	/**
	 * Append/update a month entry in the page's month index.
	 */
	private static function record_month( $page_id, $year, $month, $file, $url, $count ) {
		$months = get_post_meta( $page_id, self::META_MONTHS, true );
		if ( ! is_array( $months ) ) {
			$months = array();
		}
		$key = sprintf( '%04d-%02d', $year, $month );
		$months[ $key ] = array(
			'year'  => (int) $year,
			'month' => (int) $month,
			'file'  => $file,
			'url'   => $url,
			'count' => (int) $count,
		);
		// Newest first.
		krsort( $months );
		update_post_meta( $page_id, self::META_MONTHS, $months );
	}

	/**
	 * Rebuild the archive page: SEO intro + link to topic hub + download CTA +
	 * accordion of all past months' PDFs. Also updates Rank Math SEO title/meta.
	 */
	private static function update_page_content( $page_id, $term, $year, $month, $has_pdf, $count = 0 ) {
		$months = get_post_meta( $page_id, self::META_MONTHS, true );
		if ( ! is_array( $months ) ) {
			$months = array();
		}

		$month_name = date_i18n( 'F Y', mktime( 0, 0, 0, (int) $month, 1, (int) $year ) );
		$hub        = get_term_link( $term );

		// Latest month PDF (first entry = newest).
		$latest_key = '';
		if ( ! empty( $months ) ) {
			$keys = array_keys( $months );
			$latest_key = $keys[0];
		}

		// Intro (SEO / LLMO).
		$content  = '<p>Prepare for CSS, PMS, FPSC, PPSC, NTS and other competitive exams with our free, '
			. 'high-yield <strong>' . esc_html( $term->name ) . ' MCQs with answers and explanations</strong>. '
			. 'This page compiles every <strong>' . esc_html( $term->name ) . ' MCQ published on TheQuizWire</strong> into '
			. 'downloadable, exam-ready PDFs — one per month — so you can revise offline and on the go.</p>';

		if ( ! is_wp_error( $hub ) ) {
			$content .= '<p><a href="' . esc_url( $hub ) . '">Practice all ' . esc_html( $term->name ) . ' MCQs online here</a>.</p>';
		}

		// @NEW 9.5.6: Complete question-bank volumes — the headline download.
		$volumes = get_post_meta( $page_id, self::META_VOLUMES, true );
		if ( is_array( $volumes ) && ! empty( $volumes ) ) {
			$total_q = 0;
			foreach ( $volumes as $v ) {
				$total_q += (int) $v['count'];
			}
			$cap = self::volume_cap();

			$content .= '<h2>Complete ' . esc_html( $term->name ) . ' MCQ Bank &mdash; All ' . (int) $total_q . ' Questions</h2>';
			$content .= '<p>Download the <strong>entire ' . esc_html( $term->name ) . ' question bank</strong> below, organized into volumes of up to '
				. (int) $cap . ' MCQs each, grouped by sub-topic with answers and explanations. '
				. '<strong>The bank is refreshed on the 1st of every month</strong>: completed volumes never change, '
				. 'the newest volume grows as new questions publish, and every download link stays the same.</p>';

			$content .= '<ul style="list-style:none;margin:0 0 18px;padding:0;">';
			foreach ( $volumes as $v ) {
				if ( empty( $v['url'] ) ) {
					continue;
				}
				$badge = ! empty( $v['frozen'] )
					? '<span style="color:#1a7a1a;font-size:12px;font-weight:600;">&#10003; Complete</span>'
					: '<span style="color:#2271b1;font-size:12px;font-weight:600;">&#8635; Updated monthly</span>';
				$content .= '<li style="margin:0 0 8px;padding:10px 12px;border:1px solid #ddd;border-radius:5px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">'
					. '<span><strong>Volume ' . (int) $v['vol'] . '</strong> &mdash; Questions ' . (int) $v['from'] . '&ndash;' . (int) $v['to']
					. ' (' . (int) $v['count'] . ' MCQs) ' . $badge . '</span> '
					. '<a href="' . esc_url( $v['url'] ) . '" download style="font-weight:600;">Download PDF &rarr;</a>'
					. '</li>';
			}
			$content .= '</ul>';
		}

		// Download CTA for the latest month.
		if ( $has_pdf && $latest_key !== '' && ! empty( $months[ $latest_key ]['url'] ) ) {
			$latest = $months[ $latest_key ];
			$label  = date_i18n( 'F Y', mktime( 0, 0, 0, (int) $latest['month'], 1, (int) $latest['year'] ) );
			$content .= '<div style="border:1px solid #2271b1;border-left:5px solid #2271b1;background:#f0f6fc;padding:18px 20px;border-radius:6px;margin:18px 0;">'
				. '<h2 style="margin:0 0 8px;">' . esc_html( $term->name ) . ' MCQs with Answers/Explanations &ndash; ' . esc_html( $label ) . '</h2>'
				. '<p style="margin:0 0 12px;">Download the free PDF covering <strong>' . (int) $latest['count'] . ' MCQs</strong> published in ' . esc_html( $label ) . '.</p>'
				. '<a class="button" style="background:#2271b1;color:#fff;padding:10px 18px;border-radius:4px;text-decoration:none;font-weight:600;" href="' . esc_url( $latest['url'] ) . '" download>⬇️ Download ' . esc_html( $label ) . ' PDF</a>'
				. '</div>';
		}

		// Accordion of past months.
		if ( count( $months ) > 0 ) {
			$content .= '<h2>Previous Months</h2><p>Select any past month to download its PDF.</p><ul style="list-style:none;margin:0;padding:0;">';
			foreach ( $months as $m ) {
				if ( empty( $m['url'] ) ) {
					continue;
				}
				$mlabel = date_i18n( 'F Y', mktime( 0, 0, 0, (int) $m['month'], 1, (int) $m['year'] ) );
				$content .= '<li style="margin:0 0 8px;padding:10px 12px;border:1px solid #ddd;border-radius:5px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">'
					. '<span><strong>' . esc_html( $mlabel ) . '</strong> &mdash; ' . (int) $m['count'] . ' MCQs</span> '
					. '<a href="' . esc_url( $m['url'] ) . '" download style="font-weight:600;">Download PDF &rarr;</a>'
					. '</li>';
			}
			$content .= '</ul>';
		}

		$content .= '<p><em>Questions are sourced from TheQuizWire&rsquo;s verified current-affairs and general-knowledge MCQs and are updated monthly.</em></p>';

		// @NEW 9.5.4: Store the archive page as Gutenberg BLOCK markup (clean parts
		// become native blocks; the styled download card/list become Custom HTML
		// blocks) instead of one legacy "Classic" blob.
		if ( class_exists( 'NM_News_Article_Generator' ) && method_exists( 'NM_News_Article_Generator', 'convert_html_to_blocks' ) ) {
			$content = NM_News_Article_Generator::convert_html_to_blocks( $content );
		}

		// Update the post. Title clearly signals a downloadable PDF.
		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => $content,
				'post_title'   => 'Download ' . $term->name . ' MCQs with Answers/Explanations (PDF)',
			)
		);

		update_post_meta( $page_id, '_nm_blocks_converted', 'yes' ); // @NEW 9.5.5: born as blocks

		// Rank Math SEO meta (updated each month so %month% freshness is reflected).
		// Structure hints at the download: "[Topic] MCQs with Answers/Explanations PDF - [Month Year]".
		$seo_title = $term->name . ' MCQs with Answers/Explanations PDF - ' . $month_name;
		update_post_meta( $page_id, 'rank_math_title', sanitize_text_field( $seo_title ) );
		update_post_meta( $page_id, 'rank_math_description', sanitize_text_field( 'Free downloadable ' . $term->name . ' MCQs with answers and explanations for CSS, PMS, FPSC, PPSC and NTS. Updated monthly.' ) );
		update_post_meta( $page_id, 'rank_math_focus_keyword', sanitize_text_field( $term->name . ' mcqs' ) );
		// Yoast compatibility.
		update_post_meta( $page_id, '_yoast_wpseo_title', sanitize_text_field( $seo_title ) );
		update_post_meta( $page_id, '_yoast_wpseo_metadesc', sanitize_text_field( 'Free downloadable ' . $term->name . ' MCQs with answers and explanations for competitive exams.' ) );
	}

	/* ------------------------------------------------------------------
	 * MCQ collection
	 * ---------------------------------------------------------------- */

	/**
	 * All MCQs published in a given month for a topic (including sub-topics).
	 *
	 * @param int $term_id
	 * @param int $year
	 * @param int $month
	 * @return array[] [{post_id, question, options, answer, explanation, topic}]
	 */
	private static function collect_mcqs( $term_id, $year, $month ) {
		$q = new WP_Query(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'date',
				'order'          => 'ASC',
				'date_query'     => array(
					array(
						'column' => 'post_date', // publish date (Scheduler stamps this)
						'year'   => (int) $year,
						'month'  => (int) $month,
					),
				),
				'tax_query'      => array(
					array(
						'taxonomy'         => 'topic',
						'field'            => 'term_id',
						'terms'            => array( (int) $term_id ),
						'include_children' => true, // include sub-topics
					),
				),
				// @NEW 9.5.6: Quality gate — reported MCQs never reach a PDF.
				'meta_query'     => self::quality_gate_meta_query(),
			)
		);

		$out = array();
		foreach ( $q->posts as $pid ) {
			$pid       = (int) $pid;
			$options   = get_post_meta( $pid, 'mcq_options', true );
			$answer    = get_post_meta( $pid, 'mcq_answer', true );
			$expl      = get_post_meta( $pid, 'mcq_explanation', true );
			$out[] = array(
				'post_id'     => $pid,
				'question'    => get_the_title( $pid ),
				'options'     => is_array( $options ) ? $options : array(),
				'answer'      => (string) $answer,
				'explanation' => (string) $expl,
				'topic'       => $term_id,
			);
		}
		return $out;
	}

	/**
	 * @NEW 9.5.6: Collect ALL published MCQs for a topic (no date filter) in STABLE
	 * chronological order for the complete-bank volumes.
	 *
	 * Ordered by ID ASC — insertion order is immutable, so volume membership never
	 * shifts when a post date is edited (frozen volumes stay frozen). Includes the
	 * same quality gate as the monthly collector, plus each MCQ's sub-topic name for
	 * section grouping inside the PDF.
	 *
	 * @param int $term_id Parent topic term id.
	 * @return array[] [{post_id, question, options, answer, explanation, subtopic}]
	 */
	public static function collect_all_mcqs( $term_id ) {
		$q = new WP_Query(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'tax_query'      => array(
					array(
						'taxonomy'         => 'topic',
						'field'            => 'term_id',
						'terms'            => array( (int) $term_id ),
						'include_children' => true,
					),
				),
				'meta_query'     => self::quality_gate_meta_query(),
			)
		);

		$out = array();
		foreach ( $q->posts as $pid ) {
			$pid     = (int) $pid;
			$options = get_post_meta( $pid, 'mcq_options', true );

			// Resolve the sub-topic for section grouping: prefer a DIRECT child of the
			// parent topic; fall back to any child term; else "General".
			$subtopic = 'General';
			$terms    = get_the_terms( $pid, 'topic' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					if ( (int) $t->parent === (int) $term_id ) {
						$subtopic = $t->name;
						break;
					}
				}
				if ( 'General' === $subtopic ) {
					foreach ( $terms as $t ) {
						if ( ! empty( $t->parent ) ) {
							$subtopic = $t->name;
							break;
						}
					}
				}
			}

			$out[] = array(
				'post_id'     => $pid,
				'question'    => get_the_title( $pid ),
				'options'     => is_array( $options ) ? $options : array(),
				'answer'      => (string) get_post_meta( $pid, 'mcq_answer', true ),
				'explanation' => (string) get_post_meta( $pid, 'mcq_explanation', true ),
				'subtopic'    => $subtopic,
			);
		}
		return $out;
	}

	/**
	 * @NEW 9.5.6: Split the chronological MCQ list into append-only volumes.
	 * Vol 1 = oldest {cap} questions, Vol 2 = next {cap}, … last volume is partial/open.
	 *
	 * @param array $mcqs Chronologically ordered MCQs.
	 * @param int   $cap  Max questions per volume.
	 * @return array[] Array of chunks (1-based volume number = index + 1).
	 */
	public static function partition_volumes( array $mcqs, $cap ) {
		$cap = max( 1, (int) $cap );
		return array_chunk( $mcqs, $cap );
	}

	/* ------------------------------------------------------------------
	 * PDF generation (Dompdf)
	 * ---------------------------------------------------------------- */

	/**
	 * Generate and store the monthly PDF for a topic.
	 *
	 * @param WP_Term $term
	 * @param int $year
	 * @param int $month
	 * @param array  $mcqs  Collected MCQs.
	 * @return array|WP_Error { file (abs path), url }
	 */
	private static function generate_pdf( $term, $year, $month, $mcqs ) {
		$lib = NM_PLUGIN_PATH . 'includes/lib/vendor/autoload.php';
		if ( ! file_exists( $lib ) ) {
			return new WP_Error( 'no_dompdf', 'Dompdf library not found. Please re-upload the plugin.' );
		}
		require_once $lib;
		if ( ! class_exists( 'Dompdf\Dompdf' ) ) {
			return new WP_Error( 'no_dompdf', 'Dompdf could not be loaded.' );
		}

		$dir = self::pdf_dir( $term );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$filename = sprintf( '%s-%04d-%02d.pdf', sanitize_title( $term->slug ), (int) $year, (int) $month );
		$file     = trailingslashit( $dir ) . $filename;

		// Idempotent: if the file already exists for this month, reuse it.
		if ( file_exists( $file ) ) {
			return array( 'file' => $file, 'url' => self::pdf_url( $term, $filename ) );
		}

		$html = self::build_pdf_html( $term, $year, $month, $mcqs );

		$res = static::render_pdf_file( $file, $html );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		return array( 'file' => $file, 'url' => self::pdf_url( $term, $filename ) );
	}

	/**
	 * @NEW 9.5.6: Shared Dompdf renderer — renders $html to $file (overwrites).
	 * Extracted from generate_pdf() so the complete-bank volumes reuse the exact
	 * same engine, options and footer. Protected + late-static-bound for testability.
	 *
	 * @param string $file Absolute target path.
	 * @param string $html Full HTML document.
	 * @return true|WP_Error
	 */
	protected static function render_pdf_file( $file, $html ) {
		$lib = NM_PLUGIN_PATH . 'includes/lib/vendor/autoload.php';
		if ( ! file_exists( $lib ) ) {
			return new WP_Error( 'no_dompdf', 'Dompdf library not found. Please re-upload the plugin.' );
		}
		require_once $lib;
		if ( ! class_exists( 'Dompdf\Dompdf' ) ) {
			return new WP_Error( 'no_dompdf', 'Dompdf could not be loaded.' );
		}

		try {
			$dompdf = new \Dompdf\Dompdf();
			// Allow the site logo (from uploads) to be embedded. We pass a LOCAL file path,
			// so chroot must include the uploads dir; isRemoteEnabled is a fallback for the
			// URL form if the local path isn't resolvable.
			$uploads_dir = wp_upload_dir();
			$dompdf->set_option( 'chroot', array( ABSPATH, $uploads_dir['basedir'] ) );
			$dompdf->set_option( 'isRemoteEnabled', true );
			$dompdf->set_option( 'isHtml5ParserEnabled', true );
			$dompdf->loadHtml( $html, 'UTF-8' );
			$dompdf->setPaper( 'A4', 'portrait' );
			$dompdf->render();

			// Footer with page numbers on every page (Dompdf's reliable page_text API).
			// Coordinates are in points for A4 (595x842). x=595/2, y just above bottom margin.
			$canvas = $dompdf->getCanvas();
			$canvas->page_text(
				360,
				810,
				get_bloginfo( 'name' ) . '  |  Page {PAGE_NUM} of {PAGE_COUNT}',
				'DejaVu Sans',
				8,
				array( 0.53, 0.53, 0.53 )
			);

			$bytes = $dompdf->output();
			if ( empty( $bytes ) ) {
				return new WP_Error( 'pdf_empty', 'PDF generation returned an empty file.' );
			}
			file_put_contents( $file, $bytes ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} catch ( \Exception $e ) {
			return new WP_Error( 'pdf_failed', 'PDF generation error: ' . $e->getMessage() );
		}

		return true;
	}

	/** Absolute storage dir for a topic. */
	private static function pdf_dir( $term ) {
		$up = wp_upload_dir();
		return trailingslashit( $up['basedir'] ) . self::DIR . '/' . sanitize_title( $term->slug );
	}

	/** Public URL for a stored PDF. */
	private static function pdf_url( $term, $filename ) {
		$up = wp_upload_dir();
		return trailingslashit( $up['baseurl'] ) . self::DIR . '/' . sanitize_title( $term->slug ) . '/' . rawurlencode( $filename );
	}

	/**
	 * Build the PDF HTML: cover page + numbered MCQs with answers/explanations.
	 * CSS page counters + page-break-inside avoid guarantee questions are never cut.
	 */
	private static function build_pdf_html( $term, $year, $month, $mcqs ) {
		$month_name = date_i18n( 'F Y', mktime( 0, 0, 0, (int) $month, 1, (int) $year ) );
		$site       = get_bloginfo( 'name' );
		$home       = home_url( '/' );
		$domain     = wp_parse_url( $home, PHP_URL_HOST ); // e.g. "thequizwire.com"
		$logo       = self::logo_url();
		$count      = (int) count( $mcqs );

		$qhtml = '';
		$n     = 0;
		foreach ( $mcqs as $m ) {
			$n++;
			$options = is_array( $m['options'] ) ? $m['options'] : array();
			$opt_html = '';
			foreach ( $options as $letter => $text ) {
				$letter = strtoupper( $letter );
				$is_correct = ( strtoupper( (string) $m['answer'] ) === $letter );
				$opt_html .= '<div class="opt' . ( $is_correct ? ' correct' : '' ) . '">'
					. '<span class="opt-letter">' . esc_html( $letter ) . '</span> '
					. esc_html( $text )
					. ( $is_correct ? ' <span class="tick">&#10003;</span>' : '' )
					. '</div>';
			}
			$expl = ! empty( $m['explanation'] ) ? '<div class="expl"><strong>Explanation:</strong> ' . esc_html( $m['explanation'] ) . '</div>' : '';
			$qhtml .= '<div class="q">'
				. '<div class="q-num">Q' . $n . '.</div>'
				. '<div class="q-text">' . esc_html( $m['question'] ) . '</div>'
				. $opt_html
				. $expl
				. '</div>';
		}

		return <<<HTML
<html><head><meta charset="UTF-8"><style>
@page { margin: 2cm 1.8cm 2.2cm 1.8cm; }
body { font-family: 'DejaVu Sans', sans-serif; font-size:10pt; color:#222; line-height:1.5; }
.cover { text-align:center; page-break-after:always; padding-top:120px; }
.cover .logo { max-height:70px; max-width:300px; margin-bottom:20px; }
.cover h1 { font-size:22pt; margin:10px 0; color:#0b3d6e; }
.cover .sub { font-size:12pt; color:#555; margin-bottom:30px; }
.cover .site a { font-size:11pt; color:#0b3d6e; text-decoration:none; }
.cover .meta { margin-top:40px; font-size:10pt; color:#777; }
.q { page-break-inside:avoid; margin:0 0 14px 0; padding:10px 12px; border:1px solid #e0e0e0; border-radius:6px; }
.q-num { font-weight:bold; color:#0b3d6e; margin-bottom:2px; }
.q-text { font-weight:600; margin-bottom:6px; }
.opt { margin:1px 0; padding:1px 0; }
.opt.correct { font-weight:bold; color:#1a7a1a; }
.opt-letter { font-weight:bold; margin-right:4px; }
.tick { color:#1a7a1a; }
.expl { margin-top:6px; padding-top:6px; border-top:1px dashed #ddd; color:#444; }
</style></head>
<body>
<div class="cover">
	{$logo}
	<h1>{$term->name} MCQs with Answers/Explanations</h1>
	<div class="sub">&ndash; {$month_name} &ndash;</div>
	<div class="site"><a href="{$home}">{$domain}</a></div>
	<div class="meta">{$count} MCQs &middot; {$month_name}</div>
</div>
{$qhtml}
</body></html>
HTML;
	}

	/**
	 * @NEW 9.5.6: Build the HTML for one COMPLETE-BANK volume.
	 * Questions are grouped by sub-topic (alphabetical sections, chronological inside)
	 * with continuous numbering across volumes (Vol 2 with cap 200 starts at Q201).
	 *
	 * @param WP_Term $term       Parent topic.
	 * @param int     $vol        Volume number (1-based).
	 * @param int     $total_vols Total volumes.
	 * @param array   $mcqs       This volume's MCQs (chronological, with 'subtopic').
	 * @param int     $start_num  Global number of this volume's first question.
	 * @return string
	 */
	protected static function build_volume_pdf_html( $term, $vol, $total_vols, $mcqs, $start_num ) {
		$site    = get_bloginfo( 'name' );
		$home    = home_url( '/' );
		$domain  = wp_parse_url( $home, PHP_URL_HOST );
		$logo    = self::logo_url();
		$count   = (int) count( $mcqs );
		$end_num = $start_num + $count - 1;
		$is_open = ( $vol === $total_vols );
		$updated = date_i18n( 'F Y', current_time( 'timestamp' ) );

		// Group by sub-topic: sections alphabetical, questions chronological inside,
		// numbering continuous in rendered order.
		$groups = array();
		foreach ( $mcqs as $m ) {
			$sub = ! empty( $m['subtopic'] ) ? $m['subtopic'] : 'General';
			$groups[ $sub ][] = $m;
		}
		ksort( $groups, SORT_NATURAL | SORT_FLAG_CASE );

		$qhtml = '';
		$n     = $start_num - 1;
		foreach ( $groups as $sub_name => $items ) {
			$qhtml .= '<h2 class="sec">' . esc_html( $sub_name ) . ' <span class="sec-count">(' . count( $items ) . ' MCQs)</span></h2>';
			foreach ( $items as $m ) {
				$n++;
				$options  = is_array( $m['options'] ) ? $m['options'] : array();
				$opt_html = '';
				foreach ( $options as $letter => $text ) {
					$letter     = strtoupper( $letter );
					$is_correct = ( strtoupper( (string) $m['answer'] ) === $letter );
					$opt_html  .= '<div class="opt' . ( $is_correct ? ' correct' : '' ) . '">'
						. '<span class="opt-letter">' . esc_html( $letter ) . '</span> '
						. esc_html( $text )
						. ( $is_correct ? ' <span class="tick">&#10003;</span>' : '' )
						. '</div>';
				}
				$expl   = ! empty( $m['explanation'] ) ? '<div class="expl"><strong>Explanation:</strong> ' . esc_html( $m['explanation'] ) . '</div>' : '';
				$qhtml .= '<div class="q">'
					. '<div class="q-num">Q' . $n . '.</div>'
					. '<div class="q-text">' . esc_html( $m['question'] ) . '</div>'
					. $opt_html
					. $expl
					. '</div>';
			}
		}

		$vol_status = $is_open
			? 'This is the open volume &mdash; it grows as new questions publish and is refreshed on the <strong>1st of every month</strong>. The download link never changes.'
			: 'This volume is complete and will not change &mdash; safe to keep forever.';

		return <<<HTML
<html><head><meta charset="UTF-8"><style>
@page { margin: 2cm 1.8cm 2.2cm 1.8cm; }
body { font-family: 'DejaVu Sans', sans-serif; font-size:10pt; color:#222; line-height:1.5; }
.cover { text-align:center; page-break-after:always; padding-top:120px; }
.cover .logo { max-height:70px; max-width:300px; margin-bottom:20px; }
.cover h1 { font-size:22pt; margin:10px 0; color:#0b3d6e; }
.cover .sub { font-size:12pt; color:#555; margin-bottom:30px; }
.cover .site a { font-size:11pt; color:#0b3d6e; text-decoration:none; }
.cover .meta { margin-top:40px; font-size:10pt; color:#777; }
.cover .status { margin-top:18px; font-size:9pt; color:#777; max-width:420px; margin-left:auto; margin-right:auto; }
.sec { font-size:14pt; color:#0b3d6e; border-bottom:2px solid #0b3d6e; padding-bottom:4px; margin:22px 0 12px; page-break-after:avoid; }
.sec-count { font-size:9pt; color:#888; font-weight:normal; }
.q { page-break-inside:avoid; margin:0 0 14px 0; padding:10px 12px; border:1px solid #e0e0e0; border-radius:6px; }
.q-num { font-weight:bold; color:#0b3d6e; margin-bottom:2px; }
.q-text { font-weight:600; margin-bottom:6px; }
.opt { margin:1px 0; padding:1px 0; }
.opt.correct { font-weight:bold; color:#1a7a1a; }
.opt-letter { font-weight:bold; margin-right:4px; }
.tick { color:#1a7a1a; }
.expl { margin-top:6px; padding-top:6px; border-top:1px dashed #ddd; color:#444; }
</style></head>
<body>
<div class="cover">
	{$logo}
	<h1>Complete {$term->name} MCQs &mdash; Volume {$vol} of {$total_vols}</h1>
	<div class="sub">Questions {$start_num}&ndash;{$end_num} &middot; With Answers &amp; Explanations</div>
	<div class="site"><a href="{$home}">{$domain}</a></div>
	<div class="meta">{$count} MCQs &middot; Updated {$updated}</div>
	<div class="status">{$vol_status}</div>
</div>
{$qhtml}
</body></html>
HTML;
	}

	/**
	 * Get the site logo as an <img> for the PDF cover.
	 *
	 * Embeds the logo as a base64 data URI (from the local attachment file) so Dompdf can
	 * render it reliably — no remote-fetch or chroot dependence. Falls back to the brand name.
	 *
	 * @return string An <img> tag (or an <h1> brand fallback).
	 */
	private static function logo_url() {
		$logo_id = get_theme_mod( 'custom_logo' );
		$name    = get_bloginfo( 'name' );
		if ( $logo_id ) {
			$local = get_attached_file( $logo_id );
			if ( $local && file_exists( $local ) ) {
				$mime = function_exists( 'wp_check_filetype' ) ? wp_check_filetype( $local ) : array( 'type' => '' );
				$type = ! empty( $mime['type'] ) ? $mime['type'] : self::guess_mime( $local );
				$b64  = base64_encode( file_get_contents( $local ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				return '<img class="logo" src="data:' . $type . ';base64,' . $b64 . '" alt="' . esc_attr( $name ) . '">';
			}
		}
		// Brand-name text fallback.
		return '<h1 class="logo" style="font-size:20pt;color:#0b3d6e;">' . esc_html( $name ) . '</h1>';
	}

	/** Simple MIME guess by extension (used if wp_check_filetype is unavailable). */
	private static function guess_mime( $file ) {
		$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$map = array(
			'png'  => 'image/png',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'gif'  => 'image/gif',
			'svg'  => 'image/svg+xml',
			'webp' => 'image/webp',
		);
		return isset( $map[ $ext ] ) ? $map[ $ext ] : 'image/png';
	}

	/* ------------------------------------------------------------------
	 * Schema (Rank Math)
	 * ---------------------------------------------------------------- */

	/**
	 * Inject Article + FAQPage schema on PDF archive pages via Rank Math.
	 */
	public function inject_archive_schema( $data, $jsonld ) {
		if ( ! is_singular( 'page' ) ) {
			return $data;
		}
		$pid = get_the_ID();
		if ( ! get_post_meta( $pid, self::META_TOPIC, true ) ) {
			return $data;
		}

		$term_id = (int) get_post_meta( $pid, self::META_TOPIC, true );
		$term    = get_term( $term_id, 'topic' );
		$name    = ( $term && ! is_wp_error( $term ) ) ? $term->name : 'MCQ';
		$author  = get_bloginfo( 'name' );

		// Article.
		if ( isset( $data['Article'] ) ) {
			$data['Article']['author'] = array( '@type' => 'Person', 'name' => $author );
		} else {
			$data['Article'] = array(
				'@type'            => 'Article',
				'@id'              => get_permalink( $pid ) . '#article',
				'headline'         => get_the_title( $pid ),
				'description'      => 'Free downloadable ' . $name . ' MCQs with answers and explanations.',
				'datePublished'    => get_the_date( 'c', $pid ),
				'dateModified'     => get_the_modified_date( 'c', $pid ),
				'author'           => array( '@type' => 'Person', 'name' => $author ),
				'publisher'        => array( '@type' => 'Organization', 'name' => $author ),
				'mainEntityOfPage' => get_permalink( $pid ),
			);
		}

		// FAQPage from a small static FAQ.
		$faq = array(
			array( 'q' => 'Are these ' . $name . ' MCQs with answers free to download?', 'a' => 'Yes, all monthly ' . $name . ' MCQ PDFs on TheQuizWire are completely free to download.' ),
			array( 'q' => 'Which exams are these ' . $name . ' MCQs useful for?', 'a' => 'They help prepare for CSS, PMS, FPSC, PPSC, NTS and other competitive exams in Pakistan.' ),
			array( 'q' => 'How often are the PDFs updated?', 'a' => 'A new PDF is generated each month covering all ' . $name . ' MCQs published that month.' ),
		);
		$faq_entries = array();
		foreach ( $faq as $f ) {
			$faq_entries[] = array(
				'@type'          => 'Question',
				'name'           => $f['q'],
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['a'] ),
			);
		}
		$data['FAQPage'] = array( '@type' => 'FAQPage', 'mainEntity' => $faq_entries );

		return $data;
	}
}
