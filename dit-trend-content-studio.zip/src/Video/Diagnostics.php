<?php
/**
 * DIT Video Module — Diagnostics
 *
 * Detects what the video pipeline needs and reports what's missing. This is the
 * "setting to detect what's missing (deps etc)" requirement. Pure checks; no
 * writes except optional result caching into Settings.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

if (!defined('ABSPATH')) {
    exit;
}

class Diagnostics
{
    /** @var Settings */
    protected $settings;

    public function __construct(Settings $settings)
    {
        $this->settings = $settings;
    }

    public function exec_available(): bool
    {
        if (!function_exists('exec')) {
            return false;
        }
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
        return !in_array('exec', $disabled, true);
    }

    /**
     * Run all checks. Returns a list of ['key','label','ok','value'] rows.
     */
    public function run(): array
    {
        $checks = array();
        $checks[] = $this->check('exec', 'PHP exec()', $this->exec_available(), $this->exec_available() ? 'available' : 'DISABLED');

        // Runner dir + render.mjs
        $runner = $this->settings->runner_dir();
        $has_runner = is_file($runner . '/render.mjs');
        $checks[] = $this->check('runner', 'Video runner (render.mjs)', $has_runner, $runner);

        // Node
        $node = $this->bin('node');
        $checks[] = $this->check('node', 'Node.js', $node !== '', $node !== '' ? $node . ' ' . $this->version($node) : 'not found');

        // Python3
        $py = $this->bin('python3');
        $checks[] = $this->check('python', 'Python3', $py !== '', $py !== '' ? $py : 'not found');

        // ffmpeg
        $ff = $this->bin('ffmpeg');
        $checks[] = $this->check('ffmpeg', 'ffmpeg', $ff !== '', $ff !== '' ? $ff : 'not found');

        // Puppeteer module (node)
        $checks[] = $this->check(
            'puppeteer',
            'Puppeteer (node module)',
            $this->has_node_module($runner, 'puppeteer-core') || $this->has_node_module($runner, 'puppeteer'),
            'video-runner/node_modules'
        );

        // edge-tts (python)
        $edge = $this->py_module('edge_tts');
        $checks[] = $this->check('edge_tts', 'edge-tts (Urdu TTS)', $edge, $edge ? 'installed' : 'missing');

        // Kokoro (optional)
        $kokoro = $this->py_module('kokoro_onnx');
        $checks[] = $this->check('kokoro', 'kokoro-onnx (optional, no Urdu)', $kokoro, $kokoro ? 'installed' : 'not installed');

        // Urdu font
        $font = (new Brand())->urdu_font_path();
        $checks[] = $this->check('urdu_font', 'Urdu font (Noto Nastaliq)', $font !== '', $font !== '' ? basename($font) : 'not found');

        // Brand logo
        $logo = (new Brand())->logo_path();
        $checks[] = $this->check('brand_logo', 'Brand logo', $logo !== '', $logo !== '' ? basename($logo) : 'none set');

        return $checks;
    }

    private function check(string $key, string $label, bool $ok, string $value): array
    {
        return array('key' => $key, 'label' => $label, 'ok' => $ok, 'value' => $value);
    }

    private function bin(string $name): string
    {
        $out = array();
        $code = 1;
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null', $out, $code);
        return (0 === $code && !empty($out)) ? trim($out[0]) : '';
    }

    private function version(string $bin): string
    {
        $out = array();
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec(escapeshellarg($bin) . ' --version 2>&1 | head -1', $out);
        return isset($out[0]) ? trim($out[0]) : '';
    }

    private function has_node_module(string $runner, string $mod): bool
    {
        return is_dir($runner . '/node_modules/' . $mod);
    }

    private function py_module(string $mod): bool
    {
        if (!$this->exec_available()) {
            return false;
        }
        $out = array();
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec('python3 -c "import ' . $mod . '" 2>&1', $out, $code);
        return 0 === $code;
    }

    /**
     * Persist the diagnostics result into settings (for the admin page).
     */
    public function persist(): array
    {
        $checks = $this->run();
        $missing = array();
        foreach ($checks as $c) {
            if (!$c['ok']) {
                $missing[] = $c['label'];
            }
        }
        $this->settings->set('last_diagnostics', wp_json_encode(array(
            'ts'      => gmdate('c'),
            'missing' => $missing,
        )));
        return $checks;
    }
}
