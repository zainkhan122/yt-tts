<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap dit-ts-social-queue-wrap">
    <h1><?php \esc_html_e('Social Review Queue', 'dit-trend-content-studio'); ?></h1>
    <p><?php \esc_html_e('Review Urdu translations and select images for the social media collage. Approved items will generate a 4:5 collage, switch the post from Draft to Published, and automatically queue it for WP to Buffer Pro.', 'dit-trend-content-studio'); ?></p>

    <?php if (empty($pending_posts)) : ?>
        <div class="notice notice-info">
            <p><?php \esc_html_e('No pending social posts to review. Generation jobs will route here if they include Social Assets.', 'dit-trend-content-studio'); ?></p>
        </div>
    <?php else : ?>
        <div class="dit-ts-social-queue-list" style="max-width: 1200px; margin-top: 20px;">
            <?php foreach ($pending_posts as $item) :
                $post = \get_post($item['post_id']);
                if (!$post) continue; // Skip if post was deleted

                // @MODIFIED 2026-03-07 - Robust image detection (Fix empty queue)
                // 1) Get parented attachments
                $images = \get_attached_media('image', $post->ID);

                // 2) Fallback: Get images assigned to this job but not yet parented
                $job_id = \get_post_meta($post->ID, '_dit_ts_media_job', true);
                if (empty($images) && $job_id) {
                    $job_images = \get_posts([
                        'post_type'      => 'attachment',
                        'post_mime_type' => 'image',
                        'post_status'    => 'inherit',
                        'posts_per_page' => 20,
                        'meta_query'     => [
                            [
                                'key'   => '_dit_ts_media_job',
                                'value' => $job_id,
                            ]
                        ]
                    ]);
                    if (!empty($job_images)) {
                        $images = $job_images;
                    }
                }

                // 3) Final Fallback: Content scan for <img> tags
                if (empty($images)) {
                    $inv = new \DIT\TrendStudio\Services\Media_Inventory();
                    $inventory = $inv->get_post_image_inventory($post->ID);
                    if (!empty($inventory['ordered_ids'])) {
                        foreach ($inventory['ordered_ids'] as $att_id) {
                            $att = \get_post($att_id);
                            if ($att) $images[] = $att;
                        }
                    }
                }

                $urdu_heading = \wp_unslash($item['urdu_heading']);
                $urdu_description = \wp_unslash($item['urdu_description']);
                $hashtags = \wp_unslash($item['hashtags']);

                // @MODIFIED 2026-03-08 - Force pretty permalinks for drafts
                $original_status = $post->post_status;
                if ($original_status === 'draft' || $original_status === 'auto-draft') {
                    $post->post_status = 'publish';
                }
                $pretty_link = \get_permalink($post);
                $post->post_status = $original_status; // Restore status
            ?>
                <div class="postbox" style="margin-bottom: 25px; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05);" id="social-item-<?php echo \esc_attr($item['id']); ?>">
                    <div class="inside" style="display: flex; gap: 30px; margin: 0; padding: 25px;">

                        <!-- Left Column: Details & Images -->
                        <div style="flex: 1; min-width: 300px;">
                            <h3 style="margin-top: 0; padding: 0; font-size: 1.1em;">
                                <a href="<?php echo \esc_url(\get_preview_post_link($post)); ?>" target="_blank" style="text-decoration: none;">
                                    <?php echo \esc_html($post->post_title); ?> <span class="dashicons dashicons-external"></span>
                                </a>
                            </h3>
                            <p style="color: #666; margin-top: 5px; font-size: 13px;">Status: <strong><?php echo \esc_html(\ucfirst($post->post_status)); ?></strong></p>

                            <div style="margin-top: 20px;">
                                <h4 style="margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 5px;">1. Select Images for Collage <span style="font-weight:normal; color:#666;">(Max 4 advised)</span></h4>
                                <div class="dit-ts-image-selector" style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 15px;">
                                    <?php if (empty($images)): ?>
                                        <p style="color: #d63638;"><em><?php \esc_html_e('No images found for this post.', 'dit-trend-content-studio'); ?></em></p>
                                        <?php else:
                                        $count = 0;
                                        foreach ($images as $img):
                                            // Default to selecting the first 4
                                            $checked = ($count < 4) ? 'checked' : '';
                                            $img_src = \wp_get_attachment_image_src($img->ID, 'thumbnail');
                                            if (!$img_src) continue;
                                        ?>
                                            <label class="social-img-label" style="cursor: pointer; position: relative; border: 2px solid <?php echo $checked ? '#2271b1' : 'transparent'; ?>; border-radius: 6px; overflow: hidden; transition: all 0.2s;">
                                                <input type="checkbox" class="social-image-select" name="social_images[<?php echo \esc_attr($item['id']); ?>][]" value="<?php echo \esc_attr($img->ID); ?>" <?php echo $checked; ?> style="position: absolute; top: 5px; left: 5px; z-index: 10;">
                                                <img src="<?php echo \esc_url($img_src[0]); ?>" style="width: 100px; height: 100px; object-fit: cover; display: block;" title="ID: <?php echo $img->ID; ?>" />
                                            </label>
                                    <?php
                                            $count++;
                                        endforeach;
                                    endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: Text & Approval -->
                        <div style="flex: 1.2; background: #fafafa; padding: 15px 20px; border-radius: 6px; border: 1px solid #e2e4e7;">
                            <h4 style="margin-top: 0; margin-bottom: 15px; border-bottom: 1px solid #ddd; padding-bottom: 5px;">2. Review Urdu Content</h4>

                            <div style="margin-bottom: 15px;">
                                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Urdu Heading:</label>
                                <input type="text" id="heading-<?php echo \esc_attr($item['id']); ?>" value="<?php echo \esc_attr($urdu_heading); ?>" class="large-text" dir="rtl" style="font-size: 18px; padding: 8px; font-family: 'Jameel Noori Nastaleeq', 'Nafees Web Naskh', Tahoma, sans-serif;" />
                            </div>

                            <div style="margin-bottom: 15px;">
                                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Social Description & Hashtags:</label>
                                <textarea id="description-<?php echo \esc_attr($item['id']); ?>" rows="6" class="large-text" dir="rtl" style="font-size: 16px; padding: 8px; font-family: 'Jameel Noori Nastaleeq', 'Nafees Web Naskh', Tahoma, sans-serif; line-height: 1.6;"><?php
                                                                                                                                                                                                                                                                                echo \esc_textarea($urdu_description);
                                                                                                                                                                                                                                                                                if (!empty($hashtags)) {
                                                                                                                                                                                                                                                                                    echo "\n\n" . \esc_textarea($hashtags);
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                ?></textarea>
                            </div>

                            <div style="text-align: left; margin-top: 25px; border-top: 1px solid #ddd; padding-top: 15px; display: flex; align-items: center; justify-content: flex-end; gap: 10px;">
                                <span class="spinner" id="spinner-<?php echo \esc_attr($item['id']); ?>" style="float:none; margin: 0;"></span>
                                <button class="button button-secondary button-large dit-ts-copy-post-link" data-link="<?php echo \esc_url($pretty_link); ?>" style="display: flex; align-items: center; gap: 5px;">
                                    <span class="dashicons dashicons-admin-links"></span> <?php \esc_html_e('Copy Link', 'dit-trend-content-studio'); ?>
                                </button>
                                <button class="button button-link-delete dit-ts-delete-social" data-id="<?php echo \esc_attr($item['id']); ?>" style="display: flex; align-items: center; gap: 5px; color: #d63638; border-color: #d63638;">
                                    <span class="dashicons dashicons-trash"></span> <?php \esc_html_e('Discard / Delete', 'dit-trend-content-studio'); ?>
                                </button>
                                <button class="button button-primary button-large dit-ts-approve-social" data-id="<?php echo \esc_attr($item['id']); ?>" style="display: flex; align-items: center; gap: 5px;">
                                    <span class="dashicons dashicons-yes"></span> <?php \esc_html_e('Sync & Close (Done)', 'dit-trend-content-studio'); ?>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
    jQuery(document).ready(function($) {
        // Handle image selection styling
        $('.social-image-select').on('change', function() {
            if ($(this).is(':checked')) {
                $(this).parent('.social-img-label').css('border-color', '#2271b1');
            } else {
                $(this).parent('.social-img-label').css('border-color', 'transparent');
            }
        });

        // Handle Copy Link
        $('.dit-ts-copy-post-link').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var link = btn.data('link');

            var temp = $("<textarea>");
            $("body").append(temp);
            temp.val(link).select();
            document.execCommand("copy");
            temp.remove();

            var oldHtml = btn.html();
            btn.addClass('updated').html('<span class="dashicons dashicons-yes"></span> Copied!');
            setTimeout(function() {
                btn.removeClass('updated').html(oldHtml);
            }, 2000);
        });

        // Handle AJAX approval
        $('.dit-ts-approve-social').on('click', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            var heading = $('#heading-' + id).val();
            var description = $('#description-' + id).val();
            doSocialAction(id, 'sync', heading, description);
        });

        // Handle Discard/Delete
        $('.dit-ts-delete-social').on('click', function(e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to remove this item from the queue? This will NOT delete the actual WordPress post.')) {
                return;
            }
            var id = $(this).data('id');
            doSocialAction(id, 'delete');
        });

        function doSocialAction(id, action, heading = '', description = '') {
            var postbox = $('#social-item-' + id);
            var spinner = $('#spinner-' + id);
            var syncBtn = postbox.find('.dit-ts-approve-social');
            var delBtn = postbox.find('.dit-ts-delete-social');

            syncBtn.prop('disabled', true);
            delBtn.prop('disabled', true);
            spinner.addClass('is-active');
            postbox.css('opacity', '0.6');

            $.ajax({
                url: ditTsAdmin.ajaxUrl || ajaxurl,
                type: 'POST',
                data: {
                    action: 'dit_ts_approve_social_post',
                    nonce: ditTsAdmin.nonce,
                    id: id,
                    post_action: action,
                    heading: heading,
                    description: description
                },
                success: function(response) {
                    if (response.success) {
                        postbox.slideUp(400, function() {
                            $(this).remove();
                        });
                    } else {
                        alert('Error: ' + (response.data.message || 'Unknown error'));
                        syncBtn.prop('disabled', false);
                        delBtn.prop('disabled', false);
                        spinner.removeClass('is-active');
                        postbox.css('opacity', '1');
                    }
                },
                error: function() {
                    alert('Connection error. Please try again.');
                    syncBtn.prop('disabled', false);
                    delBtn.prop('disabled', false);
                    spinner.removeClass('is-active');
                    postbox.css('opacity', '1');
                }
            });
        }
    });
</script>