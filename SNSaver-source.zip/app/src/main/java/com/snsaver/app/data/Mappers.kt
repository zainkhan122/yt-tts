package com.snsaver.app.data
import com.google.gson.Gson
import com.snsaver.app.data.db.DownloadEntity
import com.snsaver.app.domain.model.DownloadItem
private val gson=Gson()
private fun decode(v:String)=runCatching{gson.fromJson(v,Array<String>::class.java).toList()}.getOrDefault(emptyList())
fun DownloadEntity.toDomain()=DownloadItem(id,sourceUrl,platform,status,mediaType,filePath,thumbnailPath,caption,decode(hashtagsRaw),profileUrl,profileName,decode(mediaUrlsRaw),decode(downloadedFilesRaw),progress,errorMessage,fileSize,timestamp,title,workerId)
fun DownloadItem.toEntity()=DownloadEntity(id,sourceUrl,platform,status,mediaType,filePath,thumbnailPath,caption,gson.toJson(hashtags),profileUrl,profileName,gson.toJson(mediaUrls),gson.toJson(downloadedFiles),progress,errorMessage,fileSize,timestamp,title,workerId)
