/**
 * NM Audio Manager
 * Professional audio management for Quiz Shorts Studio
 *
 * Handles SFX, background music, volume control, and ducking
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_AudioManager = {
    // Configuration
    config: {
      sfxVolume: 0.7,
      musicVolume: 0.3,
      masterVolume: 1.0,
      duckVolume: 0.1, // Music volume during TTS
      duckDuration: 300, // Fade duration for ducking
      basePath: "", // Set by init()
      isMuted: false,
    },
    // Internal tracking (needed for deterministic stop/pause)
    _sfxTimeouts: new Set(),
    _activeSfxClones: new Set(),

    // Audio buffers
    sfx: {},
    music: {},

    // State
    _currentMusic: null,
    _isDucked: false,
    _originalMusicVolume: 0.3,
    _activeSfxClones: new Set(),
    _pendingSfxTimers: new Set(),

    // SFX definitions
    sfxList: [
      "tick",
      "correct",
      "wrong",
      "whoosh",
      "reveal",
      "countdown",
      "transition",
      "success",
    ],

    // Music tracks
    musicList: ["upbeat", "tense", "chill", "epic"],

    /**
     * Initialize Audio Manager
     * @param {object} config
     */
    init: function (config = {}) {
      this.config = { ...this.config, ...config };

      if (this.config.basePath) {
        this.preloadAll();
      }

      console.log("[NM Audio] Initialized");
    },

    /**
     * Preload all audio assets
     */
    preloadAll: function () {
      const basePath = this.config.basePath;

      // Preload SFX
      this.sfxList.forEach((name) => {
        this.sfx[name] = new Audio(`${basePath}audio/sfx/${name}.mp3`);
        this.sfx[name].preload = "auto";
        this.sfx[name].volume =
          this.config.sfxVolume * this.config.masterVolume;
      });

      // Preload Music
      this.musicList.forEach((name) => {
        this.music[name] = new Audio(`${basePath}audio/music/${name}-loop.mp3`);
        this.music[name].preload = "auto";
        this.music[name].loop = true;
        this.music[name].volume =
          this.config.musicVolume * this.config.masterVolume;
      });

      console.log(
        "[NM Audio] Preloaded",
        this.sfxList.length,
        "SFX and",
        this.musicList.length,
        "music tracks"
      );
    },

    /**
     * Play sound effect
     * @param {string} name - SFX name
     * @param {object} options - volume, delay
     */
    playSFX: function (name, options = {}) {
      const sfx = this.sfx[name];
      if (!sfx) {
        console.warn("[NM Audio] SFX not found:", name);
        return;
      }

      // Hard gate: fully muted
      if (this.config.sfxVolume <= 0 || this.config.masterVolume <= 0) return;

      const volume =
        (options.volume !== undefined ? options.volume : 1) *
        this.config.sfxVolume *
        this.config.masterVolume;

      const delay = Math.max(0, Number(options.delay) || 0);

      const playNow = () => {
        const clone = sfx.cloneNode();
        try { clone.volume = Math.min(1, Math.max(0, volume)); } catch (_) { }

        this._activeSfxClones.add(clone);

        const cleanup = () => this._activeSfxClones.delete(clone);
        try { clone.addEventListener("ended", cleanup, { once: true }); } catch (_) { }
        try { clone.addEventListener("pause", cleanup, { once: true }); } catch (_) { }

        clone.play().catch((e) => {
          console.debug("[NM Audio] SFX play blocked:", e.message);
          cleanup();
        });
      };

      if (delay > 0) {
        const id = setTimeout(() => {
          this._pendingSfxTimers.delete(id);
          playNow();
        }, delay);
        this._pendingSfxTimers.add(id);
      } else {
        playNow();
      }
    },

    /**
     * @MODIFIED 2026-02-23: Consolidated stopSFX to robustly clear all timers and clones
     */
    stopSFX: function () {
      // cancel pending timers
      if (this._pendingSfxTimers.size > 0) {
        this._pendingSfxTimers.forEach((id) => { try { clearTimeout(id); } catch (_) { } });
        this._pendingSfxTimers.clear();
      }

      // stop active clones
      if (this._activeSfxClones.size > 0) {
        this._activeSfxClones.forEach((a) => {
          try { a.pause(); } catch (_) { }
          try { a.currentTime = 0; } catch (_) { }
        });
        this._activeSfxClones.clear();
      }

      // stop base preloaded sfx
      Object.values(this.sfx).forEach((audio) => {
        try { audio.pause(); } catch (_) { }
        try { audio.currentTime = 0; } catch (_) { }
      });
    },

    /**
     * Play background music

     * @param {string} name - Music track name
     * @param {object} options - fadeIn, volume
     */
    playMusic: function (name, options = {}) {
      const music = this.music[name];
      if (!music) {
        console.warn("[NM Audio] Music not found:", name);
        return;
      }

      // @NEW 2026-01-10: Milestone 1 - Hard Gate for Music Mute (consistent with SFX)
      if (this.config.isMuted || this.config.musicVolume <= 0 || this.config.masterVolume <= 0) {
        console.debug("[NM Audio] Music blocked: muted or volume zero");
        return;
      }

      // Stop current music if playing
      // @Refined 2026-01-08: Idempotency check to prevent restart
      if (this._currentMusic === music && !music.paused) return;

      this.stopMusic();

      const targetVolume =
        (options.volume || 1) *
        this.config.musicVolume *
        this.config.masterVolume;
      const fadeIn = options.fadeIn || 0;

      this._currentMusic = music;
      this._originalMusicVolume = targetVolume;

      if (fadeIn > 0) {
        music.volume = 0;
        music
          .play()
          .catch((e) =>
            console.debug("[NM Audio] Music play blocked:", e.message)
          );
        this._fadeVolume(music, 0, targetVolume, fadeIn);
      } else {
        music.volume = targetVolume;
        music
          .play()
          .catch((e) =>
            console.debug("[NM Audio] Music play blocked:", e.message)
          );
      }
    },

    /**
     * Stop background music
     * @param {number} fadeOut - Fade out duration in ms
     */
    stopMusic: function (fadeOut = 0) {
      if (!this._currentMusic) return;

      const music = this._currentMusic;

      if (fadeOut > 0) {
        this._fadeVolume(music, music.volume, 0, fadeOut, () => {
          music.pause();
          music.currentTime = 0;
        });
      } else {
        music.pause();
        music.currentTime = 0;
      }

      this._currentMusic = null;
    },

    /**
     * Pause music (for resume later)
     */
    pauseMusic: function () {
      if (this._currentMusic) {
        this._currentMusic.pause();
      }
    },

    /**
     * Resume paused music
     */
    resumeMusic: function () {
      if (this._currentMusic) {
        this._currentMusic.play().catch(() => { });
      }
    },

    /**
     * Duck music volume (for TTS)
     * Lowers music volume temporarily
     * @param {number} duration - How long to stay ducked (0 = until unduck called)
     */
    duck: function (duration = 0) {
      if (!this._currentMusic || this._isDucked) return;

      this._isDucked = true;
      const targetVolume = this.config.duckVolume * this.config.masterVolume;

      this._fadeVolume(
        this._currentMusic,
        this._currentMusic.volume,
        targetVolume,
        this.config.duckDuration
      );

      if (duration > 0) {
        setTimeout(() => this.unduck(), duration);
      }
    },

    /**
     * Restore music volume after ducking
     */
    unduck: function () {
      if (!this._currentMusic || !this._isDucked) return;

      this._isDucked = false;
      this._fadeVolume(
        this._currentMusic,
        this._currentMusic.volume,
        this._originalMusicVolume,
        this.config.duckDuration
      );
    },

    /**
     * Set volume levels
     * @param {string} type - 'master', 'sfx', 'music'
     * @param {number} level - 0-1
     */
    setVolume: function (type, level) {
      level = Math.min(1, Math.max(0, level));

      switch (type) {
        case "master":
          this.config.masterVolume = level;
          break;
        case "sfx":
          this.config.sfxVolume = level;
          if (level <= 0) this.stopSFX();
          break;

        case "music":
          this.config.musicVolume = level;
          this._originalMusicVolume = level * this.config.masterVolume;
          if (level <= 0) this.stopMusic();
          if (this._currentMusic && !this._isDucked) {
            this._currentMusic.volume = this._originalMusicVolume;
          }
          break;

      }

      // Update all preloaded volumes
      Object.values(this.sfx).forEach((audio) => {
        audio.volume = this.config.sfxVolume * this.config.masterVolume;
      });

      // IMPORTANT: already-playing clones/timers won't obey later volume changes
      if ((type === "sfx" && level === 0) && typeof this.stopSFX === "function") {
        try { this.stopSFX(); } catch (_) { }
      }
      if ((type === "master" && level === 0) && typeof this.stopAll === "function") {
        try { this.stopAll(); } catch (_) { }
      }
      Object.values(this.music).forEach((audio) => {
        audio.volume = this.config.musicVolume * this.config.masterVolume;
      });
    },


    /**
     * Get current volume levels
     * @returns {object}
     */
    getVolumes: function () {
      return {
        master: this.config.masterVolume,
        sfx: this.config.sfxVolume,
        music: this.config.musicVolume,
      };
    },

    /**
     * Mute/unmute all audio
     * @param {boolean} muted
     */
    setMuted: function (muted) {
      this.config.isMuted = !!muted;

      Object.values(this.sfx).forEach((audio) => (audio.muted = !!muted));
      Object.values(this.music).forEach((audio) => (audio.muted = !!muted));

      // Hard stop any active audio when muting (fixes "toggle off but still playing")
      if (muted) {
        this.stopAll();
      }
    },


    /**
     * Play a sequence of SFX with timing
     * @param {array} sequence - [{ name, delay }]
     */
    playSequence: function (sequence) {
      let accumulatedDelay = 0;

      sequence.forEach((item) => {
        accumulatedDelay += item.delay || 0;
        this.playSFX(item.name, { delay: accumulatedDelay });
      });
    },

    /**
     * @NEW 2025-12-18: Automated Sound Design Layering
     * Automatically triggers "whooshes" and "pops" based on engine events (Phase 6)
     */
    autoSFX: function (type) {
      const map = {
        transition: "whoosh",
        textReveal: "reveal",
        correct: "success",
      };
      const sfxName = map[type] || type;
      this.playSFX(sfxName, { volume: 0.5 });
    },

    // ==========================================
    // INTERNAL METHODS
    // ==========================================

    _fadeVolume: function (audio, from, to, duration, callback) {
      const startTime = Date.now();
      const diff = to - from;

      const fade = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(1, elapsed / duration);

        audio.volume = from + diff * progress;

        if (progress < 1) {
          requestAnimationFrame(fade);
        } else {
          audio.volume = to;
          if (callback) callback();
        }
      };

      requestAnimationFrame(fade);
    },

    /**
     * Load custom audio file
     * @param {string} type - 'sfx' or 'music'
     * @param {string} name - Name to use
     * @param {File|Blob|string} source - File, Blob, or URL
     */
    loadCustom: function (type, name, source) {
      return new Promise((resolve, reject) => {
        let url;

        if (typeof source === "string") {
          url = source;
        } else {
          url = URL.createObjectURL(source);
        }

        const audio = new Audio(url);
        audio.preload = "auto";

        audio.onloadeddata = () => {
          if (type === "sfx") {
            audio.volume = this.config.sfxVolume * this.config.masterVolume;
            this.sfx[name] = audio;
          } else {
            audio.loop = true;
            audio.volume = this.config.musicVolume * this.config.masterVolume;
            this.music[name] = audio;
          }
          resolve(audio);
        };

        audio.onerror = reject;
      });
    },

    stopAll: function () {
      this.stopMusic();
      this.stopSFX();
      console.debug("[NM Audio] Stopped all audio playback.");
    },



    /**
     * Cleanup - call when leaving page
     */
    cleanup: function () {
      this.stopMusic();
      Object.values(this.sfx).forEach((audio) => {
        audio.pause();
        audio.src = "";
      });
      Object.values(this.music).forEach((audio) => {
        audio.pause();
        audio.src = "";
      });
      this.sfx = {};
      this.music = {};
    },
  };

  // Export to window
  window.MCQVS_AudioManager = MCQVS_AudioManager;
})(window);
