<?php

/**
 * System Requirements DTO
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Schema;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Value Object for System Requirements.
 */
class System_Reqs
{
    use Type_Safety;

    /** @var array */
    public $minimum = array();

    /** @var array */
    public $recommended = array();

    /**
     * Create from array with defaults.
     *
     * @param array $data Input array.
     * @return self
     */
    public static function from_array($data = array())
    {
        $instance = new self();
        $data = (array) $data;

        // Support both old flat array and new structured key
        if (isset($data['minimum'])) {
            $instance->minimum = self::as_array($data['minimum']);
        }

        if (isset($data['recommended'])) {
            $instance->recommended = self::as_array($data['recommended']);
        }

        // If data is just a flat list (legacy), we might want to put it in minimum or handle it?
        // For now, if 'minimum' key is missing but data has other numeric keys or is a list,
        // we leave it as empty or map vaguely. The plan is to be strict.
        // However, we can preserve extra data if needed.
        if (empty($instance->minimum) && empty($instance->recommended) && !empty($data)) {
            // Check if input looks like a legacy list of string reqs
            if (isset($data[0])) {
                // It's a flat list. Store in minimum['additional'] or similar?
                // Let's just store it in minimum for backward compat if it fits.
                $instance->minimum = $data;
            }
        }

        return $instance;
    }

    /**
     * Convert to array.
     *
     * @return array
     */
    public function to_array()
    {
        return get_object_vars($this);
    }
}
