<?php

/**
 * Schema Generator (canonical SEO namespace)
 *
 * Thin wrapper for the legacy Core\SEO\Schema_Generator to keep a single
 * SEO namespace for new work: DIT\TrendStudio\SEO\*.
 *
 * @package DIT_TrendStudio\SEO
 * @since 2.15.4
 */

namespace DIT\TrendStudio\SEO;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Canonical Schema Generator.
 */
class SchemaGenerator extends \DIT\TrendStudio\Core\SEO\Schema_Generator
{
}
