<?php

namespace DIT\TrendStudio\Admin;

use DIT\TrendStudio\Services\Social_Queue_Manager;

class Drip_Settings_Page
{
    private Social_Queue_Manager $queue;

    const PAGE_SLUG   = 'dit-ts-drip-settings';
    const NONCE_KEY   = 'dit_ts_drip_settings_nonce';

    // All networks Bit Social supports
    const NETWORKS = [
        'facebook'  => 'Facebook',
        'instagram' => 'Instagram',
        'x'         => 'X (Twitter)',
        'pinterest' => 'Pinterest',
        'linkedin'  => 'LinkedIn',
        'tiktok'    => 'TikTok',
    ];

    const MAX_SLOTS = 5;

    public function __construct(Social_Queue_Manager $queue)
    {
        $this->queue = $queue;
    }

    public function init(): void
    {
        \add_action('admin_menu', [$this, 'register_menu']);
        \add_action('admin_post_dit_ts_save_drip_rules', [$this, 'handle_save']);
        \add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function register_menu(): void
    {
        add_submenu_page(
            'dit-trend-studio',   // Parent menu slug — adjust to your plugin's menu
            \__('Social Drip Rules', 'dit-trend-studio'),
            \__('Social Drip', 'dit-trend-studio'),
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'render_page']
        );
    }

    public function enqueue_assets(string $hook): void
    {
        if (strpos($hook, self::PAGE_SLUG) === false) return;

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_media();
    }

    public function handle_save(): void
    {
        if (!\check_admin_referer(self::NONCE_KEY)) {
            \wp_die('Security check failed');
        }

        if (!\current_user_can('manage_options')) {
            \wp_die('Unauthorized');
        }

        $posted_rules  = $_POST['drip_rules'] ?? [];
        $posted_x_keys = $_POST['dit_ts_x'] ?? [];
        $sanitized     = [];

        foreach ($posted_rules as $vertical => $slots) {
            $vertical = \sanitize_key($vertical);
            $sanitized[$vertical] = [];

            foreach ($slots as $slot_num => $slot) {
                $slot_num = (int)$slot_num;
                if ($slot_num < 1 || $slot_num > self::MAX_SLOTS) continue;

                $networks = array_map('sanitize_key', (array)($slot['networks'] ?? []));
                $networks = array_intersect($networks, array_keys(self::NETWORKS));

                $sanitized[$vertical][$slot_num] = [
                    'enabled'          => !empty($slot['enabled']),
                    'delay_minutes'    => max(0, (int)($slot['delay_minutes'] ?? 0)),
                    'networks'         => array_values($networks),
                    'image_source'     => sanitize_text_field($slot['image_source'] ?? 'collage'),
                    'message_template' => sanitize_textarea_field($slot['message_template'] ?? ''),
                ];
            }
        }

        $this->queue->save_rules($sanitized);

        // Save X API credentials
        $x_fields = ['consumer_key', 'consumer_secret', 'access_token', 'token_secret'];
        foreach ($x_fields as $field) {
            if (isset($posted_x_keys[$field])) {
                update_option('dit_ts_x_' . $field, sanitize_text_field($posted_x_keys[$field]));
            }
        }



        \wp_redirect(\add_query_arg([
            'page'    => self::PAGE_SLUG,
            'saved'   => '1',
        ], \admin_url('admin.php')));
        exit;
    }

    public function render_page(): void
    {
        $rules    = $this->queue->get_all_rules();
        $verticals = array_unique(array_merge(['fashion', 'showbiz', 'general'], array_keys($rules)));

        // Build gallery index options
        $gallery_index_options = ['collage' => '4:5 Auto-Generated Collage', 'featured' => 'Featured Image'];
        for ($i = 0; $i <= 14; $i++) {
            $gallery_index_options["gallery_index:{$i}"] = 'Gallery Image #' . ($i + 1);
        }
        ?>
        <div class="wrap">
            <h1>Social Drip Sharing Rules</h1>
            <p style="color:#666">Configure how many times each post category shares to social media, with which image and on which networks.</p>

            <?php if (!empty($_GET['saved'])): ?>
                <div class="notice notice-success"><p>Rules saved successfully.</p></div>
            <?php endif; ?>

            <form method="post" action="<?= esc_url(admin_url('admin-post.php')) ?>">
                <?php wp_nonce_field(self::NONCE_KEY); ?>
                <input type="hidden" name="action" value="dit_ts_save_drip_rules">

                <!-- X API Credentials -->
                <h2>X (Twitter) Direct API Credentials</h2>
                <table class="form-table">
                    <?php foreach (['consumer_key' => 'Consumer Key', 'consumer_secret' => 'Consumer Secret', 'access_token' => 'Access Token', 'token_secret' => 'Token Secret'] as $key => $label): ?>
                    <tr>
                        <th><?= esc_html($label) ?></th>
                        <td>
                            <input type="password" name="dit_ts_x[<?= esc_attr($key) ?>]"
                                   value="<?= esc_attr(get_option('dit_ts_x_' . $key)) ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>

                <hr>



                <!-- Vertical Tabs -->
                <h2 class="nav-tab-wrapper" style="margin-bottom:0">
                    <?php foreach ($verticals as $i => $v): ?>
                        <a href="#tab-<?= esc_attr($v) ?>"
                           class="nav-tab<?= $i === 0 ? ' nav-tab-active' : '' ?>"
                           onclick="showTab('<?= esc_js($v) ?>'); return false;">
                            <?= esc_html(ucfirst($v)) ?>
                        </a>
                    <?php endforeach; ?>
                </h2>

                <?php foreach ($verticals as $i => $vertical):
                    $v_rules = $rules[$vertical] ?? []; ?>

                    <div id="tab-<?= esc_attr($vertical) ?>"
                         class="dit-ts-tab-content"
                         style="<?= $i > 0 ? 'display:none;' : '' ?> border:1px solid #ccd0d4; padding:20px; background:#fff;">

                        <h3><?= esc_html(ucfirst($vertical)) ?> — Drip Share Schedule</h3>

                        <?php for ($slot = 1; $slot <= self::MAX_SLOTS; $slot++):
                            $s = $v_rules[$slot] ?? [];
                            $enabled   = !empty($s['enabled']);
                            $delay     = (int)($s['delay_minutes'] ?? 0);
                            $sel_nets  = (array)($s['networks'] ?? []);
                            $img_src   = $s['image_source'] ?? ($slot === 1 ? 'collage' : "gallery_index:" . ($slot - 1));
                            $msg_tpl   = $s['message_template'] ?? "{urdu_head}\n\n{hashtags}\n\n{link}";
                            $prefix    = "drip_rules[{$vertical}][{$slot}]";
                            ?>

                            <div style="border:1px solid #e2e4e7; padding:15px; margin-bottom:15px; background:<?= $slot === 1 ? '#f0f7ff' : '#fafafa' ?>">
                                <label style="font-weight:600; font-size:14px;">
                                    <input type="checkbox" name="<?= esc_attr($prefix) ?>[enabled]"
                                           value="1" <?= checked($enabled, true, false) ?>>
                                    Share #<?= $slot ?><?= $slot === 1 ? ' (On Publish)' : '' ?>
                                </label>

                                <table class="form-table" style="margin-top:10px">
                                    <?php if ($slot > 1): ?>
                                    <tr>
                                        <th style="width:200px">Delay After Publish</th>
                                        <td>
                                            <input type="number" min="0" max="10080"
                                                   name="<?= esc_attr($prefix) ?>[delay_minutes]"
                                                   value="<?= esc_attr($delay) ?>"
                                                   style="width:100px"> minutes
                                            <span style="color:#888">(<?= esc_html(round($delay / 60, 1)) ?> hours)</span>
                                        </td>
                                    </tr>
                                    <?php endif; ?>

                                    <tr>
                                        <th>Networks</th>
                                        <td>
                                            <?php foreach (self::NETWORKS as $net_key => $net_label): ?>
                                                <label style="margin-right:15px; display:inline-block">
                                                    <input type="checkbox"
                                                           name="<?= esc_attr($prefix) ?>[networks][]"
                                                           value="<?= esc_attr($net_key) ?>"
                                                           <?= in_array($net_key, $sel_nets, true) ? 'checked' : '' ?>>
                                                    <?= esc_html($net_label) ?>
                                                </label>
                                            <?php endforeach; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Image to Share</th>
                                        <td>
                                            <select name="<?= esc_attr($prefix) ?>[image_source]">
                                                <?php foreach ($gallery_index_options as $opt_val => $opt_label): ?>
                                                    <option value="<?= esc_attr($opt_val) ?>"
                                                            <?= selected($img_src, $opt_val, false) ?>>
                                                        <?= esc_html($opt_label) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Message Template</th>
                                        <td>
                                            <textarea name="<?= esc_attr($prefix) ?>[message_template]"
                                                      rows="3" style="width:500px"><?= esc_textarea($msg_tpl) ?></textarea>
                                            <p class="description">
                                                Available tags: <code>{urdu_head}</code> <code>{urdu_desc}</code>
                                                <code>{hashtags}</code> <code>{link}</code>
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        <?php endfor; ?>
                    </div>
                <?php endforeach; ?>

                <?php submit_button('Save Drip Rules') ?>
            </form>
        </div>

        <script>
        function showTab(v) {
            jQuery('.dit-ts-tab-content').hide();
            jQuery('.nav-tab').removeClass('nav-tab-active');
            jQuery('#tab-' + v).show();
            jQuery(event.target).addClass('nav-tab-active');
        }

        // Color Picker & Media Upload
        jQuery(document).ready(function($){
            $('.wp-color-picker').wpColorPicker();

            // Live delay → hours display
            $('input[name*="delay_minutes"]').on('input', function() {
                var hours = (this.value / 60).toFixed(1);
                $(this).next('.description-hours').text('(' + hours + ' hours)');
            });


        });
        </script>
        <?php
    }
}
