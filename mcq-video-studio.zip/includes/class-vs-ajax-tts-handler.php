<?php

/**
 * AJAX Handler for Multi-provider TTS Generation
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Calculate estimated TTS duration based on text characteristics and speech rate
 *
 * @param string $text The text to be spoken
 * @param float $rate Speaking rate (1.0 = normal, 2.0 = double speed, etc.)
 * @param string $voice_id Voice identifier (used to infer language)
 * @return float Estimated duration in seconds
 */
function mcqvs_calculate_tts_duration($text, $rate = 1.0, $voice_id = '')
{
    // Default words per minute for normal English speech
    $wpm = 140;
    
    // Adjust for voice characteristics if detectable from voice_id
    $voice_lower = strtolower($voice_id);
    if (strpos($voice_lower, 'neural') !== false || strpos($voice_lower, 'wavenet') !== false) {
        // Neural/Wavenet voices are typically slightly faster
        $wpm = 150;
    }
    
    // Count words (approximate by splitting on spaces and punctuation)
    $word_count = str_word_count(preg_replace('/[^\w\s]/', ' ', $text));
    if ($word_count < 1) {
        // Fallback to character count if no words detected
        $word_count = max(1, strlen($text) / 5); // Assume 5 chars per word
    }
    
    // Calculate base duration in minutes, then convert to seconds
    $duration_minutes = $word_count / $wpm;
    $duration_seconds = $duration_minutes * 60;
    
    // Apply speaking rate (rate = 1.0 is normal, 2.0 is 2x faster = half duration)
    $duration_seconds = $duration_seconds / $rate;
    
    // Ensure minimum duration of 0.5 seconds to prevent division by zero issues
    return max(0.5, $duration_seconds);
}

class VS_AJAX_TTS_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Generate TTS Audio
     */
    public function ajax_generate_tts()
    {
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        $text       = isset($_POST['text']) ? sanitize_textarea_field(wp_unslash($_POST['text'])) : '';
        $provider   = isset($_POST['provider']) ? sanitize_text_field(wp_unslash($_POST['provider'])) : 'google';
        $voice_id   = isset($_POST['voice']) ? sanitize_text_field(wp_unslash($_POST['voice'])) : '';
        $rate       = isset($_POST['rate']) ? floatval(wp_unslash($_POST['rate'])) : 1.0;
        $pitch      = isset($_POST['pitch']) ? floatval(wp_unslash($_POST['pitch'])) : 0.0;

        // @MODIFIED 2026-04-24: Edge is now a standalone free provider — no longer aliased to azure.
        // Azure remains its own paid provider for users with Azure Cognitive Services keys.
        $provider = strtolower($provider);

        // Clamp input (provider-dependent; clamping here keeps cache deterministic)
        $rate = max(0.25, min(2.0, $rate));
        $pitch = max(-20.0, min(20.0, $pitch));
        $target_dir = wp_upload_dir()['basedir'] . '/mcq-video-studio/tts';

        if (empty($text)) {
            wp_send_json_error(__('Text is required', 'mcq-video-studio'));
        }

        // 1. Check Cache
        // @FIX 2026-07-04: Use proper namespaced function with delimiter-separated
        // payload instead of misleading md3() + raw concatenation (collision-prone).
        $cache_key = mcqvs_tts_cache_key($text, $provider, $voice_id, $rate, $pitch);
        $filename = $cache_key . '.mp3';
        $file_path = $target_dir . '/' . $filename;
        $file_url = wp_upload_dir()['baseurl'] . '/mcq-video-studio/tts/' . $filename;

if (file_exists($file_path)) {
    // Calculate estimated duration for synchronization (even for cached files)
    $duration = mcqvs_calculate_tts_duration($text, $rate, $voice_id);
    
    wp_send_json_success(array(
        'audio_url' => $file_url,
        'cached' => true,
        'duration' => $duration
    ));
}

        if (! wp_mkdir_p($target_dir)) {
            wp_send_json_error(__('Could not create storage directory', 'mcq-video-studio'));
        }

        // 2. Delegate to Provider
        $audio_content = null;
        switch ($provider) {
            case 'edge':
                $audio_content = $this->generate_edge_tts($text, $voice_id, $rate, $pitch, $file_path);
                break;
            case 'google':
                $audio_content = $this->generate_google_tts($text, $voice_id, $rate, $pitch);
                break;
            case 'azure':
                $audio_content = $this->generate_azure_tts($text, $voice_id, $rate, $pitch);
                break;
            case 'elevenlabs':
                $audio_content = $this->generate_elevenlabs_tts($text, $voice_id);
                break;
        }

        // @MODIFIED 2026-04-24: Edge TTS writes directly to file via Node.js helper;
        // for other providers, audio_content is in-memory binary.
if ($provider === 'edge') {
    if (file_exists($file_path) && filesize($file_path) > 0) {
        // Calculate estimated duration for synchronization
        $duration = mcqvs_calculate_tts_duration($text, $rate, $voice_id);
        
        wp_send_json_success(array(
            'audio_url' => $file_url,
            'cached' => false,
            'duration' => $duration
        ));
    }
    wp_send_json_error(__('Edge TTS Generation failed — Node.js helper did not produce audio', 'mcq-video-studio'));
}

        if (! $audio_content) {
            wp_send_json_error(__('TTS Generation failed', 'mcq-video-studio'));
        }

if (file_put_contents($file_path, $audio_content)) {
    // Calculate estimated duration for synchronization
    $duration = mcqvs_calculate_tts_duration($text, $rate, $voice_id);
    
    wp_send_json_success(array(
        'audio_url' => $file_url,
        'audio_base64' => base64_encode($audio_content),
        'cached' => false,
        'duration' => $duration
    ));
}

        wp_send_json_error(__('Failed to save audio file', 'mcq-video-studio'));
    }

    /**
     * @NEW 2026-04-24: Free Edge TTS via Node.js edge-tts helper.
     * Uses Microsoft Edge's online TTS service — no API key required, unlimited.
     * The Node.js helper (render-service/edge-tts-helper.js) handles the WebSocket
     * protocol to Microsoft's Edge TTS endpoint and writes MP3 directly to disk.
     */
    private function generate_edge_tts($text, $voice_id, $rate = 1.0, $pitch = 0.0, $output_path = '')
    {
        // Rate limiting: prevent too many TTS requests in short time to avoid Microsoft rate limits
        $rate_limit_key = 'mcqvs_edge_tts_rate_limit';
        $attempts = (int) get_transient($rate_limit_key);
        if ($attempts >= 10) { // Allow max 10 requests per minute
            // Rate limit exceeded - wait before trying again
            sleep(2); // Brief pause to avoid hammering the service
            // Still try, but log the rate limit
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Edge TTS: Rate limit protection triggered', 'warning', array('text_len' => strlen($text)));
            }
        }
        
        $helper_script = MCQVS_PLUGIN_DIR . 'render-service/edge-tts-helper.js';
        if (! file_exists($helper_script)) {
            return null;
        }

        $node_path = $this->find_node_binary();
        if (! $node_path) {
            return null;
        }

        $voice = ($voice_id ?: 'en-US-AriaNeural');
        // @FIX 2026-07-04: Normalize JS sentinel "__webspeech__" so it never leaks
        // into the Edge TTS WebSocket protocol where Microsoft would reject it.
        if ($voice === '__webspeech__') {
            $voice = 'en-US-AriaNeural';
        }
        // @FIX 1.4.9.49 (TTS SSOT): the Studio preview can pass a BROWSER Web Speech
        // voice name (e.g. "Microsoft David - English (United States)") which Edge
        // TTS rejects — that produced the empty-response errors in the logs. Only
        // known Edge voice IDs are accepted; anything else falls back to the
        // Settings default voice, then en-US-AriaNeural.
        if (class_exists('VS_Settings')) {
            $allowed = VS_Settings::get_edge_english_voices();
            if (!isset($allowed[$voice])) {
                $default = get_option('mcqvs_tts_default_voice', 'en-US-AriaNeural');
                if (isset($allowed[$default])) {
                    $voice = $default;
                } else {
                    $voice = 'en-US-AriaNeural';
                }
            }
        } elseif (!preg_match('/^[a-z]{2}-[A-Z]{2}-[A-Za-z]+Neural$/', $voice)) {
            // No VS_Settings (edge case) — require the canonical Edge ID shape.
            $voice = 'en-US-AriaNeural';
        }

        $rate_pct = (int) round(($rate - 1.0) * 100);
        $rate_pct = max(-100, min(200, $rate_pct));
        $rate_attr = ($rate_pct >= 0 ? '+' : '') . $rate_pct . '%';

        $pitch_st = round($pitch, 1);
        $pitch_attr = ($pitch_st >= 0 ? '+' : '') . $pitch_st . 'Hz';

        $safe_text = str_replace(array('"', '`', '$', '\\', "\n", "\r"), array(' ', ' ', ' ', ' ', ' ', ' '), $text);
        $safe_text = trim(preg_replace('/\s+/', ' ', $safe_text));
        if (empty($safe_text)) {
            return null;
        }

        $cmd_parts = array(
            escapeshellarg($node_path),
            escapeshellarg($helper_script),
            '--text=' . escapeshellarg($safe_text),
            '--voice=' . escapeshellarg($voice),
            '--rate=' . escapeshellarg($rate_attr),
            '--pitch=' . escapeshellarg($pitch_attr),
            '--output=' . escapeshellarg($output_path),
        );
        $cmd_line = implode(' ', $cmd_parts);

        $stderr_log = tempnam(sys_get_temp_dir(), 'mcqvs_tts_err_');
        if ($stderr_log === false) {
            // Fallback to a random filename in temp directory if tempnam fails
            $stderr_log = sys_get_temp_dir() . '/mcqvs_tts_err_' . uniqid() . '.tmp';
        }
        $descriptors = array(
            0 => array('pipe', 'r'),
            1 => array('pipe', 'w'),
            2 => array('file', $stderr_log, 'a'),
        );

        $start_time = microtime(true);
        $stdout_output = '';
        $exit_code    = 1;
        $proc_error   = null;

        $proc = @proc_open($cmd_line, $descriptors, $pipes, null, null, array('suppress_errors' => true));
        if (is_resource($proc)) {
            fclose($pipes[0]);
            $stdout_output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            $exit_code = proc_close($proc);
            if ($exit_code === -1) {
                $exit_code = 1;
            }
        } else {
            $proc_error = error_get_last();
        }
        $stderr_output = (string) @file_get_contents($stderr_log);
        @unlink($stderr_log);
        $duration = microtime(true) - $start_time;

        $decoded_stdout = json_decode(trim((string) $stdout_output), true);
        $shell_success  = (is_array($decoded_stdout) && ! empty($decoded_stdout['success']))
            && $exit_code === 0
            && file_exists($output_path)
            && (int) @filesize($output_path) > 0;

        $response_payload = array(
            'success'   => $shell_success,
            'exit_code' => (int) $exit_code,
            'stdout'    => (string) $stdout_output,
            'stderr'    => $stderr_output,
        );
        if ($proc_error) {
            $response_payload['proc_error'] = $proc_error['message'];
        }

         VS_Error_Logger::get_instance()->log_api(
             'edge-tts-helper (local)',
             'SHELL',
             array('voice' => $voice, 'text_len' => strlen($safe_text)),
             $response_payload,
             $duration
         );

         // Update rate limit counter
         $rate_limit_key = 'mcqvs_edge_tts_rate_limit';
         $attempts = (int) get_transient($rate_limit_key);
         set_transient($rate_limit_key, min($attempts + 1, 20), 60); // Cap at 20, expire in 60 seconds

         if ($shell_success) {
             return true;
         }

         // Failure cleanup: do not leave a partial / stale MP3 that a future
         // request could pick up as a malformed cache hit.
         if (file_exists($output_path)) {
             @unlink($output_path);
         }
         return null;
    }

    /**
     * @NEW 2026-04-24: Locate Node.js binary on the server.
     * Checks common paths and PATH environment.
     */
    private function find_node_binary()
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $candidates = array('node', 'nodejs', '/usr/bin/node', '/usr/local/bin/node', '/usr/bin/nodejs');
        foreach ($candidates as $candidate) {
            $test = trim(shell_exec(sprintf('which %s 2>/dev/null || where %s 2>/dev/null', escapeshellarg($candidate), escapeshellarg($candidate))) ?: '');
            if (! empty($test) && is_executable(str_replace(array("\r", "\n"), '', $test))) {
                $cached = str_replace(array("\r", "\n"), '', $test);
                return $cached;
            }
        }

        $cached = false;
        return $cached;
    }

    private function generate_google_tts($text, $voice_id, $rate = 1.0, $pitch = 0.0)
    {
        // @MODIFIED 2026-01-08: Canonical read with fallback
        $api_key = get_option('mcqvs_google_cloud_tts_key', get_option('MCQVS_google_cloud_tts_key', ''));
        if (empty($api_key)) return null;

        $url = 'https://texttospeech.googleapis.com/v1/text:synthesize?key=' . $api_key;
        $body = array(
            'input' => array('text' => $text),
            'voice' => array('languageCode' => 'en-US', 'name' => $voice_id ? $voice_id : 'en-US-Wavenet-D'),
            'audioConfig' => array(
                'audioEncoding' => 'MP3',
                'speakingRate'  => $rate,
                'pitch'         => $pitch,
            ),
        );

        $start_time = microtime(true);
        $response = wp_remote_post($url, array(
            'body'    => json_encode($body),
            'headers' => array('Content-Type' => 'application/json'),
        ));
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', $body, $response, $duration);

        if (is_wp_error($response)) return null;
        // @FIX: Reject non-2xx responses — without this, 401/403/429 return bodies that look "successful".
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            VS_Error_Logger::get_instance()->log('Google TTS: Non-2xx response', 'error', array('code' => $code));
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return isset($data['audioContent']) ? base64_decode($data['audioContent']) : null;
    }

    private function generate_azure_tts($text, $voice_id, $rate = 1.0, $pitch = 0.0)
    {
        // @MODIFIED 2026-01-08: Canonical read with fallback
        $api_key = get_option('mcqvs_azure_tts_key', get_option('MCQVS_azure_tts_key', ''));
        $region  = get_option('mcqvs_azure_tts_region', get_option('MCQVS_azure_tts_region', ''));
        if (empty($api_key) || empty($region)) return null;

        $url = "https://{$region}.tts.speech.microsoft.com/cognitiveservices/v1";
        $headers = array(
            'Ocp-Apim-Subscription-Key' => $api_key,
            'Content-Type'              => 'application/ssml+xml',
            'X-Microsoft-OutputFormat'  => 'audio-16khz-128kbitrate-mono-mp3',
        );

        $safe_text = esc_html($text);
        $voice = ($voice_id ?: 'en-US-AvaMultilingualNeural');

        // Azure SSML: prosody rate as % and pitch as semitones
        $use_prosody = (abs($rate - 1.0) > 0.001) || (abs($pitch) > 0.001);
        if ($use_prosody) {
            $rate_pct = (int) round(($rate - 1.0) * 50); // conservative mapping
            $rate_pct = max(-50, min(100, $rate_pct));
            $rate_attr = ($rate_pct >= 0 ? '+' : '') . $rate_pct . '%';

            $pitch_st = round($pitch, 1);
            $pitch_attr = ($pitch_st >= 0 ? '+' : '') . $pitch_st . 'st';

            $ssml = "<speak version='1.0' xml:lang='en-US'><voice name='{$voice}'><prosody rate='{$rate_attr}' pitch='{$pitch_attr}'>{$safe_text}</prosody></voice></speak>";
        } else {
            $ssml = "<speak version='1.0' xml:lang='en-US'><voice name='{$voice}'>{$safe_text}</voice></speak>";
        }

        $start_time = microtime(true);
        $response = wp_remote_post($url, array('headers' => $headers, 'body' => $ssml));
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', array('body' => $ssml), $response, $duration);
        if (is_wp_error($response)) return null;
        // @FIX: Reject non-2xx responses — without this gate, Azure 401s were returning XML bodies
        //       treated as success and shipped back to the browser as garbled "audio".
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            VS_Error_Logger::get_instance()->log('Azure TTS: Non-2xx response', 'error', array('code' => $code));
            return null;
        }
        return wp_remote_retrieve_body($response);
    }

    public function generate_elevenlabs_tts($text, $voice_id)
    {
        // @MODIFIED 2026-01-08: Canonical read with fallback
        $api_key = get_option('mcqvs_elevenlabs_api_key', get_option('MCQVS_elevenlabs_api_key', ''));
        if (empty($api_key)) return null;

        $voice = $voice_id ?: 'pNInz6obpgueP9Nst9zR'; // Default Adam
        $url   = "https://api.elevenlabs.io/v1/text-to-speech/{$voice}";

        $start_time = microtime(true);
        $response = wp_remote_post($url, array(
            'headers' => array('xi-api-key' => $api_key, 'Content-Type' => 'application/json'),
            'body'    => json_encode(array('text' => $text, 'model_id' => 'eleven_monolingual_v1')),
            'timeout' => 30,
        ));
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', array('text' => $text), $response, $duration);

        if (is_wp_error($response)) return null;
        // @FIX: Isolate non-2xx responses; without this we would silently ship the JSON error body.
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            VS_Error_Logger::get_instance()->log('ElevenLabs TTS: Non-2xx response', 'error', array('code' => $code));
            return null;
        }
        return wp_remote_retrieve_body($response);
    }

    /**
     * AJAX: Get ElevenLabs Cloned Voices
     */
    public function ajax_get_elevenlabs_voices()
    {
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        // @MODIFIED 2026-01-08: Canonical read with fallback
        $api_key = get_option('mcqvs_elevenlabs_api_key', get_option('MCQVS_elevenlabs_api_key', ''));
        if (empty($api_key)) {
            wp_send_json_error(__('API Key missing', 'mcq-video-studio'));
        }

        $start_time = microtime(true);
        $response = wp_remote_get('https://api.elevenlabs.io/v1/voices', array(
            'headers' => array('xi-api-key' => $api_key),
        ));
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api('https://api.elevenlabs.io/v1/voices', 'GET', array(), $response, $duration);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        // @FIX: non-2xx responses still arrive as non-empty JSON; gate them.
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            wp_send_json_error('ElevenLabs API error: HTTP ' . $code);
        }

        wp_send_json_success(json_decode(wp_remote_retrieve_body($response), true));
    }
}

/**
 * Helper: TTS cache key generator
 * @FIX 2026-07-04: Replaced misleading md3() with explicit delimiter-based hash.
 * Prevents cache collisions when text boundaries align with parameter values.
 * @FIX 2026-07-22: Normalize 'webspeech' provider to 'edge' for server-side renders.
 * Browser preview uses webspeech, server uses edge — cache key must be consistent.
 */
if (! function_exists('mcqvs_tts_cache_key')) {
    function mcqvs_tts_cache_key($text, $provider, $voice_id, $rate, $pitch)
    {
        // Normalize provider: webspeech requires browser → server uses edge
        $normalized_provider = strtolower($provider);
        if ($normalized_provider === 'webspeech') {
            $normalized_provider = 'edge';
        }
        $payload = implode('|', array(
            trim($text),
            $normalized_provider,
            strtolower($voice_id),
            number_format((float) $rate, 2, '.', ''),
            number_format((float) $pitch, 2, '.', ''),
        ));
        return md5($payload);
    }
}
