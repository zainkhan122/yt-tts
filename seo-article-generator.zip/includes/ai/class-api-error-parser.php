<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI\Quota_Reset_Calculator;
use SEO_Article_Generator\Utils\Plugin_Time;

if (!defined('ABSPATH')) {
    exit;
}

class API_Error_Parser
{
    public static function parse(string $provider, int $status_code, string $body, array $headers = array()): API_Error_Info
    {
        $data = array(
            'provider' => $provider,
            'http_status' => $status_code,
            'error_status' => '',
            'error_code' => $status_code,
            'message' => '',
            'error_type' => API_Error_Info::TYPE_UNKNOWN,
            'retry_delay_seconds' => 0,
            'quota_metric' => '',
            'quota_limit' => 0,
            'is_retryable' => false,
            'is_deterministic' => false,
            'reset_at_ts' => 0,
            'details_raw' => array(),
            'field_violations' => array(),
            'response_headers' => $headers,
        );

        switch ($provider) {
            case 'gemini':
                return self::parse_gemini($data, $status_code, $body);
            case 'openai':
                return self::parse_openai($data, $status_code, $body, $headers);
            case 'groq':
                return self::parse_groq($data, $status_code, $body, $headers);
            case 'perplexity':
                return self::parse_perplexity($data, $status_code, $body, $headers);
            case 'openrouter':
                return self::parse_openrouter($data, $status_code, $body, $headers);
            default:
                // OpenAI-compatible custom providers (e.g. opencode.ai/zen/v1) emit the
                // OpenAI error taxonomy, so parse them like OpenAI instead of only by
                // HTTP status. Without this they fell into parse_generic and lost body semantics.
                if (self::is_openai_compatible_custom($provider)) {
                    return self::parse_openai($data, $status_code, $body, $headers);
                }
                return self::parse_generic($data, $status_code, $body);
        }
    }

    private static function parse_gemini(array $data, int $status_code, string $body): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (!is_array($decoded)) {
            return self::classify_by_http_status($data, $status_code);
        }

        $error = $decoded['error'] ?? array();
        if (!is_array($error)) {
            $error = array();
        }

        $data['error_status'] = (string) ($error['status'] ?? '');
        $data['error_code'] = (int) ($error['code'] ?? $status_code);
        $data['message'] = (string) ($error['message'] ?? '');
        $data['details_raw'] = (array) ($error['details'] ?? array());

        $details = $data['details_raw'];
        $retry_delay = 0;
        $quota_metric = '';
        $quota_limit = 0;
        $field_violations = array();

        foreach ($details as $detail) {
            if (!is_array($detail)) {
                continue;
            }

            $type = (string) ($detail['@type'] ?? '');

            if ($type === 'type.googleapis.com/google.rpc.RetryInfo') {
                $retry_delay_str = (string) ($detail['retryDelay'] ?? '');
                $retry_delay = self::parse_duration_seconds($retry_delay_str);
            }

            if ($type === 'type.googleapis.com/google.rpc.QuotaFailure') {
                $violations = (array) ($detail['violations'] ?? array());
                foreach ($violations as $v) {
                    if (!is_array($v)) {
                        continue;
                    }
                    $subject = (string) ($v['subject'] ?? '');
                    $description = (string) ($v['description'] ?? '');
                    if ($subject !== '' && $quota_metric === '') {
                        $quota_metric = $subject;
                    }
                    $limit_match = array();
                    if ($quota_limit === 0 && $description !== '' && preg_match('/(\d+)/', $description, $limit_match)) {
                        $quota_limit = (int) $limit_match[1];
                    }
                }
            }

            if ($type === 'type.googleapis.com/google.rpc.BadRequest') {
                $fv = (array) ($detail['fieldViolations'] ?? array());
                foreach ($fv as $violation) {
                    if (!is_array($violation)) {
                        continue;
                    }
                    $field_violations[] = array(
                        'field' => (string) ($violation['field'] ?? ''),
                        'description' => (string) ($violation['description'] ?? ''),
                    );
                }
            }
        }

        $data['retry_delay_seconds'] = $retry_delay;
        $data['quota_metric'] = $quota_metric;
        $data['quota_limit'] = $quota_limit;
        $data['field_violations'] = $field_violations;

        $error_status = $data['error_status'];

        switch ($error_status) {
            case 'RESOURCE_EXHAUSTED':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $quota_type = self::classify_gemini_quota_type($quota_metric);
                if ($quota_type === API_Error_Info::TYPE_QUOTA_UNKNOWN) {
                    // GUARD: If Gemini includes a RetryInfo with retryDelay, this is
                    // a temporary per-minute rate limit — NOT a daily quota exhaustion.
                    // Daily quota resets at midnight Pacific and never carries a short
                    // retryDelay. Without this guard, temporary RPM errors that happen
                    // to contain "billing"/"plan" in the message body were misclassified
                    // as RPD, triggering a 15-18 hour block instead of a 30-60s retry.
                    if ($retry_delay > 0) {
                        $quota_type = API_Error_Info::TYPE_QUOTA_RPM;
                    } else {
                        // Fallback: Gemini free-tier DAILY exhaustion frequently omits
                        // the QuotaFailure 'subject', leaving the metric empty. Require
                        // BOTH "exceeded your current quota" AND one of "billing"/"plan"
                        // to avoid false positives from per-minute error variants that
                        // share similar copy but DO carry a retryDelay (handled above).
                        $msg_l = strtolower($data['message']);
                        if (strpos($msg_l, 'exceeded your current quota') !== false
                            && (strpos($msg_l, 'billing') !== false
                                || strpos($msg_l, 'plan') !== false)) {
                            $quota_type = API_Error_Info::TYPE_QUOTA_RPD;
                        }
                    }
                }
                $data['error_type'] = $quota_type;
                $data['reset_at_ts'] = self::compute_gemini_reset_ts($data['error_type'], $retry_delay);
                break;

            case 'INVALID_ARGUMENT':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_REQUEST_SHAPE;
                break;

            case 'NOT_FOUND':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                break;

            case 'PERMISSION_DENIED':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            case 'UNAUTHENTICATED':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            case 'INTERNAL':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                if ($retry_delay === 0) {
                    $data['retry_delay_seconds'] = 30;
                }
                break;

            case 'UNAVAILABLE':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                if ($retry_delay === 0) {
                    $data['retry_delay_seconds'] = 30;
                }
                break;

            case 'FORBIDDEN':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            default:
                $data = self::classify_by_http_status($data, $status_code)->to_array();
                $data['error_status'] = $error_status;
                $data['message'] = $data['message'] ?: (string) ($error['message'] ?? '');
                $data['details_raw'] = $details;
                $data['retry_delay_seconds'] = $retry_delay;
                $data['quota_metric'] = $quota_metric;
                $data['quota_limit'] = $quota_limit;
                $data['field_violations'] = $field_violations;
                break;
        }

        return API_Error_Info::from_array($data);
    }

    private static function classify_gemini_quota_type(string $metric): string
    {
        $m = strtolower($metric);
        if ($m === '') {
            return API_Error_Info::TYPE_QUOTA_UNKNOWN;
        }
        if (strpos($m, 'perday') !== false || strpos($m, 'per_day') !== false || strpos($m, 'perdayperprojectpermodel') !== false) {
            return API_Error_Info::TYPE_QUOTA_RPD;
        }
        if (strpos($m, 'perminute') !== false || strpos($m, 'per_minute') !== false || strpos($m, 'requestsperminute') !== false) {
            return API_Error_Info::TYPE_QUOTA_RPM;
        }
        if (strpos($m, 'tokensperminute') !== false || strpos($m, 'perminutepermodel') !== false) {
            return API_Error_Info::TYPE_QUOTA_TPM;
        }
        return API_Error_Info::TYPE_QUOTA_UNKNOWN;
    }

    private static function compute_gemini_reset_ts(string $quota_type, int $retry_delay): int
    {
        $now = Plugin_Time::now_utc_ts();
        if ($quota_type === API_Error_Info::TYPE_QUOTA_RPD) {
            return Quota_Reset_Calculator::gemini_next_rpd_reset_ts($now);
        }
        if ($retry_delay > 0) {
            return $now + $retry_delay;
        }
        if ($quota_type === API_Error_Info::TYPE_QUOTA_RPM) {
            return $now + 60;
        }
        if ($quota_type === API_Error_Info::TYPE_QUOTA_TPM) {
            return $now + 60;
        }
        return $now + 300;
    }

    private static function parse_openai(array $data, int $status_code, string $body, array $headers): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (!is_array($decoded)) {
            return self::classify_by_http_status($data, $status_code);
        }

        $error = $decoded['error'] ?? array();
        if (!is_array($error)) {
            $error = array();
        }

        $data['error_status'] = (string) ($error['type'] ?? '');
        $data['error_code'] = $status_code;
        $data['message'] = (string) ($error['message'] ?? '');
        $data['details_raw'] = $error;

        $error_type_str = (string) ($error['type'] ?? '');
        $error_code_str = (string) ($error['code'] ?? '');

        $reset_ts = self::parse_rate_limit_reset_header($headers, 'x-ratelimit-reset-requests');
        $retry_after_header = self::parse_retry_after_header($headers);

        $data['retry_delay_seconds'] = $retry_after_header;
        $data['reset_at_ts'] = $reset_ts > 0 ? $reset_ts : 0;

        $remaining = self::parse_rate_limit_remaining($headers, 'x-ratelimit-remaining-requests');
        $limit_val = self::parse_rate_limit_remaining($headers, 'x-ratelimit-limit-requests');
        $data['quota_limit'] = $limit_val;

        switch ($error_type_str) {
            case 'rate_limit_error':
            case 'insufficient_quota':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                if ($error_code_str === 'insufficient_quota' || strpos(strtolower($data['message']), 'monthly') !== false || strpos(strtolower($data['message']), 'billing') !== false) {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPD;
                    $data['reset_at_ts'] = $reset_ts > 0 ? $reset_ts : Quota_Reset_Calculator::generic_next_reset_ts();
                } else {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPM;
                    if ($data['retry_delay_seconds'] === 0) {
                        $data['retry_delay_seconds'] = 20;
                    }
                    if ($data['reset_at_ts'] === 0) {
                        $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                    }
                }
                break;

            case 'authentication_error':
            case 'invalid_api_key':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            case 'invalid_request_error':
                if ($status_code === 404) {
                    $data['is_retryable'] = false;
                    $data['is_deterministic'] = true;
                    $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                } else {
                    $data['is_retryable'] = false;
                    $data['is_deterministic'] = true;
                    $data['error_type'] = API_Error_Info::TYPE_REQUEST_SHAPE;
                }
                break;

            case 'server_error':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                if ($data['retry_delay_seconds'] === 0) {
                    $data['retry_delay_seconds'] = 30;
                }
                break;

            default:
                $data = self::classify_by_http_status($data, $status_code)->to_array();
                break;
        }

        return API_Error_Info::from_array($data);
    }

    /**
     * OpenRouter uses its OWN error taxonomy (NOT OpenAI's type field).
     * Docs: error.code is the HTTP status, error.message is human text, and
     * error.metadata carries { provider_name, raw (upstream error), is_byok }.
     * Relying on parse_openai mis-classified every OpenRouter error because the
     * OpenAI `error.type` values never appear in OpenRouter payloads.
     */
    private static function parse_openrouter(array $data, int $status_code, string $body, array $headers): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (!is_array($decoded)) {
            return self::parse_generic($data, $status_code, $body);
        }

        $error = $decoded['error'] ?? array();
        if (!is_array($error)) {
            $error = array();
        }

        $code = (int) ($error['code'] ?? $status_code);
        $message = (string) ($error['message'] ?? '');
        $data['error_status'] = (string) ($error['type'] ?? '');
        $data['error_code'] = $code;
        $data['message'] = $message;
        $data['details_raw'] = $error;

        // OpenRouter nests the upstream/provider-specific error inside metadata.raw
        // (e.g. a 502 "Provider returned error" body that is really a model-not-found
        // or a Google AI Studio 429). Parse it so we catch hidden model/quota semantics.
        $metadata = isset($error['metadata']) && is_array($error['metadata']) ? $error['metadata'] : array();
        $raw = $metadata['raw'] ?? null;
        $upstream_message = '';
        $upstream_code = 0;
        if (is_string($raw) && $raw !== '') {
            $dec = @json_decode($raw, true);
            if (is_array($dec)) {
                $ue = $dec['error'] ?? $dec;
                $upstream_message = (string) ($ue['message'] ?? '');
                $upstream_code = (int) ($ue['code'] ?? 0);
            }
        } elseif (is_array($raw)) {
            $upstream_message = (string) ($raw['error']['message'] ?? $raw['message'] ?? '');
        }

        $retry_after = self::parse_retry_after_header($headers);
        $data['retry_delay_seconds'] = $retry_after;
        $data['reset_at_ts'] = 0;

        $msg_lower = strtolower($message . ' ' . $upstream_message);

        switch ($code) {
            case 401:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            case 402:
                // Insufficient credits — block whole provider until resolved.
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPD;
                $data['reset_at_ts'] = Quota_Reset_Calculator::generic_next_reset_ts();
                break;

            case 403:
                if (strpos($msg_lower, 'safety') !== false
                    || strpos($msg_lower, 'moderation') !== false
                    || strpos($msg_lower, 'guardrail') !== false
                    || strpos($msg_lower, 'content policy') !== false
                    || strpos($msg_lower, 'flagged') !== false) {
                    $data['is_retryable'] = false;
                    $data['is_deterministic'] = true;
                    $data['error_type'] = API_Error_Info::TYPE_SAFETY_BLOCK;
                } else {
                    $data['is_retryable'] = false;
                    $data['is_deterministic'] = true;
                    $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                }
                break;

            case 404:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                break;

            case 408:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_TRANSIENT;
                if ($retry_after === 0) {
                    $data['retry_delay_seconds'] = 15;
                }
                $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                break;

            case 413:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_QUOTA_TPM;
                $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                break;

            case 429:
                if (strpos($msg_lower, 'per day') !== false
                    || strpos($msg_lower, 'daily') !== false
                    || strpos($msg_lower, 'free-models-per-day') !== false) {
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPD;
                    $data['reset_at_ts'] = $retry_after > 0 ? Plugin_Time::now_utc_ts() + $retry_after : Quota_Reset_Calculator::generic_next_reset_ts();
                } else {
                    // Upstream rate limit (e.g. Google AI Studio) surfaced through OpenRouter.
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPM;
                    if ($retry_after === 0) {
                        $data['retry_delay_seconds'] = 20;
                    }
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                }
                break;

            case 502:
            case 503:
                // 502 = provider/model down; 503 = no provider meeting routing.
                // Both mean: switch model/provider, do not hammer the same endpoint.
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                $data['retry_delay_seconds'] = max($retry_after, 30);
                $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                break;

            default:
                if ($status_code === 429) {
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_UNKNOWN;
                    $data['retry_delay_seconds'] = max($retry_after, 30);
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                } else {
                    $data = self::classify_by_http_status($data, $status_code)->to_array();
                    $data['error_status'] = (string) ($error['type'] ?? '');
                    $data['message'] = $message;
                    $data['details_raw'] = $error;
                }
                break;
        }

        return API_Error_Info::from_array($data);
    }

    private static function is_openai_compatible_custom(string $provider): bool
    {
        if ($provider === 'openai' || $provider === 'openrouter' || $provider === 'groq' || $provider === 'perplexity' || $provider === 'gemini') {
            return false;
        }
        $endpoint = '';
        if (class_exists('\\SEO_Article_Generator\\AI\\Provider_Registry')) {
            $endpoint = (string) \SEO_Article_Generator\AI\Provider_Registry::get_instance()->get_endpoint($provider);
        }
        if ($endpoint === '') {
            return false;
        }
        $host = (string) parse_url($endpoint, PHP_URL_HOST);
        $path = (string) parse_url($endpoint, PHP_URL_PATH);
        $lower_host = strtolower($host);
        // opencode.ai/zen/v1 and any host exposing the OpenAI /v1/chat/completions surface.
        if (strpos($lower_host, 'opencode.ai') !== false) {
            return true;
        }
        if (strpos($lower_host, 'openai') !== false) {
            return true;
        }
        if (preg_match('#/v1(/|$)#i', $path)) {
            return true;
        }
        return false;
    }

    private static function parse_groq(array $data, int $status_code, string $body, array $headers): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (!is_array($decoded)) {
            return self::classify_by_http_status($data, $status_code);
        }

        $error = $decoded['error'] ?? array();
        if (!is_array($error)) {
            $error = array();
        }

        $data['error_status'] = (string) ($error['type'] ?? '');
        $data['error_code'] = $status_code;
        $data['message'] = (string) ($error['message'] ?? '');
        $data['details_raw'] = $error;

        $error_type_str = (string) ($error['type'] ?? '');
        $retry_after_header = self::parse_retry_after_header($headers);
        $data['retry_delay_seconds'] = $retry_after_header;

        switch ($error_type_str) {
            case 'rate_limit_exceeded':
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $msg_lower = strtolower($data['message']);
                if (strpos($msg_lower, 'per day') !== false || strpos($msg_lower, 'daily') !== false) {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPD;
                    $data['reset_at_ts'] = Quota_Reset_Calculator::generic_next_reset_ts();
                } elseif ($status_code === 413 || strpos($msg_lower, 'token') !== false || strpos($msg_lower, 'tpm') !== false) {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_TPM;
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                } else {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPM;
                    if ($data['retry_delay_seconds'] === 0) {
                        $data['retry_delay_seconds'] = 15;
                    }
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                }
                break;

            case 'invalid_request_error':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                if ($status_code === 404 || strpos(strtolower($data['message']), 'model') !== false) {
                    $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                } else {
                    $data['error_type'] = API_Error_Info::TYPE_REQUEST_SHAPE;
                }
                break;

            case 'authentication_error':
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            default:
                if ($status_code === 413) {
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_TPM;
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                } elseif ($status_code === 498) {
                    // Groq: Flex Tier Capacity Exceeded — transient, switch model/provider.
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                    $data['retry_delay_seconds'] = max($retry_after_header, 30);
                } elseif ($status_code === 499) {
                    // Groq: Request Cancelled — transient, safe to retry.
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_TRANSIENT;
                    $data['retry_delay_seconds'] = max($retry_after_header, 15);
                } elseif ($status_code === 503) {
                    $data['is_retryable'] = true;
                    $data['is_deterministic'] = false;
                    $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                    $data['retry_delay_seconds'] = max($retry_after_header, 30);
                } else {
                    $data = self::classify_by_http_status($data, $status_code)->to_array();
                }
                break;
        }

        return API_Error_Info::from_array($data);
    }

    private static function parse_perplexity(array $data, int $status_code, string $body, array $headers): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (!is_array($decoded)) {
            return self::classify_by_http_status($data, $status_code);
        }

        $error = $decoded['error'] ?? array();
        if (is_array($error)) {
            $data['message'] = (string) ($error['message'] ?? is_string($decoded['error']) ? $decoded['error'] : '');
            $data['error_status'] = (string) ($error['type'] ?? '');
            $data['details_raw'] = $error;
        } else {
            $data['message'] = is_string($decoded['error']) ? $decoded['error'] : '';
        }

        $retry_after_header = self::parse_retry_after_header($headers);
        $data['retry_delay_seconds'] = $retry_after_header;

        switch ($status_code) {
            case 429:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $msg_lower = strtolower($data['message']);
                if (strpos($msg_lower, 'daily') !== false || strpos($msg_lower, 'per day') !== false) {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPD;
                    $data['reset_at_ts'] = Quota_Reset_Calculator::generic_next_reset_ts();
                } else {
                    $data['error_type'] = API_Error_Info::TYPE_QUOTA_RPM;
                    if ($data['retry_delay_seconds'] === 0) {
                        $data['retry_delay_seconds'] = 15;
                    }
                    $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                }
                break;

            case 401:
            case 403:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;

            case 404:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                break;

            case 422:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_REQUEST_SHAPE;
                break;

            case 503:
            case 500:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                if ($data['retry_delay_seconds'] === 0) {
                    $data['retry_delay_seconds'] = 30;
                }
                break;

            default:
                $data = self::classify_by_http_status($data, $status_code)->to_array();
                break;
        }

        return API_Error_Info::from_array($data);
    }

    private static function parse_generic(array $data, int $status_code, string $body): API_Error_Info
    {
        $decoded = @json_decode($body, true);
        if (is_array($decoded)) {
            $error = $decoded['error'] ?? array();
            if (is_array($error)) {
                $data['message'] = (string) ($error['message'] ?? '');
                $data['error_status'] = (string) ($error['status'] ?? $error['type'] ?? '');
                $data['details_raw'] = $error;
            } elseif (is_string($decoded['error'] ?? null)) {
                $data['message'] = (string) $decoded['error'];
            }
        }
        return self::classify_by_http_status($data, $status_code);
    }

    private static function classify_by_http_status(array $data, int $status_code): API_Error_Info
    {
        switch ($status_code) {
            case 429:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_QUOTA_UNKNOWN;
                $data['retry_delay_seconds'] = max($data['retry_delay_seconds'], 30);
                $data['reset_at_ts'] = Plugin_Time::now_utc_ts() + 60;
                break;
            case 401:
            case 403:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_AUTH_FAILURE;
                break;
            case 404:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_MODEL_NOT_FOUND;
                break;
            case 400:
            case 422:
                $data['is_retryable'] = false;
                $data['is_deterministic'] = true;
                $data['error_type'] = API_Error_Info::TYPE_REQUEST_SHAPE;
                break;
            case 413:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_QUOTA_TPM;
                break;
            case 500:
            case 502:
            case 503:
            case 529:
                $data['is_retryable'] = true;
                $data['is_deterministic'] = false;
                $data['error_type'] = API_Error_Info::TYPE_SERVER_OVERLOADED;
                if ($data['retry_delay_seconds'] === 0) {
                    $data['retry_delay_seconds'] = 30;
                }
                break;
            default:
                $data['error_type'] = API_Error_Info::TYPE_UNKNOWN;
                break;
        }
        return API_Error_Info::from_array($data);
    }

    private static function parse_duration_seconds(string $duration_str): int
    {
        if ($duration_str === '') {
            return 0;
        }
        $duration_str = trim($duration_str);
        if (preg_match('/^(\d+(?:\.\d+)?)\s*s$/i', $duration_str, $m)) {
            return (int) ceil((float) $m[1]);
        }
        if (preg_match('/^(\d+)\s*ms$/i', $duration_str, $m)) {
            return (int) ceil((int) $m[1] / 1000);
        }
        if (is_numeric($duration_str)) {
            return (int) ceil((float) $duration_str);
        }
        return 0;
    }

    private static function parse_rate_limit_reset_header(array $headers, string $header_name): int
    {
        $value = self::get_header($headers, $header_name);
        if ($value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            $ts = (int) $value;
            if ($ts > 1700000000) {
                return $ts;
            }
            return Plugin_Time::now_utc_ts() + $ts;
        }
        $parsed = @strtotime($value);
        return $parsed !== false ? $parsed : 0;
    }

    private static function parse_retry_after_header(array $headers): int
    {
        $value = self::get_header($headers, 'retry-after');
        if ($value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return (int) $value;
        }
        $parsed = @strtotime($value);
        if ($parsed !== false) {
            return max(0, $parsed - Plugin_Time::now_utc_ts());
        }
        return 0;
    }

    private static function parse_rate_limit_remaining(array $headers, string $header_name): int
    {
        $value = self::get_header($headers, $header_name);
        return is_numeric($value) ? (int) $value : 0;
    }

    private static function get_header(array $headers, string $name): string
    {
        $lower = strtolower($name);
        foreach ($headers as $key => $value) {
            if (strtolower((string) $key) === $lower) {
                return is_array($value) ? (string) ($value[0] ?? '') : (string) $value;
            }
        }
        return '';
    }
}
