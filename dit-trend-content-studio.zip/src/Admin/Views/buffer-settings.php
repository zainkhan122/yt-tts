<?php
if (!defined('ABSPATH')) {
    exit;
}

use DIT\TrendStudio\Integrations\Buffer\Account_Manager;

$buffer_accounts = Account_Manager::get_accounts();

// Pre-load cached channel data per account so channels persist across page refreshes
$accounts_cached_data = [];
foreach ($buffer_accounts as $acc_id => $account) {
    $api_key = $account['api_key'] ?? '';
    $cached_channels = [];
    if (!empty($api_key)) {
        $client = new \DIT\TrendStudio\Integrations\Buffer\Client($api_key, null, $acc_id);
        $cached_channels = $client->get_cached_channels();
        if (!empty($cached_channels)) {
            foreach ($cached_channels as $ch_id => &$ch_data) {
                if (($ch_data['service'] ?? '') === 'pinterest') {
                    $transient_key = 'nm_buffer_pinterest_boards_' . md5($ch_id . $api_key);
                    $boards = get_transient($transient_key);
                    if ($boards !== false) {
                        $ch_data['pinterest_boards'] = $boards;
                    }
                }
            }
            unset($ch_data);
        }
    }
    $accounts_cached_data[$acc_id] = [
        'channels' => $cached_channels,
        'configs'  => $account['channels'] ?? [],
    ];
}

$valid_types = [
    'facebook' => ['post', 'story', 'reel'],
    'instagram' => ['post', 'story', 'reel'],
    'twitter' => ['post'],
    'linkedin' => ['post'],
    'pinterest' => ['post'],
    'youtube' => ['video'],
    'threads' => ['post', 'story'],
    'tiktok' => ['post', 'video'],
];
?>

<div class="wrap">
    <h2><?php esc_html_e('Buffer Integration', 'dit-trend-content-studio'); ?></h2>
    <p><?php esc_html_e('Share posts to social media via Buffer API. Add multiple Buffer accounts to extend your available channels (free accounts get 3 channels each).', 'dit-trend-content-studio'); ?></p>

    <div id="dit-ts-buffer-accounts-list" class="dit-ts-buffer-accounts-list">
        <?php foreach ($buffer_accounts as $acc_id => $account) :
            $cached = $accounts_cached_data[$acc_id] ?? ['channels' => [], 'configs' => []];
        ?>
            <div class="dit-ts-buffer-account-card"
                 data-account-id="<?php echo esc_attr($acc_id); ?>"
                 data-cached-channels="<?php echo esc_attr(wp_json_encode($cached['channels'])); ?>"
                 data-account-channels="<?php echo esc_attr(wp_json_encode($cached['configs'])); ?>">
                <div class="dit-ts-buffer-account-header">
                    <input type="hidden" class="dit-ts-buffer-account-id" value="<?php echo esc_attr($acc_id); ?>">
                    <strong class="dit-ts-buffer-account-name-display"><?php echo esc_html($account['name'] ?? $acc_id); ?></strong>
                    <span class="dit-ts-buffer-account-status"><?php echo !empty($account['enabled']) ? __('Enabled', 'dit-trend-content-studio') : __('Disabled', 'dit-trend-content-studio'); ?></span>
                    <button type="button" class="button dit-ts-toggle-buffer-account"><?php esc_html_e('Expand', 'dit-trend-content-studio'); ?></button>
                    <button type="button" class="button dit-ts-remove-buffer-account"><?php esc_html_e('Remove', 'dit-trend-content-studio'); ?></button>
                </div>
                <div class="dit-ts-buffer-account-body" style="display:none;">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Account Name', 'dit-trend-content-studio'); ?></th>
                            <td><input type="text" class="dit-ts-buffer-account-name regular-text" value="<?php echo esc_attr($account['name'] ?? $acc_id); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Account ID (slug)', 'dit-trend-content-studio'); ?></th>
                            <td><input type="text" class="dit-ts-buffer-account-slug regular-text" value="<?php echo esc_attr($acc_id); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('API Key', 'dit-trend-content-studio'); ?></th>
                            <td>
                                <input type="password" class="dit-ts-buffer-api-key regular-text" value="<?php echo esc_attr($account['api_key'] ?? ''); ?>" style="width:400px;">
                                <button type="button" class="button dit-ts-toggle-buffer-key"><?php esc_html_e('Show', 'dit-trend-content-studio'); ?></button>
                                <button type="button" class="button dit-ts-test-buffer-account"><?php esc_html_e('Test Connection', 'dit-trend-content-studio'); ?></button>
                                <button type="button" class="button dit-ts-refresh-buffer-channels"><?php esc_html_e('Refresh Channels', 'dit-trend-content-studio'); ?></button>
                                <div class="dit-ts-buffer-test-result" style="margin-top:4px;"></div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Enabled', 'dit-trend-content-studio'); ?></th>
                            <td><label><input type="checkbox" class="dit-ts-buffer-account-enabled" value="1" <?php checked(!empty($account['enabled'])); ?>> <?php esc_html_e('Enable this account for sharing', 'dit-trend-content-studio'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Daily Share Limit', 'dit-trend-content-studio'); ?></th>
                            <td><input type="number" class="dit-ts-buffer-daily-limit small-text" value="<?php echo esc_attr($account['daily_limit'] ?? 5); ?>" min="0" max="50"><p class="description"><?php esc_html_e('0 = unlimited. Per-account limit.', 'dit-trend-content-studio'); ?></p></td>
                        </tr>
                    </table>

                    <div class="dit-ts-buffer-channel-list">
                        <h4><?php esc_html_e('Channels', 'dit-trend-content-studio'); ?></h4>
                        <div class="dit-ts-buffer-channel-rows"></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <button type="button" class="button" id="dit-ts-add-buffer-account"><?php esc_html_e('Add Buffer Account', 'dit-trend-content-studio'); ?></button>
    <input type="hidden" name="dit_ts_buffer_accounts_json" id="dit_ts_buffer_accounts_json" value="<?php echo esc_attr(wp_json_encode(array_values($buffer_accounts))); ?>">

    <?php submit_button(__('Save Buffer Settings', 'dit-trend-content-studio'), 'primary', 'dit_ts_save_settings'); ?>
</div>

<style>
.dit-ts-buffer-account-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    margin-bottom: 16px;
    padding: 12px;
}
.dit-ts-buffer-account-header {
    display: flex;
    align-items: center;
    gap: 10px;
}
.dit-ts-buffer-account-header .dit-ts-buffer-account-name-display {
    flex: 1;
    font-size: 14px;
}
.dit-ts-buffer-account-status {
    font-size: 12px;
    padding: 2px 8px;
    border-radius: 3px;
    background: #f0f0f1;
}
.dit-ts-buffer-account-body {
    margin-top: 12px;
    border-top: 1px solid #f0f0f1;
    padding-top: 12px;
}
</style>

<script>
jQuery(document).ready(function($) {
    var bufferValidTypes = <?php echo wp_json_encode($valid_types); ?>;

    function renderBufferChannelRows($card, channels) {
        var $list = $card.find('.dit-ts-buffer-channel-rows');
        var accountChannels = $card.data('account-channels') || {};
        $list.empty();

        if (!channels || Object.keys(channels).length === 0) {
            $list.html('<p style="color:#999;"><?php echo esc_js(__('Click "Refresh Channels" to load channels for this account.', 'dit-trend-content-studio')); ?></p>');
            return;
        }

        var table = $('<table class="widefat striped"><thead><tr><th style="width:60px;"><?php echo esc_js(__('Enable', 'dit-trend-content-studio')); ?></th><th><?php echo esc_js(__('Channel', 'dit-trend-content-studio')); ?></th><th style="width:100px;"><?php echo esc_js(__('Service', 'dit-trend-content-studio')); ?></th><th style="width:120px;"><?php echo esc_js(__('Post Type', 'dit-trend-content-studio')); ?></th><th style="width:100px;"><?php echo esc_js(__('Share as Story', 'dit-trend-content-studio')); ?></th><th style="width:80px;"><?php echo esc_js(__('Link Post', 'dit-trend-content-studio')); ?></th><th><?php echo esc_js(__('Template', 'dit-trend-content-studio')); ?></th></tr></thead><tbody></tbody></table>');
        var $tbody = table.find('tbody');

        $.each(channels, function(chId, chData) {
            var cfg = accountChannels[chId] || {};
            var service = chData.service;
            var types = bufferValidTypes[service] || ['post'];
            var showLinkPost = (service === 'facebook' || service === 'linkedin');
            var showPinterest = (service === 'pinterest');
            var showStoryOption = (service === 'facebook' || service === 'instagram');

            var tr = $('<tr></tr>');
            tr.append('<td><input type="checkbox" class="dit-ts-buffer-ch-enabled" ' + (cfg.enabled ? 'checked' : '') + '></td>');
            tr.append('<td><strong>' + chData.name + '</strong>' + (chData.avatar ? ' <img src="' + chData.avatar + '" alt="" style="width:24px;height:24px;border-radius:50%;vertical-align:middle;margin-left:8px;">' : '') + '</td>');
            tr.append('<td><span class="nm-service-badge nm-service-' + service + '" style="display:inline-block;padding:2px 8px;background:#f0f0f1;border-radius:3px;font-size:12px;">' + service.charAt(0).toUpperCase() + service.slice(1) + '</span></td>');

            var typeSelect = $('<select class="dit-ts-buffer-ch-type"></select>');
            $.each(types, function(i, t) {
                typeSelect.append('<option value="' + t + '" ' + (cfg.post_type === t ? 'selected' : '') + '>' + t.charAt(0).toUpperCase() + t.slice(1) + '</option>');
            });
            tr.append($('<td></td>').append(typeSelect));

            if (showStoryOption) {
                tr.append('<td><label><input type="checkbox" class="dit-ts-buffer-ch-story" ' + (cfg.share_as_story ? 'checked' : '') + '> <?php echo esc_js(__('Yes', 'dit-trend-content-studio')); ?></label></td>');
            } else {
                tr.append('<td><span style="color:#999;">—</span></td>');
            }

            if (showLinkPost) {
                tr.append('<td><label><input type="checkbox" class="dit-ts-buffer-ch-link" ' + (cfg.is_link_post ? 'checked' : '') + '> <?php echo esc_js(__('Yes', 'dit-trend-content-studio')); ?></label></td>');
            } else {
                tr.append('<td><span style="color:#999;">—</span></td>');
            }

            var templateTd = $('<td></td>');
            var toggleBtn = $('<button type="button" class="button dit-ts-toggle-channel-template"><?php echo esc_js(__('Edit', 'dit-trend-content-studio')); ?></button>');
            var templateDiv = $('<div class="dit-ts-buffer-template-row" style="display:none;margin-top:8px;"></div>');
            templateDiv.append('<textarea class="dit-ts-buffer-ch-template" rows="3" style="width:100%;">' + (cfg.template || '') + '</textarea>');
            templateDiv.append('<p class="description"><?php echo esc_js(__('Placeholders: {urdu_head}, {urdu_desc}, {hashtags}, {link}, {primary_image}', 'dit-trend-content-studio')); ?></p>');

            if (showPinterest) {
                templateDiv.append('<hr style="margin:10px 0;">');
                templateDiv.append('<label style="display:block;margin-bottom:4px;font-weight:600;"><?php echo esc_js(__('Pinterest Pin Title', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('<input type="text" class="dit-ts-buffer-ch-pinterest-title" value="' + (cfg.pinterest_title || '{urdu_head}') + '" style="width:100%;" placeholder="{urdu_head}">');
                templateDiv.append('<p class="description"><?php echo esc_js(__('Max 100 chars. Placeholders: {urdu_head}, {urdu_desc}, {hashtags}, {link}', 'dit-trend-content-studio')); ?></p>');
                var boardSelect = $('<select class="dit-ts-buffer-ch-pinterest-board" style="width:100%;"><option value=""><?php echo esc_js(__('— Select Board —', 'dit-trend-content-studio')); ?></option></select>');
                if (chData.pinterest_boards) {
                    $.each(chData.pinterest_boards, function(bId, bName) {
                        boardSelect.append('<option value="' + bId + '" ' + (cfg.pinterest_board_id === bId ? 'selected' : '') + '>' + bName + '</option>');
                    });
                }
                templateDiv.append(boardSelect);
            }

            // YouTube-specific fields
            var showYoutube = (service === 'youtube');
            if (showYoutube) {
                templateDiv.append('<hr style="margin:10px 0;">');
                templateDiv.append('<label style="display:block;margin-bottom:4px;font-weight:600;"><?php echo esc_js(__('YouTube Video Title', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('<input type="text" class="dit-ts-buffer-ch-youtube-title" value="' + (cfg.youtube_title || '{urdu_head}') + '" style="width:100%;" placeholder="{urdu_head}">');
                templateDiv.append('<p class="description"><?php echo esc_js(__('Required. Placeholders: {urdu_head}, {urdu_desc}, {hashtags}, {link}', 'dit-trend-content-studio')); ?></p>');

                templateDiv.append('<label style="display:block;margin-top:8px;margin-bottom:4px;font-weight:600;"><?php echo esc_js(__('YouTube Category', 'dit-trend-content-studio')); ?></label>');
                var ytCategorySelect = $('<select class="dit-ts-buffer-ch-youtube-category" style="width:100%;"></select>');
                var ytCategories = {
                    '1': 'Film & Animation',
                    '2': 'Autos & Vehicles',
                    '10': 'Music',
                    '15': 'Pets & Animals',
                    '17': 'Sports',
                    '19': 'Travel & Events',
                    '20': 'Gaming',
                    '22': 'People & Blogs',
                    '23': 'Comedy',
                    '24': 'Entertainment',
                    '25': 'News & Politics',
                    '26': 'Howto & Style',
                    '27': 'Education',
                    '28': 'Science & Technology',
                    '29': 'Nonprofits & Activism'
                };
                $.each(ytCategories, function(id, name) {
                    ytCategorySelect.append('<option value="' + id + '" ' + (cfg.youtube_category_id === id ? 'selected' : '') + '>' + name + '</option>');
                });
                templateDiv.append(ytCategorySelect);

                templateDiv.append('<label style="display:block;margin-top:8px;margin-bottom:4px;font-weight:600;"><?php echo esc_js(__('Privacy', 'dit-trend-content-studio')); ?></label>');
                var ytPrivacySelect = $('<select class="dit-ts-buffer-ch-youtube-privacy" style="width:100%;"><option value="public" ' + (cfg.youtube_privacy === 'public' ? 'selected' : '') + '>Public</option><option value="unlisted" ' + (cfg.youtube_privacy === 'unlisted' ? 'selected' : '') + '>Unlisted</option><option value="private" ' + (cfg.youtube_privacy === 'private' ? 'selected' : '') + '>Private</option></select>');
                templateDiv.append(ytPrivacySelect);

                templateDiv.append('<label style="display:block;margin-top:8px;margin-bottom:4px;font-weight:600;"><?php echo esc_js(__('License', 'dit-trend-content-studio')); ?></label>');
                var ytLicenseSelect = $('<select class="dit-ts-buffer-ch-youtube-license" style="width:100%;"><option value="youtube" ' + (cfg.youtube_license === 'youtube' ? 'selected' : '') + '>Standard YouTube License</option><option value="creativeCommon" ' + (cfg.youtube_license === 'creativeCommon' ? 'selected' : '') + '>Creative Commons</option></select>');
                templateDiv.append(ytLicenseSelect);

                templateDiv.append('<div style="margin-top:8px;">');
                templateDiv.append('<label style="display:inline-flex;align-items:center;gap:6px;font-weight:600;"><input type="checkbox" class="dit-ts-buffer-ch-youtube-embeddable" ' + (cfg.youtube_embeddable ? 'checked' : '') + '> <?php echo esc_js(__('Allow embedding', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('</div>');

                templateDiv.append('<div style="margin-top:8px;">');
                templateDiv.append('<label style="display:inline-flex;align-items:center;gap:6px;font-weight:600;"><input type="checkbox" class="dit-ts-buffer-ch-youtube-made-for-kids" ' + (cfg.youtube_made_for_kids ? 'checked' : '') + '> <?php echo esc_js(__('Made for kids', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('</div>');

                templateDiv.append('<div style="margin-top:8px;">');
                templateDiv.append('<label style="display:inline-flex;align-items:center;gap:6px;font-weight:600;"><input type="checkbox" class="dit-ts-buffer-ch-youtube-notify-subscribers" ' + (cfg.youtube_notify_subscribers ? 'checked' : '') + '> <?php echo esc_js(__('Notify subscribers', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('</div>');

                templateDiv.append('<div style="margin-top:8px;">');
                templateDiv.append('<label style="display:inline-flex;align-items:center;gap:6px;font-weight:600;"><input type="checkbox" class="dit-ts-buffer-ch-youtube-is-ai-generated" ' + (cfg.youtube_is_ai_generated ? 'checked' : '') + '> <?php echo esc_js(__('AI-generated content', 'dit-trend-content-studio')); ?></label>');
                templateDiv.append('</div>');
            }

            templateTd.append(toggleBtn);
            templateTd.append(templateDiv);
            tr.append(templateTd);

            $tbody.append(tr);
        });

        $list.html(table);
    }

    function collectBufferAccounts() {
        var accounts = [];
        $('.dit-ts-buffer-account-card').each(function() {
            var $card = $(this);
            var channels = {};
            $card.find('.dit-ts-buffer-channel-rows table tbody tr').each(function() {
                var $tr = $(this);
                var chName = $tr.find('td:eq(1) strong').text();
                var chId = '';
                $card.find('.dit-ts-buffer-channel-rows table tbody').children().each(function(i) {
                    if ($(this).find('td:eq(1) strong').text() === chName) {
                        chId = Object.keys($card.data('buffer-channels') || {})[i] || '';
                    }
                });
                if (!chId) return;
                channels[chId] = {
                    enabled: $tr.find('.dit-ts-buffer-ch-enabled').is(':checked'),
                    post_type: $tr.find('.dit-ts-buffer-ch-type').val() || 'post',
                    template: $tr.find('.dit-ts-buffer-ch-template').val() || '',
                    is_link_post: $tr.find('.dit-ts-buffer-ch-link').is(':checked'),
                    share_as_story: $tr.find('.dit-ts-buffer-ch-story').is(':checked'),
                    pinterest_board_id: $tr.find('.dit-ts-buffer-ch-pinterest-board').val() || '',
                    pinterest_title: $tr.find('.dit-ts-buffer-ch-pinterest-title').val() || '',
                    youtube_title: $tr.find('.dit-ts-buffer-ch-youtube-title').val() || '',
                    youtube_category_id: $tr.find('.dit-ts-buffer-ch-youtube-category').val() || '',
                    youtube_privacy: $tr.find('.dit-ts-buffer-ch-youtube-privacy').val() || '',
                    youtube_embeddable: $tr.find('.dit-ts-buffer-ch-youtube-embeddable').is(':checked'),
                    youtube_license: $tr.find('.dit-ts-buffer-ch-youtube-license').val() || '',
                    youtube_made_for_kids: $tr.find('.dit-ts-buffer-ch-youtube-made-for-kids').is(':checked'),
                    youtube_notify_subscribers: $tr.find('.dit-ts-buffer-ch-youtube-notify-subscribers').is(':checked'),
                    youtube_is_ai_generated: $tr.find('.dit-ts-buffer-ch-youtube-is-ai-generated').is(':checked'),
                };
            });
            accounts.push({
                id: $card.find('.dit-ts-buffer-account-slug').val(),
                name: $card.find('.dit-ts-buffer-account-name').val(),
                api_key: $card.find('.dit-ts-buffer-api-key').val(),
                enabled: $card.find('.dit-ts-buffer-account-enabled').is(':checked'),
                daily_limit: parseInt($card.find('.dit-ts-buffer-daily-limit').val()) || 5,
                channels: channels,
            });
        });
        return accounts;
    }

    function syncBufferAccountsToHidden() {
        var accounts = collectBufferAccounts();
        $('#dit_ts_buffer_accounts_json').val(JSON.stringify(accounts));
    }

    function addBufferAccountCard(account) {
        account = account || { id: '', name: '', api_key: '', enabled: true, daily_limit: 5, channels: {} };
        var id = account.id || 'account_' + Date.now();
        var $card = $(
            '<div class="dit-ts-buffer-account-card" data-account-id="' + id + '">' +
            '  <div class="dit-ts-buffer-account-header">' +
            '    <input type="hidden" class="dit-ts-buffer-account-id" value="' + id + '">' +
            '    <strong class="dit-ts-buffer-account-name-display">' + (account.name || id) + '</strong>' +
            '    <span class="dit-ts-buffer-account-status">' + (account.enabled ? 'Enabled' : 'Disabled') + '</span>' +
            '    <button type="button" class="button dit-ts-toggle-buffer-account">Expand</button>' +
            '    <button type="button" class="button dit-ts-remove-buffer-account">Remove</button>' +
            '  </div>' +
            '  <div class="dit-ts-buffer-account-body" style="display:none;">' +
            '    <table class="form-table">' +
            '      <tr><th scope="row">Account Name</th><td><input type="text" class="dit-ts-buffer-account-name regular-text" value="' + (account.name || id) + '"></td></tr>' +
            '      <tr><th scope="row">Account ID (slug)</th><td><input type="text" class="dit-ts-buffer-account-slug regular-text" value="' + id + '"></td></tr>' +
            '      <tr><th scope="row">API Key</th><td><input type="password" class="dit-ts-buffer-api-key regular-text" value="' + (account.api_key || '') + '" style="width:400px;"><button type="button" class="button dit-ts-toggle-buffer-key">Show</button><button type="button" class="button dit-ts-test-buffer-account">Test Connection</button><button type="button" class="button dit-ts-refresh-buffer-channels">Refresh Channels</button><div class="dit-ts-buffer-test-result" style="margin-top:4px;"></div></td></tr>' +
            '      <tr><th scope="row">Enabled</th><td><label><input type="checkbox" class="dit-ts-buffer-account-enabled" value="1" ' + (account.enabled ? 'checked' : '') + '> Enable this account for sharing</label></td></tr>' +
            '      <tr><th scope="row">Daily Share Limit</th><td><input type="number" class="dit-ts-buffer-daily-limit small-text" value="' + (account.daily_limit || 5) + '" min="0" max="50"><p class="description">0 = unlimited. Per-account limit.</p></td></tr>' +
            '    </table>' +
            '    <div class="dit-ts-buffer-channel-list"><h4>Channels</h4><div class="dit-ts-buffer-channel-rows"></div></div>' +
            '  </div>' +
            '</div>'
        );
        $card.data('account-channels', account.channels || {});
        $('#dit-ts-buffer-accounts-list').append($card);
        syncBufferAccountsToHidden();
    }

    // Toggle account body
    $(document).on('click', '.dit-ts-toggle-buffer-account', function() {
        var $body = $(this).closest('.dit-ts-buffer-account-card').find('.dit-ts-buffer-account-body');
        $body.slideToggle();
        $(this).text($body.is(':visible') ? 'Collapse' : 'Expand');
    });

    // Toggle API key visibility
    $(document).on('click', '.dit-ts-toggle-buffer-key', function() {
        var $input = $(this).closest('td').find('.dit-ts-buffer-api-key');
        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $(this).text('Hide');
        } else {
            $input.attr('type', 'password');
            $(this).text('Show');
        }
    });

    // Toggle channel template
    $(document).on('click', '.dit-ts-toggle-channel-template', function() {
        $(this).closest('td').find('.dit-ts-buffer-template-row').slideToggle();
    });

    // Remove account
    $(document).on('click', '.dit-ts-remove-buffer-account', function() {
        if (confirm('<?php echo esc_js(__('Remove this Buffer account?', 'dit-trend-content-studio')); ?>')) {
            $(this).closest('.dit-ts-buffer-account-card').remove();
            syncBufferAccountsToHidden();
        }
    });

    // Add account
    $('#dit-ts-add-buffer-account').on('click', function() {
        addBufferAccountCard();
    });

    // Test connection
    $(document).on('click', '.dit-ts-test-buffer-account', function() {
        var $td = $(this).closest('td');
        var token = $td.find('.dit-ts-buffer-api-key').val();
        var $result = $td.find('.dit-ts-buffer-test-result');
        var $card = $(this).closest('.dit-ts-buffer-account-card');
        var accountId = $card.find('.dit-ts-buffer-account-slug').val();
        $result.html('<span style="color:#646970;">Testing...</span>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'dit_ts_buffer_test_connection',
                nonce: ditTsAdmin.nonce,
                token: token,
                account_id: accountId
            },
            success: function(response) {
                if (response.success) {
                    $result.html('<span style="color:#00a32a;">\u2713 ' + response.data.message + '</span>');
                } else {
                    $result.html('<span style="color:#d63638;">\u2717 ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $result.html('<span style="color:#d63638;">\u2717 Request failed</span>');
            }
        });
    });

    // Refresh channels
    $(document).on('click', '.dit-ts-refresh-buffer-channels', function() {
        var $td = $(this).closest('td');
        var token = $td.find('.dit-ts-buffer-api-key').val();
        var $result = $td.find('.dit-ts-buffer-test-result');
        var $card = $(this).closest('.dit-ts-buffer-account-card');
        var accountId = $card.find('.dit-ts-buffer-account-slug').val();
        $result.html('<span style="color:#646970;">Refreshing channels...</span>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'dit_ts_buffer_refresh_channels',
                nonce: ditTsAdmin.nonce,
                account_id: accountId,
                token: token
            },
            success: function(response) {
                if (response.success) {
                    $card.data('buffer-channels', response.data.channels);
                    $card.data('account-channels', response.data.channel_configs || {});
                    renderBufferChannelRows($card, response.data.channels);
                    $result.html('<span style="color:#00a32a;">\u2713 Channels refreshed.</span>');
                } else {
                    $result.html('<span style="color:#d63638;">\u2717 ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $result.html('<span style="color:#d63638;">\u2717 Request failed</span>');
            }
        });
    });

    // Auto-sync on form submit
    $('form').on('submit', function() {
        syncBufferAccountsToHidden();
    });

    // Sync on any input change
    $(document).on('change', '.dit-ts-buffer-account-name, .dit-ts-buffer-account-slug, .dit-ts-buffer-api-key, .dit-ts-buffer-account-enabled, .dit-ts-buffer-daily-limit, .dit-ts-buffer-ch-enabled, .dit-ts-buffer-ch-type, .dit-ts-buffer-ch-link, .dit-ts-buffer-ch-template, .dit-ts-buffer-ch-pinterest-title, .dit-ts-buffer-ch-pinterest-board', function() {
        syncBufferAccountsToHidden();
    });

    // Auto-render cached channels on page load so they persist across refreshes
    $('.dit-ts-buffer-account-card').each(function() {
        var $card = $(this);
        var cachedChannels = $card.data('cached-channels');
        var accountChannels = $card.data('account-channels');
        if (cachedChannels && Object.keys(cachedChannels).length > 0) {
            $card.data('buffer-channels', cachedChannels);
            $card.data('account-channels', accountChannels || {});
            renderBufferChannelRows($card, cachedChannels);
        }
    });
});
</script>

<style>
.nm-service-badge.nm-service-facebook { background: #e8f0fe; color: #1877f2; }
.nm-service-badge.nm-service-instagram { background: #fce4ec; color: #e1306c; }
.nm-service-badge.nm-service-twitter { background: #e8f5e9; color: #1da1f2; }
.nm-service-badge.nm-service-linkedin { background: #e3f2fd; color: #0077b5; }
.nm-service-badge.nm-service-pinterest { background: #ffebee; color: #bd081c; }
.nm-service-badge.nm-service-youtube { background: #ffebee; color: #ff0000; }
.nm-service-badge.nm-service-threads { background: #f3e5f5; color: #000000; }
.nm-service-badge.nm-service-tiktok { background: #e0f2f1; color: #000000; }
</style>
