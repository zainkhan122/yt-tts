<?php
namespace AiSocialCollage\Actions;

use AiSocialCollage\Config;
use AiSocialCollage\Services\FeedIngester;
use AiSocialCollage\Services\OpenRouterModelSync;
use AiSocialCollage\Services\OpenCodeZenModelSync;
use AiSocialCollage\Logger;
use AiSocialCollage\Database\JobManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CronScheduler {

	public function __construct() {
		add_action( 'init', [ $this, 'register_master_cron' ] );
		add_action( 'init', [ $this, 'register_as_filters' ] );
	}

public function register_as_filters() {
        add_filter( 'action_scheduler_queue_runner_time_limit', [ $this, 'increase_time_limit' ] );
        add_filter( 'action_scheduler_queue_runner_batch_size', [ $this, 'increase_batch_size' ] );
        add_filter( 'action_scheduler_lock_duration', [ $this, 'decrease_lock_duration' ] );
    }

	public function increase_time_limit( $limit ) {
		$max_execution_time = (int) @ini_get( 'max_execution_time' );
		if ( $max_execution_time <= 0 ) {
			$max_execution_time = 30; // Fallback default
		}
		// Allow graceful exit: time limit should be 5 seconds less than max execution time
		return max( 20, $max_execution_time - 5 );
	}

	public function increase_batch_size( $size ) {
		// Increased from 10 to 20 to process more jobs per runner execution.
		// With 5-min health checks and multiple campaigns, batch of 10 was too small
		// to clear the queue before the next batch of jobs arrived.
		return 20;
	}

	public function decrease_lock_duration( $duration ) {
		$max_execution_time = (int) @ini_get( 'max_execution_time' );
		if ( $max_execution_time <= 0 ) {
			$max_execution_time = 30;
		}
		// Lock duration must be greater than runner execution limit to prevent overlapping runs
		return max( 60, $max_execution_time + 30 );
	}

public function register_master_cron() {
		add_action( Config::ACTION_POLL_CAMPAIGNS, [ $this, 'poll_campaigns' ] );
        add_action( Config::ACTION_POLL_FEEDS, [ $this, 'poll_feeds' ] );
        add_action( Config::ACTION_SYNC_OPENROUTER_MODELS, [ $this, 'sync_openrouter_models' ] );
        add_action( Config::ACTION_SYNC_ZEN_MODELS, [ $this, 'sync_zen_models' ] );

        if ( function_exists( 'as_next_scheduled_action' ) && ! as_next_scheduled_action( Config::ACTION_POLL_CAMPAIGNS, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action(
				time(),
				Config::CRON_POLL_INTERVAL,
				Config::ACTION_POLL_CAMPAIGNS,
				[],
				Config::AS_GROUP
			);
		}

		$rss_enabled = (bool) get_option( Config::OPTION_RSS_ENABLED, false );
		$scheduled_feed_action = function_exists( 'as_next_scheduled_action' ) ? as_next_scheduled_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP ) : false;

		if ( $rss_enabled ) {
			$rss_frequency = (int) get_option( Config::OPTION_RSS_FREQUENCY, Config::RSS_DEFAULT_FREQUENCY );

			// Mirror the ACTION_POLL_CAMPAIGNS guard: never reschedule on every init.
			// Rescheduling on every page load would reset the anchor to `time()`, drifting
			// the actual run-time to whatever the longest init gap is. Only schedule when
			// no recurring action exists. To change frequency, the user must disable + re-enable RSS.
			if ( ! $scheduled_feed_action && function_exists( 'as_schedule_recurring_action' ) ) {
				as_schedule_recurring_action(
					time(),
					$rss_frequency,
					Config::ACTION_POLL_FEEDS,
					[],
					Config::AS_GROUP
				);
			}
		} else {
			if ( function_exists( 'as_unschedule_action' ) && $scheduled_feed_action ) {
				as_unschedule_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP );
			}
		}

		// ── Buffer stats refresh: 1300 PKT (0800 UTC) and 2100 PKT (1600 UTC) ──
		add_action( Config::ACTION_REFRESH_BUFFER_STATS, [ $this, 'refresh_buffer_stats' ] );
		$this->schedule_buffer_stats_refresh();

		// ── Video Publish Scheduler: every 15 minutes ──
		add_action( Config::ACTION_PUBLISH_SCHEDULED, [ $this, 'run_publish_scheduler' ] );
		$this->schedule_publish_scheduler();

		// ── Buffer pending share retry: every 5 minutes ──
		add_action( Config::ACTION_RETRY_BUFFER_PENDING, [ $this, 'retry_pending_buffer_shares' ] );
		$this->schedule_pending_buffer_shares();

		// ── Stuck-R2 recovery: every 5 minutes ──
		add_action( Config::ACTION_RETRY_STUCK_R2, [ $this, 'maybe_retry_stuck_r2_uploads' ] );
		$this->schedule_stuck_r2_retry();

		// ── OpenRouter free model sync: every 3 days ──
		$this->schedule_openrouter_sync();

		// ── OpenCode Zen free model sync: every 3 days ──
		$this->schedule_zen_sync();
	}

    public function poll_campaigns() {
        $pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );

        if ( $pipeline_paused ) {
            return;
        }

        $stuck_count = JobManager::mark_stuck_jobs_failed( 15 );
        if ( $stuck_count > 0 ) {
            Logger::info( Config::LOG_ACTION_STUCK_JOB_FAILED, null, [
                'count' => $stuck_count,
                'timeout' => '15min',
                'source' => 'auto_poll',
            ], '200' );
        }

        $campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );

        foreach ( $campaigns as $campaign ) {
            if ( empty( $campaign['active'] ) || ! empty( $campaign['stopped'] ) || ! $this->is_campaign_due( $campaign ) ) {
                continue;
            }

            $this->queue_oldest_draft( $campaign );
            self::update_campaign_last_run( $campaign['id'] );
        }
    }

    private function is_campaign_due( $campaign ) {
        $last_run = isset( $campaign['last_run'] ) ? (int) $campaign['last_run'] : 0;
        if ( ! $last_run ) {
            $last_run = (int) \get_transient( 'ai_collage_campaign_last_run_' . sanitize_key( (string) ( $campaign['id'] ?? '' ) ) );
        }
        $frequency = Config::get_campaign_value( $campaign, 'frequency', Config::FREQUENCY_1_HOUR );
        $interval  = Config::get_frequency_interval( $frequency );

        return ( time() - $last_run ) >= $interval;
	}

    private function queue_oldest_draft( $campaign ) {
		// Queue depth throttle: prevent unbounded growth during RSS spikes
		$queue_depth = $this->get_queue_depth();
		$max_queue_depth = (int) get_option( Config::OPTION_MAX_QUEUE_DEPTH, 50 );
		
		if ( $queue_depth >= $max_queue_depth ) {
			Logger::warning( 'queue_depth_throttled', null, [
				'current_depth' => $queue_depth,
				'max_depth' => $max_queue_depth,
			], '429' );
			return null;
		}

		$source_slug = sanitize_title( $campaign['source_category'] ?? '' );

        $args = [
            'post_type' => 'post',
            'post_status' => [ 'draft', 'pending' ],
            'posts_per_page' => 1,
            'orderby' => 'date',
            'order' => 'ASC',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_ai_collage_job_created',
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key' => \AiSocialCollage\Config::META_CAMPAIGN_DATA,
                    'compare' => 'NOT EXISTS',
                ],
            ],
        ];

        if ( ! empty( $source_slug ) ) {
            $args['category_name'] = $source_slug;
        }

        $query = new \WP_Query( $args );

        if ( $query->have_posts() ) {
            $post = $query->posts[0];
            $post_id = $post->ID;

            // Bounded re-queue guard: prevent the same draft from being enqueued on every poll
            // after a purge/reset clears the job row that normally deduplicates it.
            $recent_key = 'ai_collage_queued_recent_' . (int) $post_id;
            if ( false !== \get_transient( $recent_key ) ) {
                return null;
            }

            if ( ! \AiSocialCollage\Database\JobManager::job_exists_for_post( $post_id, false ) ) {
                update_post_meta( $post_id, Config::META_CAMPAIGN_DATA, $campaign );
                set_transient( $recent_key, time(), HOUR_IN_SECONDS );

                $job_id = \AiSocialCollage\Database\JobManager::create_job( $post_id );

                if ( $job_id && function_exists( 'as_schedule_single_action' ) ) {
                    $action_id = as_schedule_single_action(
                        time(),
                        Config::ACTION_PROCESS_JOB,
                        [ 'job_id' => $job_id ],
                        Config::AS_GROUP
                    );
                    if ( ! $action_id ) {
                        \AiSocialCollage\Database\JobManager::delete_job( $job_id );
                        delete_post_meta( $post_id, '_ai_collage_job_created' );
                        \AiSocialCollage\Logger::error( 'as_enqueue_failed', $job_id, [ 'post_id' => $post_id ], '500', 'Action Scheduler enqueue returned 0' );
                        return null;
                    }
                    \AiSocialCollage\Logger::info(
                        Config::LOG_ACTION_CAMPAIGN_JOB_QUEUED,
                        $job_id,
                        [ 'post_id' => $post_id, 'campaign' => $campaign['name'] ],
                        '200'
                    );

                    // CRITICAL FIX: Trigger queue runner immediately after job creation
                    // instead of waiting for the next health check (5 min) to process it.
                    // This eliminates the delay between job queuing and processing.
                    self::maybe_trigger_queue_run( $job_id );

                    return $job_id;
                }
            }
        }

        return null;
    }

	/**
	 * Trigger Action Scheduler queue runner immediately if pending actions exist.
	 * Called after job creation to eliminate processing delay.
	 * Processes the job directly in a detached background process.
	 */
	public static function maybe_trigger_queue_run( $job_id = null ) {
		if ( $job_id ) {
			$lock_key = 'ai_collage_job_lock_' . (int) $job_id;
			$lock_value = \get_transient( $lock_key );
			if ( false !== $lock_value ) {
				// FIX: If the lock is older than 5 minutes, it's stale.
				// The holding process was killed. Don't skip — let process_job()
				// handle it (it now has stale lock detection).
				$lock_age = time() - (int) $lock_value;
				if ( $lock_age < 300 ) {
					Logger::info( 'maybe_trigger_queue_run_skipped_locked', (int) $job_id, [
						'lock_age_seconds' => $lock_age,
					], '429' );
					return;
				}
				// Stale lock — delete and continue to process
				\delete_transient( $lock_key );
			}

			// Log BEFORE processing — once the connection closes, downstream
			// log writes via WP shutdown may not flush.
			Logger::info( 'job_background_processing_start', (int) $job_id, [
				'source' => 'maybe_trigger_queue_run',
			], '200' );

			// Set up process isolation BEFORE processing so the job completes
			// even if the parent request/connection is terminated.
			ignore_user_abort( true );
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( 120 );
			}

			// Run the action synchronously so the job processes immediately
			// instead of waiting for the next health check cycle.
			do_action( Config::ACTION_PROCESS_JOB, (int) $job_id );

			Logger::info( 'job_background_processing_done', (int) $job_id, [], '200' );

			// FIX: Do NOT call fastcgi_finish_request() here. This method
			// is called from within AS actions (poll_campaigns, queue_oldest_draft)
			// where there is no HTTP connection to finish. Calling it in cron
			// context can corrupt the AS runner's output buffering.
			return;
		}

		if ( ! function_exists( 'as_get_scheduled_actions' ) ) {
			return;
		}

		try {
			$pending = as_get_scheduled_actions(
				[
					'hook' => Config::ACTION_PROCESS_JOB,
					'status' => \ActionScheduler_Store::STATUS_PENDING,
				],
				'ids',
				Config::AS_GROUP
			);

			if ( count( $pending ) === 0 ) {
				return;
			}

			$runner_lock = \get_transient( 'action_scheduler_lock_queue_runner' );
			$runner_active = ( false !== $runner_lock && ( time() - (int) $runner_lock ) < 120 );

			if ( ! $runner_active ) {
				$locks = [
					'action_scheduler_lock_async-request-runner',
					'action_scheduler_lock_queue_runner',
				];
				foreach ( $locks as $lock_name ) {
					delete_option( $lock_name );
					\delete_transient( $lock_name );
				}

				if ( function_exists( 'do_action' ) ) {
					do_action( 'action_scheduler_run_queue', 'Campaign Poll: Job just queued' );
					Logger::info( 'queue_run_triggered_after_job_creation', null, [
						'pending_count' => count( $pending ),
					], '200' );
				}
			}
		} catch ( \Throwable $e ) {
			Logger::warning( 'queue_run_trigger_failed', null, [
				'error' => $e->getMessage(),
			], '500' );
		}
	}

	public static function update_campaign_last_run( $campaign_id ) {
		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		foreach ( $campaigns as &$campaign ) {
			if ( (string) ( $campaign['id'] ?? '' ) === (string) $campaign_id ) {
				$campaign['last_run'] = time();
				break;
			}
		}
		update_option( Config::OPTION_CAMPAIGNS, $campaigns );
		set_transient( 'ai_collage_campaign_last_run_' . sanitize_key( (string) $campaign_id ), time(), DAY_IN_SECONDS );
	}

	/**
	 * Get current Action Scheduler queue depth for this plugin's actions
	 */
	private function get_queue_depth(): int {
		if ( ! function_exists( 'as_get_scheduled_actions' ) ) {
			return 0;
		}

		try {
			$actions = as_get_scheduled_actions(
				[
					'hook' => Config::ACTION_PROCESS_JOB,
					'status' => [ \ActionScheduler_Store::STATUS_PENDING, \ActionScheduler_Store::STATUS_RUNNING ],
				],
				'ids',
				Config::AS_GROUP
			);
			return count( $actions );
		} catch ( \Throwable $e ) {
			Logger::warning( 'queue_depth_check_failed', null, [ 'error' => $e->getMessage() ], '500' );
			return 0;
		}
	}

	public function poll_feeds() {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			return;
		}

		$feeds = Config::get_rss_feeds();
		$max_per_run = (int) get_option( Config::OPTION_RSS_MAX_PER_RUN, Config::RSS_DEFAULT_MAX_PER_RUN );
		$total_ingested = 0;

		foreach ( $feeds as $feed ) {
			if ( empty( $feed['active'] ) || empty( $feed['url'] ) ) {
				continue;
			}

			$feed['max_items'] = $max_per_run;
			$results = FeedIngester::ingest_feed( $feed );
			$total_ingested += count( $results );

			if ( ! empty( $results ) ) {
				$this->update_feed_last_poll( $feed['id'], count( $results ) );
			}
		}

		if ( $total_ingested > 0 ) {
			Logger::info( 'rss_poll_cycle_completed', null, [
				'total_ingested' => $total_ingested,
				'feeds_count' => count( $feeds ),
			], '200' );
		}
	}

	private function update_feed_last_poll( $feed_id, $items_count ) {
		update_option( 'ai_collage_feed_last_poll_' . sanitize_key( (string) $feed_id ), gmdate( 'Y-m-d H:i:s' ), false );
		update_option( 'ai_collage_feed_last_poll_count_' . sanitize_key( (string) $feed_id ), (int) $items_count, false );
	}

	private function schedule_buffer_stats_refresh() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}

		$now    = time();
		$hour   = (int) gmdate( 'G', $now );
		$minute = (int) gmdate( 'i', $now );
		$seconds_past_hour = $minute * 60;

		if ( $hour < 8 ) {
			$anchor = $now + ( ( 8 - $hour ) * 3600 - $seconds_past_hour );
		} elseif ( $hour < 16 ) {
			$anchor = $now + ( ( 16 - $hour ) * 3600 - $seconds_past_hour );
		} else {
			$anchor = $now + ( ( 24 - $hour + 8 ) * 3600 - $seconds_past_hour );
		}

		$interval = 12 * HOUR_IN_SECONDS;

		if ( ! as_next_scheduled_action( Config::ACTION_REFRESH_BUFFER_STATS, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action(
				$anchor,
				$interval,
				Config::ACTION_REFRESH_BUFFER_STATS,
				[],
				Config::AS_GROUP
			);
		}
	}

	public static function refresh_buffer_stats() {
		$active = Config::get_active_buffer_accounts();
		$has_accounts = ! empty( $active );
		$enabled = $has_accounts || (bool) get_option( Config::OPTION_BUFFER_ENABLED, false );
		$has_token = $has_accounts || ! empty( get_option( Config::OPTION_BUFFER_ACCESS_TOKEN, '' ) );
		$draft_retention = (int) get_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS );

		$draft_count = 0;
		$daily_limit = 0;

		if ( $has_accounts ) {
			foreach ( $active as $acct_id => $acct ) {
				$daily_limit += max( 0, (int) ( $acct['daily_limit'] ?? 5 ) );
				try {
					$draft_count += \AiSocialCollage\Services\BufferIntegration::get_draft_count_from_buffer( $acct_id );
				} catch ( \Throwable $e ) {
					Logger::warning( 'buffer_stats_refresh_failed', null, [
						'account_id' => $acct_id,
						'error' => $e->getMessage(),
					] );
				}
			}
		} elseif ( $enabled && $has_token ) {
			$daily_limit = (int) get_option( Config::OPTION_BUFFER_DAILY_LIMIT, 5 );
			try {
				$draft_count = \AiSocialCollage\Services\BufferIntegration::get_draft_count_from_buffer();
			} catch ( \Throwable $e ) {
				Logger::warning( 'buffer_stats_refresh_failed', null, [
					'error' => $e->getMessage(),
				] );
				$draft_count = 0;
			}
		}

		update_option( Config::OPTION_BUFFER_STATS_CACHE, [
			'draft_count'     => $draft_count,
			'daily_limit'     => $daily_limit,
			'draft_retention' => $draft_retention,
			'fetched_at'      => time(),
		], false );

		Logger::info( 'buffer_stats_refreshed', null, [
			'draft_count' => $draft_count,
		], '200' );
	}

	private function schedule_openrouter_sync() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}

		if ( ! OpenRouterModelSync::has_openrouter_provider() ) {
			return;
		}

		$interval = 3 * DAY_IN_SECONDS;

		if ( ! as_next_scheduled_action( Config::ACTION_SYNC_OPENROUTER_MODELS, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action(
				time() + $interval,
				$interval,
				Config::ACTION_SYNC_OPENROUTER_MODELS,
				[],
				Config::AS_GROUP
			);
		}
	}

	public function sync_openrouter_models() {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			return;
		}

		$result = OpenRouterModelSync::sync();

		if ( ! $result['success'] && $result['message'] !== 'No OpenRouter custom provider found (URL must contain openrouter.ai).' ) {
			Logger::warning( Config::LOG_ACTION_OPENROUTER_SYNC, null, [
				'result' => $result,
				'source' => 'weekly_cron',
			], '500' );
		}
	}

	private function schedule_zen_sync() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}

		if ( ! OpenCodeZenModelSync::has_zen_provider() ) {
			return;
		}

		$interval = 3 * DAY_IN_SECONDS;

		if ( ! as_next_scheduled_action( Config::ACTION_SYNC_ZEN_MODELS, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action(
				time() + $interval,
				$interval,
				Config::ACTION_SYNC_ZEN_MODELS,
				[],
				Config::AS_GROUP
			);
		}
	}

	public function sync_zen_models() {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			return;
		}

		$result = OpenCodeZenModelSync::sync();

		if ( ! $result['success'] && $result['message'] !== 'No OpenCode Zen custom provider found (URL must contain opencode.ai).' ) {
			Logger::warning( Config::LOG_ACTION_ZEN_SYNC, null, [
				'result' => $result,
				'source' => 'zen_cron',
			], '500' );
		}
	}

	private function schedule_publish_scheduler() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}
		if ( ! as_next_scheduled_action( Config::ACTION_PUBLISH_SCHEDULED, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action( time() + 300, 900, Config::ACTION_PUBLISH_SCHEDULED, [], Config::AS_GROUP );
		}
	}

	private function schedule_pending_buffer_shares() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}
		if ( ! as_next_scheduled_action( Config::ACTION_RETRY_BUFFER_PENDING, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action( time() + 300, Config::CRON_POLL_INTERVAL, Config::ACTION_RETRY_BUFFER_PENDING, [], Config::AS_GROUP );
		}
	}

	public function retry_pending_buffer_shares() {
		if ( ! class_exists( '\AiSocialCollage\Services\BufferIntegration' ) ) {
			return;
		}
		if ( ! Config::is_buffer_enabled() ) {
			return;
		}
		\AiSocialCollage\Services\BufferIntegration::retry_pending_shares();
	}

	private function schedule_stuck_r2_retry() {
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}
		if ( ! Config::is_r2_configured() || ! Config::is_video_r2_buffer_auto_enabled() ) {
			return;
		}
		if ( ! as_next_scheduled_action( Config::ACTION_RETRY_STUCK_R2, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action( time() + 60, 300, Config::ACTION_RETRY_STUCK_R2, [], Config::AS_GROUP );
		}
	}

	public function maybe_retry_stuck_r2_uploads() {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			return;
		}

		if ( ! Config::is_r2_configured() || ! Config::is_video_r2_buffer_auto_enabled() ) {
			return;
		}

		if ( ! class_exists( '\AiSocialCollage\Services\VideoRenderer' ) ) {
			return;
		}

		$jobs = JobManager::get_stuck_r2_jobs( 10 );
		if ( empty( $jobs ) ) {
			return;
		}

		Logger::info( 'stuck_r2_retry_start', null, [ 'jobs_count' => count( $jobs ) ], '200' );

		foreach ( $jobs as $job ) {
			$job_id  = (int) $job->id;
			$post_id = (int) $job->post_id;

			// R2 upload is deferred until the post is published. Never upload or
			// retry for drafts/future/pending — only published posts qualify.
			$wp_post = get_post( $post_id );
			if ( ! $wp_post || $wp_post->post_type !== 'post' || $wp_post->post_status !== 'publish' ) {
				continue;
			}

			// Only AI-generated reels accepted for R2 upload — never source videos.
			// Exclude source videos (META_SOURCE_VIDEO) which may incorrectly have
			// META_IS_AI_COLLAGE set from older ingests via sideload_featured_image.
			$ai_video_attachments = get_posts( [
				'post_type'      => 'attachment',
				'post_parent'    => $post_id,
				'post_mime_type' => 'video',
				'posts_per_page' => 1,
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'   => Config::META_IS_AI_COLLAGE,
						'value' => '1',
					],
					[
						'key'     => Config::META_SOURCE_VIDEO,
						'compare' => 'NOT EXISTS',
					],
				],
			] );
			if ( empty( $ai_video_attachments ) ) {
				Logger::warning( 'r2_retry_no_ai_reel', $job_id, [
					'post_id' => $post_id,
				], '404', 'No AI-generated video reel found; R2 upload skipped.' );
				continue;
			}
			$attachment_id = (int) $ai_video_attachments[0]->ID;
			$file_path     = get_attached_file( $attachment_id );
			if ( ! $file_path || ! file_exists( $file_path ) ) {
				continue;
			}

			// Safety: verify the resolved file is actually the rendered reel,
			// not a source video that slipped through the meta_query.
			$is_reel = preg_match( '/video_reel_\d+_[a-f0-9]+_reel\.\w+$/', $file_path );
			if ( ! $is_reel ) {
				Logger::error( 'r2_retry_reject_non_reel', $job_id, [
					'post_id'       => $post_id,
					'attachment_id' => $attachment_id,
					'file_path'     => $file_path,
					'reason'        => 'Resolved file does not match rendered reel filename pattern. Refusing to upload source video to R2.',
				], '500' );
				continue;
			}

			$attempt_age_minutes = (int) round( ( time() - strtotime( $job->updated_at . ' UTC' ) ) / 60 );
			Logger::warning( 'r2_upload_retry_attempted', $job_id, [
				'post_id'             => $post_id,
				'attempt_age_minutes' => $attempt_age_minutes,
			], '500' );

			$renderer = new \AiSocialCollage\Services\VideoRenderer();
			$r2_url   = $renderer->maybe_upload_to_r2( $file_path, $job_id, $attachment_id );

			if ( $r2_url ) {
				// Compute publish_at for cron-driven Buffer push.
				$campaign = get_post_meta( $post_id, Config::META_CAMPAIGN_DATA, true );
				if ( is_array( $campaign ) ) {
					$publish_time = Config::get_campaign_value( $campaign, 'publish_time', '09:00' );
					$frequency    = Config::get_campaign_value( $campaign, 'frequency', Config::FREQUENCY_1_DAY );
					$publish_at   = \AiSocialCollage\Actions\QueueProcessor::compute_publish_at( $publish_time, $frequency );
					JobManager::update_job_fields( $job_id, [
						'publish_at' => $publish_at,
					] );
				}
				Logger::info( 'stuck_r2_retry_success', $job_id, [
					'post_id'    => $post_id,
					'video_url'  => $r2_url,
				], '200' );
			} else {
				Logger::warning( 'stuck_r2_retry_failed', $job_id, [
					'post_id' => $post_id,
				], '500' );
			}
		}
	}

	public function run_publish_scheduler() {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			return;
		}

		if ( ! Config::is_buffer_enabled() || ! Config::is_video_r2_buffer_auto_enabled() ) {
			return;
		}

		if ( ! class_exists( 'AiSocialCollage\Database\JobManager' ) ) {
			return;
		}

		$job_repo = \AiSocialCollage\Database\JobManager::init();
		$jobs = $job_repo->get_jobs_ready_for_publish( 20 );

		if ( empty( $jobs ) ) {
			return;
		}

		Logger::info( 'publish_scheduler_start', null, [ 'jobs_count' => count( $jobs ) ], '200' );

		foreach ( $jobs as $job ) {
			$job_id = $job->id;
			$video_url = $job->video_url ?? '';
			$post_id = $job->post_id ?? 0;

			if ( empty( $video_url ) ) {
				Logger::warning( 'publish_scheduler_no_video_url', $job_id, [ 'job_id' => $job_id ], '500' );
				continue;
			}

			$attachment_id = (int) get_post_thumbnail_id( $post_id );
			if ( $attachment_id <= 0 ) {
				// Only AI-generated reels — never share source videos.
				// Exclude source videos (META_SOURCE_VIDEO) which may incorrectly have
				// META_IS_AI_COLLAGE set from older ingests via sideload_featured_image.
				$ai_attachments = get_posts( [
					'post_type'      => 'attachment',
					'post_parent'    => $post_id,
					'post_mime_type' => 'video',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_query'     => [
						'relation' => 'AND',
						[
							'key'   => Config::META_IS_AI_COLLAGE,
							'value' => '1',
						],
						[
							'key'     => Config::META_SOURCE_VIDEO,
							'compare' => 'NOT EXISTS',
						],
					],
				] );
				if ( ! empty( $ai_attachments ) ) {
					$attachment_id = (int) $ai_attachments[0];
				}
			}

			if ( $attachment_id <= 0 ) {
				Logger::warning( 'publish_scheduler_no_ai_reel', $job_id, [
					'post_id' => $post_id,
				], '404', 'No AI-generated video reel found; Buffer sharing skipped.' );
				continue;
			}

			// Check daily limit per account
			$accounts = Config::get_active_buffer_accounts();
			$can_publish = true;
			foreach ( $accounts as $acct_id => $acct ) {
				if ( Config::buffer_account_daily_limit_reached( $acct_id ) ) {
					$can_publish = false;
					Logger::warning( 'buffer_account_daily_limit_reached', $job_id, [ 'account_id' => $acct_id ], '429' );
					break;
				}
			}
			if ( ! $can_publish ) {
				continue;
			}

			// Push to Buffer
			$result = \AiSocialCollage\Services\BufferIntegration::share( $post_id, $attachment_id );

			if ( $result ) {
				// Update job with published channels
				$published_channels = get_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, true );
				if ( is_array( $published_channels ) ) {
					$channel_ids = array_column( $published_channels, 'channel_id' );
					$job_repo->update_job_fields( $job_id, [
						'published_channels' => wp_json_encode( $channel_ids ),
						'buffer_post_ids'    => wp_json_encode( array_column( $published_channels, 'buffer_post_id' ) ),
					] );
				}
				Logger::info( 'publish_scheduler_success', $job_id, [ 'post_id' => $post_id, 'video_url' => $video_url ], '200' );
			} else {
				Logger::error( 'publish_scheduler_failed', $job_id, [ 'post_id' => $post_id, 'video_url' => $video_url ], '500' );
			}
		}
	}
}
