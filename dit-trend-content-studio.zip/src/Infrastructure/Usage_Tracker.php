<?php

namespace DIT\TrendStudio\Infrastructure;

/**
 * Service to track and retrieve API usage statistics.
 * 
 * @since 2.5.0
 */
class Usage_Tracker
{
    /**
     * Get provider-specific "day" key.
     *
     * Gemini RPD resets at midnight Pacific time; align usage counters to that day.
     * Others default to UTC.
     *
     * @since 2.15.18
     */
    private static function get_provider_day_key(string $provider): string
    {
        $provider = sanitize_key($provider);

        if ($provider === 'gemini') {
            try {
                $pt = new \DateTimeZone('America/Los_Angeles');
                return (new \DateTimeImmutable('now', $pt))->format('Y-m-d');
            } catch (\Throwable $e) {
                // fallthrough
            }
        }

        return gmdate('Y-m-d');
    }

    /**
     * Increment the call count for a specific provider.
     *
     * @param string $provider The provider slug (e.g., 'gemini', 'openrouter', 'groq', 'custom').
     */
    public static function increment(string $provider)
    {
        $total_key = "dit_ts_{$provider}_calls";
        $daily_key = "dit_ts_{$provider}_daily_usage";

        // Increment total calls
        $count = (int) get_option($total_key, 0);
        update_option($total_key, $count + 1);

        // Track daily usage
        $today = self::get_provider_day_key($provider);
        $daily = get_option($daily_key, []);

        if (!is_array($daily) || empty($daily['date']) || $daily['date'] !== $today) {
            $daily = ['date' => $today, 'count' => 0];
        }

        $daily['count']++;
        update_option($daily_key, $daily);

        // Trigger action for extensibility
        do_action('dit_ts_api_usage_incremented', $provider, $daily['count'], $count + 1);
    }

    /**
     * Get usage statistics for a specific provider.
     *
     * @param string $provider The provider slug.
     * @return array Stats array with 'total' and 'today'.
     */
    public static function get_stats(string $provider): array
    {
        $total_key = "dit_ts_{$provider}_calls";
        $daily_key = "dit_ts_{$provider}_daily_usage";

        $total = (int) get_option($total_key, 0);
        $daily = get_option($daily_key, []);
        $today_count = 0;

        $today = self::get_provider_day_key($provider);
        if (is_array($daily) && !empty($daily['date']) && $daily['date'] === $today) {
            $today_count = (int) $daily['count'];
        }

        return [
            'total' => $total,
            'today' => $today_count,
        ];
    }

    /**
     * Get statistics for all registered providers.
     * 
     * Providers should register themselves using the 'dit_ts_ai_usage_providers' filter.
     *
     * @return array Associative array of provider stats.
     */
	public static function get_all_stats(): array
	{
		// @MODIFIED 2026-06-01 - OpenRouter + Groq removed as standalone providers.
		// Keep the list of stats rows consistent with AI_Provider_Factory's
		// built-in strategies so the dashboard never displays rows for providers
		// that no longer exist.
		$base_providers = [
			'gemini' => 'Gemini',
			'custom' => 'Custom',
		];

		if (class_exists('DIT\\TrendStudio\\Infrastructure\\AI_Provider_Factory')) {
			$custom_providers = AI_Provider_Factory::get_custom_providers();
			if (\is_array($custom_providers)) {
				foreach ($custom_providers as $id => $profile) {
					if (!isset($base_providers[$id])) {
						$base_providers[$id] = (string) ($profile['name'] ?? $id);
					}
				}
			}
		}

		$providers = apply_filters('dit_ts_ai_usage_providers', $base_providers);

		$all_stats = [];
		foreach ($providers as $slug => $label) {
			$stats = self::get_stats($slug);
			$all_stats[$slug] = array_merge(['label' => $label], $stats);
		}

		return $all_stats;
	}
}
