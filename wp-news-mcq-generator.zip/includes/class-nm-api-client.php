<?php

/**
 * API Client
 *
 * Centralized class for all external API communications.
 *
 * @package WP_News_MCQ_Generator
 * @version 1.2
 *
 * @MODIFIED: Fixed API 404 error by updating model name to a Gemini 1.5/2.0 family model.
 * @MODIFIED: Added static methods for getting API keys, moved from helpers.php.
 * @MODIFIED: Added ScraperAPI support.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_API_Client
{


	private static $instance = null;

	private $api_key;
	private $gnews_api_key;
	private $scraper_api_key;

	private $model_name;
	private $embedding_model;

	/**
	Get Gemini API Key (from options).
	 */
	public static function get_gemini_api_key()
	{
		$key = get_option('nm_gemini_api_key', '');
		if (empty($key)) {
		}
		return $key;
	}

	/**
	Get GNews API Key (from options).
	 */
	public static function get_gnews_api_key()
	{
		$key = get_option('nm_gnews_api_key', '');
		if (empty($key)) {
		}
		return $key;
	}

	/**
	Get ScraperAPI Key (from options).
	 */
	public static function get_scraper_api_key()
	{
		$key = get_option('nm_scraper_api_key', '');
		// Optional key; no error log if empty.
		return $key;
	}
	/**
	 * Get the current embedding model name.
	 * Centralized so all callers stay in sync when Google deprecates models.
	 */
	public static function get_embedding_model_name()
	{
		$model = get_option('nm_gemini_embedding_model', 'gemini-embedding-2');
		return $model ?: 'gemini-embedding-2';
	}
	/**
	Get singleton instance, initialized with the API key.
	 */
	public static function get_instance()
	{
		if (self::$instance === null) {
			$api_key        = self::get_gemini_api_key();
			self::$instance = new self($api_key);
		}
		return self::$instance;
	}

	/**
	Constructor.
	 */
	public function __construct($api_key)
	{
		$this->api_key         = $api_key;
		$this->gnews_api_key   = self::get_gnews_api_key();
		$this->scraper_api_key = self::get_scraper_api_key();

		// Default text model; overrideable via option.
		$this->model_name      = get_option('nm_gemini_model_name', 'gemini-2.5-flash-preview-09-2025');
		$this->embedding_model = self::get_embedding_model_name();
	}

	/**
	Scrapes a URL via ScraperAPI and returns raw HTML.

	@param string $url The URL to scrape.
	@return string|false
	 */
	public function scrape_article_text($url)
	{
		if (empty($this->scraper_api_key)) {
			return false;
		}

		if (empty($url)) {
			return false;
		}

		$api_url = 'http://api.scraperapi.com?' . http_build_query(
			array(
				'api_key' => $this->scraper_api_key,
				'url'     => $url,
				'render'  => 'true',
			)
		);

		$response = wp_remote_get(
			$api_url,
			array(
				'timeout' => 60,
			)
		);

		if (is_wp_error($response)) {
			return false;
		}

		$http_code = wp_remote_retrieve_response_code($response);
		$body      = wp_remote_retrieve_body($response);

		if ($http_code != 200) {
			return false;
		}

		if (empty($body)) {
			return false;
		}

		return $body;
	}

	/**
	Get an embedding for a string of text.
	 */
	public function get_embedding($text, $api_key = null)
	{
		$api_key = $api_key ?: $this->api_key;
		if (empty($api_key) || empty($text)) {
			return null;
		}

		$api_url = 'https://generativelanguage.googleapis.com/v1beta/models/' .
			$this->embedding_model . ':embedContent?key=' . $api_key;

		$payload = array(
			'model'                => 'models/' . $this->embedding_model,
			'outputDimensionality' => 768,
			'content'              => array(
				'parts' => array(
					array('text' => $text),
				),
			),
		);

		$response = $this->make_api_call($api_url, $payload);

		if ($response['success'] && isset($response['data']['embedding']['values'])) {
			return $response['data']['embedding']['values'];
		}

		// @DIAGNOSTIC: capture the real upstream failure so it shows up in the logs
		// instead of being silently turned into a generic "Server Error".
		$this->log_embedding_failure($text, $response);

		return null;
	}

	/**
	 * @DIAGNOSTIC: Record embedding API failures with the exact upstream
	 * HTTP code and response body so the real cause can be identified.
	 *
	 * Uses the existing NM_Generation_Logger meta column. Falls back to
	 * error_log() if the logger class is unavailable.
	 *
	 * @param string $text     The input text that failed to embed.
	 * @param array  $response The response array from make_api_call().
	 */
	private function log_embedding_failure($text, $response)
	{
		$error_message = isset($response['error']) ? $response['error'] : 'Unknown embedding failure';
		$meta          = array(
			'model'         => $this->embedding_model,
			'text_length'   => strlen((string) $text),
			'text_excerpt'  => mb_substr(wp_strip_all_tags((string) $text), 0, 200),
			'response'      => $response,
		);

		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::genlog_event(
				array(
					'event_type'       => 'error',
					'severity'         => 'error',
					'source_type'      => 'embedding',
					'source_ref'       => 'gemini_embedcontent',
					'error_code'       => 'embedding_api_failed',
					'error_message'    => $error_message,
					'meta'             => $meta,
				)
			);
		}

		// Always also write to the PHP error log for quick server-side inspection.
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log('[NM Embedding] ' . $error_message . ' | model=' . $this->embedding_model . ' | text_excerpt=' . $meta['text_excerpt']);
		}
	}

	/**
	Generate an MCQ from a block of text (evergreen news / facts).
	 */
	public function generate_mcq_from_text($input_text, $generation_context = array())
	{
		$prompt = <<<PROMPT
You are a meticulous quiz creator for a competitive-exam preparation website (CSS, PMS, NTS, UK Civil Service, US competitive exams). Your SOLE task is to analyze the provided text and determine if it contains a timeless, standalone, evergreen fact suitable for a competitive exam MCQ.
Always use up-to-date, verifiable information and call web search when recent facts or current affairs are involved.
STRICT RULES:
1. Evergreen & Standalone: The final question MUST be understandable and answerable on its own, without having read the source text. It must remain factually correct for years to come.
2. No Context Words: The question, options and Explanation MUST NOT contain phrases that refer to the source text.
3. FORBIDDEN PHRASES: "According to the text", "in the provided article", "mentioned in the text", "The article states", "Based on the article".
4. Exam Relevance: Only generate a question if the fact clearly belongs to typical competitive-exam syllabi (governance, constitution, economy, international relations, major organizations, important laws/policies, significant scientific or historical facts). If it is minor gossip, local trivia, or very narrow, you MUST reject it.
5. CONCISENESS IS CRITICAL:
- The Question Text must be UNDER 140 characters (approx 20-25 words).
- Options must be UNDER 50 characters each.
- DO NOT write paragraph-style questions. Question and answer must be very precise and to the point without any verbosity.
- Example Bad: "Which of the following determines..."
- Example Good: "What determines..."
6. Micro-Trivia Ban: Do NOT create questions about exact venues of small events, names of deputy/assistant officials, or exact times of minor meetings, even if technically evergreen.
7. NO LATEX: Do not use LaTeX formatting (e.g. $...$, \circ). Use plain text for units and math (e.g. "19°C", "H2O").

YOUR TASK:
- IF you find a suitable evergreen, exam-relevant fact, create ONE Multiple Choice Question.
- IF the text is unsuitable (opinion, gossip, trivial, no exam-relevant fact), you MUST REJECT IT.

RESPONSE FORMAT:
If you accept the text, respond ONLY with a single JSON object:
{
"question": "string",
"options": { "A": "...", "B": "...", "C": "...", "D": "..." },
"answer": "A" | "B" | "C" | "D",
"explanation": "string",
"exam_tags": ["CSS","PMS","NTS","UK_CS","US_COMP","GEN"],
- "tags": Array of 3-5 specific academic subjects, syllabus topics, or core competencies (e.g. ["Macroeconomics", "Fiscal Policy", "Tax Reform"]).
- FORBIDDEN TAGS: Do NOT use generic tags like "General Knowledge", "Core Concepts", "Linguistics", "Misc", "Trivia", or "Science". Be specific.
"difficulty": "easy" | "medium" | "hard",
"cognitive_level": "remember" | "understand" | "apply" | "analyze" | "evaluate"
}

If you reject the text, respond ONLY with:
{ "question": null }

Provided Text to Analyze:
"{$input_text}"
PROMPT;

		$prompt = $this->apply_blueprint_context($prompt, $generation_context);
		return $this->execute_gemini_request($prompt);
	}

	/**
	Generate MCQs from a specific topic (topic-based batch).
	 */
	public function generate_mcq_from_topic($topic_name, $parent_name, $num_questions = 3, $existing_questions = array(), $generation_context = array())
	{
		$context = ! empty($parent_name) ? " within the broader category of '{$parent_name}'" : '';

		$question_count = intval($num_questions) > 0 ? intval($num_questions) : 3;
		$question_word  = ($question_count === 1)
			? 'ONE (1) question'
			: "UP TO {$question_count} questions";

		$prompt = <<<PROMPT
You are an expert academic proctor. Your task is to create high-quality, exam-style questions suitable for students preparing for competitive exams (CSS, PMS, NTS, UK Civil Service, US competitive exams).

Your task is to generate {$question_word} about the specific topic: "{$topic_name}"{$context}. Each question must be exam-grade, not casual trivia.

Always use accurate, up-to-date, verifiable information, and call web search when the topic depends on recent developments or current affairs.

STRICT RULES:
1. EXAM-STYLE FOCUS: Prefer questions that test core concepts, principles, or significance. Avoid trivial name/date recall unless of high importance.
2. QUALITY OVER QUANTITY: If you only find 1–2 high-quality, exam-relevant facts, generate ONLY those. If you find no suitable facts, return an empty array.
3. Evergreen & Standalone: All questions must be timeless, standalone MCQs that remain correct for years and make sense without any external text.
4. Syllabus Relevance: Focus on themes suitable for serious competitive exams (governance, constitution, public policy, economy, IR, major organizations, key historical events, important scientific concepts, major social issues).
5. NO MICRO-TRIVIA: Avoid minor local details (small venues, junior officials, obscure dates) unless clearly exam-significant.
6. No Context Words: The question, options and Explanation MUST NOT contain phrases that refer to the source text.
7. FORBIDDEN PHRASES: "According to the text", "in the provided article", "mentioned in the text", "The article states", "Based on the article".
8. PLAUSIBLE DISTRACTORS: Options A–D must be plausible and related; no joke answers.
9. CONCISENESS IS CRITICAL:
- The Question Text must be UNDER 140 characters (approx 20-25 words).
- Options must be UNDER 50 characters each.
- DO NOT write paragraph-style questions. Question and answer must be very precise and to the point without any verbosity.
- Example Bad: "Which of the following determines..."
- Example Good: "What determines..."
10. Distinct Questions: Each question in the batch must be genuinely different.
11. NO LATEX: Do not use LaTeX formatting (e.g. $...$, \circ). Use plain text for units and math (e.g. "19°C", "H2O").
12. METADATA PER QUESTION (MANDATORY):
- "exam_tags": array of codes such as ["CSS","PMS","NTS","UK_CS","US_COMP","GEN"].
- "tags": Array of 3-5 specific academic subjects or syllabus areas (e.g. ["Organic Chemistry", "Covalent Bonding"]). 
- FORBIDDEN TAGS: Avoid generic terms like "General Knowledge", "Concepts", or the topic name itself.
- "difficulty": "easy","medium","hard".
- "cognitive_level": "remember","understand","apply","analyze","evaluate" (aim for many at analyze/evaluate).

RESPONSE FORMAT:
Respond ONLY with a JSON object:
{
"questions": [
{
"question": "...",
"options": { "A":"...", "B":"...", "C":"...", "D":"..." },
"answer": "C",
"explanation": "...",
"exam_tags": [...],
"tags": ["..."],
"difficulty": "...",
"cognitive_level": "..."
}
]
}

If you cannot find any suitable facts, return:
{ "questions": [] }
PROMPT;

		$prompt = $this->apply_blueprint_context($prompt, $generation_context);
		return $this->execute_gemini_request($prompt);
	}

	/**
	Generate a news roundup article (SEO / AIO / LLMO optimized) for a batch of
	news stories + their generated MCQs.

	@param array $articles   [{ title, description, url, source_name, category }]
	@param array $mcqs       [{ post_id, question, topic, subtopic, permalink }]
	@param array $context    Optional extra context (e.g. topic hub slugs).
	@return array            { success, data } where data has title/excerpt/content/faq/slug, or success=false.
	 */
	public function generate_news_article_from_batch(array $articles = array(), array $mcqs = array(), array $context = array())
	{
		// Guard: nothing to write about.
		if (empty($articles) && empty($mcqs)) {
			return array('success' => false, 'error' => 'No articles or MCQs supplied for article generation.');
		}

		// Serialize a bounded, safe input preview for the model.
		$story_lines = array();
		foreach (array_slice($articles, 0, 5) as $a) {
			$t = isset($a['title']) ? trim($a['title']) : '';
			$d = isset($a['description']) ? trim($a['description']) : '';
			if ($t === '') {
				continue;
			}
			$story_lines[] = "- {$t}" . ($d !== '' ? " :: {$d}" : '');
		}
		$story_text = implode("\n", $story_lines);
		if ($story_text === '') {
			$story_text = 'Top current affairs headlines from this news batch.';
		}

		// Include a few MCQ question titles so the article can reference them.
		$mcq_lines = array();
		foreach (array_slice($mcqs, 0, 8) as $m) {
			if (! empty($m['question'])) {
				$mcq_lines[] = '- ' . trim($m['question']);
			}
		}
		$mcq_text = ! empty($mcq_lines) ? implode("\n", $mcq_lines) : '';

		$topic_hint = '';
		if (! empty($context['topic'])) {
			$topic_hint = ' The batch is tagged under the topic "' . esc_html($context['topic']) . '".';
		}

		$prompt = <<<PROMPT
You are a senior current-affairs writer for a competitive-exam preparation website (CSS, PMS, NTS, UK Civil Service, US competitive exams). Write ONE concise, high-accuracy news roundup article based ONLY on the provided stories and facts. The article is for aspirants preparing for general knowledge and current-affairs sections.

STRICT ACCURACY RULES (non-negotiable):
1. FACT-ONLY: State only facts present in the provided stories. NEVER invent names, numbers, dates, or details.
2. NO HALLUCINATION: If a detail is not in the source, do not add it.
3. BALANCED: Present factual information plainly. Do not express political opinion or speculation.
4. CITE SOURCES: Reference the source outlet name when given.
{$topic_hint}

SEO / AIO / LLMO RULES:
- Title: under 65 characters, keyword-rich, a single clear hook (e.g. "Pakistan, China, Turkiye Form Trilateral Defense Pact: What It Means").
- Meta/excerpt: 150-160 characters, compelling, summarizes the news + exam relevance.
- Write in plain HTML with <h2> section headings. Keep paragraphs short (2-4 sentences).
- Put the single most important fact and its answer in the FIRST sentence (so AI Overviews / answer engines can extract it).
- End with a short "Exam Takeaway" <h2> that lists 2-4 bullet points of key facts to remember.
- Include an FAQ <h2> with 2-3 <h3> questions and short <p> answers (natural language, question format) — this maps to FAQ schema.
- Do NOT use markdown code fences. Output raw HTML inside a single JSON string.

RETURN ONLY a JSON object:
{
  "title": "string",
  "slug": "string (lowercase-hyphenated, max 70 chars)",
  "excerpt": "string (150-160 chars)",
  "content": "string (full HTML article body, no <html>/<body> wrapper)",
  "faq": [ {"q": "string", "a": "string"} ]
}
PROMPT;

		// Provide the stories + generated MCQs as grounding context after the prompt.
		$prompt .= "\n\n=== STORIES FOR THIS BATCH ===\n{$story_text}\n";
		if ($mcq_text !== '') {
			$prompt .= "\n=== RELATED MCQs GENERATED FROM THESE STORIES ===\n{$mcq_text}\n";
		}

		$prompt = $this->apply_blueprint_context($prompt, $context);
		return $this->execute_article_gemini_request($prompt);
	}

	/**
	 * Generate an EVERGREEN, SEO/AIO/LLMO-optimized "topic pillar" article
	 * (800–1500 words) for a single parent topic. Used by NM_Topic_Pillar_Generator.
	 *
	 * Returns the same JSON shape as article generation:
	 *   { title, slug, excerpt, content (HTML), faq[] }
	 *
	 * @param string $topic_name       Parent topic name (e.g. "History").
	 * @param string $topic_desc       Short topic description (from the term).
	 * @param array  $exams            Optional list of exam names to reference.
	 * @param array  $mcqs             Grounding context: [{question, answer}] from the
	 *                                 topic's real MCQs so the pillar links & facts are accurate.
	 * @param int    $min_words        Target minimum length.
	 * @param int    $max_words        Target maximum length.
	 * @return array
	 */
	public function generate_topic_pillar( $topic_name, $topic_desc = '', array $exams = array(), array $mcqs = array(), $min_words = 800, $max_words = 1500 )
	{
		$topic_name = trim( (string) $topic_name );
		if ( $topic_name === '' ) {
			return array( 'success' => false, 'error' => 'No topic name supplied for pillar generation.' );
		}
		$min_words = max( 300, absint( $min_words ) );
		$max_words = max( $min_words + 100, absint( $max_words ) );

		$exam_text = '';
		if ( ! empty( $exams ) ) {
			$exam_text = ' The article should reference and prepare readers for these competitive exams: ' . implode( ', ', array_map( 'sanitize_text_field', array_slice( $exams, 0, 6 ) ) ) . '.';
		}

		$desc_text = '';
		if ( $topic_desc !== '' ) {
			$desc_text = ' The topic is described as: "' . esc_html( wp_strip_all_tags( $topic_desc ) ) . '".';
		}

		// Bounded, accurate grounding from the topic's own MCQs.
		$mcq_lines = array();
		foreach ( array_slice( $mcqs, 0, 12 ) as $m ) {
			if ( ! empty( $m['question'] ) ) {
				$mcq_lines[] = '- Q: ' . trim( $m['question'] ) . ( ! empty( $m['answer'] ) ? '  [Answer: ' . trim( $m['answer'] ) . ']' : '' );
			}
		}
		$mcq_text = ! empty( $mcq_lines ) ? "\n\n=== VERIFIED FACTS FROM THIS SITE'S MCQs (use these to ground the article, do not contradict them) ===\n" . implode( "\n", $mcq_lines ) : '';

		$prompt = <<<PROMPT
You are a senior exam-prep content director for TheQuizWire, a professional competitive-exam practice site (CSS, PMS, NTS, FPSC, PPSC, UK Civil Service, US competitive exams). Write ONE evergreen, comprehensive "pillar" article about the topic "{$topic_name}".

PURPOSE & AUDIENCE:
- Evergreen reference guide for aspirants. It must still be accurate and useful months from now (avoid "this week/last month" claims, recent announcements, product launches, or any news-cycle fact that will date the article).
- Professional, exam-focused, factual tone, written by a human subject expert.
{$desc_text}
{$exam_text}

STRICT ACCURACY RULES (non-negotiable):
1. FACT-ONLY, NEVER hallucinate. Use only widely-established knowledge of this topic, plus the VERIFIED FACTS supplied below.
2. Do NOT invent names, years, numbers, people, or statistics.
3. Stay objective and balanced. No political opinion or speculation.
4. When unsure, keep statements general but correct.

STRICT FORMAT RULES (non-negotiable):
1. Do NOT include any byline, author name, "By ..." line, or editorial-team credit anywhere in the content — the site template renders the byline.
2. Do NOT include an FAQ, "Frequently Asked Questions", or "Common Questions & Answers" section in the content — put ALL Q&A pairs ONLY in the JSON "faq" array; the site appends a single FAQ section with schema markup.
3. Do NOT include a "Related MCQs" / "Practice MCQs" section or any links to quiz pages — the site appends its own dynamic practice-question block.

SEO / AIO / LLMO RULES (this is critical):
- Title: 50–62 characters, keyword-first, a single clear hook that includes the topic name (e.g. "History MCQs: Complete Guide & Practice for CSS & PMS").
- Meta/excerpt: 150–160 characters, compelling, keyword-rich, states the page's value + exam relevance.
- Structure with <h2> sections and short <h3> sub-parts. Keep paragraphs 2–4 sentences.
- Put the single most important definition/fact and its key point in the FIRST sentence of the body (so AI Overviews / answer engines can extract it).
- Include a "Key Concepts" <h2>, a "Why It Matters for Exams" <h2> with 2–4 bullets, and an "Exam Takeaway" <h2> with 3–5 bullet point facts to remember. Each fact should appear ONCE in the body — the Exam Takeaway bullets may summarize, but do not copy identical sentences.
- Natural, human phrasing that LLMs can quote. Use a variety of sentence lengths. Do NOT overuse keywords.
- Target length: {$min_words}–{$max_words} words total.
- Output well-formed HTML: every opening tag closed, no stray closing tags, no <html>/<body> wrapper.
- Do NOT use markdown code fences. Output raw HTML inside a single JSON string.
- Return ONLY a JSON object:
{
  "title": "string",
  "slug": "string (lowercase-hyphenated, max 70 chars)",
  "excerpt": "string (150-160 chars)",
  "content": "string (full HTML article body, no <html>/<body> wrapper)",
  "faq": [ {"q": "string", "a": "string"} ]
}
PROMPT;
		$prompt .= $mcq_text;

		return $this->execute_article_gemini_request( $prompt );
	}

	/**
	 * Generate ONE daily current-affairs roundup article covering ALL MCQs published
	 * that day, grouped by topic. This is the "one post per day" roundup the user wants
	 * (instead of one tiny article per news batch).
	 *
	 * Same JSON shape as article generation: { title, slug, excerpt, content, faq }.
	 *
	 * @param array $mcqs_by_topic  [ topic_name => [ {question, answer, source_name}, ... ] ]
	 * @param string $date          Y-m-d date string (for the prompt context).
	 * @return array
	 */
	public function generate_daily_roundup_from_mcqs( array $mcqs_by_topic = array(), $date = '' )
	{
		if ( empty( $mcqs_by_topic ) ) {
			return array( 'success' => false, 'error' => 'No MCQs supplied for the daily roundup.' );
		}
		if ( $date === '' ) {
			$date = current_time( 'Y-m-d' );
		}

		// Build a grounded, factual per-topic block.
		$topic_blocks = array();
		foreach ( $mcqs_by_topic as $topic => $items ) {
			$lines = array();
			foreach ( array_slice( (array) $items, 0, 15 ) as $m ) {
				$q = isset( $m['question'] ) ? trim( $m['question'] ) : '';
				$a = isset( $m['answer'] ) ? trim( $m['answer'] ) : '';
				if ( $q === '' ) {
					continue;
				}
				$line = '- Q: ' . $q;
				if ( $a !== '' ) {
					$line .= '  [Answer: ' . $a . ']';
				}
				if ( ! empty( $m['source_name'] ) ) {
					$line .= '  (Source: ' . trim( $m['source_name'] ) . ')';
				}
				$lines[] = $line;
			}
			if ( $lines ) {
				$topic_blocks[] = "## " . $topic . "\n" . implode( "\n", $lines );
			}
		}
		$grounding = implode( "\n\n", $topic_blocks );
		if ( $grounding === '' ) {
			return array( 'success' => false, 'error' => 'No usable MCQ facts for the daily roundup.' );
		}

		$prompt = <<<PROMPT
You are a senior exam-prep content director for TheQuizWire, a professional competitive-exam practice site (CSS, PMS, NTS, FPSC, PPSC, UK Civil Service, US competitive exams). This is NOT a news site. Write ONE daily "practice compilation" post for {$date} that presents all of the day's published MCQs (and the current-affairs facts behind them) as an organized study/revision guide for aspirants.

PURPOSE & AUDIENCE:
- A single, indexable daily practice & revision post covering ALL MCQs published on the site that day, grouped by topic.
- Tone: professional, exam-focused, study-oriented — like a teacher compiling the day's practice questions for students to revise. NOT a news article; the news facts are supporting context for exam prep.
- "(By Author" byline).

STRICT ACCURACY RULES (non-negotiable):
1. FACT-ONLY: Use ONLY the facts + verified answers provided below. NEVER invent names, numbers, dates, or details.
2. NO HALLUCINATION: If a fact is not in the input, do not add it.
3. BALANCED: Plain factual presentation. No political opinion or speculation.
4. Reference the source outlet when given (as background only).

STRUCTURE & TONE (exam-practice oriented):
- Title: 50–62 characters, exam-focused, e.g. "Daily MCQs & Current Affairs Practice: {$date}".
- Meta/excerpt: 150–160 characters, compelling, emphasizes daily exam practice + current affairs.
- Frame the post as a "practice & revision guide". Open with a short intro sentence telling aspirants these are the day's MCQs grouped by topic for quick revision.
- One <h2> section per topic. Under each, present the day's facts for that topic as concise study points (2–4 sentences each), and gently reference that practice MCQs follow below.
- Keep paragraphs short and factual. This is study material, not storytelling.
- End with an "Exam Takeaway" <h2> listing 3–5 bullet-point key facts to remember.
- Include an FAQ <h2> with 2–3 <h3> questions and short <p> answers (maps to FAQ schema).
- Do NOT create a "Related MCQs" section and do NOT add links to MCQ pages — those are added automatically after generation.
- Do NOT use markdown code fences. Output raw HTML inside a single JSON string.

RETURN ONLY a JSON object:
{
  "title": "string",
  "slug": "string (lowercase-hyphenated, max 70 chars)",
  "excerpt": "string (150-160 chars)",
  "content": "string (full HTML article body, no <html>/<body> wrapper)",
  "faq": [ {"q": "string", "a": "string"} ]
}
PROMPT;

		$prompt .= "\n\n=== VERIFIED FACTS PUBLISHED ON {$date} (grouped by topic) ===\n" . $grounding;

		return $this->execute_article_gemini_request( $prompt );
	}

	/**
	Generalized Gemini request for article generation.
	Mirrors execute_gemini_request() but accepts the article JSON shape
	(title/excerpt/content/faq/slug) instead of requiring a 'question'/'questions' key.
	 */
	private function execute_article_gemini_request($prompt, $generation_config = null)
	{
		if (empty($this->api_key)) {
			return array('success' => false, 'error' => 'API key not configured.');
		}

		$api_url = 'https://generativelanguage.googleapis.com/v1beta/models/' .
			$this->model_name . ':generateContent?key=' . $this->api_key;

		$payload = array(
			'contents' => array(
				array(
					'parts' => array(
						array('text' => $prompt),
					),
				),
			),
		);

		$tools = $this->get_google_search_tools();
		if (! empty($tools)) {
			$payload['tools'] = $tools;
		}
		if (! empty($generation_config)) {
			$payload['generationConfig'] = $generation_config;
		}

		$response = $this->make_api_call($api_url, $payload);
		if (! $response['success']) {
			return $response;
		}

		if (empty($response['data']['candidates'][0]['content']['parts'][0]['text'])) {
			return array('success' => false, 'error' => 'Empty response from Gemini for article generation.');
		}

		$raw_text = trim($response['data']['candidates'][0]['content']['parts'][0]['text']);
		$start    = strpos($raw_text, '{');
		$end      = strrpos($raw_text, '}');
		if ($start === false || $end === false || $end < $start) {
			return array('success' => false, 'error' => 'Article response did not contain a JSON object.');
		}

		$json_string = substr($raw_text, $start, $end - $start + 1);
		$decoded     = json_decode($json_string, true);
		if (json_last_error() !== JSON_ERROR_NONE || ! is_array($decoded)) {
			return array('success' => false, 'error' => 'Article JSON parse failed: ' . json_last_error_msg());
		}

		// Validate required fields; tolerate partial and fill sane defaults.
		$title   = isset($decoded['title']) ? wp_strip_all_tags(trim($decoded['title'])) : '';
		$content = isset($decoded['content']) ? trim($decoded['content']) : '';
		if ($title === '' || $content === '') {
			return array('success' => false, 'error' => 'Article generation returned empty title/content.');
		}

		$slug = isset($decoded['slug']) ? sanitize_title($decoded['slug']) : sanitize_title($title);
		if ($slug === '') {
			$slug = sanitize_title($title);
		}

		$excerpt = isset($decoded['excerpt']) ? wp_strip_all_tags(trim($decoded['excerpt'])) : '';
		if (mb_strlen($excerpt) > 165) {
			$excerpt = mb_substr($excerpt, 0, 160) . '…';
		}
		if ($excerpt === '') {
			$excerpt = mb_substr(wp_strip_all_tags($title), 0, 155) . '…';
		}

		$faq = array();
		if (! empty($decoded['faq']) && is_array($decoded['faq'])) {
			foreach ($decoded['faq'] as $item) {
				if (is_array($item) && ! empty($item['q']) && ! empty($item['a'])) {
					$faq[] = array(
						'q' => wp_strip_all_tags(trim($item['q'])),
						'a' => wp_strip_all_tags(trim($item['a'])),
					);
				}
			}
		}

		return array(
			'success' => true,
			'data'    => array(
				'title'   => $title,
				'slug'    => $slug,
				'excerpt' => $excerpt,
				'content' => $content,
				'faq'     => $faq,
			),
		);
	}

	/**
	Generate MCQs with categorization (Current Affairs).
	 */
	public function generate_mcq_with_categorization($input_text, $num_questions = 3, $generation_context = array())
	{
		$question_count    = (int) get_option('nm_ca_questions_per_article', 3);
		$question_word_num = ($question_count === 1) ? 'ONE' : "UP TO {$question_count}";
		$question_word     = ($question_count === 1) ? 'fact' : 'facts';

		$prompt = <<<PROMPT
You are an expert academic proctor. Your task is to analyze the provided news text and create high-quality, exam-style questions suitable for students preparing for competitive exams (CSS, PMS, NTS, UK Civil Service, US competitive exams).

Always use accurate, up-to-date, verifiable information, and call web search when the topic depends on recent developments or current affairs.

STRICT RULES:
1. Categorize first: "Pakistan Current Affairs" or "International Current Affairs".
2. Extract {$question_word_num} EVERGREEN and ACADEMICALLY-VALUABLE {$question_word} from the text. These must have lasting value for exams and make sense months or years from now.
- QUALITY OVER QUANTITY: If only one fact is truly valuable, generate ONLY one MCQ. If none, return an empty array.
3. Exam relevance: Only use facts that fit serious exam themes (governance, constitution, public administration, economy, IR, treaties, security, environment, major reforms, significant scientific/tech developments).
4. Focus on WHAT/WHY, not trivial WHO/WHERE details.
5. No Context Words: The question, options and Explanation MUST NOT contain phrases that refer to the source text.
6. FORBIDDEN PHRASES: "According to the text", "in the provided article", "mentioned in the text", "The article states", "Based on the article".
7. PLAUSIBLE DISTRACTORS: Options A–D must be plausible and related.
8. CONCISENESS IS CRITICAL:
- The Question Text must be UNDER 140 characters (approx 20-25 words).
- Options must be UNDER 50 characters each.
- DO NOT write paragraph-style questions. Question and answer must be very precise and to the point without any verbosity.
- Example Bad: "Which of the following determines..."
- Example Good: "What determines..."
9. NO LATEX: Do not use LaTeX formatting (e.g. $...$, \circ). Use plain text for units and math (e.g. "19°C", "H2O").
10. METADATA PER QUESTION:
- "exam_tags": ["CSS","PMS","NTS","UK_CS","US_COMP","GEN"] as appropriate.
- "tags": Array of 3-5 specific academic subjects, syllabus areas, or core competencies (e.g. ["Constitutional Law", "Federalism"]).
- FORBIDDEN TAGS: Do NOT use generic tags like "Current Affairs", "General", "Misc", "Facts".
- "difficulty": "easy","medium","hard".
- "cognitive_level": "remember","understand","apply","analyze","evaluate" (prefer understand/apply/analyze).

RESPONSE FORMAT:
Return ONLY a JSON object like:
{
"topic": "Pakistan Current Affairs" | "International Current Affairs",
"questions": [
{
"question": "...",
"options": { "A":"...", "B":"...", "C":"...", "D":"..." },
"answer": "C",
"explanation": "...",
"exam_tags": [...],
"tags": ["..."],
"difficulty": "...",
"cognitive_level": "..."
}
]
}

If the text is unsuitable, return:
{ "questions": [] }

PROVIDED TEXT:
"{$input_text}"
PROMPT;

		$prompt = $this->apply_blueprint_context($prompt, $generation_context);
		return $this->execute_gemini_request($prompt);
	}

	/**
	Rephrase an existing MCQ (for Feed Importer).
	Uses a HEREDOC prompt to avoid fragile escaping and keep JSON examples safe.
	 */
	public function rephrase_mcq($data)
	{
		// Build options block line by line, e.g. "A. Option text"
		$lines = array();
		if (! empty($data['options']) && is_array($data['options'])) {
			foreach ($data['options'] as $k => $v) {
				$lines[] = $k . '. ' . $v;
			}
		}
		$opts = implode("\n", $lines);

		$question       = isset($data['question']) ? $data['question'] : '';
		$correct_letter = isset($data['correct_letter']) ? $data['correct_letter'] : '';

		$prompt = <<<PROMPT
Rephrase this MCQ slightly. Output ONLY valid JSON:

Question: {$question}
Options:
{$opts}
Correct: {$correct_letter}

JSON format:
{"question":"rephrased question","options":{"A":"opt A","B":"opt B","C":"opt C","D":"opt D"},"answer":"C","explanation":"brief text"}
PROMPT;

		$generation_config = array(
			'temperature'     => 0.3,
			'maxOutputTokens' => 500,
		);

		return $this->execute_gemini_request($prompt, $generation_config);
	}
	/**
	Prepend exam/blueprint context to a prompt.

	$generation_context may contain:
	- exam_slug
	- difficulty
	- cognitive_level
	- prompt_hint
	 */
	private function apply_blueprint_context($prompt, $generation_context = array())
	{
		if (empty($generation_context) || ! is_array($generation_context)) {
			return $prompt;
		}

		$lines = array();

		if (! empty($generation_context['exam_slug'])) {
			$lines[] = 'EXAM CONTEXT: ' . $generation_context['exam_slug'];
		}
		if (! empty($generation_context['difficulty'])) {
			$lines[] = 'TARGET DIFFICULTY: ' . $generation_context['difficulty'];
		}
		if (! empty($generation_context['cognitive_level'])) {
			$lines[] = 'TARGET COGNITIVE LEVEL: ' . $generation_context['cognitive_level'];
		}
		if (! empty($generation_context['prompt_hint'])) {
			$lines[] = 'EXAM STYLE NOTES: ' . $generation_context['prompt_hint'];
		}

		if (empty($lines)) {
			return $prompt;
		}

		$header = "### EXAM BLUEPRINT CONTEXT ###\n"
			. implode("\n", $lines)
			. "\n\n";

		return $header . $prompt;
	}
	/**
	Execute a Gemini generateContent request and parse JSON.

	@param string     $prompt
	@param array|null $generation_config
	@return array ['success'=>bool, 'data'=>array] or ['success'=>false,'error'=>string]
	 */
	private function execute_gemini_request($prompt, $generation_config = null)
	{
		if (empty($this->api_key)) {
			return array(
				'success' => false,
				'error'   => 'API key not configured.',
			);
		}

		$api_url = 'https://generativelanguage.googleapis.com/v1beta/models/' .
			$this->model_name . ':generateContent?key=' . $this->api_key;

		$payload = array(
			'contents' => array(
				array(
					'parts' => array(
						array('text' => $prompt),
					),
				),
			),
		);

		// Attach Google Search / web-grounding tools when enabled.
		$tools = $this->get_google_search_tools();
		if (! empty($tools)) {
			$payload['tools'] = $tools;
		}

		if (! empty($generation_config)) {
			$payload['generationConfig'] = $generation_config;
		}

		$response = $this->make_api_call($api_url, $payload);

		// Transport / HTTP error
		if (! $response['success']) {
			return $response;
		}

		// No text returned
		if (empty($response['data']['candidates'][0]['content']['parts'][0]['text'])) {
			$finish_reason = $response['data']['candidates'][0]['finishReason'] ?? 'unknown';
			$error_msg     = 'Empty response from Gemini. Finish Reason: ' . $finish_reason;
			if ($finish_reason === 'SAFETY') {
				$error_msg = "Content blocked by API safety filters. (Reason: {$finish_reason})";
			}
			return array(
				'success' => false,
				'error'   => $error_msg,
			);
		}

		// Raw model text (may include markdown or extra text)
		$raw_text = trim($response['data']['candidates'][0]['content']['parts'][0]['text']);

		// Extract the JSON object: everything between the first '{' and the last '}'.
		$start = strpos($raw_text, '{');
		$end   = strrpos($raw_text, '}');

		if ($start === false || $end === false || $end < $start) {
			return array(
				'success' => false,
				'error'   => 'API response did not contain a valid JSON object.',
			);
		}

		$json_string = substr($raw_text, $start, $end - $start + 1);

		// Decode JSON
		$decoded    = json_decode($json_string, true);
		$json_error = json_last_error();

		if ($json_error === JSON_ERROR_NONE && is_array($decoded)) {
			// Accept either a single MCQ or a batch of MCQs
			if (array_key_exists('question', $decoded) || array_key_exists('questions', $decoded)) {
				// Sanitize content to remove LaTeX artifacts
				$decoded = $this->sanitize_ai_response_values($decoded);

				return array(
					'success' => true,
					'data'    => $decoded,
				);
			}
		}

		return array(
			'success' => false,
			'error'   => 'API returned invalid JSON. Parser Error: ' . json_last_error_msg(),
		);
	}
	/**
	Build Google Search / web-grounding tools configuration for Gemini.

	Uses the model name to pick the right tool:
	- gemini-2.0 / 2.5 / 3.x: google_search
	- gemini-1.5.x: google_search_retrieval (legacy, with dynamic config)

	You can disable this globally via the `nm_enable_google_search_grounding`
	option (0/1) or the `nm_api_enable_google_search_grounding` filter.

	@return array|null
	 */
	private function get_google_search_tools()
	{
		// Default: enabled; allow override from WP option + filter.
		$enabled = (bool) get_option('nm_enable_google_search_grounding', true);
		$enabled = (bool) apply_filters('nm_api_enable_google_search_grounding', $enabled);

		if (! $enabled) {
			return null;
		}

		$model = (string) $this->model_name;

		// Newer Gemini 2.x / 3.x models: use google_search tool.
		// See Google Search grounding docs for supported models and JSON shape.
		if (
			strpos($model, '2.5') !== false
			|| strpos($model, '2.0') !== false
			|| strpos($model, '3.') !== false
		) {
			return array(
				array(
					'google_search' => (object) array(),
				),
			);
		}

		// Legacy Gemini 1.5 models: use google_search_retrieval with dynamic config.
		if (strpos($model, '1.5') !== false) {
			return array(
				array(
					'google_search_retrieval' => array(
						'dynamic_retrieval_config' => array(
							'mode'              => 'MODE_DYNAMIC',
							// Only perform web search when the model's confidence
							// in its own knowledge is below this threshold.
							'dynamic_threshold' => 0.7,
						),
					),
				),
			);
		}

		// For unknown / unsupported model names, avoid adding tools to prevent API errors.
		return null;
	}

	/**
	Centralized private function for all API calls.
	 */
	private function make_api_call($api_url, $payload)
	{
		$request_body = json_encode($payload);

		$response = wp_remote_post(
			$api_url,
			array(
				'method'  => 'POST',
				'headers' => array('Content-Type' => 'application/json'),
				'body'    => $request_body,
				'timeout' => 60,
			)
		);

		if (is_wp_error($response)) {
			return array(
				'success' => false,
				'error'   => 'Connection Error: ' . $response->get_error_message(),
			);
		}

		$body      = wp_remote_retrieve_body($response);
		$data      = json_decode($body, true);
		$http_code = wp_remote_retrieve_response_code($response);

		if ($http_code !== 200 || (isset($data['error']) && $data['error'])) {
			$error_message = $data['error']['message'] ?? 'Unknown API error';
			if (empty($error_message) && ! empty($body)) {
				$error_message = strip_tags($body);
			}
			return array(
				'success' => false,
				'error'   => 'HTTP ' . $http_code . ' - ' . $error_message,
			);
		}

		return array(
			'success' => true,
			'data'    => $data,
		);
	}

	/**
	 * Recursively sanitize array values to remove LaTeX and fix common formatting issues.
	 * @MODIFIED: 2026-01-15 - Added comprehensive LaTeX-to-Unicode mapping (100+ symbols) and Markdown-to-HTML conversion.
	 *
	 * @param mixed $data
	 * @return mixed
	 */
	private function sanitize_ai_response_values($data)
	{
		if (is_string($data)) {
			$text = $data;

			// --- 1. LaTeX to Unicode Replacement Map (100+ symbols) ---
			$latex_map = [
				// Greek Lowercase
				'\\alpha' => 'α',
				'\\beta' => 'β',
				'\\gamma' => 'γ',
				'\\delta' => 'δ',
				'\\epsilon' => 'ε',
				'\\zeta' => 'ζ',
				'\\eta' => 'η',
				'\\theta' => 'θ',
				'\\iota' => 'ι',
				'\\kappa' => 'κ',
				'\\lambda' => 'λ',
				'\\mu' => 'μ',
				'\\nu' => 'ν',
				'\\xi' => 'ξ',
				'\\omicron' => 'ο',
				'\\pi' => 'π',
				'\\rho' => 'ρ',
				'\\sigma' => 'σ',
				'\\tau' => 'τ',
				'\\upsilon' => 'υ',
				'\\phi' => 'φ',
				'\\chi' => 'χ',
				'\\psi' => 'ψ',
				'\\omega' => 'ω',
				// Greek Uppercase
				'\\Alpha' => 'Α',
				'\\Beta' => 'Β',
				'\\Gamma' => 'Γ',
				'\\Delta' => 'Δ',
				'\\Epsilon' => 'Ε',
				'\\Zeta' => 'Ζ',
				'\\Eta' => 'Η',
				'\\Theta' => 'Θ',
				'\\Iota' => 'Ι',
				'\\Kappa' => 'Κ',
				'\\Lambda' => 'Λ',
				'\\Mu' => 'Μ',
				'\\Nu' => 'Ν',
				'\\Xi' => 'Ξ',
				'\\Omicron' => 'Ο',
				'\\Pi' => 'Π',
				'\\Rho' => 'Ρ',
				'\\Sigma' => 'Σ',
				'\\Tau' => 'Τ',
				'\\Upsilon' => 'Υ',
				'\\Phi' => 'Φ',
				'\\Chi' => 'Χ',
				'\\Psi' => 'Ψ',
				'\\Omega' => 'Ω',

				// Math Operators & Logic
				'\\times' => '×',
				'\\div' => '÷',
				'\\pm' => '±',
				'\\mp' => '∓',
				'\\cdot' => '·',
				'\\star' => '⋆',
				'\\ast' => '*',
				'\\cup' => '∪',
				'\\cap' => '∩',
				'\\setminus' => '∖',
				'\\oplus' => '⊕',
				'\\ominus' => '⊖',
				'\\otimes' => '⊗',
				'\\oslash' => '⊘',
				'\\leq' => '≤',
				'\\geq' => '≥',
				'\\neq' => '≠',
				'\\approx' => '≈',
				'\\equiv' => '≡',
				'\\sim' => '∼',
				'\\simeq' => '≃',
				'\\cong' => '≅',
				'\\propto' => '∝',
				'\\forall' => '∀',
				'\\exists' => '∃',
				'\\nexists' => 'nexists',
				'\\in' => '∈',
				'\\notin' => '∉',
				'\\subset' => '⊂',
				'\\subseteq' => '⊆',
				'\\supset' => '⊃',
				'\\supseteq' => '⊇',
				'\\land' => '∧',
				'\\lor' => '∨',
				'\\neg' => '¬',
				'\\rightarrow' => '→',
				'\\leftarrow' => '←',
				'\\Rightarrow' => '⇒',
				'\\Leftarrow' => '⇐',
				'\\leftrightarrow' => '↔',
				'\\Leftrightarrow' => '⇔',

				// Units & Misc
				'\\degrees' => '°',
				'\\circ' => '°',
				'^{\\circ}' => '°',
				'^\\circ' => '°',
				'\\infty' => '∞',
				'\\partial' => '∂',
				'\\nabla' => '∇',
				'\\sqrt' => '√',
				'\\int' => '∫',
				'\\sum' => '∑',
				'\\prod' => '∏',
				'\\angle' => '∠',
				'\\perp' => '⊥',
				'\\parallel' => '∥',
				'\\ell' => 'ℓ',
				'\\Re' => 'ℜ',
				'\\Im' => 'ℑ',
				'\\hbar' => 'ℏ',
				'\\dag' => '†',
				'\\ddag' => '‡',
				'\\bullet' => '•',
				'\\copyright' => '©',
				'\\circledR' => '®',
				'\\euro' => '€',
				'\\pound' => '£',

				// Common Physics/Chem
				'\\AA' => 'Å',
			];

			// Apply replacement map
			$text = strtr($text, $latex_map);

			// --- 2. Clean up residual LaTeX syntax ---

			// Remove LaTeX wrappers ($...$, \(...\), \text{...}, \mathbf{...})
			// $...$
			$text = preg_replace('/\$(.*?)\$/', '$1', $text);
			// \(...\)
			$text = preg_replace('/\\\\\((.*?)\\\\\)/', '$1', $text);
			// \text{...}, \mathbf{...}, \mathrm{...}, \textit{...}
			$text = preg_replace('/\\\\(text|mathbf|mathrm|textit|emph)\{([^}]+)\}/', '$2', $text);
			// Remove lonely backslashes often left behind
			$text = str_replace('\\', '', $text);


			// --- 3. Markdown Formatting Conversions ---

			// Convert bold: **text** -> <strong>text</strong>
			$text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);

			// Convert bold-ish: *text* -> <strong>text</strong> (User preferred single star as bold)
			$text = preg_replace('/(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)/', '<strong>$1</strong>', $text);

			// Convert code/emphasis: `text` -> <strong>text</strong>
			$text = preg_replace('/`(.*?)`/', '<strong>$1</strong>', $text);


			return trim($text);
		}

		if (is_array($data)) {
			foreach ($data as $key => $value) {
				$data[$key] = $this->sanitize_ai_response_values($value);
			}
		}

		return $data;
	}
}