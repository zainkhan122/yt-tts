<?php

/**
 * Hero Block
 * @MODIFIED 2025-12-04 v1.4.0: Server-side rendered hero section block
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Blocks;

use SEO_Article_Generator\Generator\Hero_Renderer;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Register and render hero section block
 */
class Hero_Block
{
    /**
     * Initialize block registration
     * @MODIFIED 2025-12-15 v2.1.4: Added editor script enqueue
     *
     * @return void
     */
    public static function init()
    {
        add_action('init', array(__CLASS__, 'register_block'));
        // @MODIFIED 2025-12-15 v2.1.4: Enqueue JS for editor so block is recognized
        add_action('enqueue_block_editor_assets', array(__CLASS__, 'enqueue_editor_assets'));
    }

    /**
     * Enqueue editor assets for hero block
     * @MODIFIED 2025-12-15 v2.1.4: Added for editor compatibility
     *
     * @return void
     */
    public static function enqueue_editor_assets()
     {
         // @MODIFIED 2025-12-28: Cache bust via file modification time
         $block_js = \SEO_GEN_PLUGIN_DIR . 'assets/js/blocks/hero-block.js';
         \wp_enqueue_script(
             'seo-gen-hero-block',
             \SEO_GEN_PLUGIN_URL . 'assets/js/blocks/hero-block.js',
             array('wp-blocks', 'wp-element'),
             \file_exists($block_js) ? \filemtime($block_js) : \SEO_GEN_VERSION,
             true
         );
}
  
    /**
     * Register the hero block
     * @MODIFIED 2025-12-04 v1.4.0: Server-side rendered block
     *
     * @return void
     */
    public static function register_block()
    {
        // Dynamic (server-side rendered) block — no static save content.
        // save_callback returns empty string to prevent wpautop wrapping the block in <p> tags.
        \register_block_type('seo-gen/hero', array(
            'api_version'   => 3,
            'render_callback' => array(__CLASS__, 'render_block'),
            'save_callback'   => array(__CLASS__, 'save_block'),
            'attributes'    => array(), // No attributes — reads from post meta
            'supports'      => array(
                'align'    => false,
                'html'     => false,
                'inserter' => true,
            ),
        ));
    }

    /**
     * Save hero block. Since it's server-side rendered, return an empty string.
     * This prevents wpautop from wrapping the block in <p> tags.
     *
     * @return string
     */
    public static function save_block()
    {
        return '';
    }

    /**
     * Render hero block
     * @MODIFIED 2025-12-04 v1.4.0: Read from post meta and render
     *
     * @param array  $attributes Block attributes (unused, reads from meta)
     * @param string $content    Block content (unused)
     * @return string Rendered HTML
     */
    public static function render_block($attributes = array(), $content = '')
    {
        // Get current post ID
        $post_id = \get_the_ID();

        if (! $post_id) {
            return '';
        }

        // Retrieve hero data from canonical loader (handles migration and unified keys)
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);

        // If no hero data, return empty (block will be invisible)
        if (empty($hero_data) || ! \is_array($hero_data)) {
            return '';
        }

        // FIX: Inject post_id for renderer - needed in Gutenberg block context where get_the_ID() may fail
        $hero_data['post_id'] = $post_id;

        // Use renderer to generate HTML
        $renderer = new Hero_Renderer();
        return $renderer->render($hero_data);
    }

}
