/**
 * Admin Generator JavaScript
 *
 * @package SEO_Article_Generator
 */

(function ($) {
  "use strict";

  var SEOGenerator = {
    jobId: null,
    pollInterval: null,

    init: function () {
      this.bindEvents();
      this.initMediaUploader();
      // @MODIFIED 2025-12-04 v1.5.1: Removed initModeSwitch - Manual Mode removed
      this.initPartialRegenToggle();
      // @since 2.7.3: Post picker for updating existing posts
      this.initPostPicker();
    },

    bindEvents: function () {
      $("#seo-gen-form").on("submit", this.handleSubmit.bind(this));
      $("#seo-gen-publish").on("click", this.handlePublish.bind(this));
      $("#seo-gen-copy-html").on("click", this.handleCopyHtml.bind(this));
      $("#seo-gen-reset").on("click", this.handleReset.bind(this));

      // @MODIFIED 2026-01-05: Debug button bindings
      $("#seo-gen-view-request").on("click", this.handleViewRequest.bind(this));
      $("#seo-gen-view-response").on("click", this.handleViewResponse.bind(this));
      $(".debug-copy-btn").on("click", this.handleCopyDebug.bind(this));
    },

    // @MODIFIED 2025-12-02 Phase 1: WP Media Uploader for screenshots
    initMediaUploader: function () {
      var self = this;
      var screenshotIds = [];
      var mediaUploader;

      $(".seo-gen-add-screenshot").on("click", function (e) {
        e.preventDefault();

        if (mediaUploader) {
          mediaUploader.open();
          return;
        }

        mediaUploader = wp.media({
          title: "Select Screenshots",
          button: { text: "Add Screenshots" },
          multiple: true,
          library: { type: "image" },
        });

        mediaUploader.on("select", function () {
          var selection = mediaUploader.state().get("selection");
          var previews = $("#seo-gen-screenshot-previews");

          selection.each(function (attachment) {
            attachment = attachment.toJSON();
            if (
              screenshotIds.indexOf(attachment.id) === -1 &&
              screenshotIds.length < 5
            ) {
              screenshotIds.push(attachment.id);
              previews.append(
                '<div class="screenshot-preview" data-id="' +
                attachment.id +
                '">' +
                '<img src="' +
                attachment.url +
                '" style="max-width:150px;margin:5px;">' +
                '<button type="button" class="button remove-screenshot">×</button>' +
                "</div>"
              );
            }
          });

          $("#screenshot_ids").val(screenshotIds.join(","));
        });

        mediaUploader.open();
      });

      $(document).on("click", ".remove-screenshot", function () {
        var preview = $(this).parent();
        var id = preview.data("id");
        screenshotIds = screenshotIds.filter(function (i) {
          return i != id;
        });
        $("#screenshot_ids").val(screenshotIds.join(","));
        preview.remove();
      });
    },

    // @MODIFIED 2025-12-04 v1.5.0: Partial regen checkbox toggle
    initPartialRegenToggle: function () {
      var $fullArticle = $('input[name="regen_sections[]"][value="all"]');
      var $sectionBoxes = $('input[name="regen_sections[]"]').not(
        '[value="all"]'
      );

      // Initial state: Full Article checked = disable section checkboxes
      $sectionBoxes.prop("disabled", $fullArticle.is(":checked"));

      $fullArticle.on("change", function () {
        if ($(this).is(":checked")) {
          // Full Article checked: uncheck and disable individual sections
          $sectionBoxes.prop("checked", false).prop("disabled", true);
        } else {
          // Full Article unchecked: enable individual sections
          $sectionBoxes.prop("disabled", false);
        }
      });

      // If any section is checked, uncheck Full Article
      $sectionBoxes.on("change", function () {
        if ($sectionBoxes.filter(":checked").length > 0) {
          $fullArticle.prop("checked", false);
        }
      });
    },

    // @since 2.7.3: Post picker for updating existing posts
    initPostPicker: function () {
      var $checkbox = $("#update_post_checkbox");
      var $container = $("#post_search_container");
      var $select = $("#existing_post_select");
      var $hiddenInput = $("#existing_post_id");

      // Toggle container visibility
      $checkbox.on("change", function () {
        if ($(this).is(":checked")) {
          $container.slideDown(200);
          // Initialize Select2 if available
          if ($.fn.select2 && !$select.hasClass("select2-hidden-accessible")) {
            $select.select2({
              // REPLACE the existing 'ajax' object inside initPostPicker with this:
              ajax: {
                url: seoGenData.ajax_url,
                dataType: "json",
                delay: 500, // Increased delay to reduce server load
                data: function (params) {
                  return {
                    action: "seo_gen_search_posts",
                    nonce: seoGenData.nonce,
                    search: params.term,
                    page: params.page || 1 // Send page number
                  };
                },
                processResults: function (data, params) {
                  params.page = params.page || 1;
                  return {
                    results: data.data.results,
                    pagination: {
                      more: data.data.pagination.more // specific field for infinite scroll
                    }
                  };
                },
                cache: true,
              },
              placeholder: "Search posts by title or ID...",
              minimumInputLength: 1,
              allowClear: true,
              width: "100%",
            });
          }
        } else {
          $container.slideUp(200);
          $hiddenInput.val("");
        }
      });

      // Sync selection to hidden input
      $select.on("change", function () {
        var val = $(this).val();
        $hiddenInput.val(val || "");
      });

      // If pre-selected (from URL param), trigger change to sync
      if ($select.val()) {
        $hiddenInput.val($select.val());
      }
    },

    handleSubmit: function (e) {
      e.preventDefault();

      var formData = $("#seo-gen-form").serialize();
      formData += "&action=seo_gen_submit&nonce=" + seoGenData.nonce;

      // Hide form, show progress
      $(".seo-gen-form-section").hide();
      $("#seo-gen-progress").show();

      this.updateStatus("Submitting...", 0);

      $.post(
        seoGenData.ajax_url,
        formData,
        function (response) {
          if (response.success) {
            this.jobId = response.data.job_id;
            this.updateStatus("Generation started...", 10);
            this.startPolling();
          } else {
            this.showError(response.data.message);
          }
        }.bind(this)
      ).fail(
        function () {
          this.showError("Failed to submit request");
        }.bind(this)
      );
    },

    failCount: 0,
    maxFails: 5,
    startTime: null,
    timeout: 1200000, // 5 minutes

    startPolling: function () {
      this.failCount = 0;
      this.startTime = Date.now();
      this.pollInterval = setInterval(
        function () {
          this.checkStatus();
        }.bind(this),
        2000
      ); // Check every 2 seconds
    },

    checkStatus: function () {
      // Check for client-side timeout
      if (Date.now() - this.startTime > this.timeout) {
        this.showError(
          'Operation timed out. Please check the "All Posts" screen to see if the article was created.'
        );
        return;
      }

      $.post(
        seoGenData.ajax_url,
        {
          action: "seo_gen_status",
          nonce: seoGenData.nonce,
          job_id: this.jobId,
        },
        function (response) {
          // Reset fail count on success
          this.failCount = 0;

          if (response.success) {
            var status = response.data.status;

            if (status === "pending") {
              this.updateStatus("Queued for generation...", 5);
            } else if (status === "processing") {
              this.updateStatus(seoGenData.strings.processing, 50);
            } else if (status === "validating") {
              this.updateStatus(seoGenData.strings.validating, 75);
            } else if (status === "completed") {
              clearInterval(this.pollInterval);
              this.updateStatus(seoGenData.strings.completed, 100);
              this.loadPreview();
            } else if (status === "failed") {
              clearInterval(this.pollInterval);
              // @MODIFIED 2026-01-07: Pass debug details if available
              this.showError(
                response.data.error || "Generation failed",
                response.data.debug_details
              );
            }
          } else {
            // Handle logical error from server (e.g. job not found)
            this.handlePollError(
              "Server reported error: " +
              (response.data.message || "Unknown error")
            );
          }
        }.bind(this)
      ).fail(
        function (xhr, status, error) {
          // Handle network error
          console.error("SEO Gen Poll Error:", status, error);
          this.handlePollError("Network error: " + error);
        }.bind(this)
      );
    },

    handlePollError: function (errorMessage) {
      this.failCount++;
      if (this.failCount >= this.maxFails) {
        this.showError("Connection lost. " + errorMessage);
      } else {
        console.warn(
          "Poll failed (" +
          this.failCount +
          "/" +
          this.maxFails +
          "). Retrying..."
        );
      }
    },

    loadPreview: function () {
      $.post(
        seoGenData.ajax_url,
        {
          action: "seo_gen_preview",
          nonce: seoGenData.nonce,
          job_id: this.jobId,
        },
        function (response) {
          if (response.success) {
            this.showPreview(response.data);
          } else {
            this.showError("Failed to load preview");
          }
        }.bind(this)
      );
    },

    showPreview: function (data) {
      var article = data.article;
      var validation = data.validation;

      // Hide progress, show preview
      $("#seo-gen-progress").hide();
      $("#seo-gen-preview").show();

      // @MODIFIED 2026-01-05: Clear previous validation failures to avoid duplicates during regeneration
      $(".seo-gen-validation-failed").remove();

      // @MODIFIED 2025-12-24 v2.6.2: Prominent validation failure warning
      // Show clear alert when validation did NOT pass
      var validationPassed = validation && validation.passed;
      if (!validationPassed) {
        var threshold = validation.threshold || 75;
        var failedHtml =
          '<div class="seo-gen-validation-failed" style="background:#fef2f2;border:2px solid #ef4444;border-radius:6px;padding:15px;margin-bottom:20px;">';
        failedHtml +=
          '<h3 style="color:#dc2626;margin:0 0 10px 0;">⚠️ Validation Failed</h3>';
        failedHtml +=
          '<p style="margin:0;">Article scored <strong>' +
          validation.score +
          "</strong> (threshold: " +
          threshold +
          "). ";
        failedHtml +=
          "This article may need manual improvements before publishing. Review errors and warnings below.</p>";
        failedHtml += "</div>";
        $("#seo-gen-validation").before(failedHtml);
      }

      // Show validation results
      var validationHtml = '<div class="seo-gen-validation-card">';
      validationHtml += "<h3>Validation Results</h3>";
      validationHtml += '<div class="seo-gen-score">';
      validationHtml +=
        '<span class="score-value">' + validation.score + "</span>";
      validationHtml += '<span class="score-label">/100</span>';
      validationHtml += "</div>";

      if (validation.errors && validation.errors.length > 0) {
        validationHtml += '<div class="seo-gen-errors">';
        validationHtml += "<h4>Errors:</h4><ul>";
        validation.errors.forEach(function (error) {
          validationHtml += "<li>" + error + "</li>";
        });
        validationHtml += "</ul></div>";
      }

      if (validation.warnings && validation.warnings.length > 0) {
        validationHtml += '<div class="seo-gen-warnings">';
        validationHtml += "<h4>Warnings:</h4><ul>";
        validation.warnings.forEach(function (warning) {
          validationHtml += "<li>" + warning + "</li>";
        });
        validationHtml += "</ul></div>";
      }

      // @MODIFIED 2025-12-12 v1.8.3: Show failed partial regen sections
      if (validation.failed_sections && validation.failed_sections.length > 0) {
        validationHtml +=
          '<div class="seo-gen-partial-failed" style="background:#fef3cd;border:1px solid #ffc107;border-radius:4px;padding:10px;margin-top:10px;">';
        validationHtml += "<strong>⚠️ Partial Regeneration Notice:</strong> ";
        validationHtml +=
          "The following sections returned empty/invalid and were NOT updated: ";
        validationHtml +=
          "<strong>" + validation.failed_sections.join(", ") + "</strong>. ";
        validationHtml += "Original content was preserved.";
        validationHtml += "</div>";
      }

      validationHtml += "</div>";
      $("#seo-gen-validation").html(validationHtml);

      // Show article content
      var contentHtml = '<div class="seo-gen-article">';
      contentHtml += "<h1>" + article.title + "</h1>";
      contentHtml += '<div class="seo-gen-meta">';
      contentHtml +=
        "<p><strong>Meta Description:</strong> " +
        article.meta_description +
        "</p>";
      contentHtml +=
        "<p><strong>Focus Keyword:</strong> " + article.focus_keyword + "</p>";
      contentHtml += "</div>";
      contentHtml +=
        '<div class="seo-gen-body">' + data.html_content + "</div>";
      contentHtml += "</div>";

      $("#seo-gen-content").html(contentHtml);

      // Store data for publishing and raw HTML for copying
      $("#seo-gen-preview").data("article", article);
      $("#seo-gen-preview").data("raw_html", data.html_content);

      // @MODIFIED 2026-01-05: Store debug data
      $("#seo-gen-preview").data("raw_prompt", data.raw_prompt);
      $("#seo-gen-preview").data("raw_response", data.raw_response);

      // Hide debug panel on new data
      $("#seo-gen-debug-panel").hide();

      // @MODIFIED 2025-12-16 v2.2.2: Truth Validator Modal Integration
      if (data.validation_modal && data.validation_modal.length > 0) {
        // Remove existing modal if any to prevent duplicates
        $("#validation-warning-modal").remove();

        // Append new modal (it will be visible immediately via its CSS)
        $("body").append(data.validation_modal);
      }
    },

    // @MODIFIED 2025-12-13 v2.0.2: Updated to handle warnings and use inline notices
    handlePublish: function () {
      var self = this;
      var article = $("#seo-gen-preview").data("article");

      if (!article) {
        this.showErrorBanner("No article data available");
        return;
      }

      var postId = $("#existing_post_id").val();
      var button = $("#seo-gen-publish");
      var originalText = postId > 0 ? "Update Post" : "Save as Draft";

      button
        .prop("disabled", true)
        .text(postId > 0 ? "Updating..." : "Publishing...");

      $.post(
        seoGenData.ajax_url,
        {
          action: "seo_gen_publish",
          nonce: seoGenData.nonce,
          job_id: this.jobId,
          title: article.title,
          content: article.html_content,
          existing_post_id: postId,
        },
        function (response) {
          if (response.success) {
            // @MODIFIED 2025-12-13 v2.0.2: Show inline success with warnings if any
            self.showSuccessBanner("Article saved as draft!");

            if (response.data.warnings && response.data.warnings.length > 0) {
              self.showWarningBanner(response.data.warnings);
            }

            // Open post editor in new window
            window.open(response.data.edit_url, "_blank");
          } else {
            self.showErrorBanner("Failed to publish: " + response.data.message);
            button.prop("disabled", false).text("Save as Draft");
          }
        }
      ).fail(function (xhr, status, error) {
        // @MODIFIED 2026-01-16: Handle network errors to prevent stuck button
        console.error("Publish failed:", status, error);
        self.showErrorBanner("Network error during publish: " + error + ". Please try again.");
        button.prop("disabled", false).text(originalText);
      });
    },

    // @MODIFIED 2025-12-26 v2.7.2: Background Schema Sync for existing posts
    handleCopyHtml: function () {
      var rawHtml = $("#seo-gen-preview").data("raw_html");
      var self = this;
      var button = $("#seo-gen-copy-html");
      var originalText = button.text();

      if (!rawHtml) {
        this.showErrorBanner("No HTML content available to copy");
        return;
      }

      var postId = $("#existing_post_id").val();
      if (postId > 0 && this.jobId) {
        button.text("Syncing Schema...");
        $.post(seoGenData.ajax_url, {
          action: "seo_gen_sync_meta",
          nonce: seoGenData.nonce,
          job_id: this.jobId,
          post_id: postId,
        }).always(function () {
          // Proceed with copy status regardless of sync result
          self.doCopy(rawHtml, button, originalText, true);
        });
      } else {
        this.doCopy(rawHtml, button, originalText, false);
      }
    },

    // Extracted copy logic for reuse
    doCopy: function (text, button, originalText, synced) {
      var self = this;
      var successText = synced ? "✓ HTML Copied & Schema Synced!" : "✓ Copied!";

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard
          .writeText(text)
          .then(function () {
            button.text(successText);
            setTimeout(function () {
              button.text(originalText);
            }, 3000);
          })
          .catch(function (err) {
            console.error("Copy failed:", err);
            self.fallbackCopy(text, button, originalText);
          });
      } else {
        this.fallbackCopy(text, button, originalText);
      }
    },

    // Fallback copy method for browsers without Clipboard API
    fallbackCopy: function (text, button, originalText) {
      var textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();

      try {
        var success = document.execCommand("copy");
        if (success) {
          button.text("✓ Copied!");
          setTimeout(function () {
            button.text(originalText);
          }, 2000);
        } else {
          this.showErrorBanner(
            "Copy failed. Please manually select and copy the content."
          );
        }
      } catch (err) {
        this.showErrorBanner("Copy not supported in this browser.");
      }

      document.body.removeChild(textarea);
    },

    handleReset: function () {
      if (confirm("Generate a new article? Current preview will be lost.")) {
        location.reload();
      }
    },

    updateStatus: function (message, progress) {
      $(".seo-gen-status-text").text(message);
      $(".seo-gen-progress-fill").css("width", progress + "%");
    },

    // @MODIFIED 2025-12-13 v2.0.2: Replaced alert() with inline notices
    // @MODIFIED 2026-01-07: Added debugDetails param support
    showError: function (message, debugDetails) {
      clearInterval(this.pollInterval);
      $("#seo-gen-progress").hide();
      $(".seo-gen-form-section").show();

      var actionBtnsHtml = "";
      if (this.jobId) {
        actionBtnsHtml +=
          ' <button type="button" class="button" id="seo-gen-retry">Retry Generation</button>';
      }

      // @MODIFIED 2026-01-07: Add Copy Diagnostics button
      if (debugDetails) {
        actionBtnsHtml +=
          ' <button type="button" class="button button-link" id="seo-gen-copy-debug" style="margin-left: 10px; color: #b32d2e;">Copy Diagnostics</button>';
      }

      this.showErrorBanner(message + actionBtnsHtml);

      // Bind retry button
      var self = this;
      $("#seo-gen-retry")
        .off("click")
        .on("click", function () {
          $("#seo-gen-notice-area").empty();
          $("#seo-gen-form").submit();
        });

      // Bind copy debug button
      if (debugDetails) {
        $("#seo-gen-copy-debug").on("click", function (e) {
          e.preventDefault();
          var $btn = $(this);
          var content = "";

          if (typeof debugDetails === "object") {
            content = JSON.stringify(debugDetails, null, 2);
          } else {
            content = debugDetails;
          }

          var $temp = $("<textarea>");
          $("body").append($temp);
          $temp.val(content).select();
          try {
            document.execCommand("copy");
            $btn.text("Copied!");
            setTimeout(function () {
              $btn.text("Copy Diagnostics");
            }, 2000);
          } catch (err) {
            console.error("Copy failed", err);
            prompt("Diagnostics:", content);
          }
          $temp.remove();
        });
      }
    },

    // @MODIFIED 2025-12-13 v2.0.2: Inline notice helpers
    showErrorBanner: function (message) {
      var $notice = this.getNoticeArea();
      $notice.html(
        '<div class="notice notice-error"><p><strong>Error:</strong> ' +
        message +
        "</p></div>"
      );
    },

    showWarningBanner: function (warnings) {
      var $notice = this.getNoticeArea();
      var html =
        '<div class="notice notice-warning"><p><strong>⚠️ Warnings:</strong></p><ul>';
      warnings.forEach(function (w) {
        html += "<li>" + w + "</li>";
      });
      html += "</ul></div>";
      $notice.append(html);
    },

    showSuccessBanner: function (message) {
      var $notice = this.getNoticeArea();
      $notice.html(
        '<div class="notice notice-success"><p>' + message + "</p></div>"
      );
    },

    getNoticeArea: function () {
      var $notice = $("#seo-gen-notice-area");
      if (!$notice.length) {
        $notice = $(
          '<div id="seo-gen-notice-area" style="margin: 10px 0;"></div>'
        ).insertBefore("#seo-gen-form");
      }
      return $notice;
    },

    // @MODIFIED 2026-01-05: Debug Handlers
    handleViewRequest: function () {
      var data = $("#seo-gen-preview").data("raw_prompt");
      this.showDebugPanel("Raw AI Request", data || "No request data recorded.");
    },

    handleViewResponse: function () {
      var data = $("#seo-gen-preview").data("raw_response");
      this.showDebugPanel("Raw AI Response", data || "No response data recorded.");
    },

    showDebugPanel: function (title, content) {
      $("#debug-panel-title").text(title);
      $("#debug-content").text(content);
      $("#seo-gen-debug-panel").slideDown();

      // Scroll to debug panel
      $("html, body").animate(
        {
          scrollTop: $("#seo-gen-debug-panel").offset().top - 50,
        },
        500
      );
    },

    handleCopyDebug: function () {
      var content = $("#debug-content").text();
      var $temp = $("<textarea>");
      $("body").append($temp);
      $temp.val(content).select();
      document.execCommand("copy");
      $temp.remove();

      var $btn = $(".debug-copy-btn");
      var originalText = $btn.text();
      $btn.text("Copied!").css("background", "#46b450");
      setTimeout(function () {
        $btn.text(originalText).css("background", "#007cba");
      }, 2000);
    },
  };

  $(document).ready(function () {
    SEOGenerator.init();
  });
})(jQuery);
