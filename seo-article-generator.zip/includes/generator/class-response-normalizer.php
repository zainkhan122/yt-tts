<?php

/**
 * Response Normalizer
 *
 * @package SEO_Article_Generator\Generator
 * @since 2.20.0
 * @MODIFIED 2026-03-03: Created as part of lean industrial refactor
 */

namespace SEO_Article_Generator\Generator;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Post-processes AI responses to ensure consistent output regardless of provider.
 *
 * Handles:
 * - Missing optional sections (fills with empty defaults)
 * - Type coercion (strings that should be arrays, etc.)
 * - Field normalization (different providers use different key names)
 * - Citation stripping (Gemini's [1] markers, Perplexity's inline refs)
 * - JSON cleaning (strips markdown blocks, leading/trailing fluff)
 */
class Response_Normalizer
{
    /**
      * Normalize an AI provider response into canonical article structure.
      *
      * @param array              $raw_response Raw provider output
      * @param Generation_Context $context      The generation context
      * @return array Normalized article data
      */
    public static function normalize(array $raw_response, Generation_Context $context): array
    {
        $data = $raw_response;

        // ── 0. Handle potential double-encoded or "dirty" JSON ──
        if (isset($data['json_content']) && is_string($data['json_content'])) {
            $cleaned = self::clean_json_string($data['json_content']);
            $decoded = json_decode($cleaned, true);
            if (is_array($decoded)) {
                $data = array_merge($data, $decoded);
                unset($data['json_content']);
            }
        }

        // ── 1. Fix introduction type (string → array) ──
        if (isset($data['introduction']) && is_string($data['introduction'])) {
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->info('Normalizer: Fixed introduction type (string to array)');
            }
            $data['introduction'] = array($data['introduction']);
        }
        if (empty($data['introduction'])) {
            $data['introduction'] = array();
        }

        // ── 2. Tech specs defaults ──
        $data['tech_specs'] = array_merge(
            array(
                'software_name'        => '',
                'application_category' => '',
                'version'              => '',
                'license'              => '',
                'developer'            => '',
                'homepage'             => '',
                'changelogurl'         => '',
                'file_size'            => '',
                'os_support'           => '',
                'language_support'     => '',
                'last_updated'         => '',
            ),
            $data['tech_specs'] ?? array()
        );

        // ── 3. Optional section defaults ──
        // @MODIFIED 2026-05-20: download_section removed — AI no longer generates it.
        $optional_sections = array(
            'pros_cons'          => array('pros' => array(), 'cons' => array()),
            'features'           => array(),
            'whats_new'          => array(),
            'faqs'               => array(),
            'installation_guide' => array('steps' => array(), 'compatibility_notes' => '', 'common_issues' => array()),
            'moat_data'          => array('content' => array()),
            'hero_section'       => array(),
            'video_url'          => '',
            'related_software'   => array(),
            'introduction'       => array(),
        );

        // ── 2b. Extract [embed] video URLs from text fields BEFORE backfilling ──
        if (empty($data['video_url'])) {
            $text_fields = array('introduction', 'html_content', 'conclusion');
            foreach ($text_fields as $field) {
                if (!empty($data[$field])) {
                    $subject = is_array($data[$field]) ? implode("\n", $data[$field]) : $data[$field];
                    if (preg_match('/\[embed\](.*?)\[\/embed\]/i', $subject, $matches)) {
                        $data['video_url'] = trim($matches[1]);
                        // Strip it from the field to avoid duplicate video rendering (RankMath / Native split)
                        if (is_array($data[$field])) {
                            foreach ($data[$field] as &$str) {
                                $str = preg_replace('/\[embed\].*?\[\/embed\]/i', '', $str);
                            }
                            unset($str);
                        } else {
                            $data[$field] = preg_replace('/\[embed\].*?\[\/embed\]/i', '', $data[$field]);
                        }
                        $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                        if ($logger) {
                            $logger->info('Normalizer: Extracted video_url from [embed] shortcode in ' . $field);
                        }
                        break;
                    }
                }
            }
        }

        foreach ($optional_sections as $key => $default) {
            if (!isset($data[$key])) {
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info(sprintf('Normalizer: Backfilled missing section [%s]', $key));
                }
                $data[$key] = $default;
            }
        }

        // ── 3b. Repair moat_data schema if AI returned a flat array or missing content key ──
        if (isset($data['moat_data']) && is_array($data['moat_data'])) {
            $moat = $data['moat_data'];
            // Case A: AI returned flat indexed array of strings/items — wrap into {content:[...]}
            if (!isset($moat['content']) && !empty($moat) && array_keys($moat) === range(0, count($moat) - 1)) {
                $data['moat_data'] = array('content' => $moat);
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info('Normalizer: Repaired flat moat_data into {content:[...]} structure');
                }
            }
            // Case A.2: AI returned nested moat block { moat: { content: [...] } }
            elseif (isset($moat['moat']['content']) && is_array($moat['moat']['content'])) {
                $data['moat_data'] = array('content' => $moat['moat']['content']);
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info('Normalizer: Unwrapped nested moat_data.moat.content structure');
                }
            }
            // Case A.3: AI returned {heading, steps} instead of {heading, content} — remap steps → content
            elseif (!isset($moat['content']) && isset($moat['steps']) && is_array($moat['steps'])) {
                $data['moat_data'] = array('heading' => $moat['heading'] ?? '', 'content' => $moat['steps']);
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info('Normalizer: Remapped moat_data.steps → moat_data.content');
                }
            }
            // Case B: content key exists but is a string — wrap it in array
            if (isset($data['moat_data']['content']) && is_string($data['moat_data']['content'])) {
                $data['moat_data']['content'] = array($data['moat_data']['content']);
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info('Normalizer: Repaired string moat_data[content] into array');
                }
            }
        }

        // ── 4. String field defaults ──
        $string_defaults = array(
            'title'            => '',
            'meta_description' => '',
            'slug'             => '',
            'focus_keyword'    => '',
            'category'         => '',
            // @MODIFIED 2026-05-05: Ensure these fields always exist in the article contract
            // regardless of generation mode (new post search-mode vs upgrade provided-mode).
            // Upgrade-mode AI returns them; new-post search-mode AI may omit them, leaving
            // the hero block and tech specs table with missing display data.
            'license_details'  => '',
            'security_badge'   => '',
            'rating'           => '',
            'last_verified_date' => '',
        );

        foreach ($string_defaults as $key => $default) {
            if (!isset($data[$key]) || !is_string($data[$key])) {
                $data[$key] = $default;
            } else {
                // Strip markdown formatting from top-level plain text SEO fields
                if (in_array($key, array('title', 'meta_description', 'focus_keyword', 'slug'), true)) {
                    $data[$key] = self::strip_markdown($data[$key]);
                }
            }
        }

        // ── 6. Array field defaults ──
        $array_defaults = array(
            'long_tail_keywords' => array(),
            'lsi_keywords'       => array(),
        );

        foreach ($array_defaults as $key => $default) {
            if (!isset($data[$key]) || !is_array($data[$key])) {
                $data[$key] = $default;
            }
        }

        // ── 6b. SEO FIX: Anti-Robotic Keyword Stuffing Scrubber for FAQs ──
        if (!empty($data['faqs']) && !empty($data['focus_keyword'])) {
            $keyword = (string) $data['focus_keyword'];
            $keyword_pattern = '/\b' . preg_quote($keyword, '/') . '\b/i';
            
            foreach ($data['faqs'] as &$faq) {
                if (isset($faq['answer'])) {
                    $answer = (string) $faq['answer'];
                    
                    if (preg_match($keyword_pattern, $answer)) {
                        $answer = preg_replace($keyword_pattern, '{{PROTECTED_KW}}', $answer, 1);
                        
                        $replacements = array('it', 'the software', 'this application');
                        $answer = preg_replace_callback($keyword_pattern, function() use ($replacements) {
                            return $replacements[array_rand($replacements)];
                        }, $answer);
                        
                        $faq['answer'] = str_replace('{{PROTECTED_KW}}', $keyword, $answer);
                    }
                }
            }
            unset($faq);
        }

        // ── 7. Strip citation markers from ALL string values ──
        $data = self::strip_citations_recursive($data);

        // ── 8. Normalize download links ──
        self::normalize_download_links($data);

        // ── 8b. Verify Video URL exists via oEmbed ──
        if (!empty($data['video_url']) && is_string($data['video_url'])) {
            if (!self::verify_youtube_video_exists($data['video_url'])) {
                $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
                if ($logger) {
                    $logger->info('Normalizer: Stripped hallucinated/broken video URL: ' . $data['video_url']);
                }
                $data['video_url'] = ''; 
            }
        }

        // ── 9. Attach prompt version from context ──
        // ── 10. Final step before returning normalized article data ──
        $data['hero_section']     = $data['hero_section'] ?? ($data['herosection'] ?? array());
        $data['tech_specs']       = $data['tech_specs'] ?? ($data['techspecs'] ?? array());

        unset($data['herosection'], $data['techspecs']);

        $data['_prompt_version'] = $context->prompt_version;

        return $data;
    }

    /**
     * Normalizes AI-generated download links to prevent downstream validation failures.
     *
     * @param array $data The article data array, passed by reference.
     */
    public static function normalize_download_links(array &$data)
    {
        if (!isset($data['download_section']['links']) || !is_array($data['download_section']['links'])) return;
        $data['download_section']['links'] = Download_Link_Helper::normalize_links($data['download_section']['links'], 'Other');
        $data['_canonical_download_links'] = $data['download_section']['links'];
    }

    /**
     * Recursively strip citation markers like [1], [2] etc from all strings.
     *
     * @param mixed $value
     * @return mixed
     */
    private static function strip_citations_recursive($value)
    {
        if (is_string($value)) {
            // Remove [1], [2], etc. citation markers
            return preg_replace('/\[\d+\]/', '', $value);
        }

        if (is_array($value)) {
            foreach ($value as $k => &$v) {
                $v = self::strip_citations_recursive($v);
            }
            unset($v);
        }

        return $value;
    }

    /**
     * Strip basic markdown formatting (bold, italic, backticks, links) to produce clean plain text.
     *
     * @param mixed $text
     * @return string
     */
    public static function strip_markdown($text): string
    {
        if (!is_string($text)) {
            return '';
        }

        // 1. Convert markdown links [link text](url) to plain "link text"
        $text = preg_replace('/\[([^\]]+)\]\([^)]+\)/', '$1', $text);

        // 2. Strip bold asterisks **bold** -> bold
        $text = preg_replace('/\*\*(.*?)\*\*/', '$1', $text);

        // 3. Strip italic asterisks *italic* -> italic (avoiding stripping of list bullet points or single asterisks)
        $text = preg_replace('/(?<!\*)\*(?![*\s])(.+?)(?<!\s)\*(?!\*)/', '$1', $text);

        // 4. Strip backticks `code` -> code
        $text = preg_replace('/`([^`]+)`/', '$1', $text);

        // 5. Clean up any remaining double spaces
        $text = preg_replace('/\s+/', ' ', $text);

        return trim($text);
    }

    /**
     * Strips Markdown blocks and fluff from AI JSON strings.
     *
     * @param string $json
     * @return string
     */
    private static function clean_json_string($json)
    {
        if (!is_string($json)) {
            return $json;
        }

        $json = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $json);

        if (function_exists('mb_convert_encoding')) {
            $json = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
        }

        $json = preg_replace('/[\xEF\xBB\xBF]/u', '', $json);

        $json = preg_replace('/^```(?:json)?/m', '', $json);
        $json = preg_replace('/```$/m', '', $json);

        $start = strpos($json, '{');
        $end = strrpos($json, '}');

        if ($start !== false && $end !== false) {
            $json = substr($json, $start, $end - $start + 1);
        }

        return trim($json);
    }

    /**
     * Safely ping YouTube's oEmbed API to verify the hallucinated video actually exists.
     *
     * @param string $video_url The URL provided by the AI.
     * @return bool True if real, False if hallucinated or broken.
     */
    private static function verify_youtube_video_exists($video_url)
    {
        if (empty($video_url) || !is_string($video_url)) {
            return false;
        }

        // @MODIFIED 2026-08-24: Provider-aware oEmbed verification.
        // Previously ANY non-YouTube URL (Vimeo/Dailymotion) returned false and
        // was silently stripped, contradicting both the AI prompt ("YouTube/Vimeo
        // link") and Content_Formatter::format_video_embed() which renders
        // youtube/vimeo/dailymotion embeds. Each provider is now verified against
        // its own oEmbed endpoint.
        $host = strtolower((string) \wp_parse_url($video_url, PHP_URL_HOST));
        $host = preg_replace('/^www\./', '', $host);

        if ($host === 'youtube.com' || $host === 'youtube-nocookie.com'
            || substr($host, -12) === '.youtube.com' || $host === 'youtu.be') {
            $oembed_api_url = 'https://www.youtube.com/oembed?url=' . urlencode($video_url) . '&format=json';
        } elseif ($host === 'vimeo.com' || substr($host, -10) === '.vimeo.com') {
            $oembed_api_url = 'https://vimeo.com/api/oembed.json?url=' . urlencode($video_url);
        } elseif ($host === 'dailymotion.com' || substr($host, -17) === '.dailymotion.com') {
            $oembed_api_url = 'https://www.dailymotion.com/services/oembed?url=' . urlencode($video_url) . '&format=json';
        } else {
            return false;
        }

        $response = \wp_remote_get($oembed_api_url, array(
            'timeout'     => 3, // Strict 3-second timeout for background queue safety
            'redirection' => 1,
        ));

        if (\is_wp_error($response)) {
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->warning('Normalizer: YouTube oEmbed check network failure for URL: ' . $video_url);
            }
            return false; // Drop on network error to protect the frontend
        }

        $status_code = \wp_remote_retrieve_response_code($response);

        // 200 means YouTube confirms the video is real and embeddable.
        return ($status_code === 200);
    }
}
