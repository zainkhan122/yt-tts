<?php

/**
 * Admin Diagnostic / Smoke Tester
 *
 * @package SEO_Article_Generator\Admin
 * @MODIFIED 2026-03-27: Final Hardening for SEO Pipeline Architecture
 */

namespace SEO_Article_Generator\Admin;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Smoke Tester Class
 * 
 * Comprehensive diagnostic system covering:
 * - PHP syntax validation
 * - Database schema integrity
 * - File integrity
 * - Hook registrations
 * - Class/method existence
 * - Renderer functionality
 * - AJAX endpoints
 * - Asset availability
 * - WordPress compatibility
 * - Content pipeline
 * - AI Update Logic
 * - Code Integrity
 * - Job Runtime Contracts
 * - Hero Meta Round Trip
 */
class Smoke_Tester
{
    /**
     * Init hooks
     */
    public static function init()
    {
        add_action('admin_menu', array(__CLASS__, 'register_page'));
    }

    /**
     * Register hidden diagnostic page
     */
    public static function register_page()
    {
        add_submenu_page(
            null, // Hidden page
            'SEO Gen Smoke Test',
            'SEO Gen Smoke Test',
            'manage_options',
            'seogen-smoke-test',
            array(__CLASS__, 'render_page')
        );
    }

    /**
     * Run comprehensive smoke test
     * 
     * @MODIFIED 2026-03-27: Enhanced with Job Runtime and Hero Meta gates
     * @return array Test results with categories and detailed errors
     */
    public static function run_smoke_test()
    {
        $start_time = microtime(true);
        $results = array();

        // 1. PHP Syntax Validation
        $syntax_start = microtime(true);
        $results['syntax'] = self::test_php_syntax();
        $results['syntax']['duration'] = round((microtime(true) - $syntax_start) * 1000, 2);

        // 2. Database Schema
        $db_start = microtime(true);
        $results['database'] = self::test_database_schema();
        $results['database']['duration'] = round((microtime(true) - $db_start) * 1000, 2);

        // 3. File Integrity
        $files_start = microtime(true);
        $results['files'] = self::test_file_integrity();
        $results['files']['duration'] = round((microtime(true) - $files_start) * 1000, 2);

        // 4. Hook Registrations
        $hooks_start = microtime(true);
        $results['hooks'] = self::test_hook_registrations();
        $results['hooks']['duration'] = round((microtime(true) - $hooks_start) * 1000, 2);

        // 5. Class & Method Existence
        $classes_start = microtime(true);
        $results['classes'] = self::test_class_methods();
        $results['classes']['duration'] = round((microtime(true) - $classes_start) * 1000, 2);

        // 6. Renderer Functionality
        $renderers_start = microtime(true);
        $results['renderers'] = self::test_renderers();
        $results['renderers']['duration'] = round((microtime(true) - $renderers_start) * 1000, 2);

        // 7. AJAX Endpoints
        $ajax_start = microtime(true);
        $results['ajax'] = self::test_ajax_endpoints();
        $results['ajax']['duration'] = round((microtime(true) - $ajax_start) * 1000, 2);

        // 8. Asset Files
        $assets_start = microtime(true);
        $results['assets'] = self::test_asset_files();
        $results['assets']['duration'] = round((microtime(true) - $assets_start) * 1000, 2);

        // 9. WordPress Compatibility
        $compat_start = microtime(true);
        $results['compatibility'] = self::test_wordpress_compatibility();
        $results['compatibility']['duration'] = round((microtime(true) - $compat_start) * 1000, 2);

        // 10. Content Pipeline (Deterministic)
        $pipeline_start = microtime(true);
        $results['content_pipeline'] = self::test_content_pipeline();
        $results['content_pipeline']['duration'] = round((microtime(true) - $pipeline_start) * 1000, 2);

        // 11. AI Update Logic & Integrity (NEW 2026-03-12)
        $ai_update_start = microtime(true);
        $results['ai_update_integrity'] = self::test_ai_update_logic();
        $results['ai_update_integrity']['duration'] = round((microtime(true) - $ai_update_start) * 1000, 2);

        // 12. Comparison Contracts
        $contracts_start = microtime(true);
        $results['comparison_contracts'] = self::test_comparison_contracts();
        $results['comparison_contracts']['duration'] = round((microtime(true) - $contracts_start) * 1000, 2);

        // 13. Job Runtime Contracts (NEW 2026-03-27)
        $job_runtime_start = microtime(true);
        $results['job_runtime_contracts'] = self::test_job_runtime_contracts();
        $results['job_runtime_contracts']['duration'] = round((microtime(true) - $job_runtime_start) * 1000, 2);

        // 14. Hero Meta Round Trip (NEW 2026-03-27)
        $hero_meta_start = microtime(true);
        $results['hero_meta_round_trip'] = self::test_hero_meta_round_trip();
        $results['hero_meta_round_trip']['duration'] = round((microtime(true) - $hero_meta_start) * 1000, 2);

        // 15. Reconcile Failed Recovery Contracts
        $reconcile_start = microtime(true);
        $results['reconcile_failed_contracts'] = self::test_reconcile_failed_contracts();
        $results['reconcile_failed_contracts']['duration'] = round((microtime(true) - $reconcile_start) * 1000, 2);

        // 16. Installation/Troubleshooting Renderer Contracts
        $installation_start = microtime(true);
        $results['installation_contracts'] = self::test_installation_contracts();
        $results['installation_contracts']['duration'] = round((microtime(true) - $installation_start) * 1000, 2);

        // 17. Dashboard Contract Runtime (NEW 2026-04-02)
        $dashboard_start = microtime(true);
        $results['dashboard_contract_runtime'] = self::test_dashboard_contract_runtime();
        $results['dashboard_contract_runtime']['duration'] = round((microtime(true) - $dashboard_start) * 1000, 2);

        // Calculate totals
        $total_duration = round((microtime(true) - $start_time) * 1000, 2);
        $total_tests = 0;
        $total_passed = 0;
        $total_failed = 0;

        foreach ($results as $category => $data) {
            $total_tests += $data['total'];
            $total_passed += $data['passed'];
            $total_failed += $data['failed'];
        }

        return array(
            'categories' => $results,
            'summary' => array(
                'total' => $total_tests,
                'passed' => $total_passed,
                'failed' => $total_failed,
                'duration' => $total_duration,
            ),
        );
    }

    private static function get_php_binary(): string
    {
        if (defined('PHP_BINARY') && PHP_BINARY) {
            $bin = PHP_BINARY;
            if (strpos($bin, 'php-fpm') !== false) {
                $bin = str_replace('php-fpm', 'php', $bin);
            }
            return $bin;
        }

        $windows_paths = array(
            'C:\xampp\php\php.exe',
            'C:\wamp64\bin\php\php8.3.0\php.exe',
            'C:\php\php.exe',
        );

        $linux_paths = array(
            '/usr/bin/php',
            '/usr/local/bin/php',
            '/opt/cpanel/ea-php*/root/usr/bin/php',
            '/opt/php*/bin/php',
        );

        foreach ($windows_paths as $path) {
            if (file_exists($path)) {
                return $path;
            }
        }

        foreach ($linux_paths as $path) {
            if (strpos($path, '*') !== false) {
                $pattern = str_replace(array('/', '*'), array('\/', '[^/]+'), $path);
                $dir = dirname($path);
                if (is_dir($dir)) {
                    $files = glob($dir . '/php*');
                    if (!empty($files) && file_exists($files[0])) {
                        return $files[0];
                    }
                }
            } elseif (file_exists($path)) {
                return $path;
            }
        }

        return 'php';
    }

    /**
     * Test PHP syntax across all plugin files
     */
    private static function test_php_syntax()
    {
        $checks = array();
        $errors = array();

        if (!function_exists('exec')) {
            return array('total' => 1, 'passed' => 0, 'failed' => 0, 'checks' => array('exec() check' => false), 'errors' => array(array('test' => 'exec()', 'error' => 'exec() disabled', 'suggestion' => 'Enable exec() or skip this test')), 'skipped' => true);
        }

        $php_bin = self::get_php_binary();
        $test_output = array();
        $test_return = 0;
        @exec($php_bin . ' -v 2>&1', $test_output, $test_return);

        if ($test_return !== 0 && empty($test_output)) {
            return array('total' => 1, 'passed' => 0, 'failed' => 0, 'checks' => array('PHP binary check' => false), 'errors' => array(array('test' => 'php', 'error' => 'PHP binary not found or not executable', 'suggestion' => 'Skip PHP syntax check on this server')), 'skipped' => true);
        }

        $start_time = microtime(true);
        $time_limit = 45;
        $php_files = self::get_all_php_files(SEO_GEN_PLUGIN_DIR);
        
        foreach ($php_files as $file) {
            if ((microtime(true) - $start_time) > $time_limit) {
                $errors[] = array('test' => 'Syntax Check Time Limit', 'error' => 'Syntax validation exceeded time limit. Skipping remaining files.', 'suggestion' => 'Consider excluding more directories or increasing server timeout settings.');
                break;
            }
            
            $output = array();
            $return_var = 0;
            @exec($php_bin . ' -l ' . escapeshellarg($file) . ' 2>&1', $output, $return_var);
            $label = str_replace(SEO_GEN_PLUGIN_DIR, '', $file);
            $passed = ($return_var === 0);
            $checks[$label] = $passed;
            if (!$passed) {
                $errors[] = array('file' => $label, 'error' => implode("\n", $output), 'suggestion' => 'Fix syntax error');
            }
        }

        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors, 'skipped' => false);
    }

    /**
     * Test database schema integrity
     */
    private static function test_database_schema()
    {
        global $wpdb;
        $checks = array();
        $errors = array();

        $required_tables = array(
            'jobs' => \SEO_Article_Generator\Installer::table_jobs(),
            'queue' => \SEO_Article_Generator\Installer::table_queue(),
            'links' => \SEO_Article_Generator\Installer::table_links(),
            'discovery' => \SEO_Article_Generator\Installer::table_discovery(),
            'locks' => \SEO_Article_Generator\Installer::table_locks(),
        );

        $all_present = true;
        foreach ($required_tables as $label => $table) {
            $exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($table))) === $table);
            $checks["Table '$label' exists"] = $exists;
            if (!$exists) {
                $all_present = false;
                $errors[] = array('test' => "Table existence: $label", 'error' => "Table $table missing", 'suggestion' => 'Reactivate plugin to trigger table creation');
            }
        }

        if ($all_present) {
            $schema_ok = \SEO_Article_Generator\Installer::is_schema_healthy();
            $checks['Column & index integrity'] = $schema_ok;
            if (!$schema_ok) {
                $detail = (string) get_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR, '');
                $errors[] = array(
                    'test' => 'Column & index integrity',
                    'error' => $detail ?: 'Schema columns or indexes are missing. Check error_log for details.',
                    'suggestion' => 'Deactivate and reactivate the plugin to run schema migrations'
                );
            }
        }

        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test file integrity
     */
    private static function test_file_integrity()
    {
        $checks = array();
        $errors = array();
        $critical_files = array(
            'Plugin class' => SEO_GEN_PLUGIN_DIR . 'includes/class-plugin.php',
            'Publish Payload Builder' => SEO_GEN_PLUGIN_DIR . 'includes/publishing/class-publish-payload-builder.php',
            'AI Client' => SEO_GEN_PLUGIN_DIR . 'includes/ai/class-ai-client.php',
            'Job Handler' => SEO_GEN_PLUGIN_DIR . 'includes/jobs/class-job-handler.php',
            'Provider Registry' => SEO_GEN_PLUGIN_DIR . 'includes/ai/class-provider-registry.php',
            'Custom Provider' => SEO_GEN_PLUGIN_DIR . 'includes/ai/providers/class-custom-provider.php',
        );
        foreach ($critical_files as $name => $path) {
            $exists = file_exists($path);
            $checks["$name exists"] = $exists;
            if (!$exists) {
                $errors[] = array('file' => $name, 'error' => "File missing: $path", 'suggestion' => 'Reinstall plugin');
            }
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test hook registrations
     */
    private static function test_hook_registrations()
    {
        $checks = array();
        $errors = array();
        $hooks = array('wp_ajax_seo_gen_submit_rating', 'wp_ajax_seo_gen_run_smoke_test');
        $filters = array('seo_gen_register_custom_providers', 'seo_gen_custom_provider_request_body');
        foreach ($hooks as $hook) {
            $registered = (has_action($hook) !== false);
            $checks["Hook: $hook"] = $registered;
            if (!$registered) {
                $errors[] = array('test' => "Hook: $hook", 'error' => "Hook not registered", 'suggestion' => 'Check Plugin::init()');
            }
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test class and method existence
     */
    private static function test_class_methods()
    {
        $checks = array();
        $errors = array();
        $classes = array(
            'SEO_Article_Generator\Plugin' => array('get_instance', 'get_hero_data', 'write_hero_data'),
            'SEO_Article_Generator\Discovery\Post_Type_Classifier' => array('classify', 'is_plugin_owned'),
            'SEO_Article_Generator\Discovery\Discovery_Processor' => array('process_item_background', 'write_post_meta'),
            'SEO_Article_Generator\AI\Provider_Fallback_Manager' => array('get_primary_provider', 'get_provider_state'),
            'SEO_Article_Generator\AI\AI_Client' => array('generate_article'),
            'SEO_Article_Generator\Jobs\Job_Handler' => array('process_job'),
            'SEO_Article_Generator\AI\Provider_Registry' => array('get_instance', 'get_all_ids', 'is_custom', 'get_provider_class', 'get_custom_profile', 'get_custom_providers', 'save_custom_providers', 'validate_custom_profile'),
            'SEO_Article_Generator\AI\Providers\Custom_Provider' => array('generate_article', 'test_connection'),
        );
        foreach ($classes as $class => $methods) {
            $checks["Class: $class"] = class_exists($class);
            if (!class_exists($class)) {
                $errors[] = array('test' => "Class: $class", 'error' => "Class missing", 'suggestion' => 'Check autoloader');
                continue;
            }
            foreach ($methods as $method) {
                $checks["Method: $class::$method"] = method_exists($class, $method);
                if (!method_exists($class, $method)) {
                    $errors[] = array('test' => "Method: $class::$method", 'error' => "Method missing", 'suggestion' => 'Check for renames');
                }
            }
        }
        foreach ($filters as $filter) {
            $checks["Filter: $filter"] = true;
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test renderer functionality
     */
    private static function test_renderers()
    {
        $checks = array();
        $errors = array();

        try {
            $formatter = new \SEO_Article_Generator\Generator\Content_Formatter();
            $checks['Content_Formatter initialized'] = true;

            $comp_renderer = new \SEO_Article_Generator\Generator\Renderers\Competitor_Renderer();
            $comp_html = $comp_renderer->render(
                array(
                    array(
                        'name' => 'Comp A',
                        'comparison_fields' => array(
                            array('field' => 'Price', 'value' => 'Free'),
                        ),
                    ),
                ),
                array(
                    'tech_specs' => array('software_name' => 'Main App'),
                    'download_section' => array('price' => '$29'),
                    'comparison_field_order' => array('Price'),
                )
            );
            $checks['Competitor_Renderer emits wp:table markup'] =
                strpos($comp_html, 'wp:table') !== false && strpos($comp_html, 'wp-block-table') !== false;

            $dl_renderer = new \SEO_Article_Generator\Generator\Renderers\Download_Renderer();
            $dl_blocks = $dl_renderer->render_blocks(array('links' => array()), '', array(), array());
            $checks['Download_Renderer returns array'] = is_array($dl_blocks);

            $tech_renderer = new \SEO_Article_Generator\Generator\Renderers\Tech_Specs_Renderer();
            $tech_blocks = $tech_renderer->render_blocks(array('software_name' => 'Main App'), 0);
            $checks['Tech_Specs_Renderer returns array'] = is_array($tech_blocks);

            $bootstrap_source = self::get_method_source(
                'SEO_Article_Generator\\Discovery\\Discovery_Bootstrap',
                'build_dashboard_snapshot'
            );

            $checks['Dashboard snapshot exposes failed html contract'] =
                strpos($bootstrap_source, "'failed'") !== false
                && strpos($bootstrap_source, "'html'") !== false;

            $checks['Dashboard snapshot exposes completed groups contract'] =
                strpos($bootstrap_source, "'completed'") !== false
                && strpos($bootstrap_source, "'groups'") !== false
                && strpos($bootstrap_source, "'today'") !== false
                && strpos($bootstrap_source, "'history'") !== false;

            $dashboard_file = defined('SEO_GEN_PLUGIN_DIR') ? SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php' : '';
            if (!empty($dashboard_file) && file_exists($dashboard_file)) {
                $dashboard_source = (string) file_get_contents($dashboard_file);

                $checks['Dashboard view consumes completed groups contract'] =
                    strpos($dashboard_source, "['groups']") !== false &&
                    strpos($dashboard_source, "['today']") !== false &&
                    strpos($dashboard_source, "['history']") !== false;

                $checks['Dashboard view exposes completed history count target'] =
                    strpos($dashboard_source, 'sgd-done-history-count') !== false;

                $checks['Dashboard view does not depend on legacy completed flat keys'] =
                    strpos($dashboard_source, "['today_html']") === false &&
                    strpos($dashboard_source, "['history_html']") === false &&
                    strpos($dashboard_source, "['today_count']") === false &&
                    strpos($dashboard_source, "['history_count']") === false;
            } else {
                $checks['Dashboard view file found'] = false;
            }

        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Renderer functionality', 'error' => $e->getMessage(), 'suggestion' => 'Check renderer dependencies and contracts');
        }

        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test AJAX endpoints
     */
    private static function test_ajax_endpoints()
    {
        $checks = array();
        $errors = array();
        $plugin = \SEO_Article_Generator\Plugin::get_instance();
        $methods = array('ajax_run_smoke_test', 'ajax_submit_rating');
        foreach ($methods as $method) {
            $checks["Plugin::$method exists"] = method_exists($plugin, $method);
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test asset files
     */
    private static function test_asset_files()
    {
        $checks = array();
        $errors = array();
        $assets = array(SEO_GEN_PLUGIN_DIR . 'assets/css/admin.css');
        foreach ($assets as $asset) {
            $checks[basename($asset) . " exists"] = file_exists($asset);
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test WordPress compatibility
     */
    private static function test_wordpress_compatibility()
    {
        $checks = array('PHP version >= 8.0' => version_compare(PHP_VERSION, '8.0', '>='));
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => array());
    }

    /**
     * Test content pipeline (Simplified)
     */
    private static function test_content_pipeline()
    {
        $checks = array();
        $errors = array();

        try {
            $schema_class = 'SEO_Article_Generator\\Generator\\Article_Schema';
            if (class_exists($schema_class)) {
                // Test: scalar download_section should be canonicalized to array
                $malformed = array(
                    'title' => 'Test',
                    'download_section' => 'Visit our website for downloads',
                    'features' => array(array('name' => 'F1', 'description' => 'D1')),
                    'faqs' => array(array('question' => 'Q1', 'answer' => 'A1')),
                );
                $schema = call_user_func(array($schema_class, 'from_ai_array'), $malformed);
                $result = $schema->to_array();

                $checks['Schema canonicalizes scalar download_section'] =
                    is_array($result['download_section'])
                    && isset($result['download_section']['links'])
                    && is_array($result['download_section']['links']);

                // Test: scalar moat_data should be canonicalized
                $malformed2 = array(
                    'title' => 'Test',
                    'moat_data' => 'Some moat text',
                );
                $schema2 = call_user_func(array($schema_class, 'from_ai_array'), $malformed2);
                $result2 = $schema2->to_array();

                $checks['Schema canonicalizes scalar moat_data'] =
                    is_array($result2['moat_data']);

                // Test: scalar introduction should be canonicalized
                $malformed3 = array(
                    'title' => 'Test',
                    'introduction' => 'Single paragraph intro',
                );
                $schema3 = call_user_func(array($schema_class, 'from_ai_array'), $malformed3);
                $result3 = $schema3->to_array();

                $checks['Schema canonicalizes scalar introduction'] =
                    is_array($result3['introduction']);

                // Test: round-trip through from_ai_array then from_array mirrors
                // Discovery_Processor::auto_finalize() preview-validation path
                $malformed4 = array(
                    'title' => 'Preview Handoff Test',
                    'download_section' => 'Scalar download',
                    'moat_data' => 'Scalar moat',
                    'introduction' => 'Scalar intro',
                    'features' => array(array('name' => 'F1', 'description' => 'D1')),
                    'faqs' => array(array('question' => 'Q1', 'answer' => 'A1')),
                );
                $pre = call_user_func(array($schema_class, 'from_ai_array'), $malformed4)->to_array();
                $post = call_user_func(array($schema_class, 'from_array'), $pre)->to_array();

                $checks['Preview handoff round-trip preserves download_section shape'] =
                    is_array($post['download_section'])
                    && is_array($post['download_section']['links']);
                $checks['Preview handoff round-trip preserves moat_data shape'] =
                    is_array($post['moat_data']);
                $checks['Preview handoff round-trip preserves introduction shape'] =
                    is_array($post['introduction']);
            }
        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Content Pipeline', 'error' => $e->getMessage(), 'suggestion' => 'Check Article_Schema::from_ai_array');
        }

        // Test: prune_debug_payload preserves observability contract
        try {
            $gen_class = 'SEO_Article_Generator\\Generator\\Article_Generator';
            if (class_exists($gen_class)) {
                $debug_fixture = array(
                    'provider'     => 'gemini',
                    'http_trace'   => array(
                        'provider'       => 'gemini',
                        'endpoint'       => 'https://generativelanguage.googleapis.com/v1beta/models/gemini:generateContent?key=***',
                        'status_code'    => 200,
                        'request_bytes'  => 4096,
                        'response_bytes' => 16384,
                        'response_head'  => str_repeat('x', 600),
                    ),
                    'search_trace' => array(
                        'count'  => 5,
                        'sample' => array(
                            array('title' => 'S1', 'url' => 'https://example.com/1'),
                            array('title' => 'S2', 'url' => 'https://example.com/2'),
                            array('title' => 'S3', 'url' => 'https://example.com/3'),
                            array('title' => 'S4', 'url' => 'https://example.com/4'),
                            array('title' => 'S5', 'url' => 'https://example.com/5'),
                        ),
                    ),
                    'raw_prompt'   => str_repeat('p', 10000),
                    'raw_response' => str_repeat('r', 10000),
                    'messages'     => array('big'),
                    'system_prompt'=> 'large prompt',
                    'full_response_body' => str_repeat('b', 10000),
                );

                $pruned = self::invoke_inaccessible_method($gen_class, 'prune_debug_payload', array($debug_fixture));

                $checks['Prune preserves provider'] =
                    isset($pruned['provider']) && $pruned['provider'] === 'gemini';
                $checks['Prune preserves http_trace'] =
                    isset($pruned['http_trace']) && is_array($pruned['http_trace']);
                $checks['Prune preserves http_trace.status_code'] =
                    isset($pruned['http_trace']['status_code']) && $pruned['http_trace']['status_code'] === 200;
                $checks['Prune caps http_trace.response_head'] =
                    isset($pruned['http_trace']['response_head'])
                    && strlen($pruned['http_trace']['response_head']) <= 500;
                $checks['Prune strips raw_prompt'] =
                    !isset($pruned['raw_prompt']);
                $checks['Prune strips raw_response'] =
                    !isset($pruned['raw_response']);
                $checks['Prune strips messages'] =
                    !isset($pruned['messages']);
                $checks['Prune strips system_prompt'] =
                    !isset($pruned['system_prompt']);
                $checks['Prune strips full_response_body'] =
                    !isset($pruned['full_response_body']);
                $checks['Prune caps search_trace.sample to 3'] =
                    isset($pruned['search_trace']['sample'])
                    && is_array($pruned['search_trace']['sample'])
                    && count($pruned['search_trace']['sample']) <= 3;
            }
        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Debug Prune Contract', 'error' => $e->getMessage(), 'suggestion' => 'Check Article_Generator::prune_debug_payload');
        }

        // Test: Internal linking feature gate and contract
        try {
            $generate_source = self::getMethodSource('SEO_Article_Generator\\Generator\\Article_Generator', 'generate_auto_update');
            $inject_source = self::getMethodSource('SEO_Article_Generator\\Generator\\Article_Generator', 'inject_internal_links');
            $inject_compact = preg_replace('/\s+/', '', (string) $inject_source);

            $checks['Internal linking feature flag exists'] =
                strpos((string) $generate_source, 'seo_gen_internal_link_count') !== false;

            $checks['Internal linking gate runs before prompt build'] =
                strpos((string) $generate_source, 'seo_gen_internal_link_count') !== false
                && strpos((string) $generate_source, 'build_prompt_data') !== false
                && strpos((string) $generate_source, 'seo_gen_internal_link_count') < strpos((string) $generate_source, 'build_prompt_data');

            $checks['Internal link injector is not a no-op'] =
                strpos((string) $inject_compact, 'return$article_data;') === false;

            $checks['Injector normalizes moat to moatdata'] =
                strpos((string) $inject_source, "'moatdata'") !== false
                && strpos((string) $inject_source, "'moat_data'") !== false;

            $checks['Injector enforces strict structured allowlist'] =
                strpos((string) $inject_source, "'introduction'") !== false
                && strpos((string) $inject_source, "'features'") !== false
                && strpos((string) $inject_source, "'moat_data'") !== false
                && strpos((string) $inject_source, 'disallowed_section') !== false;

            $checks['Injector logs malformed token stripping'] =
                strpos((string) $inject_source, 'Malformed internal link token syntax detected and stripped.') !== false;

            $checks['Injector logs measurable success contract'] =
                strpos((string) $inject_source, 'strict_pass') !== false
                && strpos((string) $inject_source, 'success_rate') !== false
                && strpos((string) $inject_source, 'dropped_unused') !== false
                && strpos((string) $inject_source, 'wrong_zone') !== false;
        } catch (\Throwable $e) {
            $errors[] = array(
                'test' => 'Internal Linking Contract',
                'error' => $e->getMessage(),
                'suggestion' => 'Check Article_Generator::generate_auto_update and Article_Generator::inject_internal_links',
            );
        }

        $total  = count($checks);
        $passed = count(array_filter($checks));
        return array('total' => $total, 'passed' => $passed, 'failed' => $total - $passed, 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test AI Update Logic & Integrity
     */
    private static function test_ai_update_logic()
    {
        $checks = array();
        $errors = array();
        try {
            if (class_exists('SEO_Article_Generator\\Generator\\Surgical_Patcher')) {
                $mock_article = array('tech_specs' => array('software_name' => 'Mock', 'version' => '1.0'), 'download_section' => array('links' => array()));
                $res = \SEO_Article_Generator\Generator\Surgical_Patcher::patch('<div data-seo-gen-zone="download">OLD</div>', $mock_article, array('download'));
                $checks['Surgical_Patcher: Layer 0 Discovery'] = (strpos($res['content'], 'seo-gen-download-portal') !== false);
            }
        } catch (\Throwable $e) {
            $errors[] = array('test' => 'AI Update Logic', 'error' => $e->getMessage(), 'suggestion' => 'Check Surgical_Patcher');
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test comparison rendering contracts: price fallback, field order merge, block output.
     */
    private static function test_comparison_contracts()
    {
        $checks = array();
        $errors = array();

        try {
            $formatter_class = 'SEO_Article_Generator\\Generator\\Content_Formatter';
            if (!class_exists($formatter_class)) {
                $errors[] = array('test' => 'Comparison Contracts', 'error' => 'Content_Formatter class not found', 'suggestion' => 'Check autoloading');
                return array('total' => 0, 'passed' => 0, 'failed' => 0, 'checks' => $checks, 'errors' => $errors);
            }

            $article = array(
                'tech_specs' => array(
                    'software_name' => 'Main App',
                    'license' => 'GPL',
                ),
                'download_section' => array(
                    'price' => '$29',
                ),
                'comparison_field_order' => array('Price'),
                'competitors' => array(
                    array(
                        'name' => 'Comp A',
                        'comparison_fields' => array(
                            array('field' => 'Price', 'value' => 'Free'),
                        ),
                    ),
                    array(
                        'name' => 'Comp B',
                        'comparison_fields' => array(
                            array('field' => 'Portable', 'value' => 'Yes'),
                        ),
                    ),
                ),
            );

            $formatter = new $formatter_class();
            $ref = new \ReflectionClass($formatter);
            $method = $ref->getMethod('get_section_renderers');
            $method->setAccessible(true);
            $renderers = $method->invoke($formatter, $article, 0);

            $blocks = isset($renderers['competitors']) ? $renderers['competitors']() : array();
            $html = function_exists('serialize_blocks') ? serialize_blocks($blocks) : '';

            $checks['Price fallback uses download_section price'] =
                strpos($html, '$29') !== false && strpos($html, '>GPL<') === false;

            $checks['Explicit order is merged with discovered fields'] =
                strpos($html, 'Portable') !== false;

            $checks['Comparison markup parses into block output'] =
                strpos($html, 'wp-block-table') !== false || strpos($html, 'wp:table') !== false;

        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Comparison Contracts', 'error' => $e->getMessage(), 'suggestion' => 'Check Content_Formatter and Competitor_Renderer');
        }

        return array(
            'total'  => count($checks),
            'passed' => count(array_filter($checks)),
            'failed' => count($checks) - count(array_filter($checks)),
            'checks' => $checks,
            'errors' => $errors,
        );
    }

    /**
     * Test Job Runtime Contracts
     * 
     * @since 2.27.1
     * @return array Test results
     */
    private static function test_job_runtime_contracts()
    {
        $checks = array();
        $errors = array();
        try {
            $job_id = 12345;
            $expected_lock = "job_generation_$job_id";
            $actual_lock = self::invoke_inaccessible_method('SEO_Article_Generator\\Jobs\\Job_Handler', 'get_job_lock_name', array($job_id));
            $checks['Lock Name Contract'] = ($actual_lock === $expected_lock);

            $available_at = time() + 500;
            $actual_delay = self::invoke_inaccessible_method('SEO_Article_Generator\\Jobs\\Job_Handler', 'seconds_until_utc', array($available_at));
            $calculated_expected = max(60, $available_at - time());
            $checks['Deferred Delay Contract (Floor 60)'] = (abs($actual_delay - $calculated_expected) <= 5);
        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Job Runtime Contracts', 'error' => $e->getMessage(), 'suggestion' => 'Check Job_Handler private methods');
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Test Hero Meta Round Trip
     * 
     * @since 2.27.1
     * @return array Test results
     */
    private static function test_hero_meta_round_trip()
    {
        $checks = array();
        $errors = array();
        try {
            $plugin = \SEO_Article_Generator\Plugin::get_instance();
            $article = array(
                'title' => 'Round Trip Test Title',
                'focus_keyword' => 'round trip test',
                'meta_description' => 'A round trip test for hero metadata.',
                'hero_section' => array('software_name' => 'Round Trip Test', 'version' => '1.2.3'),
                'download_section' => array(
                    'links' => array(
                        array('url' => 'https://primary.com', 'is_primary' => true, 'platform' => 'Win'),
                        array('url' => 'https://secondary.com', 'is_primary' => false, 'platform' => 'Mir'),
                    )
                )
            );
            $payload = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::build(array('article' => $article), 0);
            $meta = $payload['meta_input']['seogenherodata'] ?? array();
            $checks['Hero Meta Build: Schema V2 set'] = (($meta['_schema_version'] ?? 0) === 2);
            $checks['Hero Meta Build: Primary Link count'] = (self::count_primary_links($meta['download_links'] ?? array()) === 1);

            $mock_post_id = \wp_insert_post(array('post_title' => 'Meta Test', 'post_type' => 'post', 'post_status' => 'draft'));
            if ($mock_post_id && !\is_wp_error($mock_post_id)) {
                $plugin->write_hero_data($mock_post_id, $payload['meta_input']['seogenherodata']);
                $raw_stored = get_post_meta($mock_post_id, 'seogenherodata', true);
                $checks['Hero Meta DB Contract: Stored as Array'] = is_array($raw_stored);
                $checks['Hero Meta DB Contract: Schema V2'] = (($raw_stored['_schema_version'] ?? 0) === 2);
                
                $read_back = $plugin->get_hero_data($mock_post_id);
                $checks['Hero Meta Read: Software Name intact'] = ($read_back['software_name'] === 'Round Trip Test');
                
                \wp_delete_post($mock_post_id, true);
            }
        } catch (\Throwable $e) {
            $errors[] = array('test' => 'Hero Meta Round Trip', 'error' => $e->getMessage(), 'suggestion' => 'Check metadata persistence');
        }
        return array('total' => count($checks), 'passed' => count(array_filter($checks)), 'failed' => count($checks) - count(array_filter($checks)), 'checks' => $checks, 'errors' => $errors);
    }

    /**
     * Diagnostic Page Renderer
     */
    public static function render_page()
    {
        if (!current_user_can('manage_options')) { wp_die('Unauthorized'); }
        echo '<div class="wrap"><h1>SEO Article Generator Smoke Test</h1>';
        $results = self::run_smoke_test();
        echo '<div class="card" style="padding: 20px;">';
        echo '<p><strong>Total:</strong> ' . $results['summary']['total'] . ' | <strong>Passed:</strong> ' . $results['summary']['passed'] . ' | <strong>Failed:</strong> ' . $results['summary']['failed'] . '</p>';
        foreach ($results['categories'] as $cat => $data) {
            $color = ($data['failed'] === 0) ? 'green' : 'red';
            echo "<h3 style='color: $color;'>" . ucfirst($cat) . "</h3>";
            if (!empty($data['errors'])) {
                foreach ($data['errors'] as $err) {
                    echo "<div style='background:#fee; padding:5px; border:1px solid red; margin-bottom:5px;'>";
                    echo "<strong>Error:</strong> " . esc_html($err['error']) . "<br>";
                    echo "<strong>Suggestion:</strong> " . esc_html($err['suggestion']);
                    echo "</div>";
                }
            } else {
                echo "<p>✓ All " . $data['passed'] . " checks passed</p>";
            }
        }
        echo '</div></div>';
    }

    private static function get_all_php_files($dir)
    {
        $files = array();
        $exclude_dirs = array('vendor', 'tests', 'node_modules', '.git', 'DevTools', 'Production');
        
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($it as $f) {
            if ($f->isFile() && $f->getExtension() === 'php') {
                $relative_path = str_replace($dir, '', $f->getPathname());
                $skip = false;
                foreach ($exclude_dirs as $excluded) {
                    if (strpos($relative_path, DIRECTORY_SEPARATOR . $excluded . DIRECTORY_SEPARATOR) !== false ||
                        strpos($relative_path, $excluded . DIRECTORY_SEPARATOR) === 0) {
                        $skip = true;
                        break;
                    }
                }
                if (!$skip) {
                    $files[] = $f->getPathname();
                }
            }
        }
        
        return $files;
    }

    private static function invoke_inaccessible_method($class, $method, $args = array())
    {
        $refl = new \ReflectionClass($class);
        $meth = $refl->getMethod($method);
        $meth->setAccessible(true);
        $instance = ($meth->isStatic()) ? null : (is_object($class) ? $class : $refl->newInstanceWithoutConstructor());
        return $meth->invokeArgs($instance, $args);
    }

    private static function get_method_source($class, $method)
    {
        $ref = new \ReflectionMethod($class, $method);
        $file = $ref->getFileName();

        if (! $file || ! file_exists($file)) {
            throw new \RuntimeException("Cannot read source for {$class}::{$method}");
        }

        $lines = file($file, FILE_IGNORE_NEW_LINES);
        $start = max(0, $ref->getStartLine() - 1);
        $length = max(1, $ref->getEndLine() - $ref->getStartLine() + 1);

        return implode("\n", array_slice($lines, $start, $length));
    }

    private static function count_primary_links($links)
    {
        if (!is_array($links)) return 0;
        return count(array_filter($links, function($l) { return !empty($l['is_primary']); }));
    }

    private static function inspect_reconcile_failed_contract(string $source): array
    {
        $label = 'recover_from_reconcile_failed_snapshot(';

        if (strpos($source, $label) === false) {
            return array(
                'ok'     => false,
                'reason' => 'Method does not call recover_from_reconcile_failed_snapshot().',
            );
        }

        $offset = 0;
        $found_branch = false;

        while (($pos = strpos($source, 'reconcile_failed', $offset)) !== false) {
            $found_branch = true;

            $window_start = max(0, $pos - 160);
            $window = substr($source, $window_start, 1400);

            $helper_pos   = strpos($window, 'recover_from_reconcile_failed_snapshot(');
            $failure_pos  = strpos($window, 'mark_discovery_failure(');
            $preview_pos  = strpos($window, 'get_preview(');
            $claim_pos    = strpos($window, 'claim_item_for_finalization(');
            $finalize_pos = strpos($window, 'auto_finalize(');

            if ($helper_pos === false) {
                return array(
                    'ok'     => false,
                    'reason' => 'A reconcile_failed branch exists without the canonical helper.',
                );
            }

            if ($failure_pos !== false && $failure_pos < $helper_pos) {
                return array(
                    'ok'     => false,
                    'reason' => 'A reconcile_failed branch marks failure before calling the canonical helper.',
                );
            }

            if ($preview_pos !== false) {
                return array(
                    'ok'     => false,
                    'reason' => 'A reconcile_failed branch still contains inline preview-based recovery logic.',
                );
            }

            if ($claim_pos !== false && $finalize_pos !== false) {
                return array(
                    'ok'     => false,
                    'reason' => 'A reconcile_failed branch still contains inline claim/finalize recovery logic.',
                );
            }

            $offset = $pos + strlen('reconcile_failed');
        }

        if (! $found_branch) {
            return array(
                'ok'     => false,
                'reason' => 'Method does not contain an explicit reconcile_failed branch.',
            );
        }

        return array(
            'ok'     => true,
            'reason' => '',
        );
    }

    /**
     * Test that all reconcile_failed recovery entrypoints use the canonical helper.
     *
     * @return array Test results
     */
    private static function test_reconcile_failed_contracts()
    {
        $checks = array();
        $errors = array();

        try {
            $class = 'SEO_Article_Generator\\Discovery\\Discovery_Processor';
            if (! class_exists($class)) {
                $errors[] = array(
                    'test'       => 'Reconcile Failed Contracts',
                    'error'      => 'Discovery_Processor class not found.',
                    'suggestion' => 'Check autoloading and class name.',
                );
                return array('total' => 1, 'passed' => 0, 'failed' => 1, 'checks' => $checks, 'errors' => $errors);
            }

            $methods = array(
                'resume_pipeline',
                'handle_job_finished',
                'reconcile_after_queue_reset',
                'reconcile_item_status',
                'check_and_finalize_job',
            );

            foreach ($methods as $method) {
                if (! method_exists($class, $method)) {
                    $checks["{$method} exists"] = false;
                    $errors[] = array(
                        'test'       => "{$method} existence",
                        'error'      => "{$method} method not found on Discovery_Processor.",
                        'suggestion' => 'Verify method name matches production class.',
                    );
                    continue;
                }

                $source = self::get_method_source($class, $method);
                $inspection = self::inspect_reconcile_failed_contract($source);

                $checks["{$method} uses canonical reconcile_failed contract"] = (bool) $inspection['ok'];

                if (! $inspection['ok']) {
                    $errors[] = array(
                        'test'       => "{$method} canonical reconcile_failed contract",
                        'error'      => $inspection['reason'],
                        'suggestion' => 'Use recover_from_reconcile_failed_snapshot() as the only recovery path in reconcile_failed branches, and call it before any failure marking.',
                    );
                }
            }
        } catch (\Throwable $e) {
            $errors[] = array(
                'test'       => 'Reconcile Failed Contracts',
                'error'      => $e->getMessage(),
                'suggestion' => 'Check Discovery_Processor method names and source readability.',
            );
        }

        $passed = count(array_filter($checks));
        $total  = count($checks);

        return array(
            'total'  => $total,
            'passed' => $passed,
            'failed' => $total - $passed,
            'checks' => $checks,
            'errors' => $errors,
        );
    }

    /**
     * Test Installation/Troubleshooting ownership contracts via public renderer API.
     *
     * @return array Test results
     */
    private static function test_installation_contracts()
    {
        $checks = array();
        $errors = array();

        try {
            $formatter_class = 'SEO_Article_Generator\\Generator\\Content_Formatter';
            if (! class_exists($formatter_class)) {
                $errors[] = array(
                    'test'       => 'Installation Contracts',
                    'error'      => 'Content_Formatter class not found.',
                    'suggestion' => 'Check autoloading and formatter class name.',
                );
                return array('total' => 1, 'passed' => 0, 'failed' => 1, 'checks' => $checks, 'errors' => $errors);
            }

            $formatter = new $formatter_class();

            $issues_only = array(
                'installation_guide' => array(
                    'common_issues' => array(
                        array('issue' => 'Installer blocked', 'solution' => 'Disable antivirus temporarily'),
                    ),
                ),
            );

            $intro_only = array(
                'installation_guide' => array(
                    'intro' => 'Download the package and run the installer as administrator.',
                ),
            );

            $notes_only = array(
                'installation_guide' => array(
                    'compatibility_notes' => 'Works on Windows 11 and macOS Sonoma.',
                ),
            );

            $installation_from_issues = (string) $formatter->render_zone_html('installation', $issues_only, 0);
            $troubleshooting_from_issues = (string) $formatter->render_zone_html('troubleshooting', $issues_only, 0);
            $installation_from_intro = (string) $formatter->render_zone_html('installation', $intro_only, 0);
            $installation_from_notes = (string) $formatter->render_zone_html('installation', $notes_only, 0);

            $checks['Installation excludes common_issues-only payloads'] = trim($installation_from_issues) === '';
            if (! $checks['Installation excludes common_issues-only payloads']) {
                $errors[] = array(
                    'test'       => 'Installation excludes common_issues-only payloads',
                    'error'      => 'Installation rendered content for a common_issues-only payload.',
                    'suggestion' => 'Keep common_issues owned only by Troubleshooting.',
                );
            }

            $checks['Troubleshooting renders common_issues payloads'] =
                trim($troubleshooting_from_issues) !== '' &&
                strpos($troubleshooting_from_issues, 'Installer blocked') !== false;
            if (! $checks['Troubleshooting renders common_issues payloads']) {
                $errors[] = array(
                    'test'       => 'Troubleshooting renders common_issues payloads',
                    'error'      => 'Troubleshooting did not render common_issues content.',
                    'suggestion' => 'Keep troubleshooting mapped to installation_guide.common_issues.',
                );
            }

            $checks['Installation renders intro-only payloads'] =
                trim($installation_from_intro) !== '' &&
                strpos($installation_from_intro, 'Download the package and run the installer as administrator.') !== false;
            if (! $checks['Installation renders intro-only payloads']) {
                $errors[] = array(
                    'test'       => 'Installation renders intro-only payloads',
                    'error'      => 'Installation did not render intro-only content.',
                    'suggestion' => 'Keep intro/summary in the Installation render contract.',
                );
            }

            $checks['Installation renders compatibility-notes-only payloads'] =
                trim($installation_from_notes) !== '' &&
                strpos($installation_from_notes, 'Works on Windows 11 and macOS Sonoma.') !== false;
            if (! $checks['Installation renders compatibility-notes-only payloads']) {
                $errors[] = array(
                    'test'       => 'Installation renders compatibility-notes-only payloads',
                    'error'      => 'Installation did not render compatibility_notes-only content.',
                    'suggestion' => 'Keep compatibility_notes in both the presence and render contracts.',
                );
            }
        } catch (\Throwable $e) {
            $errors[] = array(
                'test'       => 'Installation Contracts',
                'error'      => $e->getMessage(),
                'suggestion' => 'Check Content_Formatter public render API and installation/troubleshooting contracts.',
            );
        }

        $passed = count(array_filter($checks));
        $total  = count($checks);

        return array(
            'total'  => $total,
            'passed' => $passed,
            'failed' => $total - $passed,
            'checks' => $checks,
            'errors' => $errors,
        );
    }

    /**
     * Test Dashboard Contract Runtime
     *
     * Runtime smoke test that seeds completed rows and verifies snapshot grouping works correctly.
     * Also checks negative enforcement - ensuring dead code stays removed.
     *
     * @return array Test results
     */
    private static function test_dashboard_contract_runtime()
    {
        $checks = array();
        $errors = array();

        try {
            global $wpdb;
            $table = \SEO_Article_Generator\Installer::table_discovery();

            $test_rows = array(
                array(
                    'software_name'     => 'TestApp Today',
                    'discovered_version' => '1.0',
                    'status'            => 'done',
                    'type'              => 'new',
                    'created_at'        => date('Y-m-d H:i:s', strtotime('-2 hours')),
                    'completed_at'      => date('Y-m-d H:i:s', strtotime('-2 hours')),
                ),
                array(
                    'software_name'     => 'TestApp Yesterday',
                    'discovered_version' => '2.0',
                    'status'            => 'done',
                    'type'              => 'new',
                    'created_at'        => date('Y-m-d H:i:s', strtotime('-25 hours')),
                    'completed_at'      => date('Y-m-d H:i:s', strtotime('-25 hours')),
                ),
                array(
                    'software_name'     => 'TestApp Old',
                    'discovered_version' => '3.0',
                    'status'            => 'done',
                    'type'              => 'new',
                    'created_at'        => date('Y-m-d H:i:s', strtotime('-5 days')),
                    'completed_at'      => date('Y-m-d H:i:s', strtotime('-5 days')),
                ),
            );

            $inserted_ids = array();
            foreach ($test_rows as $row) {
                $result = $wpdb->insert($table, $row);
                if ($result) {
                    $inserted_ids[] = $wpdb->insert_id;
                }
            }

            $checks['Test rows seeded'] = count($inserted_ids) === 3;
            if (count($inserted_ids) !== 3) {
                $errors[] = array(
                    'test'       => 'Test rows seeded',
                    'error'      => 'Could only seed ' . count($inserted_ids) . ' of 3 test rows',
                    'suggestion' => 'Check database insert permissions and table schema',
                );
            }

            $bootstrap_class = 'SEO_Article_Generator\\Discovery\\Discovery_Bootstrap';
            $snapshot = self::invoke_inaccessible_method($bootstrap_class, 'build_dashboard_snapshot', array());

            $checks['Snapshot has completed key'] = isset($snapshot['completed']);
            $checks['Completed has groups key'] = isset($snapshot['completed']['groups']);
            $checks['Completed has today group'] = isset($snapshot['completed']['groups']['today']);
            $checks['Completed has history group'] = isset($snapshot['completed']['groups']['history']);

            if (isset($snapshot['completed']['groups'])) {
                $today_group = $snapshot['completed']['groups']['today'];
                $history_group = $snapshot['completed']['groups']['history'];

                $checks['Today group has count'] = isset($today_group['count']);
                $checks['Today group has html'] = isset($today_group['html']);
                $checks['History group has count'] = isset($history_group['count']);
                $checks['History group has html'] = isset($history_group['html']);

                $checks['Today count >= 1'] = ($today_group['count'] ?? 0) >= 1;
                $checks['History count >= 1'] = ($history_group['count'] ?? 0) >= 1;

                if (!empty($today_group['html'])) {
                    $checks['Today html contains TestApp Today'] = strpos($today_group['html'], 'TestApp Today') !== false;
                }
                if (!empty($history_group['html'])) {
                    $checks['History html contains old entries'] = strpos($history_group['html'], 'TestApp Old') !== false || strpos($history_group['html'], 'TestApp Yesterday') !== false;
                }
            } else {
                $errors[] = array(
                    'test'       => 'Completed groups structure',
                    'error'      => 'Snapshot completed does not have groups structure',
                    'suggestion' => 'Check build_dashboard_snapshot() returns groups: {today: {count, html}, history: {count, html}}',
                );
            }

            foreach ($inserted_ids as $id) {
                $wpdb->delete($table, array('id' => $id), array('%d'));
            }
            $checks['Test rows cleaned up'] = true;

            $dashboard_file = defined('SEO_GEN_PLUGIN_DIR') ? SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php' : '';
            if (!empty($dashboard_file) && file_exists($dashboard_file)) {
                $dashboard_source = (string) file_get_contents($dashboard_file);

                $checks['Dead code: .sgd-stat.is-link CSS removed'] =
                    strpos($dashboard_source, '.sgd-stat.is-link') === false;

                $checks['Dead code: applyStatusSnapshot function removed'] =
                    strpos($dashboard_source, 'function applyStatusSnapshot') === false;

                $checks['Dead code: renderPendingTab removed'] =
                    strpos($dashboard_source, 'function renderPendingTab') === false;

                $checks['Dead code: renderPipelineTab removed'] =
                    strpos($dashboard_source, 'function renderPipelineTab') === false;

                $checks['Dead code: renderFailedTab removed'] =
                    strpos($dashboard_source, 'function renderFailedTab') === false;

                $checks['Dead code: renderCompletedTab removed'] =
                    strpos($dashboard_source, 'function renderCompletedTab') === false;

                $checks['Dead code: fake snapshot fabrication removed'] =
                    strpos($dashboard_source, "fakeSnapshot['pending']") === false &&
                    strpos($dashboard_source, "fakeSnapshot['pipeline']") === false;

                $checks['Dead code: completed flat keys removed'] =
                    strpos($dashboard_source, "['today_html']") === false &&
                    strpos($dashboard_source, "['history_html']") === false;
            }

        } catch (\Throwable $e) {
            $errors[] = array(
                'test'       => 'Dashboard Contract Runtime',
                'error'      => $e->getMessage(),
                'suggestion' => 'Check build_dashboard_snapshot() method and database access',
            );
        }

        $passed = count(array_filter($checks));
        $total  = count($checks);

        return array(
            'total'  => $total,
            'passed' => $passed,
            'failed' => $total - $passed,
            'checks' => $checks,
            'errors' => $errors,
        );
    }
}
