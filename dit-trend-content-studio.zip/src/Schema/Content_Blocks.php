<?php

/**
 * Content Blocks Schema
 *
 * Defines required content blocks per vertical for consistent rankability.
 *
 * @package DIT_TrendStudio\Schema
 * @since 1.8.1
 */

namespace DIT\TrendStudio\Schema;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Content blocks requirements per vertical
 */
class Content_Blocks
{
    /**
     * Required blocks per vertical
     * Each block has: min_items (minimum array length) and required (bool)
     */
    private const VERTICAL_BLOCKS = [
        'beauty' => [
            'product_picks'      => ['min_items' => 3, 'required' => true, 'description' => 'Product recommendations'],
            'application_tips'   => ['min_items' => 3, 'required' => true, 'description' => 'How-to guidance'],
            'skin_type_guidance' => ['min_items' => 2, 'required' => false, 'description' => 'Skin type considerations'],
            'ingredient_notes'   => ['min_items' => 2, 'required' => false, 'description' => 'Key ingredient info'],
        ],
        'showbiz' => [
            'key_facts'          => ['min_items' => 0, 'required' => false, 'description' => 'Essential facts directly from the source content'],
        ],
        'showbiz_pk' => [
            'key_facts'          => ['min_items' => 0, 'required' => false, 'description' => 'Essential facts directly from the source content'],
        ],
        'fashion_pk' => [
            'key_facts'          => ['min_items' => 0, 'required' => false, 'description' => 'Essential facts directly from the source content'],
        ],
    ];

    /**
     * Get required blocks for a vertical
     *
     * @param string $vertical Vertical name
     * @return array Block requirements
     */
    public static function get_required_blocks(string $vertical): array
    {
        return self::VERTICAL_BLOCKS[$vertical] ?? self::VERTICAL_BLOCKS['showbiz'];
    }

    /**
     * Get all verticals with their block requirements
     *
     * @return array All vertical blocks
     */
    public static function get_all_verticals(): array
    {
        return self::VERTICAL_BLOCKS;
    }

    /**
     * Validate content blocks against vertical requirements
     *
     * @param array  $content_blocks Content blocks from article
     * @param string $vertical       Vertical name
     * @return array Validation result ['passed' => bool, 'errors' => [], 'warnings' => []]
     */
    public static function validate(array $content_blocks, string $vertical): array
    {
        $required = self::get_required_blocks($vertical);
        $errors = [];
        $warnings = [];

        foreach ($required as $block_type => $config) {
            $found = $content_blocks[$block_type] ?? [];
            $found_count = is_array($found) ? count($found) : 0;

            if ($config['required'] && $found_count < $config['min_items']) {
                $errors[] = sprintf(
                    'Missing or incomplete block: %s (need %d items, found %d) - %s',
                    $block_type,
                    $config['min_items'],
                    $found_count,
                    $config['description']
                );
            } elseif (!$config['required'] && $found_count === 0 && $config['min_items'] > 0) {
                $warnings[] = sprintf(
                    'Optional block missing: %s - %s',
                    $block_type,
                    $config['description']
                );
            }
        }

        return [
            'passed'   => empty($errors),
            'errors'   => $errors,
            'warnings' => $warnings,
        ];
    }

    /**
     * Build prompt instructions for required blocks
     *
     * @param string $vertical Vertical name
     * @return string Prompt text
     */
    public static function build_prompt_instructions(string $vertical): string
    {
        $required = self::get_required_blocks($vertical);
        $lines = [];
        $lines[] = "REQUIRED CONTENT BLOCKS for {$vertical}:";

        foreach ($required as $block_type => $config) {
            $req_label = $config['required'] ? 'REQUIRED' : 'optional';
            $lines[] = sprintf(
                '- %s (%s, min %d items): %s',
                $block_type,
                $req_label,
                $config['min_items'],
                $config['description']
            );
        }

        $lines[] = '';
        $lines[] = 'Include these as a "content_blocks" object in your JSON output:';
        $lines[] = '"content_blocks": {';

        foreach (array_keys($required) as $block_type) {
            $lines[] = "  \"{$block_type}\": [...],";
        }

        $lines[] = '}';

        return implode("\n", $lines);
    }
}
