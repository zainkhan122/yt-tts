<?php

/**
 * Social Searcher Provider
 *
 * Monitors social media trends (Twitter, Facebook, Instagram, YouTube, Reddit)
 * Free tier: 400 requests/day
 *
 * @package DIT_TrendStudio\Sources
 * @since 1.5.0
 */

namespace DIT\TrendStudio\Sources;

use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Social Searcher API provider implementation
 *
 * @since 1.5.0
 */
class Social_Searcher_Provider implements Source_Provider
{
    /**
     * Logger instance
     *
     * @var Logger
     * @since 1.5.0
     */
    private Logger $logger;

    /**
     * API key
     *
     * @var string
     * @since 1.5.0
     */
    private string $api_key;

    /**
     * Default hashtags to monitor
     *
     * @var array
     * @since 1.5.0
     */
    private array $default_hashtags = [
        '#OOTD',
        '#makeup',
        '#celebritystyle',
    ];

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     * @since 1.5.0
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        $this->api_key = get_option('dit_ts_social_searcher_key', '');
    }

    /**
     * Get provider name
     *
     * @return string
     * @since 1.5.0
     */
    public function get_name(): string
    {
        return 'Social Searcher';
    }

    /**
     * Get provider type
     *
     * @return string
     * @since 1.5.0
     */
    public function get_type(): string
    {
        return 'social_searcher';
    }

    /**
     * Check if provider is configured
     *
     * @return bool
     * @since 1.5.0
     */
    public function is_available(): bool
    {
        return !empty($this->api_key);
    }

    /**
     * Fetch trending social content
     *
     * @param array $params Optional parameters (hashtags can be overridden)
     * @return Idea_DTO[]
     * @throws \DIT\TrendStudio\Source_Exception On API error
     * @since 1.5.0
     */
    public function fetch_ideas(array $params = array()): array
    {
        if (!$this->is_available()) {
            $this->logger->warning('Social Searcher: API key not configured');
            return array();
        }

        $hashtags = $params['hashtags'] ?? $this->get_daily_hashtags();
        $ideas = array();

        foreach ($hashtags as $hashtag) {
            try {
                $posts = $this->search_hashtag($hashtag);
                $ideas = array_merge($ideas, $posts);
            } catch (\Exception $e) {
                $this->logger->error(sprintf('Social Searcher: Error searching "%s": %s', $hashtag, $e->getMessage()));
                // Continue with other hashtags on error
                continue;
            }
        }

        $this->logger->info(sprintf('Social Searcher: Fetched %d social posts', count($ideas)));
        return $ideas;
    }

    /**
     * Get hashtags for today (rotate to stay under rate limits)
     *
     * Uses day of month to rotate through hashtags, limiting daily API calls
     *
     * @return array
     * @since 1.5.0
     */
    private function get_daily_hashtags(): array
    {
        // Rotate hashtags based on day of month to conserve API calls
        // Free tier: 400/day, we use only 2 per day = 60/month
        $day_index = (int) gmdate('j') % count($this->default_hashtags);
        return array_slice($this->default_hashtags, $day_index, 2);
    }

    /**
     * Search for a specific hashtag
     *
     * @param string $hashtag Hashtag to search (with or without #)
     * @return Idea_DTO[]
     * @throws \Exception On API error
     * @since 1.5.0
     */
    private function search_hashtag(string $hashtag): array
    {
        // Ensure hashtag starts with #
        if (strpos($hashtag, '#') !== 0) {
            $hashtag = '#' . $hashtag;
        }

        $url = sprintf(
            'https://api.social-searcher.com/v2/search?q=%s&network=instagram,twitter&limit=10&key=%s',
            urlencode($hashtag),
            $this->api_key
        );

        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'headers' => array(
                'User-Agent' => 'DIT-TrendStudio/1.5.0',
            ),
        ));

        if (is_wp_error($response)) {
            throw new \Exception('API request failed: ' . $response->get_error_message());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            $body = wp_remote_retrieve_body($response);
            throw new \Exception(sprintf('API returned HTTP %d: %s', $status_code, $body));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Invalid JSON response: ' . json_last_error_msg());
        }

        if (isset($data['meta']['error'])) {
            throw new \Exception('API error: ' . $data['meta']['error']);
        }

        if (empty($data['posts'])) {
            return array();
        }

        return $this->convert_posts_to_ideas($data['posts'], $hashtag);
    }

    /**
     * Convert Social Searcher posts to Idea DTOs
     *
     * @param array  $posts   Raw posts from API
     * @param string $hashtag Hashtag searched
     * @return Idea_DTO[]
     * @since 1.5.0
     */
    private function convert_posts_to_ideas(array $posts, string $hashtag): array
    {
        $ideas = array();

        foreach ($posts as $post) {
            // Skip posts without required fields
            if (empty($post['text']) || empty($post['url'])) {
                continue;
            }

            // Generate a title from post text (first 100 chars)
            $title = mb_substr(sanitize_text_field($post['text']), 0, 100);
            if (mb_strlen($post['text']) > 100) {
                $title .= '...';
            }

            $ideas[] = Idea_DTO::from_array(array(
                'title'         => $title,
                'excerpt'       => sanitize_textarea_field($post['text']),
                'source_url'    => esc_url_raw($post['url']),
                'source_type'   => 'social',
                'provider_name' => 'Social Searcher',
                'image_url'     => !empty($post['image']) ? esc_url_raw($post['image']) : '',
                'published_at'  => !empty($post['posted']) ? gmdate('c', strtotime($post['posted'])) : gmdate('c'),
                'raw_data'      => array(
                    'network'   => $post['network'] ?? '',
                    'sentiment' => $post['sentiment'] ?? '',
                    'user'      => $post['user']['name'] ?? '',
                    'hashtag'   => $hashtag,
                ),
            ));
        }

        return $ideas;
    }
}
