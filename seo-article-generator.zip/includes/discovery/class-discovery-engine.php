<?php

namespace SEO_Article_Generator\Discovery;

use SEO_Article_Generator\AI\AI_Client;
use SEO_Article_Generator\Queue\AS_Registry;
use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Installer;
use SEO_Article_Generator\Utils\Plugin_Time;
use SEO_Article_Generator\Utils\SeoGen_Version_Resolver;
use SEO_Article_Generator\Discovery\Data_Extractor;
use SEO_Article_Generator\Discovery\Similarity_Helper;
use SEO_Article_Generator\Links\DB_Post_Finder;
use SEO_Article_Generator\Integration\Link_Resolver;

if (! \defined('ABSPATH')) {
	exit();
}

/**
 * Core discovery engine managing RSS, AI Scouting, and WP Auto Polling.
 *
 * @MODIFIED 2026-04-09: Hardened with Admission Gate and Robust Mutexes.
 */
class Discovery_Engine
{
	public const PLUGIN_FILTER_OPTION = 'seogen_block_plugin_generated';
	public const PLUGIN_FILTER_ERROR  = 'New + Legacy Discovery Block enabled. Add a zone manually first.';

	public const STATUS_PENDING            = 'pending';
	public const STATUS_DEFERRED           = 'deferred';
    public const STATUS_SKIPPED_NOT_NEWER = 'skipped_not_newer';
	public const STATUS_SKIPPED_DUPLICATE  = 'skippedduplicate';
	public const STATUS_IGNORED            = 'ignored';
	public const STATUS_FAILED             = 'failed';

	/** @var Logger */
	private $logger;

	/** @var AI_Client */
	private $ai_client;

	public function __construct(Logger $logger, AI_Client $ai_client)
	{
		$this->logger    = $logger;
		$this->ai_client = $ai_client;
	}

	// =========================================================================
	// PUBLIC: MUTEX / LOCKING
	// =========================================================================

	public function acquire_scanner_mutex(string $type): bool
	{
		global $wpdb;

		$lock_key = 'seo_gen_scanner_lock_' . \sanitize_key($type);
		$now      = Plugin_Time::now_utc_ts();
		$ttl      = 30 * \MINUTE_IN_SECONDS;
		$table    = $wpdb->options;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table}
				  WHERE option_name = %s
				    AND CAST(option_value AS UNSIGNED) < %d",
				$lock_key,
				$now - $ttl
			)
		);

		$wpdb->suppress_errors(true);
		$claimed = (bool) $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table} (option_name, option_value, autoload)
				 VALUES (%s, %s, 'no')",
				$lock_key,
				(string) $now
			)
		);
		$wpdb->suppress_errors(false);

		return $claimed;
	}

	public function release_scanner_mutex(string $type): void
	{
		\delete_option('seo_gen_scanner_lock_' . \sanitize_key($type));
	}

	// =========================================================================
	// PUBLIC: PASSIVE RSS DISCOVERY
	// =========================================================================

	/**
	 * Fetch RSS feeds, parse titles, compare versions, and stage genuine updates.
	 */
	public function run_rss_discovery()
	{
		if (! $this->acquire_scanner_mutex("rss")) {
			$this->logger->info("Passive RSS Discovery already running. Skipping overlap.");
			return;
		}

		try {
			if (! \get_option('seo_gen_discovery_enabled', 1)) {
				$this->logger->info('Passive RSS Discovery is globally DISABLED. Skipping.');
				return;
			}

			if (! \get_option('seo_gen_rss_discovery_enabled', 1)) {
				$this->logger->info('Passive RSS Discovery is toggled OFF (RSS). Skipping.');
				return;
			}

			$sources = \get_option('seo_gen_discovery_sources', []);
			if (empty($sources)) {
				$this->logger->info('No RSS sources configured. Skipping scan.');
				return;
			}

			$this->logger->info('Passive RSS Discovery scan started.', [
				'source_count' => count($sources),
			]);

			$staged_count = 0;
			foreach ($sources as $source) {
				try {
					$url = (string) ($source['feed_url'] ?? $source['url'] ?? '');
					if (empty($url)) {
						continue;
					}

					$rss = \fetch_feed($url);
					if (\is_wp_error($rss)) {
						$this->logger->warning('Failed to fetch RSS feed: ' . $url . ' - ' . $rss->get_error_message());
						continue;
					}

					$items = $rss->get_items(0, 50);
					foreach ($items as $item) {
						$title = $item->get_title();
						$parsed = $this->parse_rss_title($title);

						if (! $parsed) {
							$this->logger->debug('RSS item skipped: unparseable title - ' . $title);
							continue;
						}

						$software_name   = (string) $parsed['name'];
						$latest_version  = (string) $parsed['version'];

                $match = $this->find_existing_software($software_name);
                $post_id = $match ? (int) $match['id'] : 0;
                $current_ver = $match ? trim((string) $match['version']) : '';
                if ( $post_id > 0 ) {
                    $contract = self::canonicalize_discovery_contract((string) ($match['type'] ?? Post_Type_Classifier::TYPE_NEW), $post_id);
                    $post_id = (int) $contract['existing_post_id'];
                    $type = (string) $contract['type'];
                    $resolved_current_ver = SeoGen_Version_Resolver::current_version($post_id, $current_ver);
                    if ($resolved_current_ver !== '') {
                        $current_ver = $resolved_current_ver;
                    }
                } else {
                    $type = Post_Type_Classifier::TYPE_NEW;
                }

                if ($current_ver === '') {
                    $current_ver = 'Unknown';
                }

                if (Title_Analyzer::is_newer_version($latest_version, $current_ver, $this->logger)) {
                    $this->logger->info('RSS found potential update for ' . $software_name . ' ' . $latest_version);

                    $item_id = $this->stage_item(
                        $software_name,
                        $latest_version,
                        $current_ver,
                        (string) $item->get_permalink(),
                        (string) $item->get_content(),
                        $type,
                        $post_id
                    );

                    if ($item_id > 0) {
                        $staged_count++;
                    }
                }
					}
				} catch (\Throwable $e) {
					$this->logger->error('Error processing RSS source ' . $url . ': ' . $e->getMessage());
				}
			}

			$this->logger->info('Passive RSS Discovery scan complete.', [
				'staged_count' => $staged_count,
			]);
		} finally {
			$this->release_scanner_mutex("rss");
		}

		$next_midnight = Plugin_Time::next_site_midnight_utc_ts(Plugin_Time::now_utc_ts());
		AS_Registry::schedule_passive_discovery($next_midnight);
	}

    // =========================================================================
    // PUBLIC: ACTIVE AI DISCOVERY
    // =========================================================================

	/**
	 * Check existing posts for newer versions using AI web search.
	 */
	public function run_ai_update_checks()
	{
		if ('1' !== (string) \get_option('seo_gen_discovery_enabled', '1')) {
			$this->logger->info('Active AI Discovery is globally DISABLED. Skipping.');
			return;
		}

		if ('1' !== (string) \get_option('seo_gen_ai_discovery_enabled', '0')) {
			$this->logger->info('Active AI Discovery is toggled OFF (Scout). Skipping.');
			return;
		}

		$api_info = Discovery_Bootstrap::get_instance()->get_api_pause_info();
		if (! empty($api_info['paused'])) {
			$this->logger->info(\sprintf(
				'AI Update checks paused until %s. Reason: %s',
				$api_info['resume_diff'] ?: 'unknown duration',
				$api_info['reason'] ?: 'rate limit'
			));
			return;
		}

		if (! $this->acquire_scanner_mutex("ai_scout")) {
			$this->logger->info("Active AI Discovery already running. Skipping overlap.");
			return;
		}

		try {
			$daily_quota = max(0, (int) \get_option('seo_gen_daily_quota', 50));
			$quota_key   = 'seo_gen_ai_checks_' . Plugin_Time::site_today_ymd();
			$quota_ttl   = max(
				\MINUTE_IN_SECONDS,
				Plugin_Time::next_site_midnight_utc_ts(Plugin_Time::now_utc_ts()) - Plugin_Time::now_utc_ts()
			);
			$used_today  = max(0, (int) \get_transient($quota_key));

			if ($daily_quota > 0 && $used_today >= $daily_quota) {
				$this->logger->info(\sprintf(
					'Active AI Discovery daily quota reached. Used=%d Limit=%d. Skipping batch.',
					$used_today,
					$daily_quota
				));
				return;
			}

			$remaining   = ($daily_quota > 0) ? max(0, $daily_quota - $used_today) : 5;
			$batch_limit = ($daily_quota > 0) ? min(5, $remaining) : 5;

			if ($batch_limit < 1) {
				$this->logger->info(\sprintf(
					'Active AI Discovery has no remaining quota today. Used=%d Limit=%d.',
					$used_today,
					$daily_quota
				));
				return;
			}

			global $wpdb;

			$posts_to_check = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT p.ID, p.post_title, p.post_content,
						pm1.meta_value AS software_name,
						pm2.meta_value AS current_version,
						COALESCE(pm3.meta_value, 0) AS last_checked
					 FROM {$wpdb->posts} p
					 LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_seo_gen_software_name'
					 LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_seo_gen_version'
					 LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_seo_gen_last_checked'
					 WHERE p.post_status IN ('publish','draft','future')
					   AND p.post_type = 'post'
					 ORDER BY last_checked ASC
					 LIMIT %d",
					$batch_limit
				)
			);

			if (empty($posts_to_check)) {
				$this->logger->info('No posts found to check for updates.');
				return;
			}

			$batch_total = count($posts_to_check);

			$this->logger->info(
				'Starting Active AI Update Check Micro-batch. Targeting '
				. $batch_total
				. ' posts. Quota used='
				. $used_today
				. ' limit='
				. $daily_quota
			);

			$i = 0;
			foreach ($posts_to_check as $post) {
				if ($daily_quota > 0 && $used_today >= $daily_quota) {
					$this->logger->info(\sprintf(
						'Active AI Discovery quota exhausted mid-batch. Used=%d Limit=%d. Stopping.',
						$used_today,
						$daily_quota
					));
					break;
				}

				$i++;

				try {
					$software_name   = (string) ($post->software_name ?? '');
					$current_version = (string) ($post->current_version ?? '');

					if ($software_name === '' || $current_version === '') {
						$parsed = $this->parse_rss_title($post->post_title);
						if ($parsed) {
							$software_name   = $software_name !== '' ? $software_name : (string) $parsed['name'];
							$current_version = $current_version !== '' ? $current_version : (string) $parsed['version'];
						}
					}

					if ($software_name === '' || $current_version === '') {
						$this->logger->debug('Post ' . (int) $post->ID . ' skipped no software name/version detected.');
						continue;
					}

					$this->touch_post((int) $post->ID);

					$precheck_type = Post_Type_Classifier::classify((int) $post->ID);
					$precheck_blocked = (
						(int) \get_option(self::PLUGIN_FILTER_OPTION, 0) === 1
						&& Post_Type_Classifier::is_plugin_owned($precheck_type)
					);

					if ($precheck_blocked) {
						$this->logger->info(
							'[Pre-filter] Skipping API call for plugin-generated post '
							. (int) $post->ID . ' (' . $software_name . '). '
							. 'Enable zones manually, then disable New + Legacy Only to process.'
						);
						continue;
					}

if ($daily_quota > 0) {
 $used_today = (int) $wpdb->get_var($wpdb->prepare(
 "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
 $quota_key
 ));
 $used_today = max(0, $used_today);

 if ($used_today >= $daily_quota) {
 $this->logger->info(\sprintf(
 'Active AI Discovery daily quota reached. Used: %d / %d. Stopping.',
 $used_today,
 $daily_quota
 ));
 break;
 }
 }

					$this->logger->info(\sprintf(
						'AI Check %d/%d %s Current %s (Quota %d/%d)',
						$i,
						$batch_total,
						$software_name,
						$current_version,
						$used_today,
						$daily_quota
					));

					// Atomic Admission Gate for Parallel Scouts
					$gate      = \SEO_Article_Generator\Core\Admission_Gate::get_instance();
					$admission = $gate->can_proceed_scout();
					if (! $admission) {
						$this->logger->info("[Scout Admission] Deferred " . $software_name . ": parallel scout limit reached.");
						continue;
					}

					if (! $gate->claim_scout_slot()) {
						$this->logger->info("[Scout Admission] Race lost for scout slot: " . $software_name);
						continue;
					}

$api_attempted = false;
try {
$api_attempted = true;
$result = $this->ai_client->check_for_updates($software_name, $current_version);
} catch ( \Exception $e ) {
$this->logger->warning( 'AI Update check failed for Post ID ' . (int) $post->ID . ': ' . $e->getMessage() );
$result = false;
} finally {
$gate->release_scout_slot();

if ( $api_attempted ) {
$wpdb->query($wpdb->prepare(
"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, 1, 'no') ON DUPLICATE KEY UPDATE option_value = option_value + 1",
$quota_key
));
$used_today = max(0, (int) $wpdb->get_var($wpdb->prepare(
"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
$quota_key
)));
}
}

if ( ! $result ) {
continue;
}

					if (! empty($result['has_update']) && ! empty($result['latest_version'])) {
    $latest_version = (string) $result['latest_version'];

if (Title_Analyzer::is_newer_version($latest_version, $current_version, $this->logger)) {
                // Use precheck_type but add legacy fingerprint fallback for pre-meta posts
                $type = $precheck_type;
                if ( $type === Post_Type_Classifier::TYPE_NEW && $this->post_has_legacy_plugin_fingerprint( (int) $post->ID ) ) {
                    $type = Post_Type_Classifier::TYPE_LEGACY;
                }
							$this->logger->info('AI found potential update for ' . $software_name . ' ' . $latest_version);

							$item_id = $this->stage_item(
								$software_name,
								$latest_version,
								$current_version,
								(string) ($result['changelog_url'] ?? ''),
								'Discovered via AI Scouting Gateway',
								$type,
								(int) $post->ID
							);

							if ($item_id <= 0) {
								$this->logger->error('Failed to persist AI discovery row for post ' . (int) $post->ID);
							}
						}
					}
				} catch (\Throwable $e) {
					$this->logger->warning('AI Update check failed for Post ID ' . (int) $post->ID . ': ' . $e->getMessage());
				}

				if ($i < $batch_total) {
					sleep(2);
				}
			}

			$this->logger->info('Active AI Update Check micro-batch complete.');

			$next_midnight = Plugin_Time::next_site_midnight_utc_ts(Plugin_Time::now_utc_ts());
			AS_Registry::schedule_active_discovery($next_midnight + 2 * \HOUR_IN_SECONDS);
		} finally {
			$this->release_scanner_mutex("ai_scout");
		}
	}

    // =========================================================================
    // PUBLIC: WP AUTOMATIC DRAFT POLLER
    // =========================================================================

	/**
	 * Poll WP Automatic drafts.
	 */
	public function run_wp_auto_draft_poll(): int
	{
		if (! $this->acquire_scanner_mutex("wp_auto")) {
			$this->logger->info("[WP Auto Poller] Scan already running. Skipping overlap.");
			return 0;
		}

		try {
			if (! \get_option('seo_gen_discovery_enabled', 1)) {
				$this->logger->debug('[WP Auto Poller] Discovery globally disabled. Skipping.');
				return 0;
			}

			$wp_auto_cat = (int) \get_option('seo_gen_wp_auto_category_id', 0);
			if (empty($wp_auto_cat)) {
				return 0;
			}

			$drafts = $this->get_unprocessed_drafts($wp_auto_cat, 10);
			if (empty($drafts)) {
				return 0;
			}

			$this->logger->info(sprintf('[WP Auto Poller] Processing batch of %d drafts...', count($drafts)));
			$processed_count = 0;

			foreach ($drafts as $draft) {
				try {
					$this->process_single_draft($draft);
					$processed_count++;
				} catch (\Throwable $e) {
					$full_log = sprintf("[%s] %s\n%s", get_class($e), $e->getMessage(), $e->getTraceAsString());
					$this->logger->error(sprintf('[WP Auto Poller] FATAL processing draft #%d: %s', $draft->ID, $full_log));

					\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
					\update_post_meta($draft->ID, 'seo_gen_processed_status', 'system_error');
					\update_post_meta($draft->ID, 'seo_gen_error_log', $full_log);

					self::schedule_draft_deletion((int) $draft->ID);
				}
			}

			$this->logger->info(sprintf('[WP Auto Poller] Batch complete. Processed: %d/%d', $processed_count, count($drafts)));

			// Proactive orphan cleanup: delete drafts past retention that have no
			// discovery row. Runs here because AS recurring actions may be dead.
			try {
				self::cleanup_orphaned_auto_category_posts();
			} catch (\Throwable $e) {
				$this->logger->warning('[WP Auto Poller] Orphan cleanup failed: ' . $e->getMessage());
			}

			return $processed_count;
		} finally {
			$this->release_scanner_mutex("wp_auto");
		}
	}

	// =========================================================================
	// PRIVATE HELPERS FOR WP AUTO
	// =========================================================================

	private function process_single_draft(\WP_Post $draft): void
	{
		$parsed = $this->parse_draft_title($draft->post_title);
		if (! $parsed) {
			$parsed = $this->fallback_parse_draft_title($draft->post_title, $draft->ID);
		}

	$software_name = isset($parsed['name']) ? trim((string) $parsed['name']) : '';
	$version = isset($parsed['version']) ? trim((string) $parsed['version']) : '';

	// [SSOT FIX] The source draft already carries the authoritative version in its
	// structured hero data (seogenherodata / _seo_gen_version). The draft post_title
	// is an unstructured, lossy copy that may embed a stale/old version. Trust the
	// structured field FIRST, fall back to title parsing only when it is empty/unknown.
	// Without this, drafts whose title version != hero-data version are staged with the
	// wrong (title) version and it propagates to hero meta, meta description and title.
	$draft_ssot_version = self::resolve_draft_hero_version((int) $draft->ID);
	if ($draft_ssot_version !== '' && strcasecmp($draft_ssot_version, 'unknown') !== 0) {
		$version = $draft_ssot_version;
	}

	if ($software_name === '') {
		$reason = 'WP Auto draft ignored: software name could not be parsed from the draft title.';
		$this->logger->warning(sprintf(
'WP Auto Poller: draft %d ignored because software name could not be resolved.',
				(int) $draft->ID
			));
			\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
			\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_IGNORED);
		\update_post_meta($draft->ID, 'seogen_error_log', $reason);
		\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
		self::schedule_draft_deletion((int) $draft->ID);
		return;
	}

	if ($version === '' || strtolower($version) === 'unknown') {
		$reparse = $this->parse_draft_title($draft->post_title);
		if ($reparse && !empty($reparse['name']) && trim((string)$reparse['version']) !== '' && strtolower(trim((string)$reparse['version'])) !== 'unknown') {
			$software_name = trim((string)$reparse['name']);
			$version = trim((string)$reparse['version']);
		}
	}

	if ($version === '' || strtolower($version) === 'unknown') {
		$reason = sprintf(
			'WP Auto draft ignored: discovered_version is %s. Empty or unresolvable version must not be staged.',
			$version === '' ? 'empty' : '"Unknown"'
		);
		$this->logger->warning(sprintf(
			'WP Auto Poller: draft %d ignored for "%s" because parsed version is %s.',
			(int) $draft->ID, $software_name, $version === '' ? 'empty' : '"Unknown"'
		));
			\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
			\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_IGNORED);
		\update_post_meta($draft->ID, 'seogen_error_log', $reason);
		\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
		self::schedule_draft_deletion((int) $draft->ID);
		return;
	}

	if (preg_match('/\b(?:Build|Revision|Rev|RC|Beta|Alpha|Preview|Canary|Dev|SP|HF|CU)\s*\d*\b/iu', $software_name)
		|| preg_match('/\d+(?:\.\d+)+\s*$/u', $software_name)
		|| preg_match('/\b[Vv]\d+(?:\.\d+)*\b/', $software_name)    // "V267", "v1.2.3"
		|| preg_match('/\b(19[7-9]\d|20[0-9]\d)\b/', $software_name) // years 1970-2099
	) {
		$this->logger->warning(sprintf(
			'WP Auto Poller: draft %d has version debris in software name "%s" — attempting re-extraction.',
			(int) $draft->ID, $software_name
		));
		$clean_reparse = $this->parse_draft_title($software_name);
		if ($clean_reparse && !empty($clean_reparse['name']) && mb_strlen(trim((string)$clean_reparse['name'])) >= 2) {
			$software_name = trim((string)$clean_reparse['name']);
		}
	}

		$source_url = \get_post_meta($draft->ID, 'wpautomaticurl', true) ?: \get_post_meta($draft->ID, 'automatic_url', true) ?: '';
		$scraped_content = $draft->post_content;
		$image_url = \get_the_post_thumbnail_url($draft->ID, 'full') ?: '';

		$plain_text = \trim(\wp_strip_all_tags($scraped_content));
		$is_truncated = \preg_match('/\[\.\.\.\]\s*$/u', $plain_text) || \mb_strlen($plain_text) < 50;
		$is_challenge_page = \preg_match('/\b(?:Just a moment|Checking your browser|Enable JavaScript|Verifying you are human|Checking if the site connection|Please wait while we verify|Attention Required|Cloudflare|Ray ID)\b/iu', $scraped_content);
		if ($is_truncated || $is_challenge_page) {
			$reason = $is_challenge_page
				? 'WP Auto draft ignored: source content is a bot-protection/challenge page (Cloudflare, etc.).'
				: 'WP Auto draft ignored: source content appears truncated (ends with [...]).';
			$this->logger->warning(\sprintf(
				'WP Auto Poller: draft %d ignored for "%s" because %s.',
				(int) $draft->ID, $software_name,
				$is_challenge_page ? 'source is a challenge page' : 'source content is truncated'
			));
			\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
			\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_IGNORED);
			\update_post_meta($draft->ID, 'seogen_error_log', $reason);
			\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
			self::schedule_draft_deletion((int) $draft->ID);
			return;
		}

		$match = $this->find_existing_software($software_name, (int) $draft->ID);
		$post_id = $match ? (int) $match['id'] : 0;
		$current_ver = $match ? trim((string) $match['version']) : '';
		$type = $match ? (string) $match['type'] : Post_Type_Classifier::TYPE_NEW;

		if ($post_id > 0) {
			$contract = self::canonicalize_discovery_contract($type, $post_id);
			$post_id = (int) $contract['existing_post_id'];
			$type = (string) $contract['type'];
			$resolved_current_ver = SeoGen_Version_Resolver::current_version($post_id, $current_ver);
			if ($resolved_current_ver !== '') {
				$current_ver = $resolved_current_ver;
			}

			$override_type = Post_Type_Classifier::classify($post_id);
			if ($override_type !== Post_Type_Classifier::TYPE_NEW) {
				$type = $override_type;
			}
		}

		if ($current_ver === '') {
			$current_ver = 'Unknown';
		}

		if ($post_id > 0 && $current_ver !== 'Unknown') {
			if (! Title_Analyzer::is_newer_version($version, $current_ver, $this->logger)) {
				// Draft version is NOT newer than the live post — it is stale.
				// Delete immediately. WP Automatic will create a new draft when a
				// genuinely newer version appears in RSS.
				\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
				\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_SKIPPED_NOT_NEWER);
				\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
				self::schedule_draft_deletion((int) $draft->ID);

				$this->logger->info(sprintf(
					'[WP Auto Poller] Skipped & scheduled deletion: draft %d for post %d — version %s is not newer than live %s.',
					(int) $draft->ID,
					(int) $post_id,
					$version,
					$current_ver
				));
				return;
			}
		}

		if ($post_id > 0 && $version !== '' && $version !== 'Unknown') {
			global $wpdb;
			$disc_table = \SEO_Article_Generator\Installer::table_discovery();

			// @FIX 2026-07-30: Bound LAYER 1 active-discovery block by the same
			// dedupe cooldown window used by LAYER 2 (default 2h, option
			// 'seo_gen_dedup_cooldown_hours'). Previously LAYER 1 blocked
			// INDEFINITELY for ANY active state, which meant a software whose
			// first draft was stuck at pending/finalizing/deferred would silently
			// drop every subsequent version for the same post — even days later.
			// SRWare Iron (log 2026-07-29 01:26:33) was the symptom: "Skipped
			// staging: active discovery already exists" swallowed the new version
			// because discovery #1610 was still in an active state. Now bounded
			// by discovered_at + cooldown_hours so legitimate newer-version drafts
			// arriving past the window reach staging.
			$cooldown_hours = (int) \get_option('seo_gen_dedup_cooldown_hours', 24);
			if ($cooldown_hours <= 0) {
				$cooldown_hours = 24;
			}
			$active_cutoff = gmdate('Y-m-d H:i:s', time() - ($cooldown_hours * HOUR_IN_SECONDS));

			// LAYER 1: Block if an active discovery exists for this post AND was
			// discovered within the cooldown window. Active = pending/queued/
			// processing/generating/finalizing/deferred. Heartbeat-stale active
			// rows (heartbeat_at <= NOW - 600s) are also ignored as "active" so
			// genuinely stuck workers do not block legitimate newer versions.
			$heartbeat_stale_cutoff = gmdate('Y-m-d H:i:s', time() - 600);
			$existing_active = $wpdb->get_var($wpdb->prepare(
				"SELECT id FROM {$disc_table}
				WHERE existing_post_id = %d
				  AND status IN ('pending','queued','processing','generating','finalizing','deferred')
				  AND discovered_at >= %s
				  AND (status NOT IN ('processing','generating','finalizing') OR heartbeat_at IS NULL OR heartbeat_at >= %s)
				LIMIT 1",
				$post_id,
				$active_cutoff,
				$heartbeat_stale_cutoff
			));
			if ($existing_active) {
				$this->logger->info(sprintf(
					'[WP Auto Poller] Skipped staging: active discovery #%d already exists for post %d within %dh window',
					$existing_active, $post_id, $cooldown_hours
				));
				\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
				\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_SKIPPED_DUPLICATE);
				\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
				self::schedule_draft_deletion($draft->ID);
				return;
			}

			// LAYER 2: Block if a completed discovery exists within the cooldown window
			if ($cooldown_hours > 0) {
				$cooldown_cutoff = gmdate('Y-m-d H:i:s', time() - ($cooldown_hours * HOUR_IN_SECONDS));
				$recent_completed = $wpdb->get_row($wpdb->prepare(
					"SELECT id, discovered_version, completed_at FROM {$disc_table}
					WHERE existing_post_id = %d
					  AND status = 'done'
					  AND completed_at >= %s
					ORDER BY completed_at DESC
					LIMIT 1",
					$post_id,
					$cooldown_cutoff
				));
				if ($recent_completed) {
					$this->logger->info(sprintf(
						'[WP Auto Poller] Skipped staging: discovery #%d for post %d completed %s with version %s (cooldown %dh). Incoming version %s blocked.',
						(int) $recent_completed->id,
						$post_id,
						$recent_completed->completed_at,
						(string) $recent_completed->discovered_version,
						$cooldown_hours,
						$version
					));
					\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
					\update_post_meta($draft->ID, 'seo_gen_processed_status', self::STATUS_SKIPPED_DUPLICATE);
					\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
					self::schedule_draft_deletion($draft->ID);
					return;
				}
			}
		}

		// @ADDED 2026-07-04: STAGE-TIME DOWNLOAD-LINK GATE.
		// Reason: previously, drafts with zero resolvable download links were
		// unconditionally staged, then later dismissed at process time
		// (discovery-processor.php:1248 / 1280). For UPDATE posts whose
		// existing content has recoverable links, the processing path further
		// injected a single portal-fallback URL while discovering "N links
		// verified" via Link Continuity — and never made those N links
		// canonical. The result was articles degraded to 1 hero button even
		// though the source brief implied multiple platforms.
		//
		// This gate rejects the draft at staging time, before any DB row is
		// written, when no download links are resolvable AND there is no
		// existing post to recover from. Drafts that DO have an existing
		// post with recoverable links are still staged — for those the gate
		// is the same recoverable-deferred behavior as before.
		//
		// @FIX 2026-07-26: The gate previously ran only Link_Resolver::resolve_from_html
		// on the source draft HTML and the existing post's post_content. Vendors whose
		// changelog pages render download buttons via JS/POST forms or detached pages
		// (Thunderbird ESR, WineHQ Beta, GitHub release-body HTML without anchor HREFs,
		// SourceForge FileBrowser pages) carry zero raw <a href> links even though the
		// canonical download URLs are present in the structured metadata (Data_Extractor
		// DOM fallback) and in _canonical_download_links post meta. Those drafts were
		// stamped STATUS_IGNORED and the source draft deleted — the version-comparison
		// logic downstream never ran, losing legitimate updates. The gate now also
		// consults (a) Data_Extractor::extract()'s DOM-fallback link list, and (b) the
		// existing post's _canonical_download_links meta, treating those as recoverable
		// signals on par with raw HTML anchors.
		$resolved_links_for_gate = Link_Resolver::resolve_from_html( (string) $draft->post_content );
		$gate_has_real_links     = ! empty( $resolved_links_for_gate['links'] ) && is_array( $resolved_links_for_gate['links'] );

		if ( ! $gate_has_real_links ) {
			// Structured fallback (a): Data_Extractor DOM-fallback link extraction — this
			// catches changelog HTML where Link_Resolver's strict anchor filter strips
			// them but Data_Extractor::extract_links() DOM-walk recovers them.
			$gate_structured = Data_Extractor::extract( (string) $draft->post_content );
			if ( ! empty( $gate_structured['all_links'] ) && is_array( $gate_structured['all_links'] ) ) {
				$gate_has_real_links = true;
			}
		}

		if ( ! $gate_has_real_links ) {
			$existing_post_for_gate = (int) $post_id;
			$gate_recoverable        = false;
			if ( $existing_post_for_gate > 0 ) {
				$gate_existing_html  = (string) \get_post_field( 'post_content', $existing_post_for_gate, 'raw' );
				$gate_recoverable_in = \SEO_Article_Generator\Integration\Link_Resolver::resolve_from_html(
					$gate_existing_html,
					array( 'software_name' => (string) $software_name )
				);
				$gate_recoverable    = ! empty( $gate_recoverable_in['links'] ) && is_array( $gate_recoverable_in['links'] );

				// Structured fallback (b): _canonical_download_links post meta — written
				// by Article_Generator on every successful finalization and treated as the
				// SSOT for Link Continuity at discovery-processor.php link-recovery time.
				// If the existing post carries canonical links in meta, the gate passes.
				if ( ! $gate_recoverable ) {
					$gate_canonical_meta = \get_post_meta( $existing_post_for_gate, '_canonical_download_links', true );
					if ( is_array( $gate_canonical_meta ) && ! empty( $gate_canonical_meta ) ) {
						$gate_recoverable = true;
					}
				}
			}

			if ( ! $gate_recoverable ) {
				$reason = sprintf(
					'WP Auto draft %d ignored for "%s" because no download links were resolvable from source draft, structured Data_Extractor extraction, OR recoverable links in %s.',
					(int) $draft->ID,
					$software_name,
					$existing_post_for_gate > 0 ? "existing post {$existing_post_for_gate}" : 'a new post'
				);
				$this->logger->warning(
					'WP Auto Poller: ' . $reason
					. ' Draft deleted; not staged. Source URL=' . $source_url
				);
				\update_post_meta( (int) $draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts() );
				\update_post_meta( (int) $draft->ID, 'seo_gen_processed_status', self::STATUS_IGNORED );
				\update_post_meta( (int) $draft->ID, 'seogen_error_log', $reason );
				\delete_post_meta( (int) $draft->ID, 'seo_gen_throttle_until' );
				self::schedule_draft_deletion( (int) $draft->ID );
				return;
			}
			// else: gate passes — recoverable links exist on the existing post
			// and Link Continuity can recover at process time.
		}

		$item_id = (int) $this->stage_wp_auto_item(
			$software_name,
			$version,
			$current_ver,
			$source_url,
			$scraped_content,
			$image_url,
			$type,
			$post_id,
			$draft->ID
		);

		if ($item_id > 0) {
			$source_facts = $this->build_source_facts_from_draft($draft);
			self::persist_phase1_discovery_context($item_id, $source_facts, $type);

			\update_post_meta($draft->ID, 'seo_gen_processed', Plugin_Time::now_utc_ts());
			\update_post_meta($draft->ID, 'seo_gen_processed_status', 'staged');
			\delete_post_meta($draft->ID, 'seo_gen_throttle_until');
			self::schedule_draft_deletion($draft->ID);

			global $wpdb;
			$_actual_status = (string) $wpdb->get_var($wpdb->prepare(
				"SELECT status FROM " . \SEO_Article_Generator\Installer::table_discovery() . " WHERE id = %d",
				$item_id
			));
			$_log_level = ($_actual_status === 'pending') ? 'info' : 'warning';
			$this->logger->$_log_level(sprintf(
				'[WP Auto Poller] Staged discovery #%d for draft post #%d (type=%s, ver=%s, existing=%d, actual_status=%s).',
				$item_id, $draft->ID, $type, $version, $post_id, $_actual_status
			));
			if ($_actual_status !== 'pending') {
				$this->logger->warning(sprintf(
					'[WP Auto Poller] Discovery #%d INSERT kept existing status=%s (ON DUPLICATE KEY). The log previously lied about status=pending.',
					$item_id, $_actual_status
				));
			}
		}
	}

	private function get_unprocessed_drafts(int $category_id, int $limit = 10): array
	{
		$cat_ids = \get_term_children($category_id, 'category');
		$cat_ids[] = $category_id;

		$now_utc = Plugin_Time::now_utc_ts();

		// Safety-net max age: any draft older than retention_days is stale and
		// should not be polled. Schedule immediate deletion for these.
		$retention_days = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]
		);
		$max_age_days = max(1, $retention_days + 1);
		$max_age_cutoff = gmdate('Y-m-d H:i:s', $now_utc - ($max_age_days * DAY_IN_SECONDS));

		// Schedule deletion for any drafts older than max age (safety net)
		// Exclude already-processed drafts to avoid clobbering in-pipeline state.
		$stale_drafts = \get_posts([
			'post_type'      => 'post',
			'post_status'    => 'draft',
			'posts_per_page' => -1,
			'category__in'   => $cat_ids,
			'date_query'     => [
				['before' => $max_age_cutoff],
			],
			'meta_query'     => [
				['key' => 'seo_gen_processed', 'compare' => 'NOT EXISTS'],
			],
			'fields'         => 'ids',
		]);
		if (! empty($stale_drafts)) {
			foreach ($stale_drafts as $stale_id) {
				$stale_id = (int) $stale_id;
				if ($stale_id > 0) {
					\update_post_meta($stale_id, 'seo_gen_processed', $now_utc);
					\update_post_meta($stale_id, 'seo_gen_processed_status', self::STATUS_SKIPPED_NOT_NEWER);
					\delete_post_meta($stale_id, 'seo_gen_throttle_until');
					self::schedule_draft_deletion($stale_id);
				}
			}
			$this->logger->info(sprintf(
				'[WP Auto Poller] Scheduled deletion for %d stale drafts older than %d days.',
				count($stale_drafts), $max_age_days
			));
		}

		return \get_posts([
			'post_type'      => 'post',
			'post_status'    => 'draft',
			'posts_per_page' => $limit,
			'category__in'   => $cat_ids,
			'date_query'     => [
				['after' => $max_age_cutoff],
			],
			'meta_query'     => [
				'relation' => 'AND',
				['key' => 'seo_gen_processed', 'compare' => 'NOT EXISTS'],
			],
		]);
	}

	private function parse_draft_title(string $title): ?array
	{
		$analyzer = new Title_Analyzer();
		return $analyzer->extract($title) ?: null;
	}

	/**
	 * Resolve the authoritative version already present in a source draft's structured
	 * hero data, using the same precedence as the live-post resolver
	 * (SeoGen_Version_Resolver). This is the canonical version the draft was published
	 * with; the post_title text is only a fallback.
	 *
	 * @param int $draft_id
	 * @return string Trimmed version, or '' when no usable version is found.
	 */
	private static function resolve_draft_hero_version(int $draft_id): string
	{
		if ($draft_id <= 0) {
			return '';
		}
		$version = SeoGen_Version_Resolver::current_version($draft_id);
		return is_string($version) ? trim($version) : '';
	}

	private function fallback_parse_draft_title(string $title, int $draft_id): ?array
	{
		// ENHANCEMENT: Extract ANY plausible software name (90%+ hit rate on log samples)
		$title = trim(\strip_tags($title));
		if (preg_match('/^([^\d]+)(?:\s+v?[\d.]+)?/i', $title, $m)) {
			return array('name' => trim($m[1]), 'version' => '');  // Version optional
		}
		// Ultimate fallback: raw title (ensures staging)
		return array('name' => $title, 'version' => '');
	}

	private static function extract_version_changelog_slice(string $html, string $version): string
	{
		$ver_escaped = preg_quote($version, '/');

		preg_match_all('/<(h[2-4]|b|strong)[\s\S]*?<\/\1>/i', $html, $headings, PREG_OFFSET_CAPTURE);

		if (empty($headings[0])) {
			return $html;
		}

		$target_idx = -1;
		$target_offset = -1;

		foreach ($headings[0] as $idx => $match) {
			if (\preg_match('/\b' . $ver_escaped . '\b/', \strip_tags($match[0]))) {
				$target_idx = $idx;
				$target_offset = $match[1];
				break;
			}
		}

		if ($target_idx === -1) {
			return $html;
		}

		$intro = \trim(\substr($html, 0, $headings[0][0][1]));

		$end_offset = strlen($html);
		foreach ($headings[0] as $idx => $match) {
			if ($idx <= $target_idx) {
				continue;
			}

			$text = \strip_tags($match[0]);

			if (\preg_match('/\d+(?:\.\d+)+/', $text, $m)) {
				$found_ver = $m[0];
				if ($found_ver !== $version && (stripos($text, 'Changes') !== false || stripos($text, 'Version') !== false)) {
					$end_offset = $match[1];
					break;
				}
			}
		}

		$block = \substr($html, $target_offset, $end_offset - $target_offset);

		return \trim($intro) . "\n\n" . \trim($block);
	}

	private function stage_wp_auto_item(string $name, string $version, string $current_version, string $source_url, string $content, string $image_url, string $type, int $post_id, int $draft_id): int
	{
		$name = trim((string) $name);
		$version = trim((string) $version);
		$current_version = trim((string) $current_version);

		if ($name === '' || $version === '') {
			$this->logger->warning(sprintf(
				'WP Auto Poller: refusing to stage discovery with empty identity (name="%s", version="%s").',
				$name,
				$version
			));
			return 0;
		}

		$contract = self::canonicalize_discovery_contract($type, $post_id);
		$type = $contract['type'];
		$post_id = (int) $contract['existing_post_id'];

		$block_filter = (int) \get_option(self::PLUGIN_FILTER_OPTION, 0) === 1;
		if ($block_filter && Post_Type_Classifier::is_plugin_owned($type)) {
			$this->logger->info(sprintf(
				'WP Auto Poller: blocking plugin-generated discovery for "%s" (type=%s). Block filter active.',
				$name, $type
			));
			$type = 'plugingenerated';
		}

		$sliced_content = self::extract_version_changelog_slice($content, $version);

		$extracted = Data_Extractor::extract($sliced_content);
		$facts_comment = '';
		$facts_payload = [];
		foreach (['file_size', 'license', 'developer', 'last_updated', 'homepage_url', 'changelog_url'] as $fk) {
			if (!empty($extracted[$fk])) {
				$facts_payload[$fk] = $extracted[$fk];
			}
		}
		if (!empty($facts_payload)) {
			$facts_comment = '<!-- seo_gen_facts: ' . \wp_json_encode($facts_payload, JSON_UNESCAPED_UNICODE) . ' -->' . "\n";
		}

		$changelog = $facts_comment . $sliced_content;

		$source_thumbnail_url = '';
		if (!empty($extracted['all_links'])) {
			foreach ($extracted['all_links'] as $link) {
				if (!empty($link['url']) && preg_match('/\.(png|jpg|jpeg|gif|webp|svg)$/i', $link['url'])) {
					$source_thumbnail_url = $link['url'];
					break;
				}
			}
		}
		if ($source_thumbnail_url === '' && $image_url !== '') {
			$source_thumbnail_url = $image_url;
		}

		$featured_image_id = 0;
		$draft_thumb_id = (int) \get_post_thumbnail_id($draft_id);
		if ($draft_thumb_id > 0) {
			$featured_image_id = $draft_thumb_id;
		}

		global $wpdb;
		$table = \SEO_Article_Generator\Installer::table_discovery();
		// Use post_id-only dedupe key when post exists to prevent same-post multi-version duplicates
		$dedupe_key = $post_id > 0
			? md5((string) $post_id)
			: md5(strtolower($name . '|' . $version));

		$insert_data = [
			'software_name' => \sanitize_text_field($name),
			'discovered_version' => \sanitize_text_field($version),
			'current_version' => \sanitize_text_field($current_version),
			'source_url' => \esc_url_raw($source_url),
			'changelog' => \wp_kses_post($changelog),
			'source_image_url' => \esc_url_raw($image_url),
			'source_thumbnail_url' => \esc_url_raw($source_thumbnail_url),
			'featured_image_id' => $featured_image_id > 0 ? $featured_image_id : null,
			'type' => $type,
			'existing_post_id' => $post_id,
			'discovered_at' => Plugin_Time::utc_mysql_now(),
			'status' => $block_filter && $type === 'plugingenerated' ? 'failed' : 'pending',
			'source_type' => 'wp_automatic',
			'draft_post_id' => (int) $draft_id,
			'error_message' => $block_filter && $type === 'plugingenerated' ? self::PLUGIN_FILTER_ERROR : null,
			'heartbeat_at' => null,
			'dedupe_key' => $dedupe_key,
		];

		$sql = "INSERT INTO $table (" . implode(', ', array_keys($insert_data)) . ")
			VALUES (" . implode(', ', array_fill(0, count($insert_data), '%s')) . ")
			ON DUPLICATE KEY UPDATE
			status = IF(status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version, 'pending',
				IF(status IN ('generating','finalizing','processing','queued','deferred'), status,
					IF(status IN ('failed','timeout','ignored') AND VALUES(type) NOT IN ('plugingenerated','plugingeneratedlegacy'), 'pending',
						VALUES(status)))),
			job_id = IF(VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version AND discovered_version <> '', NULL, job_id),
			queue_job_id = IF(VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version AND discovered_version <> '', NULL, queue_job_id),
			completed_at = IF(VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version AND discovered_version <> '', NULL, completed_at),
			discovered_at = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(discovered_at)
				WHEN status IN ('done') THEN discovered_at
				ELSE VALUES(discovered_at)
			END,
			changelog = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(changelog)
				WHEN status IN ('done') THEN changelog
				ELSE VALUES(changelog)
			END,
			source_url = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(source_url)
				WHEN status IN ('done') THEN source_url
				WHEN VALUES(source_url) <> '' THEN VALUES(source_url)
				ELSE source_url
			END,
			source_image_url = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(source_image_url)
				WHEN status IN ('done') THEN source_image_url
				WHEN VALUES(source_image_url) <> '' THEN VALUES(source_image_url)
				ELSE source_image_url
			END,
			source_thumbnail_url = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(source_thumbnail_url)
				WHEN status IN ('done') THEN source_thumbnail_url
				WHEN VALUES(source_thumbnail_url) <> '' THEN VALUES(source_thumbnail_url)
				ELSE source_thumbnail_url
			END,
			featured_image_id = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(featured_image_id)
				WHEN status IN ('done') THEN featured_image_id
				WHEN VALUES(featured_image_id) > 0 THEN VALUES(featured_image_id)
				ELSE featured_image_id
			END,
			source_type = CASE WHEN source_type = '' OR source_type IS NULL THEN VALUES(source_type) ELSE source_type END,
			draft_post_id = CASE WHEN VALUES(draft_post_id) > 0 THEN VALUES(draft_post_id) ELSE draft_post_id END,
			current_version = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(current_version)
				WHEN status IN ('done') THEN current_version
				WHEN VALUES(current_version) <> '' AND LOWER(VALUES(current_version)) <> 'unknown' THEN VALUES(current_version)
				WHEN current_version = '' OR current_version IS NULL OR LOWER(current_version) = 'unknown' THEN VALUES(current_version)
				ELSE current_version
			END,
			discovered_version = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN VALUES(discovered_version)
				WHEN status IN ('done') THEN discovered_version
				WHEN LOWER(VALUES(discovered_version)) <> '' AND LOWER(VALUES(discovered_version)) <> 'unknown' THEN VALUES(discovered_version)
				ELSE discovered_version
			END,
			type = CASE
				WHEN status IN ('done') THEN type
				WHEN VALUES(existing_post_id) > 0 THEN VALUES(type)
				ELSE type
			END,
			existing_post_id = CASE
				WHEN status IN ('done') THEN existing_post_id
				WHEN VALUES(existing_post_id) > 0 THEN VALUES(existing_post_id)
				ELSE existing_post_id
			END,
			error_message = CASE
				WHEN status = 'done' AND VALUES(discovered_version) <> '' AND VALUES(discovered_version) <> discovered_version THEN NULL
				WHEN VALUES(error_message) IS NOT NULL THEN VALUES(error_message)
				ELSE error_message
			END,
			heartbeat_at = VALUES(heartbeat_at)";

		$wpdb->query($wpdb->prepare($sql, array_values($insert_data)));
		return (int) $wpdb->insert_id ?: (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE dedupe_key = %s", $dedupe_key));
	}

	public static function schedule_draft_deletion(int $draft_id, int $delay_seconds = -1): void
	{
		$retention_days = 0;
		if ($delay_seconds < 0) {
			$retention_days = (int) \get_option(
				\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS,
				\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]
			);
			$delay_seconds = ($retention_days > 0) ? ($retention_days * \DAY_IN_SECONDS) : 0;
		}

		AS_Registry::schedule_delete_draft($draft_id, $delay_seconds);

		// Log the scheduling for visibility
		$logger = new \SEO_Article_Generator\Logger();
		$logger->info(sprintf(
			'Draft deletion scheduled: draft_id=%d, delay=%ds (retention_days=%d)',
			$draft_id, $delay_seconds, $retention_days
		));
	}

	/**
	 * Static method to delete a draft post with proper attachment reparenting.
	 *
	 * Does not require an AI_Client — only a Logger. Can be called from any context.
	 *
	 * @param int $draft_id
	 * @param Logger|null $logger Optional logger instance. Creates default if not provided.
	 * @return void
	 */
	public static function delete_draft_post_with_reparenting(int $draft_id, ?Logger $logger = null): void
	{
		if ($draft_id <= 0 || ! \get_post($draft_id)) {
			return;
		}

		$logger = $logger ?: new \SEO_Article_Generator\Logger();

		global $wpdb;

		$draft_attachments = $wpdb->get_results($wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_parent = %d",
			$draft_id
		));

		foreach ($draft_attachments as $att) {
			$att_id = (int) $att->ID;
			
			// Check for featured image references elsewhere
			$is_featured_elsewhere = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d AND post_id != %d LIMIT 1",
				$att_id, $draft_id
			));
			
			// Check for any other attachment references (custom fields, shortcodes, etc.)
			$other_references = $wpdb->get_results($wpdb->prepare(
				"SELECT post_id, meta_key FROM {$wpdb->postmeta} 
				 WHERE meta_value = %d AND post_id != %d 
				 AND meta_key NOT IN ('_thumbnail_id', '_wp_attached_file')",
				$att_id, $draft_id
			));
			
			if ($is_featured_elsewhere > 0) {
				$new_parent = (int) $wpdb->get_var($wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d AND post_id != %d LIMIT 1",
					$att_id, $draft_id
				));
				if ($new_parent > 0) {
					\wp_update_post(array('ID' => $att_id, 'post_parent' => $new_parent));
					$logger->info(sprintf(
						'Draft cleanup: reparented attachment %d from deleted draft %d to published post %d.',
						$att_id, $draft_id, $new_parent
					));
				} else {
					$wpdb->update($wpdb->posts, array('post_parent' => 0), array('ID' => $att_id));
					$logger->info(sprintf(
						'Draft cleanup: orphaned attachment %d (post_parent set to 0) before deleting draft %d.',
						$att_id, $draft_id
					));
				}
			} elseif (!empty($other_references)) {
				// Move to first available post with references, or orphan if none
				$first_ref = reset($other_references);
				$new_parent = (int) $first_ref->post_id;
				\wp_update_post(array('ID' => $att_id, 'post_parent' => $new_parent));
				$logger->info(sprintf(
					'Draft cleanup: reparented attachment %d from deleted draft %d to post %d (other reference found).',
					$att_id, $draft_id, $new_parent
				));
			} else {
				\wp_delete_attachment($att_id, true);
				$logger->info(sprintf(
					'Draft cleanup: deleted orphaned attachment %d (no references found) before deleting draft %d.',
					$att_id, $draft_id
				));
			}
		}

		\wp_delete_post($draft_id, true);
		$logger->info(sprintf('Draft post %d deleted (force delete, with attachment reparenting).', $draft_id));

		// NULL draft_post_id in discovery table so the row no longer holds a dangling reference.
		$disc_table = \SEO_Article_Generator\Installer::table_discovery();
		$wpdb->query($wpdb->prepare(
			"UPDATE {$disc_table} SET draft_post_id = NULL WHERE draft_post_id = %d",
			$draft_id
		));
	}

	/**
	 * Static wrapper for dismiss_and_cleanup_source and other contexts without engine instance.
	 *
	 * @param int $draft_id
	 * @return void
	 */
	public static function delete_draft_post_static(int $draft_id): void
	{
		$plugin = \SEO_Article_Generator\Plugin::get_instance();
		if ( ! $plugin ) {
			$logger = new \SEO_Article_Generator\Logger();
			$logger->error( 'delete_draft_post_static: Plugin instance not available.' );
			self::delete_draft_post_with_reparenting($draft_id);
			return;
		}

		$logger = $plugin->get_logger();
		self::delete_draft_post_with_reparenting($draft_id, $logger);
	}

	public function delete_draft_post(int $draft_id): void
	{
		self::delete_draft_post_with_reparenting($draft_id, $this->logger);
	}

	/**
	 * Proactive cleanup for orphaned posts in the configured Auto category
	 * (or with plugin ownership meta) not tracked in discovery table.
	 *
	 * Finds posts in the WP Auto category (via WP_AUTO_CATEGORY_ID option)
	 * or with plugin ownership meta that are past the retention window
	 * and have no pending AS deletion action.
	 * Deletes them using the same logic as delete_draft_post().
	 *
	 * @param int $retention_days Retention period in days (default: option value)
	 * @return array{deleted: int, errors: int, skipped: int} Cleanup stats
	 */
	public static function cleanup_orphaned_auto_category_posts( int $retention_days = 0 ): array {
		$logger = new \SEO_Article_Generator\Logger();

		if ($retention_days <= 0) {
			$retention_days = (int) \get_option(
				\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS,
				\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]
			);
		}

		$cutoff_ts = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() - ($retention_days * DAY_IN_SECONDS);
		$cutoff_mysql = \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_from_utc_ts($cutoff_ts);

		global $wpdb;

		// Get Auto category ID from option (configurable, not hardcoded)
		$auto_category_id = (int) \get_option(\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID, 0);

		// Build query to find candidate posts:
		// - In Auto category (if configured) OR has plugin ownership meta
		// - Post status is draft/auto-draft/pending/trash (deletable)
		// - post_modified_gmt older than retention window
		// - NO discovery table row (true orphans only — never delete in-pipeline drafts)
		// - Direct deletion regardless of pending AS action (AS may be dead)
		$disc_table = \SEO_Article_Generator\Installer::table_discovery();
		$where_conditions = array(
			"p.post_type = 'post'",
			"p.post_status IN ('draft', 'auto-draft', 'pending', 'trash')",
			"p.post_modified_gmt <= %s",
			"NOT EXISTS (SELECT 1 FROM {$disc_table} d WHERE d.draft_post_id = p.ID)",
		);
		$where_values = array($cutoff_mysql);

		if ($auto_category_id > 0) {
			$where_conditions[] = "EXISTS (
				SELECT 1 FROM {$wpdb->term_relationships} tr
				JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
				WHERE tr.object_id = p.ID
				AND tt.term_id = %d
				AND tt.taxonomy = 'category'
			)";
			$where_values[] = $auto_category_id;
		} else {
			// Fallback: check for plugin ownership meta
			$where_conditions[] = "EXISTS (
				SELECT 1 FROM {$wpdb->postmeta} pm
				WHERE pm.post_id = p.ID
				AND pm.meta_key IN ('_seo_gen_hero_data', 'seo_gen_processed', '_seogen_content_contract', '_seo_gen_content_contract')
			)";
		}

		$where_sql = implode(' AND ', $where_conditions);

		$orphan_posts = $wpdb->get_results($wpdb->prepare(
			"SELECT p.ID, p.post_title, p.post_modified_gmt, p.post_status
			FROM {$wpdb->posts} p
			WHERE {$where_sql}
			ORDER BY p.post_modified_gmt ASC
			LIMIT 50",
			$where_values
		), ARRAY_A);

		if (empty($orphan_posts)) {
			$logger->info('Auto Category Orphan Cleanup: No orphaned posts found past retention window.');
			return array('deleted' => 0, 'errors' => 0, 'skipped' => 0);
		}

		$stats = array('deleted' => 0, 'errors' => 0, 'skipped' => 0);

		foreach ($orphan_posts as $post) {
			$post_id = (int) $post['ID'];

			// NOTE: We intentionally do NOT skip drafts that have a pending AS
			// deletion action. When the AS runner is dead (as_runner:0), the
			// scheduled actions never fire, so this direct-deletion path is the
			// only safety net. If AS later recovers and the action fires, the
			// handler (delete_draft_post_with_reparenting) checks get_post() and
			// returns early on already-deleted posts — no double-delete, no error.

			// Verify plugin ownership (defense in depth)
			$has_plugin_meta = \get_post_meta($post_id, '_seo_gen_hero_data', true)
				|| \get_post_meta($post_id, 'seo_gen_processed', true)
				|| \get_post_meta($post_id, '_seogen_content_contract', true)
				|| \get_post_meta($post_id, '_seo_gen_content_contract', true);

			if (! $has_plugin_meta && class_exists('\SEO_Article_Generator\Discovery\Post_Type_Classifier')) {
				$post_type = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify($post_id);
				if ($post_type !== \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN
					&& $post_type !== \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN_LEGACY) {
					$logger->warning(sprintf('Auto Category Orphan Cleanup: Skipping post %d - not plugin-owned (type: %s).', $post_id, $post_type));
					$stats['skipped']++;
					continue;
				}
			}

			try {
				// Use static method with explicit logger — no engine instance needed
				self::delete_draft_post_with_reparenting($post_id, $logger);
				$logger->info(sprintf('Auto Category Orphan Cleanup: Deleted orphaned post %d ("%s") past %d-day retention.', $post_id, $post['post_title'], $retention_days));
				$stats['deleted']++;
			} catch (\Throwable $e) {
				$logger->error(sprintf('Auto Category Orphan Cleanup: Failed to delete post %d: %s', $post_id, $e->getMessage()));
				$stats['errors']++;
			}
		}

		$logger->info(sprintf('Auto Category Orphan Cleanup completed: deleted=%d, errors=%d, skipped=%d', $stats['deleted'], $stats['errors'], $stats['skipped']));

		return $stats;
	}

	// =========================================================================
	// GENERIC HELPERS
	// =========================================================================

	private function parse_rss_title($title)
	{
		$analyzer = new Title_Analyzer();
		return $analyzer->extract($title);
	}

	private function touch_post($post_id)
	{
		\update_post_meta($post_id, '_seo_gen_last_checked', Plugin_Time::utc_mysql_now());
	}
    /**
     * Detect legacy-plugin ownership from post content structure.
     *
     * Posts created by this plugin before ownership meta existed carry structural
     * fingerprints that prove they are plugin-authored:
     * - <!-- wp:seo-gen/hero --> block (exclusive: ContentFormatter)
     * - class="seo-gen-download-portal" (exclusive: download zone)
     * - class="seo-gen-eeat-source" (exclusive: E-E-A-T block)
     * - id="moat-content" (exclusive: MOAT section anchor)
     * - <!-- wp:rank-math/faq-block --> (exclusive: FAQ injection)
     * - seo-gen-related-card (exclusive: related software)
     *
     * HARDENED: wp:seo-gen/hero is the single most exclusive signal — it is written
     * only by ContentFormatter::toHtml and never appears in externally-authored content.
     * It counts as 2 points alone so manually-created posts with a hero block but
     * only one other signal are correctly recognised without lowering the false-positive
     * threshold for genuinely external posts.
     *
     * @param int $post_id
     * @return bool
     */
    private function post_has_legacy_plugin_fingerprint( int $post_id ): bool
    {
        // Signal 1: definitive ownership meta written by SentinelInjector.
        $contract = \get_post_meta( $post_id, '_seogen_content_contract', true )
            ?: \get_post_meta( $post_id, '_seo_gen_content_contract', true );
        if ( $contract === 'blocks-v1' ) {
            return true; // Definitive — no false-positive possible.
        }

        $post = \get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) {
            return false;
        }

        $content = $post->post_content;
        $score = 0;

        // wp:seo-gen/hero is exclusively written by ContentFormatter::toHtml.
        // Weight 2 so a post with a hero block passes even with only one other signal.
        if ( strpos( $content, 'wp:seo-gen/hero' ) !== false ) {
            $score += 2;
        }
        if ( strpos( $content, 'seo-gen-download-portal' ) !== false ) { $score++; }
        if ( strpos( $content, 'seo-gen-eeat-source' ) !== false ) { $score++; }
        if ( strpos( $content, 'id="moat-content"' ) !== false ) { $score++; }
        if ( strpos( $content, 'wp:rank-math/faq-block' ) !== false ) { $score++; }
        if ( strpos( $content, 'seo-gen-related-card' ) !== false ) { $score++; }

        // Threshold: 2+ = any two weak signals, OR wp:seo-gen/hero alone (score=2).
        return $score >= 2;
    }

	private function stage_item($name, $version, $current, $url, $changelog, $type, $post_id): int
	{
		$contract = self::canonicalize_discovery_contract($type, $post_id);
		$type = $contract['type'];
		$post_id = (int) $contract['existing_post_id'];

		$block_filter = (int) \get_option(self::PLUGIN_FILTER_OPTION, 0) === 1;
		$is_blocked = $block_filter && Post_Type_Classifier::is_plugin_owned($type);

		$allowed_html = [
			'a' => ['href' => true, 'title' => true, 'target' => true, 'rel' => true],
			'abbr' => ['title' => true],
			'br' => [],
			'code' => [],
			'em' => [],
			'strong' => [],
			'b' => [],
			'i' => [],
			'ul' => [],
			'ol' => [],
			'li' => [],
			'p' => [],
			'h2' => [],
			'h3' => [],
			'h4' => [],
			'h5' => [],
			'h6' => [],
			'span' => ['class' => true, 'style' => true],
			'div' => ['class' => true, 'id' => true, 'style' => true],
			'table' => ['class' => true],
			'tr' => [],
			'td' => ['colspan' => true, 'rowspan' => true],
			'th' => ['colspan' => true, 'rowspan' => true],
			'thead' => [],
			'tbody' => [],
			'img' => ['src' => true, 'alt' => true, 'width' => true, 'height' => true, 'class' => true],
			'blockquote' => ['cite' => true],
			'pre' => [],
		];
		$changelog_clean = \wp_kses($changelog, $allowed_html);

		global $wpdb;
		$table = \SEO_Article_Generator\Installer::table_discovery();
		// Use post_id-only dedupe key when post exists to prevent same-post multi-version duplicates
		$dedupe_key = $post_id > 0
			? md5((string) $post_id)
			: md5(strtolower($name . '|' . $version));

		$insert_data = array(
			'software_name' => \sanitize_text_field($name),
			'discovered_version' => \sanitize_text_field($version),
			'current_version' => \sanitize_text_field($current),
			'source_url' => \esc_url_raw($url),
			'changelog' => $changelog_clean,
			'type' => $type,
			'existing_post_id' => $post_id,
			'discovered_at' => Plugin_Time::utc_mysql_now(),
			'status' => $is_blocked ? 'failed' : 'pending',
			'error_message' => $is_blocked ? self::PLUGIN_FILTER_ERROR : null,
			'dedupe_key' => $dedupe_key,
		);

		$sql = "INSERT INTO $table (" . implode(', ', array_keys($insert_data)) . ")
			VALUES (" . implode(', ', array_fill(0, count($insert_data), '%s')) . ")
			ON DUPLICATE KEY UPDATE
			status = IF(status IN ('done','generating','finalizing','processing','queued','deferred'), status,
					IF(status IN ('failed','timeout','ignored') AND VALUES(type) NOT IN ('plugingenerated','plugingeneratedlegacy'), 'pending',
						VALUES(status))),
			discovered_at = CASE WHEN status IN ('done') THEN discovered_at ELSE VALUES(discovered_at) END,
			changelog = CASE WHEN status IN ('done') THEN changelog ELSE VALUES(changelog) END,
			source_url = CASE
				WHEN status IN ('done') THEN source_url
				WHEN VALUES(source_url) <> '' THEN VALUES(source_url)
				ELSE source_url
			END,
			source_image_url = CASE
				WHEN status IN ('done') THEN source_image_url
				WHEN VALUES(source_image_url) <> '' THEN VALUES(source_image_url)
				ELSE source_image_url
			END,
			source_thumbnail_url = CASE
				WHEN status IN ('done') THEN source_thumbnail_url
				WHEN VALUES(source_thumbnail_url) <> '' THEN VALUES(source_thumbnail_url)
				ELSE source_thumbnail_url
			END,
			featured_image_id = CASE
				WHEN status IN ('done') THEN featured_image_id
				WHEN VALUES(featured_image_id) > 0 THEN VALUES(featured_image_id)
				ELSE featured_image_id
			END,
			current_version = CASE
				WHEN status IN ('done') THEN current_version
				WHEN VALUES(current_version) <> '' AND LOWER(VALUES(current_version)) <> 'unknown' THEN VALUES(current_version)
				WHEN current_version = '' OR current_version IS NULL OR LOWER(current_version) = 'unknown' THEN VALUES(current_version)
				ELSE current_version
			END,
			discovered_version = CASE
				WHEN status IN ('done') THEN discovered_version
				WHEN LOWER(VALUES(discovered_version)) <> '' AND LOWER(VALUES(discovered_version)) <> 'unknown' THEN VALUES(discovered_version)
				ELSE discovered_version
			END,
			type = CASE
				WHEN status IN ('done') THEN type
				WHEN VALUES(existing_post_id) > 0 THEN VALUES(type)
				ELSE type
			END,
			existing_post_id = CASE
				WHEN status IN ('done') THEN existing_post_id
				WHEN VALUES(existing_post_id) > 0 THEN VALUES(existing_post_id)
				ELSE existing_post_id
			END,
			error_message = CASE
				WHEN VALUES(error_message) IS NOT NULL THEN VALUES(error_message)
				ELSE error_message
			END";

		$wpdb->query($wpdb->prepare($sql, array_values($insert_data)));
		return (int) $wpdb->insert_id ?: (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE dedupe_key = %s", $dedupe_key));
	}

	/**
 * Canonicalize a discovery contract: resolve the authoritative type and
 * existing_post_id that must be written to the discovery table.
 *
 * HARDENED: When post_id > 0 but classify() returns TYPE_NEW (pre-meta legacy
 * post), we now re-run the legacy fingerprint check so that the contract
 * written to the discovery table is consistent with find_existing_software().
 *
 * This prevents the split-brain condition where find_existing_software() sees
 * TYPE_LEGACY but a subsequent canonicalize_discovery_contract() call (e.g. at
 * approval time in DiscoveryProcessor::approve_item()) sees TYPE_NEW and
 * silently routes the job to the new-post branch.
 *
 * @param string $type    Raw type string from caller (may be stale).
 * @param int    $post_id Resolved existing post ID (0 = no match).
 * @return array{type:string,existing_post_id:int}
 */
public static function canonicalize_discovery_contract( string $type, int $post_id ): array
{
    if ( $post_id <= 0 ) {
        return [
            'type'             => Post_Type_Classifier::TYPE_NEW,
            'existing_post_id' => 0,
        ];
    }

    $actual_type = Post_Type_Classifier::classify( $post_id );

    // If classify() returns TYPE_NEW for a post that was found by name-match,
    // it is almost certainly a pre-meta legacy plugin post. Run the same
    // content-fingerprint check that find_existing_software() uses.
    if ( $actual_type === Post_Type_Classifier::TYPE_NEW ) {
        $actual_type = self::resolve_legacy_contract_type( $post_id );
    }

    return [
        'type'             => $actual_type,
        'existing_post_id' => $post_id,
    ];
}
    /**
     * Static companion to post_has_legacy_plugin_fingerprint() for use in the static
     * canonicalize_discovery_contract() context.
     * Reads seogen_content_contract + structural HTML signals from post_content.
     * Returns TYPE_LEGACY if fingerprint found, TYPE_NEW otherwise.
     *
     * @param int $post_id
     * @return string Post_Type_Classifier::TYPE_LEGACY or TYPE_NEW
     */
    private static function resolve_legacy_contract_type( int $post_id ): string
    {
        // Fast path: definitive meta signal.
        // CRITICAL FIX: blocks-v1 contract means the post has been successfully
        // migrated to the new sentinel format. Return TYPE_PLUGIN to reflect
        // the actual post state. Previously returned TYPE_LEGACY which was
        // semantically wrong — that value indicated "needs migration", not
        // "migration complete". The actual classification as TYPE_PLUGIN vs
        // TYPE_PLUGIN_LEGACY is handled by Post_Type_Classifier::classify()
        // which checks sentinel structure after confirming contract exists.
        $contract = \get_post_meta( $post_id, '_seogen_content_contract', true )
            ?: \get_post_meta( $post_id, '_seo_gen_content_contract', true )
            ?: \get_post_meta( $post_id, 'seogencontentcontract', true );
        if ( $contract === 'blocks-v1' ) {
            return Post_Type_Classifier::TYPE_PLUGIN;
        }

        $post = \get_post( $post_id );
        if ( ! $post || empty( $post->post_content ) ) {
            return Post_Type_Classifier::TYPE_NEW;
        }

        $content = $post->post_content;
        $score = 0;

        // wp:seo-gen/hero is exclusively written by ContentFormatter::toHtml.
        // Weight 2 so a post with a hero block passes even with only one other signal.
        if ( strpos( $content, 'wp:seo-gen/hero' ) !== false ) {
            $score += 2;
        }
        if ( strpos( $content, 'seo-gen-download-portal' ) !== false ) { $score++; }
        if ( strpos( $content, 'seo-gen-eeat-source' ) !== false ) { $score++; }
        if ( strpos( $content, 'id="moat-content"' ) !== false ) { $score++; }
        if ( strpos( $content, 'wp:rank-math/faq-block' ) !== false ) { $score++; }
        if ( strpos( $content, 'seo-gen-related-card' ) !== false ) { $score++; }

        return ( $score >= 2 ) ? Post_Type_Classifier::TYPE_LEGACY : Post_Type_Classifier::TYPE_NEW;
    }

    /**
     * Find an existing published/draft post matching the software name.
     * Returns ownership evidence, not just a match signal.
     *
     * The `type` key in the return value is the authoritative ownership classification:
     * - TYPE_PLUGIN / TYPE_PLUGIN_LEGACY → plugin owns it, surgical update path.
     * - TYPE_LEGACY → plugin-authored but pre-meta legacy. Treat as is_update = true.
     * - TYPE_NEW → truly external post; do NOT update, create new.
     *
     * @param string $name Software name to look up.
     * @param int $exclude_id Post ID to exclude from match (avoids self-match on re-scan).
     * @return array{id:int,type:string,version:string}|false
     */
	private function find_existing_software( string $name, int $exclude_id = 0 )
	{
		global $wpdb;

		if ( ! trim( $name ) ) {
			return false;
		}

		// --- Tier 0: Pipeline deduplication via DB_Post_Finder (exact identity). ---
		$finder = new DB_Post_Finder($this->logger);
		$tier0_id = $finder->find_exact_match($name);
		if ($tier0_id && $tier0_id !== $exclude_id) {
			$this->logger->debug(sprintf('find_existing_software: Tier 0 (DB_Post_Finder exact) matched post %d for "%s".', $tier0_id, $name));
			return $this->resolve_software_match($tier0_id, $name, $exclude_id);
		}

		// --- Tier 1: Plugin-written meta key — exact, fast, indexed. ---
		$exact_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_seo_gen_software_name' AND meta_value = %s LIMIT 1",
				$name
			)
		);
		if ( ! $exact_id ) {
			$exact_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'seogensoftwarename' AND meta_value = %s LIMIT 1",
					$name
				)
			);
		}
		if ($exact_id && $exact_id !== $exclude_id) {
			$this->logger->debug(sprintf('find_existing_software: Tier 1 (exact meta) matched post %d for "%s".', $exact_id, $name));
			return $this->resolve_software_match($exact_id, $name, $exclude_id);
		}

	// --- Tier 2: Normalized meta match with Similarity_Helper safety gate. ---
	if ( ! $exact_id ) {
		$normalized = \sanitize_text_field(strtolower($name));
		$meta_candidates = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_seo_gen_software_name'
				AND p.post_status NOT IN ('trash','auto-draft')
				AND (LOWER(pm.meta_value) = %s OR LOWER(pm.meta_value) LIKE %s)
				LIMIT 10",
				$normalized,
				$wpdb->esc_like($normalized) . '%'
			)
		);
			foreach ($meta_candidates as $candidate) {
				$cid = (int) $candidate->post_id;
				if ($cid === $exclude_id) continue;
				$match = Similarity_Helper::match_result($name, $candidate->meta_value);
				if ($match['safe']) {
					$this->logger->debug(sprintf('find_existing_software: Tier 2 (normalized meta, score=%.2f) matched post %d for "%s".', $match['score'], $cid, $name));
					return $this->resolve_software_match($cid, $name, $exclude_id);
				}
			}
		}

		// --- Tier 3: Tokenized SQL broad search. ---
		$tokens = array_filter(array_map('trim', preg_split('/[\s\-_.]+/', $name)));
		$tokens = array_filter($tokens, function($t) {
			if (mb_strlen($t) <= 1) return false;
			if (preg_match('/^\d+$/', $t)) return false;
			static $platform_stop = ['for','macos','mac','osx','windows','linux','android','ios','ubuntu','debian','fedora','centos','x64','x86','arm64','64bit','32bit','64-bit','32-bit','amd64','aarch64','intel','universal'];
			return !in_array(strtolower($t), $platform_stop, true);
		});
		$broad_id = 0;
		if (count($tokens) >= 1) {
			$like_clauses = [];
			$like_args = [];
			foreach ($tokens as $token) {
				$like_clauses[] = "LOWER(post_title) LIKE %s";
				$like_args[] = '%' . $wpdb->esc_like(strtolower($token)) . '%';
			}
			$where = implode(' AND ', $like_clauses);
			$exclude_sql = $exclude_id > 0 ? $wpdb->prepare(" AND ID != %d", $exclude_id) : "";
			$broad_sql = "SELECT ID, post_title FROM {$wpdb->posts}
				WHERE post_status IN ('publish','draft','future')
				AND post_type = 'post'
				AND ($where)
				$exclude_sql
				LIMIT 20";
			$broad_results = $wpdb->get_results($wpdb->prepare($broad_sql, ...$like_args));
		}

		// --- Tier 4: Fuzzy scoring across Tier 3 candidates. ---
		if (!empty($broad_results)) {
			$best_score = 0;
			$best_id = 0;
			$analyzer = new Title_Analyzer();
			foreach ($broad_results as $row) {
				$row_id = (int) $row->ID;
				if ($row_id === $exclude_id) continue;
				$parsed = $analyzer->extract($row->post_title);
				$candidate_name = is_array($parsed) && !empty($parsed['name']) ? $parsed['name'] : $row->post_title;
				$match = Similarity_Helper::match_result($name, $candidate_name);
				if ($match['safe'] && $match['score'] > $best_score) {
					$best_score = $match['score'];
					$best_id = $row_id;
				}
			}
			if ($best_id > 0) {
				$this->logger->debug(sprintf('find_existing_software: Tier 4 (fuzzy, score=%.2f) matched post %d for "%s".', $best_score, $best_id, $name));
				return $this->resolve_software_match($best_id, $name, $exclude_id);
			}
		}

		return false;
	}

	private function resolve_software_match(int $post_id, string $name, int $exclude_id)
	{
		if ($post_id <= 0 || $post_id === $exclude_id) {
			return false;
		}

		$classified_type = Post_Type_Classifier::classify($post_id);

		if ($classified_type === Post_Type_Classifier::TYPE_NEW) {
			if ($this->post_has_legacy_plugin_fingerprint($post_id)) {
				$classified_type = Post_Type_Classifier::TYPE_LEGACY;
				$this->logger->info(
					sprintf(
						'Discovery: Post %d matched as TYPE_LEGACY (legacy plugin ownership detected via fingerprint). Will route as update. Software: %s',
						$post_id, $name
					)
				);
			}
		}

		$contract = self::canonicalize_discovery_contract($classified_type, $post_id);
		$resolved_version = SeoGen_Version_Resolver::current_version($post_id);

		return [
			'id' => $post_id,
			'type' => $contract['type'],
			'version' => $resolved_version !== '' ? $resolved_version : 'Unknown',
		];
	}

	private static function extract_inline_source_facts(string $html): array
	{
		if (preg_match('/<!--\s*seo_gen_facts:\s*(\{.*?\})\s*-->/s', $html, $m)) {
			$decoded = json_decode($m[1], true);
			if (is_array($decoded)) {
				return $decoded;
			}
		}
		return [];
	}

	private function build_source_facts_from_draft(\WP_Post $draft): array
	{
		$html = $draft->post_content;
		$facts = self::extract_inline_source_facts($html);

		$extracted = Data_Extractor::extract($html);
		if (!empty($extracted)) {
			foreach (['file_size', 'license', 'developer', 'last_updated', 'homepage_url', 'changelog_url'] as $key) {
				if (empty($facts[$key]) && !empty($extracted[$key])) {
					$facts[$key] = $extracted[$key];
				}
			}
		}

		$resolved = Link_Resolver::resolve_from_html($html);
		if (!empty($resolved['links'])) {
			$facts['resolved_links'] = $resolved['links'];
		}
		if (!empty($resolved['target_platforms'])) {
			$facts['target_platforms'] = $resolved['target_platforms'];
		}
		if (!empty($resolved['os_support'])) {
			$facts['os_support'] = $resolved['os_support'];
		}

		return $facts;
	}

	private static function persist_phase1_discovery_context(int $item_id, array $source_facts, string $classification): void
	{
		\set_transient('seo_gen_source_facts_' . $item_id, $source_facts, 12 * HOUR_IN_SECONDS);
		\set_transient('seo_gen_classification_' . $item_id, $classification, 12 * HOUR_IN_SECONDS);
	}
}