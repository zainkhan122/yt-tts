/**
 * MCQ Video Studio - Headless Render Runner
 *
 * A minimal bootstrap that runs the auto-runner loop when invoked by render.js
 * via Playwright's headless Chromium. This file is loaded ONLY on the internal
 * `admin.php?page=mcqvs-render` page, which is designed to have zero WordPress
 * admin chrome network dependencies.
 *
 * Architecture:
 *   1. Wait for `window.__MCQVSRenderRunnerMounted` (set by PHP render_runner_page()).
 *   2. Fetch job data via AJAX `mcqvs_get_job_status`.
 *   3. Call `applyJobSettings()` to populate state (template, bg_video, music, etc).
 *   4. Load questions from `job.quiz_data`.
 *   5. Instantiate `MCQVS_ExportManager(state, config)` and call `startExport(indices)`.
 *   6. On completion, signal `window.__MCQVSRenderRunnerReady = true`.
 *   7. render.js's poll loop will see `completed` status and exit.
 *
 * This eliminates the need to navigate to the full Studio Editor page, which
 * triggers Playwright's `page.goto(waitUntil: 'networkidle', timeout: 60s)` to
 * wait for the entire WordPress admin chrome to settle — a guaranteed timeout
 * on any site where the admin JS takes >60s to reach network idle.
 */

(function (window) {
    'use strict';

    const Logger = window.MCQVSLogger;

    // @FIX (audit): Do NOT capture `window.MCQVS_ExportManager` / `window.MCQVS_PlanBuilder`
    //        at IIFE-eval time. WordPress footer scripts execute in source/registration
    //        order, not strictly by the declared dependency array (see class-vs-core.php
    //        where `mcqvs-render-runner` is enqueued with deps `['mcqvs-studio-logger',
    //        'mcqvs-studio-export']` only — `mcqvs-plan-builder` is NOT in that list). If
    //        evaluation happens before those globals are assigned, `ExportManager`/`PlanBuilder`
    //        are captured as `undefined`, every later `new ExportManager()` throws
    //        `TypeError: ... is not a constructor`, and the runner times out the render.js
    //        readiness gate with no actionable reason. Resolve them lazily inside run().
    const ExportManager = () => window.MCQVS_ExportManager;
    const PlanBuilder = () => window.MCQVS_PlanBuilder;

    // @FIX 2026-07-15: Guarantee render.js never waits the full 30s readiness gate
    //       on a silent failure. Any uncaught error or unhandled promise rejection
    //       in this runner now surfaces as a __MCQVSRenderRunnerFailed sentinel with
    //       the real reason, so render.js fails fast instead of timing out with the
    //       misleading `runner_failed_to_bootstrap` (exit 5).
    function failFast(reason) {
        try {
            window.__MCQVSRenderRunnerFailed = true;
            window.__MCQVSRenderRunnerFailReason = String(reason);
        } catch (_) { /* noop */ }
    }
    window.addEventListener('error', function (ev) {
        console.error('[RenderRunner] Uncaught error:', ev && ev.message, ev && ev.error);
        failFast('uncaught: ' + ((ev && ev.message) || 'unknown'));
    });
    window.addEventListener('unhandledrejection', function (ev) {
        const r = ev && ev.reason ? (ev.reason.message || ev.reason) : 'unhandledrejection';
        console.error('[RenderRunner] Unhandled rejection:', r);
        failFast('unhandledrejection: ' + r);
    });

    // Minimal state object that ExportManager needs
    // Mirrors the state populated by StudioController.handleApprovePlan() + applyJobSettings()
    const state = {
        questions: [],
        selectedQuestions: [],
        currentTemplate: 'trivia',
        templateId: 'trivia',
        videoFormat: 'shorts',
        width: 1080,
        height: 1920,
        hookText: 'Can you score 5/5?',
        hookVisible: true,
        ctaText: 'Subscribe for more!',
        ctaStyle: 'score', // score|subscribe|comment|follow|like|share|link|custom
        useRankSystemCTA: false,
        computedCtaText: '',
        websiteUrl: '',
        brandName: 'TheQuizWire',
        quizName: '',
        brandLogoImage: null,
        logoPosition: 'all',
        // @NEW 2026-08-11: Explanation bar toggle (default OFF — only when explicitly true).
        showExplanation: false,
        bgImage: null,
        bgVideoUrl: null,
        bgVideoFrames: null,
        bgVideoFrameDur: 33.33,
        bgMusicUrl: null,
        musicEnabled: true,
        sfxEnabled: true,
        fontOverride: null,
        templateConfig: {},
        templateColors: null,
        templateFonts: null,
        templateEffects: null,
        brandColor: null,
        subHookText: '',
        textEffects: null,
        // @FIX 2026-08-11: Shorts-first timing (SSOT with studio.controller + server fallback).
        // 600+500+4600+2000 = 7700ms/question; hook 1.2s; outro 3.2s.
        timing: {
            hookIntro: 1200,
            questionAppear: 600,
            optionsAppear: 500,
            userThinkTime: 4600,
            revealAnswer: 2000,
            outroDuration: 3200,
            questionTotal: 7700,
            questionPhases: { intro: 600, reveal: 2000, reading: 5100 }
        },
        voiceover: {
            enabled: false,
            provider: (window.MCQVS_Config && window.MCQVS_Config.tts && window.MCQVS_Config.tts.provider) ? String(window.MCQVS_Config.tts.provider).trim() : 'edge',
            voice: (window.MCQVS_Config && window.MCQVS_Config.tts && window.MCQVS_Config.tts.defaultVoice) ? String(window.MCQVS_Config.tts.defaultVoice).trim() : 'en-US-AriaNeural',
            rate: 1.05,
            pitch: 0,
            answerPhrase: 'correct answer is',
            speakHook: true,
            speakOptions: true,
            speakAnswer: true,
            speakCta: false,
            autoFitTiming: true
        },
        saveMode: 'local',
        activeJobId: null
    };

    // Config object for ExportManager - built from MCQVS_Config
    const config = {
        ajaxUrl: window.MCQVS_Config?.ajaxUrl || window.MCQVS_Config?.ajaxurl || window.ajaxurl || '',
        nonce: window.MCQVS_Config?.nonce || '',
        rootUrl: window.MCQVS_Config?.rootUrl || window.MCQVS_Config?.pluginUrl || MCQVS_PLUGIN_URL || '',
        assetsUrl: window.MCQVS_Config?.assetsUrl || '',
        videoFormat: window.MCQVS_Config?.videoFormat || 'shorts',
        canvasSize: window.MCQVS_Config?.canvasSize || { width: 1080, height: 1920 },
        width: window.MCQVS_Config?.canvasSize?.width || 1080,
        height: window.MCQVS_Config?.canvasSize?.height || 1920,
        brandName: window.MCQVS_Config?.brandName || 'TheQuizWire',
        quizName: window.MCQVS_Config?.quizName || '',
        hookText: window.MCQVS_Config?.hookText || 'Can you score 5/5?',
        ctaText: window.MCQVS_Config?.ctaText || 'Subscribe for more!',
        ctaStyle: window.MCQVS_Config?.ctaStyle || 'score',
        websiteUrl: window.MCQVS_Config?.websiteUrl || '',
        bgMusicUrl: window.MCQVS_Config?.bgMusicUrl || null,
        fontOverride: window.MCQVS_Config?.fontOverride || null,
        voiceover: window.MCQVS_Config?.voiceover || state.voiceover,
        timing: window.MCQVS_Config?.timing || state.timing,
        templateConfig: window.MCQVS_Config?.templateConfig || {},
        templateColors: window.MCQVS_Config?.templateColors || null,
        templateFonts: window.MCQVS_Config?.templateFonts || null,
        templateEffects: window.MCQVS_Config?.templateEffects || null,
        brandColor: window.MCQVS_Config?.brandColor || null,
        subHookText: window.MCQVS_Config?.subHookText || '',
        textEffects: window.MCQVS_Config?.textEffects || null
    };

    // Helper: AJAX post (mirrors studio.controller.js's ajaxPost)
    // @FIX 2026-07-14: Added 15s AbortController — without this, any hang on
    //                 admin-ajax.php (DB lock, PHP worker exhaustion, Apache
    //                 connection limits) left run() wedged on the first
    //                 mcqvs_get_job_status call, and render.js's waitForFunction
    //                 timed out 30s later with runner_failed_to_bootstrap.
    async function ajaxPost(action, data = {}) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('nonce', config.nonce);
        Object.entries(data).forEach(([k, v]) => {
            if (v !== undefined && v !== null) formData.append(k, String(v));
        });
        const ac = new AbortController();
        const t = setTimeout(() => ac.abort(), 15000);
        try {
            const response = await fetch(config.ajaxUrl, { method: 'POST', body: formData, signal: ac.signal });
            return await response.json();
        } finally {
            clearTimeout(t);
        }
    }

    // Helper: Normalize question to expected format
    function normalizeQuestion(q) {
        if (!q) return null;
        return {
            question: q.question || q.text || '',
            options: Array.isArray(q.options) ? q.options : [],
            correct: Number.isInteger(q.correct) ? q.correct : (parseInt(q.correct, 10) || 0)
        };
    }

    // Helper: Extract video frames from a URL (mirrors studio.controller.js extractVideoFrames)
    // @FIX 2026-07-31: Frames are drawn at OUTPUT resolution (1080x1920 / 1920x1080) as
    //       JPEG, not the source's native size. Also returns the real per-frame duration
    //       so `state.bgVideoFrameDur` matches the source video — the previous code
    //       hardcoded 120000ms (2 min) per loop, which played the background in slow motion
    //       and desynced the exported MP4 from the preview.
    async function extractVideoFrames(videoUrl, frameCount) {
        frameCount = frameCount || 60;
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.crossOrigin = 'anonymous';
            video.muted = true;
            video.playsInline = true;
            video.preload = 'auto';
            video.src = videoUrl;
            video.onloadedmetadata = async () => {
                const dur = video.duration;
                if (!dur || !isFinite(dur)) { resolve({ frames: [], frameDurMs: 0 }); return; }
                const outW = Number(state.width) || 1080;
                const outH = Number(state.height) || 1920;
                const canvas = document.createElement('canvas');
                canvas.width = outW;
                canvas.height = outH;
                const ctx = canvas.getContext('2d');
                const frames = [];
                for (let i = 0; i < frameCount; i++) {
                    const time = (dur * i) / frameCount;
                    video.currentTime = time;
                    await new Promise(r => { video.onseeked = r; });
                    try {
                        ctx.drawImage(video, 0, 0, outW, outH);
                        const img = new Image();
                        img.src = canvas.toDataURL('image/jpeg', 0.82);
                        frames.push(img);
                    } catch (e) {
                        // tainted canvas — skip this frame, don't fail the whole render
                    }
                }
                resolve({ frames, frameDurMs: (dur / frameCount) * 1000 });
            };
            video.onerror = () => resolve({ frames: [], frameDurMs: 0 });
        });
    }

    // Helper: Load an image from a URL into a drawable Image (mirrors studio.controller.js
    // logo loading). Tries crossOrigin='anonymous' first so canvas drawImage → toDataURL
    // stays untainted; falls back to a plain load (same-origin or no-CORS host) on error.
    function loadImage(url) {
        return new Promise((resolve) => {
            if (!url) { resolve(null); return; }
            const img = new Image();
            const done = (im) => { if (im && im.width > 0 && im.height > 0) resolve(im); else resolve(null); };
            img.onload = () => done(img);
            img.onerror = () => {
                // Retry without crossOrigin (some servers reject CORS requests).
                if (img.crossOrigin !== '') {
                    const retry = new Image();
                    retry.onload = () => done(retry);
                    retry.onerror = () => resolve(null);
                    retry.src = url;
                } else {
                    resolve(null);
                }
            };
            img.crossOrigin = 'anonymous';
            img.src = url;
        });
    }

    // Helper: Apply job settings (template, bg_video, music, save_mode)
    async function applyJobSettings(settings) {
        if (!settings || typeof settings !== 'object') return;

        // @FIX 2026-08-XX: Reset template/font state from any previous job to prevent
        //       cross-job leakage. The module-level state object persists across jobs
        //       in the same Playwright tab — without this reset, state.fontOverride
        //       and state.templateFonts from job A leak into job B when job B has no
        //       explicit settings.font key.
        state.fontOverride = null;
        state.templateFonts = null;
        state.templateColors = null;
        state.templateEffects = null;

        // Template
        if (settings.template) {
            state.currentTemplate = String(settings.template);
            state.templateId = state.currentTemplate;
        }

        // Apply template schema (colors/fonts/effects) from template definition
        try {
            if (window.MCQVS_VideoTemplates && typeof window.MCQVS_VideoTemplates.apply === 'function') {
                window.MCQVS_VideoTemplates.apply(String(state.currentTemplate || 'trivia'), state);
            }
        } catch (_) {}

        // Font override — re-apply AFTER template apply so it takes priority
        if (settings.font) {
            state.fontOverride = String(settings.font);
        }

        // Music — resolve slug to full URL using assetsUrl base
        if (settings.music) {
            const musicVal = String(settings.music).trim();
            if (musicVal.startsWith('http://') || musicVal.startsWith('https://')) {
                state.bgMusicUrl = musicVal;
            } else {
                const file = musicVal.endsWith('.mp3') ? musicVal : `${musicVal}.mp3`;
                const base = config.assetsUrl || window.MCQVS_Config?.assetsUrl || '';
                state.bgMusicUrl = base ? `${base.replace(/\/$/, '')}/audio/music/${file}` : file;
            }
            state.musicEnabled = !!state.bgMusicUrl;
        }

        // Background Video — extract frames for canvas rendering
        if (settings.bg_video) {
            const videoUrl = String(settings.bg_video).trim();
            if (videoUrl) {
                state.bgVideoUrl = videoUrl;
                state.bgImage = null; // @FIX 2026-07-31: video replaces any stale image background
                try {
                    const extracted = await extractVideoFrames(videoUrl);
                    state.bgVideoFrames = extracted.frames || [];
                    if (state.bgVideoFrames.length > 0 && Number(extracted.frameDurMs) > 0) {
                        state.bgVideoFrameDur = Number(extracted.frameDurMs);
                    }
                } catch (e) {
                    console.warn('[RenderRunner] Failed to extract bg video frames:', e);
                }
            }
        }

        // Hook visibility
        if (settings.hookVisible !== undefined) {
            state.hookVisible = settings.hookVisible !== false && settings.hookVisible !== '0';
        }

        // Hook text
        if (settings.hookText) {
            state.hookText = String(settings.hookText);
        }

        // CTA text
        if (settings.ctaText) {
            state.ctaText = String(settings.ctaText);
            state.computedCtaText = String(settings.ctaText);
        }

        // Brand name
        if (settings.brandName) {
            state.brandName = String(settings.brandName);
        }

        // Quiz name
        if (settings.quizName) {
            state.quizName = String(settings.quizName);
        }

        // Explanation bar toggle (Settings > Defaults & Scheduling).
        if (settings.showExplanation !== undefined) {
            state.showExplanation = !!settings.showExplanation;
        }

        // Logo
        // @FIX 2026-08-11 (Gap 2): applyJobSettings() read settings.logoPath but never
        //       loaded the image — state.brandLogoImage stayed null, so the logo was
        //       completely absent from browser-headless renders. Load the image now
        //       (async) so TemplateManager.drawLogo() has a drawable bitmap.
        if (settings.logoPath) {
            state.logoPosition = settings.logoPosition || 'all';
            try {
                const loaded = await loadImage(String(settings.logoPath));
                if (loaded) state.brandLogoImage = loaded;
            } catch (e) {
                console.warn('[RenderRunner] Failed to load logo image:', e);
            }
        }

        // Save Mode
        if (settings.save_mode) {
            state.saveMode = String(settings.save_mode);
        }

        // Topic name -> quizName (fallback if no explicit quizName)
        if (settings.topic_name && !settings.quizName) {
            state.quizName = String(settings.topic_name);
        }

        // Cover config (bg_color, badge_style, brand_size, show_logo)
        if (settings.cover_config && typeof settings.cover_config === 'object') {
            state.coverConfig = settings.cover_config;
        }

        // Voiceover
        if (settings.voiceover) {
            state.voiceover = settings.voiceover;
        }

        // SFX
        if (settings.sfxEnabled !== undefined) {
            state.sfxEnabled = !!settings.sfxEnabled;
        }

        // Canvas dimensions based on format
        if (state.videoFormat === 'youtube') {
            state.width = 1920;
            state.height = 1080;
        } else {
            state.width = 1080;
            state.height = 1920;
        }
        state.canvasSize = { width: state.width, height: state.height };
    }

    // @FIX 2026-07-14: Helper that marks the job failed in the DB and signals
    //              render.js. Every early-return branch below was previously
    //              a silent return — render.js's readiness gate then timed
    //              out at 30s but kept polling for the entire 900s budget while
    //              the row sat `rendering` with no progress.
    async function markJobFailed(reason) {
        console.error('[RenderRunner] Marking job failed:', reason);
        try {
            await ajaxPost('mcqvs_update_job_status', {
                job_id: state.activeJobId,
                status: 'failed',
                error: String(reason)
            });
        } catch (_) { /* best-effort */ }
        window.__MCQVSRenderRunnerFailed = true;
        window.__MCQVSRenderRunnerFailReason = String(reason);
    }

    // Main entry point
    async function run() {
        const jobId = window.__MCQVSRenderRunnerActiveJob;
        if (!jobId) {
            console.error('[RenderRunner] No active job ID found');
            window.__MCQVSRenderRunnerFailed = true;
            return;
        }

        // @FIX 2026-07-15: Signal bootstrap success IMMEDIATELY after the runner page
        //       is confirmed alive (job id present). render.js's readiness gate has a
        //       ~30s timeout, but the actual video encode runs for minutes and its
        //       completion is detected by render.js polling mcqvs_get_job_status — NOT
        //       by this sentinel. Historically the sentinel was set only AFTER the
        //       encode finished, so the gate expired first and forced a spurious
        //       `runner_failed_to_bootstrap` (exit 5). Any later failure updates the
        //       job status to `failed` via markJobFailed, which render.js polls.
        window.__MCQVSRenderRunnerReady = true;

        // Hard watchdog: if 25s elapse and nothing has signalled ready/failed (e.g. a
        // hang the per-step catches did not cover), fail fast so render.js does not
        // wait the full 30s gate blindly. 5s margin for render.js to read the sentinel.
        setTimeout(function () {
            if (!window.__MCQVSRenderRunnerReady && !window.__MCQVSRenderRunnerFailed) {
                failFast('bootstrap watchdog: no readiness signal within 25s');
            }
        }, 25000);

        console.log('[RenderRunner] Starting headless render for job:', jobId);
        state.activeJobId = jobId;

        // Step 1: Fetch job data
        let jobData;
        try {
            const res = await ajaxPost('mcqvs_get_job_status', { job_id: jobId });
            if (!res.success) {
                await markJobFailed('Failed to fetch job: ' + JSON.stringify(res));
                return;
            }
            jobData = res.data;
        } catch (e) {
            await markJobFailed('AJAX error fetching job: ' + e.message);
            return;
        }

        if (!jobData) {
            await markJobFailed('No job data returned for job ' + jobId);
            return;
        }

        // @FIX 2026-07-13: project_id may be empty for topic-based jobs (not project-based).
        //       Set it to the job_id as a fallback since the server-side handler
        //       expects project_id to be a non-empty string for R2 path resolution.
        //       This was previously placed above the `let jobData;` declaration (TDZ),
        //       causing a ReferenceError before any render code could execute.
        state.activeProjectId = jobData.project_id || jobId;

        // Step 2: Check if already completed/failed
        if (jobData.status === 'completed') {
            console.log('[RenderRunner] Job already completed');
            window.__MCQVSRenderRunnerReady = true;
            return;
        }
        if (jobData.status === 'failed') {
            console.warn('[RenderRunner] Job already failed:', jobData.error_message);
            window.__MCQVSRenderRunnerFailed = true;
            return;
        }

        // Step 3: Mark as rendering
        try {
            await ajaxPost('mcqvs_update_job_status', {
                job_id: jobId,
                status: 'rendering'
            });
        } catch (e) {
            console.error('[RenderRunner] Failed to mark rendering:', e);
        }

        // Step 4: Apply settings from job
        try {
            const settings = jobData.settings ? JSON.parse(jobData.settings) : {};
            // @FIX: Read per-job video format from save_mode_video_format (Content Planner pipeline)
            //       Falls back to format, then to global config, then to 'shorts'.
            state.videoFormat = settings.save_mode_video_format || settings.format || window.MCQVS_Config?.videoFormat || 'shorts';
            await applyJobSettings(settings);
        } catch (e) {
            console.warn('[RenderRunner] Error parsing settings:', e);
        }

        // Step 5: Load questions
        try {
            const questions = jobData.quiz_data ? JSON.parse(jobData.quiz_data) : [];
            state.questions = questions.map(normalizeQuestion).filter(Boolean);
            state.selectedQuestions = state.questions.map((_, i) => i);
            console.log('[RenderRunner] Loaded', state.questions.length, 'questions');
        } catch (e) {
            console.error('[RenderRunner] Error parsing quiz_data:', e);
            await markJobFailed('Error parsing quiz_data: ' + e.message);
            return;
        }

        if (state.questions.length === 0) {
            await markJobFailed('No questions to render (quiz_data empty after parse)');
            return;
        }

        // Step 6: Build render plan (required by ExportManager.spawnWorker)
        try {
            const PB = PlanBuilder();
            if (!PB || typeof PB.buildFromState !== 'function') {
                await markJobFailed('Render module missing: MCQVS_PlanBuilder not loaded (check mcqvs-plan-builder enqueue + asset 404)');
                return;
            }
            const plan = PB.buildFromState(state, {
                fps: 30,
                width: state.width,
                height: state.height,
                templateId: state.templateId,
                currentTemplate: state.templateId,
                assetConfig: { musicUrl: state.bgMusicUrl || null, sfx: {} }
            });
            state.renderPlan = plan;
            state.timing = plan.timing || state.timing;
            console.log('[RenderRunner] Render plan built, totalMs:', plan.totalMs);
        } catch (e) {
            await markJobFailed('Failed to build render plan: ' + e.message);
            return;
        }

        // Step 7: Instantiate ExportManager and start export
        try {
            const EM = ExportManager();
            if (!EM || typeof EM !== 'function') {
                await markJobFailed('Render module missing: MCQVS_ExportManager not loaded (check mcqvs-studio-export enqueue + asset 404)');
                return;
            }
            const exporter = new EM(state, config);
            state.export = exporter;

            const indices = state.selectedQuestions;
            console.log('[RenderRunner] Starting export for', indices.length, 'questions');

            // Signal bootstrap success BEFORE the (long) export begins. render.js's
            // readiness gate has a ~30s timeout; the full video encode runs for minutes,
            // so signalling only after completion made the gate expire and forced a
            // spurious `runner_failed_to_bootstrap` (exit 5) failure. Completion is
            // detected by render.js polling mcqvs_get_job_status, not by this sentinel.
            window.__MCQVSRenderRunnerReady = true;

            await exporter.startExport(indices);

            console.log('[RenderRunner] Export completed successfully');
            // Notify render.js that we're done (it polls mcqvs_get_job_status).
            // The export handler already updated video_url; readiness was signalled above.
        } catch (exportErr) {
            console.error('[RenderRunner] Export failed:', exportErr);
            try {
                await ajaxPost('mcqvs_update_job_status', {
                    job_id: jobId,
                    status: 'failed',
                    error: exportErr.message || String(exportErr)
                });
            } catch (_) { }
            await markJobFailed('Export failed: ' + (exportErr.message || String(exportErr)));
            return;
        }
    }

    // Wait for the runner page to mount, then start
    (function waitForMount() {
        if (window.__MCQVSRenderRunnerMounted === true) {
            run().catch(e => {
                // @FIX: A fatal throw inside run() previously only logged to console,
                // leaving render.js's readiness gate to time out at 30s with a
                // misleading `runner_failed_to_bootstrap`. Surface a real failure
                // sentinel so render.js fails fast with the actual reason.
                console.error('[RenderRunner] Fatal error:', e);
                window.__MCQVSRenderRunnerFailed = true;
                window.__MCQVSRenderRunnerFailReason = String((e && e.message) ? e.message : e);
            });
        } else {
            setTimeout(waitForMount, 50);
        }
    })();

})(window);