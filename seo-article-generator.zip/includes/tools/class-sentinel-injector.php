<?php
namespace SEO_Article_Generator\Tools;

use SEO_Article_Generator\Discovery\Post_Type_Classifier;
use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Discovery\Title_Analyzer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Ensure TypeClassifier is available regardless of bootstrap path
if ( ! class_exists( Post_Type_Classifier::class, false ) ) {
	require_once __DIR__ . '/../discovery/class-post-type-classifier.php';
}

final class Sentinel_Injector {
		private const META_BACKFILL         = '_seo_gen_sentinel_backfill';
		private const META_BACKFILL_FAILED = '_seo_gen_backfill_failed';
		private const META_CONTENT_CONTRACT = '_seo_gen_content_contract';
		private const META_CONTENT_CONTRACT_LEGACY = 'seogencontentcontract';
		private const CONTENT_CONTRACT_V1   = 'blocks-v1';
		private const META_AMBIGUOUS        = '_seo_gen_legacy_identification_status';
		private const AJAX_BATCH_LIMIT      = 25;

	public static function register(): void {
		add_action( 'wp_ajax_seo_gen_inject_sentinels',        [ __CLASS__, 'ajax_run' ] );
		add_action( 'wp_ajax_seo_gen_backfill_stats',          [ __CLASS__, 'ajax_stats' ] );
		add_action( 'wp_ajax_seo_gen_identify_legacy_posts',   [ __CLASS__, 'ajax_identify_posts' ] );
		add_action( 'wp_ajax_seo_gen_backfill_software_name',  [ __CLASS__, 'ajax_backfill_software_name' ] );
		add_action( 'wp_ajax_seo_gen_purge_unknown_ownership', [ __CLASS__, 'ajax_purge_unknown_ownership' ] );
		add_action( 'wp_ajax_seo_gen_clear_backfill_failures', [ __CLASS__, 'ajax_clear_backfill_failures' ] );
	}

	public static function ajax_run(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				[
					'message' => 'Forbidden',
				],
				403
			);
		}

		check_ajax_referer( 'seo_gen_nonce', 'nonce' );

		$limit   = isset( $_POST['limit'] ) ? min( self::AJAX_BATCH_LIMIT, max( 1, (int) $_POST['limit'] ) ) : self::AJAX_BATCH_LIMIT;
		$dry_run = isset( $_POST['dry_run'] ) && 'true' === $_POST['dry_run'];
		$offset  = isset( $_POST['offset'] ) ? max( 0, (int) $_POST['offset'] ) : 0;

		$category_id = isset( $_POST['category_id'] ) ? (int) $_POST['category_id'] : 0;

		$excluded_category_ids = [];
		if ( isset( $_POST['excluded_category_ids'] ) ) {
			$raw = is_array( $_POST['excluded_category_ids'] ) ? $_POST['excluded_category_ids'] : [ $_POST['excluded_category_ids'] ];
			$excluded_category_ids = array_values( array_filter( array_map( 'intval', $raw ), static function ( $term_id ) use ( $category_id ) {
				return $term_id > 0 && $term_id !== $category_id;
			} ) );
		}

		$post_ids = self::query_unmigrated_posts( $limit, $offset, $category_id, $excluded_category_ids );
		$results  = [
			'targeted_posts' => count( $post_ids ),
			'updated_posts'  => 0,
			'skipped_posts'  => 0,
			'errors'         => [],
			'details'        => [],
		];

		foreach ( $post_ids as $post_id ) {
			$post = get_post( $post_id );

			if ( ! $post ) {
				$results['skipped_posts']++;
				continue;
			}

			if ( ! get_post_meta( $post_id, '_seo_gen_software_name', true ) ) {
				$hero_data = get_post_meta( $post_id, '_seo_gen_hero_data', true );
				if ( is_array( $hero_data ) && ! empty( $hero_data['software_name'] ) ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, '_seo_gen_software_name', $hero_data['software_name'] );
					}
				}
			}

			$classified_type = Post_Type_Classifier::classify( $post_id );

			if ( '' !== $classified_type && ! Post_Type_Classifier::is_plugin_owned( $classified_type ) ) {
				if ( ! $dry_run ) {
					update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'not_plugin_owned' );
				}
				$results['skipped_posts']++;
				$results['details'][] = [
					'post_id'    => $post_id,
					'post_title' => get_the_title( $post_id ),
					'status'     => 'skipped',
					'reason'     => 'not_plugin_owned',
				];
				continue;
			}

			$existing_contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT, true );
			if ( '' === $existing_contract ) {
				$existing_contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY, true );
			}
			if ( $existing_contract === self::CONTENT_CONTRACT_V1 ) {
				$actual_format = self::detect_format( $post->post_content );
				if ( in_array( $actual_format, [ 'comment', 'attribute', 'none' ], true ) ) {
					// FIXED: Reset contract and process the post instead of skipping
					// This fixes "stuck" posts that were skipped but never processed
					delete_post_meta( $post_id, self::META_CONTENT_CONTRACT );
					delete_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY );
					delete_post_meta( $post_id, self::META_BACKFILL );

					// Loop protection - check retry count
					$reset_count = (int) get_post_meta( $post_id, '_seo_gen_contract_reset_count', true );
					if ( $reset_count >= 2 ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'contract_reset_loop_detected' );
						$results['skipped_posts']++;
						$results['details'][] = [
							'post_id'    => $post_id,
							'post_title' => get_the_title( $post_id ),
							'status'     => 'failed',
							'reason'     => 'contract_reset_loop_detected',
						];
						continue;
					}

					// Increment reset counter for loop detection
					update_post_meta( $post_id, '_seo_gen_contract_reset_count', $reset_count + 1 );

					$results['details'][] = [
						'post_id'    => $post_id,
						'post_title' => get_the_title( $post_id ),
						'status'     => 'contract_reset_recovered',
						'reason'     => 'stale_contract_legacy_content_' . $actual_format,
					];
					// Do NOT continue - allow loop to proceed to upgrade logic below
				} else {
					// Block format with valid content - it's already migrated, skip
					$results['skipped_posts']++;
					continue;
				}
			}

			if ( empty( $post->post_content ) ) {
				if ( ! $dry_run ) {
					update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'empty_content' );
				}
				$results['skipped_posts']++;
				$results['details'][] = [
					'post_id'    => $post_id,
					'post_title' => get_the_title( $post_id ),
					'status'     => 'failed',
					'reason'     => 'empty_content',
				];
				continue;
			}

			try {
				$original_content = (string) $post->post_content;

				// T2 FIX: Detect format FIRST. Exit early for 'none' format before
				// running any upgrade, so no wasted work and no corrupted DB writes.
				$format = self::detect_format( $original_content );

				// FIX: Detect corrupted block format (self-closing/clustered sentinels) 
				// and force a downgrade to 'none' to trigger the Content_Normalizer recovery path.
				if ( 'block' === $format ) {
					$has_self_closing = preg_match( '/\/\s*-->\s*$/im', $original_content );
					$has_empty_blocks = preg_match( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*-->\s*<!--\s*\/wp:seo-gen\/section\s*-->/is', $original_content );
					
					if ( $has_self_closing || $has_empty_blocks ) {
						$original_content = preg_replace( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*-->/is', '', $original_content );
						$original_content = preg_replace( '/<!--\s*\/wp:seo-gen\/section\s*-->/i', '', $original_content );
						$format           = 'none';
					}
				}

				// FIX: For plugin-owned posts that return 'none' or 'pseudo-block' — attempt 
				// Content_Normalizer recovery before permanently failing. These posts have 
				// zone-identifiable structure (id="moat-content", class="seo-gen-download-portal", etc.) 
				// but lack proper zone sentinels.
				// Sentinel_Fallback_Utility::repair_and_audit() calls Content_Normalizer::normalize()
				// then upgrade_legacy_html_to_blocks(), injecting comment sentinels from class/anchor markers.
				if ( in_array( $format, [ 'none', 'pseudo-block' ], true ) ) {
					$classified_type = Post_Type_Classifier::classify( $post_id );

					$is_plugin_owned = Post_Type_Classifier::is_plugin_owned( $classified_type );

					if ( $is_plugin_owned && class_exists( '\SEO_Article_Generator\Tools\Sentinel_Fallback_Utility' ) ) {
						$repair = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::repair_and_audit( $original_content );

						if ( ! empty( $repair['migration_attempted'] ) && $repair['changed'] && empty( $repair['audit']['fatal_reasons'] ) ) {
							$repaired_format = self::detect_format( $repair['content'] );
							if ( 'none' !== $repaired_format ) {
								$original_content = $repair['content'];
								$format           = $repaired_format;
							}
						} elseif ( ! empty( $repair['migration_attempted'] ) ) {
							if ( ! $dry_run ) {
								$fatal = implode( ', ', $repair['audit']['fatal_reasons'] ?? [] );
								\error_log(
									sprintf(
										'SEO Gen Backfill: sentinel migration failed for post %d (%s).',
										$post_id,
										$fatal ?: 'unknown'
									)
								);
							}
						}
					}
				}

				// If still 'none' after repair attempt — permanently fail (original gate preserved).
				if ( 'none' === $format ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'no_sentinel_structure' );
					}
					$results['details'][] = [
						'post_id'    => $post_id,
						'post_title' => get_the_title( $post_id ),
						'status'     => 'failed',
						'reason'     => 'no_sentinel_structure_requires_regen',
					];
					$results['skipped_posts']++;
					continue;
				}

				[ $blocks, $new_content ] = self::upgrade_legacy_html_to_blocks( $original_content, $format );

				// T3 FIX: Guard against null return from preg_replace_callback PCRE limit.
				if ( ! is_string( $new_content ) ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'pcre_limit_exceeded' );
					}
					$results['errors'][] = [
						'post_id' => $post_id,
						'error'   => 'upgrade_returned_null_pcre_limit_exceeded',
					];
					$results['skipped_posts']++;
					continue;
				}

				// R1 FIX: For any non-block-format post, the upgrade MUST produce at least one
				// block delimiter. If it doesn't (unbalanced HTML / PCRE fallback returned original),
				// $changed will be false and the post silently passes to mark_post_as_backfilled().
				// That permanently marks an unconverted post as done and breaks every future patch.
				if ( 'block' !== $format && strpos( $new_content, '<!-- wp:seo-gen/section ' ) === false ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'upgrade_produced_no_block_delimiters' );
					}
					$results['details'][] = [
						'post_id'    => $post_id,
						'post_title' => get_the_title( $post_id ),
						'status'     => 'failed',
						'reason'     => 'upgrade_produced_no_block_delimiters',
					];
					$results['skipped_posts']++;
					continue;
				}

				$changed   = $new_content !== $post->post_content;
				$status    = $changed ? 'updated' : 'unchanged';
				$injected  = self::detect_injected_zones( $post->post_content, $new_content );

				// If migration ran but produced zero zone blocks — content is corrupt.
				if ( $changed && empty( $blocks ) ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'injection_produced_no_zones' );
					}
					$results['details'][] = [
						'post_id'    => $post_id,
						'post_title' => get_the_title( $post_id ),
						'status'     => 'failed',
						'reason'     => 'injection_produced_no_zones',
					];
					$results['skipped_posts']++;
					continue;
				}

				// Pre-build detail array so block-format repair path can use it.
				$detail = [
					'post_id'    => $post_id,
					'post_title' => get_the_title( $post_id ),
					'status'     => $status,
					'injected'   => $injected,
				];

				// Block-format pass-through: verify ALL zones are present before
				// marking as backfilled. Incomplete zone coverage must NOT be
				// sealed with blocks-v1 — it would permanently prevent patching.
				if ( ! $changed && 'block' === $format ) {
					$all_zones = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
					$present   = array_values( array_filter( $all_zones, static function ( $z ) use ( $new_content ) {
						return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $new_content, $z ) !== false;
					} ) );
					$missing   = array_values( array_diff( $all_zones, $present ) );

					if ( ! empty( $missing ) ) {
						// DEEP REPAIR: run ContentNormalizer on the existing content.
						[ $repaired, $zones_added, $zones_absent ] = self::repair_incomplete_block_format( $new_content );

						if ( $dry_run ) {
							$detail['status']         = ! empty( $zones_added ) ? ( empty( $zones_absent ) ? 'repair_preview_full_seal' : 'repair_preview_partial' ) : 'failed';
							$detail['reason']         = ! empty( $zones_added ) ? ( empty( $zones_absent ) ? null : 'zones_absent_needs_regen' ) : 'incomplete_zone_coverage_needs_regen';
							$detail['repair_preview'] = [
								'zones_currently_wrapped' => $present,
								'zones_would_be_added'    => $zones_added,
								'zones_still_absent'      => $zones_absent,
								'outcome'                 => empty( $zones_absent ) ? 'full_seal' : ( ! empty( $zones_added ) ? 'partial_seal_regen_needed' : 'needs_full_regen' ),
							];
							$results['skipped_posts']++;
							$results['details'][] = $detail;
							continue;
						}

						// Write updated content only when FULL coverage has been restored.
						// Partial repairs must not be sealed as blocks-v1.
						if ( ! empty( $zones_absent ) ) {
							if ( ! $dry_run ) {
								update_post_meta(
									$post_id,
									self::META_BACKFILL_FAILED,
									'zones_absent_needs_regen:' . implode( ',', $zones_absent )
								);
							}

							$detail['status']        = 'failed';
							$detail['reason']        = 'zones_absent_needs_regen';
							$detail['zones_present'] = $present;
							$detail['zones_added']   = $zones_added;
							$detail['zones_absent']  = $zones_absent;

							$results['skipped_posts']++;
							$results['details'][] = $detail;
							continue;
						}

						if ( ! empty( $zones_added ) ) {
							$result = self::bulk_atomic_db_update( $post_id, $repaired );
							if ( ! $result['success'] ) {
								$detail['status']        = 'failed';
								$detail['reason']        = $result['reason'] ?? 'bulk_write_failed';
								$detail['zones_present'] = $present;
								$detail['zones_added']   = $zones_added;
								$detail['zones_absent']  = $zones_absent;
								$results['skipped_posts']++;
								$results['details'][] = $detail;
								continue;
							}

							$detail['status'] = 'repaired_sealed';
						} else {
							self::mark_post_as_backfilled( $post_id );
							$detail['status'] = 'sealed';
						}

						$results['updated_posts']++;
						$detail['zones_present'] = $present;
						$detail['zones_added']   = $zones_added;
						$detail['zones_absent']  = $zones_absent;
						$results['details'][]    = $detail;
						continue;
				}

				// FIXED: Lenient validation - only require core zones (moat, download, tech_specs)
				// Posts with core zones are sealable; optional zones can be regenerated later
				$core_zones          = [ 'moat', 'download', 'tech_specs' ];
				$all_zones          = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
				$zones_present = array_values( array_filter( $all_zones, static function ( $z ) use ( $new_content ) {
					return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $new_content, $z ) !== false;
				} ) );
				$missing_zones      = array_values( array_diff( $all_zones, $zones_present ) );
				$missing_core      = array_values( array_diff( $core_zones, $zones_present ) );

			// Fail only if ALL core zones are missing
			if ( count( $missing_core ) === count( $core_zones ) ) {
					if ( ! $dry_run ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'pre_seal_validation_missing_core_zones:' . implode( ',', $missing_core ) );
					}
					$results['details'][] = [
						'post_id'        => $post_id,
						'post_title'     => get_the_title( $post_id ),
						'status'         => 'failed',
						'reason'         => 'pre_seal_validation_missing_core_zones',
						'zones_present'  => $zones_present,
						'zones_missing'  => $missing_zones,
					];
					$results['skipped_posts']++;
					continue;
				}

				// Core zones present - seal the post (optional zones can be regenerated later)
				if ( ! $dry_run ) {
					self::mark_post_as_backfilled( $post_id );
				}
				$detail['status']     = $dry_run ? 'ready_to_seal' : 'sealed';
				$detail['confidence'] = 'high';
				if ( $dry_run ) {
					$results['skipped_posts']++;
				} else {
					$results['updated_posts']++;
				}
				$results['details'][] = $detail;
				continue;
			}

				if ( $changed ) {
					// FIXED: Lenient validation - only require core zones
					$core_zones = [ 'moat', 'download', 'tech_specs' ];
					$all_zones = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
					$zones_present = array_values( array_filter( $all_zones, static function ( $z ) use ( $new_content ) {
						return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $new_content, $z ) !== false;
					} ) );
					$missing_zones = array_values( array_diff( $all_zones, $zones_present ) );
					$missing_core  = array_values( array_diff( $core_zones, $zones_present ) );

					// Fail only if ALL core zones are missing
					if ( count( $missing_core ) === count( $core_zones ) ) {
						if ( ! $dry_run ) {
							update_post_meta(
								$post_id,
								self::META_BACKFILL_FAILED,
								'post_write_validation_missing_core_zones:' . implode( ',', $missing_core )
							);
						}
						
						$detail['status']        = 'failed';
						$detail['reason']        = 'post_write_validation_missing_core_zones';
						$detail['zones_present'] = $zones_present;
						$detail['zones_missing']  = $missing_zones;
						$results['skipped_posts']++;
						$results['details'][]    = $detail;
						continue;
					}
				}

				// Write upgraded content to DB for comment/attribute-format posts.
				if ( ! $dry_run && $changed ) {
					// FIXED: Lenient pre-write validation - only require core zones
					$core_zones = [ 'moat', 'download', 'tech_specs' ];
					$all_zones = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
					$zones_present = array_values( array_filter( $all_zones, static function ( $z ) use ( $new_content ) {
						return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $new_content, $z ) !== false;
					} ) );
					$missing_zones = array_values( array_diff( $all_zones, $zones_present ) );
					$missing_core  = array_values( array_diff( $core_zones, $zones_present ) );

					// Fail only if ALL core zones are missing
					if ( count( $missing_core ) === count( $core_zones ) ) {
						update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'pre_write_validation_missing_core_zones:' . implode( ',', $missing_core ) );
						$detail['status']        = 'failed';
						$detail['reason']        = 'pre_write_validation_missing_core_zones';
						$detail['zones_present'] = $zones_present;
						$detail['zones_missing'] = $missing_zones;
						$results['skipped_posts']++;
						$results['details'][]    = $detail;
						continue;
					}

					$result = self::bulk_atomic_db_update( $post_id, $new_content );
					if ( ! $result['success'] ) {
						$detail['status'] = 'failed';
						$detail['reason'] = $result['reason'] ?? 'bulk_write_failed';
						$results['skipped_posts']++;
						$results['details'][] = $detail;
						continue;
					}
				}

				if ( $changed ) {
					$results['updated_posts']++;
				} else {
					$results['skipped_posts']++;
				}

				// P2 FIX: In dry-run mode, emit per-post zone detection results.
				if ( $dry_run ) {
					$detected_zones = [];
					$missing_zones  = [];
					$all_known      = Article_Schema::get_ordered_section_keys();
					foreach ( $all_known as $zone ) {
						if ( \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $new_content, $zone ) !== false ) {
							$detected_zones[] = $zone;
						} else {
							$missing_zones[] = $zone;
						}
					}
					$detail['format_detected'] = $format;
					$detail['zones_detected']  = $detected_zones;
					$detail['zones_missing']   = $missing_zones;
					$detail['confidence']      = empty( $missing_zones ) ? 'high'
						: ( count( $detected_zones ) > count( $missing_zones ) ? 'medium' : 'low' );
				}

				$results['details'][] = $detail;
			} catch ( \Throwable $e ) {
				// Catch-all: mark permanently failed so it leaves the queue.
				if ( ! $dry_run ) {
					update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'exception: ' . substr( $e->getMessage(), 0, 100 ) );
				}
				$results['errors'][] = [
					'post_id' => $post_id,
					'error'   => $e->getMessage(),
				];
				$results['skipped_posts']++;
			}
		}

		wp_send_json_success( $results );
	}

	public static function ajax_stats(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
		}

		check_ajax_referer( 'seo_gen_nonce', 'nonce' );

		global $wpdb;

		$category_id = isset( $_POST['category_id'] ) ? (int) $_POST['category_id'] : 0;

		$excluded_category_ids = [];
		if ( isset( $_POST['excluded_category_ids'] ) ) {
			$raw = is_array( $_POST['excluded_category_ids'] ) ? $_POST['excluded_category_ids'] : [ $_POST['excluded_category_ids'] ];
			$excluded_category_ids = array_values(
				array_filter(
					array_map( 'intval', $raw ),
					static function ( $term_id ) use ( $category_id ) {
						return $term_id > 0 && $term_id !== $category_id;
					}
				)
			);
		}

		$include_category_ids = [];
		if ( $category_id > 0 ) {
			$include_category_ids[] = $category_id;
			$children = get_term_children( $category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$include_category_ids = array_merge( $include_category_ids, array_map( 'intval', $children ) );
			}
			$include_category_ids = array_values( array_unique( array_filter( array_map( 'intval', $include_category_ids ) ) ) );
		}

		$expanded_excluded = [];
		foreach ( $excluded_category_ids as $excluded_id ) {
			$expanded_excluded[] = (int) $excluded_id;
			$children = get_term_children( (int) $excluded_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$expanded_excluded = array_merge( $expanded_excluded, array_map( 'intval', $children ) );
			}
		}
		$excluded_category_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $expanded_excluded ),
					static function ( $term_id ) use ( $include_category_ids ) {
						return $term_id > 0 && ! in_array( $term_id, $include_category_ids, true );
					}
				)
			)
		);

		$joins   = '';
		$where   = [
			"p.post_type = 'post'",
			"p.post_status IN ('publish', 'draft')",
		];
		$prepare = [];

		if ( ! empty( $include_category_ids ) ) {
			$joins .= " INNER JOIN {$wpdb->term_relationships} tr_in ON p.ID = tr_in.object_id";
			$joins .= " INNER JOIN {$wpdb->term_taxonomy} tt_in ON tr_in.term_taxonomy_id = tt_in.term_taxonomy_id";
			$where[] = "tt_in.taxonomy = 'category'";
			$where[] = 'tt_in.term_id IN (' . implode( ',', array_fill( 0, count( $include_category_ids ), '%d' ) ) . ')';
			foreach ( $include_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		if ( ! empty( $excluded_category_ids ) ) {
			$where[] = "NOT EXISTS (
				SELECT 1
				FROM {$wpdb->term_relationships} tr_ex
				INNER JOIN {$wpdb->term_taxonomy} tt_ex ON tr_ex.term_taxonomy_id = tt_ex.term_taxonomy_id
				WHERE tr_ex.object_id = p.ID
				  AND tt_ex.taxonomy = 'category'
				  AND tt_ex.term_id IN (" . implode( ',', array_fill( 0, count( $excluded_category_ids ), '%d' ) ) . ')
			)';
			foreach ( $excluded_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		$sql = "SELECT DISTINCT p.ID FROM {$wpdb->posts} p {$joins} WHERE " . implode( ' AND ', $where ) . " ORDER BY p.ID ASC";
		$scoped_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( $sql, $prepare ) ) );

        $stats = [
            'total' => 0,
            'pending' => 0,
            'completed' => 0,
            'potential' => 0,
            'permanently_failed' => 0,
            'missing_software_name' => 0,
        ];

        foreach ( $scoped_ids as $post_id ) {
            $has_software_name = (bool) get_post_meta( $post_id, '_seo_gen_software_name', true );
            if ( ! $has_software_name ) {
                $has_software_name = (bool) get_post_meta( $post_id, 'seogensoftwarename', true );
            }

            // Check for plugin ownership signals (hero_data or job_id indicate plugin ownership)
            $has_ownership_signal = (bool) \SEO_Article_Generator\Plugin::get_instance()->get_hero_data( $post_id )
                || (bool) get_post_meta( $post_id, '_seo_gen_job_id', true );

            $type = Post_Type_Classifier::classify( $post_id );
            if ( ! Post_Type_Classifier::is_plugin_owned( $type ) && ! $has_ownership_signal ) {
                continue;
            }

            $review_state = (string) get_post_meta( $post_id, self::META_AMBIGUOUS, true );

            $stats['total']++;

            // Track posts with plugin ownership but missing software name
            if ( ! $has_software_name && $has_ownership_signal ) {
                $stats['missing_software_name']++;
            }

            $contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT, true );
            if ( '' === $contract ) {
                $contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY, true );
            }

            $failed = get_post_meta( $post_id, self::META_BACKFILL_FAILED, true );

            if ( $contract === self::CONTENT_CONTRACT_V1 ) {
                $stats['completed']++;
                continue;
            }

            if ( is_string( $failed ) && $failed !== '' ) {
                $stats['permanently_failed']++;
                continue;
            }

            // Potential = plugin-owned but no software_name meta (title-based identification needed)
            if ( ! $has_software_name && ! $has_ownership_signal ) {
                $stats['potential']++;
                continue;
            }

            $stats['pending']++;
        }

        wp_send_json_success( $stats );
    }

    public static function ajax_identify_posts(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
		}

		check_ajax_referer( 'seo_gen_nonce', 'nonce' );

		$category_id = isset( $_POST['category_id'] ) ? (int) $_POST['category_id'] : 0;
		$limit       = isset( $_POST['limit'] ) ? min( self::AJAX_BATCH_LIMIT, max( 1, (int) $_POST['limit'] ) ) : self::AJAX_BATCH_LIMIT;

		$excluded_category_ids = [];
		if ( isset( $_POST['excluded_category_ids'] ) ) {
			$raw = is_array( $_POST['excluded_category_ids'] ) ? $_POST['excluded_category_ids'] : [ $_POST['excluded_category_ids'] ];
			$excluded_category_ids = array_values(
				array_filter(
					array_map( 'intval', $raw ),
					static function ( $term_id ) use ( $category_id ) {
						return $term_id > 0 && $term_id !== $category_id;
					}
				)
			);
		}

		global $wpdb;

		$include_category_ids = [];
		if ( $category_id > 0 ) {
			$include_category_ids[] = $category_id;
			$children = get_term_children( $category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$include_category_ids = array_merge( $include_category_ids, array_map( 'intval', $children ) );
			}
			$include_category_ids = array_values( array_unique( array_filter( array_map( 'intval', $include_category_ids ) ) ) );
		}

		$expanded_excluded_category_ids = [];
		foreach ( $excluded_category_ids as $excluded_category_id ) {
			$expanded_excluded_category_ids[] = (int) $excluded_category_id;
			$children = get_term_children( (int) $excluded_category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$expanded_excluded_category_ids = array_merge( $expanded_excluded_category_ids, array_map( 'intval', $children ) );
			}
		}
		$excluded_category_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $expanded_excluded_category_ids ),
					static function ( $term_id ) use ( $include_category_ids ) {
						return $term_id > 0 && ! in_array( $term_id, $include_category_ids, true );
					}
				)
			)
		);

		$joins   = '';
		$where   = [
			"p.post_type = 'post'",
			"p.post_status IN ('publish', 'draft')",
			"NOT EXISTS (
				SELECT 1
				FROM {$wpdb->postmeta} pm_name_new
				WHERE pm_name_new.post_id = p.ID
				  AND pm_name_new.meta_key = '_seo_gen_software_name'
				  AND pm_name_new.meta_value <> ''
			)",
			"NOT EXISTS (
				SELECT 1
				FROM {$wpdb->postmeta} pm_name_legacy
				WHERE pm_name_legacy.post_id = p.ID
				  AND pm_name_legacy.meta_key = 'seogensoftwarename'
				  AND pm_name_legacy.meta_value <> ''
			)",
			"NOT EXISTS (
				SELECT 1
				FROM {$wpdb->postmeta} pm_review
				WHERE pm_review.post_id = p.ID
				  AND pm_review.meta_key = %s
				  AND pm_review.meta_value <> ''
			)",
			"(
				EXISTS (
					SELECT 1
					FROM {$wpdb->postmeta} pm_owner
					WHERE pm_owner.post_id = p.ID
					  AND pm_owner.meta_key IN (
						  '_seo_gen_software_name',
						  '_seo_gen_hero_data',
						  '_seo_gen_job_id',
						  'seogensoftwarename',
						  'seogenherodata'
					  )
					  AND pm_owner.meta_value <> ''
				)
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
			)",
		];
		$prepare = [
			self::META_AMBIGUOUS,
			'%seo-gen-%',
			'%wp:seo-gen/%',
			'%data-seo-gen-zone=%',
			'%<!-- SW_%',
			'%<!-- seo-gen-%',
		];

		if ( ! empty( $include_category_ids ) ) {
			$joins .= " INNER JOIN {$wpdb->term_relationships} tr_in ON p.ID = tr_in.object_id";
			$joins .= " INNER JOIN {$wpdb->term_taxonomy} tt_in ON tr_in.term_taxonomy_id = tt_in.term_taxonomy_id";
			$where[] = "tt_in.taxonomy = 'category'";
			$where[] = 'tt_in.term_id IN (' . implode( ',', array_fill( 0, count( $include_category_ids ), '%d' ) ) . ')';
			foreach ( $include_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		if ( ! empty( $excluded_category_ids ) ) {
			$where[] = "NOT EXISTS (
				SELECT 1
				FROM {$wpdb->term_relationships} tr_ex
				INNER JOIN {$wpdb->term_taxonomy} tt_ex ON tr_ex.term_taxonomy_id = tt_ex.term_taxonomy_id
				WHERE tr_ex.object_id = p.ID
				  AND tt_ex.taxonomy = 'category'
				  AND tt_ex.term_id IN (" . implode( ',', array_fill( 0, count( $excluded_category_ids ), '%d' ) ) . ')
			)';
			foreach ( $excluded_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		$sql = "
			SELECT DISTINCT p.ID
			FROM {$wpdb->posts} p
			{$joins}
			WHERE " . implode( "\n      AND ", $where ) . "
			ORDER BY p.ID ASC
			LIMIT %d OFFSET %d
		";

		$scan_chunk = max( 100, $limit * 4 );
		$scan_offset = 0;
		$post_ids    = [];

		while ( count( $post_ids ) < $limit ) {
			$batch_prepare   = $prepare;
			$batch_prepare[] = $scan_chunk;
			$batch_prepare[] = $scan_offset;

			$raw_batch = array_map(
				'intval',
				(array) $wpdb->get_col( $wpdb->prepare( $sql, $batch_prepare ) )
			);

			if ( empty( $raw_batch ) ) {
				break;
			}

			foreach ( $raw_batch as $candidate_id ) {
				$type = Post_Type_Classifier::classify( $candidate_id );

				if ( ! Post_Type_Classifier::is_plugin_owned( $type ) ) {
					continue;
				}

				$post_ids[] = $candidate_id;

				if ( count( $post_ids ) >= $limit ) {
					break;
				}
			}

			$scan_offset += $scan_chunk;
		}

		$results = [
			'batch_count' => count( $post_ids ),
			'scanned'     => 0,
			'identified'  => 0,
			'ambiguous'   => 0,
			'skipped'     => 0,
			'details'     => [],
		];

		if ( empty( $post_ids ) ) {
			wp_send_json_success( $results );
		}

		$titleAnalyzerFile = __DIR__ . '/../discovery/class-title-analyzer.php';

		if ( ! class_exists( Title_Analyzer::class, false ) && file_exists( $titleAnalyzerFile ) ) {
			require_once $titleAnalyzerFile;
		}

		if ( ! class_exists( Title_Analyzer::class, false ) ) {
			wp_send_json_error(
				array(
					'message' => 'TitleAnalyzer is not available. Identification cannot run until class-title-analyzer.php is loaded.',
				),
				500
			);
		}

		$analyzer = new Title_Analyzer();

		foreach ( $post_ids as $post_id ) {
			$type = Post_Type_Classifier::classify( $post_id );

			if ( ! Post_Type_Classifier::is_plugin_owned( $type ) ) {
				continue;
			}

			$results['scanned']++;

			$title = get_the_title( $post_id );
			$match = $analyzer->extract( $title );

			if (
				$match
				&& ! empty( $match['name'] )
				&& ! empty( $match['version'] )
				&& strtolower( (string) $match['version'] ) !== 'unknown'
			) {
				update_post_meta( $post_id, '_seo_gen_software_name', $match['name'] );
				update_post_meta( $post_id, '_seo_gen_version', $match['version'] );
				delete_post_meta( $post_id, 'seogensoftwarename' );
				delete_post_meta( $post_id, 'seogenversion' );
				update_post_meta( $post_id, self::META_AMBIGUOUS, 'identified' );

				$results['identified']++;
				$results['details'][] = [
					'id'      => $post_id,
					'status'  => 'identified',
					'name'    => $match['name'],
					'version' => $match['version'],
				];
				continue;
			}

			delete_post_meta( $post_id, '_seo_gen_software_name' );
			delete_post_meta( $post_id, '_seo_gen_version' );
			delete_post_meta( $post_id, 'seogensoftwarename' );
			delete_post_meta( $post_id, 'seogenversion' );
			update_post_meta( $post_id, self::META_AMBIGUOUS, 'ambiguous' );

			$results['ambiguous']++;
			$results['details'][] = [
				'id'     => $post_id,
				'status' => 'ambiguous',
				'title'  => $title,
			];
		}

		wp_send_json_success( $results );
	}

    /**
     * One-time fix: populate _seo_gen_software_name from _seo_gen_hero_data for
     * plugin-owned posts that are missing it — regardless of whether blocks-v1
     * contract has been written yet.
     *
     * FIXED: Removed the hard INNER JOIN on seogen_content_contract = 'blocks-v1'.
     * The original query was invisible to the 169 manually-created posts because
     * they have no contract meta. We now search ANY post that has seogen_hero_data
     * but is missing seogen_software_name, then verify ownership via PostTypeClassifier
     * + legacy fingerprint before writing anything.
     *
     * Safe to call multiple times — skips posts that already have the meta.
     */
    public static function ajax_backfill_software_name(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
        }

        check_ajax_referer( 'seo_gen_nonce', 'nonce' );

        global $wpdb;

        // FIXED: No longer INNER JOINs on blocks-v1 contract.
        // Finds plugin-owned posts that have hero_data but are missing software_name.
        $post_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT pmhero.post_id
                FROM {$wpdb->postmeta} pmhero
                LEFT JOIN {$wpdb->postmeta} pmname
                    ON pmhero.post_id = pmname.post_id
                    AND pmname.meta_key = %s
                WHERE pmhero.meta_key = %s
                AND ( pmname.meta_id IS NULL OR pmname.meta_value = '' )
                LIMIT 200",
                '_seo_gen_software_name',
                '_seo_gen_hero_data'
            )
        );

        $fixed = 0;
        $skipped = 0;
        $details = [];

        // Ensure TitleAnalyzer is available for the fallback path.
        if ( ! class_exists( \SEO_Article_Generator\Discovery\Title_Analyzer::class, false ) ) {
            $file = __DIR__ . '/../discovery/class-title-analyzer.php';
            if ( file_exists( $file ) ) {
                require_once $file;
            }
        }

        foreach ( array_map( 'intval', (array) $post_ids ) as $post_id ) {
            // Ownership guard: only touch plugin-owned or confirmed legacy posts.
            $type = Post_Type_Classifier::classify( $post_id );
            $is_owned = Post_Type_Classifier::is_plugin_owned( $type ) || $type === Post_Type_Classifier::TYPE_LEGACY;

            if ( ! $is_owned ) {
                // Last resort: run the fingerprint check directly before skipping.
                $contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT, true )
                    ?: get_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY, true );
                if ( $contract === self::CONTENT_CONTRACT_V1 ) {
                    $is_owned = true;
                } else {
                    $post = get_post( $post_id );
                    $content = $post ? (string) $post->post_content : '';
                    $score = 0;
                    // wp:seo-gen/hero is exclusively written by ContentFormatter::toHtml (weight 2)
                    if ( strpos( $content, 'wp:seo-gen/hero' ) !== false ) { $score += 2; }
                    if ( strpos( $content, 'seo-gen-download-portal' ) !== false ) { $score++; }
                    if ( strpos( $content, 'seo-gen-eeat-source' ) !== false ) { $score++; }
                    if ( strpos( $content, 'id="moat-content"' ) !== false ) { $score++; }
                    if ( strpos( $content, 'wp:rank-math/faq-block' ) !== false ) { $score++; }
                    if ( strpos( $content, 'seo-gen-related-card' ) !== false ) { $score++; }
                    $is_owned = $score >= 2;
                }
            }

            if ( ! $is_owned ) {
                $skipped++;
                continue;
            }

            // Path A: herodata carries the software name directly.
            $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data( $post_id );
            if ( is_array( $hero_data ) && ! empty( $hero_data['software_name'] ) ) {
                update_post_meta( $post_id, '_seo_gen_software_name', $hero_data['software_name'] );
                $fixed++;
                $details[] = [
                    'post_id' => $post_id,
                    'name' => $hero_data['software_name'],
                    'source' => 'herodata'
                ];
                continue;
            }

            // Path B: no herodata — extract from post title via TitleAnalyzer (same
            // logic already used in ajaxIdentifyPosts; no new code paths introduced).
            if ( class_exists( \SEO_Article_Generator\Discovery\Title_Analyzer::class, false ) ) {
                $title = get_the_title( $post_id );
                $analyzer = new \SEO_Article_Generator\Discovery\Title_Analyzer();
                $match = $analyzer->extract( $title );
                if ( ! empty( $match['name'] ) ) {
                    update_post_meta( $post_id, '_seo_gen_software_name', $match['name'] );
                    if ( ! empty( $match['version'] ) && strtolower( $match['version'] ) !== 'unknown' ) {
                        update_post_meta( $post_id, '_seo_gen_version', $match['version'] );
                    }
                    $fixed++;
                    $details[] = [
                        'post_id' => $post_id,
                        'name' => $match['name'],
                        'source' => 'title_fallback'
                    ];
                    continue;
                }
            }

            $skipped++;
        }

        wp_send_json_success( [
            'fixed' => $fixed,
            'skipped' => $skipped,
            'details' => $details,
        ] );
    }

    /**
     * One-time purge: removes _seo_gen_software_name and _seo_gen_version from posts
	 * that were incorrectly tagged by the pre-gate identify scan (version = 'Unknown'
	 * AND no _seo_gen_hero_data, meaning the plugin never actually generated them).
	 *
	 * Safe to call multiple times. Processes 200 posts per call; JS must batch until
	 * purged === 0.
	 */
	public static function ajax_purge_unknown_ownership(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
		}

		check_ajax_referer( 'seo_gen_nonce', 'nonce' );

		global $wpdb;

		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT pm_name.post_id
			 FROM {$wpdb->postmeta} pm_name
			 INNER JOIN {$wpdb->postmeta} pm_ver
			     ON pm_name.post_id = pm_ver.post_id
			     AND pm_ver.meta_key = %s
			     AND pm_ver.meta_value = %s
			 LEFT JOIN {$wpdb->postmeta} pm_hero
			     ON pm_name.post_id = pm_hero.post_id
			     AND pm_hero.meta_key = %s
			 WHERE pm_name.meta_key = %s
			   AND pm_hero.meta_id IS NULL
			 LIMIT 200",
			'_seo_gen_version',
			'Unknown',
			'_seo_gen_hero_data',
			'_seo_gen_software_name'
		) );

		$purged  = 0;
		$details = [];

		foreach ( array_map( 'intval', $post_ids ) as $post_id ) {
			$title = get_the_title( $post_id );
			delete_post_meta( $post_id, '_seo_gen_software_name' );
			delete_post_meta( $post_id, '_seo_gen_version' );
			delete_post_meta( $post_id, self::META_AMBIGUOUS );
			$purged++;
			$details[] = [ 'post_id' => $post_id, 'title' => $title ];
		}

		wp_send_json_success( [
			'purged'  => $purged,
			'details' => $details,
		] );
	}

	public static function ajax_clear_backfill_failures(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
		}

		check_ajax_referer( 'seo_gen_nonce', 'nonce' );

		global $wpdb;

		$category_id = isset( $_POST['category_id'] ) ? (int) $_POST['category_id'] : 0;

		$excluded_category_ids = [];
		if ( isset( $_POST['excluded_category_ids'] ) ) {
			$raw = is_array( $_POST['excluded_category_ids'] ) ? $_POST['excluded_category_ids'] : [ $_POST['excluded_category_ids'] ];
			$excluded_category_ids = array_values(
				array_filter(
					array_map( 'intval', $raw ),
					static function ( $term_id ) use ( $category_id ) {
						return $term_id > 0 && $term_id !== $category_id;
					}
				)
			);
		}

		$include_category_ids = [];
		if ( $category_id > 0 ) {
			$include_category_ids[] = $category_id;
			$children = get_term_children( $category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$include_category_ids = array_merge( $include_category_ids, array_map( 'intval', $children ) );
			}
			$include_category_ids = array_values( array_unique( array_filter( array_map( 'intval', $include_category_ids ) ) ) );
		}

		$expanded_excluded = [];
		foreach ( $excluded_category_ids as $excluded_id ) {
			$expanded_excluded[] = (int) $excluded_id;
			$children = get_term_children( (int) $excluded_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$expanded_excluded = array_merge( $expanded_excluded, array_map( 'intval', $children ) );
			}
		}
		$excluded_category_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $expanded_excluded ),
					static function ( $term_id ) use ( $include_category_ids ) {
						return $term_id > 0 && ! in_array( $term_id, $include_category_ids, true );
					}
				)
			)
		);

		$joins   = '';
		$where   = [
			'p.post_type = \'post\'',
			'p.post_status IN (\'publish\', \'draft\')',
		];
		$prepare = [];

		if ( ! empty( $include_category_ids ) ) {
			$joins .= " INNER JOIN {$wpdb->term_relationships} tr_in ON p.ID = tr_in.object_id";
			$joins .= " INNER JOIN {$wpdb->term_taxonomy} tt_in ON tr_in.term_taxonomy_id = tt_in.term_taxonomy_id";
			$where[] = "tt_in.taxonomy = 'category'";
			$where[] = 'tt_in.term_id IN (' . implode( ',', array_fill( 0, count( $include_category_ids ), '%d' ) ) . ')';
			foreach ( $include_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		if ( ! empty( $excluded_category_ids ) ) {
			$where[] = "NOT EXISTS (
				SELECT 1
				FROM {$wpdb->term_relationships} tr_ex
				INNER JOIN {$wpdb->term_taxonomy} tt_ex ON tr_ex.term_taxonomy_id = tt_ex.term_taxonomy_id
				WHERE tr_ex.object_id = p.ID
				  AND tt_ex.taxonomy = 'category'
				  AND tt_ex.term_id IN (" . implode( ',', array_fill( 0, count( $excluded_category_ids ), '%d' ) ) . ')
			)';
			foreach ( $excluded_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		$scoped_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT p.ID
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm_failed
				     ON p.ID = pm_failed.post_id
				     AND pm_failed.meta_key = %s
				 {$joins}
				 WHERE " . implode( ' AND ', $where ) . "
				 ORDER BY p.ID ASC",
				array_merge(
					[ self::META_BACKFILL_FAILED ],
					$prepare
				)
			)
		);

		$cleared      = 0;
		$cleared_ids = [];
		foreach ( array_map( 'intval', (array) $scoped_ids ) as $post_id ) {
			$type = Post_Type_Classifier::classify( $post_id );
			if ( ! Post_Type_Classifier::is_plugin_owned( $type ) ) {
				continue;
			}

			delete_post_meta( $post_id, self::META_BACKFILL_FAILED );
			$cleared++;
			$cleared_ids[] = $post_id;
		}

		wp_send_json_success( [
			'cleared'  => $cleared,
			'post_ids' => $cleared_ids,
		] );
	}

	private static function query_unmigrated_posts(
		int $limit,
		int $offset = 0,
		int $category_id = 0,
		array $excluded_category_ids = []
	): array {
		global $wpdb;

		$limit  = max( 1, $limit );
		$offset = max( 0, $offset );

		$sql_parts   = [];
		$prepare     = [];
		$joins       = '';
		$where       = [
			"p.post_type = 'post'",
			"p.post_status IN ('publish', 'draft')",
			"NOT EXISTS (
				SELECT 1
				FROM {$wpdb->postmeta} pm_contract
				WHERE pm_contract.post_id = p.ID
				  AND pm_contract.meta_key IN ('_seo_gen_content_contract', 'seogencontentcontract')
				  AND pm_contract.meta_value = %s
			)",
			"NOT EXISTS (
				SELECT 1
				FROM {$wpdb->postmeta} pm_failed
				WHERE pm_failed.post_id = p.ID
				  AND pm_failed.meta_key = %s
			)",
			"(
				EXISTS (
					SELECT 1
					FROM {$wpdb->postmeta} pm_owner
					WHERE pm_owner.post_id = p.ID
					  AND pm_owner.meta_key IN (
						  '_seo_gen_software_name',
						  '_seo_gen_hero_data',
						  '_seo_gen_job_id',
						  'seogensoftwarename',
						  'seogenherodata'
					  )
				)
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
				OR p.post_content LIKE %s
			)",
		];

		$prepare[] = self::CONTENT_CONTRACT_V1;
		$prepare[] = self::META_BACKFILL_FAILED;
		$prepare[] = '%seo-gen-%';
		$prepare[] = '%wp:seo-gen/%';
		$prepare[] = '%data-seo-gen-zone=%';
		$prepare[] = '%<!-- SW_%';
		$prepare[] = '%<!-- seo-gen-%';

		$include_category_ids = [];
		if ( $category_id > 0 ) {
			$include_category_ids[] = $category_id;
			$children = get_term_children( $category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$include_category_ids = array_merge( $include_category_ids, array_map( 'intval', $children ) );
			}
			$include_category_ids = array_values( array_unique( array_filter( array_map( 'intval', $include_category_ids ) ) ) );
		}

		$expanded_excluded_category_ids = [];
		foreach ( $excluded_category_ids as $excluded_category_id ) {
			$expanded_excluded_category_ids[] = (int) $excluded_category_id;
			$children = get_term_children( (int) $excluded_category_id, 'category' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$expanded_excluded_category_ids = array_merge( $expanded_excluded_category_ids, array_map( 'intval', $children ) );
			}
		}
		$excluded_category_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $expanded_excluded_category_ids ),
					static function ( $term_id ) use ( $include_category_ids ) {
						return $term_id > 0 && ! in_array( $term_id, $include_category_ids, true );
					}
				)
			)
		);

		if ( ! empty( $include_category_ids ) ) {
			$joins .= " INNER JOIN {$wpdb->term_relationships} tr_in ON p.ID = tr_in.object_id";
			$joins .= " INNER JOIN {$wpdb->term_taxonomy} tt_in ON tr_in.term_taxonomy_id = tt_in.term_taxonomy_id";
			$where[] = "tt_in.taxonomy = 'category'";
			$where[] = 'tt_in.term_id IN (' . implode( ',', array_fill( 0, count( $include_category_ids ), '%d' ) ) . ')';
			foreach ( $include_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		if ( ! empty( $excluded_category_ids ) ) {
			$where[] = "NOT EXISTS (
				SELECT 1
				FROM {$wpdb->term_relationships} tr2
				INNER JOIN {$wpdb->term_taxonomy} tt2 ON tr2.term_taxonomy_id = tt2.term_taxonomy_id
				WHERE tr2.object_id = p.ID
				  AND tt2.taxonomy = 'category'
				  AND tt2.term_id IN (" . implode( ',', array_fill( 0, count( $excluded_category_ids ), '%d' ) ) . ')
			)';
			foreach ( $excluded_category_ids as $term_id ) {
				$prepare[] = $term_id;
			}
		}

		$prepare[] = $limit;
		$prepare[] = $offset;

		$sql = "
			SELECT DISTINCT p.ID
			FROM {$wpdb->posts} p
			{$joins}
			WHERE " . implode( "\n          AND ", $where ) . "
			ORDER BY p.ID ASC
			LIMIT %d OFFSET %d
		";

		$raw_ids = $wpdb->get_col( $wpdb->prepare( $sql, $prepare ) );

		$ids = array_values(
			array_filter(
				array_map( 'intval', (array) $raw_ids ),
				static function ( int $post_id ): bool {
					$type = Post_Type_Classifier::classify( $post_id );
					return Post_Type_Classifier::is_plugin_owned( $type );
				}
			)
		);

		return $ids;
	}

	public static function upgrade_legacy_html_to_blocks( string $html, ?string $format_hint = null ): array {
		if ( trim( $html ) === '' ) {
			return [ [], $html ];
		}

		// R2 FIX: Accept pre-computed format to avoid double detect_format() scan.
		$format = ( null !== $format_hint ) ? $format_hint : self::detect_format( $html );

		// Pass-through: already in canonical block format
		if ( 'block' === $format ) {
			// CRITICAL FIX: Check if block format has complete zone coverage.
			// Posts with incomplete zones (empty sentinels at top, real content elsewhere)
			// need repair before they can be properly patched.
			$all_zones = class_exists( '\SEO_Article_Generator\Generator\Article_Schema' )
				? \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys()
				: [];
			
			if ( ! empty( $all_zones ) ) {
				$zones_present = array_values( array_filter( $all_zones, static function ( $z ) use ( $html ) {
					return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $html, $z ) !== false;
				} ) );
				
				$missing_zones = array_values( array_diff( $all_zones, $zones_present ) );
				
				// If zones are missing, run repair to ensure complete sentinel coverage
				if ( ! empty( $missing_zones ) && class_exists( '\SEO_Article_Generator\Content\Content_Normalizer' ) ) {
					[ $repaired, , $still_absent ] = self::repair_incomplete_block_format( $html );
					
					// Only use repaired content if it adds the missing zones
					if ( ! empty( $repaired ) && $repaired !== $html && empty( $still_absent ) ) {
						$html = $repaired;
					}
				}
			}
			
			$blocks = \parse_blocks( $html );
			return [ $blocks, $html ];
		}

		// P3 FIX: Handle pseudo-block format (has wp:seo-gen/* but no wp:seo-gen/section)
		// These posts need migration via Content_Normalizer to inject missing zone sentinels
		if ( 'pseudo-block' === $format ) {
			if ( class_exists( '\SEO_Article_Generator\Content\Content_Normalizer' ) ) {
				$normalized = \SEO_Article_Generator\Content\Content_Normalizer::normalize( $html );
				$html       = (string) ( $normalized['normalized_html'] ?? $html );

				// After normalization, check if we now have comment sentinels to upgrade
				if ( strpos( $html, '<!-- seo-gen-zone:' ) !== false ) {
					$upgraded = self::upgrade_comment_format( $html );
					$blocks   = \parse_blocks( $upgraded );
					return [ $blocks, $upgraded ];
				}
			}

			// Fallback: try upgrade anyway (may produce partial results)
			$upgraded = self::upgrade_comment_format( $html );
			$blocks   = \parse_blocks( $upgraded );
			return [ $blocks, $upgraded ];
		}

		// Format B: HTML comment sentinels
		if ( 'comment' === $format ) {
			$upgraded = self::upgrade_comment_format( $html );
			$blocks   = \parse_blocks( $upgraded );
			return [ $blocks, $upgraded ];
		}

		// Format A: data-seo-gen-zone attribute wrapper divs
		if ( 'attribute' === $format ) {
			$upgraded = self::upgrade_attribute_format( $html );

			// T3 FIX: upgrade_attribute_format now uses strpos-based loop (no preg_replace_callback),
			// so null return is impossible. Guard defensively anyway.
			if ( ! is_string( $upgraded ) || '' === trim( $upgraded ) ) {
				return [ [], $html ];
			}

			$blocks = \parse_blocks( $upgraded );
			return [ $blocks, $upgraded ];
		}

		// Format 'none': plain HTML, no sentinels at all
		return [ [], $html ];
	}

	/**
	 * Detect the sentinel format present in $html.
	 * Returns one of: 'block', 'comment', 'attribute', 'none'.
	 */
	public static function detect_format( string $html ): string {
		if ( strpos( $html, '<!-- wp:seo-gen/section' ) !== false ) {
			return 'block';
		}

		// P3 FIX: Detect "pseudo-block" format - has wp:seo-gen/* blocks (like wp:seo-gen/hero)
		// but LACKS the required wp:seo-gen/section zone sentinels. Common in XML imports.
		// This format needs migration to become proper block format.
		if ( preg_match( '/<!--\s*wp:seo-gen\/(?!section\b)[a-z0-9_-]+/i', $html ) ) {
			return 'pseudo-block';
		}

		if ( preg_match( '/<!--\s*seo-gen-zone(?::|\s+)[a-z0-9_-]+\s*-->/i', $html ) ) {
			return 'comment';
		}
		if ( strpos( $html, 'data-seo-gen-zone=' ) !== false ) {
			return 'attribute';
		}
		return 'none';
	}

	/**
	 * Upgrade Format B: <!-- seo-gen-zone:{zone} --> comment sentinels.
	 * Uses two-pass tokenizer instead of fragile single regex.
	 */
	private static function upgrade_comment_format( string $html ): string {
		$sentinel_pattern = '/(?:<p[^>]*>\s*)?<!--\s*seo-gen-zone:([a-z0-9\-_]+)\s*-->(?:\s*<\/p>)?/is';
		preg_match_all( $sentinel_pattern, $html, $matches, PREG_OFFSET_CAPTURE );

		if ( empty( $matches[0] ) ) {
			return $html;
		}

		$result    = '';
		$sentinels = [];

		foreach ( $matches[0] as $i => $match ) {
			$sentinels[] = [
				'offset'   => (int) $match[1],
				'length'   => strlen( $match[0] ),
				'raw_zone' => strtolower( trim( (string) $matches[1][ $i ][0] ) ),
			];
		}

		$sentinel_count = count( $sentinels );

		for ( $i = 0; $i < $sentinel_count; $i++ ) {
			$content_start = $sentinels[ $i ]['offset'] + $sentinels[ $i ]['length'];
			$content_end   = ( $i + 1 < $sentinel_count ) ? $sentinels[ $i + 1 ]['offset'] : strlen( $html );

			if ( $i === 0 && $sentinels[0]['offset'] > 0 ) {
				$result .= substr( $html, 0, $sentinels[0]['offset'] );
			}

			$raw_zone  = $sentinels[ $i ]['raw_zone'];
			// FIXED: Use canonicalize_zone for consistent alias handling
			// Remove strict Article_Schema check - canonicalize_zone handles aliases via zone_alias_map()
			$canonical = self::canonicalize_zone( $raw_zone );

			// Allow upgrade to proceed for any recognizable zone - let canonicalize_zone
			// normalize and fallback to raw zone if not in alias map
			if ( $canonical === '' ) {
				$result .= substr( $html, $sentinels[ $i ]['offset'], $content_end - $sentinels[ $i ]['offset'] );
				continue;
			}

			$content = trim( substr( $html, $content_start, $content_end - $content_start ) );
			$result .= self::serialize_section_block( $canonical, $content );
		}

		return is_string( $result ) && $result !== '' ? $result : $html;
	}

	/**
	 * Upgrade Format A: <div data-seo-gen-zone="{zone}">...</div> attribute wrappers.
	 * T1 FIX: Uses depth-counting to find balanced closing </div>, not greedy truncation.
	 */
	private static function upgrade_attribute_format( string $html ): string {
		$result  = '';
		$pos     = 0;
		$len     = strlen( $html );
		$pattern = '/<div([^>]*)\bdata-seo-gen-zone=(["\'])([a-zA-Z_-]+)\2([^>]*)>/i';

		while ( $pos < $len ) {
			if ( ! preg_match( $pattern, $html, $m, PREG_OFFSET_CAPTURE, $pos ) ) {
				$result .= substr( $html, $pos );
				break;
			}

			$match_start = (int) $m[0][1];
			$tag_end     = $match_start + strlen( $m[0][0] );
			$zone        = self::canonicalize_zone( (string) $m[3][0] );

			$result .= substr( $html, $pos, $match_start - $pos );

			$depth    = 1;
			$scan     = $tag_end;
			$close_at = -1;

			while ( $depth > 0 && $scan < $len ) {
				$next_open  = strpos( $html, '<div', $scan );
				$next_close = strpos( $html, '</div>', $scan );

				if ( false === $next_close ) {
					break;
				}

				if ( false !== $next_open && $next_open < $next_close ) {
					$char_after = $html[ $next_open + 4 ] ?? '';
					if ( in_array( $char_after, [ '>', ' ', "\t", "\n", "\r" ], true ) ) {
						$depth++;
					}
					$scan = $next_open + 1;
				} else {
					$depth--;
					if ( 0 === $depth ) {
						$close_at = $next_close;
					}
					$scan = $next_close + 6;
				}
			}

			if ( -1 === $close_at ) {
				$result .= substr( $html, $match_start, $tag_end - $match_start );
				$pos = $tag_end;
				continue;
			}

			$inner_html = substr( $html, $tag_end, $close_at - $tag_end );
			$attrs      = wp_json_encode( [ 'zone' => $zone ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			$result    .= '<!-- wp:seo-gen/section ' . $attrs . ' -->'
						. trim( $inner_html )
						. '<!-- /wp:seo-gen/section -->';
			$pos        = $close_at + 6;
		}

		return $result;
	}

	private static function serialize_section_block( string $zone, string $inner_html ): string {
		if ( function_exists( 'get_comment_delimited_block_content' ) ) {
			return get_comment_delimited_block_content(
				'seo-gen/section',
				[ 'zone' => $zone ],
				$inner_html
			);
		}

		$attrs = wp_json_encode(
			[ 'zone' => $zone ],
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

		return sprintf(
			'<!-- wp:seo-gen/section %1$s -->%2$s<!-- /wp:seo-gen/section -->',
			$attrs,
			$inner_html
		);
	}

	private static function zone_alias_map(): array {
		return class_exists( '\SEO_Article_Generator\Generator\Article_Schema' )
			? Article_Schema::get_alias_map()
			: [];
	}

	public static function canonicalize_zone( string $zone, array $aliases = [] ): string {
		$zone = strtolower( trim( $zone ) );

		if ( $zone === '' ) {
			return '';
		}

		if ( class_exists( '\SEO_Article_Generator\Generator\Article_Schema' ) ) {
			$schema_key = Article_Schema::get_canonical_key( $zone );
			if ( is_string( $schema_key ) && $schema_key !== '' ) {
				return $schema_key;
			}
		}

		$aliases = ! empty( $aliases ) ? $aliases : self::zone_alias_map();
		$key     = str_replace( [ '_', ' ' ], '-', $zone );

		return isset( $aliases[ $key ] ) ? $aliases[ $key ] : $zone;
	}

	private static function detect_injected_zones( string $before, string $after ): array {
		$zones    = class_exists( '\SEO_Article_Generator\Generator\Article_Schema' )
			? Article_Schema::get_ordered_section_keys()
			: array_values( array_unique( self::zone_alias_map() ) );
		$injected = array();

		foreach ( $zones as $zone ) {
			$needle = '"zone":"' . $zone . '"';
			if ( strpos( $before, $needle ) === false && strpos( $after, $needle ) !== false ) {
				$injected[] = $zone;
			}
		}

		return $injected;
	}

	/**
	 * Attempt to wrap un-sentineled zone content for a format=block post
	 * that has incomplete zone coverage.
	 *
	 * Strategy (three steps):
	 *  1. DOWNGRADE   — strip existing canonical seo-gen/section block wrappers
	 *                   back to comment sentinels so the whole document is uniform.
	 *  2. NORMALIZE   — run ContentNormalizer::normalize() which detects zones via
	 *                   CSS class, heading anchor, and regex patterns, injecting
	 *                   <!-- seo-gen-zone:X --> comments before each detected zone.
	 *  3. UPGRADE     — run upgrade_comment_format() to convert all comment
	 *                   sentinels (both original and newly injected) back to the
	 *                   canonical <!-- wp:seo-gen/section {"zone":"X"} --> format.
	 *
	 * Returns [ string $repaired_html, array $zones_added, array $zones_still_absent ].
	 * If the repair produces no change, returns the original HTML with empty arrays.
	 *
	 * @param string $html Existing post HTML (format=block, incomplete zones).
	 * @return array{ 0: string, 1: string[], 2: string[] }
	 */
	private static function repair_incomplete_block_format( string $html ): array {

		// Guard: ContentNormalizer must be loaded.
		if ( ! class_exists( \SEO_Article_Generator\Content\Content_Normalizer::class ) ) {
			return [ $html, [], [] ];
		}

		// ── Step 1: DOWNGRADE ────────────────────────────────────────────────
		// Convert <!-- wp:seo-gen/section {"zone":"X"} --> back to
		// <!-- seo-gen-zone:X --> so the document is in uniform comment format.
		$downgraded = preg_replace_callback(
			'/<!--\s*wp:seo-gen\/section\s+(\{.*?\})\s*-->/i',
			static function ( array $m ): string {
				$attrs = json_decode( (string) $m[1], true );
				$zone  = '';

				if ( is_array( $attrs ) && ! empty( $attrs['zone'] ) ) {
					$zone = self::canonicalize_zone( (string) $attrs['zone'] );
				}

				return $zone !== '' ? '<!-- seo-gen-zone:' . $zone . ' -->' : $m[0];
			},
			$html
		);
		$downgraded = str_replace( '<!-- /wp:seo-gen/section -->', '', (string) $downgraded );

		// ── Step 2: NORMALIZE ────────────────────────────────────────────────
		$norm_result = \SEO_Article_Generator\Content\Content_Normalizer::normalize( $downgraded );
		$normalized  = $norm_result['normalized_html'] ?? $downgraded;

		// If ContentNormalizer made no changes, no new zones were detected.
		if ( $normalized === $downgraded ) {
			[ , $re_upgraded ] = self::upgrade_legacy_html_to_blocks( $normalized, 'comment' );
			return [ is_string( $re_upgraded ) && $re_upgraded !== '' ? $re_upgraded : $html, [], [] ];
		}

		// ── Step 3: UPGRADE ──────────────────────────────────────────────────
		[ , $upgraded ] = self::upgrade_legacy_html_to_blocks( $normalized, 'comment' );

		if ( ! is_string( $upgraded ) || trim( $upgraded ) === '' ) {
			return [ $html, [], [] ];
		}

		// ── Diff: zones_added and zones_still_absent ─────────────────────────
		$all_zones = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();

		$present_before = array_values( array_filter(
			$all_zones,
			static function ( $z ) use ( $html ) {
				return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $html, $z ) !== false;
			}
		) );

		$present_after = array_values( array_filter(
			$all_zones,
			static function ( $z ) use ( $upgraded ) {
				return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $upgraded, $z ) !== false;
			}
		) );

		$zones_added  = array_values( array_diff( $present_after, $present_before ) );
		$zones_absent = array_values( array_diff( $all_zones, $present_after ) );

		return [ $upgraded, $zones_added, $zones_absent ];
	}

	private static function mark_post_as_backfilled( int $post_id ): void {
		$now = \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now();

		update_post_meta( $post_id, self::META_BACKFILL, $now );
		update_post_meta( $post_id, self::META_CONTENT_CONTRACT, self::CONTENT_CONTRACT_V1 );
		delete_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY );

		// T4 FIX: Clear any stale failure flag from a previous attempt.
		// Without this, a successfully-retried post stays in the permanently_failed stat count.
		delete_post_meta( $post_id, self::META_BACKFILL_FAILED );

		// FIXED: Clear contract reset counter on successful backfill
		delete_post_meta( $post_id, '_seo_gen_contract_reset_count' );
	}

	/**
	 * @return array{ success: bool, reason?: string }
	 */
	private static function bulk_atomic_db_update( int $post_id, string $content ): array {
		global $wpdb;

		$current_contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT, true );
		if ( '' === $current_contract ) {
			$current_contract = get_post_meta( $post_id, self::META_CONTENT_CONTRACT_LEGACY, true );
		}

		if ( $current_contract === self::CONTENT_CONTRACT_V1 && strpos( $content, '<!-- wp:seo-gen/section ' ) !== false ) {
			if ( ! get_post_meta( $post_id, '_seo_gen_software_name', true ) ) {
				$hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data( $post_id );
				if ( is_array( $hero_data ) && ! empty( $hero_data['software_name'] ) ) {
					update_post_meta( $post_id, '_seo_gen_software_name', $hero_data['software_name'] );
				}
			}

			clean_post_cache( $post_id );
			return [ 'success' => true ];
		}

		if ( function_exists( 'parse_blocks' ) ) {
			$parsed = \parse_blocks( $content );
			$valid_blocks = array_filter( $parsed, static function ( $b ) {
				return ! empty( $b['blockName'] );
			} );

			if ( empty( $valid_blocks ) ) {
				update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'post_write_validation_parse_blocks_empty' );
				return [ 'success' => false, 'reason' => 'post_write_validation_parse_blocks_empty' ];
			}

			$has_zone_block = false;
			array_walk_recursive( $parsed, static function ( $val ) use ( &$has_zone_block ) {
				if ( $val === 'seo-gen/section' ) {
					$has_zone_block = true;
				}
			} );

			if ( ! $has_zone_block ) {
				update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'post_write_validation_no_zone_blocks' );
				return [ 'success' => false, 'reason' => 'post_write_validation_no_zone_blocks' ];
			}
		}

		if ( class_exists( '\SEO_Article_Generator\Tools\Sentinel_Fallback_Utility' ) ) {
			$audit = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::audit(
				$content,
				array( 'is_update' => false )
			);

			if ( ! empty( $audit['fatal_reasons'] ) ) {
				$fatal_reason = 'post_write_validation_fatal:' . implode( ',', (array) $audit['fatal_reasons'] );
				update_post_meta( $post_id, self::META_BACKFILL_FAILED, $fatal_reason );
				return [ 'success' => false, 'reason' => $fatal_reason ];
			}
		}

		$core_zones    = [ 'moat', 'download', 'tech_specs' ];
		$all_zones     = Article_Schema::get_ordered_section_keys();
		$zones_present = array_values(
			array_filter(
				$all_zones,
				static function ( $z ) use ( $content ) {
					return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $content, $z ) !== false;
				}
			)
		);
		$missing_core = array_values( array_diff( $core_zones, $zones_present ) );

		// STRICT GATE: If ANY core zone is missing, abort the db write to prevent corruption.
		// Tag the post so the Discovery Processor knows to ignore existing content and do a full rewrite.
		if ( count( $missing_core ) > 0 ) {
			$fatal_reason = 'post_write_validation_missing_core_zones:' . implode( ',', $missing_core );
			update_post_meta( $post_id, self::META_BACKFILL_FAILED, $fatal_reason );
			update_post_meta( $post_id, '_seo_gen_force_legacy_rewrite', '1' );
			return [ 'success' => false, 'reason' => $fatal_reason ];
		}

		$updated = $wpdb->update(
			$wpdb->posts,
			[
				'post_content'      => $content,
				'post_modified'     => \SEO_Article_Generator\Utils\Plugin_Time::site_mysql_from_utc_ts( \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() ),
				'post_modified_gmt' => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now(),
			],
			[ 'ID' => $post_id ],
			[ '%s', '%s', '%s' ],
			[ '%d' ]
		);

		if ( false === $updated ) {
			update_post_meta( $post_id, self::META_BACKFILL_FAILED, 'bulk_migration_db_update_failed' );
			return [
				'success' => false,
				'reason'  => 'bulk_migration_db_update_failed',
			];
		}

		if ( ! get_post_meta( $post_id, '_seo_gen_software_name', true ) ) {
				$hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data( $post_id );
			if ( is_array( $hero_data ) && ! empty( $hero_data['software_name'] ) ) {
				update_post_meta( $post_id, '_seo_gen_software_name', $hero_data['software_name'] );
			}
		}

		clean_post_cache( $post_id );
		self::mark_post_as_backfilled( $post_id );

		return [ 'success' => true ];
	}
}
