<?php

if (! defined('ABSPATH')) {
	exit;
}

class NM_Social_Image_Generator
{
 public static function init() {
 add_action('transition_post_status', array(self::class, 'generate_on_publish'), 5, 3);
 add_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99, 3);
 add_action('nm_generate_social_image_cron', array(self::class, 'handle_cron'), 10, 1);
 add_action('before_delete_post', array(self::class, 'cleanup_on_delete'), 10, 1);
 }

    public static function generate_on_publish($new_status, $old_status, $post) {
        if ($post->post_type !== 'mcq') {
            return;
        }

        if ($new_status === 'publish' && $old_status !== 'publish') {
            remove_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99);
            self::get_or_generate_image($post->ID, '', 4, true);
            add_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99, 3);
        }
    }

public static function generate_after_save($postid) {
    if (!self::has_renderable_options($postid, 2)) {
 if (!wp_next_scheduled('nm_generate_social_image_cron', array((int) $postid))) {
 wp_schedule_single_event(time() + 90, 'nm_generate_social_image_cron', array((int) $postid));
 }
 return false;
 }

    if (function_exists('imagecreatetruecolor') && function_exists('imagewebp')) {
 return self::get_or_generate_image($postid, '', 4, true);
 }

    if (!wp_next_scheduled('nm_generate_social_image_cron', array((int) $postid))) {
 wp_schedule_single_event(time() + 90, 'nm_generate_social_image_cron', array((int) $postid));
    }

    return false;
}

	public static function schedule_on_save($post_id, $post, $update)
	{
		if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
			return;
		}
		if (! $post || $post->post_type !== 'mcq') {
			return;
		}
		$existing_url = get_post_meta($post_id, '_nm_social_image_url', true);
		if (!empty($existing_url)) {
			$upload_dir = wp_upload_dir();
			$version = get_post_meta($post_id, '_nm_social_image_version', true) ?: 1;
			$file_path = $upload_dir['basedir'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp';
			if (file_exists($file_path)) {
				return;
			}
		}

		if (wp_next_scheduled('nm_generate_social_image_cron', array((int)$post_id))) {
			return;
		}

		wp_schedule_single_event(time() + 90, 'nm_generate_social_image_cron', array((int)$post_id));
	}

    public static function handle_cron($post_id)
    {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return;
        }
        remove_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99);
        self::get_or_generate_image($post_id, '', 4, true);
        add_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99, 3);
    }

    public static function cleanup_on_delete($post_id) {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'mcq') {
            return;
        }

        if ($post->post_status === 'publish') {
            return;
        }

        $version = get_post_meta($post_id, '_nm_social_image_version', true);
        if (!$version) {
            $version = 1;
        }

        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp';

        if (file_exists($file_path)) {
            @unlink($file_path);
        }

        // Also remove the story variant if it exists
        $story_file_path = $upload_dir['basedir'] . '/nm-social/mcq-story-' . $post_id . '-' . $version . '.webp';
        if (file_exists($story_file_path)) {
            @unlink($story_file_path);
        }

        $thumbnail_id = get_post_thumbnail_id($post_id);
        if ($thumbnail_id) {
            wp_delete_attachment($thumbnail_id, true);
        }

        delete_post_meta($post_id, '_nm_social_image_url');
        delete_post_meta($post_id, '_nm_social_story_image_url');
        delete_post_meta($post_id, '_nm_social_image_version');
    }

    /**
     * Daily cleanup: delete story image files older than 48 hours.
     *
     * Story images must persist until Buffer's async pipeline fetches them.
     * Once they've been available for 48 hours, they're safe to remove.
     */
    public static function cleanup_old_story_images()
    {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'] . '/nm-social';

        if (! is_dir($base_dir)) {
            return;
        }

        $deleted = 0;
        $now     = time();
        $max_age = 48 * HOUR_IN_SECONDS;

        foreach (glob($base_dir . '/mcq-story-*.webp') as $file_path) {
            if (file_exists($file_path) && ($now - filemtime($file_path)) > $max_age) {
                if (@unlink($file_path)) {
                    $deleted++;
                }
            }
        }

        if ($deleted > 0) {
            error_log('NM Social Image: Daily cleanup deleted ' . $deleted . ' stale story image(s) from ' . $base_dir);
        }
    }

private static function normalize_options($raw) {
    if (is_string($raw)) {
        $decoded = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $raw = $decoded;
        }
    }

    if (!is_array($raw)) {
        return array();
    }

    if (isset($raw['options']) && is_array($raw['options'])) {
        $raw = $raw['options'];
    }

    $normalized = array();

    foreach ($raw as $key => $value) {
        if (is_array($value)) {
            $value = $value['text'] ?? $value['option'] ?? $value['label'] ?? '';
        }

        $value = trim(wp_strip_all_tags((string) $value));

        if ($value !== '') {
            $normalized[] = $value;
        }

        if (count($normalized) === 4) {
            break;
        }
    }

    return $normalized;
}

 private static function has_renderable_options($postid, $minimum = 2) {
 return count(self::normalize_options(get_post_meta($postid, 'mcq_options', true))) >= $minimum;
 }
	/**
	 * Generate or retrieve a social share image for an MCQ.
	 *
	 * @param int $post_id The MCQ post ID.
	 * @return string The URL of the generated (or cached) image.
	 */
	public static function get_or_generate_image($post_id, $question_text = '', $answer_count = 4, $force_sync = false)
	{
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'] . '/nm-social';
 $base_url = set_url_scheme($upload_dir['baseurl'] . '/nm-social', 'https');

		if (! file_exists($base_dir)) {
			wp_mkdir_p($base_dir);
		}

		// Check if we already have a generated image version
		$version = get_post_meta($post_id, '_nm_social_image_version', true);
		if (! $version) {
			$version = 1;
		}

		$filename  = 'mcq-' . $post_id . '-' . $version . '.webp';
		$file_path = $base_dir . '/' . $filename;
		$file_url  = $base_url . '/' . $filename;

		// If file exists, return it
		if (file_exists($file_path)) {
			// ✅ FIX: Ensure it's attached as the Featured Image even if the file already exists on disk
			self::set_featured_image($post_id, $file_path, $file_url);
			return $file_url;
		}

		// Don't kill memory on frontend loads! Only generate if explicitly forced (e.g. cron).
		if (! $force_sync) {
			if (! wp_next_scheduled('nm_generate_social_image_cron', array((int)$post_id))) {
				wp_schedule_single_event(time() + 15, 'nm_generate_social_image_cron', array((int)$post_id));
			}
			return false;
		}

		// Generate new image
		return self::generate_image($post_id, $file_path, $file_url, $version);
	}

	/**
	 * Generate or retrieve a 9:16 story-optimized image for Instagram/Facebook Stories.
	 *
	 * Creates a 1080x1920 canvas with the same gradient background, then places
	 * the existing 1200x630 feed image centered and scaled to fit the width.
	 * This prevents the full-screen stretching that makes feed images unreadable
	 * as Instagram Stories.
	 *
	 * @param int $post_id The MCQ post ID.
	 * @return string|false URL of the story image, or false on failure.
	 */
	public static function get_or_generate_story_image($post_id)
	{
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'] . '/nm-social';
		$base_url   = set_url_scheme($upload_dir['baseurl'] . '/nm-social', 'https');

		if (! file_exists($base_dir)) {
			wp_mkdir_p($base_dir);
		}

		$version = get_post_meta($post_id, '_nm_social_image_version', true);
		if (! $version) {
			$version = 1;
		}

		$story_filename  = 'mcq-story-' . $post_id . '-' . $version . '.webp';
		$story_file_path = $base_dir . '/' . $story_filename;
		$story_file_url  = $base_url . '/' . $story_filename;

		if (file_exists($story_file_path)) {
			error_log('NM Social Image: Story image cache hit for post ' . $post_id . ' — ' . $story_file_url);
			return $story_file_url;
		}

		// Feed image must exist first
		$feed_filename  = 'mcq-' . $post_id . '-' . $version . '.webp';
		$feed_file_path = $base_dir . '/' . $feed_filename;
		if (! file_exists($feed_file_path)) {
			error_log('NM Social Image: Cannot generate story image for post ' . $post_id . ' — feed image not found at ' . $feed_file_path);
			return false;
		}

		if (! function_exists('imagecreatetruecolor') || ! function_exists('imagewebp')) {
			error_log('NM Social Image: Cannot generate story image for post ' . $post_id . ' — GD/WebP libraries missing.');
			return false;
		}

		// 9:16 story canvas (1080x1920)
		$story_w = 1080;
		$story_h = 1920;
		$story_im = imagecreatetruecolor($story_w, $story_h);

		// Match the feed image gradient colors
		$blue_r   = 52;
		$blue_g   = 152;
		$blue_b   = 219;
		$purple_r = 102;
		$purple_g = 126;
		$purple_b = 234;

		for ($i = 0; $i < $story_h; $i++) {
			$p = $i / $story_h;
			$r = $blue_r + ($purple_r - $blue_r) * $p;
			$g = $blue_g + ($purple_g - $blue_g) * $p;
			$b = $blue_b + ($purple_b - $blue_b) * $p;
			$color = imagecolorallocate($story_im, (int) $r, (int) $g, (int) $b);
			imageline($story_im, 0, $i, $story_w, $i, $color);
		}

		// Load feed image and center it on the 9:16 canvas
		if (function_exists('imagecreatefromwebp')) {
			$feed_im = @imagecreatefromwebp($feed_file_path);
			if ($feed_im) {
				$feed_w = imagesx($feed_im);
				$feed_h = imagesy($feed_im);

				// Scale to fit story width (1080), preserve aspect ratio
				$scale = $story_w / $feed_w;
				$new_w = (int) round($feed_w * $scale);
				$new_h = (int) round($feed_h * $scale);

				// Center vertically
				$dst_x = 0;
				$dst_y = (int) round(($story_h - $new_h) / 2);

				imagecopyresampled($story_im, $feed_im, $dst_x, $dst_y, 0, 0, $new_w, $new_h, $feed_w, $feed_h);
				imagedestroy($feed_im);
			}
		}

		imagewebp($story_im, $story_file_path, 90);
		imagedestroy($story_im);

		update_post_meta($post_id, '_nm_social_story_image_url', $story_file_url);

		error_log('NM Social Image: Story image generated for post ' . $post_id . ' — ' . $story_file_url);

		return $story_file_url;
	}

	/**
	 * The core generation logic using PHP GD.
	 * Implements "Option 2B: The Vibrant Gradient + Footer Bar"
	 */
	private static function generate_image($post_id, $file_path, $file_url, $version = 2)
	{
		// @MODIFIED v9.0.3 - Add GD/WebP guards
		if (! function_exists('imagecreatetruecolor') || ! function_exists('imagewebp')) {
			return false;
		}
		// 1. Setup Canvas (1200x630)
		$width  = 1200;
		$height = 630;
		$im     = imagecreatetruecolor($width, $height);

		// 2. Colors
		// Gradient Colors: Blue #3498db to Purple #667eea
		$blue_r   = 52;
		$blue_g   = 152;
		$blue_b   = 219;
		$purple_r = 102;
		$purple_g = 126;
		$purple_b = 234;

		$white = imagecolorallocate($im, 255, 255, 255);
		$gold  = imagecolorallocate($im, 255, 215, 0); // #ffd700

		// Semi-transparent footer background (Black with ~35% opacity = ~90 alpha in GD 0-127 scale)
		$footer_bg = imagecolorallocatealpha($im, 0, 0, 0, 90);

		// Badge background: White with low opacity (~20% opacity = ~100 alpha)
		$badge_bg = imagecolorallocatealpha($im, 255, 255, 255, 100);

		// 3. Draw Diagonal Gradient (Top-Left to Bottom-Right)
		// Simple interpolation loop
		for ($i = 0; $i < $height; $i++) {
			// Calculate interpolation factor (0.0 to 1.0) based on Y position
			$p = $i / $height;
			$r = $blue_r + ($purple_r - $blue_r) * $p;
			$g = $blue_g + ($purple_g - $blue_g) * $p;
			$b = $blue_b + ($purple_b - $blue_b) * $p;

			$color = imagecolorallocate($im, (int) $r, (int) $g, (int) $b);
			imageline($im, 0, $i, $width, $i, $color);
		}

		// 4. Load Fonts - ✅ Robust Path Detection
		// Try primary path first (NM_PLUGIN_PATH)
		$font_path = NM_PLUGIN_PATH . 'assets/fonts/Roboto-Bold.ttf';

		// Fallback: Check relative to this file if constant isn't working as expected
		if (! file_exists($font_path)) {
			$font_path = plugin_dir_path(dirname(__FILE__)) . 'assets/fonts/Roboto-Bold.ttf';
		}

		// Fallback: WordPress Core fonts
		if (! file_exists($font_path)) {
			$font_path = ABSPATH . WPINC . '/fonts/roboto/Roboto-Bold.ttf';
		}

		$font_regular = $font_path; // use bold for question as well for visibility

		$has_font = file_exists($font_path);

		// Log error if font missing to help debug
		if (! $has_font) {
			error_log('NM Social Image Generator: Font not found at ' . NM_PLUGIN_PATH . 'assets/fonts/Roboto-Bold.ttf');
		}

		// 5. Draw Logo (Top Left) - Site logo image if available, else text
		$logo_drawn = false;

		// Try WordPress custom logo
		$logo_id = get_theme_mod('custom_logo');
		if ($logo_id) {
			$logo_path = get_attached_file($logo_id);
			if ($logo_path && file_exists($logo_path)) {
				$logo_info = getimagesize($logo_path);
				if ($logo_info) {
					$src_w = $logo_info[0];
					$src_h = $logo_info[1];

					// Target box ~220x60, preserving aspect ratio
					$target_h = 60;
					$scale    = $target_h / $src_h;
					$target_w = (int) round($src_w * $scale);
					if ($target_w > 220) {
						$scale    = 220 / $src_w;
						$target_w = 220;
						$target_h = (int) round($src_h * $scale);
					}

					$dst_x = 40;
					$dst_y = 40;

					switch ($logo_info['mime']) {
						case 'image/png':
							$logo_im = imagecreatefrompng($logo_path);
							break;
						case 'image/jpeg':
						case 'image/jpg':
							$logo_im = imagecreatefromjpeg($logo_path);
							break;
						default:
							$logo_im = null;
							break;
					}

					if ($logo_im) {
						imagecopyresampled(
							$im,
							$logo_im,
							$dst_x,
							$dst_y,
							0,
							0,
							$target_w,
							$target_h,
							$src_w,
							$src_h
						);
						imagedestroy($logo_im);
						$logo_drawn = true;
					}
				}
			}
		}

		// Fallback: text brand if no logo image could be drawn
		if (! $logo_drawn) {
			$brand_text = 'TheQuizWire';
			if ($has_font) {
				imagettftext($im, 26, 0, 40, 70, $white, $font_path, $brand_text);
			} else {
				imagestring($im, 5, 40, 40, $brand_text, $white);
			}
		}

		// 6. Draw Badge (Top Right)
		// "X Options"
		$options = self::normalize_options(get_post_meta($post_id, 'mcq_options', true));
$count = count($options);
$badge_text = ($count > 0 ? $count : 4) . ' Options';

		if ($has_font) {
			// Badge Box
			$bbox   = imagettfbbox(14, 0, $font_path, $badge_text);
			$text_w = $bbox[2] - $bbox[0];
			$box_x1 = $width - 40 - $text_w - 30; // Right margin 40, padding 15*2
			$box_y1 = 35;
			$box_x2 = $width - 40;
			$box_y2 = 75;

			imagefilledrectangle($im, $box_x1, $box_y1, $box_x2, $box_y2, $badge_bg);
			imagettftext($im, 14, 0, $box_x1 + 15, $box_y1 + 28, $white, $font_path, $badge_text);
		} else {
			imagestring($im, 4, $width - 120, 40, $badge_text, $white);
		}

		// 7. Draw Main Title (Moved Up)
		// "Daily Quiz Challenge"
		$title_text = 'Daily Quiz Challenge';

		if ($has_font) {
			$bbox   = imagettfbbox(32, 0, $font_path, $title_text);
			$text_w = $bbox[2] - $bbox[0];
			$x      = ($width - $text_w) / 2;
			$y      = 130; // Moved up from 200

			// Drop shadow
			$shadow_color = imagecolorallocatealpha($im, 0, 0, 0, 100);
			imagettftext($im, 32, 0, (int) ($x + 2), (int) ($y + 4), $shadow_color, $font_path, $title_text);
			imagettftext($im, 32, 0, (int) $x, (int) $y, $white, $font_path, $title_text);
		} else {
			$x = ($width - (strlen($title_text) * 10)) / 2;
			imagestring($im, 5, $x, 100, $title_text, $white);
		}

		// 8. Draw Question Text (Wrapped & Moved Up)
		// Prefer the MCQ question meta; fall back to post content/title if empty
		$question = get_post_meta($post_id, 'mcq_question', true);
		if (! $question) {
			$question = get_post_field('post_content', $post_id);
		}
		if (! $question) {
			$question = get_the_title($post_id);
		}
		$question = wp_strip_all_tags($question);

		// Store question bottom Y to position options relatively
		$question_bottom_y = 250;

		if ($has_font) {
			$len = mb_strlen($question);
			if ($len > 260) {
				$font_size = 22;
			} elseif ($len > 180) {
				$font_size = 24;
			} else {
				$font_size = 30;
			}

			$max_width   = 1000; // Slightly wider
			$line_height = 45;
			$start_y     = 200; // Moved up from 300

			$words        = explode(' ', $question);
			$lines        = array();
			$current_line = '';

			foreach ($words as $word) {
				$test_line = $current_line . ($current_line ? ' ' : '') . $word;
				$bbox      = imagettfbbox($font_size, 0, $font_regular, $test_line);
				if (($bbox[2] - $bbox[0]) > $max_width) {
					$lines[]      = $current_line;
					$current_line = $word;
				} else {
					$current_line = $test_line;
				}
			}
			$lines[] = $current_line;

			// Background panel behind question text
			$line_count   = count($lines);
			$total_height = $line_count * $line_height;
			$padding_y    = 20;
			$padding_x    = 60;
			$panel_top    = $start_y - $line_height - $padding_y + 10; // Adjust for baseline
			$panel_bottom = $start_y + ($line_count - 1) * $line_height + $padding_y + 15;

			$panel_color = imagecolorallocatealpha($im, 0, 0, 0, 90); // dark, ~35% opacity
			imagefilledrectangle(
				$im,
				$padding_x,
				$panel_top,
				$width - $padding_x,
				$panel_bottom,
				$panel_color
			);

			// Draw lines centered
			foreach ($lines as $i => $line) {
				$bbox   = imagettfbbox($font_size, 0, $font_regular, $line);
				$text_w = $bbox[2] - $bbox[0];
				$x      = ($width - $text_w) / 2;
				$y      = $start_y + ($i * $line_height);

				// Shadow
				$shadow = imagecolorallocatealpha($im, 0, 0, 0, 100);
				imagettftext($im, $font_size, 0, (int) ($x + 2), (int) ($y + 2), $shadow, $font_regular, $line);

				// Main white text
				imagettftext($im, $font_size, 0, (int) $x, (int) $y, $white, $font_regular, $line);
			}

			$question_bottom_y = $panel_bottom; // Update for options positioning
		} else {
			// Simple fallback
			$x = ($width - (strlen($question) * 8)) / 2;
			imagestring($im, 5, $x, 150, substr($question, 0, 100), $white);
			$question_bottom_y = 200;
		}

// 9. Draw Options Grid (2x2)
// Retrieve and normalize options
$options_raw = get_post_meta($post_id, 'mcq_options', true);
$grid_options = self::normalize_options($options_raw);

// Do not generate a broken question-only image when options are missing
if (empty($grid_options)) {
    imagedestroy($im);
    return false;
}

// Fill remaining spots if less than 4
while (count($grid_options) < 4) {
    $grid_options[] = '';
}

		if ($has_font) {
			$grid_start_y = $question_bottom_y + 40; // 40px gap below question
			$col_gap      = 30;
			$row_gap      = 25;

			// Grid layout: 2 columns centered
			// Total width available: 1200. Let's use ~1000px width for options area.
			// Item width = (1000 - gap) / 2 = 485px.
			$item_w = 480;
			$item_h = 60; // Height of option "pill"

			// Calculate starting X to center the entire grid
			$grid_total_w = ($item_w * 2) + $col_gap;
			$grid_start_x = ($width - $grid_total_w) / 2;

			$letters = array('A', 'B', 'C', 'D');

			// Check vertical overflow
			$needed_height = ($item_h * 2) + $row_gap;
			$footer_top    = $height - 80;
			if (($grid_start_y + $needed_height) > $footer_top) {
				// Squeeze if tight
				$grid_start_y = $question_bottom_y + 20;
				$row_gap = 15;
			}

			$idx = 0;
			foreach ($grid_options as $opt_text) {
				$opt_text = trim($opt_text);
				if (empty($opt_text)) continue;

				$col = $idx % 2; // 0 or 1
				$row = floor($idx / 2); // 0 or 1

				$x = $grid_start_x + ($col * ($item_w + $col_gap));
				$y = $grid_start_y + ($row * ($item_h + $row_gap));

				// 9a. Draw Pill Background (Semi-transparent white)
				$pill_color = imagecolorallocatealpha($im, 255, 255, 255, 110); // ~15% opacity white (127 scale: 110 is ~13% visible? Reversed: 0 is opaque, 127 transp. 110 is very transparent. Wait. GD alpha is 0 opaque, 127 transparent. 
				// To get 15% opacity (mostly transparent), we want alpha ~108.
				// To get 15% VISIBLE aka 85% transparent, alpha ~108. 
				// Mockup had 0.15 opacity.
				$pill_color = imagecolorallocatealpha($im, 255, 255, 255, 40);

				imagefilledrectangle($im, $x, $y, $x + $item_w, $y + $item_h, $pill_color);

				// 9b. Draw Letter Circle
				$circle_dia = 40;
				$circle_x   = $x + 30; // 30px padding left
				$circle_y   = $y + ($item_h / 2); // Vertically centered

				// Gold Circle
				imagefilledellipse($im, $circle_x, $circle_y, $circle_dia, $circle_dia, $gold);

				// Letter
				$letter = $letters[$idx];
				$l_bbox = imagettfbbox(16, 0, $font_path, $letter);
				$l_w    = $l_bbox[2] - $l_bbox[0];
				$l_h    = $l_bbox[1] - $l_bbox[7]; // Height approx
				// Centering text in circle
				$lx = $circle_x - ($l_w / 2);
				$ly = $circle_y + ($l_h / 2) - 1;

				$black = imagecolorallocate($im, 30, 30, 30);
				imagettftext($im, 16, 0, (int)$lx, (int)$ly, $black, $font_path, $letter);

				// 9c. Draw Option Text
				$text_x = $circle_x + ($circle_dia / 2) + 15; // Gap after circle
				$text_y = $circle_y + 8; // Baseline adj
				$max_text_w = $item_w - ($text_x - $x) - 10; // Remaining width

				// Define Black Color for text (User Request)
				$option_text_color = imagecolorallocate($im, 0, 0, 0);

				// Adaptive Font Scaling to avoid truncation
				$font_sizes = [18, 16, 14, 12];
				$final_font_size = 12;
				$fits = false;

				foreach ($font_sizes as $size) {
					$t_bbox = imagettfbbox($size, 0, $font_regular, $opt_text);
					if (($t_bbox[2] - $t_bbox[0]) <= $max_text_w) {
						$final_font_size = $size;
						$fits = true;
						break;
					}
				}

				$display_text = $opt_text;

				// If it still doesn't fit at smallest size, truncate
				if (!$fits) {
					$final_font_size = 12;
					// Truncate loop
					while (true) {
						$t_bbox = imagettfbbox($final_font_size, 0, $font_regular, $display_text . '...');
						if (($t_bbox[2] - $t_bbox[0]) <= $max_text_w) break;
						if (mb_strlen($display_text) == 0) break;
						$display_text = mb_substr($display_text, 0, -1);
					}
					$display_text .= '...';
				}

				// Adjust Y slightly for smaller fonts to keep centered
				// Baseline shift approx: 18->8, 12->5
				$y_adjustment = 8;
				if ($final_font_size < 16) $y_adjustment = 6;

				imagettftext($im, $final_font_size, 0, (int)$text_x, (int)($circle_y + $y_adjustment), $option_text_color, $font_regular, $display_text);

				$idx++;
			}
		}

		// 10. Draw Footer Bar (Bottom) - Updated Text
		$footer_height = 80;
		imagefilledrectangle($im, 0, $height - $footer_height, $width, $height, $footer_bg);

		// "↓ View Correct Answer and Explanation on TheQuizWire.com"
		$text_part1 = '↓ View Correct Answer and Explanation on ';
		$text_part2 = 'TheQuizWire.com';

		if ($has_font) {
			$font_size_footer = 20; // Slightly smaller to fit long text

			// Calculate total width to center it
			$bbox1 = imagettfbbox($font_size_footer, 0, $font_path, $text_part1);
			$w1    = $bbox1[2] - $bbox1[0];

			$bbox2 = imagettfbbox($font_size_footer, 0, $font_path, $text_part2);
			$w2    = $bbox2[2] - $bbox2[0];

			$total_w  = $w1 + $w2;
			$start_x  = ($width - $total_w) / 2;
			$footer_y = $height - 25;

			// Draw Part 1 (White)
			imagettftext($im, $font_size_footer, 0, (int) $start_x, (int) $footer_y, $white, $font_path, $text_part1);

			// Draw Part 2 (Gold)
			imagettftext($im, $font_size_footer, 0, (int) ($start_x + $w1), (int) $footer_y, $gold, $font_path, $text_part2);
		} else {
			imagestring($im, 4, 300, $height - 50, $text_part1 . $text_part2, $white);
		}

		// 10. Save and Output
		// Save as WebP
		imagewebp($im, $file_path, 90);

		// Cleanup
		imagedestroy($im);

		// Update version meta to prevent regeneration
		update_post_meta($post_id, '_nm_social_image_version', $version);
		update_post_meta($post_id, '_nm_social_image_url', $file_url);

		// ✅ NEW: Attach to Media Library and set as Featured Image for Jetpack
		self::set_featured_image($post_id, $file_path, $file_url);

		return $file_url;
	}

	/**
	 * Generate an ARTICLE featured image (Design 2 — Frosted Band), matched to the MCQ
	 * featured image's colors/typography: blue #3498db → purple #667eea diagonal gradient,
	 * Roboto-Bold, gold #ffd700 CTA, logo + brand top-left, dynamic topic tag top-right.
	 *
	 * @since 9.3.5
	 * @param int $post_id Article post ID.
	 * @return string|false Image URL on success, false on failure.
	 */
	public static function generate_article_image($post_id)
	{
		$post_id = absint($post_id);
		if (! $post_id) {
			return false;
		}
		$post = get_post($post_id);
		if (! $post || $post->post_type !== 'post') {
			return false;
		}
		if (! function_exists('imagecreatetruecolor') || ! function_exists('imagewebp')) {
			return false;
		}

		$width  = 1200;
		$height = 630;
		$im     = imagecreatetruecolor($width, $height);

		// --- Colors (exact MCQ image spec) ---
		// Gradient: blue #3498db -> purple #667eea
		$blue_r = 52;  $blue_g = 152; $blue_b = 219;
		$pur_r  = 102; $pur_g  = 126; $pur_b  = 234;
		$white  = imagecolorallocate($im, 255, 255, 255);
		$gold   = imagecolorallocate($im, 255, 215, 0); // #ffd700

		// --- Diagonal gradient (top-left -> bottom-right), same as MCQ image ---
		for ($i = 0; $i < $height; $i++) {
			$p = $i / $height;
			$r = $blue_r + ($pur_r - $blue_r) * $p;
			$g = $blue_g + ($pur_g - $blue_g) * $p;
			$b = $blue_b + ($pur_b - $blue_b) * $p;
			$color = imagecolorallocate($im, (int)$r, (int)$g, (int)$b);
			imageline($im, 0, $i, $width, $i, $color);
		}

		// --- Font (Roboto-Bold, same as MCQ image) ---
		$font_path = NM_PLUGIN_PATH . 'assets/fonts/Roboto-Bold.ttf';
		if (! file_exists($font_path)) {
			$font_path = plugin_dir_path(dirname(__FILE__)) . 'assets/fonts/Roboto-Bold.ttf';
		}
		if (! file_exists($font_path)) {
			$font_path = ABSPATH . WPINC . '/fonts/roboto/Roboto-Bold.ttf';
		}
		$has_font = file_exists($font_path);

		// --- Logo + brand (top-left): WP custom logo image, else brand text ---
		$brand_name = get_bloginfo('name');
		$logo_drawn = false;
		$logo_id    = get_theme_mod('custom_logo');
		if ($logo_id) {
			$logo_path = get_attached_file($logo_id);
			if ($logo_path && file_exists($logo_path)) {
				$logo_info = @getimagesize($logo_path);
				if ($logo_info) {
					$src_w = $logo_info[0];
					$src_h = $logo_info[1];
					$target_h = 46;
					$scale    = $target_h / max(1, $src_h);
					$target_w = (int)round($src_w * $scale);
					if ($target_w > 120) {
						$scale    = 120 / $src_w;
						$target_w = 120;
						$target_h = (int)round($src_h * $scale);
					}
					$logo_im = null;
					if ($logo_info['mime'] === 'image/png')       $logo_im = @imagecreatefrompng($logo_path);
					elseif ($logo_info['mime'] === 'image/jpeg' || $logo_info['mime'] === 'image/jpg') $logo_im = @imagecreatefromjpeg($logo_path);
					if ($logo_im) {
						@imagecopyresampled($im, $logo_im, 30, 28, 0, 0, $target_w, $target_h, $src_w, $src_h);
						@imagedestroy($logo_im);
						$logo_drawn = true;
					}
				}
			}
		}
		if (! $logo_drawn && $has_font) {
			imagettftext($im, 22, 0, 30, 58, $white, $font_path, $brand_name);
		}

		// --- Topic tag (top-right), dynamic from post terms ---
		$topic_name = '';
		$terms      = wp_get_post_terms($post_id, 'topic', array('number' => 1));
		if ($terms && ! is_wp_error($terms) && ! empty($terms)) {
			$topic_name = $terms[0]->name;
		}
		if (empty($topic_name)) {
			$topic_name = 'Current Affairs';
		}
		if ($has_font) {
			$tag_text = strtoupper($topic_name);
			$t_bbox   = imagettfbbox(13, 0, $font_path, $tag_text);
			$t_w      = $t_bbox[2] - $t_bbox[0];
			$t_pad_x  = 16; $t_pad_y = 6;
			$tag_w    = $t_w + $t_pad_x * 2;
			$tag_h    = 30;
			$tag_x1   = $width - 30 - $tag_w;
			$tag_y1   = 30;
			$tag_bg   = imagecolorallocatealpha($im, 255, 255, 255, 70); // ~28% white (solid enough for dark text)
			imagefilledrectangle($im, $tag_x1, $tag_y1, $tag_x1 + $tag_w, $tag_y1 + $tag_h, $tag_bg);
			// @FIX 9.3.6: dark pill background -> use BLACK text for contrast/readability
			$tag_black = imagecolorallocate($im, 30, 30, 30);
			imagettftext($im, 13, 0, $tag_x1 + $t_pad_x, $tag_y1 + 21, $tag_black, $font_path, $tag_text);
		}

		// --- Frosted band (centered) + wrapped bold title ---
		$title    = wp_strip_all_tags(trim(get_the_title($post_id)));
		if ($title === '') {
			$title = $brand_name;
		}
		$band_top = (int)round($height * 0.20);
		$band_h   = (int)round($height * 0.44);
		$band_bg  = imagecolorallocatealpha($im, 10, 16, 35, 75); // ~41% dark
		imagefilledrectangle($im, 0, $band_top, $width, $band_top + $band_h, $band_bg);
		// band top/bottom hairlines
		$line = imagecolorallocatealpha($im, 255, 255, 255, 100);
		imageline($im, 0, $band_top, $width, $band_top, $line);
		imageline($im, 0, $band_top + $band_h, $width, $band_top + $band_h, $line);

		if ($has_font) {
			// word-wrap title to fit ~1040px
			$font_size  = 37;
			$max_width  = 1040;
			$line_h     = 47;
			$words      = explode(' ', $title);
			$lines      = array();
			$cur        = '';
			foreach ($words as $word) {
				$test = $cur === '' ? $word : $cur . ' ' . $word;
				$bb   = imagettfbbox($font_size, 0, $font_path, $test);
				if (($bb[2] - $bb[0]) > $max_width && $cur !== '') {
					$lines[] = $cur;
					$cur = $word;
				} else {
					$cur = $test;
				}
			}
			if ($cur !== '') { $lines[] = $cur; }

			// If too many lines, shrink font a touch (keeps readability)
			while (count($lines) > 4 && $font_size > 26) {
				$font_size -= 2;
				$line_h    -= 2;
				$lines = array();
				$cur = '';
				foreach ($words as $word) {
					$test = $cur === '' ? $word : $cur . ' ' . $word;
					$bb   = imagettfbbox($font_size, 0, $font_path, $test);
					if (($bb[2] - $bb[0]) > $max_width && $cur !== '') { $lines[] = $cur; $cur = $word; }
					else { $cur = $test; }
				}
				if ($cur !== '') { $lines[] = $cur; }
			}

			$block_h = count($lines) * $line_h;
			$start_y = $band_top + (int)(($band_h - $block_h) / 2) + $line_h;

			// shadow + main
			$shadow = imagecolorallocatealpha($im, 0, 0, 0, 110);
			foreach ($lines as $i => $line_text) {
				$bb = imagettfbbox($font_size, 0, $font_path, $line_text);
				$tw = $bb[2] - $bb[0];
				$x  = (int)(($width - $tw) / 2);
				$y  = $start_y + $i * $line_h;
				imagettftext($im, $font_size, 0, $x + 2, $y + 3, $shadow, $font_path, $line_text);
				imagettftext($im, $font_size, 0, $x, $y, $white, $font_path, $line_text);
			}
		}

		// --- CTA (bottom, gold) ---
		// @FIX 9.3.6: bigger font + raised higher for readability.
		if ($has_font) {
			$cta_text = 'Read the Full Brief →';
			$cta_font = 24;
			$cta_bbox = imagettfbbox($cta_font, 0, $font_path, $cta_text);
			$cta_w    = $cta_bbox[2] - $cta_bbox[0];
			$cta_x    = (int)(($width - $cta_w) / 2);
			$cta_y    = $height - 56; // raised from -34
			imagettftext($im, $cta_font, 0, $cta_x + 2, $cta_y + 3, imagecolorallocatealpha($im, 0, 0, 0, 110), $font_path, $cta_text);
			imagettftext($im, $cta_font, 0, $cta_x, $cta_y, $gold, $font_path, $cta_text);
		}

		// --- Save ---
		$upload = wp_upload_dir();
		$dir    = $upload['basedir'] . '/nm-social';
		if (! is_dir($dir)) {
			wp_mkdir_p($dir);
		}
		$file_name = 'article-' . $post_id . '-' . time() . '.webp';
		$file_path = $dir . '/' . $file_name;
		$file_url  = set_url_scheme($upload['baseurl'] . '/nm-social/' . $file_name, 'https');

		if (! imagewebp($im, $file_path, 90)) {
			imagedestroy($im);
			return false;
		}
		imagedestroy($im);

		// Store meta + set as featured image (Jetpack/Social).
		update_post_meta($post_id, '_nm_article_image_url', $file_url);
		self::set_featured_image($post_id, $file_path, $file_url);
		return $file_url;
	}

	/**
	 * Attach the generated image to the WP Media Library and set it as the Featured Image.
	 * Required by Jetpack Social for sharing to Instagram.
	 */
	private static function set_featured_image($post_id, $file_path, $file_url)
	{
		// Ensure the social image URL meta is always set/updated
		update_post_meta($post_id, '_nm_social_image_url', $file_url);

		// Check if it's already the featured image
	$thumbnail_id = get_post_thumbnail_id($post_id);
	if ($thumbnail_id) {
		$existing_url = wp_get_attachment_url($thumbnail_id);
		if (set_url_scheme($existing_url, 'https') === set_url_scheme($file_url, 'https')) {
			return; // Already attached and set
		}
		wp_delete_attachment($thumbnail_id, true);
	}

		$wp_filetype = wp_check_filetype(basename($file_path), null);

		$attachment = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title'     => 'Social Image for MCQ ' . $post_id,
			'post_content'   => '',
			'post_status'    => 'inherit'
		);

        remove_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99);

        $attach_id = wp_insert_attachment($attachment, $file_path, $post_id);

        if (!is_wp_error($attach_id)) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
            wp_update_attachment_metadata($attach_id, $attach_data);

            set_post_thumbnail($post_id, $attach_id);
        }

        add_action('save_post_mcq', array(self::class, 'schedule_on_save'), 99, 3);
	}
}