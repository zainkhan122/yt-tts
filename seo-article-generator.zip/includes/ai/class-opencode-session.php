<?php
/**
 * OpenCode Zen session-header support.
 *
 * OpenCode Go / Zen (https://opencode.ai/docs/go/#where-can-i-use-it) requires
 * clients to "send a stable session ID in `x-opencode-session` for each
 * conversation" so Zen can optimize routing and prompt caching. The plugin did
 * not send this header; this class derives the correct session id and decides
 * when a request targets Zen.
 *
 * Contract (per the OpenCode Go guidance):
 *  - Header is sent on OpenCode/Zen chat-completion requests ONLY: text
 *    generation, vision requests, connection tests, model-fallback hops, and
 *    response-format / web-search self-correction retries all reuse the same
 *    id for one logical conversation. The non-chat `/v1/models` sync must NOT
 *    send it.
 *  - Detection is by endpoint hostname (opencode.ai + subdomains) so OpenRouter,
 *    Gemini, Groq and other custom providers are left unchanged.
 *  - For a generation job the id is DETERMINISTIC (site + job_id) so it is
 *    stable across PHP workers, Action Scheduler retries, and model/provider
 *    fallback. For a request with no job context a fresh random UUID is minted
 *    once per logical request and reused across its internal retries.
 *  - No persisted/static configuration field is created; ids are derived.
 *
 * @package SEO_Article_Generator\AI
 * @since   2.34.4
 */

namespace SEO_Article_Generator\AI;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Opencode_Session {

	/**
	 * Fixed namespace UUID used for deterministic job sessions (v5).
	 * Generated once for this plugin (namespace for "seo-article-generator/opencode-session").
	 */
	const NAMESPACE_UUID = '6f2c1a9e-7b3d-4e8a-9c5f-2d6a8b1e4f70';

	/** Header name Zen reads the stable conversation id from. */
	const HEADER_NAME = 'x-opencode-session';

	/**
	 * True when the given API URL targets OpenCode Zen (opencode.ai host or a
	 * subdomain, e.g. zen.opencode.ai). Mirrors Provider_Registry::is_zen_url()
	 * but is self-contained so it works before the registry is booted.
	 *
	 * @param string $api_url
	 * @return bool
	 */
	public static function is_zen_endpoint( string $api_url ): bool {
		if ( '' === $api_url ) {
			return false;
		}
		$host = wp_parse_url( $api_url, PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			// Fall back to a substring check when the URL is host-less/malformed.
			return false !== stripos( $api_url, 'opencode.ai' );
		}
		$host = strtolower( $host );
		return 'opencode.ai' === $host
			|| substr( $host, -strlen( '.opencode.ai' ) ) === '.opencode.ai';
	}

	/**
	 * Resolve the stable session id for a given execution context.
	 *
	 * @param array $context Optional. Execution context:
	 *   - job_id int   When > 0 the id is deterministic (site + job_id).
	 *   - (future-safe: any other keys ignored).
	 * @return string A UUID string.
	 */
	public static function session_id( array $context = array() ): string {
		$job_id = (int) ( $context['job_id'] ?? 0 );
		if ( $job_id > 0 ) {
			return self::deterministic_id( $job_id );
		}
		return self::random_uuid();
	}

	/**
	 * Deterministic UUID v5 from the site identity + job_id. Stable across
	 * workers, retries and fallback because the inputs never change for a job.
	 *
	 * @param int $job_id
	 * @return string
	 */
	public static function deterministic_id( int $job_id ): string {
		$site = function_exists( 'get_site_url' ) ? (string) get_site_url() : 'seo-article-generator';
		$name = $site . '::seo-gen-job::' . $job_id;
		return self::uuid_v5( self::NAMESPACE_UUID, $name );
	}

	/**
	 * Add the Zen session header to a headers array when the request targets
	 * Zen and does not already carry the header. Returns the (possibly) mutated
	 * headers array; the chosen session id is also returned by reference.
	 *
	 * @param string $api_url
	 * @param array  $headers
	 * @param array  $context
	 * @param string $session_out Receives the session id used ('' when not Zen).
	 * @return array
	 */
	public static function apply_header( string $api_url, array $headers, array $context = array(), string &$session_out = '' ): array {
		$session_out = '';
		if ( ! self::is_zen_endpoint( $api_url ) ) {
			return $headers;
		}

		$session_out = self::session_id( $context );
		if ( '' === $session_out ) {
			return $headers;
		}

		// Preserve any existing header regardless of case.
		foreach ( array_keys( $headers ) as $key ) {
			if ( strtolower( (string) $key ) === strtolower( self::HEADER_NAME ) ) {
				return $headers;
			}
		}

		$headers[ self::HEADER_NAME ] = $session_out;
		return $headers;
	}

	/**
	 * RFC 4122 v4 random UUID.
	 *
	 * @return string
	 */
	public static function random_uuid(): string {
		$data = random_bytes( 16 );
		$data[6] = chr( ( ord( $data[6] ) & 0x0f ) | 0x40 );
		$data[8] = chr( ( ord( $data[8] ) & 0x3f ) | 0x80 );
		return self::format_uuid( $data );
	}

	/**
	 * RFC 4122 v5 (SHA-1 namespace + name) UUID.
	 *
	 * @param string $namespace Valid UUID string.
	 * @param string $name
	 * @return string
	 */
	public static function uuid_v5( string $namespace, string $name ): string {
		$nhex = str_replace( array( '-', '{' , '}' ), '', $namespace );
		$nstr = '';
		for ( $i = 0; $i < strlen( $nhex ); $i+=2 ) {
			$nstr .= chr( hexdec( substr( $nhex, $i, 2 ) ) );
		}
		$hash = sha1( $nstr . $name );
		// First 16 bytes of the 20-byte SHA-1 digest.
		$data = '';
		for ( $i = 0; $i < 16; $i++ ) {
			$data .= chr( hexdec( substr( $hash, $i * 2, 2 ) ) );
		}
		$data[6] = chr( ( ord( $data[6] ) & 0x0f ) | 0x50 ); // version 5.
		$data[8] = chr( ( ord( $data[8] ) & 0x3f ) | 0x80 ); // RFC variant.
		return self::format_uuid( $data );
	}

	/**
	 * Format 16 raw binary bytes as a canonical 8-4-4-4-12 UUID string.
	 *
	 * @param string $binary
	 * @return string
	 */
	private static function format_uuid( string $binary ): string {
		$hex = bin2hex( $binary );
		return sprintf(
			'%s-%s-%s-%s-%s',
			substr( $hex, 0, 8 ),
			substr( $hex, 8, 4 ),
			substr( $hex, 12, 4 ),
			substr( $hex, 16, 4 ),
			substr( $hex, 20, 12 )
		);
	}
}
