<?php

/**
 * AJAX Handler for Branding Settings
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Branding_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Save Branding Settings
     */
    public function ajax_save_branding()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            VS_Error_Logger::get_instance()->log('Branding Save: Access Denied', 'warning');
            wp_send_json_error('Access denied');
        }

        // @MODIFIED 2026-08-10: Merge into existing branding instead of replacing.
        //       Logo upload/position are managed exclusively in Settings → Assets tab.
        //       The Studio Editor sends only brand_name, quiz_name, cta_text, cta_style
        //       and must NOT overwrite logo_url or logo_pos.
        $branding = get_option('MCQVS_studio_branding', array());
        if (isset($_POST['logo_url']) || isset($_POST['logo_pos'])) {
            // Legacy path: Studio Editor sending logo fields (should not happen after 2026-08-10
            // patch, but kept for backward compatibility if older JS is cached).
            if (isset($_POST['logo_url'])) {
                $branding['logo_url'] = esc_url_raw(wp_unslash($_POST['logo_url']));
            }
            if (isset($_POST['logo_pos'])) {
                $branding['logo_pos'] = sanitize_text_field(wp_unslash($_POST['logo_pos']));
            }
        }
        if (isset($_POST['cta_text'])) {
            $branding['cta_text'] = sanitize_text_field(wp_unslash($_POST['cta_text']));
        }
        if (isset($_POST['cta_style'])) {
            $branding['cta_style'] = sanitize_text_field(wp_unslash($_POST['cta_style']));
        }
        if (isset($_POST['brand_name'])) {
            $branding['brand_name'] = sanitize_text_field(wp_unslash($_POST['brand_name']));
        }
        if (isset($_POST['quiz_name'])) {
            $branding['quiz_name'] = sanitize_text_field(wp_unslash($_POST['quiz_name']));
        }
        if (isset($_POST['bg_overlay'])) {
            $branding['bg_overlay'] = sanitize_text_field(wp_unslash($_POST['bg_overlay']));
        }
        if (isset($_POST['watermark'])) {
            $branding['watermark'] = sanitize_text_field(wp_unslash($_POST['watermark']));
        }
        if (isset($_POST['hookVisible'])) {
            $branding['hookVisible'] = sanitize_text_field(wp_unslash($_POST['hookVisible'])) !== '0';
        }

        update_option('MCQVS_studio_branding', $branding);
        wp_send_json_success(array('message' => 'Branding saved'));
    }

    /**
     * AJAX: Get Branding Settings
     */
    public function ajax_get_branding()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $branding = get_option('MCQVS_studio_branding', array());
        wp_send_json_success($branding);
    }

    /**
     * AJAX: Upload Branding Logo
     *
     * Copies the selected Media Library image into the plugin assets folder
     * (assets/images/brand-logo.<ext>) so headless rendering reads it from local
     * disk instead of downloading it for every render. Persists the plugin-assets
     * URL into MCQVS_studio_branding.logo_url (single source of truth).
     */
    public function ajax_upload_branding_logo()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $attachment_id = absint(wp_unslash($_POST['attachment_id'] ?? 0));
        if (! $attachment_id) {
            wp_send_json_error('No attachment ID provided');
        }

        $src_path = get_attached_file($attachment_id);
        if (! $src_path || ! file_exists($src_path)) {
            wp_send_json_error('Attachment file not found on server');
        }

        $mime = wp_check_filetype($src_path);
        $allowed = array(
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'webp' => 'image/webp',
            'gif'  => 'image/gif',
        );
        if (empty($mime['ext']) || ! isset($allowed[$mime['ext']])) {
            wp_send_json_error('Logo must be a PNG, JPG, JPEG, WebP or GIF image');
        }

        $logo_dir = MCQVS_PLUGIN_DIR . 'assets/images/';
        if (! is_dir($logo_dir)) {
            wp_mkdir_p($logo_dir);
        }

        $copied = false;
        if (is_dir($logo_dir) && is_writable($logo_dir)) {
            $target_ext = ($mime['ext'] === 'jpeg') ? 'jpg' : $mime['ext'];
            $target = $logo_dir . 'brand-logo.' . $target_ext;

            // Remove any older extension variants (brand-logo.png vs .jpg vs .webp ...)
            // so the copied file is always the one referenced by the stored URL.
            foreach ($allowed as $ext => $_unused) {
                $ext_norm = ($ext === 'jpeg') ? 'jpg' : $ext;
                $old = $logo_dir . 'brand-logo.' . $ext_norm;
                if ($old !== $target && file_exists($old)) {
                    @unlink($old);
                }
            }

            if (@copy($src_path, $target)) {
                $copied = true;
            }
        }

        $branding = get_option('MCQVS_studio_branding', array());

        if ($copied) {
            $logo_url = MCQVS_PLUGIN_URL . 'assets/images/brand-logo.' . $target_ext;
            $message = 'Logo copied into the plugin assets folder (local read on every render)';
        } else {
            // Fallback: plugin assets folder not writable — store the Media Library URL
            // so renders still show the logo (downloaded from URL per render).
            $logo_url = esc_url_raw(wp_get_attachment_url($attachment_id));
            if (empty($logo_url)) {
                $logo_url = esc_url_raw($branding['logo_url'] ?? '');
            }
            $message = 'Plugin assets folder not writable — storing the Media Library URL instead (logo is downloaded from URL on each render)';
        }

        $branding['logo_url'] = $logo_url;
        if (empty($branding['logo_pos'])) {
            $branding['logo_pos'] = 'all';
        }
        update_option('MCQVS_studio_branding', $branding);

        wp_send_json_success(array(
            'logo_url'  => $logo_url,
            'logo_path' => $copied ? $target : '',
            'mode'      => $copied ? 'local' : 'remote',
            'message'   => $message,
        ));
    }

    /**
     * AJAX: Remove Branding Logo
     *
     * Clears MCQVS_studio_branding.logo_url and deletes the local copy in the
     * plugin assets folder.
     */
    public function ajax_remove_branding_logo()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $branding = get_option('MCQVS_studio_branding', array());
        $branding['logo_url'] = '';
        update_option('MCQVS_studio_branding', $branding);

        $logo_dir = MCQVS_PLUGIN_DIR . 'assets/images/';
        foreach (array('png', 'jpg', 'webp', 'gif') as $ext) {
            $f = $logo_dir . 'brand-logo.' . $ext;
            if (file_exists($f)) {
                @unlink($f);
            }
        }

        wp_send_json_success(array('message' => 'Logo removed'));
    }

    /**
     * AJAX: Save Branding Logo Position
     */
    public function ajax_save_branding_position()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $allowed = array('corner', 'outro', 'all');
        $pos = sanitize_text_field(wp_unslash($_POST['logo_pos'] ?? 'all'));
        if (! in_array($pos, $allowed, true)) {
            $pos = 'all';
        }

        $branding = get_option('MCQVS_studio_branding', array());
        $branding['logo_pos'] = $pos;
        update_option('MCQVS_studio_branding', $branding);

        wp_send_json_success(array('logo_pos' => $pos));
    }
}
