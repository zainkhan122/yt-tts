<?php

/**
 * Scoring Engine
 *
 * Orchestrates quality validation and point distribution.
 *
 * @package DIT_TrendStudio\Security
 * @since   1.3.0
 */

namespace DIT\TrendStudio\Security;

use DIT\TrendStudio\Schema\Content_Schema;
use DIT\TrendStudio\Content\QualityGate;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Weighted scoring system for magazine articles.
 */
class Scoring_Engine
{
    private QualityGate $truth_enforcer;
    private Style_Auditor $style_auditor;
    private Safety_Auditor $safety_auditor;

    public function __construct()
    {
        $this->truth_enforcer = new QualityGate();
        $this->style_auditor = new Style_Auditor();
        $this->safety_auditor = new Safety_Auditor();
    }

    /**
     * Calculate consolidated score.
     *
     * @param Content_Schema $schema
     * @param string         $mode
     * @return array
     */
    public function calculate(Content_Schema $schema, string $mode = 'editorial'): array
    {
        $config = Threshold_Config::get($mode);
        $breakdown = [];
        $total_score = 100;

        // 1. Sourcing & Grounding (40 pts)
        $truth_res = $this->truth_enforcer->audit($schema, $config['sourcing']);
        $sourcing_lost = min($config['sourcing']['pts_full'], $truth_res['pts_lost']);
        $breakdown['sourcing'] = [
            'raw'      => $config['sourcing']['pts_full'] - $sourcing_lost,
            'max'      => $config['sourcing']['pts_full'],
            'issues'   => $truth_res['issues'],
        ];

        // 2. Readability & Structure (25 pts)
        $style_res = $this->style_auditor->audit($schema, $config['readability']);
        $style_lost = min($config['readability']['pts_full'], $style_res['pts_lost']);
        $breakdown['readability'] = [
            'raw'      => $config['readability']['pts_full'] - $style_lost,
            'max'      => $config['readability']['pts_full'],
            'issues'   => $style_res['issues'],
        ];

        // 3. SEO Basics (20 pts)
        $seo_res = $this->audit_seo($schema, $config['seo']);
        $seo_lost = min($config['seo']['pts_full'], $seo_res['pts_lost']);
        $breakdown['seo'] = [
            'raw'      => $config['seo']['pts_full'] - $seo_lost,
            'max'      => $config['seo']['pts_full'],
            'issues'   => $seo_res['issues'],
        ];

        // 4. Media Readiness (15 pts)
        $media_res = $this->audit_media($schema, $config['media']);
        $media_lost = min($config['media']['pts_full'], $media_res['pts_lost']);
        $breakdown['media'] = [
            'raw'      => $config['media']['pts_full'] - $media_lost,
            'max'      => $config['media']['pts_full'],
            'issues'   => $media_res['issues'],
        ];

        // 5. Safety & Compliance (Penalty Category)
        // Note: Penalties here can exceed 0 and affect final total
        $safety_res = $this->safety_auditor->audit($schema);
        if (!empty($safety_res['issues'])) {
            $breakdown['safety'] = [
                'raw'    => -$safety_res['pts_lost'],
                'max'    => 0, // Deductive only
                'issues' => $safety_res['issues'],
            ];
        }

        $calc_total = $breakdown['sourcing']['raw'] + $breakdown['readability']['raw'] + $breakdown['seo']['raw'] + $breakdown['media']['raw'];
        $final_score = $calc_total + ($breakdown['safety']['raw'] ?? 0);

        return [
            'score'     => max(0, $final_score),
            'threshold' => $config['threshold'],
            'passed'    => ($final_score >= $config['threshold']),
            'breakdown' => $breakdown,
        ];
    }

    /**
     * Audit SEO basics.
     */
    private function audit_seo(Content_Schema $schema, array $cfg): array
    {
        $issues = [];
        $pts_lost = 0;

        $title_len = strlen($schema->headline);
        if ($title_len < $cfg['min_title'] || $title_len > $cfg['max_title']) {
            $issues[] = sprintf('Headline length (%d) is suboptimal (target: %d-%d).', $title_len, $cfg['min_title'], $cfg['max_title']);
            $pts_lost += 5;
        }

        $meta_len = strlen($schema->meta_description);
        if ($meta_len < $cfg['min_meta'] || $meta_len > $cfg['max_meta']) {
            $issues[] = sprintf('Meta description length (%d) is suboptimal (target: %d-%d).', $meta_len, $cfg['min_meta'], $cfg['max_meta']);
            $pts_lost += 5;
        }

        return ['issues' => $issues, 'pts_lost' => $pts_lost];
    }

    /**
     * Audit Media readiness.
     */
    private function audit_media(Content_Schema $schema, array $cfg): array
    {
        $issues = [];
        $pts_lost = 0;

        if (empty($schema->hero_image_alt)) {
            $issues[] = 'Missing hero image alt text guidance.';
            $pts_lost += 5;
        }

        $credit = $schema->image_attribution['credit'] ?? '';
        if (empty($credit) && $cfg['require_credit']) {
            $issues[] = 'Hero image lacks specific photographer/agency credit.';
            $pts_lost += 10;
        }

        return ['issues' => $issues, 'pts_lost' => $pts_lost];
    }
}
