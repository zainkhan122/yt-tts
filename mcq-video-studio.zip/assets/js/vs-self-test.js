/**
 * MCQ Video Studio - Admin Self-Test
 * Runs a deterministic client-side validation suite:
 * - template schema validator
 * - render plan builder + validator
 * - preflight asset checks
 * - worker init + single-frame render (parity gate)
 */
(function ($, window) {
  "use strict";

  const $byId = (id) => $(document.getElementById(id));

  console.log('[NM SelfTest] Script loaded. Waiting for DOM...');

  const nowStamp = () => {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  };

  function setRow(rowKey, status, detail) {
    const $row = $byId(`mcqvsSelfTestRow_${rowKey}`);
    if (!$row.length) return;
    $row.find(".mcqvs-st-status").text(status);
    $row.find(".mcqvs-st-detail").text(detail || "");
    $row.attr("data-status", status);
  }

  function appendLog(line) {
    const $out = $byId("mcqvsSelfTestLog");
    if (!$out.length) return;
    const prev = $out.val() || "";
    $out.val(prev + (prev ? "\n" : "") + line);
    $out.scrollTop($out[0].scrollHeight);
  }

  function requireGlobal(name) {
    if (!window[name]) throw new Error(`${name} missing (script not loaded)`);
    return window[name];
  }

  function buildSamplePlaylist(timing) {
    const t = timing || {
      questionTotal: 7700,
      questionPhases: { reading: 5100, reveal: 2000, buffer: 600 },
    };
    return [
      { id: "intro", type: "intro", duration: 2000, content: { hookText: "Self-Test" } },
      {
        id: "q1",
        type: "question",
        duration: t.questionTotal,
        timing: { ...t },
        content: {
          question: "Self-test question: 2 + 2 = ?",
          options: ["3", "4", "5", "6"],
          answer: "4",
          correctIndex: 1,
        },
      },
      { id: "outro", type: "outro", duration: 5000, content: { ctaText: "Subscribe" } },
    ];
  }

  async function runSelfTest() {
    const cfg = window.mcqvsSelfTestConfig || {};
    const assetsUrl = String(cfg.assetsUrl || "");
    if (!assetsUrl) throw new Error("mcqvsSelfTestConfig.assetsUrl missing");

    const templateId = String($byId("mcqvsSelfTestTemplate").val() || "corporate");
    appendLog(`== MCQVS Self-Test (${templateId}) ==`);

    // 0. Modular Environment Validation
    try {
      appendLog("[env] Checking modular classes...");
      requireGlobal("MCQVS_TimelineEngine");
      requireGlobal("MCQVS_PlanBuilder");
      requireGlobal("MCQVS_AudioRouter");
      requireGlobal("MCQVS_PreviewManager"); // Updated from PreviewPlayer
      appendLog("[env] PASS: Modular classes loaded");
    } catch (e) {
      setRow("schema", "FAIL", "Missing modular classes"); // Fail early
      appendLog("[env] FAIL: " + e.message);
      throw e;
    }

    // Resolve template
    const Templates = requireGlobal("MCQVS_VideoTemplates");
    const tCfg = Templates.get ? Templates.get(templateId) : null;
    if (!tCfg) throw new Error(`Template not found: ${templateId}`);

    // 1. Template schema validation
    try {
      const Schema = requireGlobal("MCQVS_SchemaValidate");
      const schema = tCfg.schema || null;
      const res = Schema.validate(schema, tCfg, "template");
      if (!res.ok) {
        setRow("schema", "FAIL", `${res.issues.length} issue(s)`);
        appendLog("[schema] FAIL: " + JSON.stringify(res.issues, null, 2));
        throw new Error("Template schema invalid");
      }
      setRow("schema", "PASS", "ok");
      appendLog("[schema] PASS");
    } catch (e) {
      setRow("schema", "FAIL", e.message);
      throw e;
    }

    // 2. RenderPlan build + validate (also consumes template cue pack)
    let plan = null;
    try {
      const RenderPlan = requireGlobal("MCQVS_RenderPlan");
      const MCQVS_RenderPlanValidator = window.MCQVS_RenderPlanValidator;

      const playlist = buildSamplePlaylist();
      plan = RenderPlan.buildFromPlaylist(playlist, {
        fps: 30,
        width: 1080,
        height: 1920,
        templateId,
      });

      // Merge template-declared assets + cue points into plan
      if (typeof tCfg.getDeclaredAssets === "function") {
        const a = tCfg.getDeclaredAssets() || {};
        plan.assets = plan.assets || { images: [], audio: [], fonts: [] };
        plan.assets.fonts = Array.from(new Set([...(plan.assets.fonts || []), ...((a.fonts || []).map(String))]));
        plan.assets.images = Array.from(new Set([...(plan.assets.images || []), ...((a.images || []).map(String))]));
        plan.assets.audio = Array.from(new Set([...(plan.assets.audio || []), ...((a.audio || []).map(String))]));
      }
      if (typeof tCfg.getCuePoints === "function") {
        const cuePack = tCfg.getCuePoints(plan) || {};
        plan.fxEvents = cuePack.fxEvents || [];
        plan.sfxEvents = cuePack.sfxEvents || [];
        plan.duckWindows = cuePack.duckWindows || [];
        plan.requiredSfx = cuePack.requiredSfx || [];
      }

      const vres = MCQVS_RenderPlanValidator.validate(plan);
      if (!vres.ok) {
        setRow("renderplan", "FAIL", `${vres.issues.length} issue(s)`);
        appendLog("[renderPlan] FAIL: " + JSON.stringify(vres.issues, null, 2));
        throw new Error("RenderPlan invalid");
      }

      setRow("renderplan", "PASS", `${plan.scenes.length} scenes, ${Math.round(plan.totalMs)}ms`);
      appendLog("[renderPlan] PASS");
    } catch (e) {
      setRow("renderplan", "FAIL", e.message);
      throw e;
    }

    // 3. Preflight
    try {
      const AssetCache = requireGlobal("MCQVS_AssetCache");
      const Preflight = requireGlobal("MCQVS_Preflight");

      const cache = AssetCache.create({ persist: true, versionKey: "v9" });
      let audioCtx = null;
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (_) {
        audioCtx = null;
      }
      const pf = await Preflight.run(plan, { assetCache: cache, audioContext: audioCtx, timeoutMs: 12000 });
      if (audioCtx && audioCtx.state !== "closed") {
        try { await audioCtx.close(); } catch (_) { }
      }

      if (!pf.ok) {
        setRow("preflight", "WARN", `${pf.issues.length} issue(s)`);
        appendLog("[preflight] WARN: " + JSON.stringify(pf.issues, null, 2));
      } else {
        setRow("preflight", "PASS", "ok");
        appendLog("[preflight] PASS");
      }
    } catch (e) {
      setRow("preflight", "FAIL", e.message);
      throw e;
    }

    // 3b. @NEW 2026-06-29: Diagnostics buffer regression guard.
    // Asserts that MCQVSLogger.export() returns a populated buffer in production.
    // Previously, the structured logger was disabled outside dev hosts, so
    // Diagnostics card "Copy Logs" silently copied []. Trigger one INFO event
    // and verify the buffer grew — this fails fast if F2 ever regresses.
    try {
      const LG = requireGlobal("MCQVSLogger");
      if (!LG || typeof LG.info !== "function" || typeof LG.export !== "function") {
        setRow("logger", "FAIL", "MCQVSLogger missing or export() unavailable");
        appendLog("[logger] FAIL: MCQVSLogger.export missing");
        throw new Error("Diagnostics logger missing");
      }
      const before = (LG.export() && LG.export().logs) ? LG.export().logs.length : 0;
      try { LG.info("SELF_TEST_PROBE", { ranAt: new Date().toISOString() }); } catch (_) { }
      const after = (LG.export() && LG.export().logs) ? LG.export().logs.length : 0;
      if (after > before) {
        setRow("logger", "PASS", `${before}→${after} entries`);
        appendLog(`[logger] PASS ring buffer ${before}→${after}`);
      } else {
        setRow("logger", "FAIL", `ring buffer not advancing (${before}=${after})`);
        appendLog(`[logger] FAIL buffer stuck at ${after}`);
        throw new Error("Diagnostics ring buffer not populated");
      }
    } catch (e) {
      setRow("logger", "FAIL", e.message);
      throw e;
    }

    // 4. Worker init + 1-frame render + parity checksum (main-thread vs worker)
    try {
      if (!window.OffscreenCanvas) {
        setRow("worker", "SKIP", "OffscreenCanvas not supported in this browser");
        appendLog("[worker] SKIP (OffscreenCanvas unsupported)");
        return;
      }
      const workerPluginUrl = String(cfg.pluginUrl || "").replace(/\/+$/, '') + "/assets/";
      const workerUrl = workerPluginUrl + "js/vs-render-worker.js?ver=" + Date.now();
      const w = new Worker(workerUrl);

      const canvas = new OffscreenCanvas(1080, 1920);

      const initOk = await new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("Worker INIT timeout")), 12000);
        w.onmessage = (ev) => {
          const msg = ev.data || {};
          if (msg.type === "INIT_COMPLETE") {
            clearTimeout(t);
            resolve(true);
          }
        };
        w.onerror = (err) => {
          clearTimeout(t);
          reject(err);
        };
        w.postMessage({
          type: "INIT",
          data: {
            config: {
              assetsUrl: assetsUrl,
              logoPosition: "top-left",
              fps: 30,
              width: 1080,
              height: 1920,
            },
            assets: {},
            canvas: canvas,
            fonts: [],
          },
        }, [canvas]);
      });
      if (!initOk) throw new Error("Worker init failed");

      const workerFrame = await new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("Worker self-test timeout")), 12000);
        const handler = (ev) => {
          const msg = ev.data || {};
          if (msg.type === "SELF_TEST_OK") {
            clearTimeout(t);
            w.removeEventListener("message", handler);
            resolve(msg.data || {});
          }
          if (msg.type === "SELF_TEST_FAIL") {
            clearTimeout(t);
            w.removeEventListener("message", handler);
            reject(new Error(msg.error || "SELF_TEST_FAIL"));
          }
        };
        w.addEventListener("message", handler);

        w.postMessage({
          type: "SELF_TEST_FRAME",
          data: {
            templateId,
            renderPlan: plan,
            scene: plan.scenes && plan.scenes[0] ? plan.scenes[0] : null,
          },
        });
      });

      try { w.terminate(); } catch (_) { }

      // Main-thread render of the same scene and checksum comparison
      let mainChecksum = 0;
      try {
        const tm = requireGlobal("MCQVS_TemplateManager");
        const template = tm.getTemplate(templateId);

        const c = document.createElement("canvas");
        c.width = 1080;
        c.height = 1920;

        const cctx = c.getContext("2d", { alpha: false, willReadFrequently: true });
        if (!cctx) throw new Error("2D context unavailable");

        cctx.imageSmoothingEnabled = true;
        cctx.imageSmoothingQuality = 'high';
        cctx.clearRect(0, 0, c.width, c.height);

        // @MODIFIED 2026-01-30: Fix config and variable names
        const UR = requireGlobal("MCQVS_UnifiedRenderer");
        const ur = new UR();

        const scene0 = plan.scenes[0];
        const scene0c = (scene0 && scene0.content) ? scene0.content : {};

        ur.render(cctx, {
          activeScene: scene0,
          ...scene0c,

          currentSceneId: String(scene0.id || "scene0"),
          currentTemplate: templateId,

          elapsed: 0,
          prevElapsed: 0,
          elapsedInScene: 0,
          animationPhase: "intro",

          fxEvents: Array.isArray(plan.fxEvents) ? plan.fxEvents : [],
          timing: (scene0 && scene0.timing) ? scene0.timing : null,

          showSafeZone: false,
          config: { assetsUrl: assetsUrl, fps: 30, width: 1080, height: 1920 }
        }, {});

        // Checksum logic
        const w = Math.min(128, c.width);
        const h = Math.min(64, c.height);
        const img = cctx.getImageData(0, 0, w, h);
        const d = img.data;
        for (let i = 0; i < d.length; i += 17) {
          mainChecksum = (mainChecksum + d[i]) % 1000000007;
        }
      } catch (e) {
        mainChecksum = -1;
      }

      const wc = Number(workerFrame.checksum || 0);
      if (mainChecksum >= 0) {
        const delta = Math.abs(wc - mainChecksum);
        const tolerance = 500; // OffscreenCanvas vs DOM canvas can differ slightly due to text AA/subpixel rasterization

        if (delta > tolerance) {
          setRow("worker", "FAIL", `checksum mismatch Δ=${delta} worker=${wc} main=${mainChecksum}`);
          appendLog(`[worker] FAIL parity: Δ=${delta} worker=${wc} main=${mainChecksum}`);
          throw new Error("Parity mismatch (worker vs main thread)");
        }

        // PASS with tolerance
        setRow("worker", "PASS", `Δ=${delta} checksum worker=${wc} main=${mainChecksum}`);
        appendLog(`[worker] PASS parity (tolerance): Δ=${delta}`);
      } else {
        setRow("worker", "PASS", `checksum=${wc}`);
        appendLog("[worker] PASS (worker checksum only)");
      }

      // 5. Full mini pipeline: START_BATCH encode (proves WebCodecs+mp4-muxer pipeline)
      try {
        const w2 = new Worker(workerUrl);
        const canvas2 = new OffscreenCanvas(1080, 1920);

        // INIT
        await new Promise((resolve, reject) => {
          const t = setTimeout(() => reject(new Error("Worker INIT timeout (pipeline)")), 12000);
          const onMsg = (ev) => {
            const msg = ev.data || {};
            if (msg.type === "INIT_COMPLETE") {
              clearTimeout(t);
              w2.removeEventListener("message", onMsg);
              resolve(true);
            }
          };
          w2.addEventListener("message", onMsg);
          w2.onerror = (err) => {
            clearTimeout(t);
            try { w2.removeEventListener("message", onMsg); } catch (_) { }
            reject(err);
          };
          w2.postMessage({
            type: "INIT",
            data: { config: { assetsUrl, logoPosition: "top-left", fps: 30, width: 1080, height: 1920 }, assets: {}, canvas: canvas2, fonts: [] },
          }, [canvas2]);
        });

        const res = await new Promise((resolve, reject) => {
          const t = setTimeout(() => reject(new Error("Mini export timeout")), 30000);
          const onMsg = (ev) => {
            const msg = ev.data || {};
            if (msg.type === "JOB_COMPLETE" && msg.data && msg.data.video) {
              clearTimeout(t);
              w2.removeEventListener("message", onMsg);
              resolve({ bytes: msg.data.video.byteLength || 0 });
            }
            if (msg.type === "ERROR") {
              clearTimeout(t);
              w2.removeEventListener("message", onMsg);
              reject(new Error(msg.error || "Worker ERROR"));
            }
            // @NEW 2026-01-30: Capture interim worker logs
            if (msg.type === "LOG" && msg.msg) {
              appendLog(`[worker-debug] ${msg.msg}`);
            }
            if (msg.type === "STATUS" && msg.message) {
              appendLog(`[worker-status] ${msg.message}`);
            }
          };
          w2.addEventListener("message", onMsg);

          // Shrink plan for speed: just first scene, 1s duration
          const tinyPlan = JSON.parse(JSON.stringify(plan));
          if (tinyPlan && Array.isArray(tinyPlan.scenes) && tinyPlan.scenes.length) {
            tinyPlan.scenes = [tinyPlan.scenes[0]];
            tinyPlan.scenes[0].durMs = 1000;
            tinyPlan.scenes[0].endMs = (tinyPlan.scenes[0].startMs || 0) + 1000;
            tinyPlan.totalMs = 1000;
          }

          w2.postMessage({
            type: "START_BATCH",
            data: {
              jobs: [{ id: "selftest" }],
              debugMode: true,
              audioData: null,
              renderPlan: tinyPlan,
            },
          });
        });

        try { w2.terminate(); } catch (_) { }

        if (res.bytes < 5000) {
          setRow("pipeline", "FAIL", `encoded bytes too small (${res.bytes})`);
          appendLog(`[pipeline] FAIL: bytes=${res.bytes}`);
          throw new Error("Mini export produced an unexpectedly small file");
        }

        setRow("pipeline", "PASS", `encoded bytes=${res.bytes}`);
        appendLog(`[pipeline] PASS: encoded bytes=${res.bytes}`);
      } catch (e2) {
        setRow("pipeline", "FAIL", e2.message);
        appendLog("[pipeline] FAIL: " + (e2 && e2.stack ? e2.stack : e2.message));
        throw e2;
      }
    } catch (e) {
      setRow("worker", "FAIL", e.message);
      appendLog("[worker] FAIL: " + (e && e.stack ? e.stack : e.message));
      throw e;
    }
  }

  function buildReportPayload(overallOverride) {
    const cfg = window.mcqvsSelfTestConfig || {};
    const table = {
      schema: $byId("mcqvsSelfTestRow_schema").attr("data-status") || "",
      renderplan: $byId("mcqvsSelfTestRow_renderplan").attr("data-status") || "",
      preflight: $byId("mcqvsSelfTestRow_preflight").attr("data-status") || "",
      logger: $byId("mcqvsSelfTestRow_logger").attr("data-status") || "",
      worker: $byId("mcqvsSelfTestRow_worker").attr("data-status") || "",
      pipeline: $byId("mcqvsSelfTestRow_pipeline").attr("data-status") || "",
    };

    const isPass =
      table.schema === "PASS" &&
      table.renderplan === "PASS" &&
      table.logger === "PASS" &&
      table.worker === "PASS" &&
      table.pipeline === "PASS";

    const overall = (typeof overallOverride === "string")
      ? overallOverride
      : (isPass ? "pass" : "fail");

    return {
      overall,
      generatedAt: new Date().toISOString(),
      templateId: String($byId("mcqvsSelfTestTemplate").val() || ""),
      ajax: { ajaxurl: String(cfg.ajaxurl || ""), nonce: String(cfg.nonce || "") },
      table,
      log: $byId("mcqvsSelfTestLog").val() || "",
    };
  }

  async function persistReportToServer(payload) {
    const cfg = window.mcqvsSelfTestConfig || {};
    const ajaxurl = String(cfg.ajaxurl || "");
    const nonce = String(cfg.nonce || "");
    if (!ajaxurl || !nonce) return;
    try {
      await $.post(ajaxurl, {
        action: "mcqvs_save_selftest_report",
        nonce,
        report: JSON.stringify(payload),
      });
    } catch (e) {
      // Non-fatal: persistence is best-effort
    }
  }

  $(function () {
    console.log('[NM SelfTest] DOM Ready.');
    const $btn = $byId("mcqvsSelfTestRunBtn");
    console.log('[NM SelfTest] Button found:', $btn.length);

    if (!$btn.length) {
      console.error('[NM SelfTest] Button NOT found!');
      return;
    }

    $btn.on("click", async function (e) {
      // @MODIFIED 2026-02-03: Prevent default button behavior and bubbling (future-proofing)
      if (e && typeof e.preventDefault === "function") e.preventDefault();
      if (e && typeof e.stopPropagation === "function") e.stopPropagation();

      console.log('[NM SelfTest] Button clicked!');
      $btn.prop("disabled", true);
      $byId("mcqvsSelfTestLog").val("");
      ["schema", "renderplan", "preflight", "worker", "pipeline"].forEach((k) => setRow(k, "PENDING", ""));
      try {
        await runSelfTest();
        appendLog("== DONE ==");

        const report = buildReportPayload();
        await persistReportToServer(report);
      } catch (e) {
        appendLog("== FAILED == " + (e && e.message ? e.message : String(e)));

        const report = buildReportPayload("fail");
        await persistReportToServer(report);
      } finally {
        $btn.prop("disabled", false);
      }
    });

    $byId("mcqvsSelfTestDownloadBtn").on("click", function () {
      const payload = buildReportPayload();
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `mcqvs-self-test-${nowStamp()}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    });
  });
})(jQuery, window);
