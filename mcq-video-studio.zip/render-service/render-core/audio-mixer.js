/**
 * MCQ Video Studio — Server Audio Mixer (FFmpeg)
 *
 * Faithfully reproduces the browser Web Audio mix (studio.export.js prepareAudio)
 * on the server:
 *   - Background music: looped to full duration, ducked during voiceover windows.
 *   - Voiceover (TTS): each segment overlaid at its scheduled start time.
 *   - SFX: each cue overlaid at its time-locked position.
 *
 * Output: a single 44100 Hz stereo WAV that the MP4 mux step combines with the
 * canvas-drawn video. Using FFmpeg (not a re-implemented decoder) is the robust,
 * professional, CapCut-style approach.
 *
 * @package MCQ_Video_Studio
 * @subpackage render-service/render-core
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

/**
 * @param {object} spec
 *   ffmpegBin: string
 *   sampleRate: number (44100)
 *   durationSec: number
 *   music: { path, volume } | null
 *   voiceovers: Array<{ path, atSec }>
 *   sfx: Array<{ path, atSec, gain }>
 *   duckWindows: Array<{ startSec, endSec, volume }>
 *   outPath: string  (WAV)
 * @returns {boolean} true on success
 */
function mixAudio(spec) {
    const ffmpeg = spec.ffmpegBin;
    const sr = spec.sampleRate || 44100;
    const dur = Math.max(0.1, Number(spec.durationSec) || 1);

    // Build input list. Index 0 = music (optional, else silence).
    const inputs = [];
    const labels = [];
    let musicLabel = null;

    if (spec.music && spec.music.path && fs.existsSync(spec.music.path)) {
        inputs.push('-i', spec.music.path);
        musicLabel = '[' + labels.length + ':a]';
        labels.push('music');
    } else {
        // Generate silence as music placeholder so graph indices stay stable.
        inputs.push('-f', 'lavfi', '-i', `anullsrc=r=${sr}:cl=stereo:d=${dur.toFixed(3)}`);
        musicLabel = '[' + labels.length + ':a]';
        labels.push('silence');
    }

    const voiceLabels = [];
    for (const v of (spec.voiceovers || [])) {
        if (v.path && fs.existsSync(v.path)) {
            inputs.push('-i', v.path);
            voiceLabels.push({
                label: '[' + labels.length + ':a]',
                atSec: Number(v.atSec) || 0,
                // @FIX 1.4.9.52 (TTS OVERLAP): durSec + trimSec let the mixer
                // guarantee ONE voice at a time. durSec = full WAV length;
                // trimSec = how much may actually play (capped at the reveal
                // moment / scene end) so a too-long read can never run over
                // the answer or the next question.
                durSec: Number(v.durSec) || 0,
                trimSec: v.trimSec != null ? Number(v.trimSec) : null,
            });
            labels.push('voice');
        }
    }
    const sfxLabels = [];
    for (const s of (spec.sfx || [])) {
        if (s.path && fs.existsSync(s.path)) {
            inputs.push('-i', s.path);
            sfxLabels.push({ label: '[' + labels.length + ':a]', atSec: Number(s.atSec) || 0, gain: Number(s.gain) || 1 });
            labels.push('sfx');
        }
    }

    // ---- Filter graph ----
    const parts = [];

    // 1) Music: loop to duration + ducking envelope.
    const musicBase = spec.music && spec.music.volume != null ? Number(spec.music.volume) : 0.30;
    const duckDips = (spec.duckWindows || [])
        .map(w => `between(t\\,${Number(w.startSec).toFixed(3)}\\,${Number(w.endSec).toFixed(3)})`)
        .join('+');
    let musicVolExpr;
    if (duckDips) {
        const duckFloor = 0.14;
        musicVolExpr = `max(${duckFloor}\\,${musicBase} - ${(musicBase - duckFloor).toFixed(2)}*(${duckDips}))`;
    } else {
        musicVolExpr = String(musicBase);
    }
    parts.push(`${musicLabel}aloop=loop=-1:size=2e9,atrim=0:${dur.toFixed(3)},volume=${musicVolExpr}[musicv]`);

    // 2) Voice layers (delayed to start time, full gain).
    // @FIX 1.4.9.52 (TTS OVERLAP — final safety net): sort by start time and never
    //       let a later segment start while an earlier one is still playing. When
    //       timing is correct this is a no-op (segments are already sequential);
    //       when a segment is ever placed too early (e.g. a long read whose reveal
    //       anchor was mis-measured), the later segment is pushed just past the
    //       previous one's end so two voices NEVER overlap in the mix. Mirrors the
    //       browser export's cursorEndSec guarantee.
    voiceLabels.sort((a, b) => a.atSec - b.atSec);
    const voiceDelayed = [];
    let cursorEndSec = 0;
    voiceLabels.forEach((vl, i) => {
        const startSec = Math.max(vl.atSec, cursorEndSec + 0.02);
        const durSec = vl.durSec > 0 ? vl.durSec : 8;
        cursorEndSec = Math.max(cursorEndSec, startSec + durSec);
        const delayMs = Math.max(0, Math.round(startSec * 1000));
        let chain = `${vl.label}`;
        if (vl.trimSec != null && vl.trimSec > 0) {
            chain += `atrim=0:${vl.trimSec.toFixed(3)}`;
        }
        chain += `,adelay=${delayMs}|${delayMs},volume=1.0[v${i}]`;
        parts.push(chain);
        voiceDelayed.push(`[v${i}]`);
    });

    // 3) SFX layers (delayed + per-cue gain).
    const sfxDelayed = [];
    sfxLabels.forEach((sl, i) => {
        const delayMs = Math.max(0, Math.round(sl.atSec * 1000));
        const g = (0.80 * sl.gain).toFixed(3);
        parts.push(`${sl.label}adelay=${delayMs}|${delayMs},volume=${g}[s${i}]`);
        sfxDelayed.push(`[s${i}]`);
    });

    // 4) Mix everything.
    const all = ['[musicv]', ...voiceDelayed, ...sfxDelayed];
    const mixCount = all.length;
    parts.push(`${all.join('')}amix=inputs=${mixCount}:duration=longest:normalize=0[out]`);

    const filterComplex = parts.join(';');

    const args = [
        ...inputs,
        '-filter_complex', filterComplex,
        '-map', '[out]',
        '-ac', '2',
        '-ar', String(sr),
        '-c:a', 'pcm_s16le',
        '-y', spec.outPath,
    ];

    const res = spawnSync(ffmpeg, args, { stdio: 'pipe' });
    if (res.status !== 0) {
        // Fall back: just music (or silence) without overlays so audio still exists.
        const fb = spawnSync(ffmpeg, [
            ...inputs.slice(0, 2),
            '-filter_complex', `${musicLabel}aloop=loop=-1:size=2e9,atrim=0:${dur.toFixed(3)},volume=${musicVolExpr}[out]`,
            '-map', '[out]', '-ac', '2', '-ar', String(sr), '-c:a', 'pcm_s16le', '-y', spec.outPath,
        ], { stdio: 'pipe' });
        if (fb.status !== 0) {
            // Last resort: pure silence.
            spawnSync(ffmpeg, ['-f', 'lavfi', '-i', `anullsrc=r=${sr}:cl=stereo:d=${dur.toFixed(3)}`, '-ac', '2', '-ar', String(sr), '-c:a', 'pcm_s16le', '-y', spec.outPath], { stdio: 'pipe' });
        }
    }

    return fs.existsSync(spec.outPath) && fs.statSync(spec.outPath).size > 0;
}

module.exports = { mixAudio };
