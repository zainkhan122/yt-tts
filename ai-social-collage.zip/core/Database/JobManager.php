<?php
namespace AiSocialCollage\Database;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class JobManager {

	public static function create_job( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			Migration::ensure_tables();
		}

		// ── AUDIT FIX F8 ──────────────────────────────────────────────────────
		// The previous implementation used
		//   INSERT ... ON DUPLICATE KEY UPDATE post_id = post_id
		// and then returned $wpdb->insert_id. With InnoDB, an INSERT that turns
		// into an ON DUPLICATE KEY UPDATE still *allocates* an AUTO_INCREMENT
		// value, so LAST_INSERT_ID() can return a reserved, NON-EXISTENT id.
		// That is how log rows ended up referencing job id 110045 for a row whose
		// real id is 3470 — the plugin then scheduled and processed an action for
		// an id that does not exist in the jobs table.
		//
		// Fix: resolve the existing row explicitly (the UNIQUE KEY
		// (post_id, status) makes this an index-only lookup), then insert plainly.
		$existing_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $table_name WHERE post_id = %d AND status = %s LIMIT 1",
			(int) $post_id,
			Config::STATUS_PENDING
		) );

		if ( $existing_id > 0 ) {
			// Already queued. Return 0 so callers treat it as "no new job".
			return 0;
		}

		$inserted = $wpdb->insert(
			$table_name,
			[
				'post_id'    => (int) $post_id,
				'status'     => Config::STATUS_PENDING,
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ '%d', '%s', '%s', '%s' ]
		);

		if ( ! $inserted ) {
			// Lost the race, or a genuine failure. Re-read to disambiguate so the
			// caller never acts on a phantom id.
			$race_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM $table_name WHERE post_id = %d AND status = %s LIMIT 1",
				(int) $post_id,
				Config::STATUS_PENDING
			) );
			if ( $race_id > 0 ) {
				return 0;
			}
			Logger::error( 'create_job_failed', null, [
				'post_id'    => (int) $post_id,
				'db_error'   => $wpdb->last_error,
			], '500', 'Job insert failed' );
			return false;
		}

		update_post_meta( $post_id, '_ai_collage_job_created', 1 );

		return $wpdb->insert_id;
	}

	/**
	 * AUDIT FIX F2: atomically increment and return the attempt counter.
	 *
	 * This MUST be written to the database *before* any work is attempted, so
	 * that a job which hard-crashes the PHP process (OOM / max_execution_time /
	 * segfault — none of which are catchable as \Throwable) still leaves a
	 * durable trace. Without this, a poison job is retried forever and blocks
	 * every job behind it.
	 *
	 * @return int The new attempt count (1-based).
	 */
	public static function increment_retry_count( $job_id ): int {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->query( $wpdb->prepare(
			"UPDATE $table_name
			    SET retry_count = retry_count + 1,
			        updated_at  = %s
			  WHERE id = %d",
			gmdate( 'Y-m-d H:i:s' ),
			(int) $job_id
		) );

		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT retry_count FROM $table_name WHERE id = %d",
			(int) $job_id
		) );
	}

	/**
	 * AUDIT FIX F2: reset the attempt counter (used after a successful step).
	 */
	public static function reset_retry_count( $job_id ): void {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'retry_count' => 0,
				'updated_at'  => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_status( $job_id, $status ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$status = sanitize_text_field( $status );

		$updated = $wpdb->update(
			$table_name,
			[
				'status' => $status,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);

		// ── AUDIT FIX F9 ──────────────────────────────────────────────────────
		// The jobs table carries UNIQUE KEY post_id_status (post_id, status).
		// If another row for the same post already holds the target status, this
		// UPDATE silently fails: $wpdb->update() returns false, no PHP exception
		// is raised, and the caller carries on believing the transition worked.
		// That silently strands a job in its previous status forever.
		//
		// Make the failure visible, and auto-resolve the duplicate-row conflict
		// so the pipeline can continue.
		if ( false === $updated ) {
			$error = (string) $wpdb->last_error;

			Logger::error( 'job_status_update_failed', (int) $job_id, [
				'target_status' => $status,
				'db_error'      => $error,
			], '500', 'Job status transition failed: ' . $error );

			if ( stripos( $error, 'duplicate' ) !== false ) {
				self::resolve_status_conflict( (int) $job_id, $status );
			}

			return false;
		}

		return $updated;
	}

	/**
	 * AUDIT FIX F9: resolve a UNIQUE KEY (post_id, status) collision.
	 *
	 * Keeps the row we were trying to move, and moves the *other* row for the
	 * same post out of the way by flagging it FAILED. This unblocks the
	 * transition instead of leaving the job stranded in a stale status.
	 */
	private static function resolve_status_conflict( $job_id, string $status ): void {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$job = self::get_job( $job_id );
		if ( ! $job || empty( $job->post_id ) ) {
			return;
		}

		$conflict_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $table_name
			  WHERE post_id = %d AND status = %s AND id <> %d
			  ORDER BY id DESC LIMIT 1",
			(int) $job->post_id,
			$status,
			(int) $job_id
		) );

		if ( $conflict_id <= 0 ) {
			return;
		}

		$wpdb->query( $wpdb->prepare(
			"UPDATE $table_name SET status = %s, updated_at = %s WHERE id = %d",
			Config::STATUS_FAILED,
			gmdate( 'Y-m-d H:i:s' ),
			$conflict_id
		) );

		Logger::warning( 'job_status_conflict_resolved', (int) $job_id, [
			'target_status'  => $status,
			'conflict_job'   => $conflict_id,
			'post_id'        => (int) $job->post_id,
			'conflict_action'=> 'moved to failed',
		], '200', 'Duplicate (post_id,status) row found; older conflicting job failed to unblock this transition.' );

		// Retry the original transition once now that the conflict is gone.
		$wpdb->update(
			$table_name,
			[
				'status'     => $status,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

public static function update_job_data( $job_id, $headline, $hook ) {
        global $wpdb;
        $table_name = $wpdb->prefix . Config::TABLE_JOBS;
  
        // Guard against null values - sanitize_utf8_text handles null but be explicit
        $headline = $headline ?? '';
        $hook     = $hook ?? '';
  
        $wpdb->update(
            $table_name,
            [
                'ai_headline' => self::sanitize_utf8_text( $headline ),
                'ai_hook' => self::sanitize_utf8_text( $hook ),
                'updated_at' => gmdate( 'Y-m-d H:i:s' ),
            ],
            [ 'id' => (int) $job_id ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );
    }

	public static function update_detailed_description( $job_id, $description ) {
 global $wpdb;
 $table_name = $wpdb->prefix . Config::TABLE_JOBS;
 
 $wpdb->update(
 $table_name,
 [
 'ai_detailed_description' => self::sanitize_utf8_text( $description ),
 'updated_at' => gmdate( 'Y-m-d H:i:s' ),
 ],
 [ 'id' => (int) $job_id ],
 [ '%s', '%s' ],
 [ '%d' ]
);
}

	public static function update_eyebrow_key_terms( $job_id, $eyebrow, $key_terms ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'ai_eyebrow' => sanitize_text_field( $eyebrow ),
				'ai_key_terms' => is_array( $key_terms ) ? wp_json_encode( $key_terms ) : '',
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_emphasis_word( $job_id, $emphasis_word ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
 			'ai_emphasis_word' => mb_substr( self::sanitize_utf8_text( $emphasis_word ), 0, 50, 'UTF-8' ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

private static function sanitize_utf8_text( ?string $text ): string {
  		if ( $text === null || $text === '' ) {
  			return '';
  		}
  		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
  		$text = wp_strip_all_tags( $text );
  		$text = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text );
  		$text = trim( $text );
  		if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
  			$text = mb_convert_encoding( $text, 'UTF-8', 'UTF-8' );
  		}
  		return $text;
  	}

 	public static function update_image_metadata( $job_id, $metadata_json ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'image_metadata' => $metadata_json,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function job_exists_for_post( $post_id, $exclude_failed = false ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return false;
		}

		$post_exists = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE ID = %d",
			$post_id
		) );

		if ( $post_exists === 0 ) {
			$wpdb->delete( $table_name, [ 'post_id' => (int) $post_id ], [ '%d' ] );
			return false;
		}

		// Active/recoverable statuses that should block re-enqueueing.
		// FAILED and DISCARDED are terminal — they do NOT block.
		// SCHEDULED is included only when explicitly checking for active jobs (exclude_failed=false).
		// This matches CronScheduler's intent: don't queue if job is scheduled for prime time.
		if ( $exclude_failed ) {
			// FeedIngester path: only block on truly active jobs.
			// COMPLETED is included to prevent duplicate completed jobs.
			$blocking_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_COMPLETED ];
		} else {
			// CronScheduler path: also block on SCHEDULED (prime-time wait).
			$blocking_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_SCHEDULED, Config::STATUS_COMPLETED ];
		}

		$placeholders = implode( ',', array_fill( 0, count( $blocking_statuses ), '%s' ) );
		$sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE post_id = %d AND status IN ($placeholders)",
			array_merge( [ (int) $post_id ], $blocking_statuses )
		);
		$count = $wpdb->get_var( $sql );

		return (int) $count > 0;
	}

	public static function has_completed_job_for_post( int $post_id ): bool {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return false;
		}

		$post_exists = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE ID = %d",
			$post_id
		) );

		if ( $post_exists === 0 ) {
			$wpdb->delete( $table_name, [ 'post_id' => $post_id ], [ '%d' ] );
			return false;
		}

		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE post_id = %d AND status = %s LIMIT 1",
			$post_id,
			Config::STATUS_COMPLETED
		) ) > 0;
	}

	/**
	 * Check if a post has ANY job record (including failed/discarded).
	 * Used for auditing/debugging, not for enqueue blocking.
	 */
	public static function job_any_exists_for_post( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return false;
		}

		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE post_id = %d",
			(int) $post_id
		) );

		return $count > 0;
	}

	public static function get_job( $job_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE id = %d",
				(int) $job_id
			)
		);
	}

	public static function get_jobs_by_status( $status, $limit = 100, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE status = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $status ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function get_status_counts() {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [];
		}

		$results = $wpdb->get_results(
			"SELECT status, COUNT(*) as cnt FROM $table_name GROUP BY status"
		);

		$counts = [];
		foreach ( $results as $row ) {
			$counts[ $row->status ] = (int) $row->cnt;
		}

		return $counts;
	}

	public static function update_template_data( $job_id, $template, $category, $language ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'template' => sanitize_text_field( $template ),
				'template_category' => sanitize_text_field( $category ),
				'language' => sanitize_text_field( $language ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_brand_data( $job_id, $logo_position, $emphasis_color, $key_term_color, $breaking_color, $text_backing_color ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'brand_logo_position' => sanitize_text_field( $logo_position ),
				'emphasis_color' => sanitize_hex_color( $emphasis_color ),
				'key_term_color' => sanitize_hex_color( $key_term_color ),
				'breaking_color' => sanitize_hex_color( $breaking_color ),
				'text_backing_color' => sanitize_hex_color( $text_backing_color ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s', '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_additional_images( $job_id, array $image_urls ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$data = [ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ];
		$format = [ '%s' ];

		for ( $i = 2; $i <= 4; $i++ ) {
			$key = 'image_url_' . $i;
			$data[ $key ] = isset( $image_urls[ $i ] ) ? esc_url_raw( $image_urls[ $i ] ) : null;
			$format[] = '%s';
		}

		$wpdb->update(
			$table_name,
			$data,
			[ 'id' => (int) $job_id ],
			$format,
			[ '%d' ]
		);
	}

	public static function update_headline_verified( $job_id, $verified = true ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'headline_verified' => $verified ? 1 : 0,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_original_image( $job_id, string $image_path ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'original_image_path' => $image_path,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_ai_generated_image_url( $job_id, $url ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'ai_generated_image_url' => esc_url_raw( $url ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function get_jobs_by_template( $template, $limit = 50, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE template = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $template ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function get_jobs_by_language( $language, $limit = 50, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE language = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $language ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function delete_job( $job_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$job = self::get_job( $job_id );
		if ( $job && ! empty( $job->post_id ) ) {
			$post_id = (int) $job->post_id;
			delete_post_meta( $post_id, '_ai_collage_job_created' );
			delete_post_meta( $post_id, Config::META_CAMPAIGN_DATA );
			delete_transient( 'ai_collage_queued_recent_' . $post_id );

			// AUDIT F1: clear Buffer share history so a re-queued job can
			// re-share to channels that were already shared. Without this,
			// the new per-channel dedup in BufferIntegration would silently
			// skip every channel on the re-run, defeating the purpose of
			// manually deleting the job.
			delete_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY );

			// AUDIT F5: clear any pending Buffer share for this post so a
			// re-queue starts at retry_count=0 instead of inheriting a stale
			// count that may have hit the cap.
			$pending = get_option( Config::OPTION_BUFFER_PENDING_SHARES, [] );
			if ( is_array( $pending ) ) {
				$changed = false;
				foreach ( $pending as $key => $entry ) {
					if ( isset( $entry['post_id'] ) && (int) $entry['post_id'] === $post_id ) {
						unset( $pending[ $key ] );
						$changed = true;
					}
				}
				if ( $changed ) {
					update_option( Config::OPTION_BUFFER_PENDING_SHARES, $pending );
				}
			}
		}

		$wpdb->delete(
			$table_name,
			[ 'id' => (int) $job_id ],
			[ '%d' ]
		);
	}

    public static function purge_old_jobs( $days ) {
        global $wpdb;
        $table_name = $wpdb->prefix . Config::TABLE_JOBS;
        $posts_table = $wpdb->posts;

        // AUDIT FIX 2.1: completed jobs must NOT be purged while their WP post
        // still exists. has_completed_job_for_post() is the duplicate guard at
        // every enqueue point (PostObserver, CronScheduler, FeedIngester);
        // deleting the row first un-guards the post and a later save re-queues
        // it, producing a duplicate generated post. Failed jobs have no such
        // guard dependency, so they purge on age alone.
        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE j FROM $table_name j
                 LEFT JOIN $posts_table p ON p.ID = j.post_id
                 WHERE j.created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)
                   AND (
                         j.status IN (%s, %s)
                         OR ( j.status = %s AND p.ID IS NULL )
                       )",
                (int) $days,
                Config::STATUS_FAILED,
                Config::STATUS_DISCARDED,
                Config::STATUS_COMPLETED
            )
        );
    }

	/**
	 * Purge jobs stuck in non-terminal active statuses beyond the retention window.
	 *
	 * Covers `pending` jobs whose Action Scheduler action was lost and `scheduled`
	 * jobs whose prime-time action never fired (legitimate prime-time waits are < 24h).
	 * `ready_for_review` is intentionally excluded (human action pending);
	 * `rewriting`/`rendering` are transitioned to failed within minutes by
	 * mark_stuck_jobs_failed() and then purged by purge_old_jobs().
	 * Uses updated_at: every state transition refreshes it, so only truly
	 * stagnant rows are removed.
	 */
	public static function purge_stuck_jobs( $days ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $table_name WHERE updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) AND status IN (%s, %s)",
				(int) $days,
				Config::STATUS_PENDING,
				Config::STATUS_SCHEDULED
			)
		);
	}

	public static function count_stuck_jobs( $timeout_minutes = 30 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		$stuck_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_SCHEDULED ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );
		$sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM `$table_name` WHERE status IN ($placeholders) AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
			array_merge( $stuck_statuses, [ (int) $timeout_minutes ] )
		);
		return (int) $wpdb->get_var( $sql );
	}

	public static function mark_stuck_jobs_failed( $timeout_minutes = 30, $pending_minutes = 30, $pending_min_attempts = 3 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		$stuck_statuses = [ Config::STATUS_REWRITING, Config::STATUS_RENDERING ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );

		$stuck = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `$table_name` WHERE status IN ($placeholders) AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
				array_merge( $stuck_statuses, [ (int) $timeout_minutes ] )
			)
		);

		$count = 0;
		foreach ( $stuck as $job ) {
			$wpdb->update(
				$table_name,
				[ 'status' => Config::STATUS_FAILED, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
				[ 'id' => (int) $job->id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);

			// ENHANCEMENT: Clear individual job locks to prevent persistent staleness
			delete_transient( 'ai_collage_job_lock_' . (int) $job->id );
			delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );

			delete_post_meta( (int) $job->post_id, '_ai_collage_job_created' );

			$count++;
		}

		// PENDING recovery: a pending job whose Action Scheduler action was lost
		// (failed enqueue, AS table truncation, etc.) can never transition and
		// would sit in the queue forever. Fail it so it surfaces on the Jobs page
		// for manual retry. A pending job that still owns a live AS action is
		// left untouched — this includes jobs deferred while the pipeline is
		// paused (QueueProcessor::process_job re-schedules them every 60s, so a
		// live action always exists for them). If a stale action fires after the
		// job was failed, do_process_job() safely no-ops on STATUS_FAILED.
		//
		// "Live action" semantics MUST match QueueHealthMonitor::fix_orphaned_db_jobs()
		// (single source of truth for action-existence): three argument formats
		// (compact JSON, JSON with space, PHP-serialized) AND a 5-minute
		// scheduled_date_gmt window. Without the window, a stale-but-pending
		// action (runner dead) would shield an orphaned job — defeating the fix
		// exactly when the monitor is also dead.
		// ── AUDIT FIX F4 ──────────────────────────────────────────────────────
		// The block below was DEAD CODE in production, because of two
		// interactions with the health monitor:
		//
		//   1. It tests  j.updated_at < NOW - N minutes.
		//      But QueueHealthMonitor::auto_recover_stuck_pipeline() and
		//      ::fix_orphaned_db_jobs() both bump `updated_at` to NOW for every
		//      pending job on every 5-minute cycle. `updated_at` is therefore
		//      ALWAYS fresh, so a genuinely dead pending job never looks stale.
		//
		//   2. It requires NOT EXISTS (a live AS action scheduled in the last
		//      5 minutes). But those same recovery routines schedule a brand new
		//      AS action for every pending job on every cycle, so a "live"
		//      action always exists and shields the job permanently.
		//
		// Net effect: the only staleness detector for PENDING jobs was blinded
		// by the very routine that was supposed to be its safety net. That is
		// why every Reset / Force Recover reported "stuck_failed: 0".
		//
		// Fix: age PENDING jobs by `created_at` (never rewritten by recovery)
		// and gate on `retry_count` (incremented by QueueProcessor::process_job
		// BEFORE any work, so it survives fatal crashes). Jobs that are simply
		// queued and healthy have retry_count = 0 and are never touched.
		$as_live_table = $wpdb->prefix . 'actionscheduler_actions';
		$pending_minutes     = (int) ( $pending_minutes > 0 ? $pending_minutes : 30 );
		$pending_min_attempts = (int) $pending_min_attempts;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_live_table'" ) === $as_live_table ) {
			$orphaned_sql = 'SELECT j.id, j.post_id FROM `' . $table_name . '` j '
				. 'WHERE j.status = %s '
				// created_at is immutable — recovery routines must not be able
				// to launder a dead job's age.
				. 'AND j.created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE) '
				. 'AND ( j.retry_count >= %d '
				. '   OR j.created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 180 MINUTE) ) '
				. 'AND NOT EXISTS ('
				. '  SELECT 1 FROM `' . $as_live_table . '` a '
				. '  WHERE a.hook = %s '
				. '    AND ( '
				. '      (a.status = \'in-progress\') '
				. '      OR (a.status = \'pending\' AND a.scheduled_date_gmt > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)) '
				. '    ) '
				. '    AND ( a.args LIKE CONCAT(\'%%"job_id":\', j.id, \'}\') '
				. '       OR a.args LIKE CONCAT(\'%%"job_id": \', j.id, \'}\') '
				. '       OR a.args LIKE CONCAT(\'%%\\\'job_id\\\':\', j.id, \';%%\') )'
				. ')';
			$orphaned_pending = $wpdb->get_results( $wpdb->prepare(
				$orphaned_sql,
				Config::STATUS_PENDING,
				$pending_minutes,
				$pending_min_attempts,
				Config::ACTION_PROCESS_JOB
			) );

			foreach ( $orphaned_pending as $pjob ) {
				$attempts = (int) ( $pjob->retry_count ?? 0 );

				$wpdb->update(
					$table_name,
					[ 'status' => Config::STATUS_FAILED, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
					[ 'id' => (int) $pjob->id ],
					[ '%s', '%s' ],
					[ '%d' ]
				);

				delete_transient( 'ai_collage_job_lock_' . (int) $pjob->id );
				delete_transient( 'ai_collage_queued_recent_' . (int) $pjob->post_id );
				delete_transient( 'ai_collage_job_perm_fail_' . (int) $pjob->id );

				delete_post_meta( (int) $pjob->post_id, '_ai_collage_job_created' );

				// AUDIT FIX F4: make poison-job quarantine visible in the log.
				// Previously these were counted but never reported, so the
				// dashboard always read "stuck_failed: 0".
				Logger::warning( 'pending_job_quarantined', (int) $pjob->id, [
					'post_id'  => (int) $pjob->post_id,
					'attempts' => $attempts,
					'age_min'  => $pending_minutes,
					'reason'   => 'Pending job exceeded attempt/age budget — marked FAILED to unblock the queue.',
				], '500', 'Poison pending job quarantined' );

				$count++;
			}
		}

		// CRITICAL FIX: Properly unclaim stuck AS actions AND delete orphaned claim rows
		// This replaces the previous raw SQL that only zeroed claim_id without cleaning up
		// the claims table, which caused queue deadlocks.
		$as_table = $wpdb->prefix . 'actionscheduler_actions';
		$claims_table = $wpdb->prefix . 'actionscheduler_claims';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) === $as_table ) {
			// First, collect the claim IDs that will be orphaned so we can clean them up
			$claim_ids_to_delete = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT claim_id FROM `$as_table` 
				 WHERE claim_id != 0 AND status = 'in-progress' AND hook = %s",
				Config::ACTION_PROCESS_JOB
			) );
			
			// Reset stuck actions to pending and unclaim them
			$wpdb->query( $wpdb->prepare(
				"UPDATE `$as_table` SET status = 'pending', claim_id = 0 
				 WHERE status = 'in-progress' AND hook = %s",
				Config::ACTION_PROCESS_JOB
			) );
			
			// Delete the orphaned claim rows to prevent claim count inflation
			if ( ! empty( $claim_ids_to_delete ) ) {
				$claim_placeholders = implode( ',', array_fill( 0, count( $claim_ids_to_delete ), '%d' ) );
				$wpdb->query( $wpdb->prepare(
					"DELETE FROM `$claims_table` WHERE claim_id IN ($claim_placeholders)",
					$claim_ids_to_delete
				) );
			}
		}

		return $count;
	}

	public static function update_viability_score( $job_id, $score, $reason = '' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'viability_score' => (int) $score,
				'viability_reason' => sanitize_text_field( mb_substr( $reason, 0, 500 ) ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function purge_discarded_jobs( $days ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $table_name WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) AND status = %s",
				(int) $days,
				Config::STATUS_DISCARDED
			)
		);
	}

	public static function get_viability_stats() {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [ 'total_scored' => 0, 'avg_score' => 0, 'discarded_count' => 0, 'passed_count' => 0, 'score_distribution' => [] ];
		}

		$total_scored = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM $table_name WHERE viability_score IS NOT NULL"
		);

		$avg_score = (float) $wpdb->get_var(
			"SELECT AVG(viability_score) FROM $table_name WHERE viability_score IS NOT NULL"
		);

		$discarded_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE status = %s",
				Config::STATUS_DISCARDED
			)
		);

		$passed_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE viability_score IS NOT NULL AND status != %s",
				Config::STATUS_DISCARDED
			)
		);

		$distribution = [];
		$rows = $wpdb->get_results(
			"SELECT
				CASE
					WHEN viability_score BETWEEN 1 AND 3 THEN '1-3'
					WHEN viability_score BETWEEN 4 AND 6 THEN '4-6'
					WHEN viability_score BETWEEN 7 AND 8 THEN '7-8'
					WHEN viability_score BETWEEN 9 AND 10 THEN '9-10'
					ELSE 'unknown'
				END as bucket,
				COUNT(*) as cnt
			FROM $table_name
			WHERE viability_score IS NOT NULL
			GROUP BY bucket
			ORDER BY bucket"
		);
		foreach ( $rows as $row ) {
			$distribution[ $row->bucket ] = (int) $row->cnt;
		}

		return [
			'total_scored' => $total_scored,
			'avg_score' => round( $avg_score, 2 ),
			'discarded_count' => $discarded_count,
			'passed_count' => $passed_count,
			'score_distribution' => $distribution,
		];
	}

	public static function update_retry_count( $job_id, $retry_count ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'retry_count' => (int) $retry_count,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
	}

	/**
	 * Get video jobs ready for Buffer publishing via the publish scheduler cron.
	 * Returns jobs with a video_url, publish_at <= now, and not yet published to all channels.
	 *
	 * @param int $limit Max jobs to return.
	 * @return array Array of job objects.
	 */
	/**
	 * Get the latest completed job for a specific post.
	 */
	public static function get_completed_job_for_post( int $post_id ): ?object {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name
				 WHERE post_id = %d
				   AND status = %s
				   AND (video_url IS NULL OR video_url = '')
				 ORDER BY id DESC
				 LIMIT 1",
				$post_id,
				Config::STATUS_COMPLETED
			)
		);
	}

	/**
	 * Get completed jobs that should already have a video_url but don't
	 * (render finished but R2 upload was skipped, failed, or aborted).
	 * Used by the stuck-R2 retry cron to find recoverable jobs.
	 *
	 * @param int $limit Max jobs to return.
	 * @return array Array of job objects.
	 */
	public static function get_stuck_r2_jobs( int $limit = 10 ): array {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [];
		}
		// Only recover completed jobs whose WP post is PUBLISHED and that have an
		// AI-generated reel attachment. Draft/future posts defer R2 to publish
		// time (PostObserver::on_publish_transition) and image posts never have a
		// reel — neither belongs in the stuck-R2 recovery loop.
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT j.* FROM $table_name j
				 INNER JOIN {$wpdb->posts} p ON p.ID = j.post_id
					AND p.post_type = 'post'
					AND p.post_status = 'publish'
				 INNER JOIN {$wpdb->posts} att ON att.post_parent = j.post_id
					AND att.post_type = 'attachment'
					AND att.post_mime_type LIKE 'video%'
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = att.ID
					AND pm.meta_key = %s
					AND pm.meta_value = '1'
				 WHERE j.status = %s
				   AND (j.video_url IS NULL OR j.video_url = '')
				   AND j.updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 10 MINUTE)
				   AND j.updated_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)
				 ORDER BY j.updated_at ASC
				 LIMIT %d",
				Config::META_IS_AI_COLLAGE,
				Config::STATUS_COMPLETED,
				$limit
			)
		);
	}

	public static function get_jobs_ready_for_publish( int $limit = 20 ): array {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name
				WHERE status = %s
				AND video_url IS NOT NULL AND video_url != ''
				AND publish_at IS NOT NULL AND publish_at != ''
				AND publish_at <= UTC_TIMESTAMP()
				ORDER BY publish_at ASC
				LIMIT %d",
				Config::STATUS_COMPLETED,
				$limit
			)
		);
	}

	public static function update_job_fields( $job_id, array $fields ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$allowed = [ 'video_url', 'publish_at', 'published_channels', 'buffer_post_ids' ];
		$data = [];
		$format = [];
		foreach ( $fields as $key => $value ) {
			if ( in_array( $key, $allowed, true ) ) {
				$data[ $key ] = $value;
				$format[] = '%s';
			}
		}
		if ( empty( $data ) ) {
			return;
		}
		$data['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		$format[] = '%s';

		$wpdb->update(
			$table_name,
			$data,
			[ 'id' => (int) $job_id ],
			$format,
			[ '%d' ]
		);
	}
}
