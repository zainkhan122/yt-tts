<?php

/**
 * AJAX Handler for AI Quiz and News Quiz Generation
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_AI_Quiz_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @NEW 2026-02-16: Get Authoritative Working Model
     * Consolidates the "proven" model ID into one place.
     * @MODIFIED 2026-06-26: Honor active AI provider via Provider Registry.
     */
    public function get_working_model()
    {
        $active = get_option('mcqvs_api_provider', 'gemini');
        if (class_exists('VS_Provider_Registry') && !empty($active)) {
            try {
                return VS_Provider_Registry::get_instance()->get_working_model($active);
            } catch (\Exception $e) {
                // keep legacy Gemini fallback
            }
        }
        return get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
    }

    /**
     * AJAX Handler for AI Quiz Generation
     */
    public function ajax_generate_ai_quiz()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        $topic   = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';

        if (strlen($topic) > 1000) {
            wp_send_json_error(__('Topic description is too long.', 'mcq-video-studio'));
        }

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if (!$registry) {
            $active_provider = 'gemini';
            $is_custom = false;
            $api_key = get_option('mcqvs_gemini_api_key', '');
            if (empty($api_key)) {
                $api_key = get_option('nm_gemini_api_key', '');
            }
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
        } else {
            $rotation = $registry->get_next_model('ajax_quiz');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $is_custom = $registry->is_custom($active_provider);
            $api_key = $registry->get_rotation_api_key($active_provider);
        }

        if (empty($api_key)) {
            if (class_exists('NM_Generation_Logger')) {
                NM_Generation_Logger::nm_log_activity(
                    'AI API key not configured',
                    'error',
                    array(
                        'source_type' => 'video_studio',
                        'error_code'  => 'missing_api_key',
                        'provider'    => $active_provider,
                    )
                );
            }
            wp_send_json_error(__('AI API Key not configured in Studio Settings.', 'mcq-video-studio'));
        }

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        $prompt = "Generate a 5-question viral quiz about \"$topic\" for TikTok/Shorts.
        
Rules:
- Scene 0: Viral hook title (options: empty, correct: 0)
- Scene 1-5: Quiz questions with 4 options each, short (max 15 words)
- Scene 6: CTA 'Follow for more quizzes!' (options: empty, correct: 0)

Each question must have exactly 4 options and correct must be 0-3.
CRITICAL: Return a JSON ARRAY of 7 objects (scene 0 + 5 questions + scene 6). Begin with [.";

        // @NEW 2026-01-10: JSON Response Schema for Gemini
        $response_schema = array(
            'type' => 'ARRAY',
            'items' => array(
                'type' => 'OBJECT',
                'properties' => array(
                    'question' => array('type' => 'STRING'),
                    'options' => array(
                        'type' => 'ARRAY',
                        'items' => array('type' => 'STRING')
                    ),
                    'correct' => array('type' => 'INTEGER'),
                    'background' => array('type' => 'STRING')
                ),
                'required' => array('question', 'options', 'correct')
            )
        );

        $max_retries = 5;
        $attempt = 0;
        $delay = 1;
        $last_error = null;
        $questions = null;
        $rotation_retries = 0;
        $max_rotation_retries = 3;
        $current_provider = $active_provider;
        $current_model = $model;
        $current_api_key = $api_key;
        $current_is_custom = $is_custom;

        $last_attempt_key = '';
        while ($attempt <= $max_retries) {
            // @FIX 1.5.1 (NO WAIT ON FAILOVER): only backoff when retrying the SAME
            // model. When a model fails, record_failure() puts ONLY that model in cooldown
            // and get_next_model() returns a fresh model/provider — so we must NOT sleep
            // before trying the next model. We simply move on immediately; the throttled
            // model is skipped until its cooldown expires.
            $attempt_key = $current_provider . '::' . $current_model;
            if ($attempt > 0 && $attempt_key === $last_attempt_key) {
                sleep($delay);
                $delay *= 2;
            }
            $last_attempt_key = $attempt_key;
            $attempt++;

            if (class_exists('VS_Provider_Registry')) {
                $url = VS_Provider_Registry::get_instance()->build_rotation_url($current_provider, $current_model);
            } else {
                $url = "https://generativelanguage.googleapis.com/v1beta/models/{$current_model}:generateContent?key=" . $current_api_key;
            }

            if (class_exists('VS_Provider_Registry')) {
                $request_body = VS_Provider_Registry::get_instance()->build_request_body(
                    $current_provider,
                    array(array('role' => 'user', 'content' => $prompt)),
                    $current_model,
                    array(
                        'response_schema' => $response_schema,
                        'json_mode' => true
                    )
                );
            } else {
                $request_body = array(
                    'contents' => array(array('parts' => array(array('text' => $prompt)))),
                    'generationConfig' => array(
                        'response_mime_type' => 'application/json',
                        'response_schema' => $response_schema
                    )
                );
            }

            $start_time = microtime(true);
            $post_args = array(
                'body'    => wp_json_encode($request_body),
                'timeout' => 180,
            );
            if (class_exists('VS_Provider_Registry')) {
                $post_args['headers'] = VS_Provider_Registry::get_instance()->build_rotation_headers($current_provider, $url);
            } else {
                $post_args['headers'] = array('Content-Type' => 'application/json');
            }
            $response = wp_remote_post(
                $url,
                $post_args
            );
            $duration = microtime(true) - $start_time;

            // Central API Logging
            VS_Error_Logger::get_instance()->log_api(
                $url,
                'POST',
                array('prompt' => $prompt, 'model' => $current_model, 'provider' => $current_provider, 'attempt' => $attempt),
                $response,
                $duration,
                $current_provider
            );

            if (is_wp_error($response)) {
                $last_error = $response->get_error_message();
                VS_Error_Logger::get_instance()->log(
                    'AI API request failed',
                    'error',
                    array('message' => $last_error, 'topic' => $topic, 'attempt' => $attempt, 'provider' => $current_provider)
                );
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model);
                    $next = VS_Provider_Registry::get_instance()->get_next_model('ajax_quiz');
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }

            $code = wp_remote_retrieve_response_code($response);
            if ($code === 429 || $code === 503) {
                $last_error = "HTTP {$code} from {$current_provider}/{$current_model}";
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model);
                    $next = VS_Provider_Registry::get_instance()->get_next_model('ajax_quiz');
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }
            if ($code >= 400) {
                $raw_body_err = wp_remote_retrieve_body($response);
                $body_err = json_decode($raw_body_err, true);
                $last_error = $body_err['error']['message'] ?? $body_err['message'] ?? "API HTTP Error: {$code}";
                VS_Error_Logger::get_instance()->log(
                    'AI API client error',
                    'error',
                    array('code' => $code, 'error' => $last_error, 'provider' => $current_provider)
                );
                continue;
            }

            $raw_body_str = wp_remote_retrieve_body($response);
            $body = json_decode($raw_body_str, true);

            $raw_text = '';
            if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
                $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
            } elseif (isset($body['choices'][0]['message']['content'])) {
                $raw_text = $body['choices'][0]['message']['content'];
            }

            if (empty($raw_text)) {
                $last_error = 'Empty response from API';
                continue;
            }

            $questions = json_decode($raw_text, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $questions = $this->parse_ai_json_response($raw_text);
            }

            if (!$questions || !is_array($questions)) {
                $last_error = 'Failed to parse JSON response';
                continue;
            }

            // @NEW 2026-01-10: Validate Structure (4 options, correct 0-3)
            $validation_error = $this->validate_quiz_questions($questions);
            if ($validation_error) {
                $last_error = $validation_error;
                VS_Error_Logger::get_instance()->log(
                    'Quiz validation failed',
                    'warning',
                    array('error' => $validation_error, 'attempt' => $attempt)
                );
                continue; // Retry on validation failure
            }

            // Valid response - break out of retry loop
            if (class_exists('VS_Provider_Registry')) {
                VS_Provider_Registry::get_instance()->record_success($current_provider, $current_model);
            }
            break;
        }

        if ($questions === null || $last_error) {
            wp_send_json_error(array(
                'message'      => __('Failed after retries: ', 'mcq-video-studio') . ($last_error ?? 'Unknown error'),
                'attempts'     => $attempt,
                'debug_prompt' => $prompt
            ));
        }

        wp_send_json_success(array(
            'questions'    => $questions,
            'debug_prompt' => $prompt,
            'model'        => $current_model,
            'provider'     => $current_provider,
            'attempts'     => $attempt
        ));
    }

    /**
     * @NEW 2026-01-10: Validate Quiz Questions
     * 
     * Checks that quiz scenes have valid structure:
     * - Non-hook/CTA scenes must have 4 options
     * - Correct index must be 0-3 or 0 for hook/CTA
     *
     * @param array $questions Array of question objects
     * @return string|null Error message or null if valid
     */
    private function validate_quiz_questions($questions)
    {
        if (!is_array($questions) || count($questions) < 3) {
            return 'Too few questions returned';
        }

        foreach ($questions as $idx => $q) {
            if (!isset($q['question']) || !isset($q['options']) || !isset($q['correct'])) {
                return "Question $idx missing required fields";
            }

            $is_hook_or_cta = ($idx === 0 || $idx === count($questions) - 1);

            if (!$is_hook_or_cta) {
                // Quiz questions must have exactly 4 options
                if (count($q['options']) !== 4) {
                    return "Question $idx must have exactly 4 options (has " . count($q['options']) . ")";
                }

                // Correct index must be 0-3
                if ($q['correct'] < 0 || $q['correct'] > 3) {
                    return "Question $idx has invalid correct index: " . $q['correct'];
                }
            }
        }

        return null; // Valid
    }
    /**
     * @NEW 2026-02-08: Public method for background/bulk quiz generation
     * Returns array of questions or WP_Error
     * 
     * @param string $topic Topic name
     * @param int $count Number of questions (default 5)
     * @return array|WP_Error
     */
    /**
     * @NEW 2026-02-19: Batch Quiz Generation (Multi-Topic in 1 Call)
     * Groups multiple topics into one API request to save costs and time.
     * 
     * @param array $topics Array of topic strings
     * @param int $count_per_topic Number of questions per topic
     * @return array|WP_Error Nested array [topic => questions] or WP_Error
     */
    public function generate_batch_topic_quiz_data($topics, $count_per_topic = 5)
    {
        if (empty($topics) || !is_array($topics)) {
            return new WP_Error('invalid_topics', 'Topics array is required.');
        }

        $topics_list = implode("\n", array_map(function ($t) {
            return "- " . $t;
        }, $topics));

        $prompt = "You are a professional exam quiz creator and a viral-shorts copywriter. Create a {$count_per_topic}-question multiple-choice quiz for EACH of the following topics:\n\n"
            . "TOPICS:\n{$topics_list}\n\n"
            . "STRICT REQUIREMENTS:\n"
            . "1. Provide exactly {$count_per_topic} questions per topic.\n"
            . "2. Questions must be CONCISE (max 12 words) and challenging.\n"
            . "3. Options must be short (1-5 words), ALL four must be PLAUSIBLE and clearly distinguishable — the quiz fails if wrong options are silly or obviously wrong.\n"
            . "4. Include the correct answer as an index (0-3).\n"
            . "5. FACT ACCURACY: only use well-established, verifiable facts. Never invent statistics, dates, or people. When in doubt, leave the question out.\n"
            . "6. Each topic must contain AT LEAST ONE genuinely surprising 'wow' fact that would make a viewer comment or share.\n"
            . "7. Order the questions EASY -> MEDIUM -> HARD (a viewer must win early to keep watching).\n"
            . "8. Provide exactly 3-5 highly relevant social-media hashtags for each topic. Hashtags must be single words (no spaces), lowercase, comma or space separated, WITHOUT the # prefix. Example: \"science,quiz,learnfast\".\n"
            . "9. Provide ONE short viral hook line (max 8 words) for each topic, starting with a relevant emoji. IMPORTANT: the hook MUST be derived from the MOST surprising question you generated for that topic — reference that surprising fact (e.g. \"🦑 The largest animal eye belongs to...\"). It must be a question or a bold claim that creates a curiosity gap WITHOUT spoiling the answer, NOT a generic phrase. No markdown, no asterisks, no dashes.\n\n"
            . "Response format:\n"
            . '[{"topic": "Name of Topic", "hashtags": "science,quiz,learnfast", "hook": "🤔 Can you name the animal with the largest eye?", "questions": [{"question": "...", "options": ["..."], "correct": 0, "difficulty": "Easy"}]}]';

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('batch_quiz');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = get_option('mcqvs_gemini_api_key', '');
            if (empty($api_key)) $api_key = get_option('nm_gemini_api_key', '');
        }
        if (empty($api_key)) return new WP_Error('missing_api_key', 'AI API Key not found.');

        // @SCHEMA: Nested structure [ {topic, hashtags, hook, questions: []} ]
        $response_schema = array(
            'type' => 'ARRAY',
            'items' => array(
                'type' => 'OBJECT',
                'properties' => array(
                    'topic' => array('type' => 'STRING'),
                    'hashtags' => array('type' => 'STRING'),
                    'hook' => array('type' => 'STRING'),
                    'questions' => array(
                        'type' => 'ARRAY',
                        'items' => array(
                            'type' => 'OBJECT',
                            'properties' => array(
                                'question' => array('type' => 'STRING'),
                                'options' => array(
                                    'type' => 'ARRAY',
                                    'items' => array('type' => 'STRING')
                                ),
                                'correct' => array('type' => 'INTEGER'),
                                'difficulty' => array('type' => 'STRING'),
                                'explanation' => array('type' => 'STRING')
                            ),
                            'required' => array('question', 'options', 'correct')
                        )
                    )
                ),
                'required' => array('topic', 'questions')
            )
        );

        $max_retries = 2;
        $attempt = 0;
        $delay = 1;
        $last_error = null;
        $batch_results = null;
        $rotation_retries = 0;
        $max_rotation_retries = 3;
        $current_provider = $active_provider;
        $current_model = $model;
        $current_api_key = $api_key;

        $last_attempt_key = '';
        while ($attempt <= $max_retries) {
            // @FIX 1.5.1 (NO WAIT ON FAILOVER): only backoff when retrying the SAME
            // model. When a model fails, record_failure() puts ONLY that model in cooldown
            // and get_next_model() returns a fresh model/provider — so we must NOT sleep
            // before trying the next model. We simply move on immediately; the throttled
            // model is skipped until its cooldown expires.
            $attempt_key = $current_provider . '::' . $current_model;
            if ($attempt > 0 && $attempt_key === $last_attempt_key) {
                sleep($delay);
                $delay *= 2;
            }
            $last_attempt_key = $attempt_key;
            $attempt++;

            $url = class_exists('VS_Provider_Registry')
                ? VS_Provider_Registry::get_instance()->build_rotation_url($current_provider, $current_model)
                : "https://generativelanguage.googleapis.com/v1beta/models/{$current_model}:generateContent?key=" . $current_api_key;

            if (class_exists('VS_Provider_Registry')) {
                $request_body = VS_Provider_Registry::get_instance()->build_request_body(
                    $current_provider,
                    array(array('role' => 'user', 'content' => $prompt)),
                    $current_model,
                    array(
                        'response_schema' => $response_schema,
                        'json_mode' => true
                    )
                );
            } else {
                $request_body = array(
                    'contents' => array(array('parts' => array(array('text' => $prompt)))),
                    'generationConfig' => array(
                        'response_mime_type' => 'application/json',
                        'response_schema' => $response_schema
                    )
                );
            }

            $post_args = array(
                'body'    => wp_json_encode($request_body),
                'timeout' => 180,
            );
            if (class_exists('VS_Provider_Registry')) {
                $post_args['headers'] = VS_Provider_Registry::get_instance()->build_rotation_headers($current_provider, $url);
            } else {
                $post_args['headers'] = array('Content-Type' => 'application/json');
            }

            $start_time = microtime(true);
            $response = wp_remote_post($url, $post_args);
            $duration = microtime(true) - $start_time;

            VS_Error_Logger::get_instance()->log_api($url, 'POST', array('topics' => $topics, 'attempt' => $attempt, 'provider' => $current_provider, 'model' => $current_model), $response, $duration, $current_provider);

            if (is_wp_error($response)) {
                $last_error = $response->get_error_message();
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, 'http_error');
                    $next = VS_Provider_Registry::get_instance()->get_next_model('batch_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("Batch retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (http_error)", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            if ($http_code === 429 || $http_code === 503) {
                $last_error = "HTTP {$http_code} from {$current_provider}/{$current_model}";
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, (string) $http_code);
                    $next = VS_Provider_Registry::get_instance()->get_next_model('batch_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("Batch retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (HTTP {$http_code})", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }
            if ($http_code >= 400) {
                $raw_body_err = wp_remote_retrieve_body($response);
                $body_err = json_decode($raw_body_err, true);
                $last_error = $body_err['error']['message'] ?? $body_err['message'] ?? "API HTTP Error: {$http_code}";
                continue;
            }

            $raw_body = wp_remote_retrieve_body($response);
            $body = json_decode($raw_body, true);

            $raw_text = '';
            if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
                $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
            } elseif (isset($body['choices'][0]['message']['content'])) {
                $raw_text = $body['choices'][0]['message']['content'];
            }

            if (empty($raw_text)) {
                $last_error = 'Empty response from API';
                continue;
            }

            $batch_results = $this->parse_ai_json_response($raw_text);
            if (!is_array($batch_results) || empty($batch_results)) {
                $last_error = 'Failed to parse batch response';
                continue;
            }

            if (class_exists('VS_Provider_Registry')) {
                VS_Provider_Registry::get_instance()->record_success($current_provider, $current_model);
            }
            $last_error = null;
            break;
        }

        if ($batch_results === null || $last_error) {
            return new WP_Error('batch_generation_failed', $last_error ?? 'Unknown error');
        }

        // Format & Segregate
        $final_map = array();
        foreach ($batch_results as $group) {
            $topic_name = $group['topic'] ?? 'Unknown';
            $questions = $group['questions'] ?? array();

            if (empty($questions)) continue;

            // @NEW 2026-08-01: Normalize AI hashtags -> clean "#tag" space-separated list.
            //       Strips markdown (**), backticks, leading -, *, #, and comma/semicolon
            //       separators so the values render cleanly on social networks.
            $hashtags = self::normalize_hashtags($group['hashtags'] ?? '');
            // @NEW 2026-08-01: Normalize AI hook -> single trimmed line, emoji preserved,
            //       stripped of markdown artifacts (**, `, leading -/*/#), max 120 chars.
            $hook = self::normalize_hook($group['hook'] ?? '');

            $formatted = array_map(function ($q, $i) use ($topic_name) {
                $options = array_map(function ($opt) {
                    return trim(preg_replace('/^(Option\s+|[A-D0-9][\.\)\:\-\s]+|\([A-D0-9]\)\s*)/i', '', sanitize_text_field($opt)));
                }, $q['options'] ?? array());

                $correct_index = absint($q['correct'] ?? 0);
                $correct_text = isset($options[$correct_index]) ? $options[$correct_index] : '';

                if (!empty($correct_text)) {
                    shuffle($options);
                    $new_correct_index = array_search($correct_text, $options);
                    if ($new_correct_index === false) {
                        $new_correct_index = mt_rand(0, 3);
                        $options[$new_correct_index] = $correct_text;
                    }
                } else {
                    $new_correct_index = 0;
                }

                // @NEW 2026-08-11: Preserve difficulty/explanation through the batch path
                //       (same normalization as the single-topic path).
                $difficulty = isset($q['difficulty']) ? sanitize_text_field($q['difficulty']) : '';
                $difficulty = in_array(strtolower($difficulty), array('easy', 'medium', 'hard'), true) ? ucfirst(strtolower($difficulty)) : '';

                return array(
                    'id' => 'topic_' . sanitize_title($topic_name) . '_' . $i,
                    'question' => sanitize_text_field($q['question'] ?? ''),
                    'options' => $options,
                    'correct' => $new_correct_index,
                    'difficulty' => $difficulty,
                    'explanation' => isset($q['explanation']) ? sanitize_text_field($q['explanation']) : '',
                    'background' => 'gradient',
                );
            }, $questions, array_keys($questions));

            $final_map[$topic_name] = array(
                'questions' => $formatted,
                'hashtags'  => $hashtags,
                'hook'      => $hook,
            );
        }

        // @NEW 2026-04-22: Partial retry — find topics that got no results and retry them individually
        $found_topic_keys = array();
        foreach (array_keys($final_map) as $key) {
            $found_topic_keys[strtolower(trim($key, " \t\n\r\0\x0B.?!"))] = true;
        }

        $missing_topics = array();
        foreach ($topics as $t) {
            $lookup = strtolower(trim($t, " \t\n\r\0\x0B.?!"));
            if (!isset($found_topic_keys[$lookup])) {
                $missing_topics[] = $t;
            }
        }

        if (!empty($missing_topics) && count($missing_topics) <= 5) {
            VS_Error_Logger::get_instance()->log('Partial retry: ' . count($missing_topics) . ' topics missing from AI response, retrying individually.', 'info', array('missing' => $missing_topics));

            foreach ($missing_topics as $missing_topic) {
                $retry_result = $this->generate_topic_quiz_data($missing_topic, $count_per_topic);
                if (!is_wp_error($retry_result) && is_array($retry_result)) {
                    // @NEW 2026-08-01: Keep the return shape consistent. This retry path
                    //       has no per-topic hashtags/hook metadata, so default them to empty
                    //       and let the Buffer caption fall back to a clean omit.
                    $final_map[$missing_topic] = array(
                        'questions' => $retry_result,
                        'hashtags'  => '',
                        'hook'      => '',
                    );
                }
            }
        } elseif (!empty($missing_topics)) {
            VS_Error_Logger::get_instance()->log(count($missing_topics) . ' topics missing from AI response (too many for individual retry).', 'warning', array('missing' => $missing_topics));
        }

        return $final_map;
    }

    public function generate_topic_quiz_data($topic, $count = 5, $context = 'auto')
    {
        if (empty($topic)) {
            return new WP_Error('invalid_topic', 'Topic is required.');
        }

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if (!$registry) {
            $active_provider = 'gemini';
            $is_custom = false;
            $api_key = get_option('mcqvs_gemini_api_key', '');
            if (empty($api_key)) {
                $api_key = get_option('nm_gemini_api_key', '');
            }
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
        } else {
            $rotation = $registry->get_next_model($context);
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $is_custom = $registry->is_custom($active_provider);
            $api_key = $registry->get_rotation_api_key($active_provider);
        }

        if (empty($api_key)) {
            return new WP_Error('missing_api_key', 'AI API Key not configured.');
        }

        $prompt = "You are a professional exam quiz creator for competitive exams (CSS/PMS/NTS/FPSC/PPSC/UPSC/SSC/General Knowledge). Create a {$count}-question multiple-choice quiz about \"{$topic}\".\n\n"
            . "STRICT REQUIREMENTS:\n"
            . "1. Questions must be highly engaging, relevant, and accurate.\n"
            . "2. Questions and Options must be CONCISE, SHORT, and easy to understand within 10 seconds.\n"
            . "3. MAX 12 words per question.\n"
            . "4. Options must be short (1-5 words), ALL four must be PLAUSIBLE and clearly distinguishable — wrong options must look like real answers, never silly or obviously wrong.\n"
            . "5. Include the correct answer as an index (0-3).\n"
            . "6. Focus on Timeless General Knowledge, Facts, and Concepts (Avoid transient news unless historically significant).\n"
            . "7. FACT ACCURACY: only use well-established, verifiable facts. Never invent statistics, dates, or people.\n"
            . "8. Include at least ONE genuinely surprising 'wow' fact.\n"
            . "9. Order the questions EASY -> MEDIUM -> HARD (viewer wins early, stays for the challenge).\n"
            . "10. For each question provide a short one-line explanation (max 12 words) a viewer learns from after the reveal.\n\n"
            . "CRITICAL: You MUST return a JSON ARRAY of objects, NOT a single object. Begin with [ and end with ].\n"
            . "Response format (JSON array only, no markdown):\n"
            . '[{"question": "What is...?", "options": ["Option A", "Option B", "Option C", "Option D"], "correct": 0, "explanation": "Short reason", "difficulty": "Medium"}]';

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;

        // @MODIFIED 2026-02-19: Enable Strict JSON Mode (Reuse proven Studio logic)
        $response_schema = array(
            'type' => 'ARRAY',
            'items' => array(
                'type' => 'OBJECT',
                'properties' => array(
                    'question' => array('type' => 'STRING'),
                    'options' => array(
                        'type' => 'ARRAY',
                        'items' => array('type' => 'STRING')
                    ),
                    'correct' => array('type' => 'INTEGER'),
                    'explanation' => array('type' => 'STRING'),
                    'difficulty' => array('type' => 'STRING')
                ),
                'required' => array('question', 'options', 'correct')
            )
        );

        $max_retries = 5;
        $attempt = 0;
        $delay = 1;
        $last_error = null;
        $questions = null;
        $rotation_retries = 0;
        $max_rotation_retries = 3;
        $current_provider = $active_provider;
        $current_model = $model;
        $current_api_key = $api_key;
        $current_is_custom = $is_custom;

        $last_attempt_key = '';
        while ($attempt <= $max_retries) {
            // @FIX 1.5.1 (NO WAIT ON FAILOVER): only backoff when retrying the SAME
            // model. When a model fails, record_failure() puts ONLY that model in cooldown
            // and get_next_model() returns a fresh model/provider — so we must NOT sleep
            // before trying the next model. We simply move on immediately; the throttled
            // model is skipped until its cooldown expires.
            $attempt_key = $current_provider . '::' . $current_model;
            if ($attempt > 0 && $attempt_key === $last_attempt_key) {
                sleep($delay);
                $delay *= 2;
            }
            $last_attempt_key = $attempt_key;
            $attempt++;

            if (class_exists('VS_Provider_Registry')) {
                $url = VS_Provider_Registry::get_instance()->build_rotation_url($current_provider, $current_model);
            } else {
                $url = "https://generativelanguage.googleapis.com/v1beta/models/{$current_model}:generateContent?key=" . $current_api_key;
            }

            if (class_exists('VS_Provider_Registry')) {
                $request_body = VS_Provider_Registry::get_instance()->build_request_body(
                    $current_provider,
                    array(array('role' => 'user', 'content' => $prompt)),
                    $current_model,
                    array(
                        'response_schema' => $response_schema,
                        'json_mode' => true
                    )
                );
            } else {
                $request_body = array(
                    'contents' => array(array('parts' => array(array('text' => $prompt)))),
                    'generationConfig' => array(
                        'response_mime_type' => 'application/json',
                        'response_schema' => $response_schema
                    )
                );
            }

            $post_args = array(
                'body'    => wp_json_encode($request_body),
                'timeout' => 180,
            );
            if (class_exists('VS_Provider_Registry')) {
                $post_args['headers'] = VS_Provider_Registry::get_instance()->build_rotation_headers($current_provider, $url);
            } else {
                $post_args['headers'] = array('Content-Type' => 'application/json');
            }

            $start_time = microtime(true);
            $response = wp_remote_post($url, $post_args);
            $duration = microtime(true) - $start_time;

            VS_Error_Logger::get_instance()->log_api(
                $url,
                'POST',
                array('prompt' => $prompt, 'type' => 'topic_quiz', 'attempt' => $attempt, 'provider' => $current_provider, 'model' => $current_model),
                $response,
                $duration,
                $current_provider
            );

            if (is_wp_error($response)) {
                $last_error = $response->get_error_message();
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, 'http_error');
                    $next = VS_Provider_Registry::get_instance()->get_next_model('topic_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("Topic quiz retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (http_error)", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            if ($http_code === 429 || $http_code === 503) {
                $last_error = "HTTP {$http_code} from {$current_provider}/{$current_model}";
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, (string) $http_code);
                    $next = VS_Provider_Registry::get_instance()->get_next_model('topic_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("Topic quiz retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (HTTP {$http_code})", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }
            if ($http_code === 400) {
                $raw_body_err = wp_remote_retrieve_body($response);
                $body_err = json_decode($raw_body_err, true);
                $last_error = $body_err['error']['message'] ?? $body_err['message'] ?? "API HTTP Error: {$http_code}";
                continue;
            }

            $raw_body_str = wp_remote_retrieve_body($response);
            $body = json_decode($raw_body_str, true);

            $raw_text = '';
            if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
                $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
            } elseif (isset($body['choices'][0]['message']['content'])) {
                $raw_text = $body['choices'][0]['message']['content'];
            }

            if (empty($raw_text)) {
                $last_error = 'Empty response from API';
                continue;
            }

            $questions = $this->parse_ai_json_response($raw_text);

            if (! is_array($questions) || empty($questions)) {
                $last_error = 'Failed to parse AI response';
                continue;
            }

            $min_expected = max(3, (int) ceil($count * 0.6));
            if (count($questions) < $min_expected) {
                $last_error = "AI returned " . count($questions) . " questions, expected at least {$min_expected}";
                continue;
            }

            $last_error = null;
            if (class_exists('VS_Provider_Registry')) {
                VS_Provider_Registry::get_instance()->record_success($current_provider, $current_model);
            }
            break;
        }

        if ($questions === null || $last_error) {
            return new WP_Error('generation_failed', $last_error ?? 'Unknown error');
        }

        // Format & Randomize
        $formatted = array_map(function ($q, $i) {
            $options = array_map(function ($opt) {
                return trim(preg_replace('/^(Option\s+|[A-D0-9][\.\)\:\-\s]+|\([A-D0-9]\)\s*)/i', '', sanitize_text_field($opt)));
            }, $q['options'] ?? array());

            $correct_index = absint($q['correct'] ?? 0);
            $correct_text = isset($options[$correct_index]) ? $options[$correct_index] : '';

            // Robust Shuffling:
            // 1. If we have a valid correct answer text, shuffle and find new position.
            if (!empty($correct_text)) {
                shuffle($options);
                $new_correct_index = array_search($correct_text, $options);

                // Fallback: This should mathematically never happen with array_search on the same set, 
                // but if type juggling occurs or string encoding weirdness:
                if ($new_correct_index === false) {
                    // Force the correct answer into a random slot to save the question
                    $new_correct_index = mt_rand(0, 3);
                    $options[$new_correct_index] = $correct_text;
                }
            } else {
                // Fallback: Logic failed or index was OOB initially. 
                // Just force correct index to 0 or random, but marking as '0' is safest if data is bad.
                $new_correct_index = 0;
            }

            // @NEW 2026-08-11: Preserve AI explanation + difficulty through the pipeline.
            //       explanation is a 1-line learning hook (used by future reveal overlays /
            //       site sync); difficulty tags the question (Easy/Medium/Hard) for badges
            //       and ordering. Both are optional — legacy responses omit them safely.
            $difficulty = isset($q['difficulty']) ? sanitize_text_field($q['difficulty']) : '';
            $difficulty = in_array(strtolower($difficulty), array('easy', 'medium', 'hard'), true) ? ucfirst(strtolower($difficulty)) : '';

            return array(
                'id'          => 'topic_' . $i,
                'question'    => sanitize_text_field($q['question'] ?? ''),
                'options'     => $options,
                'correct'     => $new_correct_index,
                'explanation' => isset($q['explanation']) ? sanitize_text_field($q['explanation']) : '',
                'difficulty'  => $difficulty,
                'background'  => 'gradient',
            );
        }, $questions, array_keys($questions));

        return $formatted;
    }

    public function ajax_generate_topic_quiz()
    {
        error_log('MCQVS DEBUG: VS_AJAX_AI_Quiz_Handler::ajax_generate_topic_quiz called');
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        $topic = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';

        $count = isset($_POST['count']) ? absint($_POST['count']) : 5;
        $count = max(3, min(30, $count));

        if (empty($topic)) {
            wp_send_json_error(__('Please provide a topic.', 'mcq-video-studio'));
        }

        // @MODIFIED 2026-02-08: Use new public method
        $formatted = $this->generate_topic_quiz_data($topic, $count);

        if (is_wp_error($formatted)) {
            wp_send_json_error(array(
                'message' => $formatted->get_error_message()
            ));
        }

        // @NEW 2026-06-27: Persist generated questions to dedicated MCQ bank (topic path)
        $saved_count = 0;
        $skipped_duplicates = 0;
        if (class_exists('VS_MCQ_Repository') && !empty($formatted)) {
            $repo = VS_MCQ_Repository::get_instance();
            $topic_id = $repo->create_topic($topic, 'topic', 0);
            if (!empty($topic_id)) {
                foreach ($formatted as $fq) {
                    if (empty($fq['question'])) {
                        continue;
                    }
                    $opts = isset($fq['options']) && is_array($fq['options']) ? $fq['options'] : array('', '', '', '');
                    $result = $repo->insert_mcq(array(
                        'question_text' => (string) $fq['question'],
                        'options'       => $opts,
                        'correct_index' => isset($fq['correct']) ? (int) $fq['correct'] : 0,
                        'topic_id'      => (int) $topic_id,
                        'status'        => 'approved',
                        'source_ref'    => 'topic',
                        'difficulty'    => 'medium',
                    ));
                    if (is_wp_error($result)) {
                        if ($result->get_error_code() === 'duplicate_mcq') {
                            $skipped_duplicates++;
                        }
                        // silently swallow other wpdb errors
                    } else {
                        $saved_count++;
                    }
                }
            }
        }

        // @NEW 2026-08-11: Question-aware hook + hashtags for the Studio Topic Card.
        //       Runs AFTER questions exist so the hook references the actual content.
        //       Fails soft (empty strings) — never blocks question generation.
        $topic_hook_meta = $this->generate_topic_hook_and_hashtags($topic, $formatted);

        wp_send_json_success(array(
            'questions'          => $formatted,
            'hook'               => $topic_hook_meta['hook'],
            'hashtags'           => $topic_hook_meta['hashtags'],
            'source'             => 'Topic AI',
            'topic'              => $topic,
            'count'              => count($formatted),
            'saved_to_bank'      => $saved_count,
            'duplicates_skipped' => $skipped_duplicates,
        ));
    }


    /**
     * AJAX Handler for AI News-Based Quiz Generation
     */
    public function ajax_generate_news_quiz()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        $topic = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';
        $count = isset($_POST['count']) ? absint($_POST['count']) : 5;
        $count = max(3, min(10, $count));

        if (empty($topic)) {
            wp_send_json_error(__('Please provide a topic to search news for.', 'mcq-video-studio'));
        }

        if (strlen($topic) > 200) {
            wp_send_json_error(__('Topic is too long. Please use a shorter search term.', 'mcq-video-studio'));
        }

        $articles = array();
        if (class_exists('MCQVS_Advanced_News_Sources')) {
            $articles = MCQVS_Advanced_News_Sources::fetch_via_google_news($topic, 10);
        } else {
            $rss_url = 'https://news.google.com/rss/search?q=' . urlencode($topic) . '&hl=en&gl=US&ceid=US:en';
            $rss = fetch_feed($rss_url);

            if (! is_wp_error($rss)) {
                $items = $rss->get_items(0, 10);
                foreach ($items as $item) {
                    $articles[] = array(
                        'title'       => $item->get_title(),
                        'description' => wp_strip_all_tags($item->get_description()),
                    );
                }
            }
        }

        if (empty($articles)) {
            wp_send_json_error(__('No recent news found for this topic. Try a different search term.', 'mcq-video-studio'));
        }

        $headlines_context = implode("\n", array_map(function ($a) {
            return '- ' . $a['title'];
        }, array_slice($articles, 0, 5)));

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('news_quiz');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = get_option('mcqvs_gemini_api_key', '');
            if (empty($api_key)) {
                $api_key = get_option('nm_gemini_api_key', '');
            }
        }

        if (empty($api_key)) {
            wp_send_json_error(__('AI API Key not configured in plugin settings.', 'mcq-video-studio'));
        }

        $prompt = "You are a professional quiz creator specializing in current affairs and General Knowledge, and a viral-shorts copywriter. Create a {$count}-question multiple-choice quiz based on recent news headlines about \"{$topic}\".\n\n"
            . "Recent Headlines:\n{$headlines_context}\n\n"
            // @MODIFIED 2026-01-17: Strict Rules for GK/Quality
            . "STRICT Rules:\n"
            . "1. Do NOT ask about the news source, publisher (e.g., 'Who reported this?'), or specific dates (e.g., 'In which month?').\n"
            . "2. Focus on the CORE EVENT, geopolitical context, or historical significance triggering these headlines.\n"
            . "3. If the user asks for 'GK' or 'Important' questions, prioritize facts that will remain relevant (timeless facts) over transient news details.\n"
            . "4. Options must be plausible but clearly distinguishable — wrong options must look like real answers, never silly.\n"
            . "5. Questions must be under 15 words and competitive exam standard (CSS/PMS/NTS/FPSC/PPSC/UPSC/SSC).\n"
            . "6. FACT ACCURACY: only use facts verifiable from the headlines or well-established background. Never invent figures, names, or dates.\n"
            . "7. Order questions EASY -> MEDIUM -> HARD and include at least one surprising 'wow' fact.\n"
            . "8. Provide exactly 3-5 highly relevant social-media hashtags (single words, lowercase, comma or space separated, WITHOUT the # prefix).\n"
            . "9. Provide ONE short viral hook line (max 8 words) starting with a relevant emoji, derived from the most surprising question or headline (e.g. \"🇵🇰 Pakistan exports hit a record — by how much?\"). Must be a question or bold claim that creates a curiosity gap without spoiling the answer, NOT a generic phrase.\n\n"
            . "Response format (single JSON object, no markdown):\n"
            . '{"hook": "🇵🇰 ...", "hashtags": "pakistan,exports,economy", "questions": [{"question": "What is...?", "options": ["Option A", "Option B", "Option C", "Option D"], "correct": 0, "difficulty": "Medium", "explanation": "Short reason"}]}';

        $response_schema = array(
            'type' => 'OBJECT',
            'properties' => array(
                'hook' => array('type' => 'STRING'),
                'hashtags' => array('type' => 'STRING'),
                'questions' => array(
                    'type' => 'ARRAY',
                    'items' => array(
                        'type' => 'OBJECT',
                        'properties' => array(
                            'question' => array('type' => 'STRING'),
                            'options' => array(
                                'type' => 'ARRAY',
                                'items' => array('type' => 'STRING')
                            ),
                            'correct' => array('type' => 'INTEGER'),
                            'difficulty' => array('type' => 'STRING'),
                            'explanation' => array('type' => 'STRING')
                        ),
                        'required' => array('question', 'options', 'correct')
                    )
                )
            ),
            'required' => array('hook', 'hashtags', 'questions')
        );

        $max_retries = 2;
        $attempt = 0;
        $delay = 1;
        $last_error = null;
        $rotation_retries = 0;
        $max_rotation_retries = 3;
        $current_provider = $active_provider;
        $current_model = $model;
        $current_api_key = $api_key;
        $http_code = 0;

        $last_attempt_key = '';
        while ($attempt <= $max_retries) {
            // @FIX 1.5.1 (NO WAIT ON FAILOVER): only backoff when retrying the SAME
            // model. When a model fails, record_failure() puts ONLY that model in cooldown
            // and get_next_model() returns a fresh model/provider — so we must NOT sleep
            // before trying the next model. We simply move on immediately; the throttled
            // model is skipped until its cooldown expires.
            $attempt_key = $current_provider . '::' . $current_model;
            if ($attempt > 0 && $attempt_key === $last_attempt_key) {
                sleep($delay);
                $delay *= 2;
            }
            $last_attempt_key = $attempt_key;
            $attempt++;

            $url = $registry ? $registry->build_rotation_url($current_provider, $current_model) : "https://generativelanguage.googleapis.com/v1beta/models/{$current_model}:generateContent?key=" . $current_api_key;
            $post_args['headers'] = $registry ? $registry->build_rotation_headers($current_provider, $url) : array('Content-Type' => 'application/json');

            if (class_exists('VS_Provider_Registry')) {
                $request_body = VS_Provider_Registry::get_instance()->build_request_body(
                    $current_provider,
                    array(array('role' => 'user', 'content' => $prompt)),
                    $current_model,
                    array(
                        'response_schema' => $response_schema,
                        'json_mode' => true
                    )
                );
            } else {
                $request_body = array(
                    'contents' => array(array('parts' => array(array('text' => $prompt)))),
                    'generationConfig' => array(
                        'response_mime_type' => 'application/json',
                        'response_schema' => $response_schema,
                    ),
                );
            }
            $post_args['body'] = wp_json_encode($request_body);

            $start_time = microtime(true);
            $response = wp_remote_post($url, $post_args);
            $duration = microtime(true) - $start_time;

            VS_Error_Logger::get_instance()->log_api(
                $url,
                'POST',
                array('prompt' => $prompt, 'provider' => $current_provider, 'model' => $current_model, 'attempt' => $attempt),
                $response,
                $duration,
                $current_provider
            );

            if (is_wp_error($response)) {
                $last_error = $response->get_error_message();
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, 'http_error');
                    $next = VS_Provider_Registry::get_instance()->get_next_model('news_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("News quiz retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (http_error)", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }

            $http_code = wp_remote_retrieve_response_code($response);
            if ($http_code === 429 || $http_code === 503) {
                $last_error = "HTTP {$http_code} from {$current_provider}/{$current_model}";
                if ($rotation_retries < $max_rotation_retries && class_exists('VS_Provider_Registry')) {
                    VS_Provider_Registry::get_instance()->record_failure($current_provider, $current_model, (string) $http_code);
                    $next = VS_Provider_Registry::get_instance()->get_next_model('news_quiz');
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log("News quiz retry: rotating from {$current_provider}/{$current_model} to {$next['provider']}/{$next['model']} (HTTP {$http_code})", 'warning');
                    }
                    $current_provider = $next['provider'];
                    $current_model = $next['model'];
                    $current_api_key = VS_Provider_Registry::get_instance()->get_rotation_api_key($current_provider);
                    $rotation_retries++;
                }
                continue;
            }
            if ($http_code >= 400) {
                $raw_body_err = wp_remote_retrieve_body($response);
                $body_err = json_decode($raw_body_err, true);
                $last_error = $body_err['error']['message'] ?? $body_err['message'] ?? "API HTTP Error: {$http_code}";
                continue;
            }
            break;
        }

        if (is_wp_error($response) || $http_code >= 400) {
            if (class_exists('MCQVS_Generation_Logger')) {
                MCQVS_Generation_Logger::MCQVS_log_activity(
                    'News quiz generation API failed',
                    'error',
                    array(
                        'source_type' => 'video_studio',
                        'error_code'  => 'api_request_failed',
                        'topic'       => $topic,
                        'message'     => $last_error,
                    )
                );
            }
            VS_Error_Logger::get_instance()->log(
                'News quiz generation API failed',
                'error',
                array('message' => $last_error, 'topic' => $topic)
            );
            wp_send_json_error(__('API Error: ', 'mcq-video-studio') . $last_error);
        }

        if (class_exists('VS_Provider_Registry')) {
            VS_Provider_Registry::get_instance()->record_success($current_provider, $current_model);
        }

        $raw_body_str = wp_remote_retrieve_body($response);
        $body = json_decode($raw_body_str, true);

        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }

        if (empty($raw_text)) {
            $raw_text = "Extraction Failed. Full Body:\n" . substr($raw_body_str, 0, 2000);
        }

        // @MODIFIED 2026-01-09: Robust JSON Parsing
        // @NEW 2026-08-11: The news response is now an object {hook, hashtags, questions}.
        //       Unwrap it (also tolerate older array-of-questions responses) so the rest
        //       of the pipeline is unchanged.
        $parsed_news = $this->parse_ai_json_response($raw_text);
        $news_hook      = '';
        $news_hashtags  = '';
        if (is_array($parsed_news)) {
            if (isset($parsed_news['questions']) && is_array($parsed_news['questions']) && !isset($parsed_news[0])) {
                $news_hook     = $parsed_news['hook'] ?? '';
                $news_hashtags = $parsed_news['hashtags'] ?? '';
                $parsed_news   = $parsed_news['questions'];
            } elseif (isset($parsed_news[0]) && is_array($parsed_news[0]) && isset($parsed_news[0]['questions']) && is_array($parsed_news[0]['questions'])) {
                $news_hook     = $parsed_news[0]['hook'] ?? '';
                $news_hashtags = $parsed_news[0]['hashtags'] ?? '';
                $parsed_news   = $parsed_news[0]['questions'];
            }
        }
        $questions = $parsed_news;

        if (! is_array($questions) || empty($questions)) {
            if (class_exists('MCQVS_Generation_Logger')) {
                MCQVS_Generation_Logger::MCQVS_log_activity(
                    'Failed to parse news quiz AI response',
                    'error',
                    array(
                        'source_type'  => 'video_studio',
                        'error_code'   => 'parse_failed',
                        'topic'        => $topic,
                        'raw_response' => substr($raw_text, 0, 300),
                    )
                );
            }
            wp_send_json_error(array(
                'message'      => __('Failed to parse AI response. Please try again.', 'mcq-video-studio'),
                'raw_response' => $raw_text,
                'debug_prompt' => $prompt // @NEW: Send prompt for debugging
            ));
        }

        // Validate structure (must be list of arrays)
        if (array_keys($questions) !== range(0, count($questions) - 1)) {
            wp_send_json_error(array(
                'message'      => __('AI returned an invalid format (not a list).', 'mcq-video-studio'),
                'raw_response' => $raw_text,
                'debug_prompt' => $prompt
            ));
        }

        $formatted = array_map(function ($q, $i) {
            $options = array_map(function ($opt) {
                // Remove prefixes like "A.", "Option B", "1)", "(a)"
                return trim(preg_replace('/^(Option\s+|[A-D0-9][\.\)\:\-\s]+|\([A-D0-9]\)\s*)/i', '', sanitize_text_field($opt)));
            }, $q['options'] ?? array());

            $correct_index = absint($q['correct'] ?? 0);
            $correct_text = isset($options[$correct_index]) ? $options[$correct_index] : '';

            // Robust Shuffling (Same logic as Topic Quiz)
            if (!empty($correct_text)) {
                shuffle($options);
                $new_correct_index = array_search($correct_text, $options);

                if ($new_correct_index === false) {
                    // Fallback: Force correct answer into random slot
                    $new_correct_index = mt_rand(0, 3);
                    $options[$new_correct_index] = $correct_text;
                }
            } else {
                $new_correct_index = 0;
            }

            // @NEW 2026-08-11: Preserve difficulty/explanation through the news path.
            $difficulty = isset($q['difficulty']) ? sanitize_text_field($q['difficulty']) : '';
            $difficulty = in_array(strtolower($difficulty), array('easy', 'medium', 'hard'), true) ? ucfirst(strtolower($difficulty)) : '';

            return array(
                'id'          => 'news_' . $i,
                'question'    => sanitize_text_field($q['question'] ?? ''),
                'options'     => $options,
                'correct'     => $new_correct_index,
                'difficulty'  => $difficulty,
                'explanation' => isset($q['explanation']) ? sanitize_text_field($q['explanation']) : '',
                'background'  => 'gradient',
            );
        }, $questions, array_keys($questions));

        // ... logger ...

        // @NEW 2026-06-27: Persist generated questions to dedicated MCQ bank
        // Previously questions lived only in JS state and disappeared on page refresh.
        $saved_count = 0;
        $skipped_duplicates = 0;
        if (class_exists('VS_MCQ_Repository') && !empty($formatted)) {
            $repo = VS_MCQ_Repository::get_instance();
            // Resolve/create topic so question is bound to a navigable bank entry
            $topic_id = $repo->create_topic($topic, 'news', 0);
            if (!empty($topic_id)) {
                foreach ($formatted as $fq) {
                    if (empty($fq['question'])) {
                        continue;
                    }
                    $opts = isset($fq['options']) && is_array($fq['options']) ? $fq['options'] : array('', '', '', '');
                    $result = $repo->insert_mcq(array(
                        'question_text' => (string) $fq['question'],
                        'options'       => $opts,
                        'correct_index' => isset($fq['correct']) ? (int) $fq['correct'] : 0,
                        'topic_id'      => (int) $topic_id,
                        'status'        => 'approved',
                        'source_ref'    => 'news',
                        'difficulty'    => 'medium',
                    ));
                    if (is_wp_error($result)) {
                        if ($result->get_error_code() === 'duplicate_mcq') {
                            $skipped_duplicates++;
                        }
                        // silently swallow other wpdb errors to avoid breaking UX
                    } else {
                        $saved_count++;
                    }
                }
            }
        }

        // @NEW 2026-08-11: Normalize + surface the AI hook/hashtags so the Studio
        //       can auto-fill the hook text and caption hashtags (no generic fallback).
        $news_hook = self::normalize_hook($news_hook);
        $news_hashtags = self::normalize_hashtags($news_hashtags);

        wp_send_json_success(array(
            'questions'          => $formatted,
            'hook'               => $news_hook,
            'hashtags'           => $news_hashtags,
            'source'             => 'Google News',
            'topic'              => $topic,
            'count'              => count($formatted),
            'saved_to_bank'      => $saved_count,
            'duplicates_skipped' => $skipped_duplicates,
            'debug_prompt'       => $prompt,
            'raw_response'       => $raw_text,
        ));
    }

    /**
     * Helper: Robust JSON Parser for AI Responses
     * Handles markdown code blocks, extra text, and whitespace
     * 
     * @param string $raw_text
     * @return array|null
     */
    private function parse_ai_json_response($raw_text)
    {
        if (empty($raw_text)) {
            return null;
        }

        // 1. Try standard decode first
        $json = json_decode($raw_text, true);
        if ($json && is_array($json)) {
            // If it's a sequential array (list of questions), return as-is
            if (array_keys($json) === range(0, count($json) - 1)) {
                return $json;
            }
            // If it's a single object with question keys, wrap in array
            if (isset($json['question'], $json['options'], $json['correct'])) {
                return array($json);
            }
            return $json;
        }

        // 2. Extract JSON using bracket matching (for Arrays)
        if (preg_match('/\[.*\]/s', $raw_text, $matches)) {
            $json = json_decode($matches[0], true);
            if ($json && is_array($json)) {
                return $json;
            }
        }

        // 3. Fallback: Aggressive cleanup of markdown code blocks
        $clean_text = preg_replace('/```json\s*|\s*```/', '', $raw_text);
        $clean_text = trim($clean_text);

        $json = json_decode($clean_text, true);

        if ($json && is_array($json)) {
            // 4. Robust Unwrapping: Check common keys
            $possible_keys = array('questions', 'quiz', 'mcqs', 'results', 'data');
            foreach ($possible_keys as $key) {
                if (isset($json[$key]) && is_array($json[$key])) {
                    return $json[$key];
                }
            }

            // 5. Single-object unwrap: if decoded object has question keys, wrap it
            if (isset($json['question'], $json['options'], $json['correct'])) {
                return array($json);
            }

            // 6. Fallback: If it has exactly ONE key and that value is an array of arrays, take it.
            if (count($json) === 1) {
                $first_val = reset($json);
                if (is_array($first_val) && isset($first_val[0]) && is_array($first_val[0])) {
                    return $first_val;
                }
            }

            // Return original if no better structure found
            return $json;
        }

        return null;
    }

    /**
     * Normalize AI-generated hashtags into a clean, SMN-safe "#tag #tag" list.
     *
     * Accepts arrays, comma/semicolon/space separated strings, with or without the
     * leading "#", and strips markdown artifacts (bold/italic, backticks, bullets).
     * Hashtags are lowercased, deduped, and capped at 5.
     *
     * @param mixed $raw Hashtag value from the AI response.
     * @return string Space-separated hashtags, each prefixed with "#". Empty string when nothing valid.
     */
    public static function normalize_hashtags($raw)
    {
        if (is_array($raw)) {
            $raw = implode(' ', $raw);
        }
        $raw = (string) $raw;

        // Strip markdown bold/italic, backticks and stray leading list/bullet markers.
        $raw = str_replace(array('**', '`'), '', $raw);
        $raw = trim($raw);

        if ($raw === '') {
            return '';
        }

        // Split on any combination of whitespace, commas, semicolons or pipes.
        $parts = preg_split('/[\s,;|]+/', $raw);
        if (!is_array($parts)) {
            return '';
        }

        $seen = array();
        foreach ($parts as $part) {
            $tag = trim($part);
            // Strip leading # and any remaining non-alphanumeric/underscore characters.
            $tag = preg_replace('/^#+/', '', $tag);
            $tag = preg_replace('/[^A-Za-z0-9_]/', '', $tag);
            $tag = strtolower($tag);

            if ($tag === '' || strlen($tag) > 40) {
                continue;
            }
            $key = $tag;
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $clean[] = '#' . $tag;
        }

        if (empty($clean)) {
            return '';
        }

        return implode(' ', array_slice($clean, 0, 5));
    }

    /**
     * Normalize an AI-generated hook line into a single clean trimmed line.
     *
     * Strips markdown artifacts (**, backticks), leading list/bullet markers (-, *, #),
     * collapses internal whitespace, preserves emoji/unicode, and caps length at 120 chars.
     *
     * @param mixed $raw Hook value from the AI response.
     * @return string Normalized hook. Empty string when nothing valid.
     */
    public static function normalize_hook($raw)
    {
        $hook = is_array($raw) ? implode(' ', $raw) : (string) $raw;
        $hook = trim($hook);

        if ($hook === '') {
            return '';
        }

        // Strip markdown bold/italic and backticks.
        $hook = str_replace(array('**', '__', '`'), '', $hook);
        // Strip leading bullet/list markers (e.g. "- ", "* ", "# ", "1. ").
        $hook = preg_replace('/^\s*[\-\*#]\s+/', '', $hook);
        $hook = preg_replace('/^\s*\d+[\.\)]\s*/', '', $hook);
        // Collapse internal whitespace (keeps the emoji + single space separation).
        $hook = preg_replace('/\s+/', ' ', $hook);
        $hook = trim($hook);

        if ($hook === '') {
            return '';
        }

        // Cap length to avoid overly long captions.
        $hook = function_exists('mb_substr') ? mb_substr($hook, 0, 120) : substr($hook, 0, 120);
        $hook = trim($hook);
        // If a trailing separator was chopped, keep it clean.
        $hook = rtrim($hook, " \t\n\r\0\x0B-*#");

        return $hook;
    }

    /**
     * @NEW 2026-08-11: Generate a question-aware hook + hashtags for a single topic
     * after its questions have been generated (Studio Topic Card path). The model
     * sees the actual questions so the hook references the most surprising fact
     * instead of a generic phrase. One extra AI call — acceptable for a manual
     * Studio action, and skipped entirely for CSV imports (CSV supplies hook/hashtags).
     *
     * @param string $topic
     * @param array  $questions List of question arrays (question/options/correct).
     * @return array{hook:string, hashtags:string} Empty strings on any failure (never throws).
     */
    public function generate_topic_hook_and_hashtags($topic, $questions)
    {
        $out = array('hook' => '', 'hashtags' => '');

        if (empty($topic) || ! is_array($questions) || empty($questions)) {
            return $out;
        }

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;
        if ($registry) {
            $rotation = $registry->get_next_model('hooks');
            $provider = $rotation['provider'];
            $model    = $rotation['model'];
            $api_key  = $registry->get_rotation_api_key($provider);
        } else {
            $provider = 'gemini';
            $model    = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key  = get_option('mcqvs_gemini_api_key', '');
            if (empty($api_key)) $api_key = get_option('nm_gemini_api_key', '');
        }
        if (empty($api_key)) {
            return $out;
        }

        $q_context = '';
        foreach (array_slice($questions, 0, 8) as $i => $q) {
            $q_context .= ($i + 1) . '. ' . trim((string) ($q['question'] ?? '')) . "\n";
        }
        $q_context = trim($q_context);
        if ($q_context === '') {
            return $out;
        }

        $prompt = "You are a viral-shorts copywriter. Topic: \"{$topic}\".\n"
            . "These are the quiz questions in the video:\n{$q_context}\n\n"
            . "Write ONE viral hook line (max 8 words) that starts with a relevant emoji and is derived from the MOST surprising question or answer above (a question or bold claim creating a curiosity gap, never generic).\n"
            . "Also write 3-5 highly relevant hashtags (single words, lowercase, comma or space separated, WITHOUT the # prefix).\n"
            . "Return ONLY JSON: {\"hook\": \"...\", \"hashtags\": \"...\"}. No markdown, no asterisks.";

        $url = $registry
            ? $registry->build_rotation_url($provider, $model)
            : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;

        if ($registry) {
            $request_body = $registry->build_request_body(
                $provider,
                array(array('role' => 'user', 'content' => $prompt)),
                $model,
                array('json_mode' => true)
            );
            $headers = $registry->build_rotation_headers($provider, $url);
        } else {
            $request_body = array(
                'contents' => array(array('parts' => array(array('text' => $prompt)))),
                'generationConfig' => array('response_mime_type' => 'application/json'),
            );
            $headers = array('Content-Type' => 'application/json');
        }

        $response = wp_remote_post($url, array(
            'body'    => wp_json_encode($request_body),
            'headers' => $headers,
            'timeout' => 60,
        ));

        if (is_wp_error($response)) {
            return $out;
        }
        $http = wp_remote_retrieve_response_code($response);
        if ($http >= 400) {
            return $out;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }
        if ($raw_text === '') {
            return $out;
        }

        $parsed = $this->parse_ai_json_response($raw_text);
        if (! is_array($parsed)) {
            return $out;
        }
        // Tolerate {hook,hashtags} or [ {hook,hashtags} ].
        if (isset($parsed[0]) && is_array($parsed[0])) {
            $parsed = $parsed[0];
        }

        $out['hook']     = self::normalize_hook($parsed['hook'] ?? '');
        $out['hashtags'] = self::normalize_hashtags($parsed['hashtags'] ?? '');
        return $out;
    }
}
