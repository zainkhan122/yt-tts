<?php
/**
 * Plugin Name: WSX Software Cross-Campaign Dedup (24h, First-Arrival Wins)
 * Description: Blocks duplicate SOFTWARE posts across WP-Automatic campaigns within 24h.
 * FIRST ARRIVAL ALWAYS WINS (user decision 2026-08-30 — no site priority): whichever
 * campaign posts the software first keeps it; every later same-software post from any
 * campaign is trashed with its attachments (featured image + all sideloaded media)
 * PERMANENTLY deleted incl. files. Decisions are echoed into the WPA campaign log
 * (same request, inline live) + stored in option wsx_dedup_log.
 *
 * v1.4 (2026-08-31): DELETION SHIELD. User cannot enable WPA's "never post same link
 * again" (software posts keep updating), and WPA re-offers feed items — so a deleted
 * post used to come back the same day. Now every software title that passes through
 * here is remembered in option wsx_dedup_seen (normalized title => first-seen time,
 * 24h TTL). If the twin post was deleted, the recreation attempt is STILL killed.
 * Also: attachment sweeper — media WPA sideloads onto an already-killed post is
 * force-deleted (add_attachment hook), so no orphans survive.
 *
 * Version: 1.4
 * INSTALL: upload as wp-content/mu-plugins/wpa-software-dedup.php (upload the FILE,
 * do not copy-paste its text — pasting mangles regex backslashes).
 * NOTE: duplicates are fully created first (credits/images spent), then killed — this
 * hook point is after wp_insert_post. Measured dup rate ~6% of posts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WSX_DEDUP_HOURS', 24 );      // duplicate window (live-post scan)
define( 'WSX_DEDUP_SEEN_TTL', 24 );   // deletion-shield window: how long a DELETED post's title stays blocked. Want deleted = forever? Raise this (e.g. 8760).
define( 'WSX_DEDUP_SEEN_MAX', 500 );  // seen-map hard cap (auto-pruned by time anyway)

add_action( 'wp_insert_post', 'wsx_dedup_guard', 5, 3 );
function wsx_dedup_guard( $post_id, $post, $update ) {

	if ( $update || ! $post instanceof WP_Post ) {
		return;
	}
	if ( 'post' !== $post->post_type || in_array( $post->post_status, array( 'auto-draft', 'inherit', 'trash' ), true ) ) {
		return;
	}
	if ( get_post_meta( $post_id, '_wsx_dedup_done', true ) ) {
		return;
	}
	update_post_meta( $post_id, '_wsx_dedup_done', 1 ); // run once per post

	$title = $post->post_title;
	if ( ! wsx_dedup_is_software( $title ) ) {
		return; // non-release titles pass untouched
	}
	$name     = wsx_dedup_norm( $title );
	if ( '' === $name ) {
		return;
	}
	$my_site  = wsx_dedup_site_name( $post_id );

	// 1) live twin scan — gives us a real winner for the log (v1.3 behavior)
	$q = new WP_Query( array(
		'post_type'      => 'post',
		'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
		'posts_per_page' => 200,
		'date_query'     => array( array( 'after' => gmdate( 'Y-m-d H:i:s', time() - WSX_DEDUP_HOURS * HOUR_IN_SECONDS ) ) ),
		'fields'         => 'ids',
		'post__not_in'   => array( $post_id ),
	) );

	foreach ( $q->posts as $other_id ) {
		$other = get_post( $other_id );
		if ( ! $other || 'trash' === $other->post_status || ! wsx_dedup_is_software( $other->post_title ) ) {
			continue;
		}
		if ( wsx_dedup_norm( $other->post_title ) === $name ) {
			// FIRST ARRIVAL WINS: the existing post keeps it, this new post loses
			wsx_dedup_seen_mark( $name ); // shield covers this title even if the winner predates the plugin or is deleted later
			$other_site = wsx_dedup_site_name( $other_id );
			wsx_dedup_kill( $post_id, $title, $my_site, $other_id, $other->post_title, $other_site, $name, 'first arrival wins' );
			return;
		}
	}

	// 2) v1.4 deletion shield — no live twin, but the title was already posted inside
	// the shield window and the post has since been deleted: block the recreation.
	// (seen[$name] is stamped below, only for posts that SURVIVE — so a first-of-the-day
	// post can never block itself.)
	$first_seen = wsx_dedup_seen_at( $name );
	if ( $first_seen && ( time() - $first_seen ) < WSX_DEDUP_SEEN_TTL * HOUR_IN_SECONDS ) {
		wsx_dedup_kill( $post_id, $title, $my_site, 0, '(post deleted)', '—', $name, 'recreation after deletion blocked' );
		return;
	}

	// 3) survived = this is the first arrival of the day for this title: stamp it.
	wsx_dedup_seen_mark( $name );
}

/**
 * v1.4 seen-memory: normalized title => first-seen timestamp.
 * Prunes expired entries on every write so the option stays tiny.
 */
function wsx_dedup_seen_mark( $name ) {
	$seen = get_option( 'wsx_dedup_seen', array() );
	if ( ! is_array( $seen ) ) {
		$seen = array();
	}
	$now   = time();
	$dirty = false;
	foreach ( $seen as $k => $ts ) {
		if ( ! is_numeric( $ts ) || ( $now - (int) $ts ) >= WSX_DEDUP_SEEN_TTL * HOUR_IN_SECONDS ) {
			unset( $seen[ $k ] ); // expired shield
			$dirty = true;
		}
	}
	if ( ! isset( $seen[ $name ] ) ) {
		$seen[ $name ] = $now; // first arrival stamps it; never overwritten
		$dirty = true;
	}
	if ( count( $seen ) > WSX_DEDUP_SEEN_MAX ) {
		asort( $seen );
		$seen  = array_slice( $seen, -WSX_DEDUP_SEEN_MAX, null, true );
		$dirty = true;
	}
	if ( $dirty ) {
		update_option( 'wsx_dedup_seen', $seen, false );
	}
}

/** @return int|0 first-seen timestamp for a normalized title (0 = unknown). */
function wsx_dedup_seen_at( $name ) {
	$seen = get_option( 'wsx_dedup_seen', array() );
	return isset( $seen[ $name ] ) && is_numeric( $seen[ $name ] ) ? (int) $seen[ $name ] : 0;
}

/**
 * v1.4 attachment sweeper: WPA sideloads images AFTER wp_insert_post returns — by then
 * our kill has already trashed the post. Any attachment that lands on a post killed by
 * this plugin is force-deleted (file included) so nothing orphans in the Media Library.
 */
add_action( 'add_attachment', 'wsx_dedup_attachment_sweep', 10, 1 );
function wsx_dedup_attachment_sweep( $att_id ) {
	$parent = (int) get_post_field( 'post_parent', $att_id );
	if ( $parent < 1 ) {
		return; // standalone Media Library uploads are none of our business
	}
	$post = get_post( $parent );
	if ( ! $post || 'trash' !== $post->post_status || 'post' !== $post->post_type ) {
		return;
	}
	if ( ! get_post_meta( $parent, '_wsx_dedup_done', true ) || ! wsx_dedup_is_software( $post->post_title ) ) {
		return;
	}
	$name = wsx_dedup_norm( $post->post_title );
	if ( '' === $name || ! wsx_dedup_seen_at( $name ) ) {
		return;
	}
	if ( wp_delete_attachment( $att_id, true ) ) {
		$log   = get_option( 'wsx_dedup_log', array() );
		$log[] = array(
			'time'          => time(),
			'loser'         => $post->post_title,
			'loser_site'    => wsx_dedup_site_name( $parent ),
			'loser_id'      => $parent,
			'winner'        => '(sweep)',
			'winner_site'   => '—',
			'winner_id'     => 0,
			'name'          => $name,
			'why'           => 'attachment swept (landed on killed post)',
			'media_deleted' => 1,
		);
		update_option( 'wsx_dedup_log', array_slice( $log, -20 ), false );
	}
}

/** Trash the losing post + permanently delete its media (featured image + all attachments). */
function wsx_dedup_kill( $loser_id, $loser_title, $loser_site, $winner_id, $winner_title, $winner_site, $name, $why ) {

	$deleted_media = 0;

	// featured image attachment
	$thumb_id = (int) get_post_meta( $loser_id, '_thumbnail_id', true );
	if ( $thumb_id && get_post( $thumb_id ) ) {
		if ( wp_delete_attachment( $thumb_id, true ) ) {
			$deleted_media++;
		}
	}

	// all other attachments sideloaded onto this post
	$atts = get_posts( array(
		'post_type'      => 'attachment',
		'post_parent'    => $loser_id,
		'posts_per_page' => 100,
		'fields'         => 'ids',
		'post_status'    => 'any',
	) );
	foreach ( $atts as $att_id ) {
		if ( wp_delete_attachment( $att_id, true ) ) {
			$deleted_media++;
		}
	}
	delete_post_meta( $loser_id, '_thumbnail_id' ); // stale featured ref hygiene

	wp_trash_post( $loser_id );

	// live line in the WPA campaign log (echo happens inside the campaign request)
	if ( $winner_id ) {
		echo '<br>WSX-dedup: [' . esc_html( $loser_site ) . '] "' . esc_html( $loser_title ) . '" duplicate of [' . esc_html( $winner_site ) . '] "' . esc_html( $winner_title ) . '" (' . esc_html( $why ) . ') — post trashed, ' . (int) $deleted_media . ' media file(s) deleted.';
	} else {
		echo '<br>WSX-dedup: [' . esc_html( $loser_site ) . '] "' . esc_html( $loser_title ) . '" was already posted today and deleted — recreation blocked (' . esc_html( $why ) . ') — post trashed, ' . (int) $deleted_media . ' media file(s) deleted.';
	}

	$log     = get_option( 'wsx_dedup_log', array() );
	$log[]   = array(
		'time'         => time(),
		'loser'        => $loser_title,
		'loser_site'   => $loser_site,
		'loser_id'     => $loser_id,
		'winner'       => $winner_title,
		'winner_site'  => $winner_site,
		'winner_id'    => $winner_id,
		'name'         => $name,
		'why'          => $why,
		'media_deleted'=> $deleted_media,
	);
	$log     = array_slice( $log, -20 );
	update_option( 'wsx_dedup_log', $log, false );
}

function wsx_dedup_site_name( $post_id ) {
	$link  = (string) get_post_meta( $post_id, 'original_link', true );
	$hosts = array( 'kaldata.com', 'neowin.net', 'softexia.com' );
	foreach ( $hosts as $host ) {
		if ( false !== stripos( $link, $host ) ) {
			return strtok( $host, '.' ); // kaldata / neowin / softexia
		}
	}
	return 'manual';
}

function wsx_dedup_is_software( $title ) {
	return 1 === preg_match( '~[0-9]+[.][0-9]+~', $title ); // dotted version = release title
}

function wsx_dedup_norm( $title ) {
	$title = preg_replace( '~\s*[-–—]\s*Neowin\s*$~u', '', $title ); // site suffixes
	$title = preg_replace( '~\s*/\s*.*$~u', '', $title );           // "X 1.2 / 3.4 dual" cut
	$title = preg_replace( '~[0-9]+([.][0-9]+)+~u', ' ', $title );  // dotted versions
	$title = preg_replace( '~\bBuild[ ]+[0-9]+\b~ui', ' ', $title );// Build 3211
	$title = preg_replace( '~\b(final|portable|setup|beta|rc|stable|release)\b~ui', ' ', $title );
	$title = preg_replace( '~[^a-z0-9+# ]~ui', ' ', strtolower( $title ) );
	$title = preg_replace( '~\s+~', ' ', trim( $title ) );
	return trim( (string) preg_replace( '~\s*v$~', '', $title ) );
}
