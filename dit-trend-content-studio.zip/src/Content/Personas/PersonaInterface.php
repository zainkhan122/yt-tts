<?php

namespace DIT\TrendStudio\Content\Personas;

/**
 * Persona blueprint provider.
 *
 * Used to supply vertical-specific prompt blueprints without hard-coding
 * vertical conditionals throughout the prompt layer.
 *
 * @package DIT_TrendStudio\Content
 * @since 2.15.4
 */
interface PersonaInterface
{
    /**
     * Return the vertical key this persona handles (e.g. showbiz_pk).
     *
     * @return string
     */
    public function get_vertical(): string;

    /**
     * Return the persona blueprint override.
     *
     * @param string $global_restrictions Guardrails injected globally by AI_Style_Guard.
     * @return array
     */
    public function get_blueprint(string $global_restrictions): array;
}
