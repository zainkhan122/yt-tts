<?php

/**
 * Generator Form View - Auto-Update Mode Only
 * @MODIFIED 2025-12-04 v1.5.1: Removed Manual Mode completely
 *
 * @package SEO_Article_Generator
 */

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap seo-gen-wrap">
    <h1><?php esc_html_e('Generate SEO Article', 'seo-article-generator'); ?></h1>

    <div class="seo-gen-container">
        <div class="seo-gen-form-section">
            <form id="seo-gen-form" method="post">
                <!-- Hidden field to always send generation_mode=auto -->
                <input type="hidden" name="generation_mode" value="auto">
                <!-- @MODIFIED 2025-12-12 v1.8.3: For partial regen merge with existing posts -->
                <input type="hidden" name="existing_post_id" id="existing_post_id" value="<?php echo isset($_GET['post_id']) ? absint($_GET['post_id']) : 0; ?>">

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="article_context"><?php esc_html_e('Article Text or Software Name', 'seo-article-generator'); ?> *</label>
                        </th>
                        <td>
                            <textarea id="article_context" name="article_context" rows="20" class="large-text" required placeholder="Paste one of the following:

1. Your existing article to update (full HTML or plain text)
2. Just the software name (e.g., 'VLC Media Player')
3. A list of features or bullet points

The AI will:
- Extract software name and context
- Search the web for latest version, size, changelog
- Find official download links
- Generate/update complete SEO article"></textarea>
                            <p class="description">
                                <?php esc_html_e('The AI will automatically research the web for the latest specifications, download links, and changelog. No need to fill individual fields!', 'seo-article-generator'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Optional: Allow category override -->
                    <tr>
                        <th scope="row">
                            <label for="auto_category"><?php esc_html_e('Category (Optional)', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="auto_category" name="auto_category" class="regular-text" placeholder="e.g., Media Player, Browser (AI will auto-detect if empty)">
                            <p class="description"><?php esc_html_e('Leave empty to let AI detect the category automatically', 'seo-article-generator'); ?></p>
                        </td>
                    </tr>

                    <!-- @since 2.7.3 Update Existing Post selector -->
                    <tr class="seo-gen-update-post">
                        <th scope="row">
                            <label for="update_post_checkbox"><?php esc_html_e('Update Existing Post', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <label class="seo-gen-checkbox-label">
                                <input type="checkbox" id="update_post_checkbox" <?php checked(!empty($_GET['post_id'])); ?>>
                                <?php esc_html_e('Update an existing post instead of creating new draft', 'seo-article-generator'); ?>
                            </label>
                            <div id="post_search_container" style="margin-top: 10px; <?php echo empty($_GET['post_id']) ? 'display:none;' : ''; ?>">
                                <select id="existing_post_select" class="regular-text" style="width: 100%; max-width: 400px;">
                                    <?php if (!empty($_GET['post_id'])):
                                        $post_id = absint($_GET['post_id']);
                                        $post = get_post($post_id);
                                        if ($post): ?>
                                            <option value="<?php echo $post_id; ?>" selected><?php echo esc_html($post->post_title); ?> (ID: <?php echo $post_id; ?>)</option>
                                    <?php endif;
                                    endif; ?>
                                </select>
                                <p class="description"><?php esc_html_e('Search by post title or ID. The selected post will be updated with the generated content.', 'seo-article-generator'); ?></p>
                            </div>
                        </td>
                    </tr>

                    <!-- @MODIFIED 2025-12-04 v1.5.0: Partial Regeneration Options -->
                    <tr class="seo-gen-partial-regen">
                        <th scope="row">
                            <label><?php esc_html_e('Sections to Generate', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <fieldset>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="all" checked> <strong><?php esc_html_e('Full Article', 'seo-article-generator'); ?></strong></label>
                                <hr style="margin: 8px 0; border: 0; border-top: 1px solid #ddd;">
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="introduction"> <?php esc_html_e('Introduction', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="features"> <?php esc_html_e('Features List', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="tech_specs"> <?php esc_html_e('Tech Specs', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="download"> <?php esc_html_e('Download Links', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="pros_cons"> <?php esc_html_e('Pros and Cons', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="competitors"> <?php esc_html_e('Competitor Table', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="faqs"> <?php esc_html_e('FAQs', 'seo-article-generator'); ?></label>
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="installation"> <?php esc_html_e('Installation Guide', 'seo-article-generator'); ?></label>
                                <!-- @MODIFIED 2026-01-05: Added Moat Content toggle -->
                                <label class="seo-gen-checkbox-label"><input type="checkbox" name="regen_sections[]" value="moat"> <?php esc_html_e('Moat Content', 'seo-article-generator'); ?></label>
                            </fieldset>
                            <p class="description"><?php esc_html_e('Uncheck Full Article and select specific sections to regenerate only those parts.', 'seo-article-generator'); ?></p>
                        </td>
                    </tr>
                    <!-- @MODIFIED 2025-12-05 v1.5.2: Target platforms drive AI links + manual parsing -->
                    <tr class="seo-gen-platforms">
                        <th scope="row">
                            <label><?php esc_html_e('Target Platforms', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <fieldset>
                                <legend class="screen-reader-text">
                                    <span><?php esc_html_e('Target Platforms', 'seo-article-generator'); ?></span>
                                </legend>

                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_win11" value="1" checked>
                                    <?php esc_html_e('Windows 11', 'seo-article-generator'); ?>
                                </label>
                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_win10" value="1" checked>
                                    <?php esc_html_e('Windows 10', 'seo-article-generator'); ?>
                                </label>
                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_mac" value="1">
                                    <?php esc_html_e('macOS', 'seo-article-generator'); ?>
                                </label>
                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_linux" value="1">
                                    <?php esc_html_e('Linux', 'seo-article-generator'); ?>
                                </label>
                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_android" value="1">
                                    <?php esc_html_e('Android', 'seo-article-generator'); ?>
                                </label>
                                <label class="seo-gen-checkbox-label">
                                    <input type="checkbox" name="platform_ios" value="1">
                                    <?php esc_html_e('iOS', 'seo-article-generator'); ?>
                                </label>
                            </fieldset>

                            <p class="description">
                                <?php esc_html_e('These platforms control both AI-generated download buttons and how pasted manual URLs are grouped by platform.', 'seo-article-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    <!-- @MODIFIED 2025-12-15 v2.1.0: Software category for moat content strategy -->
                    <tr class="seo-gen-category">
                        <th scope="row">
                            <label for="software_category"><?php esc_html_e('Software Category', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <select id="software_category" name="software_category" class="regular-text">
                                <option value=""><?php esc_html_e('Auto-detect from homepage', 'seo-article-generator'); ?></option>
                                <optgroup label="<?php esc_attr_e('Complex (Settings Guides)', 'seo-article-generator'); ?>">
                                    <option value="video-editing"><?php esc_html_e('Video Editing', 'seo-article-generator'); ?></option>
                                    <option value="audio-production"><?php esc_html_e('Audio Production', 'seo-article-generator'); ?></option>
                                    <option value="3d-modeling"><?php esc_html_e('3D Modeling', 'seo-article-generator'); ?></option>
                                    <option value="streaming"><?php esc_html_e('Streaming/Broadcasting', 'seo-article-generator'); ?></option>
                                    <option value="graphic-design"><?php esc_html_e('Graphic Design', 'seo-article-generator'); ?></option>
                                    <option value="development"><?php esc_html_e('Development/IDE', 'seo-article-generator'); ?></option>
                                </optgroup>
                                <optgroup label="<?php esc_attr_e('Simple (Quick Start)', 'seo-article-generator'); ?>">
                                    <option value="compression"><?php esc_html_e('File Compression', 'seo-article-generator'); ?></option>
                                    <option value="text-editor"><?php esc_html_e('Text Editors', 'seo-article-generator'); ?></option>
                                    <option value="utility"><?php esc_html_e('System Utilities', 'seo-article-generator'); ?></option>
                                    <option value="security"><?php esc_html_e('Security/Antivirus', 'seo-article-generator'); ?></option>
                                    <option value="productivity"><?php esc_html_e('Productivity', 'seo-article-generator'); ?></option>
                                </optgroup>
                            </select>
                            <p class="description">
                                <?php esc_html_e('Complex software gets "Best Settings" guides. Simple utilities get "Quick Start" guides.', 'seo-article-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    <!-- @MODIFIED 2025-12-16 v2.1.4: Editor Rating for Hero Section -->
                    <tr class="seo-gen-rating">
                        <th scope="row">
                            <label for="editor_rating"><?php esc_html_e('Editor Rating', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <select id="editor_rating" name="editor_rating" class="regular-text">
                                <option value=""><?php esc_html_e('Default (4.5)', 'seo-article-generator'); ?></option>
                                <option value="5.0">★★★★★ 5.0</option>
                                <option value="4.5">★★★★½ 4.5</option>
                                <option value="4.0">★★★★☆ 4.0</option>
                                <option value="3.5">★★★½☆ 3.5</option>
                                <option value="3.0">★★★☆☆ 3.0</option>
                                <option value="2.5">★★½☆☆ 2.5</option>
                                <option value="2.0">★★☆☆☆ 2.0</option>
                            </select>
                            <p class="description">
                                <?php esc_html_e('Rating displayed in the App Store style hero section.', 'seo-article-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    <!-- @MODIFIED 2025-12-05 v1.5.2: Manual download URLs override AI links -->
                    <tr class="seo-gen-manual-downloads">
                        <th scope="row">
                            <label for="download_link"><?php esc_html_e('Manual Download URLs / HTML', 'seo-article-generator'); ?></label>
                        </th>
                        <td>
                            <textarea id="download_link"
                                name="download_link"
                                rows="6"
                                class="large-text"
                                placeholder="<?php echo esc_attr__(
                                                    'Optional. One URL or <a href> per line. If provided, these override AI-generated download links.',
                                                    'seo-article-generator'
                                                ); ?>"></textarea>

                            <p class="description">
                                <?php esc_html_e('Examples:', 'seo-article-generator'); ?><br>
                                <code>https://example.com/download/windows</code><br>
                                <code>&lt;a href="https://example.com/download/mac"&gt;Download for macOS&lt;/a&gt;</code>
                            </p>

                            <p class="description">
                                <?php esc_html_e('Each non-empty line becomes a download button. If you use plain URLs, the first selected platform is applied automatically.', 'seo-article-generator'); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary button-large" id="seo-gen-submit">
                        <?php esc_html_e('Generate Article', 'seo-article-generator'); ?>
                    </button>
                </p>
            </form>
        </div>

        <!-- Progress Section -->
        <div id="seo-gen-progress" class="seo-gen-progress" style="display: none;">
            <h2><?php esc_html_e('Generation Progress', 'seo-article-generator'); ?></h2>
            <div class="seo-gen-progress-bar">
                <div class="seo-gen-progress-fill"></div>
            </div>
            <p class="seo-gen-status-text"><?php esc_html_e('Initializing...', 'seo-article-generator'); ?></p>
        </div>

        <!-- Preview Section -->
        <div id="seo-gen-preview" class="seo-gen-preview" style="display: none;">
            <h2><?php esc_html_e('Article Preview', 'seo-article-generator'); ?></h2>

            <!-- Validation Results -->
            <div id="seo-gen-validation" class="seo-gen-validation"></div>

            <!-- Article Content -->
            <div id="seo-gen-content" class="seo-gen-content"></div>

            <div class="seo-gen-actions">
                <button type="button" class="button button-primary button-large" id="seo-gen-publish">
                    <?php esc_html_e('Save as Draft', 'seo-article-generator'); ?>
                </button>
                <button type="button" class="button button-secondary" id="seo-gen-copy-html">
                    <?php esc_html_e('Copy HTML', 'seo-article-generator'); ?>
                </button>
                <button type="button" class="button button-secondary" id="seo-gen-reset">
                    <?php esc_html_e('Generate New Article', 'seo-article-generator'); ?>
                </button>
            </div>

            <!-- @MODIFIED 2026-01-05: Debug Actions Section -->
            <div class="seo-gen-debug-actions" style="margin-top: 20px; padding-top: 15px; border-top: 1px dashed #ccc;">
                <h4 style="margin: 0 0 10px 0; color: #666; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">
                    <?php esc_html_e('Developer Debug Tools', 'seo-article-generator'); ?>
                </h4>
                <div class="seo-gen-button-group">
                    <button type="button" class="button button-small" id="seo-gen-view-request">
                        <span class="dashicons dashicons-cloud" style="font-size: 16px; margin-top: 4px;"></span>
                        <?php esc_html_e('Raw Request', 'seo-article-generator'); ?>
                    </button>
                    <button type="button" class="button button-small" id="seo-gen-view-response">
                        <span class="dashicons dashicons-rest-api" style="font-size: 16px; margin-top: 4px;"></span>
                        <?php esc_html_e('Raw Response', 'seo-article-generator'); ?>
                    </button>
                </div>
            </div>

            <!-- Debug Data Display (Hidden) -->
            <div id="seo-gen-debug-panel" class="seo-gen-debug-panel" style="display: none; margin-top: 20px;">
                <div class="debug-panel-header" style="display: flex; justify-content: space-between; align-items: center; background: #23282d; color: #fff; padding: 8px 12px; border-radius: 4px 4px 0 0;">
                    <span id="debug-panel-title"></span>
                    <button type="button" class="debug-copy-btn button button-small" style="background: #007cba; border-color: #007cba; color: #fff;">
                        <?php esc_html_e('Copy to Clipboard', 'seo-article-generator'); ?>
                    </button>
                </div>
                <pre id="debug-content" style="margin: 0; padding: 15px; background: #f6f7f7; border: 1px solid #ccd0d4; border-top: none; overflow: auto; max-height: 400px; font-family: monospace; font-size: 12px; line-height: 1.5; white-space: pre-wrap; word-break: break-all;"></pre>
            </div>
        </div>
    </div>
</div>
