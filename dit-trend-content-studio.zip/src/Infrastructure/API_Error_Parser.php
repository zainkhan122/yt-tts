<?php

/**
 * API Error Parser
 *
 * Structured, provider-aware error extraction from API responses.
 * Parses JSON error bodies and HTTP headers into a normalized result
 * that the rest of the system can consume without string-matching.
 *
 * Replaces all inline strpos/stripos quota-detection patterns.
 *
 * @package DIT_TrendStudio
 * @since 2026-04-22
 */

namespace DIT\TrendStudio\Infrastructure;

if (!defined('ABSPATH')) {
    exit;
}

class API_Error_Parser
{
    const RPD = 'rpd';
    const RPM = 'rpm';
    const TPM = 'tpm';
    const UNKNOWN = 'unknown';

    /**
     * Parse a 429/403/413 response into a structured error info array.
     *
 * @param string $provider Provider slug (gemini, groq, openrouter, custom)
     * @param int      $http_code HTTP status code
     * @param string   $raw_body  Raw response body
     * @param array    $headers   Response headers (from wp_remote_retrieve_headers)
     * @return array Normalized error info
     */
	public static function parse(string $provider, int $http_code, string $raw_body, array $headers = []): array
	{
		$method = 'parse_' . $provider;
		if (method_exists(self::class, $method)) {
			return self::$method($http_code, $raw_body, $headers);
		}

		if ($provider !== '' && $provider !== 'unknown') {
			return self::parse_custom($http_code, $raw_body, $headers, $provider);
		}

		return self::parse_generic($http_code, $raw_body, $headers);
	}

    public static function parse_gemini(int $http_code, string $raw_body, array $headers): array
    {
        $parsed = json_decode($raw_body, true);
        $error = $parsed['error'] ?? [];
        $details = (array) ($error['details'] ?? []);
        $lower = strtolower($raw_body);

        $info = self::base_info('gemini', $http_code, $raw_body);

        // @MODIFIED 2026-04-29 - Handle HTTP 503 Service Unavailable (high demand)
        if ($http_code === 503) {
            $info['error_type'] = 'service_unavailable';
            $info['quota_bucket'] = self::RPM;
            $info['error_status'] = (string) ($error['status'] ?? 'UNAVAILABLE');
            if (isset($error['message']) && stripos($error['message'], 'high demand') !== false) {
                $info['retry_delay'] = 5;
            }
            return $info;
        }

        foreach ($details as $detail) {
            $type = $detail['@type'] ?? '';

            if (stripos($type, 'RetryDelay') !== false && isset($detail['retryDelay'])) {
                $info['retry_delay'] = (int) $detail['retryDelay'];
            }

            if (stripos($type, 'QuotaFailure') !== false && !empty($detail['violations'])) {
                foreach ($detail['violations'] as $v) {
                    $metric = strtolower($v['quotaMetric'] ?? '');
                    $qid = strtolower($v['quotaId'] ?? '');
                    $info['quota_metric'] = $v['quotaMetric'] ?? '';
                    $info['quota_id'] = $v['quotaId'] ?? '';
                    $info['quota_bucket'] = self::classify_quota_bucket($qid, $metric);
                }
            }

            if (stripos($type, 'ErrorInfo') !== false) {
                $meta = $detail['metadata'] ?? [];
                $metric = strtolower($meta['quota_metric'] ?? $meta['service'] ?? '');
                $qid = strtolower($meta['quota_id'] ?? '');
                if ($metric || $qid) {
                    $info['quota_metric'] = $meta['quota_metric'] ?? $meta['service'] ?? '';
                    $info['quota_id'] = $meta['quota_id'] ?? '';
                    $info['quota_bucket'] = self::classify_quota_bucket($qid, $metric);
                }
            }
        }

        if ($info['retry_delay'] === 0 && isset($error['retryDelay'])) {
            $info['retry_delay'] = (int) $error['retryDelay'];
        }

        $info['error_status'] = (string) ($error['status'] ?? '');

        $info['is_quota_zero'] = (strpos($lower, 'limit: 0') !== false && $info['quota_bucket'] !== self::RPD);

        if ($info['quota_bucket'] === self::UNKNOWN && empty($info['quota_metric'])) {
            $info['quota_bucket'] = self::classify_by_body_heuristics($lower);
        }

        $info['error_type'] = self::derive_error_type($info);

        if ($info['quota_bucket'] === self::RPD && class_exists(__NAMESPACE__ . '\\Quota_Reset_Calculator')) {
            $info['reset_at'] = Quota_Reset_Calculator::gemini_next_rpd_reset_ts(time());
        }

        return $info;
    }

    public static function parse_groq(int $http_code, string $raw_body, array $headers): array
    {
        $info = self::base_info('groq', $http_code, $raw_body);
        $parsed = json_decode($raw_body, true);
        $error = $parsed['error'] ?? [];
        $lower = strtolower($raw_body);

        $info['error_status'] = (string) ($error['status'] ?? ($parsed['detail'] ?? ''));

        $retry_after = $headers['retry-after'] ?? '';
        if (is_numeric($retry_after)) {
            $info['retry_delay'] = (int) $retry_after;
        }

        if ($http_code === 413) {
            $info['error_type'] = 'tpm_exceeded';
            $info['quota_bucket'] = self::TPM;
        } elseif (strpos($lower, 'rate_limit') !== false || strpos($lower, 'too many requests') !== false) {
            $info['quota_bucket'] = self::RPM;
            $info['error_type'] = 'rpm_burst';
        } elseif (strpos($lower, 'daily') !== false || strpos($lower, 'per day') !== false) {
            $info['quota_bucket'] = self::RPD;
            $info['error_type'] = 'daily_quota';
        } else {
            $info['error_type'] = 'rpm_burst';
            $info['quota_bucket'] = self::RPM;
        }

        return $info;
    }

    public static function parse_perplexity(int $http_code, string $raw_body, array $headers): array
    {
        $info = self::base_info('perplexity', $http_code, $raw_body);
        $lower = strtolower($raw_body);
        $parsed = json_decode($raw_body, true);
        $detail = strtolower($parsed['detail'] ?? $parsed['error']['message'] ?? '');

        $retry_after = $headers['retry-after'] ?? '';
        if (is_numeric($retry_after)) {
            $info['retry_delay'] = (int) $retry_after;
        }

        if (strpos($detail, 'daily') !== false || strpos($detail, 'per day') !== false) {
            $info['quota_bucket'] = self::RPD;
            $info['error_type'] = 'daily_quota';
        } elseif (strpos($detail, 'rate') !== false || strpos($detail, 'too many') !== false || $http_code === 429) {
            $info['quota_bucket'] = self::RPM;
            $info['error_type'] = 'rpm_burst';
        } else {
            $info['error_type'] = 'unknown_429';
        }

        $info['error_status'] = $detail;

        return $info;
    }

    public static function parse_openrouter(int $http_code, string $raw_body, array $headers): array
    {
        $info = self::base_info('openrouter', $http_code, $raw_body);
        $parsed = json_decode($raw_body, true);
        $error = $parsed['error'] ?? [];
        $lower = strtolower($raw_body);

        if (is_array($error)) {
            $info['error_status'] = (string) ($error['message'] ?? $error['code'] ?? '');
            $meta = $error['metadata'] ?? [];
            if (!empty($meta['rate_limit'])) {
                $info['quota_metric'] = $meta['rate_limit'];
            }
        } else {
            $info['error_status'] = (string) $error;
        }

        $retry_after = $headers['retry-after'] ?? $headers['x-ratelimit-reset'] ?? '';
        if (is_numeric($retry_after)) {
            $val = (int) $retry_after;
            if ($val > 1000000000) {
                $info['retry_delay'] = max(0, $val - time());
                $info['reset_at'] = $val;
            } else {
                $info['retry_delay'] = $val;
            }
        }

        $rl_remaining = $headers['x-ratelimit-remaining'] ?? '';
        if (is_numeric($rl_remaining)) {
            $info['rate_limit_remaining'] = (int) $rl_remaining;
        }
        $rl_limit = $headers['x-ratelimit-limit'] ?? '';
        if (is_numeric($rl_limit)) {
            $info['rate_limit_limit'] = (int) $rl_limit;
        }

        if (strpos($lower, 'daily') !== false || strpos($lower, 'per day') !== false) {
            $info['quota_bucket'] = self::RPD;
            $info['error_type'] = 'daily_quota';
        } elseif ($http_code === 429) {
            $info['quota_bucket'] = self::RPM;
            $info['error_type'] = 'rpm_burst';
        } else {
            $info['error_type'] = 'unknown_429';
        }

        return $info;
    }

	public static function parse_custom(int $http_code, string $raw_body, array $headers, string $provider_slug = 'custom'): array
	{
		$info = self::base_info($provider_slug, $http_code, $raw_body);
		$parsed = json_decode($raw_body, true);
		$lower = strtolower($raw_body);
		$error = $parsed['error'] ?? [];

		if (is_array($error)) {
			$info['error_status'] = (string) ($error['message'] ?? $error['code'] ?? '');
		} else {
			$info['error_status'] = (string) $error;
		}

		$retry_after = $headers['retry-after'] ?? $headers['x-ratelimit-reset'] ?? '';
		if (is_numeric($retry_after)) {
			$val = (int) $retry_after;
			if ($val > 1000000000) {
				$info['retry_delay'] = max(0, $val - time());
				$info['reset_at'] = $val;
			} else {
				$info['retry_delay'] = $val;
			}
		}

		$rl_remaining = $headers['x-ratelimit-remaining'] ?? '';
		if (is_numeric($rl_remaining)) {
			$info['rate_limit_remaining'] = (int) $rl_remaining;
		}

		if (strpos($lower, 'daily') !== false || strpos($lower, 'per day') !== false) {
			$info['quota_bucket'] = self::RPD;
			$info['error_type'] = 'daily_quota';
		} elseif ($http_code === 429) {
			$info['quota_bucket'] = self::RPM;
			$info['error_type'] = 'rpm_burst';
		} elseif ($http_code === 403 && strpos($lower, 'limit') !== false) {
			$info['quota_bucket'] = self::RPM;
			$info['error_type'] = 'rpm_burst';
		} else {
			$info['error_type'] = 'unknown_429';
		}

		return $info;
	}

	public static function parse_deepseek(int $http_code, string $raw_body, array $headers): array
    {
        $info = self::base_info('deepseek', $http_code, $raw_body);
        $parsed = json_decode($raw_body, true);
        $lower = strtolower($raw_body);

        $info['error_status'] = (string) ($parsed['error']['message'] ?? $parsed['message'] ?? '');

        $retry_after = $headers['retry-after'] ?? '';
        if (is_numeric($retry_after)) {
            $info['retry_delay'] = (int) $retry_after;
        }

        if (strpos($lower, 'daily') !== false || strpos($lower, 'per day') !== false) {
            $info['quota_bucket'] = self::RPD;
            $info['error_type'] = 'daily_quota';
        } elseif ($http_code === 429) {
            $info['quota_bucket'] = self::RPM;
            $info['error_type'] = 'rpm_burst';
        } else {
            $info['error_type'] = 'unknown_429';
        }

        return $info;
    }

    public static function parse_generic(int $http_code, string $raw_body, array $headers): array
    {
        $info = self::base_info('unknown', $http_code, $raw_body);

        $retry_after = $headers['retry-after'] ?? '';
        if (is_numeric($retry_after)) {
            $info['retry_delay'] = (int) $retry_after;
        }

        if ($http_code === 429) {
            $info['error_type'] = 'rpm_burst';
            $info['quota_bucket'] = self::RPM;
        } elseif ($http_code === 413) {
            $info['error_type'] = 'tpm_exceeded';
            $info['quota_bucket'] = self::TPM;
        }

        return $info;
    }

    private static function base_info(string $provider, int $http_code, string $raw_body): array
    {
        return [
            'provider' => $provider,
            'http_code' => $http_code,
            'error_type' => 'unknown_429',
            'error_status' => '',
            'quota_bucket' => self::UNKNOWN,
            'quota_metric' => '',
            'quota_id' => '',
            'retry_delay' => 0,
            'reset_at' => 0,
            'is_quota_zero' => false,
            'rate_limit_remaining' => null,
            'rate_limit_limit' => null,
            'raw_body_preview' => substr($raw_body, 0, 500),
        ];
    }

    private static function classify_quota_bucket(string $qid, string $metric): string
    {
        $haystack = $qid . ' ' . $metric;

        if (preg_match('/per[_]?day|_rpd|daily/i', $haystack)) {
            return self::RPD;
        }
        if (preg_match('/per[_]?minute|_rpm|minute/i', $haystack)) {
            return self::RPM;
        }
        if (preg_match('/per[_]?token|_tpm|token/i', $haystack)) {
            return self::TPM;
        }

        return self::UNKNOWN;
    }

    private static function classify_by_body_heuristics(string $lower): string
    {
        $has_daily = (
            strpos($lower, 'generate_content_free_tier_requests') !== false
            || strpos($lower, 'requests per day') !== false
            || strpos($lower, 'requests_per_day') !== false
            || (strpos($lower, 'rpd') !== false && strpos($lower, 'quota') !== false)
        );

        $has_quota = (
            strpos($lower, 'quota') !== false
            || strpos($lower, 'resource_exhausted') !== false
            || strpos($lower, 'exceeded') !== false
        );

        if ($has_daily && $has_quota) {
            return self::RPD;
        }
        if ($has_quota) {
            return self::RPM;
        }
        return self::UNKNOWN;
    }

    private static function derive_error_type(array $info): string
    {
        if ($info['is_quota_zero']) {
            return 'quota_zero';
        }
        if ($info['quota_bucket'] === self::RPD) {
            return 'daily_quota';
        }
        if ($info['quota_bucket'] === self::TPM) {
            return 'tpm_exceeded';
        }
        if ($info['quota_bucket'] === self::RPM) {
            return 'rpm_burst';
        }
        return 'unknown_429';
    }

    /**
     * Extract usageMetadata from a successful Gemini response.
     *
     * @param array $json Decoded response body
     * @return array Normalized usage info
     */
    public static function extract_gemini_usage(array $json): array
    {
        $meta = $json['usageMetadata'] ?? [];
        return [
            'prompt_tokens' => (int) ($meta['promptTokenCount'] ?? 0),
            'candidates_tokens' => (int) ($meta['candidatesTokenCount'] ?? 0),
            'total_tokens' => (int) ($meta['totalTokenCount'] ?? 0),
            'thoughts_tokens' => (int) ($meta['thoughtsTokenCount'] ?? 0),
            'model_version' => (string) ($json['modelVersion'] ?? ''),
        ];
    }
}
