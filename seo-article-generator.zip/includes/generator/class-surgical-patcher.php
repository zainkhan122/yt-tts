<?php
namespace SEO_Article_Generator\Generator;

use SEO_Article_Generator\Tools\Sentinel_Injector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Surgical_Patcher {

	private const SELF_CLOSING_ZONES = ['hero'];

	public static function patch( string $existing_html, array $new_data, array $regen_sections, array $heading_map = [], int $post_id = 0 ): array {
		// Normalize the hero block comment on the way IN so legacy / space-variant /
		// <p>-wrapped forms never reach parse_blocks(). Single source of truth lives in
		// Article_Schema::canonicalize_hero_block_comment(); called by every save path.
		$existing_html = Article_Schema::canonicalize_hero_block_comment( $existing_html );

		$normalized_regen_sections = Article_Schema::normalize_sections( (array) $regen_sections );

		$normalized_regen_sections = array_values( array_diff( $normalized_regen_sections, self::SELF_CLOSING_ZONES ) );

		if ( in_array( 'all', $normalized_regen_sections, true ) ) {
			return [
				'content'   => (string) ( $new_data['html_content'] ?? $existing_html ),
				'patched'   => [ 'all' ],
				'skipped'   => [],
				'not_found' => [],
			];
		}

		if ( trim( $existing_html ) === '' ) {
			return [
				'content'   => (string) ( $new_data['html_content'] ?? '' ),
				'patched'   => [],
				'skipped'   => [],
				'not_found' => $normalized_regen_sections,
			];
		}

		[ $blocks, $html ] = Sentinel_Injector::upgrade_legacy_html_to_blocks( $existing_html );

		$needs_repair         = false;
		$repair_was_attempted = false;

		// CRITICAL FIX: Check for corruption in UPGRADED content, not original.
		// The original may have empty sentinels at top while real content exists elsewhere.
		// After upgrade, we must validate the upgraded content for this pattern.
		$has_self_closing = preg_match( '/\/\s*-->\s*$/im', $html );
		$has_empty_blocks = preg_match( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*-->\s*<!--\s*\/wp:seo-gen\/section\s*-->/is', $html );

		// Also check for legacy format markers in the UPGRADED content
		if (
			strpos( $html, '<!-- seo-gen-zone:' ) !== false ||
			strpos( $html, 'data-seo-gen-zone=' ) !== false
		) {
			$needs_repair = true;
		}

		// CRITICAL FIX: Check if UPGRADED content has complete zone coverage.
		// If block format but missing zones, we need to repair before patching can work.
		if ( is_string( $html ) && $html !== '' ) {
			preg_match_all(
				'/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"([^"]+)"[^}]*\}\s*-->/i',
				$html,
				$zone_matches
			);

			$present_block_zones = [];
			foreach ( (array) ( $zone_matches[1] ?? [] ) as $raw_zone ) {
				$canonical             = Article_Schema::get_canonical_key( (string) $raw_zone );
				$present_block_zones[] = is_string( $canonical ) && $canonical !== '' ? $canonical : (string) $raw_zone;
			}
			$present_block_zones = array_values( array_unique( array_filter( $present_block_zones ) ) );

			// CRITICAL FIX: Check ALL zones, not just requested ones.
			// If upgraded content is missing zones, surgical patch cannot work.
			$all_zones = Article_Schema::get_ordered_section_keys();
			$missing_zones = array_values( array_diff( $all_zones, $present_block_zones ) );

			if ( ! empty( $missing_zones ) ) {
				// Check if any missing zone exists in the ORIGINAL content (outside blocks)
				// If so, we need to repair to inject those missing sentinels
				foreach ( $missing_zones as $zone ) {
					if ( self::find_zone( $existing_html, $zone ) !== false ) {
						$needs_repair = true;
						break;
					}
				}
			}

			// Even if zones are missing from blocks, check if requested sections are covered
			$requested_missing_from_blocks = array_values( array_diff( $normalized_regen_sections, $present_block_zones ) );

			foreach ( $requested_missing_from_blocks as $zone ) {
				if ( self::find_zone( $existing_html, $zone ) !== false ) {
					$needs_repair = true;
					break;
				}
			}
		}

		if ( $needs_repair && class_exists( '\SEO_Article_Generator\Tools\Sentinel_Fallback_Utility' ) ) {
			$repair_was_attempted = true;
			$repair = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::repair_and_audit(
				$existing_html,
				$normalized_regen_sections,
				[ 'is_update' => false ]
			);

			if ( ! empty( $repair['changed'] ) && empty( $repair['audit']['fatal_reasons'] ) ) {
				[ $blocks, $html ] = Sentinel_Injector::upgrade_legacy_html_to_blocks( $repair['content'] );
			}
		}

		if ( strpos( $html, '<!-- wp:seo-gen/section ' ) === false ) {
			if ( class_exists( '\SEO_Article_Generator\Tools\Sentinel_Fallback_Utility' ) ) {
				$repair_was_attempted = true;
				$repair = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::repair_and_audit(
					$existing_html,
					[],
					[ 'is_update' => false ]
				);
				if ( $repair['changed'] && empty( $repair['audit']['fatal_reasons'] ) ) {
					[ $blocks, $html ] = Sentinel_Injector::upgrade_legacy_html_to_blocks( $repair['content'] );
				}
			}

			if ( strpos( $html, '<!-- wp:seo-gen/section ' ) === false ) {
				return [
					'content'          => $existing_html,
					'patched'          => [],
					'skipped'          => [],
					'not_found'        => $normalized_regen_sections,
					'error'            => 'migration_failed_missing_block_delimiters',
					'needs_full_regen' => true,
				];
			}

			if ( ! is_array( $blocks ) || empty( $blocks ) ) {
				$blocks = \parse_blocks( $html );
			}
		}

		if ( ! is_array( $blocks ) || empty( $blocks ) ) {
			return [
				'content'   => $existing_html,
				'patched'   => [],
				'skipped'   => [],
				'not_found' => $normalized_regen_sections,
				'error'     => 'parse_blocks_returned_empty_after_upgrade',
			];
		}

		$patched = [];
		$skipped = [];

		$blocks = self::process_blocks(
			$blocks,
			$normalized_regen_sections,
			$new_data,
			$patched,
			$skipped,
			$heading_map,
			$post_id
		);

		// ADDITIVE-INSERT: requested zones absent from the live post
		// (e.g. a section the admin just enabled in Settings) are injected at
		// their canonical position instead of forcing a destructive full rewrite.
		// Existing zone blocks are left byte-for-byte intact — preserving SEO.
		if ( class_exists( 'Content_Formatter' ) ) {
			$_sp_formatter = new Content_Formatter( $heading_map );
			$_sp_ordered   = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
			$_sp_order_idx = array_flip( $_sp_ordered );

			$_sp_existing = array();
			foreach ( $blocks as $_sp_b ) {
				if ( isset( $_sp_b['blockName'], $_sp_b['attrs']['zone'] ) && 'seo-gen/section' === $_sp_b['blockName'] ) {
					$_sp_existing[] = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key( (string) $_sp_b['attrs']['zone'] );
				}
			}

			foreach ( $normalized_regen_sections as $_sp_zone ) {
				if ( in_array( $_sp_zone, $patched, true ) || in_array( $_sp_zone, $skipped, true ) ) {
					continue;
				}
				if ( in_array( $_sp_zone, $_sp_existing, true ) ) {
					continue;
				}
				$_sp_inner = $_sp_formatter->render_zone_blocks( $_sp_zone, $new_data, $post_id );
				if ( empty( $_sp_inner ) ) {
					$skipped[] = $_sp_zone;
					continue;
				}
				$_sp_wrapped = Content_Formatter::zone_block( $_sp_zone, $_sp_inner );
				$_sp_insert  = is_array( $_sp_wrapped ) ? $_sp_wrapped[0] : $_sp_wrapped;

				$_sp_at     = count( $blocks );
				$_sp_order = (int) ( $_sp_order_idx[ $_sp_zone ] ?? 1000 );
				foreach ( $blocks as $_sp_i => $_sp_b ) {
					if ( isset( $_sp_b['blockName'], $_sp_b['attrs']['zone'] ) && 'seo-gen/section' === $_sp_b['blockName'] ) {
						$_sp_bk      = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key( (string) $_sp_b['attrs']['zone'] );
						$_sp_bk_ord = (int) ( $_sp_order_idx[ $_sp_bk ] ?? 1000 );
						if ( $_sp_bk_ord > $_sp_order ) {
							$_sp_at = $_sp_i;
							break;
						}
					}
				}
				array_splice( $blocks, $_sp_at, 0, array( $_sp_insert ) );
				$patched[] = $_sp_zone;
			}
			unset( $_sp_formatter, $_sp_ordered, $_sp_order_idx, $_sp_existing, $_sp_zone, $_sp_inner, $_sp_wrapped, $_sp_insert, $_sp_at, $_sp_order, $_sp_i, $_sp_b, $_sp_bk, $_sp_bk_ord );
		}

		$all_not_found = array_values( array_diff( $normalized_regen_sections, $patched, $skipped ) );

		$not_found_in_content       = [];
		$not_found_detection_failed = [];

		foreach ( $all_not_found as $zone ) {
			if ( $repair_was_attempted ) {
				$not_found_detection_failed[] = $zone;
			} else {
				$not_found_in_content[] = $zone;
			}
		}

		// Normalize the hero block comment on the way OUT.
		// WP core's serialize_blocks() emits the canonical no-space form for self-closing
		// blocks today, but the canonical form was not always emitted by older core / JS
		// round-trips, and a stray `<p>` wrapper from a previous freeform-fallback save
		// can survive the parse → serialize round-trip. Re-applying the canonicalization
		// here makes the update path symmetric with the new-post path and guarantees the
		// hero block survives the next editor load.
		$serialized_content = Article_Schema::canonicalize_hero_block_comment( \serialize_blocks( $blocks ) );

		return [
			'content'                    => $serialized_content,
			'patched'                    => array_values( array_unique( $patched ) ),
			'skipped'                    => array_values( array_unique( $skipped ) ),
			'not_found'                  => $all_not_found,
			'not_found_in_content'       => $not_found_in_content,
			'not_found_detection_failed' => $not_found_detection_failed,
		];
	}

	private static function process_blocks(
		array $blocks,
		array $regen_sections,
		array $new_data,
		array &$patched,
		array &$skipped,
		array $heading_map = [],
		int $post_id = 0
	): array {
		foreach ( $blocks as $index => &$block ) {
			if (
				isset( $block['blockName'], $block['attrs']['zone'] ) &&
				'seo-gen/section' === $block['blockName']
			) {
				$raw_zone = (string) $block['attrs']['zone'];
				$zone     = Article_Schema::get_canonical_key( $raw_zone );

				if ( ! is_string( $zone ) || $zone === '' ) {
					$zone = $raw_zone;
				}

				if ( $zone !== $raw_zone ) {
					$block['attrs']['zone'] = $zone;
				}

				if ( in_array( $zone, $regen_sections, true ) ) {
					// @MODIFIED 2026-03-26: Block-Tree Injection with Sync
					// Instead of stuffing serialized HTML into the node, we replace the whole node
					// with a fresh canonical zone block (including its innerBlocks tree).
					// Passing $heading_map and $post_id to ensure heading/anchor consistency.
					$formatter = new Content_Formatter( $heading_map );
					$inner_blocks = $formatter->render_zone_blocks( $zone, $new_data, $post_id );

					if ( ! empty( $inner_blocks ) ) {
						// Replace the whole wrapper node with a fresh one containing the new block tree.
						$wrapped = Content_Formatter::zone_block( $zone, $inner_blocks );
						$blocks[ $index ] = $wrapped[0];
						$patched[] = $zone;
					} else {
						$skipped[] = $zone;
					}
					// Note: If we replaced it, we don't recurse into it as it's fresh.
					continue;
				}
			}

		if ( ! empty( $block['innerBlocks'] ) ) {
			$block['innerBlocks'] = self::process_blocks(
				$block['innerBlocks'],
				$regen_sections,
				$new_data,
				$patched,
				$skipped,
				$heading_map,
				$post_id
			);
			$blocks[ $index ] = $block;
		}
		}

		// T6 FIX: Destroy reference to last loop element.
		// Without this, $block remains aliased to $blocks[last] after the loop ends.
		unset( $block );

		return $blocks;
	}


	/**
	 * Find the position of a zone sentinel in the HTML.
	 * Required for Smoke_Tester existence check.
	 * T5 FIX: Now checks all three formats: block, comment, and attribute.
	 *
	 * @param string $html HTML content to search.
	 * @param string $zone Zone key to find.
	 * @return int|false Offset of the sentinel or false if not found.
	 */
	public static function find_zone( string $html, string $zone ): int|false {
		$canonical = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key( $zone );

		if ( ! is_string( $canonical ) || $canonical === '' ) {
			return false;
		}

		$alias_map = \SEO_Article_Generator\Generator\Article_Schema::get_alias_map();
		$specs     = class_exists( '\SEO_Article_Generator\Content\Content_Normalizer' )
			? \SEO_Article_Generator\Content\Content_Normalizer::zone_marker_specs( $html )
			: \SEO_Article_Generator\Generator\Article_Schema::get_marker_specs();

		$candidates = [ $canonical ];

		foreach ( $alias_map as $alias => $mapped ) {
			if ( $mapped === $canonical ) {
				$candidates[] = $alias;
			}
		}

		$candidates = array_values( array_unique( array_filter( $candidates ) ) );

		// Pass 1: exact block/comment sentinel formats
		foreach ( $candidates as $candidate ) {
			$pos = strpos( $html, sprintf( '<!-- wp:seo-gen/section {"zone":"%s"}', $candidate ) );
			if ( false !== $pos ) {
				return $pos;
			}

			$pos = strpos( $html, sprintf( '<!-- seo-gen-zone:%s -->', $candidate ) );
			if ( false !== $pos ) {
				return $pos;
			}

			// Detect self-closing hero block in both forms:
			//   - canonical   : `<!-- wp:seo-gen/hero /-->`     (no space between `/` and `-->`)
			//   - legacy/bad  : `<!-- wp:seo-gen/hero / -->`   (space between `/` and `-->`)
			// WP core's PHP `serialize_blocks()` AND Gutenberg's JS `getCommentDelimitedContent()`
			// both emit the canonical no-space form for self-closing blocks, so the canonical
			// form is what every modern code path writes. The space form only survives in DB
			// rows written by older plugin code or by third-party tooling, and is parser-fatal
			// (it demotes the block to freeform). Both forms are accepted here so detection
			// works regardless of which form a stale post carries.

			// Detect self-closing hero block: <!-- wp:seo-gen/hero /-->
			if ( $candidate === 'hero' ) {
				$pos = strpos( $html, '<!-- wp:seo-gen/hero / -->' );
				if ( false !== $pos ) {
					return $pos;
				}
				// Fallback: legacy format without space (written by older plugin versions)
				$pos = strpos( $html, '<!-- wp:seo-gen/hero /-->' );
				if ( false !== $pos ) {
					return $pos;
				}
			}
		}

		// Pass 2: HTML attribute markers
		$spec     = (array) ( $specs[ $canonical ] ?? [] );
		$patterns = [];

		if ( ! empty( $spec['data_attr'] ) ) {
			$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bdata-seo-gen-zone\s*=\s*([\'"])'
				. preg_quote( (string) $spec['data_attr'], '/' )
				. '\1[^>]*>/i';
		}

		foreach ( [ 'block_class', 'legacy_class' ] as $class_key ) {
			$class_needle = (string) ( $spec[ $class_key ] ?? '' );
			if ( $class_needle !== '' ) {
				$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bclass\s*=\s*([\'"])[^\'\"]*\b'
					. preg_quote( $class_needle, '/' )
					. '\b[^\'\"]*\1[^>]*>/i';
			}
		}

		if ( ! empty( $spec['anchor_id'] ) ) {
			$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bid\s*=\s*([\'"])'
				. preg_quote( (string) $spec['anchor_id'], '/' )
				. '\1[^>]*>/i';
		}

		foreach ( (array) ( $spec['anchor_id_patterns'] ?? [] ) as $raw_pattern ) {
			if ( is_string( $raw_pattern ) && $raw_pattern !== '' ) {
				$patterns[] = $raw_pattern;
			}
		}

		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $html, $m, PREG_OFFSET_CAPTURE ) ) {
				return (int) $m[0][1];
			}
		}

		return false;
	}

	private static function humanize_key( string $key ): string {
		$key = str_replace( [ '_', '-' ], ' ', $key );
		return ucwords( trim( $key ) );
	}
}
