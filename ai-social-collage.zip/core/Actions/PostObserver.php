<?php
namespace AiSocialCollage\Actions;

use AiSocialCollage\Config;
use AiSocialCollage\Database\JobManager;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PostObserver {

    public static bool $suppress = false;

    public function __construct() {
        add_action( 'save_post', [ $this, 'detect_new_post' ], 10, 3 );
        add_action( 'transition_post_status', [ $this, 'on_publish_transition' ], 10, 3 );
        // Sync user edits from post_content/post_title back to META_AUTO_META
        // Priority 20 = after content filters, before other plugins
        add_action( 'save_post', [ $this, 'sync_user_edits_to_meta' ], 20, 3 );
    }

    public function detect_new_post( $post_id, $post, $update ) {
        if ( self::$suppress ) {
            return;
        }

        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        if ( $post->post_type !== 'post' ) {
            return;
        }

        if ( in_array( $post->post_status, [ 'auto-draft', 'trash', 'inherit' ], true ) ) {
            return;
        }

        $raw_content = get_post_meta( $post_id, Config::META_RSS_CONTENT, true );
        if ( empty( $raw_content ) ) {
            $raw_content = $post->post_content;
        }
        $clean_text = trim( wp_strip_all_tags( $raw_content ) );
        if ( empty( $clean_text ) ) {
            return;
        }

        if ( JobManager::job_exists_for_post( $post_id, true ) ) {
            return;
        }

        $pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
        if ( $pipeline_paused ) {
            return;
        }

		$campaign = self::find_matching_campaign( $post_id );
		if ( ! $campaign ) {
			Logger::info( 'post_no_campaign_match', null, [ 'post_id' => $post_id ], '200', 'No active campaign matches this post category; skipping.' );
			return;
		}

		$job_id = JobManager::create_job( $post_id );
		if ( ! $job_id ) {
			Logger::error( 'job_create_failed', null, [ 'post_id' => $post_id ], '500' );
			return;
		}

		update_post_meta( $post_id, Config::META_CAMPAIGN_DATA, $campaign );

		if ( function_exists( 'as_schedule_single_action' ) ) {
			$action_id = as_schedule_single_action(
				time(),
				Config::ACTION_PROCESS_JOB,
				[ 'job_id' => $job_id ],
				Config::AS_GROUP
			);
			if ( $action_id ) {
				Logger::info( 'job_queued', $job_id, [ 'post_id' => $post_id, 'campaign_id' => $campaign['id'] ] );
			} else {
				Logger::error( 'job_as_enqueue_failed', $job_id, [ 'post_id' => $post_id ], '500', 'Action Scheduler returned 0; job created but not scheduled.' );
			}
		} else {
			Logger::warning( 'job_queued_no_as', $job_id, [ 'post_id' => $post_id ], '200', 'Action Scheduler not found. Job created but not scheduled.' );
		}
	}

	public function on_publish_transition( $new_status, $old_status, $post ) {
		if ( self::$suppress ) {
			return;
		}

		// Handle both draft→publish and future→publish (prime-time scheduled posts)
		$is_publish_transition = (
			( $old_status === 'draft' && $new_status === 'publish' ) ||
			( $old_status === 'future' && $new_status === 'publish' )
		);
		if ( ! $is_publish_transition ) {
			return;
		}

		if ( $post->post_type !== 'post' ) {
			return;
		}

		// WP fires transition_post_status BEFORE save_post (wp_insert_post:
		// wp_transition_post_status() then do_action('save_post')). A manual
		// publish therefore reaches the Buffer share below before the
		// save_post priority-20 sync_user_edits_to_meta() has run — Buffer would
		// send the stale AI meta. Re-sync here so the share always uses the
		// latest user-approved content, regardless of hook ordering.
		$this->sync_user_edits_to_meta( $post->ID, $post, true );

		$auto_meta = get_post_meta( $post->ID, Config::META_AUTO_META, true );
		if ( ! is_array( $auto_meta ) || empty( $auto_meta ) ) {
			return;
		}

		$history = get_post_meta( $post->ID, Config::META_BUFFER_SHARE_HISTORY, true );
		$has_history = is_array( $history ) && ! empty( $history );

		$thumbnail_id = (int) get_post_thumbnail_id( $post->ID );

		// Resolve the AI-generated video reel attachment.
		// Only META_IS_AI_COLLAGE videos are accepted — never share the raw
		// source video. If no rendered reel exists, $video_attachment_id stays 0
		// and Buffer/R2 are skipped for this post.
		// Exclude source videos (META_SOURCE_VIDEO) which may incorrectly have
		// META_IS_AI_COLLAGE set from older ingests via sideload_featured_image.
		$video_attachment_id = 0;
		$ai_video_attachments = get_posts( [
			'post_type'      => 'attachment',
			'post_parent'    => $post->ID,
			'post_mime_type' => 'video',
			'posts_per_page' => 1,
			'meta_query'     => [
				'relation' => 'AND',
				[
					'key'   => Config::META_IS_AI_COLLAGE,
					'value' => '1',
				],
				[
					'key'     => Config::META_SOURCE_VIDEO,
					'compare' => 'NOT EXISTS',
				],
			],
		] );
		if ( ! empty( $ai_video_attachments ) ) {
			$video_attachment_id = (int) $ai_video_attachments[0]->ID;
		} else {
			Logger::warning( 'no_ai_reel_for_post', null, [
				'post_id' => $post->ID,
			], '404', 'No AI-generated video reel found; Buffer/R2 sharing skipped for this post.' );
		}

// R2 upload happens at publish time (not during rendering) to avoid wasting resources on unpublished posts
        if ( Config::is_video_r2_buffer_auto_enabled() && Config::is_r2_configured() && Config::is_buffer_enabled() && $video_attachment_id > 0 ) {
            $job = \AiSocialCollage\Database\JobManager::get_completed_job_for_post( $post->ID );
            if ( $job && empty( $job->video_url ) ) {
                // R2 upload needed - video was rendered but not uploaded to R2 yet (R2/BUFFER_AUTO was disabled at render time)
                $file_path = get_attached_file( $video_attachment_id );

                // Safety: verify the resolved file is actually the rendered reel,
                // not a source video that slipped through the meta_query.
                // Reel filenames follow the pattern: video_reel_{job_id}_{uniqid}_reel.mp4
                $is_reel = preg_match( '/video_reel_\d+_[a-f0-9]+_reel\.\w+$/', $file_path ?? '' );
                if ( ! $is_reel ) {
                    Logger::error( 'r2_upload_reject_non_reel', $job->id, [
                        'post_id'             => $post->ID,
                        'video_attachment_id' => $video_attachment_id,
                        'file_path'           => $file_path ?? 'not found',
                        'reason'              => 'Resolved file does not match rendered reel filename pattern. Refusing to upload source video to R2.',
                    ], '500' );
                } elseif ( $file_path && file_exists( $file_path ) ) {
                    Logger::warning( 'r2_upload_needed_on_publish', $job->id, [
                        'post_id' => $post->ID,
                        'reason'  => 'Video rendered but R2 upload skipped during rendering (feature disabled). Uploading now on publish.',
                    ], '500' );
                    $renderer = new \AiSocialCollage\Services\VideoRenderer();
                    $r2_url = $renderer->maybe_upload_to_r2( $file_path, $job->id, $video_attachment_id );
                    if ( $r2_url ) {
                        $campaign = get_post_meta( $post->ID, Config::META_CAMPAIGN_DATA, true );
                        $stored_publish_at = '';
                        if ( is_array( $campaign ) ) {
                            $publish_time = Config::get_campaign_value( $campaign, 'publish_time', '09:00' );
                            $frequency    = Config::get_campaign_value( $campaign, 'frequency', Config::FREQUENCY_1_DAY );
                            $stored_publish_at = \AiSocialCollage\Actions\QueueProcessor::compute_publish_at( $publish_time, $frequency );
                            \AiSocialCollage\Database\JobManager::update_job_fields( $job->id, [
                                'publish_at' => $stored_publish_at,
                            ] );
                        }
                        Logger::info( 'r2_upload_on_publish', $job->id, [
                            'post_id' => $post->ID,
                            'url' => $r2_url,
                            'publish_at' => $stored_publish_at,
                        ], '200' );
                    } else {
                        Logger::error( 'r2_upload_failed_on_publish', $job->id, [
                            'post_id' => $post->ID,
                            'video_attachment_id' => $video_attachment_id,
                        ], '500' );
                    }
                } else {
                    Logger::error( 'r2_upload_file_missing', $job->id, [
                        'post_id' => $post->ID,
                        'video_attachment_id' => $video_attachment_id,
                        'file_path' => $file_path ?? 'not found',
                    ], '500' );
                }
            }
        }

        // Buffer share on publish - BufferIntegration will handle getting the right URL (R2 or local)
        if ( Config::is_buffer_enabled() && ! $has_history ) {
            $attachment_to_share = $thumbnail_id;
            // For video posts, prefer sharing the video attachment if available
            if ( $video_attachment_id > 0 ) {
                $attachment_to_share = $video_attachment_id;
            }
            
            try {
                \AiSocialCollage\Services\BufferIntegration::share( $post->ID, $attachment_to_share );
                Logger::info( 'buffer_triggered_on_publish', null, [
                    'post_id' => $post->ID,
                    'type' => $video_attachment_id > 0 ? 'video' : 'image',
                ] );
            } catch ( \Throwable $e ) {
                Logger::warning( 'buffer_publish_exception', null, [
                    'post_id' => $post->ID,
                    'error' => $e->getMessage(),
                ] );
            }
        } elseif ( $has_history ) {
            Logger::debug( 'buffer_already_shared_skip', null, [ 'post_id' => $post->ID ] );
        }

		if ( Config::is_jetpack_enabled() ) {
			try {
				\AiSocialCollage\Services\JetpackSocial::sync( $post->ID, $thumbnail_id );
			} catch ( \Throwable $e ) {
				Logger::warning( 'jetpack_publish_exception', null, [
					'post_id' => $post->ID,
					'error' => $e->getMessage(),
				] );
			}
		}
	}

	private static function find_matching_campaign( $post_id ) {
		$categories = get_the_category( $post_id );
		if ( is_wp_error( $categories ) || empty( $categories ) ) {
			return null;
		}

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		if ( empty( $campaigns ) ) {
			return null;
		}

		$post_slugs = array_map( function( $cat ) {
			return $cat->slug;
		}, $categories );

		foreach ( $campaigns as $campaign ) {
			if ( empty( $campaign['active'] ) ) {
				continue;
			}
			$source_slug = sanitize_title( $campaign['source_category'] ?? '' );
			if ( ! empty( $source_slug ) && in_array( $source_slug, $post_slugs, true ) ) {
				return $campaign;
			}
		}

	return null;
	}

	/**
	 * Sync user edits from post_content/post_title back to META_AUTO_META
	 * so BufferIntegration sees the latest user-approved content.
	 */
	public function sync_user_edits_to_meta( $post_id, $post, $update ) {
		if ( self::$suppress ) return;
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
		if ( $post->post_type !== 'post' ) return;

		$auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
		if ( ! is_array( $auto_meta ) || empty( $auto_meta ) ) return; // Only sync AI-generated posts

		// Parse edited content
		$parsed = \AiSocialCollage\Services\BufferIntegration::parse_post_content_for_buffer( $post->post_content, $auto_meta );

		// Update editable fields, preserve AI-generated fallbacks
		$auto_meta['ai_headline']             = $post->post_title ?: $auto_meta['ai_headline'];
		$auto_meta['ai_detailed_description'] = $parsed['ai_detailed_description'] ?: $auto_meta['ai_detailed_description'];
		$auto_meta['ai_hook']                 = $parsed['ai_hook'] ?: $auto_meta['ai_hook'];
		$auto_meta['ai_hashtags']             = $parsed['ai_hashtags'] ?: $auto_meta['ai_hashtags'];
		$auto_meta['ai_mentions']             = $parsed['ai_mentions'] ?: $auto_meta['ai_mentions'];
		$auto_meta['x_content']               = $parsed['x_content'] ?: ( $auto_meta['x_content'] ?? '' );
		$auto_meta['ai_x_hashtags']           = $parsed['x_hashtags'] ?: ( $auto_meta['ai_x_hashtags'] ?? [] );
		$auto_meta['ai_x_description']        = $parsed['x_description'] ?: ( $auto_meta['ai_x_description'] ?? '' );

		update_post_meta( $post_id, Config::META_AUTO_META, $auto_meta );

		// Also sync WP tags from hashtags
		$tag_source = $auto_meta['ai_hashtags'] ?? [];
		if ( ! is_array( $tag_source ) ) {
			$tag_source = [];
		}
		$tag_names = array_map( fn( $tag ) => ltrim( (string) $tag, '#' ), $tag_source );
		wp_set_post_tags( $post_id, array_slice( array_unique( $tag_names ), 0, 10 ), true );
	}
}
