/**
 * SEO Gen Hero Block - Editor Registration
 * 
 * @MODIFIED 2025-12-15 v2.1.4: Added JS block registration for editor compatibility
 * 
 * This block is server-side rendered. This JS file only registers it with
 * the WordPress block editor so it doesn't show "block not supported" error.
 */
(function (wp) {
    var registerBlockType = wp.blocks.registerBlockType;
    var el = wp.element.createElement;

    registerBlockType('seo-gen/hero', {
        apiVersion: 3,
        title: 'SEO Gen Hero',
        description: 'App Store style hero section with download CTA. Server-side rendered from post meta.',
        icon: 'download',
        category: 'widgets',

        // Prevent manual insertion - this block is auto-generated
        supports: {
            inserter: false,
            html: false,
            reusable: false,
            align: false,
            interactivity: true
        },

        // No attributes - reads from _seo_gen_hero_data post meta
        attributes: {},

        // Editor placeholder
        edit: function () {
            return el(
                'div',
                {
                    style: {
                        padding: '20px',
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        borderRadius: '12px',
                        color: '#fff',
                        textAlign: 'center',
                        fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif'
                    }
                },
                el('span', { style: { fontSize: '24px', marginRight: '8px' } }, '⬇️'),
                el('strong', null, 'Hero Section'),
                el('p', { style: { margin: '8px 0 0', opacity: 0.8, fontSize: '13px' } },
                    'App Store style download CTA. Rendered from post meta on frontend.')
            );
        },

        // Dynamic block - no save, server renders
        save: function () {
            return null;
        }
    });
})(window.wp);
