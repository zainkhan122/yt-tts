<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ImageVerificationService {

    private static $instance = null;
    private $chain_runner = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->chain_runner = new VerificationChainRunner();
    }

    public function verify_image_removal( string $image_path, string $original_path, int $post_id = 0 ): array {
        if ( ! file_exists( $image_path ) ) {
            return $this->build_error_result( 'Generated image not found', $post_id );
        }

        if ( ! file_exists( $original_path ) ) {
            return $this->build_error_result( 'Original image not found', $post_id );
        }

        $threshold = (float) get_option( Config::OPTION_VERIFICATION_CONFIDENCE_THRESHOLD, 0.7 );

        $result = $this->chain_runner->verify_image( $image_path, $original_path, $post_id );

        if ( ! $result['clean'] && $result['confidence'] >= $threshold ) {
            $this->log_verification_failure( $post_id, $result );
            $this->store_verification_meta( $post_id, $result );
        }

        return $result;
    }

    public function batch_verify( string $image_path, string $original_path, int $post_id = 0, int $max_retries = 2 ): array {
        $attempt = 0;
        $last_result = null;

        while ( $attempt <= $max_retries ) {
            $result = $this->verify_image_removal( $image_path, $original_path, $post_id );

            if ( $result['clean'] || $attempt === $max_retries ) {
                return $result;
            }

            $attempt++;
            usleep( 500000 );
        }

        return $last_result ?? $this->build_error_result( 'Max retries exceeded', $post_id );
    }

    public function get_verification_providers(): array {
        return $this->chain_runner->get_providers();
    }

    private function build_error_result( string $error, int $post_id ): array {
        Logger::error( 'verification_error', $post_id, [ 'error' => $error ] );
        return [
            'clean' => true,
            'issues' => [],
            'details' => $error,
            'confidence' => 0.0,
            'audit_log' => [],
        ];
    }

    private function log_verification_failure( int $post_id, array $result ): void {
        Logger::warning( Config::LOG_ACTION_IMAGE_VERIFICATION, $post_id, [
            'issues' => $result['issues'],
            'confidence' => $result['confidence'],
            'details' => $result['details'],
        ], '200' );
    }

    private function store_verification_meta( int $post_id, array $result ): void {
        update_post_meta( $post_id, Config::META_VERIFICATION_ISSUES, $result['issues'] );
        update_post_meta( $post_id, Config::META_VERIFICATION_DETAILS, $result['details'] );
        update_post_meta( $post_id, Config::META_VERIFICATION_CONFIDENCE, $result['confidence'] );
        update_post_meta( $post_id, Config::META_VERIFICATION_PROVIDER, $result['audit_log'][0]['provider'] ?? '' );
    }
}