<?php
$current = [
    'prf.hn', 'awin1.com', 'shareasale.com', 'cjmp.gw',
    'jdoqocy.com', 'tkqlhce.com', 'anrdoezrs.net', 'dpbolvw.net',
    'kqzyfj.com', 'qksrv.net', 'click.linksynergy.com', 'rd.bizrate.com',
    'commission-junction.com', 'impact.com', 'impactradius.com',
    'flexlinkspro.com', 'tracking.flexlinks.com', 'referralrock.com',
    'partnerstack.com', 'getrewardful.com', 'tapfiliate.com',
    'leaddyno.com', 'refersion.com', 'ambassador.com',
];

$candidates = [
    'emjcd.com',
    'linksynergy.com', 'rakuten.com',
    'avangate.com', 'shareit.com', 'regnow.com',
    'digistore24.com',
    'hop.clickbank.net', 'clickbank.com',
    'ad.admitad.com',
    'clk.tradedoubler.com', 'tradedoubler.com',
    'track.webgains.com',
    'postaffiliatepro.com',
    'xtsl.net', '9w9.io', 'irs01.com',
    'incomeaccess.com',
    'go.hasoffers.com',
    'performancepartner.com',
    'linkconnector.com',
    'gopajam.com', 'pjatracker.com',
    'affiliatewindow.com', 'zanox.com',
    'cj.com',
    'referralcandy.com',
];

$new = [];
foreach ($candidates as $c) {
    $is_covered = false;
    foreach ($current as $cur) {
        if ($c === $cur) { $is_covered = true; break; }
        if (substr($c, -(strlen('.' . $cur))) === '.' . $cur) { $is_covered = true; break; }
    }
    if (!$is_covered) {
        $new[] = $c;
    }
}

echo "Net-new domains to add (" . count($new) . "):\n";
foreach ($new as $d) echo "  $d\n";

echo "\nFull combined list (" . (count($current) + count($new)) . "):\n";
$all = array_merge($current, $new);
foreach ($all as $d) echo "$d\n";
