<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class VideoProcessor {

	private $temp_dir;
	private $ffmpeg_path;
	public $last_error = '';

	public function __construct() {
		$this->temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $this->temp_dir ) ) {
			wp_mkdir_p( $this->temp_dir );
		}
		$this->ffmpeg_path = $this->find_ffmpeg();
	}

	/**
	 * Extract sample frames from video for analysis.
	 *
	 * @param string $video_path Path to input video.
	 * @param int    $num_frames Number of frames to extract (default 3).
	 * @return array List of extracted frame file paths.
	 */
	public function extract_frames( string $video_path, int $num_frames = 3 ): array {
		if ( ! file_exists( $video_path ) ) {
			Logger::warning( 'video_frame_extract_file_missing', null, [ 'path' => $video_path ], '404' );
			return [];
		}

		$duration = $this->get_video_duration( $video_path );
		if ( $duration <= 0 ) {
			Logger::warning( 'video_frame_extract_duration_zero', null, [ 'path' => $video_path ], '400' );
			return [];
		}

		$frames = [];
		$interval = max( 1, (int) floor( $duration / ( $num_frames + 1 ) ) );

		for ( $i = 1; $i <= $num_frames; $i++ ) {
			$timestamp = $interval * $i;
			$out_path = $this->temp_dir . '/frame_' . uniqid() . '.jpg';

			$cmd = sprintf(
				'%s -hide_banner -loglevel error -ss %d -i %s -frames:v 1 -q:v 2 %s 2>&1',
				escapeshellarg( $this->ffmpeg_path ),
				$timestamp,
				escapeshellarg( $video_path ),
				escapeshellarg( $out_path )
			);

			@exec( $cmd, $output, $ret );
			if ( $ret === 0 && file_exists( $out_path ) && filesize( $out_path ) > 100 ) {
				$frames[] = $out_path;
			}
		}

		Logger::info( Config::LOG_ACTION_VIDEO_FRAME_ANALYSIS, null, [
			'video' => basename( $video_path ),
			'duration' => $duration,
			'frames_extracted' => count( $frames ),
		], '200' );

		return $frames;
	}

	/**
	 * Get video duration in seconds.
	 *
	 * @param string $video_path Path to video file.
	 * @return float Duration in seconds, or 0 on failure.
	 */
	public function get_video_duration( string $video_path ): float {
		$cmd = sprintf(
			'%s -hide_banner -i %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $video_path )
		);

		@exec( $cmd, $output, $ret );

		$joined = implode( "\n", $output );
		if ( preg_match( '/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/', $joined, $m ) ) {
			$hours   = (float) $m[1];
			$minutes = (float) $m[2];
			$seconds = (float) $m[3];
			return ( $hours * 3600 ) + ( $minutes * 60 ) + $seconds;
		}

		return 0.0;
	}

	/**
	 * Get video dimensions.
	 *
	 * @param string $video_path Path to video file.
	 * @return array Associative array with 'width' and 'height'.
	 */
	public function get_video_dimensions( string $video_path ): array {
		$cmd = sprintf(
			'%s -hide_banner -i %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $video_path )
		);

		@exec( $cmd, $output, $ret );

		$joined = implode( "\n", $output );
		if ( preg_match( '/Stream.*Video:.*\s(\d+)x(\d+)/', $joined, $m ) ) {
			return [ 'width' => (int) $m[1], 'height' => (int) $m[2] ];
		}

		return [ 'width' => 0, 'height' => 0 ];
	}

	/**
	 * Crop video to a specific region.
	 *
	 * @param string $input_path  Path to input video.
	 * @param array  $region      Region with x, y, w, h as percentages (0.0-1.0).
	 * @param string $output_path Path to output video.
	 * @return bool True on success.
	 */
	public function crop_video( string $input_path, array $region, string $output_path ): bool {
		$dims = $this->get_video_dimensions( $input_path );
		if ( $dims['width'] === 0 || $dims['height'] === 0 ) {
			Logger::warning( 'video_crop_dims_invalid', null, [ 'path' => $input_path ], '400' );
			return false;
		}

		$x = (int) round( $dims['width'] * ( $region['x'] ?? 0 ) );
		$y = (int) round( $dims['height'] * ( $region['y'] ?? 0 ) );
		$w = (int) round( $dims['width'] * ( $region['w'] ?? 1 ) );
		$h = (int) round( $dims['height'] * ( $region['h'] ?? 1 ) );

		$w = $this->to_even( $w );
		$h = $this->to_even( $h );
		$x = min( $x, $dims['width'] - $w );
		$y = min( $y, $dims['height'] - $h );
		$x = max( 0, $x );
		$y = max( 0, $y );

		$cmd = sprintf(
			'%s -hide_banner -loglevel error -i %s -vf "crop=%d:%d:%d:%d" -c:v libx264 -crf 18 -preset fast -c:a copy %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $input_path ),
			$w, $h, $x, $y,
			escapeshellarg( $output_path )
		);

		@exec( $cmd, $output, $ret );
		$success = ( $ret === 0 && file_exists( $output_path ) && filesize( $output_path ) > 100 );

		if ( $success ) {
			Logger::info( Config::LOG_ACTION_VIDEO_CROPPED, null, [
				'input' => basename( $input_path ),
				'crop' => [ 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h ],
				'output_size' => filesize( $output_path ),
			], '200' );
		} else {
			Logger::warning( 'video_crop_failed', null, [
				'input' => basename( $input_path ),
				'error' => implode( "\n", $output ),
				'cmd'   => $cmd,
			], '500' );
		}

		return $success;
	}

	/**
	 * Compose final reel: heading image + video + brand bar on a canvas.
	 *
	 * @param string $video_path    Path to (cropped) video.
	 * @param string $heading_path  Path to heading PNG image.
	 * @param string $brand_bar_path Path to brand bar PNG image.
	 * @param int    $canvas_width  Canvas width (default 1080).
	 * @param int    $canvas_height Canvas height (default 1920).
	 * @param string $output_path   Path to output reel.
	 * @param string $top_logo_path Optional path to top-corner logo overlay PNG.
	 * @return bool True on success.
	 */
	public function compose_reel(
		string $video_path,
		string $heading_path,
		string $brand_bar_path,
		int $canvas_width = 1080,
		int $canvas_height = 1920,
		string $output_path,
		string $top_logo_path = '',
		array $brand = [],
		int $heading_y_offset = 0,
		bool $mute_audio = false,
		string $replacement_music_path = '',
		?array $logo_zone = null
	): bool {
		if ( ! file_exists( $video_path ) ) {
			Logger::warning( 'reel_compose_video_missing', null, [ 'video' => $video_path ], '404' );
			return false;
		}

		// Parse heading_padding for overlay positioning (top/left offset so words aren't cropped).
		// Video-specific padding (video_heading_padding) takes precedence over
		// the shared heading_padding so collage tweaks never move the video heading.
		$heading_padding_css = $brand['video_heading_padding'] ?? '';
		if ( $heading_padding_css === '' ) {
			$heading_padding_css = $brand['heading_padding'] ?? 'clamp(4px,0.5cqh,8px) clamp(10px,1.5cqw,16px) clamp(4px,0.5cqh,8px) clamp(10px,1.5cqw,16px)';
		}
		$h_padding = $this->parse_padding_h(
			$heading_padding_css,
			$canvas_width,
			$canvas_height
		);

		$heading_h = 0;
		$brand_h = 0;

		if ( ! empty( $heading_path ) && file_exists( $heading_path ) ) {
			$heading_info = @getimagesize( $heading_path );
			if ( $heading_info ) {
				$heading_h = (int) round( $heading_info[1] * ( $canvas_width / $heading_info[0] ) );
			}
		}

		if ( ! empty( $brand_bar_path ) && file_exists( $brand_bar_path ) ) {
			$brand_info = @getimagesize( $brand_bar_path );
			if ( $brand_info ) {
				$brand_h = (int) round( $brand_info[1] * ( $canvas_width / $brand_info[0] ) );
			}
		}

		if ( $heading_h === 0 ) {
			// Fallback: use video heading height proportion from brand settings
			// (default 25% of canvas height, matches VideoRenderer fallback).
			// Video-only setting takes precedence over the shared one.
			$heading_h_pct = floatval( $brand['video_heading_height_proportion'] ?? '' );
			if ( $heading_h_pct <= 0 ) {
				$heading_h_pct = floatval( $brand['heading_height_proportion'] ?? '25.0' );
			}
			$heading_h = ( $heading_h_pct > 0 )
				? (int) round( $canvas_height * $heading_h_pct / 100.0 )
				: (int) ( $canvas_height * 0.12 );
		}
		if ( $brand_h === 0 ) {
			$brand_h = (int) ( $canvas_height * 0.10 );
		}

		// Do NOT cap heading height here. The heading image is already
		// trimmed by -trim +repage in render_text_to_png(), so its pixel
		// height equals the visible text height. Capping creates a mismatch
		// between heading_h (video start position) and the actual heading
		// image extent, producing a visible gap between heading and video.

		$video_area_h = $canvas_height - $heading_h - $brand_h;
		$video_area_h = $this->to_even( $video_area_h );

		// Detect source orientation and compute letterbox fit for ALL orientations.
		// Video content will be centered in video_area_h with black bars top/bottom.
		// Heading sits just above video content, brand bar just below.
		$source_dims   = $this->get_video_dimensions( $video_path );
		$source_w      = $source_dims['width'] ?? 0;
		$source_h      = $source_dims['height'] ?? 0;
		$source_ar     = ( $source_w > 0 && $source_h > 0 ) ? ( $source_w / $source_h ) : 0.0;

		Logger::info( 'video_fit_planned', null, [
			'source'        => $source_w . 'x' . $source_h,
			'source_ar'      => round( $source_ar, 3 ),
			'video_area'     => $canvas_width . 'x' . $video_area_h,
			'fit_mode'       => 'letterbox_all',
		], '200' );

		// Pre-compute fitted video bounds for content-adjacent overlay positioning.
		// Letterbox: scale to fit INSIDE video_area (contain), pad remaining with black.
		$video_content_top    = $heading_h;
		$video_content_bottom = $heading_h + $video_area_h;
		$fitted_w             = $canvas_width;
		$fitted_h             = $video_area_h;
		$pad_top              = 0;
		$pad_bottom           = 0;

		if ( $source_ar > 0.0 ) {
			// Calculate scale to fit source inside canvas_width x video_area_h
			$scale_w = $canvas_width / $source_w;
			$scale_h = $video_area_h / $source_h;
			$scale   = min( $scale_w, $scale_h );

			$fitted_w = (int) round( $source_w * $scale );
			$fitted_h = (int) round( $source_h * $scale );
			$fitted_w = $this->to_even( $fitted_w );
			$fitted_h = $this->to_even( $fitted_h );

			// Vertical padding (letterbox bars) inside video_area_h
			$pad_top    = (int) round( ( $video_area_h - $fitted_h ) / 2 );
			$pad_bottom = $video_area_h - $fitted_h - $pad_top;

			// Actual video content position on canvas
			$video_content_top    = $heading_h + $pad_top;
			$video_content_bottom = $video_content_top + $fitted_h;

			Logger::info( 'video_letterbox_computed', null, [
				'source'           => $source_w . 'x' . $source_h,
				'fitted'           => $fitted_w . 'x' . $fitted_h,
				'pad_top'          => $pad_top,
				'pad_bottom'       => $pad_bottom,
				'video_content_top'    => $video_content_top,
				'video_content_bottom' => $video_content_bottom,
			], '200' );
		}

		$filter_parts = [];
		$inputs = [];

		$filter_parts[] = sprintf(
			'color=c=black:s=%dx%d:d=999 [canvas]',
			$canvas_width, $canvas_height
		);

		$inputs[] = '-i ' . escapeshellarg( $video_path );

		// UNIVERSAL LETTERBOX: contain + pad for ALL orientations.
		// Scale to fit inside canvas_width x video_area_h, pad with black.
		$filter_parts[] = sprintf(
			'[0:v]scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,setpts=PTS-STARTPTS [vid]',
			$canvas_width,
			$video_area_h,
			$canvas_width,
			$video_area_h
		);

		// Overlay fitted video at heading_h (top of video area).
		// The pad filter above centers video vertically within video_area_h.
		$filter_parts[] = sprintf(
			'[canvas][vid]overlay=(W-w)/2:%d:shortest=1 [tmp1]',
			$heading_h
		);

		$input_idx = 1;
		$tmp_label = 'tmp1';
		if ( ! empty( $heading_path ) && file_exists( $heading_path ) ) {
			$inputs[] = '-i ' . escapeshellarg( $heading_path );
			// Scale heading to fit within horizontal padding (not full canvas width)
			// so it doesn't overflow the right edge when overlaid at h_padding['left'].
			$heading_scale_w = $canvas_width - $h_padding['left'] - $h_padding['right'];
			$filter_parts[] = sprintf(
				'[%d:v]scale=%d:-1 [hdg]',
				$input_idx, $heading_scale_w
			);
			// Heading sits just above video content with horizontal padding.
			// Vertical position: video_content_top - heading_h - h_padding['bottom'] - heading_y_offset
			$heading_y = max( 0, $video_content_top - $heading_h - $h_padding['bottom'] - $heading_y_offset );
			$filter_parts[] = sprintf(
				'[%s][hdg]overlay=%d:%d [tmp2]',
				$tmp_label, $h_padding['left'], $heading_y
			);
			$tmp_label = 'tmp2';
			$input_idx++;
		}

		// Top-corner logo overlay — adapts to canvas dimensions and logo_position.
		// Position relative to video content top (not canvas top).
		if ( ! empty( $top_logo_path ) && file_exists( $top_logo_path ) ) {
			$inputs[] = '-i ' . escapeshellarg( $top_logo_path );

			// When a logo_zone is provided (per-campaign source-logo removal
			// feature), the brand logo must land at the EXACT same region
			// the source logo was removed from — regardless of where the
			// configured top-left/top-right padding would have placed it.
			// Otherwise fall back to the brand setting's logo_position.
			if ( ! empty( $logo_zone ) && isset( $logo_zone['x'], $logo_zone['y'], $logo_zone['w'], $logo_zone['h'] )
				&& (float) $logo_zone['w'] > 0 && (float) $logo_zone['h'] > 0 ) {
				$logo_canvas_w = (int) round( (float) $logo_zone['w'] * $fitted_w );
				$logo_canvas_h = (int) round( (float) $logo_zone['h'] * $fitted_h );
				$logo_canvas_x = (int) round( ( $canvas_width - $fitted_w ) / 2 + (float) $logo_zone['x'] * $fitted_w );
				$logo_canvas_y = (int) round( $video_content_top + (float) $logo_zone['y'] * $fitted_h );
				$logo_canvas_w = $this->to_even( $logo_canvas_w );
				$logo_canvas_h = $this->to_even( $logo_canvas_h );
				$filter_parts[] = sprintf(
					'[%d:v]scale=%d:%d:force_original_aspect_ratio=decrease [tlogo]',
					$input_idx, max( 2, $logo_canvas_w ), max( 2, $logo_canvas_h )
				);
				$filter_parts[] = sprintf(
					'[%s][tlogo]overlay=%d:%d [tmp_tlogo]',
					$tmp_label, $logo_canvas_x, $logo_canvas_y
				);
			} else {
				$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;

				// Scale padding proportionally to canvas size (not fixed pixels).
				$pad_x = (int) round( $canvas_width * 0.02 );
				$pad_y = (int) round( $canvas_height * 0.012 );
				if ( ! empty( $brand['brand_bar_padding'] ) ) {
					$parsed = $this->parse_padding_h( $brand['brand_bar_padding'], $canvas_width, $canvas_height );
					$pad_x = $parsed['left'] ?: $pad_x;
					$pad_y = $parsed['top'] ?: (int) round( $pad_x * 0.8 );
				}
				// Y offset: sit on the video content area, below the heading.
				$pad_y = $video_content_top + $pad_y;

				// Max dimensions from brand settings (already resolved by render_top_logo_png).
				$max_w = (int) round( $this->parse_css_size( $brand['logo_max_width_top'] ?? '110px', $canvas_width, $canvas_height ) );
				$max_h = (int) round( $this->parse_css_size( $brand['logo_max_height_top'] ?? '34px', $canvas_width, $canvas_height ) );
				if ( $max_w <= 0 ) $max_w = (int) ( $canvas_width * 0.08 );
				if ( $max_h <= 0 ) $max_h = (int) ( $canvas_height * 0.04 );
				$filter_parts[] = sprintf(
					'[%d:v]scale=%d:%d:force_original_aspect_ratio=decrease [tlogo]',
					$input_idx, $max_w, $max_h
				);
				// Right-aligned logos use FFmpeg expression: W = canvas width, w = overlay width.
				if ( $logo_position === 'top-right' ) {
					$overlay_pos = sprintf( 'W-w-%d:%d', $pad_x, $pad_y );
				} else {
					$overlay_pos = sprintf( '%d:%d', $pad_x, $pad_y );
				}
				$filter_parts[] = sprintf(
					'[%s][tlogo]overlay=%s [tmp_tlogo]',
					$tmp_label, $overlay_pos
				);
			}
			$tmp_label = 'tmp_tlogo';
			$input_idx++;
		}

		if ( ! empty( $brand_bar_path ) && file_exists( $brand_bar_path ) ) {
			$inputs[] = '-i ' . escapeshellarg( $brand_bar_path );
			$filter_parts[] = sprintf(
				'[%d:v]scale=%d:-1 [br]',
				$input_idx, $canvas_width
			);
			// Brand bar sits just below video content.
			$brand_y = $video_content_bottom;
			$filter_parts[] = sprintf(
				'[%s][br]overlay=0:%d [out]',
				$tmp_label, $brand_y
			);
		} else {
			$filter_parts[] = sprintf( '[%s]copy [out]', $tmp_label );
		}

		$inputs_str = implode( ' ', $inputs );
		$filter_str = implode( '; ', $filter_parts );

		// When muting, a replacement track MUST be present so the reel is never
		// left silent. If the caller passed an empty/missing path, fall back to
		// the bundled default track. If even that is unavailable, do NOT mute
		// (keep the original audio) rather than emit a silent (-an) video.
		if ( $mute_audio ) {
			if ( $replacement_music_path === '' || ! file_exists( $replacement_music_path ) ) {
				$replacement_music_path = Config::get_replacement_music_path( true );
			}
			if ( $replacement_music_path === '' || ! file_exists( $replacement_music_path ) ) {
				// No track available anywhere: preserve source audio instead of
				// producing a dead-silent video.
				$mute_audio = false;
				Logger::warning( 'reel_mute_skipped_no_music', null, [
					'video' => basename( $video_path ),
				], '200' );
			}
		}

		$use_replacement_music = ( $mute_audio && $replacement_music_path !== '' && file_exists( $replacement_music_path ) );
		if ( $use_replacement_music ) {
			$duration = $this->get_video_duration( $video_path );
			$music_input_idx = count( $inputs );
			$inputs[] = '-i ' . escapeshellarg( $replacement_music_path );
			$inputs_str = implode( ' ', $inputs );
			$filter_parts[] = sprintf(
				'[%d:a]aloop=loop=-1:size=2e+09,atrim=0:%s,volume=0.7[bg]',
				$music_input_idx,
				max( 1, $duration )
			);
			$filter_parts[] = '[bg]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=mono[aout]';
			$filter_str = implode( '; ', $filter_parts );
			$audio_args = '-map "[aout]" -c:a aac -b:a 128k';
		} else {
			$audio_args = $mute_audio ? '-an' : '-map 0:a? -c:a aac -b:a 128k';
		}

		$cmd = sprintf(
			'%s -hide_banner -loglevel error %s -filter_complex %s -map "[out]" %s -c:v libx264 -crf 18 -preset fast -movflags +faststart %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			$inputs_str,
			escapeshellarg( $filter_str ),
			$audio_args,
			escapeshellarg( $output_path )
		);

		$this->last_error = '';
		@exec( $cmd, $output, $ret );
		$success = ( $ret === 0 && file_exists( $output_path ) && filesize( $output_path ) > 1000 );

		if ( $success ) {
			Logger::info( Config::LOG_ACTION_VIDEO_REEL_GENERATED, null, [
				'video' => basename( $video_path ),
				'heading' => ! empty( $heading_path ) ? basename( $heading_path ) : 'none',
				'brand_bar' => ! empty( $brand_bar_path ) ? basename( $brand_bar_path ) : 'none',
				'canvas' => $canvas_width . 'x' . $canvas_height,
				'output_size' => filesize( $output_path ),
				'audio_muted' => $mute_audio,
				'replacement_music' => $use_replacement_music ? basename( $replacement_music_path ) : 'none',
			], '200' );

			// Prepend poster frame so the first frame shows video content, not black.
			// Social media platforms (WhatsApp, Instagram, etc.) use the first frame
			// as the video cover. Without this, the cover is a black screen.
			$poster_result = $this->prepend_poster_frame( $output_path );
			if ( ! empty( $poster_result ) && file_exists( $poster_result ) ) {
				@unlink( $output_path );
				rename( $poster_result, $output_path );
			}
		} else {
			$this->last_error = implode( "\n", $output );
			Logger::warning( 'reel_compose_failed', null, [
				'ret' => $ret,
				'output_exists' => file_exists( $output_path ),
				'output_size' => file_exists( $output_path ) ? filesize( $output_path ) : 0,
				'error' => $this->last_error,
				'filter' => $filter_str,
				'cmd' => $cmd,
			], '500' );
		}

		return $success;
	}

	/**
	 * Scale video to fit within a given width, preserving aspect ratio.
	 *
	 * @param string $input_path  Path to input video.
	 * @param int    $target_width Target width.
	 * @param string $output_path Path to output video.
	 * @return bool True on success.
	 */
	public function scale_video( string $input_path, int $target_width, string $output_path ): bool {
		$this->last_error = '';
		$cmd = sprintf(
			'%s -hide_banner -loglevel error -i %s -vf "scale=%d:-2" -c:v libx264 -crf 18 -preset fast -c:a copy %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $input_path ),
			$target_width,
			escapeshellarg( $output_path )
		);

		@exec( $cmd, $output, $ret );
		$success = ( $ret === 0 && file_exists( $output_path ) && filesize( $output_path ) > 100 );

		if ( $success ) {
			Logger::info( 'video_scaled', null, [
				'input'  => basename( $input_path ),
				'width'  => $target_width,
				'output_size' => filesize( $output_path ),
			], '200' );
		} else {
			$this->last_error = implode( "\n", $output );
			Logger::warning( 'video_scale_failed', null, [
				'input'  => basename( $input_path ),
				'error'  => $this->last_error,
				'cmd'    => $cmd,
			], '500' );
		}

		return $success;
	}

	/**
	 * Remove a corner logo from a source video using FFmpeg's `removelogo` filter.
	 *
	 * Generates a static binary mask (white = area to inpaint, black = keep) sized to
	 * the user-supplied rectangle (as fractions of source width/height), then runs a
	 * single-pass FFmpeg removelogo over the whole video. The brand logo placed later
	 * in compose_reel() covers the inpainted region, so any residual smudge is not
	 * visible in the final reel.
	 *
	 * @param string $input_path   Source video.
	 * @param string $output_path  Destination for cleaned video.
	 * @param array  $logo_zone    Associative array with keys x, y, w, h (0.0-1.0 fractions).
	 * @return bool True on success.
	 */
	public function remove_logo_with_removelogo( string $input_path, string $output_path, array $logo_zone ): bool {
		if ( ! file_exists( $input_path ) ) {
			Logger::warning( 'video_logo_removal_input_missing', null, [ 'path' => $input_path ], '404' );
			return false;
		}

		if ( ! isset( $logo_zone['x'], $logo_zone['y'], $logo_zone['w'], $logo_zone['h'] ) ) {
			Logger::warning( 'video_logo_removal_zone_incomplete', null, [ 'zone' => $logo_zone ], '400' );
			return false;
		}

		$x_pct = (float) $logo_zone['x'];
		$y_pct = (float) $logo_zone['y'];
		$w_pct = (float) $logo_zone['w'];
		$h_pct = (float) $logo_zone['h'];
		$w_pct = max( 0.01, min( 1.0, $w_pct ) );
		$h_pct = max( 0.01, min( 1.0, $h_pct ) );
		$x_pct = max( 0.0, min( 1.0 - $w_pct, $x_pct ) );
		$y_pct = max( 0.0, min( 1.0 - $h_pct, $y_pct ) );

		$dims = $this->get_video_dimensions( $input_path );
		$src_w = (int) ( $dims['width'] ?? 0 );
		$src_h = (int) ( $dims['height'] ?? 0 );
		if ( $src_w <= 0 || $src_h <= 0 ) {
			Logger::warning( 'video_logo_removal_dims_invalid', null, [ 'path' => $input_path ], '400' );
			return false;
		}

		$mx = (int) round( $src_w * $x_pct );
		$my = (int) round( $src_h * $y_pct );
		$mw = max( 16, (int) round( $src_w * $w_pct ) );
		$mh = max( 16, (int) round( $src_h * $h_pct ) );
		if ( $mw % 2 !== 0 ) $mw++;
		if ( $mh % 2 !== 0 ) $mh++;
		$mx2 = $mx + $mw - 1;
		$my2 = $my + $mh - 1;
		if ( $mx2 >= $src_w ) { $mw = $src_w - $mx; $mx2 = $src_w - 1; }
		if ( $my2 >= $src_h ) { $mh = $src_h - $my; $my2 = $src_h - 1; }

		$mask_path = $this->temp_dir . '/logo_mask_' . uniqid( 'mask_', true ) . '.png';

		$convert = Config::IM_CONVERT_PATH;
		if ( empty( $convert ) || ! function_exists( 'exec' ) ) {
			Logger::warning( 'video_logo_removal_no_imagemagick', null, [], '500' );
			return false;
		}

		$mask_cmd = sprintf(
			'%s -size %dx%d xc:black -fill white -draw "rectangle %d,%d %d,%d" %s 2>&1',
			escapeshellarg( $convert ),
			$src_w, $src_h,
			$mx, $my, $mx2, $my2,
			escapeshellarg( $mask_path )
		);
		@exec( $mask_cmd, $mask_out, $mask_rc );
		if ( $mask_rc !== 0 || ! file_exists( $mask_path ) || filesize( $mask_path ) < 100 ) {
			Logger::warning( 'video_logo_removal_mask_failed', null, [
				'zone'  => [ 'x' => $x_pct, 'y' => $y_pct, 'w' => $w_pct, 'h' => $h_pct ],
				'error' => implode( "\n", $mask_out ),
			], '500' );
			if ( file_exists( $mask_path ) ) @unlink( $mask_path );
			return false;
		}

		$filter = sprintf( 'removelogo=%s', escapeshellarg( $mask_path ) );

		$cmd = sprintf(
			'%s -hide_banner -loglevel error -i %s -vf %s -c:v libx264 -crf 18 -preset fast -c:a copy %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $input_path ),
			escapeshellarg( $filter ),
			escapeshellarg( $output_path )
		);

		@exec( $cmd, $output, $ret );
		$success = ( $ret === 0 && file_exists( $output_path ) && filesize( $output_path ) > 100 );
		@unlink( $mask_path );

		if ( $success ) {
			Logger::info( 'video_logo_removed', null, [
				'input' => basename( $input_path ),
				'zone'  => [ 'x' => $x_pct, 'y' => $y_pct, 'w' => $w_pct, 'h' => $h_pct ],
				'mask'  => $mw . 'x' . $mh . '@' . $mx . ',' . $my,
				'output'=> filesize( $output_path ),
			], '200' );
		} else {
			Logger::warning( 'video_logo_removal_failed', null, [
				'input' => basename( $input_path ),
				'zone'  => [ 'x' => $x_pct, 'y' => $y_pct, 'w' => $w_pct, 'h' => $h_pct ],
				'error' => implode( "\n", $output ),
				'cmd'   => $cmd,
			], '500' );
			if ( file_exists( $output_path ) ) @unlink( $output_path );
		}

		return $success;
	}

	/**
	 * Trim video to a maximum duration.
	 *
	 * @param string $input_path  Path to input video.
	 * @param float  $max_duration Maximum duration in seconds.
	 * @param string $output_path Path to output video.
	 * @return bool True on success.
	 */
	public function trim_video( string $input_path, float $max_duration, string $output_path ): bool {
		$duration = $this->get_video_duration( $input_path );
		if ( $duration <= $max_duration ) {
			copy( $input_path, $output_path );
			return true;
		}

		$cmd = sprintf(
			'%s -hide_banner -loglevel error -i %s -t %s -c copy %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $input_path ),
			$this->format_timestamp( $max_duration ),
			escapeshellarg( $output_path )
		);

		@exec( $cmd, $output, $ret );
		return ( $ret === 0 && file_exists( $output_path ) && filesize( $output_path ) > 100 );
	}

	/**
	 * Render text to PNG using Pango/ImageMagick (reuses existing plugin infrastructure).
	 *
	 * @param string $text      Text to render.
	 * @param string $font_font  Font family name.
	 * @param int    $font_size  Font size.
	 * @param string $fill_color Hex color.
	 * @param int    $max_width  Maximum width for text wrapping.
	 * @param string $language   'en' or 'ur'.
	 * @return string|false Path to rendered PNG, or false on failure.
	 */
	public function render_text_to_png( string $text, string $font_family, int $font_size, string $fill_color, int $max_width, string $language = 'ur', string $bg_color = '', int $bar_height = 0, int $canvas_width = 0 ) {
		if ( empty( $text ) || trim( $text ) === '' ) {
			return false;
		}

		$font_path = $this->resolve_font_path( $font_family );
		if ( empty( $font_path ) || ! file_exists( $font_path ) ) {
			Logger::warning( 'video_text_font_missing', null, [ 'font' => $font_family ], '404' );
			// Fall through to GD fallback below (was: return false) — mirrors
			// ImageRenderer::pango_render() which falls back to gd_text_fallback()
			// instead of silently blanking the heading.
		}

		if ( $font_path && file_exists( $font_path ) && function_exists( 'exec' ) ) {
			$pango_size = $font_size * 1024;

			// Wrap text before Pango rendering so long Urdu text breaks to
			// multiple lines instead of flowing off-canvas. Pango's
			// pango:@file renderer does NOT auto-wrap; without this, a
			// long headline overflows max_width and gets clipped by
			// `-trim +repage`. Pre-wrapping produces a properly bounded
			// multi-line PNG that the heading bar can contain.
			$wrapped_text    = $this->wrap_text_for_pango( $text, $font_path, $font_size, $max_width, $language );
			$escaped_text    = htmlspecialchars( $wrapped_text, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
			$escaped_font    = htmlspecialchars( $font_family, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
			$escaped_color   = htmlspecialchars( $fill_color, ENT_XML1 | ENT_QUOTES, 'UTF-8' );

			// RTL right-bearing compensation: Pango anchors RTL text at the
			// right edge of the layout, so the first character's right bearing
			// extends beyond the canvas and is clipped during rasterization.
			// Prepending spaces to each line pushes the text LEFT, placing the
			// right bearing within the canvas. After -trim the spaces vanish
			// (transparent) but the right bearing (non-transparent) is preserved.
			if ( $language === 'ur' ) {
				$rtl_margin = str_repeat( ' ', 3 );
				$escaped_lines = explode( "\n", $escaped_text );
				$escaped_lines = array_map( function( $line ) use ( $rtl_margin ) {
					return $rtl_margin . $line;
				}, $escaped_lines );
				$escaped_text = implode( "\n", $escaped_lines );
			}

			$fc_file = $this->ensure_fontconfig();
			$old_fc = getenv( 'FONTCONFIG_FILE' );
			if ( $fc_file ) {
				putenv( 'FONTCONFIG_FILE=' . $fc_file );
			}

			$markup = sprintf(
				'<span font_family="%s" size="%d" foreground="%s">%s</span>',
				$escaped_font, $pango_size, $escaped_color, $escaped_text
			);

			$tmp_markup = $this->temp_dir . '/video_pango_' . uniqid() . '.tmp';
			$tmp_png = $this->temp_dir . '/video_pango_' . uniqid() . '.tmp.png';

			file_put_contents( $tmp_markup, $markup );

			$rtl_define = $language === 'ur' ? ' -define pango:direction=rtl' : '';
			// Pass the resolved .ttf path directly via -font so Pango
			// resolves Urdu ligatures without depending on fontconfig.
			// Without this, a broken/missing fontconfig causes Pango to
			// fall back to a system font that renders each character
			// independently (no glyph joining for Urdu/Arabic scripts).
			$font_flag = ' -font ' . escapeshellarg( $font_path );

			$cmd = sprintf(
				'%s -background none -alpha on%s%s -size %dx pango:@%s -trim +repage PNG32:%s',
				escapeshellarg( Config::IM_CONVERT_PATH ),
				$rtl_define,
				$font_flag,
				$max_width,
				escapeshellarg( $tmp_markup ),
				escapeshellarg( $tmp_png )
			);

			@exec( $cmd . ' 2>&1', $out, $ret );

			@unlink( $tmp_markup );
			if ( $old_fc !== false ) putenv( 'FONTCONFIG_FILE=' . $old_fc );

			if ( $ret === 0 && file_exists( $tmp_png ) && filesize( $tmp_png ) >= 50 ) {
				// Re-pad the trimmed PNG so Urdu Nastaliq ascenders/descenders
				// (dots, marks above the baseline) aren't clipped by `-trim +repage`.
				// Urdu grows ~20% above and ~30% below the Latin baseline; add
				// proportional padding to preserve glyph integrity before
				// compositing onto the background bar.
				if ( $language === 'ur' || stripos( $font_path, 'nastaliq' ) !== false ) {
					$pad_top    = max( 2, (int) round( $font_size * 0.18 ) );
					$pad_bottom = max( 2, (int) round( $font_size * 0.12 ) );
					$pad_left   = max( 2, (int) round( $font_size * 0.05 ) );
					$pad_right  = max( 4, (int) round( $font_size * 0.50 ) );
					$tmp_png_padded = $this->temp_dir . '/video_pango_padded_' . uniqid() . '.png';
					$pad_cmd = sprintf(
						'%s %s -background none -alpha on -gravity North -splice 0x%d -gravity South -splice 0x%d -gravity West -splice %dx0 -gravity East -splice %dx0 PNG32:%s',
						escapeshellarg( Config::IM_CONVERT_PATH ),
						escapeshellarg( $tmp_png ),
						$pad_top,
						$pad_bottom,
						$pad_left,
						$pad_right,
						escapeshellarg( $tmp_png_padded )
					);
					@exec( $pad_cmd . ' 2>&1', $pad_out, $pad_ret );
					if ( $pad_ret === 0 && file_exists( $tmp_png_padded ) && filesize( $tmp_png_padded ) >= 50 ) {
						@unlink( $tmp_png );
						$tmp_png = $tmp_png_padded;
					} else {
						@unlink( $tmp_png_padded );
					}
				}

				// If a background color is requested, composite the trimmed
				// text onto a solid background — matches the collage pipeline's
				// heading background (heading_bg_color → text_backing_color).
				// Use canvas_width for the bar so the background spans full width.
				$bg_bar_width = ( $canvas_width > 0 ) ? $canvas_width : $max_width;
				if ( ! empty( $bg_color ) ) {
					$bg_composited = $this->heading_composite_on_background( $tmp_png, $bg_color, $bg_bar_width, $bar_height );
					if ( $bg_composited ) {
						@unlink( $tmp_png );
						Logger::info( 'video_heading_pango_success', null, [
							'font_path' => $font_path,
							'font_size' => $font_size,
							'text_len'  => mb_strlen( $text, 'UTF-8' ),
							'language'  => $language,
							'bg_color'  => $bg_color,
						], '200' );
						return $bg_composited;
					}
				}
				Logger::info( 'video_heading_pango_success', null, [
					'font_path' => $font_path,
					'font_size' => $font_size,
					'text_len'  => mb_strlen( $text, 'UTF-8' ),
					'language'  => $language,
				], '200' );
				return $tmp_png;
			}

			Logger::warning( 'video_heading_pango_failed', null, [
				'font_path' => $font_path,
				'error'     => implode( "\n", $out ),
				'cmd'       => $cmd,
			], '500' );
			@unlink( $tmp_png );
		}

		// GD fallback — mirrors ImageRenderer::gd_text_fallback() + wrap_text_gd().
		// Ensures the AI heading still renders when Pango/ImageMagick is unavailable
		// or the requested font file is missing (the prior source of "heading:none").
		return $this->render_text_to_png_gd( $text, $font_path, $font_size, $fill_color, $max_width, $language );
	}

	/**
	 * GD fallback for render_text_to_png — mirrors ImageRenderer::gd_text_fallback().
	 *
	 * @param string       $text       Text to render.
	 * @param string|false $font_path  Resolved font path (may be empty if resolve failed).
	 * @param int          $font_size  Font size in pixels.
	 * @param string       $fill_color Hex color.
	 * @param int          $max_width  Wrap width.
	 * @param string       $language   'en' or 'ur'.
	 * @return string|false PNG path or false.
	 */
	private function render_text_to_png_gd( string $text, $font_path, int $font_size, string $fill_color, int $max_width, string $language ) {
		if ( ! function_exists( 'imagettftext' ) || ! function_exists( 'imagecreatetruecolor' ) ) {
			return false;
		}
		if ( empty( $font_path ) || ! file_exists( $font_path ) ) {
			return false;
		}

		$lines = $this->wrap_text_gd( $text, $font_path, $font_size, $max_width );
		$is_urdu  = ( $language === 'ur' || stripos( $font_path, 'nastaliq' ) !== false );
		$multiplier = $is_urdu ? 2.0 : 1.5;
		$line_height = (int) ( $font_size * $multiplier );
		$ascender_pad = $is_urdu ? (int) ( $font_size * 0.5 ) : 5;
		$total_height = count( $lines ) * $line_height + $ascender_pad + 10;

		$img = imagecreatetruecolor( $max_width, $total_height );
		if ( ! $img ) return false;
		imagesavealpha( $img, true );
		imagealphablending( $img, true );
		$transparent = imagecolorallocatealpha( $img, 0, 0, 0, 127 );
		imagefill( $img, 0, 0, $transparent );

		$rgb = $this->hex_to_rgb( $fill_color );
		$text_alloc = imagecolorallocate( $img, $rgb['r'], $rgb['g'], $rgb['b'] );

		$y = $font_size + $ascender_pad;
		foreach ( $lines as $line ) {
			imagettftext( $img, $font_size, 0, 5, $y, $text_alloc, $font_path, $line );
			$y += $line_height;
		}

		$out_path = $this->temp_dir . '/video_heading_gd_' . uniqid() . '.png';
		$saved = imagepng( $img, $out_path, 1 );
		imagedestroy( $img );

		if ( ! $saved || ! file_exists( $out_path ) ) {
			return false;
		}

		// Trim transparent padding from GD output so heading height
		// matches visible text — avoids gap between heading and video.
		if ( function_exists( 'exec' ) ) {
			$trimmed = $this->temp_dir . '/video_heading_gd_trimmed_' . uniqid() . '.png';
			$trim_cmd = sprintf(
				'%s %s -trim +repage PNG32:%s 2>&1',
				escapeshellarg( Config::IM_CONVERT_PATH ),
				escapeshellarg( $out_path ),
				escapeshellarg( $trimmed )
			);
			@exec( $trim_cmd, $trim_out, $trim_ret );
			if ( $trim_ret === 0 && file_exists( $trimmed ) && filesize( $trimmed ) > 50 ) {
				@unlink( $out_path );
				return $trimmed;
			}
			@unlink( $trimmed );
		}

		return $out_path;
	}

	/**
	 * Word-wrap text for GD rendering — mirrors ImageRenderer::wrap_text_gd().
	 */
	private function wrap_text_gd( string $text, string $font_path, int $font_size, int $max_width ): array {
		$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		$lines = [];
		$current = '';

		foreach ( $words as $word ) {
			$test = $current === '' ? $word : $current . ' ' . $word;
			$bbox = imagettfbbox( $font_size, 0, $font_path, $test );
			$w = isset( $bbox[2] ) ? ( $bbox[2] - $bbox[0] ) : 0;
			if ( $w > $max_width && $current !== '' ) {
				$lines[] = $current;
				$current = $word;
			} else {
				$current = $test;
			}
		}
		if ( $current !== '' ) {
			$lines[] = $current;
		}

		return $lines ?: [ $text ];
	}

	/**
	 * Word-wrap text for Pango rendering and return the joined multi-line
	 * string. Pango's `pango:@file` syntax does NOT auto-wrap on its own —
	 * without explicit newlines, long Urdu strings flow in a single line
	 * that exceeds max_width and gets clipped by `-trim +repage`.
	 *
	 * For Urdu (RTL), word boundaries use the Unicode word-break property
	 * (`\p{Z}` / ` `) which works the same as Latin since Urdu is
	 * space-separated. For very long single tokens (rare in headlines),
	 * falls back to character-break to prevent overflow.
	 *
	 * @param string $text       Headline text.
	 * @param string $font_path  Resolved .ttf path for measurement.
	 * @param int    $font_size  Font size in pixels.
	 * @param int    $max_width  Target max width.
	 * @param string $language   'en' or 'ur'.
	 * @return string Wrapped text with "\n" inserted between lines.
	 */
	private function wrap_text_for_pango( string $text, string $font_path, int $font_size, int $max_width, string $language = 'ur' ): string {
		if ( empty( $text ) || $max_width <= 0 || empty( $font_path ) || ! file_exists( $font_path ) ) {
			return $text;
		}

		$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		if ( empty( $words ) ) {
			return $text;
		}

		$lines     = [];
		$current   = '';
		$word_w_cache = [];

		// HarfBuzz (used by Pango) produces wider output than FreeType
		// metrics for Urdu Nastaliq due to OpenType GSUB/GPOS features
		// (ligatures, kashida, mark positioning). Use 85% of max_width
		// as the wrapping threshold so shaped lines don't overflow.
		$safe_width = ( $language === 'ur' || stripos( $font_path, 'nastaliq' ) !== false )
			? (int) round( $max_width * 0.85 )
			: $max_width;

		$measure = function( $str ) use ( $font_path, $font_size, &$word_w_cache ) {
			$key = md5( $str );
			if ( ! isset( $word_w_cache[ $key ] ) ) {
				$bbox = imagettfbbox( $font_size, 0, $font_path, $str );
				$word_w_cache[ $key ] = isset( $bbox[2] ) ? (int) ( $bbox[2] - $bbox[0] ) : 0;
			}
			return $word_w_cache[ $key ];
		};

		foreach ( $words as $word ) {
			$word_w    = $measure( $word );
			$space_w   = $measure( ' ' );

			// Token wider than safe_width — break it character-by-character.
			if ( $word_w > $safe_width ) {
				if ( $current !== '' ) {
					$lines[] = $current;
					$current = '';
				}
				$chunk = '';
				$chars = preg_split( '//u', $word, -1, PREG_SPLIT_NO_EMPTY );
				foreach ( $chars as $ch ) {
					$test    = $chunk . $ch;
					$test_w  = $measure( $test );
					if ( $test_w > $safe_width && $chunk !== '' ) {
						$lines[]  = $chunk;
						$chunk    = $ch;
					} else {
						$chunk    = $test;
					}
				}
				if ( $chunk !== '' ) {
					$current = $chunk;
				}
				continue;
			}

			$test      = ( $current === '' ) ? $word : $current . ' ' . $word;
			$test_w    = $measure( $test );
			if ( $test_w > $safe_width && $current !== '' ) {
				$lines[]  = $current;
				$current  = $word;
			} else {
				$current  = $test;
			}
		}
		if ( $current !== '' ) {
			$lines[] = $current;
		}

		return implode( "\n", $lines );
	}

	/**
	 * Composite trimmed heading text PNG onto a solid background.
	 * Used when heading_bg_color is set — the collage pipeline renders the
	 * heading inside a div with background-color; the video pipeline must
	 * produce the same look by compositing the Pango text onto a solid bar.
	 *
	 * @param string $text_png   Path to trimmed Pango text PNG.
	 * @param string $bg_color   Hex color (e.g. '#000000').
	 * @param int    $bar_width  Full canvas width for the background bar.
	 * @return string|false Path to composited PNG, or false on failure.
	 */
	private function heading_composite_on_background( string $text_png, string $bg_color, int $bar_width, int $bar_height_override = 0 ) {
		$text_img = @imagecreatefrompng( $text_png );
		if ( ! $text_img ) return false;

		$text_w = imagesx( $text_img );
		$text_h = imagesy( $text_img );

		// Use override height if provided (from heading_height_proportion),
		// otherwise fall back to text height. Always use the LARGER of the two
		// so multi-line Urdu/Nastaliq text is never clipped when centered on
		// the background bar. The override (e.g. 21% canvas height) is a
		// minimum, not a hard cap.
		$bar_height = ( $bar_height_override > 0 ) ? max( $bar_height_override, $text_h ) : $text_h;

		$canvas = imagecreatetruecolor( $bar_width, $bar_height );
		if ( ! $canvas ) {
			imagedestroy( $text_img );
			return false;
		}
		imagesavealpha( $canvas, true );
		imagefill( $canvas, 0, 0, imagecolorallocatealpha( $canvas, 0, 0, 0, 127 ) );

		// Parse background color.
		$bg_rgb = $this->hex_to_rgb( $bg_color );
		$bg_alloc = imagecolorallocate( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'] );
		imagefilledrectangle( $canvas, 0, 0, $bar_width - 1, $bar_height - 1, $bg_alloc );

		// Center text horizontally and vertically on the background bar.
		$x = (int) ( ( $bar_width - $text_w ) / 2 );
		$y = (int) ( ( $bar_height - $text_h ) / 2 );
		imagecopy( $canvas, $text_img, $x, $y, 0, 0, $text_w, $text_h );
		imagedestroy( $text_img );

		$out_path = $this->temp_dir . '/heading_bg_' . uniqid() . '.png';
		$saved = imagepng( $canvas, $out_path );
		imagedestroy( $canvas );

		if ( ! $saved || ! file_exists( $out_path ) ) {
			return false;
		}

		return $out_path;
	}

	/**
	 * Render brand bar to PNG using GD (reuses ImageMagickCompositor logic).
	 *
	 * @param array  $brand Brand settings array.
	 * @param int    $width Canvas width.
	 * @param int    $height Bar height.
	 * @return string|false Path to rendered PNG, or false on failure.
	 */
	public function render_brand_bar_to_png( array $brand, int $width, int $height ) {
		// Honor user-overridable bar height — mirrors ImageMagickCompositor::draw_brand_bar
		// (it reads brand['brand_bar_height_pct'] via Config::DEFAULT_BRAND_BAR_HEIGHT_PCT).
		// Prior behavior hardcoded $height * 0.10 and ignored the user setting.
		$bar_height_pct = floatval( $brand['brand_bar_height_pct'] ?? Config::DEFAULT_BRAND_BAR_HEIGHT_PCT );
		$bar_h = max( 1, (int) round( $height * $bar_height_pct / 100 ) );
		$canvas = imagecreatetruecolor( $width, $bar_h );
		if ( ! $canvas ) return false;

		imagesavealpha( $canvas, true );
		imagealphablending( $canvas, false );

		$bg_css = ! empty( $brand['brand_bar_bg_color'] ) ? $brand['brand_bar_bg_color'] : Config::DEFAULT_BRAND_BAR_BG_COLOR;
		if ( preg_match( '/^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)$/i', $bg_css, $m ) ) {
			$bg_rgb = [ 'r' => (int) $m[1], 'g' => (int) $m[2], 'b' => (int) $m[3] ];
			$bg_alpha = (int) round( ( 1 - (float) $m[4] ) * 127 );
		} else {
			$bg_rgb = $this->hex_to_rgb( $bg_css );
			// Fully opaque — the brand bar is a standalone PNG composited
			// via ffmpeg, not a blended overlay on existing content.
			// ImageMagickCompositor uses alpha 120 because it draws on a
			// live canvas; here the PNG must be solid so ffmpeg compositing
			// shows the actual brand_bar_bg_color, not black canvas through it.
			$bg_alpha = 0;
		}
		$bar_bg = imagecolorallocatealpha( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'], $bg_alpha );
		imagefill( $canvas, 0, 0, $bar_bg );

		imagealphablending( $canvas, true );

		$accent = ! empty( $brand['accent_color'] ) ? $brand['accent_color'] : Config::DEFAULT_BRAND_ACCENT_COLOR;
		$show_accent = ( isset( $brand['brand_bar_accent_line'] ) && $brand['brand_bar_accent_line'] === '1' );
		if ( $show_accent ) {
			$line_rgb = $this->hex_to_rgb( $accent );
			$line_alloc = imagecolorallocatealpha( $canvas, $line_rgb['r'], $line_rgb['g'], $line_rgb['b'], 0 );
			// Accent line at the TOP edge of the bar (matches ImageMagickCompositor::draw_brand_bar
			// line 526: imagefilledrectangle(..., 0, $brand_bar_y, $w, $brand_bar_y + 1, ...)).
			// In our standalone PNG the bar's top is row 0.
			imagefilledrectangle( $canvas, 0, 0, $width, 1, $line_alloc );
		}

		// Logo — derives max-height/max-width from brand settings, matching
		// the HTML template's {{LOGO_MAX_HEIGHT_BOTTOM_CSS}} / {{LOGO_MAX_WIDTH_BOTTOM_CSS}}.
		$logo_padding_x = $this->parse_padding_h( $brand['brand_bar_padding'] ?? '', $width, $height );
		if ( $logo_padding_x === 0 ) $logo_padding_x = 20;

		$logo = $this->load_logo( [ 'brand' => $brand ] );
		$logo_w = 0;
		$logo_h = 0;
		if ( $logo ) {
			$orig_w = imagesx( $logo );
			$orig_h = imagesy( $logo );
			// Resolve max-height from brand settings: e.g. "clamp(24px,3.5cqh,36px)"
			$max_h_css = $brand['logo_max_height_bottom'] ?? Config::DEFAULT_LOGO_MAX_HEIGHT_BOTTOM;
			$max_logo_h = (int) round( $this->parse_css_size( $max_h_css, $width, $height ) );
			if ( $max_logo_h <= 0 ) $max_logo_h = $bar_h;
			// Resolve max-width from brand settings: e.g. "clamp(100px,25cqw,300px)"
			$max_w_css = $brand['logo_max_width_bottom'] ?? Config::DEFAULT_LOGO_MAX_WIDTH_BOTTOM;
			$max_logo_w = (int) round( $this->parse_css_size( $max_w_css, $width, $height ) );
			if ( $max_logo_w <= 0 ) $max_logo_w = $width;
			// Constrain logo to both max-height and max-width, preserving aspect ratio.
			if ( ( $orig_h > $max_logo_h || $orig_w > $max_logo_w ) && $orig_h > 0 && $orig_w > 0 ) {
				$scale_h = ( $max_logo_h > 0 ) ? $max_logo_h / $orig_h : 1;
				$scale_w = ( $max_logo_w > 0 ) ? $max_logo_w / $orig_w : 1;
				$scale   = min( $scale_h, $scale_w );
				$new_w   = max( 1, (int) ( $orig_w * $scale ) );
				$new_h   = max( 1, (int) ( $orig_h * $scale ) );
				$resized = imagecreatetruecolor( $new_w, $new_h );
				if ( $resized ) {
					imagesavealpha( $resized, true );
					imagefill( $resized, 0, 0, imagecolorallocatealpha( $resized, 0, 0, 0, 127 ) );
					imagecopyresampled( $resized, $logo, 0, 0, 0, 0, $new_w, $new_h, $orig_w, $orig_h );
					imagedestroy( $logo );
					$logo  = $resized;
					$orig_w = $new_w;
					$orig_h = $new_h;
				}
			}
			$logo_w = $orig_w;
			$logo_h = $orig_h;
			// Don't draw yet — position depends on logo_position centering.
		}

		$brand_name = $brand['brand_name'] ?? '';
		$brand_url = $brand['brand_url'] ?? '';
		$text_color = ! empty( $brand['brand_bar_text_color'] ) ? $brand['brand_bar_text_color'] : '#ffffff';
		$font_size = intval( $brand['brand_bar_font_size'] ?? Config::DEFAULT_BRAND_BAR_FONT_SIZE );
		$letter_spacing = intval( $brand['brand_bar_letter_spacing'] ?? Config::DEFAULT_BRAND_BAR_LETTER_SPACING );

		// Font from brand settings — matches {{BODY_FONT}} in the HTML template.
		$font_family = ! empty( $brand['font_body'] ) ? $brand['font_body'] : Config::DEFAULT_BRAND_FONT_BODY;
		$font_path = $this->resolve_font_path( $font_family );
		if ( $font_path && file_exists( $font_path ) ) {
			$text_rgb = $this->hex_to_rgb( $text_color );
			$text_alloc = imagecolorallocate( $canvas, $text_rgb['r'], $text_rgb['g'], $text_rgb['b'] );
			$text_y = (int) ( $bar_h / 2 ) + (int) ( $font_size / 3 );

			$brand_url_rgb = $this->hex_to_rgb( $accent );
			$url_alloc = imagecolorallocate( $canvas, $brand_url_rgb['r'], $brand_url_rgb['g'], $brand_url_rgb['b'] );
			$url_font_size = max( 9, $font_size - 2 );
			$url_text_y = (int) ( $bar_h / 2 ) + (int) ( $url_font_size / 3 );

			// Pre-calculate text widths with letter spacing.
			$chars = preg_split( '//u', $brand_name, -1, PREG_SPLIT_NO_EMPTY );
			$brand_name_w = 0;
			foreach ( $chars as $ch ) {
				$bbox = imagettfbbox( $font_size, 0, $font_path, $ch );
				$brand_name_w += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
			}

			$url_chars = preg_split( '//u', $brand_url, -1, PREG_SPLIT_NO_EMPTY );
			$url_total_w = 0;
			foreach ( $url_chars as $ch ) {
				$bbox = imagettfbbox( $url_font_size, 0, $font_path, $ch );
				$url_total_w += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
			}

			// CSS flex gaps from the HTML template:
			//   .brand-info gap (logo↔name): clamp(6px,1cqw,10px)
			//   .brand-bar  gap (info↔url):  clamp(12px,2cqw,20px)
			$logo_name_gap = (int) round( $this->parse_css_size( 'clamp(6px,1cqw,10px)', $width, $height ) );
			$flex_gap      = (int) round( $this->parse_css_size( 'clamp(12px,2cqw,20px)', $width, $height ) );

			// Layout depends on logo_position — matches the HTML template's
			// justify-content rule for .brand-bar[data-logo-position="..."].
			$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;
			$is_centered = in_array( $logo_position, [ 'top-left', 'top-right' ], true );
			$is_right    = ( $logo_position === 'bottom-right' );

			if ( $is_centered ) {
				// Center: total_w = logo + gap + name + flex_gap + url
				$content_w = $logo_w + $logo_name_gap + $brand_name_w + $flex_gap + $url_total_w;
				$start_x   = max( 0, (int) ( ( $width - $content_w ) / 2 ) );

				// Draw logo
				if ( $logo ) {
					$logo_y = (int) ( ( $bar_h - $logo_h ) / 2 );
					imagecopy( $canvas, $logo, $start_x, $logo_y, 0, 0, $logo_w, $logo_h );
					imagedestroy( $logo );
					$logo = null;
				}

				// Draw brand name
				$cx = $start_x + $logo_w + $logo_name_gap;
				foreach ( $chars as $ch ) {
					imagettftext( $canvas, $font_size, 0, $cx, $text_y, $text_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $font_size, 0, $font_path, $ch );
					$cx += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}

				// Draw URL
				$url_x = $start_x + $logo_w + $logo_name_gap + $brand_name_w + $flex_gap;
				foreach ( $url_chars as $ch ) {
					imagettftext( $canvas, $url_font_size, 0, $url_x, $url_text_y, $url_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $url_font_size, 0, $font_path, $ch );
					$url_x += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}
			} elseif ( $is_right ) {
				// Right-align: url at right edge, name to its left, logo to its left.
				if ( $logo ) {
					$logo_y = (int) ( ( $bar_h - $logo_h ) / 2 );
					$logo_x = $width - $logo_padding_x - $logo_w;
					imagecopy( $canvas, $logo, $logo_x, $logo_y, 0, 0, $logo_w, $logo_h );
					imagedestroy( $logo );
					$logo = null;
				}

				$name_x = $width - $logo_padding_x - $url_total_w - $flex_gap - $brand_name_w;
				$cx = $name_x;
				foreach ( $chars as $ch ) {
					imagettftext( $canvas, $font_size, 0, $cx, $text_y, $text_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $font_size, 0, $font_path, $ch );
					$cx += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}

				$url_x = $width - $logo_padding_x - $url_total_w;
				foreach ( $url_chars as $ch ) {
					imagettftext( $canvas, $url_font_size, 0, $url_x, $url_text_y, $url_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $url_font_size, 0, $font_path, $ch );
					$url_x += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}
			} else {
				// Left-align (default for bottom-left): logo at left, name after, url at right.
				if ( $logo ) {
					$logo_y = (int) ( ( $bar_h - $logo_h ) / 2 );
					imagecopy( $canvas, $logo, $logo_padding_x, $logo_y, 0, 0, $logo_w, $logo_h );
					imagedestroy( $logo );
					$logo = null;
				}

				$cx = $logo ? $logo_padding_x + $logo_w + $logo_name_gap : $logo_padding_x;
				foreach ( $chars as $ch ) {
					imagettftext( $canvas, $font_size, 0, $cx, $text_y, $text_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $font_size, 0, $font_path, $ch );
					$cx += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}

				$url_x = $width - $logo_padding_x - $url_total_w;
				foreach ( $url_chars as $ch ) {
					imagettftext( $canvas, $url_font_size, 0, $url_x, $url_text_y, $url_alloc, $font_path, $ch );
					$bbox = imagettfbbox( $url_font_size, 0, $font_path, $ch );
					$url_x += abs( $bbox[2] - $bbox[0] ) + $letter_spacing;
				}
			}

			// Destroy logo if not yet destroyed (no-logo case).
			if ( $logo ) imagedestroy( $logo );
		}

		$out_path = $this->temp_dir . '/brand_bar_' . uniqid() . '.png';
		$saved = imagepng( $canvas, $out_path, 1 );
		imagedestroy( $canvas );

		if ( ! $saved || ! file_exists( $out_path ) ) {
			return false;
		}

		return $out_path;
	}

	/**
	 * Render a top-corner logo overlay PNG — mirrors the collage pipeline's
	 * ImageMagickCompositor::draw_top_logo(). Constrained to brand settings'
	 * logo_max_height_top / logo_max_width_top.
	 *
	 * @param array  $brand Brand settings.
	 * @param int    $canvas_w Canvas width.
	 * @param int    $canvas_h Canvas height.
	 * @return string|false Path to PNG, or false on failure.
	 */
	public function render_top_logo_png( array $brand, int $canvas_w, int $canvas_h ) {
		$logo = $this->load_logo( [ 'brand' => $brand ] );
		if ( ! $logo ) return false;

		$orig_w = imagesx( $logo );
		$orig_h = imagesy( $logo );
		if ( $orig_w <= 0 || $orig_h <= 0 ) {
			imagedestroy( $logo );
			return false;
		}

		// Resolve max-height from brand settings: e.g. "clamp(24px,3cqh,34px)"
		$max_h_css = $brand['logo_max_height_top'] ?? Config::DEFAULT_LOGO_MAX_HEIGHT_TOP;
		$max_h = (int) round( $this->parse_css_size( $max_h_css, $canvas_w, $canvas_h ) );
		if ( $max_h <= 0 ) $max_h = (int) ( $canvas_h * 0.04 );

		// Resolve max-width from brand settings: e.g. "clamp(70px,11cqw,110px)"
		$max_w_css = $brand['logo_max_width_top'] ?? Config::DEFAULT_LOGO_MAX_WIDTH_TOP;
		$max_w = (int) round( $this->parse_css_size( $max_w_css, $canvas_w, $canvas_h ) );
		if ( $max_w <= 0 ) $max_w = (int) ( $canvas_w * 0.08 );

		// Constrain to both max-height and max-width, preserving aspect ratio.
		if ( ( $orig_h > $max_h || $orig_w > $max_w ) && $orig_h > 0 && $orig_w > 0 ) {
			$scale_h = ( $max_h > 0 ) ? $max_h / $orig_h : 1;
			$scale_w = ( $max_w > 0 ) ? $max_w / $orig_w : 1;
			$scale   = min( $scale_h, $scale_w );
			$new_w   = max( 1, (int) ( $orig_w * $scale ) );
			$new_h   = max( 1, (int) ( $orig_h * $scale ) );
			$resized = imagecreatetruecolor( $new_w, $new_h );
			if ( $resized ) {
				imagesavealpha( $resized, true );
				imagefill( $resized, 0, 0, imagecolorallocatealpha( $resized, 0, 0, 0, 127 ) );
				imagecopyresampled( $resized, $logo, 0, 0, 0, 0, $new_w, $new_h, $orig_w, $orig_h );
				imagedestroy( $logo );
				$logo = $resized;
			}
		}

		$out_path = $this->temp_dir . '/top_logo_' . uniqid() . '.png';
		$saved = imagepng( $logo, $out_path );
		imagedestroy( $logo );

		if ( ! $saved || ! file_exists( $out_path ) ) {
			return false;
		}

		Logger::info( 'video_top_logo_rendered', null, [
			'output' => basename( $out_path ),
			'size'   => filesize( $out_path ),
		], '200' );

		return $out_path;
	}

	/**
	 * Check if a file extension is a supported video type.
	 *
	 * @param string $extension File extension (without dot).
	 * @return bool True if video type.
	 */
	public static function is_video_extension( string $extension ): bool {
		return in_array( strtolower( $extension ), Config::VIDEO_EXTENSIONS, true );
	}

	/**
	 * Detect if a file is a video based on its content/type.
	 *
	 * @param string $file_path Path to file.
	 * @return bool True if file is a video.
	 */
	public static function is_video_file( string $file_path ): bool {
		$ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		if ( self::is_video_extension( $ext ) ) {
			return true;
		}

		if ( function_exists( 'mime_content_type' ) ) {
			$mime = @mime_content_type( $file_path );
			return strpos( $mime, 'video/' ) === 0;
		}

		return false;
	}

	// ── Audio Detection ───────────────────────────────────────────────────────

	/**
	 * Check if a video file contains at least one audio stream.
	 *
	 * @param string $video_path Path to video file.
	 * @return bool True if an audio stream exists.
	 */
	public function video_has_audio_stream( string $video_path ): bool {
		$cmd = sprintf(
			'%s -hide_banner -i %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $video_path )
		);
		@exec( $cmd, $output, $ret );
		// FFmpeg exits with code 1 when run with -i and no output file,
		// but it still prints stream info to stderr. Ignore the return code
		// and parse the output, matching get_video_duration()/get_video_dimensions().
		$joined = implode( "\n", $output );
		return preg_match( '/Stream\s*#\d+:\d+.*Audio:/i', $joined ) === 1;
	}

	/**
	 * Detect whether the audio content of a source video is primarily voice
	 * (speech), music (background music), or ambiguous.
	 *
	 * Strategy: probe for an audio stream; if present, sample several short
	 * windows spread across the video and score each window on two features:
	 *   1. speech_ratio — energy in the speech band (300–3400 Hz) vs full
	 *      spectrum. Speech concentrates energy here; music spreads it wider.
	 *   2. bass_ratio — energy below 200 Hz vs full spectrum. Music (esp.
	 *      with a beat/bed) carries far more sub-200 Hz energy than speech.
	 *
	 * Each window is classified voice/music, then the clip is decided by
	 * majority vote. This prevents a single musical intro/outro or a
	 * speech clip with ambient hall/background music from flipping the whole
	 * reel. Windows that land in the grey zone (speech_ratio 0.35–0.60)
	 * count as ambiguous votes rather than forcing a hard music verdict.
	 *
	 * @param string $video_path Path to the source video.
	 * @return string 'voice', 'music', or 'ambiguous'
	 */
	public function detect_audio_type( string $video_path ): string {
		if ( ! file_exists( $video_path ) ) {
			return 'ambiguous';
		}

		if ( ! $this->video_has_audio_stream( $video_path ) ) {
			Logger::info( 'video_audio_type_detected', null, [
				'video'  => basename( $video_path ),
				'result' => 'ambiguous',
				'reason' => 'no audio stream found',
			], '200' );
			return 'ambiguous';
		}

		$duration = $this->get_video_duration( $video_path );
		if ( $duration <= 0 ) {
			return 'ambiguous';
		}

		// Cap sample to 5 s but use at least 1 s for very short clips.
		$sample_duration = (int) min( 5, max( 1, $duration / 3 ) );

		// Spread windows across the clip (skip the very ends where intros/outros
		// tend to sit). For short clips this collapses to a single centered window.
		$offsets = array();
		if ( $duration >= 20 ) {
			$offsets = array( $duration * 0.2, $duration * 0.4, $duration * 0.6, $duration * 0.8 );
		} elseif ( $duration > 10 ) {
			$offsets = array( $duration * 0.33, $duration * 0.66 );
		} else {
			$offsets = array( 0.0 );
		}

		$voice_votes   = 0;
		$music_votes   = 0;
		$ambiguous_cnt = 0;
		$ratios        = array();
		$bass_ratios   = array();
		$rms_values    = array();

		foreach ( $offsets as $offset_seconds ) {
			if ( $offset_seconds + $sample_duration > $duration ) {
				$offset_seconds = max( 0.0, $duration - $sample_duration );
			}
			$analysis  = $this->analyze_audio_sample( $video_path, $sample_duration, $offset_seconds );
			$full_db   = $analysis['full_rms_db'];
			$speech_rt = $analysis['speech_ratio'];
			$bass_rt   = $analysis['bass_ratio'];

			$ratios[]      = round( $speech_rt, 4 );
			$bass_ratios[] = round( $bass_rt, 4 );
			$rms_values[]  = round( $full_db, 2 );

			// Silence in this window: ignore for voting (neither voice nor music).
			if ( $full_db < -50.0 ) {
				continue;
			}

			// Per-window classification using both features:
			//   - speech_ratio > 0.6  => confident speech (ignore bass: speech
			//     recordings can carry low-frequency energy too).
			//   - speech_ratio < 0.35 => confident non-speech (music).
			//   - grey zone 0.35–0.60 => default to preserving the source
			//     (ambiguous). Promote to music only when a strong low-frequency
			//     bed (bass_ratio >= 0.6) indicates background music, NOT speech.
			if ( $speech_rt > 0.6 ) {
				$voice_votes++;
			} elseif ( $speech_rt < 0.35 ) {
				$music_votes++;
			} else {
				$ambiguous_cnt++;
				if ( $bass_rt >= 0.6 ) {
					$music_votes++;
				}
			}
		}

		// Majority vote across informative windows.
		if ( $voice_votes > $music_votes && $voice_votes >= $ambiguous_cnt ) {
			$result = 'voice';
		} elseif ( $music_votes > $voice_votes ) {
			$result = 'music';
		} else {
			// Tie, or ambiguous dominates, or only silence: preserve the original
			// audio rather than risk muting genuine speech.
			$result = 'ambiguous';
		}

		$log_context = array(
			'video'             => basename( $video_path ),
			'result'            => $result,
			'speech_ratios'     => $ratios,
			'bass_ratios'       => $bass_ratios,
			'full_rms_db'       => $rms_values,
			'voice_votes'       => $voice_votes,
			'music_votes'       => $music_votes,
			'ambiguous_votes'   => $ambiguous_cnt,
			'sample_dur'        => $sample_duration,
			'windows'           => count( $offsets ),
		);

		Logger::info( 'video_audio_type_detected', null, $log_context, '200' );

		return $result;
	}

	/**
	 * Analyze a short audio segment extracted from a video.
	 *
	 * Measures overall RMS (mean volume) and speech-band RMS (300–3400 Hz)
	 * using FFmpeg's volumedetect filter. Returns the ratio of speech-band
	 * energy to total energy in linear amplitude space.
	 *
	 * @param string $video_path     Path to the source video.
	 * @param int    $sample_duration Duration in seconds to sample.
	 * @param float  $offset_seconds  Seek offset in seconds.
	 * @return array {full_rms_db, speech_rms_db, bass_rms_db, speech_ratio, bass_ratio}
	 */
	private function analyze_audio_sample( string $video_path, int $sample_duration, float $offset_seconds ): array {
		$ss = $this->format_timestamp( $offset_seconds );

		// Full-spectrum mean volume (RMS in dB)
		$cmd_full = sprintf(
			'%s -hide_banner -ss %s -i %s -t %d -ar 44100 -ac 1 -af "volumedetect" -f null - 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			$ss,
			escapeshellarg( $video_path ),
			$sample_duration
		);
		@exec( $cmd_full, $output_full, $ret_full );
		$full_rms_db = $this->parse_volume_level( implode( "\n", $output_full ) );

		// Speech-band mean volume (300 Hz high-pass + 3400 Hz low-pass)
		$cmd_speech = sprintf(
			'%s -hide_banner -ss %s -i %s -t %d -ar 44100 -ac 1 -af "highpass=f=300,lowpass=f=3400,volumedetect" -f null - 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			$ss,
			escapeshellarg( $video_path ),
			$sample_duration
		);
		@exec( $cmd_speech, $output_speech, $ret_speech );
		$speech_rms_db = $this->parse_volume_level( implode( "\n", $output_speech ) );

		// Bass-band mean volume (<200 Hz). Music (esp. with a beat/bed) carries
		// far more sub-200 Hz energy than speech; used to separate speech+BGM
		// from pure speech.
		$cmd_bass = sprintf(
			'%s -hide_banner -ss %s -i %s -t %d -ar 44100 -ac 1 -af "lowpass=f=200,volumedetect" -f null - 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			$ss,
			escapeshellarg( $video_path ),
			$sample_duration
		);
		@exec( $cmd_bass, $output_bass, $ret_bass );
		$bass_rms_db = $this->parse_volume_level( implode( "\n", $output_bass ) );

		// Convert dB RMS to linear amplitude and compute ratios.
		// volumedetect mean_volume is RMS (10*log10(mean_power)),
		// so amplitude = 10^(dB/20).
		$full_linear   = pow( 10, $full_rms_db / 20 );
		$speech_linear = pow( 10, $speech_rms_db / 20 );
		$bass_linear   = pow( 10, $bass_rms_db / 20 );
		$ratio     = ( $full_linear > 0 ) ? min( 1.0, $speech_linear / $full_linear ) : 0.0;
		$bass_ratio = ( $full_linear > 0 ) ? min( 1.0, $bass_linear / $full_linear ) : 0.0;

		return [
			'full_rms_db'   => $full_rms_db,
			'speech_rms_db' => $speech_rms_db,
			'bass_rms_db'   => $bass_rms_db,
			'speech_ratio'  => $ratio,
			'bass_ratio'    => $bass_ratio,
		];
	}

	/**
	 * Parse the mean volume from volumedetect FFmpeg output.
	 *
	 * The volumedetect filter outputs lines like:
	 *   [Parsed_volumedetect_0 ...] mean_volume: -18.5 dB
	 *
	 * @param string $ffoutput Raw FFmpeg stderr.
	 * @return float Mean volume in dB (defaults to -96.0 if not found).
	 */
	private function parse_volume_level( string $ffoutput ): float {
		if ( preg_match( '/mean_volume:\s*(-?[\d.]+)\s*dB/', $ffoutput, $m ) ) {
			return (float) $m[1];
		}
		if ( preg_match( '/mean_volume\s*:\s*(-?[\d.]+)/i', $ffoutput, $m ) ) {
			return (float) $m[1];
		}
		return -96.0;
	}

	// ── Private Helpers ──────────────────────────────────────────────────────

	/**
	 * Resolve a CSS size value to pixels — mirrors what the browser does for
	 * the HTML template's CSS. Handles: px, cqw (container-query width),
	 * cqh (container-query height), and clamp(MIN, VAL, MAX).
	 *
	 * @param string $css          CSS size value (e.g. "24px", "clamp(14px,2cqw,24px)").
	 * @param int    $container_w  Container width in pixels (canvas width).
	 * @param int    $container_h  Container height in pixels (canvas height).
	 * @return float Resolved pixel value.
	 */
	private function parse_css_size( $css, $container_w, $container_h ) {
		$css = trim( $css );
		if ( $css === '' ) return 0.0;

		// clamp(MIN, VAL, MAX)
		if ( preg_match( '/^clamp\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)$/i', $css, $m ) ) {
			$min = $this->parse_css_size( $m[1], $container_w, $container_h );
			$val = $this->parse_css_size( $m[2], $container_w, $container_h );
			$max = $this->parse_css_size( $m[3], $container_w, $container_h );
			return max( $min, min( $val, $max ) );
		}

		// Npx
		if ( preg_match( '/^([\d.]+)\s*px$/i', $css, $m ) ) {
			return (float) $m[1];
		}

		// Ncqw (container-query width = % of container width)
		if ( preg_match( '/^([\d.]+)\s*cqw$/i', $css, $m ) ) {
			return $container_w * (float) $m[1] / 100.0;
		}

		// Ncqh (container-query height = % of container height)
		if ( preg_match( '/^([\d.]+)\s*cqh$/i', $css, $m ) ) {
			return $container_h * (float) $m[1] / 100.0;
		}

		// Plain number (treat as px)
		if ( is_numeric( $css ) ) {
			return (float) $css;
		}

		return 0.0;
	}

	/**
	 * Parse CSS padding shorthand and return an associative array of pixel values.
	 * CSS shorthand: 1 val = all, 2 = vert horiz, 3 = vert horiz vert, 4 = top right bot left.
	 *
	 * @param string $css          CSS padding value (e.g. "0 clamp(14px,2cqw,24px)").
	 * @param int    $container_w  Container width.
	 * @param int    $container_h  Container height.
	 * @return array Associative array with top, right, bottom, left pixel values.
	 */
	public function parse_padding_h( $css, $container_w, $container_h ) {
		if ( empty( $css ) ) return [ 'top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0 ];
		$parts = preg_split( '/\s+/', trim( $css ) );
		$count = count( $parts );
		if ( $count === 0 ) return [ 'top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0 ];

		$top = $right = $bottom = $left = '';
		if ( $count === 1 ) {
			$top = $right = $bottom = $left = $parts[0];
		} elseif ( $count === 2 ) {
			$top = $bottom = $parts[0];
			$left = $right = $parts[1];
		} elseif ( $count === 3 ) {
			$top = $parts[0];
			$left = $right = $parts[1];
			$bottom = $parts[2];
		} else {
			$top = $parts[0];
			$right = $parts[1];
			$bottom = $parts[2];
			$left = $parts[3];
		}

		return [
			'top'    => max( 0, (int) round( $this->parse_css_size( $top, $container_w, $container_h ) ) ),
			'right'  => max( 0, (int) round( $this->parse_css_size( $right, $container_w, $container_h ) ) ),
			'bottom' => max( 0, (int) round( $this->parse_css_size( $bottom, $container_w, $container_h ) ) ),
			'left'   => max( 0, (int) round( $this->parse_css_size( $left, $container_w, $container_h ) ) ),
		];
	}

	/**
	 * Extract the horizontal padding from a CSS padding shorthand string.
	 * Uses parse_padding_h for full parsing but returns only the left/right average or sum as needed.
	 * NOTE: For backwards compatibility where an integer was expected, this now returns the left value.
	 *
	 * @param string $css          CSS padding value (e.g. "0 clamp(14px,2cqw,24px)").
	 * @param int    $container_w  Container width.
	 * @param int    $container_h  Container height.
	 * @return int Horizontal padding (left) in pixels.
	 */
	public function get_padding_left( $css, $container_w, $container_h ) {
		$parsed = $this->parse_padding_h( $css, $container_w, $container_h );
		return $parsed['left'];
	}

	private function find_ffmpeg(): string {
		$candidates = [
			'/usr/bin/ffmpeg',
			'/usr/local/bin/ffmpeg',
			'/usr/sbin/ffmpeg',
		];

		foreach ( $candidates as $path ) {
			if ( file_exists( $path ) && is_executable( $path ) ) {
				return $path;
			}
		}

		if ( function_exists( 'exec' ) ) {
			@exec( 'which ffmpeg 2>/dev/null', $out, $ret );
			if ( $ret === 0 && ! empty( $out[0] ) && file_exists( trim( $out[0] ) ) ) {
				return trim( $out[0] );
			}
		}

		return '/usr/bin/ffmpeg';
	}

	private function to_even( int $value ): int {
		return $value & ~1;
	}

	private function format_timestamp( float $seconds ): string {
		$h = (int) floor( $seconds / 3600 );
		$m = (int) floor( ( $seconds % 3600 ) / 60 );
		$s = $seconds % 60;
		return sprintf( '%02d:%02d:%06.3f', $h, $m, $s );
	}

	private function resolve_font_path( string $font_family ): string {
		$map = [
			'Noto Nastaliq Urdu'        => 'NotoNastaliqUrdu-Regular.ttf',
			'Noto Nastaliq Urdu Medium' => 'NotoNastaliqUrdu-Medium.ttf',
			'Jameel Noori Nastaliq'     => 'JameelNooriNastaliq.ttf',
			'Nafees Web Naskh'          => 'NafeesWebNaskh.ttf',
			'Noto Sans Arabic'          => 'NotoSansArabic-Regular.ttf',
			'Montserrat'                => 'Montserrat-Bold.ttf',
			'Inter'                     => 'Inter-Regular.ttf',
			'Poppins'                   => 'Poppins-Bold.ttf',
			'Oswald'                    => 'Oswald-Bold.ttf',
			'Roboto'                    => 'Roboto-Bold.ttf',
			'Bebas Neue'                => 'BebasNeue-Regular.ttf',
			'Lora'                      => 'Lora-Bold.ttf',
			'Raleway'                   => 'Raleway-Bold.ttf',
			'Playfair Display'          => 'PlayfairDisplay-Bold.ttf',
		];
		$file = $map[ $font_family ] ?? '';
		if ( $file === '' ) return '';
		$path = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts/' . $file;
		if ( file_exists( $path ) ) return $path;
		// Urdu-only fallbacks (preserved from original behavior).
		$urdu_fallbacks = [ 'NotoNastaliqUrdu-Regular.ttf', 'JameelNooriNastaliq.ttf', 'NotoSansArabic-Regular.ttf' ];
		$fonts_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts';
		foreach ( $urdu_fallbacks as $fb ) {
			$fb_path = $fonts_dir . '/' . $fb;
			if ( file_exists( $fb_path ) ) return $fb_path;
		}
		// Latin system-font fallbacks — mirrors ImageMagickCompositor::resolve_font_path
		// so a missing bundled font (e.g. Montserrat-Bold.ttf / Inter-Regular.ttf) does not
		// silently blank the video heading and brand bar.
		$system_fallbacks = [
			'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
			'/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
			'/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
			'C:\\Windows\\Fonts\\arial.ttf',
			'C:\\Windows\\Fonts\\verdana.ttf',
		];
		foreach ( $system_fallbacks as $fb ) {
			if ( file_exists( $fb ) ) return $fb;
		}
		return '';
	}

	private function ensure_fontconfig(): string {
		$fonts_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts';
		$fc_file = $fonts_dir . '/fonts.conf';
		$abs = realpath( $fonts_dir );
		if ( ! $abs ) return '';

		$expected_dir = str_replace( '\\', '/', $abs );
		if ( file_exists( $fc_file ) ) {
			$existing = file_get_contents( $fc_file );
			if ( $existing !== false && strpos( $existing, $expected_dir ) !== false ) {
				return $fc_file;
			}
		}

		$xml = '<?xml version="1.0"?>' . "\n"
			. '<!DOCTYPE fontconfig SYSTEM "fonts.dtd">' . "\n"
			. '<fontconfig>' . "\n"
			. '  <dir>' . htmlspecialchars( $abs, ENT_XML1 ) . '</dir>' . "\n"
			. '</fontconfig>';
		if ( file_put_contents( $fc_file, $xml ) ) {
			return $fc_file;
		}
		return '';
	}

	private function hex_to_rgb( string $hex ): array {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return [ 'r' => 0, 'g' => 0, 'b' => 0 ];
		}
		return [
			'r' => hexdec( substr( $hex, 0, 2 ) ),
			'g' => hexdec( substr( $hex, 2, 2 ) ),
			'b' => hexdec( substr( $hex, 4, 2 ) ),
		];
	}

	/**
	 * Load an image from a URL or local path — mirrors ImageMagickCompositor::load_image().
	 * Required so the brand bar can composite the logo just like the image pipeline.
	 */
	private function load_image( $url ) {
		if ( empty( $url ) ) return null;

		if ( ! preg_match( '/^https?:\/\//i', $url ) && file_exists( $url ) ) {
			$ext = strtolower( pathinfo( $url, PATHINFO_EXTENSION ) );
			if ( $ext === 'jpg' || $ext === 'jpeg' ) return @imagecreatefromjpeg( $url );
			if ( $ext === 'png' ) return @imagecreatefrompng( $url );
			if ( $ext === 'webp' ) return @imagecreatefromwebp( $url );
			return @imagecreatefromstring( file_get_contents( $url ) );
		}

		$upload_dir = wp_upload_dir();
		if ( strpos( $url, $upload_dir['baseurl'] ) === 0 ) {
			$path = str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $url );
			if ( file_exists( $path ) ) {
				$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
				if ( $ext === 'jpg' || $ext === 'jpeg' ) return @imagecreatefromjpeg( $path );
				if ( $ext === 'png' ) return @imagecreatefrompng( $path );
				if ( $ext === 'webp' ) return @imagecreatefromwebp( $path );
				return @imagecreatefromstring( file_get_contents( $path ) );
			}
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $url, 30 );
		if ( is_wp_error( $tmp ) ) {
			Logger::warning( 'video_brand_logo_download_failed', null, [ 'url' => mb_substr( $url, 0, 120 ) ], '500' );
			return null;
		}
		$img = @imagecreatefromstring( file_get_contents( $tmp ) );
		@unlink( $tmp );
		return $img;
	}

	/**
	 * Load the brand logo at original size — constraining to brand settings'
	 * max-height/max-width happens in render_brand_bar_to_png().
	 */
	private function load_logo( array $d ) {
		$brand = $d['brand'] ?? [];
		$logo_url = $brand['logo_url'] ?? '';
		if ( empty( $logo_url ) ) return null;

		$logo = $this->load_image( $logo_url );
		if ( ! $logo ) return null;

		$logo_w = imagesx( $logo );
		$logo_h = imagesy( $logo );
		if ( $logo_w <= 0 || $logo_h <= 0 ) {
			imagedestroy( $logo );
			return null;
		}

		return $logo;
	}

	/**
	 * Prepend a poster frame to the video so the first frame shows actual content
	 * instead of black. Extracts a frame at 25% of duration and creates a 0.5s clip,
	 * then concatenates it before the full video.
	 *
	 * @param string $video_path Path to the composed video.
	 * @return string|false Path to the new video with poster, or false on failure.
	 */
	private function prepend_poster_frame( string $video_path ) {
		$duration = $this->get_video_duration( $video_path );
		if ( $duration <= 1.0 ) {
			return false;
		}

		$seek_time = max( 0.5, $duration * 0.25 );
		$poster_clip = $this->temp_dir . '/poster_clip_' . uniqid() . '.mp4';
		$output = $this->temp_dir . '/poster_final_' . uniqid() . '.mp4';

		// Step 1: Create 0.5s clip from a frame at 25% duration.
		// The loop filter duplicates the single frame to produce a short video
		// whose first frame is actual video content (not black).
		$cmd1 = sprintf(
			'%s -hide_banner -loglevel error -ss %s -i %s -frames:v 1 -vf "loop=loop=15:size=1:start=0" -t 0.5 -c:v libx264 -crf 18 -pix_fmt yuv420p -an %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			$seek_time,
			escapeshellarg( $video_path ),
			escapeshellarg( $poster_clip )
		);

		@exec( $cmd1, $out1, $ret1 );
		if ( $ret1 !== 0 || ! file_exists( $poster_clip ) || filesize( $poster_clip ) < 100 ) {
			@unlink( $poster_clip );
			return false;
		}

		// Step 2: Concatenate poster clip + original video.
		// Audio is taken from the original video (map 1:a?).
		$cmd2 = sprintf(
			'%s -hide_banner -loglevel error -i %s -i %s -filter_complex "[0:v][1:v]concat=n=2:v=1:a=0[outv]" -map "[outv]" -map 1:a? -c:v libx264 -crf 18 -preset fast -c:a copy %s 2>&1',
			escapeshellarg( $this->ffmpeg_path ),
			escapeshellarg( $poster_clip ),
			escapeshellarg( $video_path ),
			escapeshellarg( $output )
		);

		@exec( $cmd2, $out2, $ret2 );
		@unlink( $poster_clip );

		if ( $ret2 !== 0 || ! file_exists( $output ) || filesize( $output ) < 1000 ) {
			@unlink( $output );
			return false;
		}

		Logger::info( 'video_poster_frame_prepended', null, [
			'video'     => basename( $video_path ),
			'seek_time' => round( $seek_time, 2 ),
			'duration'  => round( $duration, 2 ),
			'output'    => basename( $output ),
		], '200' );

		return $output;
	}
}
