<?php

/**
 * Generate Article Job
 *
 * @package SEO_Article_Generator
 * @since 2.25.0
 */

namespace SEO_Article_Generator\Queue\Jobs;

use SEO_Article_Generator\Queue\Abstract_Job;
use SEO_Article_Generator\Jobs\Job_Handler;
use SEO_Article_Generator\Logger;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Handles AI article generation sequentially.
 */
class Generate_Article_Job extends Abstract_Job
{
    /**
     * Execute the article generation.
     *
     * @return bool True on success.
     */
    public function handle()
    {
        $job_id  = $this->reference_id;
        $logger  = new \SEO_Article_Generator\Logger();
        $handler = new Job_Handler($logger);

        // Audit Fix: Call the concrete processor to start the AI generation task.
        $handler->process_job($job_id, $this->queue_job_id, $this->reservation_token);

        // Always return reconciled as Job_Handler manages the ticket for this job type.
        return \SEO_Article_Generator\Queue\Job_Interface::STATUS_RECONCILED;
    }
}
