package com.snsaver.app.data.repository
import com.snsaver.app.data.*
import com.snsaver.app.data.db.DownloadDao
import com.snsaver.app.domain.model.*
import com.snsaver.app.domain.repository.DownloadRepository
import kotlinx.coroutines.flow.*
import javax.inject.Inject
class DownloadRepositoryImpl @Inject constructor(private val dao:DownloadDao):DownloadRepository{
 override fun observeAll()=dao.observeAll().map{it.map{e->e.toDomain()}}
 override fun observeCompleted()=dao.observeStatuses(listOf(DownloadStatus.COMPLETED)).map{it.map{e->e.toDomain()}}
 override fun observe(id:Long)=dao.observe(id).map{it?.toDomain()}
 override suspend fun get(id:Long)=dao.get(id)?.toDomain()
 override suspend fun add(item:DownloadItem)=dao.insert(item.toEntity())
 override suspend fun update(item:DownloadItem)=dao.update(item.toEntity())
 override suspend fun setStatus(id:Long,status:DownloadStatus,progress:Int)=dao.setStatus(id,status,progress)
 override suspend fun fail(id:Long,message:String?)=dao.fail(id,message)
 override suspend fun delete(id:Long)=dao.delete(id)
 override suspend fun deleteAll()=dao.deleteAll()
}
